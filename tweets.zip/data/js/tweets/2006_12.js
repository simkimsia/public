Grailbird.data.tweets_2006_12 = 
 [ {
  "source" : "im",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1949563",
  "text" : "350 people showed up last night.  Nobody died.  Success!",
  "id" : 1949563,
  "created_at" : "2007-01-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/devices\" rel=\"nofollow\"\u003Etxt\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1890593",
  "text" : "Turquoise is the new black",
  "id" : 1890593,
  "created_at" : "2006-12-31 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/devices\" rel=\"nofollow\"\u003Etxt\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1861523",
  "text" : "I don't have time for hangovers anymore.",
  "id" : 1861523,
  "created_at" : "2006-12-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "im",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1825403",
  "text" : "McLeod has sound!  Or is it seond?",
  "id" : 1825403,
  "created_at" : "2006-12-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "im",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1704563",
  "text" : "new year's resolution: do something that surprises, inspires, and terrifies me (again)",
  "id" : 1704563,
  "created_at" : "2006-12-26 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "im",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1618563",
  "text" : "lazy night drinking wine and cutting stickers after sweeping the halls of McLeod",
  "id" : 1618563,
  "created_at" : "2006-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/devices\" rel=\"nofollow\"\u003Etxt\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1645393",
  "text" : "Drinking Red Bull and trying to summarize my year. You?",
  "id" : 1645393,
  "created_at" : "2006-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "im",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1454383",
  "text" : "lack of sleep + egg nog + self-inflicted madness = ooeeooeeooee",
  "id" : 1454383,
  "created_at" : "2006-12-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/devices\" rel=\"nofollow\"\u003Etxt\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1417923",
  "text" : "Not eating soy.",
  "id" : 1417923,
  "created_at" : "2006-12-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "im",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1397273",
  "text" : "If you're coming to McLeod's NYE party (which you're invited to), send me 10 pictures summarizing your 2007 by next Wed!",
  "id" : 1397273,
  "created_at" : "2006-12-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "im",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1397403",
  "text" : "I mean, summarize 2006.  I'm from the future, sorry.",
  "id" : 1397403,
  "created_at" : "2006-12-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/devices\" rel=\"nofollow\"\u003Etxt\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shorty",
      "screen_name" : "Shorty",
      "indices" : [ 0, 7 ],
      "id_str" : "25195917",
      "id" : 25195917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1286983",
  "text" : "@Shorty's ! Notaries make me nervous, need a drink",
  "id" : 1286983,
  "created_at" : "2006-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/devices\" rel=\"nofollow\"\u003Etxt\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1239653",
  "text" : "That Red Bull, rum, and red wine invention last night has had dire consequences.",
  "id" : 1239653,
  "created_at" : "2006-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "im",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "962243",
  "text" : "naming the rooms of McLeod Residence... parlor, south room, tower, laboratory, etc.",
  "id" : 962243,
  "created_at" : "2006-12-11 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "im",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "890313",
  "text" : "i think i just had my craziest idea",
  "id" : 890313,
  "created_at" : "2006-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "im",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "892113",
  "text" : "I can't wait for my caffeine to wear off to find out if my crazy idea is actually any good!",
  "id" : 892113,
  "created_at" : "2006-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "547643",
  "text" : "Thinking about accountability... what creates it?  A mirror, a video camera, a friend?",
  "id" : 547643,
  "created_at" : "2006-12-02 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]