Grailbird.data.tweets_2009_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/devices\" rel=\"nofollow\"\u003Etxt\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3066515150",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar What do you need? The doctors are at Cal Anderson and here for you!",
  "id" : 3066515150,
  "created_at" : "2009-08-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meredith Modzelewski",
      "screen_name" : "meredithmo",
      "indices" : [ 111, 122 ],
      "id_str" : "17069950",
      "id" : 17069950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3074077549",
  "text" : "Are Sarah and Todd Palin getting a divorce? Shambles! http:\/\/tinyurl.com\/nt6gfs http:\/\/tinyurl.com\/ksjev5 (via @meredithmo)",
  "id" : 3074077549,
  "created_at" : "2009-08-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3063176350",
  "text" : "Perfect night for watching Flash Gordon at Cal Anderson at dusk, right?",
  "id" : 3063176350,
  "created_at" : "2009-08-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3064338013",
  "text" : "8:36pm Waiting for a table before food then a movie in the park http:\/\/flic.kr\/p\/6KGoCn",
  "id" : 3064338013,
  "created_at" : "2009-08-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2945190058",
  "text" : "8:36pm Festival of Losers is my first kickball game and it's CRAZY! http:\/\/flic.kr\/p\/6KwiWY",
  "id" : 2945190058,
  "created_at" : "2009-07-31 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2953809549",
  "geo" : { },
  "id_str" : "3055101976",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel Yes, searching, then no service. Restarting didn't help but now my phone's fine and Kellianne's is screwed. It ain't right!",
  "id" : 3055101976,
  "in_reply_to_status_id" : 2953809549,
  "created_at" : "2009-07-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3056024578",
  "text" : "Gonna be renting a canoe at UW's Waterfront Activities Center around 2 if anyone wants to join.  Meet us there!",
  "id" : 3056024578,
  "created_at" : "2009-07-31 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 90, 100 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3057187084",
  "text" : "Singing \"Easy like a hurricane blowing through\" - Emery Carl http:\/\/flic.kr\/p\/6KFgqJ (via @kellianne)",
  "id" : 3057187084,
  "created_at" : "2009-07-31 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2920737435",
  "text" : "We're going to be a bit late to the lake tonight -- my masters at Apple called and need me to do something for them.",
  "id" : 2920737435,
  "created_at" : "2009-07-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 3, 17 ],
      "id_str" : "820661",
      "id" : 820661
    }, {
      "name" : "Lusty Lady Marquee",
      "screen_name" : "lustylady",
      "indices" : [ 61, 71 ],
      "id_str" : "18593137",
      "id" : 18593137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2922882664",
  "text" : "RT @daveschappell Seattle Lusty Lady billboard fans -- enjoy @lustylady",
  "id" : 2922882664,
  "created_at" : "2009-07-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2923477888",
  "text" : "8:36pm Hanging with Hannah totally ready to jump in Greenlake after faxing things to Apple upside-down http:\/\/flic.kr\/p\/6KfBgm",
  "id" : 2923477888,
  "created_at" : "2009-07-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2923473283",
  "geo" : { },
  "id_str" : "2923492248",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel We're on our way! Plan on hopping back in!",
  "id" : 2923492248,
  "in_reply_to_status_id" : 2923473283,
  "created_at" : "2009-07-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 24, 40 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2925761669",
  "text" : "I love this one too! RT @cjlikearockstar daily aphorism- between 2 evils, i always take the one i haven't tried before",
  "id" : 2925761669,
  "created_at" : "2009-07-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2926332701",
  "text" : "Swimming at Greenlake = not even dying of man-eating bacteria. Plus Shorty's hotdog = no prob limo!",
  "id" : 2926332701,
  "created_at" : "2009-07-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2903135513",
  "text" : "8:36pm Catching Kellianne up on the dancing wedding YouTube video. And Hannah just got back from camp! http:\/\/flic.kr\/p\/6JYoef",
  "id" : 2903135513,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2904083263",
  "geo" : { },
  "id_str" : "2904102114",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling That's not magic that's duck poop. :) I'm just jealous!",
  "id" : 2904102114,
  "in_reply_to_status_id" : 2904083263,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2913500717",
  "text" : "I'm sort of losing my mind a little bit thinking about this stuff.  It happens every couple years: http:\/\/bit.ly\/4cAtG",
  "id" : 2913500717,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2913913007",
  "text" : "Anyone using the new @BooyahTeam game? http:\/\/booyah.com I'm not quite getting it yet, but it seems interesting!",
  "id" : 2913913007,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2914508728",
  "text" : "Let's all go swimming in Greenlake tonight! 7ish? See you there!",
  "id" : 2914508728,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/devices\" rel=\"nofollow\"\u003Etxt\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kindrameyer",
      "screen_name" : "kindrameyer",
      "indices" : [ 0, 12 ],
      "id_str" : "16400277",
      "id" : 16400277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2914688097",
  "in_reply_to_user_id" : 16400277,
  "text" : "@kindrameyer What if I get a stomach cramp??? :) Will you be by the dock area or somewhere else?",
  "id" : 2914688097,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "kindrameyer",
  "in_reply_to_user_id_str" : "16400277",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/devices\" rel=\"nofollow\"\u003Etxt\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2917868456",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Those who swam last night are still alive! That said, I'll swim wherever friends are! I mean, who better to deathwish with, right?",
  "id" : 2917868456,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2918091656",
  "text" : "Note to self, there are 3 kinds of people: those who complain, those who complain about complaining, & those who are silent... crap.",
  "id" : 2918091656,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2918203863",
  "geo" : { },
  "id_str" : "2918535837",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar I need better names for them but I have: producer, maintainer, artist, sharer, tinkerer, explorer, organizer, & consumer.",
  "id" : 2918535837,
  "in_reply_to_status_id" : 2918203863,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BedlamCoffee",
      "screen_name" : "BedlamCoffee",
      "indices" : [ 67, 80 ],
      "id_str" : "29375223",
      "id" : 29375223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2881007797",
  "text" : "It's pretty neat! Also, a little tempted to build one myself... RT @BedlamCoffee: CoCollage at Bedlam now! Register at bedlam.cocollage.com",
  "id" : 2881007797,
  "created_at" : "2009-07-28 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2883551368",
  "text" : "8:36pm Leaving a productive day at work for some cool sushi http:\/\/flic.kr\/p\/6JANga",
  "id" : 2883551368,
  "created_at" : "2009-07-28 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kindrameyer",
      "screen_name" : "kindrameyer",
      "indices" : [ 0, 12 ],
      "id_str" : "16400277",
      "id" : 16400277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2899587500",
  "geo" : { },
  "id_str" : "2899767276",
  "in_reply_to_user_id" : 16400277,
  "text" : "@kindrameyer Can we bring a 14-year old?",
  "id" : 2899767276,
  "in_reply_to_status_id" : 2899587500,
  "created_at" : "2009-07-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "kindrameyer",
  "in_reply_to_user_id_str" : "16400277",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2863247556",
  "text" : "Made good progress on the magic photo mirror this weekend. It's gonna be awesome!",
  "id" : 2863247556,
  "created_at" : "2009-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2864200087",
  "text" : "8:36pm BBQ'ed, did the dishes, pet the cat, now nothing left to do but watch True Blood I guess! http:\/\/flic.kr\/p\/6JgfS2",
  "id" : 2864200087,
  "created_at" : "2009-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2872985811",
  "text" : "I had a realization right before bed last night and somehow figured it out more in my sleep!",
  "id" : 2872985811,
  "created_at" : "2009-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy James Hall",
      "screen_name" : "JimmyJameson",
      "indices" : [ 0, 13 ],
      "id_str" : "35141809",
      "id" : 35141809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2873026047",
  "geo" : { },
  "id_str" : "2873498304",
  "in_reply_to_user_id" : 35141809,
  "text" : "@JimmyJameson More abstract! I'm gonna try to figure it out more today. But first I gotta listen to that crow report!",
  "id" : 2873498304,
  "in_reply_to_status_id" : 2873026047,
  "created_at" : "2009-07-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "JimmyJameson",
  "in_reply_to_user_id_str" : "35141809",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2847809981",
  "text" : "8:36pm Drinks with Aimee at Rendezvous http:\/\/flic.kr\/p\/6HZY6N",
  "id" : 2847809981,
  "created_at" : "2009-07-26 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2831788269",
  "text" : "8:36pm Making dinner while listening to NPR podcasts http:\/\/flic.kr\/p\/6HKfP1",
  "id" : 2831788269,
  "created_at" : "2009-07-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jesuisjuba",
      "screen_name" : "jesuisjuba",
      "indices" : [ 0, 11 ],
      "id_str" : "47478936",
      "id" : 47478936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2830069713",
  "geo" : { },
  "id_str" : "2840023809",
  "in_reply_to_user_id" : 47478936,
  "text" : "@jesuisjuba Twitter occasionally purges spam accounts, and all of our follower counts down a bit. So, you only lost 25 spam followers.",
  "id" : 2840023809,
  "in_reply_to_status_id" : 2830069713,
  "created_at" : "2009-07-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "jesuisjuba",
  "in_reply_to_user_id_str" : "47478936",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Track Your Happiness",
      "screen_name" : "trackhappiness",
      "indices" : [ 39, 54 ],
      "id_str" : "56808301",
      "id" : 56808301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2840062229",
  "text" : "The new http:\/\/trackyourhappiness.org (@trackhappiness) project is the best mood-tracking tool out there at the moment.",
  "id" : 2840062229,
  "created_at" : "2009-07-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2812122618",
  "text" : "8:36pm Madsens! Roof! Emergency room stories! http:\/\/flic.kr\/p\/6Hvazj",
  "id" : 2812122618,
  "created_at" : "2009-07-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2814981175",
  "text" : "OH: To life. Which is pain. (and too dark to capture) http:\/\/flic.kr\/p\/6Ht9Ut",
  "id" : 2814981175,
  "created_at" : "2009-07-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2827121151",
  "text" : "Hangovers make me paranoid.",
  "id" : 2827121151,
  "created_at" : "2009-07-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2788300607",
  "text" : "Tossing paper airplanes off the 22nd floor.",
  "id" : 2788300607,
  "created_at" : "2009-07-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2791712363",
  "text" : "8:36pm My paper airplane compatriates in Vancouver about to get all you can eat sushi at Shobusen http:\/\/flic.kr\/p\/6HeGhN",
  "id" : 2791712363,
  "created_at" : "2009-07-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2793259325",
  "text" : "Vancouver beats Seattle at fireworks.",
  "id" : 2793259325,
  "created_at" : "2009-07-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2793306134",
  "geo" : { },
  "id_str" : "2793513709",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara Yes! First day!",
  "id" : 2793513709,
  "in_reply_to_status_id" : 2793306134,
  "created_at" : "2009-07-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2793702536",
  "geo" : { },
  "id_str" : "2794658346",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara I definitely chose the right day to visit! It was amazing.",
  "id" : 2794658346,
  "in_reply_to_status_id" : 2793702536,
  "created_at" : "2009-07-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meredith Modzelewski",
      "screen_name" : "meredithmo",
      "indices" : [ 3, 14 ],
      "id_str" : "17069950",
      "id" : 17069950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2804011296",
  "text" : "RT @meredithmo \"It is not necessary to change. Survival is not mandatory.\" -- W. Edwards Deming",
  "id" : 2804011296,
  "created_at" : "2009-07-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2771456747",
  "text" : "8:36pm Trying to explain Eschaton to Sopor http:\/\/flic.kr\/p\/6GT5ED",
  "id" : 2771456747,
  "created_at" : "2009-07-22 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infsum",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2772170252",
  "text" : "8 November Year of The Depend Adult Undergarment \nInterdependence Day\nGaudeamus Igitur\nis the weirdest chapter so far. By far. #infsum",
  "id" : 2772170252,
  "created_at" : "2009-07-22 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Karnjanaprakorn",
      "screen_name" : "mikekarnj",
      "indices" : [ 22, 32 ],
      "id_str" : "5901702",
      "id" : 5901702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2782911679",
  "text" : "Super fascinating! RT @mikekarnj From the New Yorker, Malcolm Gladwell: The psychology of overconfidence -- http:\/\/bit.ly\/nu9Q7",
  "id" : 2782911679,
  "created_at" : "2009-07-22 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2784761170",
  "text" : "Apparently my washed passport, history of name changes, copy of Infinite Jest and naturally awkward demeanor is suspicious to border police.",
  "id" : 2784761170,
  "created_at" : "2009-07-22 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2751801850",
  "text" : "8:36pm Downloading the 2nd episode of True Blood after a slow walk home. I love it! http:\/\/flic.kr\/p\/6GzCzc",
  "id" : 2751801850,
  "created_at" : "2009-07-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2731598794",
  "geo" : { },
  "id_str" : "2731644758",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Ah you must be on endnote 110! I've been watching it coming closer for a while now... I just passed 104.",
  "id" : 2731644758,
  "in_reply_to_status_id" : 2731598794,
  "created_at" : "2009-07-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2733985600",
  "text" : "8:36pm Cute movie http:\/\/flic.kr\/p\/6Ggny2",
  "id" : 2733985600,
  "created_at" : "2009-07-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2742090216",
  "text" : "I've decided to bus up to Vancouver this Wed for a one day secret adventure. Anyone there have a couch for me to crash on?",
  "id" : 2742090216,
  "created_at" : "2009-07-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2744633902",
  "text" : "Watching Apollo XI land: http:\/\/kottke.org\/apollo-11\/",
  "id" : 2744633902,
  "created_at" : "2009-07-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2716487998",
  "text" : "8:36pm Trying to read Infinite Jest but keep falling asleep http:\/\/flic.kr\/p\/6FUKYM",
  "id" : 2716487998,
  "created_at" : "2009-07-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2724254957",
  "text" : "Who is Scott S. and how many times do I need to checkin here to become mayor? (@ Bedlam Coffee in Seattle) http:\/\/bit.ly\/3paaFs",
  "id" : 2724254957,
  "created_at" : "2009-07-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2724336711",
  "text" : "How much cuter would the world be if humans weren't the only ones that could sense rhythm and tap to the beat? This pug should be dancing.",
  "id" : 2724336711,
  "created_at" : "2009-07-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2724363074",
  "geo" : { },
  "id_str" : "2725059592",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling Are pugs your olives and raisins of the animal world? Cause this pug right here is PRETTY CUTE! Even without tapping his foot.",
  "id" : 2725059592,
  "in_reply_to_status_id" : 2724363074,
  "created_at" : "2009-07-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kimberley",
      "screen_name" : "xaotica",
      "indices" : [ 3, 11 ],
      "id_str" : "13983",
      "id" : 13983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2725548529",
  "text" : "Hm @xaotica points out that talking birds can dance (http:\/\/bit.ly\/1183u3). Does it take a sound-imitating brain to dance? So no cats\/dogs?",
  "id" : 2725548529,
  "created_at" : "2009-07-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2700912597",
  "text" : "8:36pm Just got out of the shower after my first post-half-marathon run http:\/\/flic.kr\/p\/6FEkSk",
  "id" : 2700912597,
  "created_at" : "2009-07-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2701140909",
  "text" : "Just got a Google Wave developer sandbox account in my inbox. Can't wait to try it out!",
  "id" : 2701140909,
  "created_at" : "2009-07-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2701965475",
  "text" : "First thoughts on Google Wave: 1) Why so slow? 2) Where are my people? 3) Wait, what? 4) I want to like this!",
  "id" : 2701965475,
  "created_at" : "2009-07-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 107, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2710690145",
  "text" : "What do you think of this very basic break-down of different kinds of self-medication? http:\/\/bit.ly\/LFFpR #fb",
  "id" : 2710690145,
  "created_at" : "2009-07-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Adventure School",
      "screen_name" : "adventureschool",
      "indices" : [ 50, 66 ],
      "id_str" : "351312115",
      "id" : 351312115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2679121256",
  "text" : "All ~700 of 'em! Count your @cjlikearockstars! RT @AdventureSchool: Bastille Day Fete photobooth pics are up! http:\/\/bit.ly\/101paR",
  "id" : 2679121256,
  "created_at" : "2009-07-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2682082374",
  "text" : "8:36pm Firing up the grill for romanticles date with wifey after a day of inspiring meetings all over the place http:\/\/flic.kr\/p\/6FqjP2",
  "id" : 2682082374,
  "created_at" : "2009-07-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BedlamCoffee",
      "screen_name" : "BedlamCoffee",
      "indices" : [ 61, 74 ],
      "id_str" : "29375223",
      "id" : 29375223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2692212863",
  "text" : "The cinnamon toast and \"really really strong iced coffee\" at @bedlamcoffee are woah delicious breakfastioso!",
  "id" : 2692212863,
  "created_at" : "2009-07-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin.P",
      "screen_name" : "MPREV",
      "indices" : [ 12, 18 ],
      "id_str" : "1599582248",
      "id" : 1599582248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2693748020",
  "text" : "Awesome! RT @mprev: Montage from the Bastille day celebration photobooth at the Corson Building, http:\/\/bit.ly\/7eOm5",
  "id" : 2693748020,
  "created_at" : "2009-07-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2663584811",
  "text" : "Walking to dinner after a productive but hazy day http:\/\/flic.kr\/p\/6FeTQN",
  "id" : 2663584811,
  "created_at" : "2009-07-16 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enjoymentland",
      "screen_name" : "enjoymentland",
      "indices" : [ 28, 42 ],
      "id_str" : "19808652",
      "id" : 19808652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2673861348",
  "text" : "My morning meditation... RT @enjoymentland: New blog post: Fear of failure http:\/\/bit.ly\/T6SjG",
  "id" : 2673861348,
  "created_at" : "2009-07-16 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2642429475",
  "text" : "Chicken race! (slightly confused) http:\/\/flic.kr\/p\/6EW7Ph",
  "id" : 2642429475,
  "created_at" : "2009-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2645951695",
  "text" : "8:36pm Mike is the photo mirror hero! http:\/\/flic.kr\/p\/6EZ9SC",
  "id" : 2645951695,
  "created_at" : "2009-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2646642909",
  "geo" : { },
  "id_str" : "2646911837",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne Are you already tired of first polygamy style? Oh well. Onwards and upwards!",
  "id" : 2646911837,
  "in_reply_to_status_id" : 2646642909,
  "created_at" : "2009-07-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Adventure School",
      "screen_name" : "adventureschool",
      "indices" : [ 27, 43 ],
      "id_str" : "351312115",
      "id" : 351312115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2655915936",
  "text" : "770 pictures were taken at @adventureschool's awesome Bastille Day party at the Corson Building yesterday! Going through them now...",
  "id" : 2655915936,
  "created_at" : "2009-07-15 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2623629412",
  "text" : "In my own spreadsheet-heavy, list-making, nail-biting, coffee-chugging way, I'm sort of freaking out a little about what I got us into.",
  "id" : 2623629412,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2623904175",
  "text" : "To be honest, the fear of failure is a necessary ingredient in my \"best of all possible worlds.\" Wouldn't want to live without it.",
  "id" : 2623904175,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2625547601",
  "text" : "Tried to list all of my money-making schemes today. 9 total, plus just got a new one! Too bad I can't live by quantity of ideas alone...",
  "id" : 2625547601,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2625858527",
  "geo" : { },
  "id_str" : "2626185342",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Hit me!",
  "id" : 2626185342,
  "in_reply_to_status_id" : 2625858527,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2626306683",
  "text" : "8:36pm Hannah's getting all packed up for her camp tomorrow! http:\/\/flic.kr\/p\/6EFjZS",
  "id" : 2626306683,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2633826442",
  "text" : "Kellianne is a crazy hula-hooper http:\/\/flic.kr\/p\/6EJuw8",
  "id" : 2633826442,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Adventure School",
      "screen_name" : "adventureschool",
      "indices" : [ 84, 100 ],
      "id_str" : "351312115",
      "id" : 351312115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2636282001",
  "text" : "I'll be at the Corson Building today at the Bastille Day F\u00EAte put on by the amazing @adventureschool. Come by! My photobooth+chicken races!",
  "id" : 2636282001,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lia bulaong",
      "screen_name" : "liabulaong",
      "indices" : [ 17, 28 ],
      "id_str" : "188534264",
      "id" : 188534264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2636457413",
  "text" : "I want all 5! RT @liabulaong: if i was a dude and had $500 I would TOTALLY buy one of these neon suits: http:\/\/is.gd\/1yIh4",
  "id" : 2636457413,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Boscardin",
      "screen_name" : "abosco",
      "indices" : [ 0, 7 ],
      "id_str" : "16742020",
      "id" : 16742020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2636498438",
  "geo" : { },
  "id_str" : "2636682361",
  "in_reply_to_user_id" : 16742020,
  "text" : "@abosco Maybe I need to throw a fundraiser.",
  "id" : 2636682361,
  "in_reply_to_status_id" : 2636498438,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "abosco",
  "in_reply_to_user_id_str" : "16742020",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2637010709",
  "geo" : { },
  "id_str" : "2637182743",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar What can I do for you in exchange for a neon suit (or 5?)",
  "id" : 2637182743,
  "in_reply_to_status_id" : 2637010709,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2639686844",
  "text" : "Bastille Day awesomeness! (@ corson building in Seattle) http:\/\/bit.ly\/N7oDo",
  "id" : 2639686844,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/devices\" rel=\"nofollow\"\u003Etxt\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2640933603",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Yes come over!",
  "id" : 2640933603,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2608621917",
  "text" : "8:36pm Family relaxation time! http:\/\/flic.kr\/p\/6EkWYW",
  "id" : 2608621917,
  "created_at" : "2009-07-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2611025261",
  "text" : "Finished the latest of the beautiful and troubling Up Series documentaries, 49 Up, and now can't sleep. Oh mortality. Tick tock tick tock.",
  "id" : 2611025261,
  "created_at" : "2009-07-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enjoymentland",
      "screen_name" : "enjoymentland",
      "indices" : [ 98, 112 ],
      "id_str" : "19808652",
      "id" : 19808652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2611074170",
  "text" : "Insomnia could also be related to the fact that today, with the help of a spreadsheet, I forecast @enjoymentland's \"worst case scenario.\"",
  "id" : 2611074170,
  "created_at" : "2009-07-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2611086204",
  "text" : "Or the fact that it's only 12:36am.",
  "id" : 2611086204,
  "created_at" : "2009-07-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2611091216",
  "geo" : { },
  "id_str" : "2611103413",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel The weird thing is, I got in bed at 9:30! Living with a teen is exhausting! :)",
  "id" : 2611103413,
  "in_reply_to_status_id" : 2611091216,
  "created_at" : "2009-07-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2621560438",
  "text" : "My photobooth prototype is working and ready for a test run at the Corson Building's Bastille Day Fete tomorrow! http:\/\/flic.kr\/p\/6Ewr1i",
  "id" : 2621560438,
  "created_at" : "2009-07-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "indices" : [ 11, 19 ],
      "id_str" : "4030",
      "id" : 4030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2592721224",
  "text" : "Me too! RT @monstro \"PIE LAB = a neutral place + a slice of pie, which = conversation.\" I want one! http:\/\/pielab.org\/",
  "id" : 2592721224,
  "created_at" : "2009-07-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2593589305",
  "text" : "8:36pm Kellianne's mom's last night and birthday! http:\/\/flic.kr\/p\/6DWVKg",
  "id" : 2593589305,
  "created_at" : "2009-07-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2601735611",
  "text" : "Kellianne's 14-year old sis is staying with us. So far, lots of fun but not much work getting done!",
  "id" : 2601735611,
  "created_at" : "2009-07-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2602325833",
  "geo" : { },
  "id_str" : "2602412260",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar Then get started on that manifesto! Take a walk, eat some fro-yo, and drink some tabasco sauce. Works every time.",
  "id" : 2602412260,
  "in_reply_to_status_id" : 2602325833,
  "created_at" : "2009-07-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2604212083",
  "text" : "Is anyone good at finding or making sound clips? I need something to play right before a picture is taken with my photobooth. Help!",
  "id" : 2604212083,
  "created_at" : "2009-07-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Lane",
      "screen_name" : "futileboy",
      "indices" : [ 0, 10 ],
      "id_str" : "4132781",
      "id" : 4132781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2604237331",
  "geo" : { },
  "id_str" : "2604434922",
  "in_reply_to_user_id" : 4132781,
  "text" : "@futileboy Hm... he might be too professional for what I need.  I just need a 2-3 second dinging thing for an event Tuesday, any thoughts?",
  "id" : 2604434922,
  "in_reply_to_status_id" : 2604237331,
  "created_at" : "2009-07-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "futileboy",
  "in_reply_to_user_id_str" : "4132781",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2602886698",
  "geo" : { },
  "id_str" : "2604467440",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar Start small. Make a list of the most important points. Maybe 10 things. Like that article from last week. Build from there.",
  "id" : 2604467440,
  "in_reply_to_status_id" : 2602886698,
  "created_at" : "2009-07-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2605204050",
  "geo" : { },
  "id_str" : "2605256787",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Like countdown beeps... but I think I'm gonna just use my ghetto garageband beeps... they're good enough. But tips for future?",
  "id" : 2605256787,
  "in_reply_to_status_id" : 2605204050,
  "created_at" : "2009-07-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2578947751",
  "text" : "8:36pm I scream http:\/\/flic.kr\/p\/6DL4kS",
  "id" : 2578947751,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infsum",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2586553065",
  "text" : "According to my spreadsheet I'm finally caught up on my Infinite Jest reading.  It's so good! http:\/\/bit.ly\/ZbJiu #infsum",
  "id" : 2586553065,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2562310826",
  "text" : "8:36pm Taking a lil' nap after a big day in Ballard http:\/\/flic.kr\/p\/6DrFpD",
  "id" : 2562310826,
  "created_at" : "2009-07-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2563385257",
  "geo" : { },
  "id_str" : "2564162483",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling We're going to Bainbridge tomorrow. Wanna join?",
  "id" : 2564162483,
  "in_reply_to_status_id" : 2563385257,
  "created_at" : "2009-07-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2564202667",
  "geo" : { },
  "id_str" : "2564215029",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling After lunch or so.",
  "id" : 2564215029,
  "in_reply_to_status_id" : 2564202667,
  "created_at" : "2009-07-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2544476842",
  "text" : "8:36pm Just eatin' melon, cheese, and prosciutto before dinner is all, and reading Infinite Jest is all http:\/\/flic.kr\/p\/6DfPYQ",
  "id" : 2544476842,
  "created_at" : "2009-07-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infsum",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2545032658",
  "text" : "\"You play right up to your limit & then pass your limit & look back at your former limit & wave a hankie at it, embarking.\" pg166 #infsum",
  "id" : 2545032658,
  "created_at" : "2009-07-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 40, 56 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2552770720",
  "text" : "Summer fashion tips from my good friend @cjlikearockstar. I especially like \"Cowboy boots and bow ties. Duh.\" http:\/\/bit.ly\/1boNNL",
  "id" : 2552770720,
  "created_at" : "2009-07-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All Day Buffet",
      "screen_name" : "alldaybuffet",
      "indices" : [ 48, 61 ],
      "id_str" : "426827630",
      "id" : 426827630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2552855536",
  "text" : "I'm gonna check out all 100 of these links from @alldaybuffet http:\/\/alldaybuffet.org\/newyork100\/",
  "id" : 2552855536,
  "created_at" : "2009-07-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2552897544",
  "text" : "Already loving this one! Trust Art http:\/\/trustart.org\/how-to-play",
  "id" : 2552897544,
  "created_at" : "2009-07-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2523763025",
  "geo" : { },
  "id_str" : "2524218217",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz So true! Awesome work on the app, by the way!",
  "id" : 2524218217,
  "in_reply_to_status_id" : 2523763025,
  "created_at" : "2009-07-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2525441754",
  "text" : "Picking up Kellianne's mom and sister for their first visit to the Northwest! (@ Seattle-Tacoma International Airport) http:\/\/bit.ly\/CPmwT",
  "id" : 2525441754,
  "created_at" : "2009-07-08 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2526791599",
  "text" : "8:36pm Just got our new house guest home. Hungry! http:\/\/flic.kr\/p\/6CZ4Tw",
  "id" : 2526791599,
  "created_at" : "2009-07-08 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2537910029",
  "text" : "The parking lot that my office overlooks is highly entertaining.  Funny how people see parking lots as private locations.",
  "id" : 2537910029,
  "created_at" : "2009-07-08 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2508396881",
  "text" : "8:36pm Russell's helping me empty the storage unit http:\/\/flic.kr\/p\/6CBr9k",
  "id" : 2508396881,
  "created_at" : "2009-07-07 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2505486799",
  "geo" : { },
  "id_str" : "2519876966",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit I'm gonna be busy with a 14-year old guest for the next couple weeks, but I would definitely love to share thoughts soon!",
  "id" : 2519876966,
  "in_reply_to_status_id" : 2505486799,
  "created_at" : "2009-07-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hi koo girl",
      "screen_name" : "haikugirl",
      "indices" : [ 0, 10 ],
      "id_str" : "580262124",
      "id" : 580262124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2489378187",
  "geo" : { },
  "id_str" : "2489440419",
  "in_reply_to_user_id" : 12761252,
  "text" : "@haikugirl Oh, I can walk, I'm just a bit slow. Excited about tomorrow!",
  "id" : 2489440419,
  "in_reply_to_status_id" : 2489378187,
  "created_at" : "2009-07-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "heatherquintal",
  "in_reply_to_user_id_str" : "12761252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2490876807",
  "text" : "This issue of Wired titled \"Living by Numbers\" seems to have been written for me. Must get a copy! http:\/\/bit.ly\/nNfx6",
  "id" : 2490876807,
  "created_at" : "2009-07-06 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2490905382",
  "text" : "The issue seems to focus on tracking exercise and eating habits, which are fine, but I think morale is still the hidden, difficult, gem.",
  "id" : 2490905382,
  "created_at" : "2009-07-06 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2491753718",
  "text" : "8:36pm Rehashing the day with wifey at Ohana http:\/\/flic.kr\/p\/6Cgzog",
  "id" : 2491753718,
  "created_at" : "2009-07-06 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infsum",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2501821576",
  "text" : "Now caught up to the 11pgs\/day reading train for Infinite Jest. Just in time for this amazing analysis of pg 140 http:\/\/bit.ly\/9y9MI #infsum",
  "id" : 2501821576,
  "created_at" : "2009-07-06 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 31, 42 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2502303753",
  "text" : "More cities should do this! RT @jasonfried: From Boston comes a wonderful combo of tech & civic nuisance reporting http:\/\/tinyurl.com\/ok87r8",
  "id" : 2502303753,
  "created_at" : "2009-07-06 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zipcar",
      "screen_name" : "Zipcar",
      "indices" : [ 0, 7 ],
      "id_str" : "19364978",
      "id" : 19364978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2502576257",
  "in_reply_to_user_id" : 19364978,
  "text" : "@zipcar You need more trucks available in downtown Seattle... one of my primary uses for you is to help me move big things around!",
  "id" : 2502576257,
  "created_at" : "2009-07-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "Zipcar",
  "in_reply_to_user_id_str" : "19364978",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2504826554",
  "text" : "Is it possible to build a hierarchy of all emotions & rate them on strength, pleasantness, energy, & focus? How many emotion words r there?",
  "id" : 2504826554,
  "created_at" : "2009-07-06 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charity Gourley",
      "screen_name" : "GourleyGirl",
      "indices" : [ 0, 12 ],
      "id_str" : "19945483",
      "id" : 19945483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2504954797",
  "geo" : { },
  "id_str" : "2505281451",
  "in_reply_to_user_id" : 19945483,
  "text" : "@GourleyGirl True, I wouldn't rate on usefulness or necessity, but rather pleasant&lt;-&gt;unpleasant, weak&lt;-&gt;strong, etc. Is anger ever pleasant?",
  "id" : 2505281451,
  "in_reply_to_status_id" : 2504954797,
  "created_at" : "2009-07-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "GourleyGirl",
  "in_reply_to_user_id_str" : "19945483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2505139316",
  "geo" : { },
  "id_str" : "2505300266",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit Yes! What if we could somehow collaboratively build a list of antidotes for specific negative emotions ranked by effectiveness?",
  "id" : 2505300266,
  "in_reply_to_status_id" : 2505139316,
  "created_at" : "2009-07-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2478187914",
  "text" : "8:36pm 4th of July at Erin's with sangria, dj, pool, friends, and beautiful sunset http:\/\/flic.kr\/p\/6BWiVk",
  "id" : 2478187914,
  "created_at" : "2009-07-05 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2479198593",
  "text" : "Fireworks finale! http:\/\/flic.kr\/p\/6C2wns",
  "id" : 2479198593,
  "created_at" : "2009-07-05 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 64, 80 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2485385867",
  "text" : "Sprained my ankle last night pretty bad. Today I'm walking like @cjlikearockstar with his bum paw.",
  "id" : 2485385867,
  "created_at" : "2009-07-05 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leeni",
      "screen_name" : "leenirama",
      "indices" : [ 0, 10 ],
      "id_str" : "17236443",
      "id" : 17236443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2487338632",
  "geo" : { },
  "id_str" : "2487393376",
  "in_reply_to_user_id" : 17236443,
  "text" : "@leenirama That's what I was hoping! Are you going to have to get a bigger pool for it to live in?",
  "id" : 2487393376,
  "in_reply_to_status_id" : 2487338632,
  "created_at" : "2009-07-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "leenirama",
  "in_reply_to_user_id_str" : "17236443",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leeni",
      "screen_name" : "leenirama",
      "indices" : [ 0, 10 ],
      "id_str" : "17236443",
      "id" : 17236443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2487436388",
  "geo" : { },
  "id_str" : "2487542023",
  "in_reply_to_user_id" : 17236443,
  "text" : "@leenirama Let me know when you get the big inflatable cauldron and we'll make inflatable turtle soup in the hot tub!",
  "id" : 2487542023,
  "in_reply_to_status_id" : 2487436388,
  "created_at" : "2009-07-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "leenirama",
  "in_reply_to_user_id_str" : "17236443",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2464586926",
  "text" : "8:36pm At Chef Wang's looking at the Friends book with friends http:\/\/flic.kr\/p\/6BKFk1",
  "id" : 2464586926,
  "created_at" : "2009-07-04 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2475116536",
  "text" : "Human \/ pet look-alike contest! http:\/\/flic.kr\/p\/6BT9eP",
  "id" : 2475116536,
  "created_at" : "2009-07-04 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2446390457",
  "text" : "Got a little lost in Renton, found a fireworks stand! http:\/\/flic.kr\/p\/6BpZyn",
  "id" : 2446390457,
  "created_at" : "2009-07-03 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2448509118",
  "text" : "8:36pm Watching kids in the hot tub. Waiting for our turn. http:\/\/flic.kr\/p\/6BvQJs",
  "id" : 2448509118,
  "created_at" : "2009-07-03 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2449774342",
  "text" : "Fireworks! http:\/\/flic.kr\/p\/6BsG9z",
  "id" : 2449774342,
  "created_at" : "2009-07-03 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/app\/twitter\/id333903271?mt=8\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2459903643",
  "text" : "My first frugalification report. Spending in June was 39% lower than spending in May. I hope July is even better. http:\/\/bit.ly\/11t47L",
  "id" : 2459903643,
  "created_at" : "2009-07-03 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2431544607",
  "text" : "8:36pm On a boat http:\/\/flic.kr\/p\/6BfZeG",
  "id" : 2431544607,
  "created_at" : "2009-07-02 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]