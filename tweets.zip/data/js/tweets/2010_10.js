Grailbird.data.tweets_2010_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29332929405",
  "text" : "Am I a pirate? Yes. http:\/\/tcrn.ch\/cx5PJX\n\nThough I disagree with the premise that entrepreneurs don't understand risk. Boredom is a risk!",
  "id" : 29332929405,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "indices" : [ 0, 6 ],
      "id_str" : "8708232",
      "id" : 8708232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29333018213",
  "geo" : { },
  "id_str" : "29334970919",
  "in_reply_to_user_id" : 8708232,
  "text" : "@brynn Glad you're playing again! How was the first month?",
  "id" : 29334970919,
  "in_reply_to_status_id" : 29333018213,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "brynn",
  "in_reply_to_user_id_str" : "8708232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 0, 2 ],
      "id_str" : "11222",
      "id" : 11222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29339401634",
  "geo" : { },
  "id_str" : "29339765000",
  "in_reply_to_user_id" : 11222,
  "text" : "@k You had a good excuse. Congratulations, by the way! No way to skip the month, but after today it won't matter, because it's over...",
  "id" : 29339765000,
  "in_reply_to_status_id" : 29339401634,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "k",
  "in_reply_to_user_id_str" : "11222",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "indices" : [ 0, 6 ],
      "id_str" : "8708232",
      "id" : 8708232
    }, {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 7, 12 ],
      "id_str" : "10959642",
      "id" : 10959642
    }, {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 13, 15 ],
      "id_str" : "11222",
      "id" : 11222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29339529022",
  "geo" : { },
  "id_str" : "29339865055",
  "in_reply_to_user_id" : 8708232,
  "text" : "@brynn @tara @k Start a new team here http:\/\/bit.ly\/bv6mrg or join mine! http:\/\/bit.ly\/akBFln",
  "id" : 29339865055,
  "in_reply_to_status_id" : 29339529022,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "brynn",
  "in_reply_to_user_id_str" : "8708232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125, -122.3475 ]
  },
  "id_str" : "29340263275",
  "text" : "8:36pm Helping people get ready for November's health month. Sign up friends: healthmonth.com http:\/\/flic.kr\/p\/8PFNUF",
  "id" : 29340263275,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29340142679",
  "geo" : { },
  "id_str" : "29340746779",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara As many as you want! Join my team join my team!",
  "id" : 29340746779,
  "in_reply_to_status_id" : 29340142679,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29343565967",
  "text" : "OH: \"It's got everything. It's metallic. It's got a bow.\"",
  "id" : 29343565967,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gwen Bell",
      "screen_name" : "gwenbell",
      "indices" : [ 0, 9 ],
      "id_str" : "1250104952",
      "id" : 1250104952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29345886023",
  "text" : "@gwenbell Good luck with the writing this month! Have you said what you're planning to write?",
  "id" : 29345886023,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A. Smith",
      "screen_name" : "michaelasmith",
      "indices" : [ 0, 14 ],
      "id_str" : "16609638",
      "id" : 16609638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29343929095",
  "geo" : { },
  "id_str" : "29346015204",
  "in_reply_to_user_id" : 16609638,
  "text" : "@michaelasmith Close! Actually, way off, but good guess! :)",
  "id" : 29346015204,
  "in_reply_to_status_id" : 29343929095,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "michaelasmith",
  "in_reply_to_user_id_str" : "16609638",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanya",
      "screen_name" : "Rabourn",
      "indices" : [ 0, 8 ],
      "id_str" : "691073",
      "id" : 691073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29346521838",
  "geo" : { },
  "id_str" : "29346663418",
  "in_reply_to_user_id" : 691073,
  "text" : "@Rabourn How so? And will you play again?",
  "id" : 29346663418,
  "in_reply_to_status_id" : 29346521838,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "Rabourn",
  "in_reply_to_user_id_str" : "691073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nanowrimo",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29347476166",
  "text" : "REALLY jealous of those playing #nanowrimo starting tonight. I've done it twice but this year just added some Easter eggs to 750words.com",
  "id" : 29347476166,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3054\u3058\u307E\u306A\u306A\u307F",
      "screen_name" : "hyph_en",
      "indices" : [ 0, 8 ],
      "id_str" : "1349259768",
      "id" : 1349259768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29375656001",
  "geo" : { },
  "id_str" : "29379883096",
  "in_reply_to_user_id" : 69960885,
  "text" : "@Hyph_En You should get an email about it in the next hour or so!  Let me know if you don't.",
  "id" : 29379883096,
  "in_reply_to_status_id" : 29375656001,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "AkvileHarlow",
  "in_reply_to_user_id_str" : "69960885",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 45, 56 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29399184710",
  "text" : "I just unlocked the \"Healthy Crane\" badge on @foursquare! http:\/\/4sq.com\/czuEz2",
  "id" : 29399184710,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ida Z. Sagberg",
      "screen_name" : "ziarah",
      "indices" : [ 0, 7 ],
      "id_str" : "21390842",
      "id" : 21390842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29400304971",
  "geo" : { },
  "id_str" : "29400616890",
  "in_reply_to_user_id" : 21390842,
  "text" : "@ziarah I fixed a bug with the badge giving machine, so thanks for pointing it out!  :)",
  "id" : 29400616890,
  "in_reply_to_status_id" : 29400304971,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "ziarah",
  "in_reply_to_user_id_str" : "21390842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 3, 13 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29418772524",
  "text" : "RT @webwright: Once again, Farmville lost more users last month than your web service will ever have - http:\/\/goo.gl\/rZSU",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29418156143",
    "text" : "Once again, Farmville lost more users last month than your web service will ever have - http:\/\/goo.gl\/rZSU",
    "id" : 29418156143,
    "created_at" : "2010-11-01 23:46:06 +0000",
    "user" : {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "protected" : false,
      "id_str" : "786818",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000854425648\/4327d7de842d356da89f9f923f2a4e01_normal.jpeg",
      "id" : 786818,
      "verified" : false
    }
  },
  "id" : 29418772524,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29418156143",
  "geo" : { },
  "id_str" : "29418913104",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright I'd be curious to know whether the total uniques went up for the bunch, or if that is declining too...",
  "id" : 29418913104,
  "in_reply_to_status_id" : 29418156143,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 0, 12 ],
      "id_str" : "15019184",
      "id" : 15019184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29242763941",
  "geo" : { },
  "id_str" : "29244168372",
  "in_reply_to_user_id" : 15019184,
  "text" : "@heyamberrae So the former? If you don't pay attention to the flavors of your meal it is less tasty?",
  "id" : 29244168372,
  "in_reply_to_status_id" : 29242763941,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "heyamberrae",
  "in_reply_to_user_id_str" : "15019184",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Specht",
      "screen_name" : "maryspecht",
      "indices" : [ 0, 11 ],
      "id_str" : "259834384",
      "id" : 259834384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29243941833",
  "geo" : { },
  "id_str" : "29244310800",
  "in_reply_to_user_id" : 7357082,
  "text" : "@maryspecht Yeah I still think about that book often. What's next?",
  "id" : 29244310800,
  "in_reply_to_status_id" : 29243941833,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "designmary",
  "in_reply_to_user_id_str" : "7357082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ramdan The Viking",
      "screen_name" : "TheRamdan",
      "indices" : [ 0, 10 ],
      "id_str" : "746722298",
      "id" : 746722298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29244194999",
  "geo" : { },
  "id_str" : "29244407849",
  "in_reply_to_user_id" : 76539829,
  "text" : "@theRamdan Tomorrow!",
  "id" : 29244407849,
  "in_reply_to_status_id" : 29244194999,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "ramd4n",
  "in_reply_to_user_id_str" : "76539829",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Specht",
      "screen_name" : "maryspecht",
      "indices" : [ 0, 11 ],
      "id_str" : "259834384",
      "id" : 259834384
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthmonth",
      "indices" : [ 46, 58 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29244596603",
  "geo" : { },
  "id_str" : "29244783048",
  "in_reply_to_user_id" : 7357082,
  "text" : "@maryspecht Awesome! Maybe we should create a #healthmonth book club.",
  "id" : 29244783048,
  "in_reply_to_status_id" : 29244596603,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "designmary",
  "in_reply_to_user_id_str" : "7357082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 0, 12 ],
      "id_str" : "15019184",
      "id" : 15019184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29245059147",
  "geo" : { },
  "id_str" : "29245703750",
  "in_reply_to_user_id" : 15019184,
  "text" : "@heyamberrae I'd say the event will be more fun but the food will not necessarily be more tasty. Unless good mood leads to focus on flavors.",
  "id" : 29245703750,
  "in_reply_to_status_id" : 29245059147,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "heyamberrae",
  "in_reply_to_user_id_str" : "15019184",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Specht",
      "screen_name" : "maryspecht",
      "indices" : [ 0, 11 ],
      "id_str" : "259834384",
      "id" : 259834384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29245687439",
  "geo" : { },
  "id_str" : "29245821132",
  "in_reply_to_user_id" : 7357082,
  "text" : "@maryspecht Definitely not the only ones! Will think about the best way to do that. Are there any existing online book club tools out there?",
  "id" : 29245821132,
  "in_reply_to_status_id" : 29245687439,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "designmary",
  "in_reply_to_user_id_str" : "7357082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "octave kitten",
      "screen_name" : "zombielolita",
      "indices" : [ 0, 13 ],
      "id_str" : "239622110",
      "id" : 239622110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29301627400",
  "geo" : { },
  "id_str" : "29301936240",
  "in_reply_to_user_id" : 16366882,
  "text" : "@zombielolita Everyone. But it should be back now. Sorry!",
  "id" : 29301936240,
  "in_reply_to_status_id" : 29301627400,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karolyn Sitanggang",
      "screen_name" : "mKarolyn",
      "indices" : [ 0, 9 ],
      "id_str" : "91932008",
      "id" : 91932008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29230301318",
  "geo" : { },
  "id_str" : "29232585070",
  "in_reply_to_user_id" : 91932008,
  "text" : "@mKarolyn I think I just sponsored you!  Good luck in November!",
  "id" : 29232585070,
  "in_reply_to_status_id" : 29230301318,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "mKarolyn",
  "in_reply_to_user_id_str" : "91932008",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anju Stovia \u2606 \u2606 ",
      "screen_name" : "AnjuStovia",
      "indices" : [ 0, 11 ],
      "id_str" : "59758921",
      "id" : 59758921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29233776482",
  "geo" : { },
  "id_str" : "29234825673",
  "in_reply_to_user_id" : 59758921,
  "text" : "@AnjuStovia Send me a link to your page and I'll sponsor you!",
  "id" : 29234825673,
  "in_reply_to_status_id" : 29233776482,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "AnjuStovia",
  "in_reply_to_user_id_str" : "59758921",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29237461701",
  "text" : "How much does what you get out of an experience depend on where you choose to put your attention vs the natural qualities of the experience?",
  "id" : 29237461701,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125, -122.347667 ]
  },
  "id_str" : "29243755175",
  "text" : "8:36pm Tired and reading while everyone else is being social. Enjoying Halloween via Twitter this year. Have fun! http:\/\/flic.kr\/p\/8PkoUr",
  "id" : 29243755175,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Chivers",
      "screen_name" : "JessicaChivers",
      "indices" : [ 0, 15 ],
      "id_str" : "17492166",
      "id" : 17492166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29121887377",
  "geo" : { },
  "id_str" : "29138879868",
  "in_reply_to_user_id" : 17492166,
  "text" : "@JessicaChivers Your streak seems intact. Did you get into the site after all? It was definitely a Facebook-was-down issue.",
  "id" : 29138879868,
  "in_reply_to_status_id" : 29121887377,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "JessicaChivers",
  "in_reply_to_user_id_str" : "17492166",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Chivers",
      "screen_name" : "JessicaChivers",
      "indices" : [ 0, 15 ],
      "id_str" : "17492166",
      "id" : 17492166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29143111448",
  "geo" : { },
  "id_str" : "29143664823",
  "in_reply_to_user_id" : 17492166,
  "text" : "@JessicaChivers Ah, got it. Fixed now!",
  "id" : 29143664823,
  "in_reply_to_status_id" : 29143111448,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "JessicaChivers",
  "in_reply_to_user_id_str" : "17492166",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.347667 ]
  },
  "id_str" : "29147180642",
  "text" : "My favorite work setup: pen, paper, bread, butter, soup, and wine http:\/\/flic.kr\/p\/8P7GTd",
  "id" : 29147180642,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 8, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29147334000",
  "text" : "Q about #gamification: do we encourage mastery by letting people make their own mistakes, or by telling them the best practices\/cheats?",
  "id" : 29147334000,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125, -122.347667 ]
  },
  "id_str" : "29151407998",
  "text" : "8:36pm Suggesting people for this crazy person to follow on Twitter http:\/\/flic.kr\/p\/8P596D",
  "id" : 29151407998,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Carmichael",
      "screen_name" : "accarmichael",
      "indices" : [ 0, 13 ],
      "id_str" : "15916492",
      "id" : 15916492
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 70, 85 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29053318782",
  "geo" : { },
  "id_str" : "29153542128",
  "in_reply_to_user_id" : 15916492,
  "text" : "@accarmichael Thank you, Alexandra! I would love your feedback from a #quantifiedself perspective. And also a curetogether perspective!",
  "id" : 29153542128,
  "in_reply_to_status_id" : 29053318782,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "accarmichael",
  "in_reply_to_user_id_str" : "15916492",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Carmichael",
      "screen_name" : "accarmichael",
      "indices" : [ 0, 13 ],
      "id_str" : "15916492",
      "id" : 15916492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29153921295",
  "geo" : { },
  "id_str" : "29156132486",
  "in_reply_to_user_id" : 15916492,
  "text" : "@accarmichael I like the new minute! How did you choose it?",
  "id" : 29156132486,
  "in_reply_to_status_id" : 29153921295,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "accarmichael",
  "in_reply_to_user_id_str" : "15916492",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29156470156",
  "text" : "Appendix B of Punished by Rewards opens, without closing, Pandora's Box by revealing that he cannot define \"intrinsic motivation\". Shit.",
  "id" : 29156470156,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29156262835",
  "geo" : { },
  "id_str" : "29156622841",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara Yes we DOOOOOOO! Sunday morning?",
  "id" : 29156622841,
  "in_reply_to_status_id" : 29156262835,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Carmichael",
      "screen_name" : "accarmichael",
      "indices" : [ 0, 13 ],
      "id_str" : "15916492",
      "id" : 15916492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29156534956",
  "geo" : { },
  "id_str" : "29156687965",
  "in_reply_to_user_id" : 15916492,
  "text" : "@accarmichael That's awesome! Well done. I might join you at the earlier hour now that I have a baby.",
  "id" : 29156687965,
  "in_reply_to_status_id" : 29156534956,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "accarmichael",
  "in_reply_to_user_id_str" : "15916492",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deepthoughtsafter2glassesofwine",
      "indices" : [ 86, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29156760299",
  "text" : "The secret to gaining trust: give away all of your own secrets; keep everyone else's. #deepthoughtsafter2glassesofwine",
  "id" : 29156760299,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29157623948",
  "geo" : { },
  "id_str" : "29157725207",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley Thanks! Hey I'm gonna be in SF 2-nights-only on 11\/11-11\/12... are you gonna be around for a Hemlock rendezvous?",
  "id" : 29157725207,
  "in_reply_to_status_id" : 29157623948,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29157200037",
  "geo" : { },
  "id_str" : "29157803809",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara Costumes?! Uh oh, I gave up my 10 good parents points so I could pretend Halloween didn't exist this year!",
  "id" : 29157803809,
  "in_reply_to_status_id" : 29157200037,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29158805841",
  "geo" : { },
  "id_str" : "29158895337",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley Save the date! (I'm also open to other venues if you can recommend even better spots.)",
  "id" : 29158895337,
  "in_reply_to_status_id" : 29158805841,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29197051019",
  "text" : "Rally to Restore Sanity and\/or Fear live stream! Currently watching The Roots on stage: http:\/\/bit.ly\/ayfbky",
  "id" : 29197051019,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Magnuson",
      "screen_name" : "emaggie",
      "indices" : [ 0, 8 ],
      "id_str" : "15857267",
      "id" : 15857267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29206801810",
  "geo" : { },
  "id_str" : "29210568866",
  "in_reply_to_user_id" : 15857267,
  "text" : "@emaggie What happened with the saving quirks? Let me know as I'm trying to track these things down and can repair streaks if broken.",
  "id" : 29210568866,
  "in_reply_to_status_id" : 29206801810,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "emaggie",
  "in_reply_to_user_id_str" : "15857267",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.574166, -122.314167 ]
  },
  "id_str" : "29041757867",
  "text" : "Owen! http:\/\/flic.kr\/p\/8NP8Y6",
  "id" : 29041757867,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.563333, -122.2345 ]
  },
  "id_str" : "29053840368",
  "text" : "8:36pm Brought dinner to Joe, Venessa, Aaron, Isaac, and the brand new Lilla! http:\/\/flic.kr\/p\/8NQJ8V",
  "id" : 29053840368,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Chivers",
      "screen_name" : "JessicaChivers",
      "indices" : [ 0, 15 ],
      "id_str" : "17492166",
      "id" : 17492166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29036547061",
  "geo" : { },
  "id_str" : "29060830470",
  "in_reply_to_user_id" : 17492166,
  "text" : "@JessicaChivers What happens? I can repair your streak if you missed a day due to a technical error.",
  "id" : 29060830470,
  "in_reply_to_status_id" : 29036547061,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "JessicaChivers",
  "in_reply_to_user_id_str" : "17492166",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Chivers",
      "screen_name" : "JessicaChivers",
      "indices" : [ 0, 15 ],
      "id_str" : "17492166",
      "id" : 17492166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29079983500",
  "geo" : { },
  "id_str" : "29095275081",
  "in_reply_to_user_id" : 17492166,
  "text" : "@JessicaChivers Maybe Facebook was down? Let me know your name on the site and I'll fix your streak.",
  "id" : 29095275081,
  "in_reply_to_status_id" : 29079983500,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "JessicaChivers",
  "in_reply_to_user_id_str" : "17492166",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.347667 ]
  },
  "id_str" : "29114536844",
  "text" : "I'm no longer needed here. http:\/\/flic.kr\/p\/8P2WwJ",
  "id" : 29114536844,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 3, 8 ],
      "id_str" : "10959642",
      "id" : 10959642
    }, {
      "name" : "jason",
      "screen_name" : "Jason",
      "indices" : [ 93, 99 ],
      "id_str" : "3840",
      "id" : 3840
    }, {
      "name" : "news.yc Popular",
      "screen_name" : "newsycombinator",
      "indices" : [ 100, 116 ],
      "id_str" : "14335498",
      "id" : 14335498
    }, {
      "name" : "TechZIng",
      "screen_name" : "techzing",
      "indices" : [ 117, 126 ],
      "id_str" : "44281928",
      "id" : 44281928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29115057048",
  "text" : "RT @tara: New Post \"I have a baby and I\u2019m doing a startup. Whoopie\" http:\/\/bit.ly\/9giKyQ \/cc @jason @newsycombinator @techzing",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jason",
        "screen_name" : "Jason",
        "indices" : [ 83, 89 ],
        "id_str" : "3840",
        "id" : 3840
      }, {
        "name" : "news.yc Popular",
        "screen_name" : "newsycombinator",
        "indices" : [ 90, 106 ],
        "id_str" : "14335498",
        "id" : 14335498
      }, {
        "name" : "TechZIng",
        "screen_name" : "techzing",
        "indices" : [ 107, 116 ],
        "id_str" : "44281928",
        "id" : 44281928
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29113572005",
    "text" : "New Post \"I have a baby and I\u2019m doing a startup. Whoopie\" http:\/\/bit.ly\/9giKyQ \/cc @jason @newsycombinator @techzing",
    "id" : 29113572005,
    "created_at" : "2010-10-29 18:46:45 +0000",
    "user" : {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "protected" : false,
      "id_str" : "10959642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/424418652893347840\/5-G5MLJn_normal.png",
      "id" : 10959642,
      "verified" : false
    }
  },
  "id" : 29115057048,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.347667 ]
  },
  "id_str" : "28955362847",
  "text" : "8:36pm Hot potato. http:\/\/flic.kr\/p\/8NBbrr",
  "id" : 28955362847,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trapper Markelz",
      "screen_name" : "trappermarkelz",
      "indices" : [ 0, 15 ],
      "id_str" : "1032241",
      "id" : 1032241
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HealthMonth",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29002980938",
  "geo" : { },
  "id_str" : "29005654612",
  "in_reply_to_user_id" : 1032241,
  "text" : "@trappermarkelz That Well-Being Index is amazing. I would love to include it on #HealthMonth (with attribution of course). Is that possible?",
  "id" : 29005654612,
  "in_reply_to_status_id" : 29002980938,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "trappermarkelz",
  "in_reply_to_user_id_str" : "1032241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trapper Markelz",
      "screen_name" : "trappermarkelz",
      "indices" : [ 20, 35 ],
      "id_str" : "1032241",
      "id" : 1032241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29002980938",
  "geo" : { },
  "id_str" : "29006132327",
  "in_reply_to_user_id" : 1032241,
  "text" : "Inspiring work from @trappermarkelz  Gallup, and Healthways building the well-being index. http:\/\/bit.ly\/aUNDIH http:\/\/bit.ly\/aCE1dH",
  "id" : 29006132327,
  "in_reply_to_status_id" : 29002980938,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "trappermarkelz",
  "in_reply_to_user_id_str" : "1032241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trapper Markelz",
      "screen_name" : "trappermarkelz",
      "indices" : [ 0, 15 ],
      "id_str" : "1032241",
      "id" : 1032241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29006440002",
  "geo" : { },
  "id_str" : "29017020022",
  "in_reply_to_user_id" : 1032241,
  "text" : "@trappermarkelz Awesome, looking through it now. I would love to include a user survey that helped map their wellness to the report.",
  "id" : 29017020022,
  "in_reply_to_status_id" : 29006440002,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "trappermarkelz",
  "in_reply_to_user_id_str" : "1032241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29017936602",
  "text" : "Friendship pages on Facebook sound really cool.  http:\/\/on.fb.me\/aTifU0",
  "id" : 29017936602,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdtweet",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29022602662",
  "text" : "Cracking into Xcode for the first time in a while. I love it because it's so powerful, but fear it because it's hyper-finnicky. #nerdtweet",
  "id" : 29022602662,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.662833, -122.301334 ]
  },
  "id_str" : "28858892641",
  "text" : "8:36pm Listening to a new hero of mine speak about the future: Kevin Kelly! http:\/\/flic.kr\/p\/8NqFjN",
  "id" : 28858892641,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Cunningham",
      "screen_name" : "emahlee",
      "indices" : [ 0, 8 ],
      "id_str" : "17856201",
      "id" : 17856201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28850136968",
  "geo" : { },
  "id_str" : "28865642386",
  "in_reply_to_user_id" : 17856201,
  "text" : "@emahlee Thanks for saying hi today!",
  "id" : 28865642386,
  "in_reply_to_status_id" : 28850136968,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "emahlee",
  "in_reply_to_user_id_str" : "17856201",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 75, 78 ]
    }, {
      "text" : "marketresearch",
      "indices" : [ 79, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28920668510",
  "text" : "Which would you rather do: gain 20 lbs of extra weight, or break a finger? #fb #marketresearch",
  "id" : 28920668510,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28922000711",
  "geo" : { },
  "id_str" : "28922039597",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim Any finger!",
  "id" : 28922039597,
  "in_reply_to_status_id" : 28922000711,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28926676519",
  "text" : "Informal results from Twitter and Facebook: 76% of people would rather break their finger than gain 20lbs.",
  "id" : 28926676519,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "w2sON",
      "indices" : [ 122, 128 ]
    }, {
      "text" : "pickme",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28738585289",
  "text" : "Health Month makes health-improvement and behavior-change TOTALLY FUN for the post-Facebook world. http:\/\/healthmonth.com #w2sON #pickme!",
  "id" : 28738585289,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl \u266B Smith",
      "screen_name" : "CarlosNZ",
      "indices" : [ 0, 9 ],
      "id_str" : "16728047",
      "id" : 16728047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28740314454",
  "geo" : { },
  "id_str" : "28740721148",
  "in_reply_to_user_id" : 16728047,
  "text" : "@CarlosNZ Shoot.  I'll look into that.",
  "id" : 28740721148,
  "in_reply_to_status_id" : 28740314454,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "CarlosNZ",
  "in_reply_to_user_id_str" : "16728047",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 41, 52 ],
      "id_str" : "784078",
      "id" : 784078
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 57, 64 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125, -122.347667 ]
  },
  "id_str" : "28756739783",
  "text" : "8:36pm Dressed for storytime courtesy of @alicetiara and @harryh http:\/\/flic.kr\/p\/8N6JWH",
  "id" : 28756739783,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "livetweetingwhilereading",
      "indices" : [ 66, 91 ]
    }, {
      "text" : "motivation",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28759438136",
  "text" : "The stick is contained in the carrot. - Punished by Rewards pg 53 #livetweetingwhilereading #motivation",
  "id" : 28759438136,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28759552462",
  "geo" : { },
  "id_str" : "28759809127",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim Thanks! It's good to mix a few baby pics in with the serious talk, right? :)",
  "id" : 28759809127,
  "in_reply_to_status_id" : 28759552462,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rodney Mitchell",
      "screen_name" : "rodmitch",
      "indices" : [ 0, 9 ],
      "id_str" : "2082491",
      "id" : 2082491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28808019904",
  "geo" : { },
  "id_str" : "28808384346",
  "in_reply_to_user_id" : 2082491,
  "text" : "@rodmitch I just added 20 sponsored invites to your team.  To get the link, click on \"invite friends\" from your team page.",
  "id" : 28808384346,
  "in_reply_to_status_id" : 28808019904,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "rodmitch",
  "in_reply_to_user_id_str" : "2082491",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Shell",
      "screen_name" : "Brethren",
      "indices" : [ 0, 9 ],
      "id_str" : "9857922",
      "id" : 9857922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28815109280",
  "geo" : { },
  "id_str" : "28816491529",
  "in_reply_to_user_id" : 9857922,
  "text" : "@Brethren Thanks! Watching now. It makes me squirm to watch people trying to explain their art. :)",
  "id" : 28816491529,
  "in_reply_to_status_id" : 28815109280,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Brethren",
  "in_reply_to_user_id_str" : "9857922",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28822395421",
  "text" : "Sometimes I take the troll bait.",
  "id" : 28822395421,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Pusateri",
      "screen_name" : "Cruftbox",
      "indices" : [ 0, 9 ],
      "id_str" : "792738",
      "id" : 792738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28823265181",
  "geo" : { },
  "id_str" : "28823432324",
  "in_reply_to_user_id" : 792738,
  "text" : "@Cruftbox Yeah, my host, Heroku, is down at the moment. See http:\/\/status.heroku.com for updates.",
  "id" : 28823432324,
  "in_reply_to_status_id" : 28823265181,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cruftbox",
  "in_reply_to_user_id_str" : "792738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Pusateri",
      "screen_name" : "Cruftbox",
      "indices" : [ 0, 9 ],
      "id_str" : "792738",
      "id" : 792738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28824019951",
  "geo" : { },
  "id_str" : "28824458243",
  "in_reply_to_user_id" : 792738,
  "text" : "@Cruftbox Looks like it's back now. Crossing my fingers. Plus, it's raining outside.",
  "id" : 28824458243,
  "in_reply_to_status_id" : 28824019951,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cruftbox",
  "in_reply_to_user_id_str" : "792738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cole Farrell",
      "screen_name" : "coleifornia",
      "indices" : [ 0, 12 ],
      "id_str" : "26382323",
      "id" : 26382323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28826905293",
  "geo" : { },
  "id_str" : "28829759449",
  "in_reply_to_user_id" : 21357984,
  "text" : "@coleifornia What do you mean \"up the game\"?  I'm always looking for ways to make it better... you want to edit entries after the date?",
  "id" : 28829759449,
  "in_reply_to_status_id" : 28826905293,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "colefarrell",
  "in_reply_to_user_id_str" : "21357984",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Riad Djemili",
      "screen_name" : "riadd",
      "indices" : [ 0, 6 ],
      "id_str" : "15610427",
      "id" : 15610427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28833636210",
  "geo" : { },
  "id_str" : "28834164671",
  "in_reply_to_user_id" : 15610427,
  "text" : "@riadd Looking into the problem. Sorry about that... should be back up shortly. And thank you!",
  "id" : 28834164671,
  "in_reply_to_status_id" : 28833636210,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "riadd",
  "in_reply_to_user_id_str" : "15610427",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "indices" : [ 15, 27 ],
      "id_str" : "1532061",
      "id" : 1532061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28838564385",
  "text" : "Stoked to hear @kevin2kelly speak about his book, What Technology Wants, at U Village tonight. Anyone else going?",
  "id" : 28838564385,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612833, -122.345334 ]
  },
  "id_str" : "28659296676",
  "text" : "8:36pm Drinks with Lane! http:\/\/flic.kr\/p\/8MRzqS",
  "id" : 28659296676,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Romenesko",
      "screen_name" : "romenesko",
      "indices" : [ 3, 13 ],
      "id_str" : "15087011",
      "id" : 15087011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28692651392",
  "text" : "RT @romenesko: Prof who has studied \"The Daily Show\" says Jon Stewart's cultural influence surpasses Glenn Beck's. http:\/\/journ.us\/bKjY9W",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28690109361",
    "text" : "Prof who has studied \"The Daily Show\" says Jon Stewart's cultural influence surpasses Glenn Beck's. http:\/\/journ.us\/bKjY9W",
    "id" : 28690109361,
    "created_at" : "2010-10-25 13:22:06 +0000",
    "user" : {
      "name" : "Romenesko",
      "screen_name" : "romenesko",
      "protected" : false,
      "id_str" : "15087011",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1669789869\/RomeneskoTwitterIcon_normal.jpg",
      "id" : 15087011,
      "verified" : true
    }
  },
  "id" : 28692651392,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabe Zichermann",
      "screen_name" : "gzicherm",
      "indices" : [ 69, 78 ],
      "id_str" : "5907582",
      "id" : 5907582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28697490932",
  "geo" : { },
  "id_str" : "28699145391",
  "in_reply_to_user_id" : 5907582,
  "text" : "It's gonna be exciting. Especially as it navigates the intrinsic. RT @gzicherm \"Get ready for the decade of gamification\" http:\/\/ht.ly\/2YUt0",
  "id" : 28699145391,
  "in_reply_to_status_id" : 28697490932,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "gzicherm",
  "in_reply_to_user_id_str" : "5907582",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "noah kagan",
      "screen_name" : "noahkagan",
      "indices" : [ 0, 10 ],
      "id_str" : "13737",
      "id" : 13737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28698228978",
  "geo" : { },
  "id_str" : "28699219733",
  "in_reply_to_user_id" : 13737,
  "text" : "@noahkagan Woah impressive! What's the plan?",
  "id" : 28699219733,
  "in_reply_to_status_id" : 28698228978,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "noahkagan",
  "in_reply_to_user_id_str" : "13737",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28703671960",
  "text" : "Just got called out on my own blog for being a solipsistic echo chamber that doesn't \"reward\" its commenters. http:\/\/bit.ly\/cAJW5Z",
  "id" : 28703671960,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "noah kagan",
      "screen_name" : "noahkagan",
      "indices" : [ 0, 10 ],
      "id_str" : "13737",
      "id" : 13737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28702549287",
  "geo" : { },
  "id_str" : "28703781179",
  "in_reply_to_user_id" : 13737,
  "text" : "@noahkagan Looks great to me. Let me know how it goes!",
  "id" : 28703781179,
  "in_reply_to_status_id" : 28702549287,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "noahkagan",
  "in_reply_to_user_id_str" : "13737",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "socialworkout",
      "screen_name" : "socialworkout",
      "indices" : [ 53, 67 ],
      "id_str" : "17006221",
      "id" : 17006221
    }, {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 120, 131 ],
      "id_str" : "784078",
      "id" : 784078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28713959260",
  "text" : "This brightened my day. A leaderboard for huggers at @socialworkout. http:\/\/www.socialworkout.com\/activity\/show\/68 \/via @alicetiara",
  "id" : 28713959260,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Franklin",
      "screen_name" : "AaronSeattle",
      "indices" : [ 69, 82 ],
      "id_str" : "15358390",
      "id" : 15358390
    }, {
      "name" : "Garry Tan",
      "screen_name" : "garrytan",
      "indices" : [ 108, 117 ],
      "id_str" : "11768582",
      "id" : 11768582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28716220289",
  "text" : "2 good posts on finding your niche passion:\n\nhttp:\/\/bit.ly\/a6GBZJ by @AaronSeattle\n\nhttp:\/\/bit.ly\/d4Fh6O by @GarryTan",
  "id" : 28716220289,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gameful",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125, -122.347667 ]
  },
  "id_str" : "28734363460",
  "text" : "My mysterious #gameful puzzle piece. Now what? http:\/\/flic.kr\/p\/8N6cNL",
  "id" : 28734363460,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Buie",
      "screen_name" : "ebuie",
      "indices" : [ 0, 6 ],
      "id_str" : "13232092",
      "id" : 13232092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28553162937",
  "geo" : { },
  "id_str" : "28554625350",
  "in_reply_to_user_id" : 13232092,
  "text" : "@ebuie Yes, that's coming soon. Not in time for November though unfortunately.",
  "id" : 28554625350,
  "in_reply_to_status_id" : 28553162937,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "ebuie",
  "in_reply_to_user_id_str" : "13232092",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125, -122.347834 ]
  },
  "id_str" : "28561410676",
  "text" : "8:36pm Watching \"one foot on the grave and three feet on a banana peel\" while making apple bread http:\/\/flic.kr\/p\/8MvPF3",
  "id" : 28561410676,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 134, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28573440008",
  "text" : "If you ask yourself, \"Am I more often right or wrong about things?\" what's your answer? And how do you know if you're right or wrong? #fb",
  "id" : 28573440008,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 3, 12 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28610352338",
  "text" : "RT @rondiver: Kevin Kelly discussion at U-Village BN this Tuesday. Join me, maybe we'll convince him to go out for drinks after. http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28609960840",
    "text" : "Kevin Kelly discussion at U-Village BN this Tuesday. Join me, maybe we'll convince him to go out for drinks after. http:\/\/bit.ly\/ch5nHm",
    "id" : 28609960840,
    "created_at" : "2010-10-24 16:36:44 +0000",
    "user" : {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "protected" : false,
      "id_str" : "12661782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448861100025462786\/hl-I2X20_normal.jpeg",
      "id" : 12661782,
      "verified" : false
    }
  },
  "id" : 28610352338,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole Lazzaro",
      "screen_name" : "NicoleLazzaro",
      "indices" : [ 3, 17 ],
      "id_str" : "7315732",
      "id" : 7315732
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sxd",
      "indices" : [ 94, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28610382580",
  "text" : "RT @NicoleLazzaro: \"Show me you care about me\" is the primary motivator for all Social Media. #sxd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sxd",
        "indices" : [ 75, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28609753606",
    "text" : "\"Show me you care about me\" is the primary motivator for all Social Media. #sxd",
    "id" : 28609753606,
    "created_at" : "2010-10-24 16:33:33 +0000",
    "user" : {
      "name" : "Nicole Lazzaro",
      "screen_name" : "NicoleLazzaro",
      "protected" : false,
      "id_str" : "7315732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000861357278\/pEINEet-_normal.jpeg",
      "id" : 7315732,
      "verified" : false
    }
  },
  "id" : 28610382580,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28614724582",
  "text" : "\"To de-emphasize conventional rewards (grades\/money\/perks) threatens the existing power structure.\" - Mihaly Csikszentmihalyi (parens mine)",
  "id" : 28614724582,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Bianchini",
      "screen_name" : "ginab",
      "indices" : [ 3, 9 ],
      "id_str" : "72403",
      "id" : 72403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28614946018",
  "text" : "RT @ginab: True for start-ups too: First they ignore you, then they laugh at you, then they fight you, then you win. Mohandas Gandhi",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28614081191",
    "text" : "True for start-ups too: First they ignore you, then they laugh at you, then they fight you, then you win. Mohandas Gandhi",
    "id" : 28614081191,
    "created_at" : "2010-10-24 17:36:48 +0000",
    "user" : {
      "name" : "Gina Bianchini",
      "screen_name" : "ginab",
      "protected" : false,
      "id_str" : "72403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3198671630\/d6bf09c89b94cefe17609f25fc29f6a9_normal.jpeg",
      "id" : 72403,
      "verified" : false
    }
  },
  "id" : 28614946018,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick B",
      "screen_name" : "nbeezzy",
      "indices" : [ 0, 8 ],
      "id_str" : "14479635",
      "id" : 14479635
    }, {
      "name" : "Eric Hodel",
      "screen_name" : "drbrain",
      "indices" : [ 127, 135 ],
      "id_str" : "670283",
      "id" : 670283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28617924934",
  "geo" : { },
  "id_str" : "28618229812",
  "in_reply_to_user_id" : 14479635,
  "text" : "@nbeezzy I don't really. At least not freelancing developers. Not sure if this is still going on? http:\/\/www.seattlerb.org \/cc @drbrain",
  "id" : 28618229812,
  "in_reply_to_status_id" : 28617924934,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "nbeezzy",
  "in_reply_to_user_id_str" : "14479635",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick B",
      "screen_name" : "nbeezzy",
      "indices" : [ 0, 8 ],
      "id_str" : "14479635",
      "id" : 14479635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28617924934",
  "geo" : { },
  "id_str" : "28618395231",
  "in_reply_to_user_id" : 14479635,
  "text" : "@nbeezzy From what I hear though, diaspora isn't really worth your time...",
  "id" : 28618395231,
  "in_reply_to_status_id" : 28617924934,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "nbeezzy",
  "in_reply_to_user_id_str" : "14479635",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28640190658",
  "text" : "RT @MarshallHaas: Netflix CEO: \u201CBy every measure, we are now primarily a streaming company that also offers DVD-by-mail.\u201D http:\/\/goo.gl\/SgIv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28639562013",
    "text" : "Netflix CEO: \u201CBy every measure, we are now primarily a streaming company that also offers DVD-by-mail.\u201D http:\/\/goo.gl\/SgIv",
    "id" : 28639562013,
    "created_at" : "2010-10-24 23:38:32 +0000",
    "user" : {
      "name" : "Marshall Haas",
      "screen_name" : "marshal",
      "protected" : false,
      "id_str" : "19028099",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453603163849760768\/_OKoY3xs_normal.jpeg",
      "id" : 19028099,
      "verified" : false
    }
  },
  "id" : 28640190658,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28455026881",
  "geo" : { },
  "id_str" : "28456166091",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver Thanks! Now I wish I had paid a little more attention in Philosophy 101...",
  "id" : 28456166091,
  "in_reply_to_status_id" : 28455026881,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125, -122.347667 ]
  },
  "id_str" : "28468257438",
  "text" : "8:36pm Researching and taking notes on pitch decks. http:\/\/flic.kr\/p\/8MfWP7",
  "id" : 28468257438,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "MarshallHaas",
      "indices" : [ 0, 13 ],
      "id_str" : "1268491417",
      "id" : 1268491417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28468490222",
  "geo" : { },
  "id_str" : "28468547054",
  "in_reply_to_user_id" : 19028099,
  "text" : "@MarshallHaas Maaybe. :)",
  "id" : 28468547054,
  "in_reply_to_status_id" : 28468490222,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "MarshallHaas",
      "indices" : [ 0, 13 ],
      "id_str" : "1268491417",
      "id" : 1268491417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28468596427",
  "geo" : { },
  "id_str" : "28469146303",
  "in_reply_to_user_id" : 19028099,
  "text" : "@MarshallHaas I am, I am...",
  "id" : 28469146303,
  "in_reply_to_status_id" : 28468596427,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28471195032",
  "geo" : { },
  "id_str" : "28471533784",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver Yes but it's a noble idea to strive for, isn't it?",
  "id" : 28471533784,
  "in_reply_to_status_id" : 28471195032,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125, -122.3475 ]
  },
  "id_str" : "28515066342",
  "text" : "My sporty wife taking calls at the breakfast table before hitting the gym. http:\/\/flic.kr\/p\/8MjonD",
  "id" : 28515066342,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "complete honesty",
      "screen_name" : "nosocialbarrier",
      "indices" : [ 0, 16 ],
      "id_str" : "204696158",
      "id" : 204696158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28524079152",
  "geo" : { },
  "id_str" : "28524297418",
  "in_reply_to_user_id" : 204696158,
  "text" : "@nosocialbarrier They should be going out again. Are you still not getting them? Also, send me your name on site and I'll fix your streak.",
  "id" : 28524297418,
  "in_reply_to_status_id" : 28524079152,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "nosocialbarrier",
  "in_reply_to_user_id_str" : "204696158",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Chapman",
      "screen_name" : "TrickChapman",
      "indices" : [ 0, 13 ],
      "id_str" : "75433017",
      "id" : 75433017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28521769643",
  "geo" : { },
  "id_str" : "28529248847",
  "in_reply_to_user_id" : 75433017,
  "text" : "@TrickChapman Thanks for the link to the post. I replied to your comment, too.",
  "id" : 28529248847,
  "in_reply_to_status_id" : 28521769643,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "TrickChapman",
  "in_reply_to_user_id_str" : "75433017",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28529403836",
  "text" : "I think virtual rewards might be able to *improve* an intrinsically valuable experience: http:\/\/bit.ly\/9JUk54 #gamification",
  "id" : 28529403836,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ignite Seattle",
      "screen_name" : "ignitesea",
      "indices" : [ 37, 47 ],
      "id_str" : "3567281",
      "id" : 3567281
    }, {
      "name" : "brady forrest",
      "screen_name" : "brady",
      "indices" : [ 98, 104 ],
      "id_str" : "6140",
      "id" : 6140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28537813609",
  "text" : "I just submitted a talk for the 12th @ignitesea.  Unfortunately, it's a day late. We'll see.  \/cc @brady",
  "id" : 28537813609,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28538089759",
  "text" : "Here's my talk from the 1st Ignite ever, in 2006, on How to Use Technology to Get What You Want.  Hand-drawn slides! http:\/\/bit.ly\/9VC4np",
  "id" : 28538089759,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28538067011",
  "geo" : { },
  "id_str" : "28538216002",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin Hey good point!",
  "id" : 28538216002,
  "in_reply_to_status_id" : 28538067011,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28542434591",
  "geo" : { },
  "id_str" : "28542672469",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Thanks, Alex! Interesting also that I now see several flaws in my thinking back then. :)",
  "id" : 28542672469,
  "in_reply_to_status_id" : 28542434591,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28428085487",
  "geo" : { },
  "id_str" : "28428552837",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim I like that list of intrinsic rewards. Add: autonomy, sense of contributing to greater good, balanced self-esteem... what else?",
  "id" : 28428552837,
  "in_reply_to_status_id" : 28428085487,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Clark",
      "screen_name" : "drjavafox",
      "indices" : [ 0, 10 ],
      "id_str" : "77165220",
      "id" : 77165220
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28021857402",
  "geo" : { },
  "id_str" : "28024558421",
  "in_reply_to_user_id" : 77165220,
  "text" : "@drjavafox You should get one today. Let me know if you don't!",
  "id" : 28024558421,
  "in_reply_to_status_id" : 28021857402,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "drjavafox",
  "in_reply_to_user_id_str" : "77165220",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Armour",
      "screen_name" : "TacoJohn",
      "indices" : [ 0, 9 ],
      "id_str" : "518167442",
      "id" : 518167442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28023871382",
  "geo" : { },
  "id_str" : "28024583713",
  "in_reply_to_user_id" : 10399,
  "text" : "@tacojohn Those are the best! Good work.",
  "id" : 28024583713,
  "in_reply_to_status_id" : 28023871382,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "John_Infante",
  "in_reply_to_user_id_str" : "10399",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan",
      "screen_name" : "effthatlizard",
      "indices" : [ 0, 14 ],
      "id_str" : "16126226",
      "id" : 16126226
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "750words",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28002102701",
  "geo" : { },
  "id_str" : "28037020717",
  "in_reply_to_user_id" : 16126226,
  "text" : "@effthatlizard What bugs are you seeing? I think I fixed most of them yesterday but let me know! #750words",
  "id" : 28037020717,
  "in_reply_to_status_id" : 28002102701,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "effthatlizard",
  "in_reply_to_user_id_str" : "16126226",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyndi Thompson",
      "screen_name" : "lyndit",
      "indices" : [ 0, 7 ],
      "id_str" : "15411442",
      "id" : 15411442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28034328117",
  "geo" : { },
  "id_str" : "28038871293",
  "in_reply_to_user_id" : 15411442,
  "text" : "@lyndit Free review? I'd love to learn more... would you be interested in reviewing healthmonth.com?",
  "id" : 28038871293,
  "in_reply_to_status_id" : 28034328117,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "lyndit",
  "in_reply_to_user_id_str" : "15411442",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyndi Thompson",
      "screen_name" : "lyndit",
      "indices" : [ 0, 7 ],
      "id_str" : "15411442",
      "id" : 15411442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28039214531",
  "geo" : { },
  "id_str" : "28039795785",
  "in_reply_to_user_id" : 15411442,
  "text" : "@lyndit Awesome! My email address is busterbenson at gmail... let me know what you need from me.",
  "id" : 28039795785,
  "in_reply_to_status_id" : 28039214531,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "lyndit",
  "in_reply_to_user_id_str" : "15411442",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28040874003",
  "text" : "Is anyone doing NaNoWriMo this year? On 750words.com? It's like peanut butter and bananas! http:\/\/bit.ly\/amLFRC",
  "id" : 28040874003,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan",
      "screen_name" : "effthatlizard",
      "indices" : [ 0, 14 ],
      "id_str" : "16126226",
      "id" : 16126226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28045356601",
  "geo" : { },
  "id_str" : "28045796211",
  "in_reply_to_user_id" : 16126226,
  "text" : "@effthatlizard Looking into this today. Sorry for the trouble!",
  "id" : 28045796211,
  "in_reply_to_status_id" : 28045356601,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "effthatlizard",
  "in_reply_to_user_id_str" : "16126226",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "MarshallHaas",
      "indices" : [ 0, 13 ],
      "id_str" : "1268491417",
      "id" : 1268491417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28058090066",
  "geo" : { },
  "id_str" : "28058334401",
  "in_reply_to_user_id" : 19028099,
  "text" : "@MarshallHaas You can be healed past 10 points, and can also win life points on the wheel.",
  "id" : 28058334401,
  "in_reply_to_status_id" : 28058090066,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 34, 45 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28070534984",
  "text" : "I just unlocked the \"5K\" badge on @foursquare! http:\/\/4sq.com\/b6JzxI",
  "id" : 28070534984,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "MarshallHaas",
      "indices" : [ 0, 13 ],
      "id_str" : "1268491417",
      "id" : 1268491417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28071727362",
  "geo" : { },
  "id_str" : "28073069969",
  "in_reply_to_user_id" : 19028099,
  "text" : "@MarshallHaas You didn't have to plea for fruit. :) I'm going to try to make that more obvious as a good strategy somehow. Ideas?",
  "id" : 28073069969,
  "in_reply_to_status_id" : 28071727362,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "indices" : [ 3, 11 ],
      "id_str" : "4030",
      "id" : 4030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28369597952",
  "text" : "RT @monstro: \u201CIt\u2019s hard to be in your late 30s and want to hire your friends. It leads to a very expensive payroll.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28369355822",
    "text" : "\u201CIt\u2019s hard to be in your late 30s and want to hire your friends. It leads to a very expensive payroll.\u201D",
    "id" : 28369355822,
    "created_at" : "2010-10-22 03:19:45 +0000",
    "user" : {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "protected" : false,
      "id_str" : "4030",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1248189330\/Judith_s_40th_Birthday-248_normal.jpg",
      "id" : 4030,
      "verified" : false
    }
  },
  "id" : 28369597952,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.347667 ]
  },
  "id_str" : "28373131616",
  "text" : "This crashed while Niko was is in it. Otherwise a delightful dinner with Kindra and Mike. http:\/\/flic.kr\/p\/8M3ir3",
  "id" : 28373131616,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deb Roby",
      "screen_name" : "debroby",
      "indices" : [ 0, 8 ],
      "id_str" : "55273",
      "id" : 55273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28372272304",
  "geo" : { },
  "id_str" : "28374481239",
  "in_reply_to_user_id" : 55273,
  "text" : "@debroby You can do it!",
  "id" : 28374481239,
  "in_reply_to_status_id" : 28372272304,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "debroby",
  "in_reply_to_user_id_str" : "55273",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Angel Forum",
      "screen_name" : "openangelforum",
      "indices" : [ 0, 15 ],
      "id_str" : "90059161",
      "id" : 90059161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27792465837",
  "geo" : { },
  "id_str" : "28376503493",
  "in_reply_to_user_id" : 90059161,
  "text" : "@openangelforum Hi! What's the deadline for applications from entrepreneurs for Seattle?",
  "id" : 28376503493,
  "in_reply_to_status_id" : 27792465837,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "openangelforum",
  "in_reply_to_user_id_str" : "90059161",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 111, 116 ],
      "id_str" : "418",
      "id" : 418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28376664823",
  "text" : "Interesting way of putting it. Ideas are a multiplier on the value of the execution. http:\/\/bit.ly\/97BlO5 \/via @dens",
  "id" : 28376664823,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27979782859",
  "text" : "[insert helpless frustration here] \n\nSending it down the Twitter river, away from me. Bye!",
  "id" : 27979782859,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 53, 66 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.347667 ]
  },
  "id_str" : "27993848623",
  "text" : "8:36pm Tough or tiring days all around. Good to have @meganwelling here! http:\/\/flic.kr\/p\/8LNjSd",
  "id" : 27993848623,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T.N. Tobias",
      "screen_name" : "tn_tobias",
      "indices" : [ 0, 10 ],
      "id_str" : "16267585",
      "id" : 16267585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27886597502",
  "geo" : { },
  "id_str" : "27887344046",
  "in_reply_to_user_id" : 16267585,
  "text" : "@tn_tobias Thank you! Hopefully the worst of the server downtime issues are behind us now. I'm crossing my fingers.",
  "id" : 27887344046,
  "in_reply_to_status_id" : 27886597502,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "tn_tobias",
  "in_reply_to_user_id_str" : "16267585",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "intothelava",
      "indices" : [ 0, 12 ],
      "id_str" : "283417841",
      "id" : 283417841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27887875778",
  "text" : "@intothelava Yes, I've been migrating the server all day. Read the posts on that blog for more info.",
  "id" : 27887875778,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sorcyress",
      "screen_name" : "Sorcyress",
      "indices" : [ 0, 10 ],
      "id_str" : "14023082",
      "id" : 14023082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27896151987",
  "geo" : { },
  "id_str" : "27896367138",
  "in_reply_to_user_id" : 14023082,
  "text" : "@Sorcyress Thanks for letting me know! And good work!",
  "id" : 27896367138,
  "in_reply_to_status_id" : 27896151987,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "Sorcyress",
  "in_reply_to_user_id_str" : "14023082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryce Roberts",
      "screen_name" : "bryce",
      "indices" : [ 3, 9 ],
      "id_str" : "6160742",
      "id" : 6160742
    }, {
      "name" : "tristan walker",
      "screen_name" : "tristanwalker",
      "indices" : [ 32, 46 ],
      "id_str" : "18206161",
      "id" : 18206161
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 64, 75 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27896549192",
  "text" : "RT @bryce: had my mind blown by @tristanwalker on the future of @foursquare this afternoon. game changing couple of months ahead.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "tristan walker",
        "screen_name" : "tristanwalker",
        "indices" : [ 21, 35 ],
        "id_str" : "18206161",
        "id" : 18206161
      }, {
        "name" : "Foursquare",
        "screen_name" : "foursquare",
        "indices" : [ 53, 64 ],
        "id_str" : "14120151",
        "id" : 14120151
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27895315339",
    "text" : "had my mind blown by @tristanwalker on the future of @foursquare this afternoon. game changing couple of months ahead.",
    "id" : 27895315339,
    "created_at" : "2010-10-20 02:56:20 +0000",
    "user" : {
      "name" : "Bryce Roberts",
      "screen_name" : "bryce",
      "protected" : false,
      "id_str" : "6160742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1760909983\/me_normal.jpg",
      "id" : 6160742,
      "verified" : false
    }
  },
  "id" : 27896549192,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.347667 ]
  },
  "id_str" : "27898426505",
  "text" : "8:36pm I am ti-red after this day http:\/\/flic.kr\/p\/8Lynay",
  "id" : 27898426505,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deb Roby",
      "screen_name" : "debroby",
      "indices" : [ 0, 8 ],
      "id_str" : "55273",
      "id" : 55273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27932438102",
  "geo" : { },
  "id_str" : "27935400338",
  "in_reply_to_user_id" : 55273,
  "text" : "@debroby Can you send me a link or screenshot to the page that's not working for you?",
  "id" : 27935400338,
  "in_reply_to_status_id" : 27932438102,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "debroby",
  "in_reply_to_user_id_str" : "55273",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deb Roby",
      "screen_name" : "debroby",
      "indices" : [ 0, 8 ],
      "id_str" : "55273",
      "id" : 55273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27935568826",
  "geo" : { },
  "id_str" : "27936880182",
  "in_reply_to_user_id" : 55273,
  "text" : "@debroby I'm able to load that page... what are you seeing instead?",
  "id" : 27936880182,
  "in_reply_to_status_id" : 27935568826,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "debroby",
  "in_reply_to_user_id_str" : "55273",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Fleischer",
      "screen_name" : "DobraWorks",
      "indices" : [ 0, 11 ],
      "id_str" : "14976274",
      "id" : 14976274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27938404786",
  "geo" : { },
  "id_str" : "27938942565",
  "in_reply_to_user_id" : 14976274,
  "text" : "@DobraWorks Okay, thank you. I'm looking into it today. Does this happen only after you get to 750 words, and it deletes everything?",
  "id" : 27938942565,
  "in_reply_to_status_id" : 27938404786,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "DobraWorks",
  "in_reply_to_user_id_str" : "14976274",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Fleischer",
      "screen_name" : "DobraWorks",
      "indices" : [ 0, 11 ],
      "id_str" : "14976274",
      "id" : 14976274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27944885627",
  "geo" : { },
  "id_str" : "27945637932",
  "in_reply_to_user_id" : 14976274,
  "text" : "@DobraWorks I may have just fixed it. If not, let me know your name on the site and I'll look into it some more.",
  "id" : 27945637932,
  "in_reply_to_status_id" : 27944885627,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "DobraWorks",
  "in_reply_to_user_id_str" : "14976274",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27948471281",
  "text" : "Has anyone else tried this Natural Stress Relief meditation method?  http:\/\/bit.ly\/9pgJ2i Today seems like a good day to start.",
  "id" : 27948471281,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthmonth",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27964878075",
  "text" : "Added 7 new rules + more flexibility. Check them out and start thinking about your November #healthmonth rules! http:\/\/bit.ly\/d9Fb0D",
  "id" : 27964878075,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Site5 Web Hosting",
      "screen_name" : "site5",
      "indices" : [ 41, 47 ],
      "id_str" : "18324846",
      "id" : 18324846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27967068867",
  "text" : "Migrated 750words.com over to a VPS with @site5.  Went pretty well, but sending email throws errors. Coming up on 24-hours with help desk...",
  "id" : 27967068867,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27967375205",
  "geo" : { },
  "id_str" : "27967632766",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs It was on one of their dedicated servers. I like the most of the time, but their migrations always end up problematic.",
  "id" : 27967632766,
  "in_reply_to_status_id" : 27967375205,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Site5 Web Hosting",
      "screen_name" : "site5",
      "indices" : [ 0, 6 ],
      "id_str" : "18324846",
      "id" : 18324846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27967886444",
  "geo" : { },
  "id_str" : "27967963599",
  "in_reply_to_user_id" : 18324846,
  "text" : "@site5 Yes! I've been going back and forth all day on ticket TQCP-77056... so far, no luck.",
  "id" : 27967963599,
  "in_reply_to_status_id" : 27967886444,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "site5",
  "in_reply_to_user_id_str" : "18324846",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Huffman",
      "screen_name" : "aaronhuffman",
      "indices" : [ 0, 13 ],
      "id_str" : "52137644",
      "id" : 52137644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthmonth",
      "indices" : [ 40, 52 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27969150596",
  "geo" : { },
  "id_str" : "27969991671",
  "in_reply_to_user_id" : 52137644,
  "text" : "@aaronhuffman Awesome that you're doing #healthmonth! I wish I could join you in the graphic novel month... sounds fun!",
  "id" : 27969991671,
  "in_reply_to_status_id" : 27969150596,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "aaronhuffman",
  "in_reply_to_user_id_str" : "52137644",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27969935588",
  "geo" : { },
  "id_str" : "27970028618",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean Yeah. I almost used them. But it would've been too expensive for 750words.com's paltry income.",
  "id" : 27970028618,
  "in_reply_to_status_id" : 27969935588,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Rezac",
      "screen_name" : "drezac",
      "indices" : [ 3, 10 ],
      "id_str" : "6153072",
      "id" : 6153072
    }, {
      "name" : "Daniel Pink",
      "screen_name" : "DanielPink",
      "indices" : [ 30, 41 ],
      "id_str" : "14378113",
      "id" : 14378113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27783903564",
  "text" : "RT @drezac: I was going to do @DanielPink 's video, but the book as a prize made me lose my motivation. http:\/\/bit.ly\/a2AnyW",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Pink",
        "screen_name" : "DanielPink",
        "indices" : [ 18, 29 ],
        "id_str" : "14378113",
        "id" : 14378113
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27781803677",
    "text" : "I was going to do @DanielPink 's video, but the book as a prize made me lose my motivation. http:\/\/bit.ly\/a2AnyW",
    "id" : 27781803677,
    "created_at" : "2010-10-18 23:47:14 +0000",
    "user" : {
      "name" : "Daniel Rezac",
      "screen_name" : "drezac",
      "protected" : false,
      "id_str" : "6153072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465947324578299906\/DUQEcSJC_normal.jpeg",
      "id" : 6153072,
      "verified" : false
    }
  },
  "id" : 27783903564,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 66, 76 ],
      "id_str" : "1771141",
      "id" : 1771141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614166, -122.346667 ]
  },
  "id_str" : "27800806016",
  "text" : "8:36pm Keeping Niko up past his bedtime to enjoy dinnertimes with @samantham http:\/\/flic.kr\/p\/8LfAyg",
  "id" : 27800806016,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27801561991",
  "geo" : { },
  "id_str" : "27803156487",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel It's cool, right? Only question I have is how do you measure results?",
  "id" : 27803156487,
  "in_reply_to_status_id" : 27801561991,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27846693210",
  "text" : "Moving 750words.com to a much bigger server today, in prep for NaNoWriMo. I hate moving servers. Wish me luck and sanity.",
  "id" : 27846693210,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Boisvenue",
      "screen_name" : "Travisboisvenue",
      "indices" : [ 28, 44 ],
      "id_str" : "14054915",
      "id" : 14054915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27850480842",
  "text" : "Here's a fun interview with @travisboisvenue where I get to talk about everything I love working on http:\/\/bit.ly\/dreGhz",
  "id" : 27850480842,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Boisvenue",
      "screen_name" : "Travisboisvenue",
      "indices" : [ 0, 16 ],
      "id_str" : "14054915",
      "id" : 14054915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27849319881",
  "geo" : { },
  "id_str" : "27850552887",
  "in_reply_to_user_id" : 14054915,
  "text" : "@Travisboisvenue Thanks for putting that interview together... it was a lot of fun to do.",
  "id" : 27850552887,
  "in_reply_to_status_id" : 27849319881,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "Travisboisvenue",
  "in_reply_to_user_id_str" : "14054915",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gwen Bell",
      "screen_name" : "gwenbell",
      "indices" : [ 0, 9 ],
      "id_str" : "1250104952",
      "id" : 1250104952
    }, {
      "name" : "Hashable",
      "screen_name" : "Hashable",
      "indices" : [ 79, 88 ],
      "id_str" : "140882350",
      "id" : 140882350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27852105186",
  "text" : "@gwenbell I love the idea of public intros. Especially short, simple ones that @hashable allows. Thanks for the 1st one... send me more! :)",
  "id" : 27852105186,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27857195972",
  "text" : "My mind just got blown by Mozilla's new Open Web App ecosystem proposal. This is gonna be big. http:\/\/bit.ly\/bpZp7R",
  "id" : 27857195972,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27864371882",
  "text" : "The server migration for http:\/\/750words.com has started, and is going to take 4+ hours. Why does this stuff stress me out so much?",
  "id" : 27864371882,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Ballum",
      "screen_name" : "SheeplessCo",
      "indices" : [ 0, 12 ],
      "id_str" : "21873025",
      "id" : 21873025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27864778522",
  "geo" : { },
  "id_str" : "27865106926",
  "in_reply_to_user_id" : 21873025,
  "text" : "@sheeplessco No, it should be redirecting to the blog with updates on the migration. Part of the migration is the database.",
  "id" : 27865106926,
  "in_reply_to_status_id" : 27864778522,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "SheeplessCo",
  "in_reply_to_user_id_str" : "21873025",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naunihal Singh",
      "screen_name" : "naunihalpublic",
      "indices" : [ 0, 15 ],
      "id_str" : "32232142",
      "id" : 32232142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27867328929",
  "geo" : { },
  "id_str" : "27867596245",
  "in_reply_to_user_id" : 32232142,
  "text" : "@naunihalpublic You should... sorry about that. I didn't build in error handling to handle the server migration. Please save your words!",
  "id" : 27867596245,
  "in_reply_to_status_id" : 27867328929,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "naunihalpublic",
  "in_reply_to_user_id_str" : "32232142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PoorYorick",
      "screen_name" : "PoorYorick",
      "indices" : [ 0, 11 ],
      "id_str" : "7622622",
      "id" : 7622622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27876363936",
  "geo" : { },
  "id_str" : "27876668888",
  "in_reply_to_user_id" : 7622622,
  "text" : "@PoorYorick Yes, I will be doing something like that!",
  "id" : 27876668888,
  "in_reply_to_status_id" : 27876363936,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "PoorYorick",
  "in_reply_to_user_id_str" : "7622622",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27686643705",
  "geo" : { },
  "id_str" : "27689042278",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin Yes, I liked it, but don't think about it all the time like the others. I haven't read Impro though - I'll check it out.",
  "id" : 27689042278,
  "in_reply_to_status_id" : 27686643705,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 38, 48 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 56, 67 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125, -122.3475 ]
  },
  "id_str" : "27701696900",
  "text" : "8:36pm Reading Dan Pink's Drive while @Kellianne nurses @NikoBenson http:\/\/flic.kr\/p\/8KZxtG",
  "id" : 27701696900,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27708137891",
  "text" : "\"The easier it is to quantify, the less it's worth.\" - Seth Godin, Linchpin",
  "id" : 27708137891,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Specht",
      "screen_name" : "maryspecht",
      "indices" : [ 0, 11 ],
      "id_str" : "259834384",
      "id" : 259834384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27702892805",
  "geo" : { },
  "id_str" : "27712411540",
  "in_reply_to_user_id" : 7357082,
  "text" : "@maryspecht Tell me what you think of those books! They're both short and sweet.",
  "id" : 27712411540,
  "in_reply_to_status_id" : 27702892805,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "designmary",
  "in_reply_to_user_id_str" : "7357082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "signmeup",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27712896868",
  "text" : "Is it possible that science HAS proven the existence of God, and Its name is Placebo? Also, placebo is Latin for \"I shall please.\" #signmeup",
  "id" : 27712896868,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KiteZA",
      "screen_name" : "KiteZA",
      "indices" : [ 0, 7 ],
      "id_str" : "161012068",
      "id" : 161012068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27762075967",
  "geo" : { },
  "id_str" : "27762242477",
  "in_reply_to_user_id" : 161012068,
  "text" : "@KiteZA No, it doesn't... I already have too many Twitter accounts. I would use the Tumblr blog as the best way to get updates.",
  "id" : 27762242477,
  "in_reply_to_status_id" : 27762075967,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "KiteZA",
  "in_reply_to_user_id_str" : "161012068",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 82, 90 ],
      "id_str" : "5502392",
      "id" : 5502392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27762596216",
  "text" : "How to build a business that optimizes for happiness:\nhttp:\/\/bit.ly\/azrwuw \n\nThis @mojombo guy is my new hero.",
  "id" : 27762596216,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27769883697",
  "text" : "Does anyone know of any tech startups that are L3Cs? http:\/\/en.wikipedia.org\/wiki\/L3C",
  "id" : 27769883697,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen",
      "screen_name" : "allenm73",
      "indices" : [ 0, 9 ],
      "id_str" : "571505381",
      "id" : 571505381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27770306596",
  "geo" : { },
  "id_str" : "27770421709",
  "in_reply_to_user_id" : 22118364,
  "text" : "@allenm73 Any idea why they decided against it?",
  "id" : 27770421709,
  "in_reply_to_status_id" : 27770306596,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "allenmmurray",
  "in_reply_to_user_id_str" : "22118364",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 19, 28 ],
      "id_str" : "780991",
      "id" : 780991
    }, {
      "name" : "Hashable",
      "screen_name" : "Hashable",
      "indices" : [ 130, 139 ],
      "id_str" : "140882350",
      "id" : 140882350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "talkingwith",
      "indices" : [ 6, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27779215619",
  "text" : "After #talkingwith @amyjokim today, I feel better prepared to safely navigate the turbulent waters of this gamification trend \/cc @hashable",
  "id" : 27779215619,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Pink",
      "screen_name" : "DanielPink",
      "indices" : [ 127, 138 ],
      "id_str" : "14378113",
      "id" : 14378113
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 42, 55 ]
    }, {
      "text" : "someta",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27781287143",
  "text" : "I'm starting a new series scoring various #gamification and motivation techniques I've found: http:\/\/bit.ly\/bc2N7E #someta \/cc @danielpink",
  "id" : 27781287143,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 129, 137 ],
      "id_str" : "5502392",
      "id" : 5502392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27592235581",
  "text" : "My kinda guy. \"Optimize for happiness by striving for autonomy, mastery, and purpose.\" - paraphrase of Dan Pink's book DRiVE via @mojombo",
  "id" : 27592235581,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sus2010",
      "indices" : [ 9, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27594141544",
  "text" : "Watching #sus2010 http:\/\/bit.ly\/cRVz7v . Ron Conway made me want to build the next Facebook. Cofounder of GitHub convinced me to bootstrap.",
  "id" : 27594141544,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HJEntertains",
      "indices" : [ 44, 57 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27596200515",
  "geo" : { },
  "id_str" : "27597094756",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane You are too kind. Thanks for the #HJEntertains tip about chilling champagne yesterday too!",
  "id" : 27597094756,
  "in_reply_to_status_id" : 27596200515,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.347667 ]
  },
  "id_str" : "27603140162",
  "text" : "8:36pm Telling this guy that sleep is the latest rage but he's not buying it http:\/\/flic.kr\/p\/8KAGQi",
  "id" : 27603140162,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27606226306",
  "geo" : { },
  "id_str" : "27610615271",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver Yes, for sure. Was just realizing the attractiveness of both options.",
  "id" : 27610615271,
  "in_reply_to_status_id" : 27606226306,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Om Malik",
      "screen_name" : "om",
      "indices" : [ 3, 6 ],
      "id_str" : "989",
      "id" : 989
    }, {
      "name" : "Gigaom",
      "screen_name" : "gigaom",
      "indices" : [ 82, 89 ],
      "id_str" : "2893971",
      "id" : 2893971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 77 ],
      "url" : "http:\/\/t.co\/jL3nFXs",
      "expanded_url" : "http:\/\/gigaom.com\/2010\/10\/16\/my-9-favorite-startup-lessons-from-startup-school\/",
      "display_url" : "gigaom.com\/2010\/10\/16\/my-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "27638404792",
  "text" : "RT @om: My 9 Favorite Startup Lessons From Startup\u00A0School http:\/\/t.co\/jL3nFXs via @gigaom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gigaom",
        "screen_name" : "gigaom",
        "indices" : [ 74, 81 ],
        "id_str" : "2893971",
        "id" : 2893971
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 69 ],
        "url" : "http:\/\/t.co\/jL3nFXs",
        "expanded_url" : "http:\/\/gigaom.com\/2010\/10\/16\/my-9-favorite-startup-lessons-from-startup-school\/",
        "display_url" : "gigaom.com\/2010\/10\/16\/my-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "27608425184",
    "text" : "My 9 Favorite Startup Lessons From Startup\u00A0School http:\/\/t.co\/jL3nFXs via @gigaom",
    "id" : 27608425184,
    "created_at" : "2010-10-17 04:56:38 +0000",
    "user" : {
      "name" : "Om Malik",
      "screen_name" : "om",
      "protected" : false,
      "id_str" : "989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2601170258\/z3bo77mwfuz7ll7fd9z0_normal.jpeg",
      "id" : 989,
      "verified" : true
    }
  },
  "id" : 27638404792,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Orgnet, LLC",
      "screen_name" : "orgnet",
      "indices" : [ 3, 10 ],
      "id_str" : "41841330",
      "id" : 41841330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27638644741",
  "text" : "RT @orgnet: Are Social Signals the New PageRank?  http:\/\/bit.ly\/cfix3H",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27634067115",
    "text" : "Are Social Signals the New PageRank?  http:\/\/bit.ly\/cfix3H",
    "id" : 27634067115,
    "created_at" : "2010-10-17 12:48:55 +0000",
    "user" : {
      "name" : "Orgnet, LLC",
      "screen_name" : "orgnet",
      "protected" : false,
      "id_str" : "41841330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3725769707\/a146810f81f82f65f518017527387f50_normal.png",
      "id" : 41841330,
      "verified" : false
    }
  },
  "id" : 27638644741,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27657549393",
  "text" : "I agree that Twitter is undervalued compared to Facebook. Good reasons here: http:\/\/tcrn.ch\/943cYQ",
  "id" : 27657549393,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27661847719",
  "text" : "The biggest threat to idea books is that most good ideas seem about the size of a TED Talk or a medium-sized blog post.",
  "id" : 27661847719,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27677614493",
  "text" : "Books that have changed the way I think: Flow, Mastery, Linchpin, Drive, The War of Art, One Small Step Can Change Your Life",
  "id" : 27677614493,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 27, 37 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27559890770",
  "text" : "Anyone want to join us for @kellianne's birthday brunch at Portage Bay in about an hour?",
  "id" : 27559890770,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tina Roth Eisenberg",
      "screen_name" : "swissmiss",
      "indices" : [ 3, 13 ],
      "id_str" : "1504011",
      "id" : 1504011
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "feastongood",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27493395040",
  "text" : "RT @swissmiss: \"You're the average of the five people you spend the most time with\".  - Jim Rohn #feastongood",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "feastongood",
        "indices" : [ 82, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27477818964",
    "text" : "\"You're the average of the five people you spend the most time with\".  - Jim Rohn #feastongood",
    "id" : 27477818964,
    "created_at" : "2010-10-15 21:01:54 +0000",
    "user" : {
      "name" : "Tina Roth Eisenberg",
      "screen_name" : "swissmiss",
      "protected" : false,
      "id_str" : "1504011",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451419379264012288\/ZKB70ht2_normal.jpeg",
      "id" : 1504011,
      "verified" : false
    }
  },
  "id" : 27493395040,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 51, 61 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614166, -122.327834 ]
  },
  "id_str" : "27509518374",
  "text" : "8:36pm CELEBRATING with the loveliest of lovelies, @Kellianne! http:\/\/flic.kr\/p\/8Km8rc",
  "id" : 27509518374,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27511526199",
  "geo" : { },
  "id_str" : "27517995923",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin Not sure but I have the same crazy scenario go through my head every morning that I walk down the stairs.",
  "id" : 27517995923,
  "in_reply_to_status_id" : 27511526199,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27518235318",
  "geo" : { },
  "id_str" : "27559789427",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin I co-hosted the first Quantified Self Seattle meeting last week! Want to be involved in the next one?",
  "id" : 27559789427,
  "in_reply_to_status_id" : 27518235318,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27386071331",
  "geo" : { },
  "id_str" : "27400692541",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb I just noticed that when I checked your page earlier today to see if I was getting any closer to passing you. :)",
  "id" : 27400692541,
  "in_reply_to_status_id" : 27386071331,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "snakeeatstail",
      "indices" : [ 104, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27403379698",
  "text" : "What if snopes.com created fake controversies in order to sell ads? This is not a hoax. Please forward. #snakeeatstail",
  "id" : 27403379698,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 67, 77 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27407265930",
  "text" : "8:36pm Watching John and Mary with the family and dinner in bed on @kellianne's bday eve http:\/\/flic.kr\/p\/8KaVxC",
  "id" : 27407265930,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27408699952",
  "geo" : { },
  "id_str" : "27465545168",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim He's 5 months old today, and totally awesome in every way.",
  "id" : 27465545168,
  "in_reply_to_status_id" : 27408699952,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hashable",
      "screen_name" : "Hashable",
      "indices" : [ 20, 29 ],
      "id_str" : "140882350",
      "id" : 140882350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "intro",
      "indices" : [ 42, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27478829431",
  "text" : "Who's already using @hashable?  Would you #intro me to someone? I would love to try it out.",
  "id" : 27478829431,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Yavonditte",
      "screen_name" : "mikeyavo",
      "indices" : [ 0, 9 ],
      "id_str" : "59580078",
      "id" : 59580078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27478869339",
  "geo" : { },
  "id_str" : "27479224184",
  "in_reply_to_user_id" : 59580078,
  "text" : "@mikeyavo Thanks, Michael!",
  "id" : 27479224184,
  "in_reply_to_status_id" : 27478869339,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "mikeyavo",
  "in_reply_to_user_id_str" : "59580078",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Yavonditte",
      "screen_name" : "mikeyavo",
      "indices" : [ 0, 9 ],
      "id_str" : "59580078",
      "id" : 59580078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27480730147",
  "geo" : { },
  "id_str" : "27481386694",
  "in_reply_to_user_id" : 59580078,
  "text" : "@mikeyavo Already did it! It's unclear if it has saved my email credentials or just used it to find people, though.",
  "id" : 27481386694,
  "in_reply_to_status_id" : 27480730147,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "mikeyavo",
  "in_reply_to_user_id_str" : "59580078",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Yavonditte",
      "screen_name" : "mikeyavo",
      "indices" : [ 0, 9 ],
      "id_str" : "59580078",
      "id" : 59580078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27481473820",
  "geo" : { },
  "id_str" : "27481748182",
  "in_reply_to_user_id" : 59580078,
  "text" : "@mikeyavo Got it. Well love it so far. Good work.",
  "id" : 27481748182,
  "in_reply_to_status_id" : 27481473820,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "mikeyavo",
  "in_reply_to_user_id_str" : "59580078",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27307698038",
  "text" : "8:36pm At a totally fun meetup of self-trackers! http:\/\/flic.kr\/p\/8JW4kA",
  "id" : 27307698038,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27308035530",
  "geo" : { },
  "id_str" : "27314612115",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie I am so jealous. I want to go to one so badly. I'm planning an SF trip soon... when's the next one?",
  "id" : 27314612115,
  "in_reply_to_status_id" : 27308035530,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Dean",
      "screen_name" : "sgdean",
      "indices" : [ 0, 7 ],
      "id_str" : "12065472",
      "id" : 12065472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 51, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27329858208",
  "geo" : { },
  "id_str" : "27352692938",
  "in_reply_to_user_id" : 12065472,
  "text" : "@sgdean That's great! Wish I could join you at the #quantifiedself meetup tonight, just co-hosted our 1st in Seattle last night.",
  "id" : 27352692938,
  "in_reply_to_status_id" : 27329858208,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "sgdean",
  "in_reply_to_user_id_str" : "12065472",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MacRumors.com",
      "screen_name" : "MacRumors",
      "indices" : [ 3, 13 ],
      "id_str" : "14861285",
      "id" : 14861285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27372443200",
  "text" : "RT @MacRumors: Former Apple CEO John Sculley Reflects on Steve Jobs http:\/\/macrumo.rs\/8ZLLQE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27371989607",
    "text" : "Former Apple CEO John Sculley Reflects on Steve Jobs http:\/\/macrumo.rs\/8ZLLQE",
    "id" : 27371989607,
    "created_at" : "2010-10-14 20:03:03 +0000",
    "user" : {
      "name" : "MacRumors.com",
      "screen_name" : "MacRumors",
      "protected" : false,
      "id_str" : "14861285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2611360072\/uoza6k5toiy51th66jlj_normal.jpeg",
      "id" : 14861285,
      "verified" : true
    }
  },
  "id" : 27372443200,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin L. Haas",
      "screen_name" : "delohaas",
      "indices" : [ 0, 9 ],
      "id_str" : "24212532",
      "id" : 24212532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27385535105",
  "geo" : { },
  "id_str" : "27385739177",
  "in_reply_to_user_id" : 24212532,
  "text" : "@delohaas Sweet! Pimp my stuff, Ben!",
  "id" : 27385739177,
  "in_reply_to_status_id" : 27385535105,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "delohaas",
  "in_reply_to_user_id_str" : "24212532",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QuantifiedSelf",
      "indices" : [ 69, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27192738683",
  "text" : "Come have a drink & discuss the fun of tracking your life at the 1st #QuantifiedSelf Seattle meetup ever! Tomorrow! http:\/\/bit.ly\/9kSc1P",
  "id" : 27192738683,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27208490293",
  "text" : "8:36pm Exhausted + wine+ chocolate + downloading the Garden State = my brain today http:\/\/flic.kr\/p\/8JFkH1",
  "id" : 27208490293,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 11, 20 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27215556910",
  "geo" : { },
  "id_str" : "27215670558",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel @rickwebb Laziness wins out! Daily Show is all I could manage.",
  "id" : 27215670558,
  "in_reply_to_status_id" : 27215556910,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QuantifiedSelf",
      "indices" : [ 77, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27267530153",
  "text" : "I think I'm going to talk about this idea of a fitness function at tonight's #QuantifiedSelf meetup. You should come! http:\/\/bit.ly\/dtnJdE",
  "id" : 27267530153,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 37, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27281203331",
  "text" : "I'm in The Stranger this week! pg 30 #fb http:\/\/flic.kr\/p\/8JPx4a",
  "id" : 27281203331,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan P. Mart\u00EDnek",
      "screen_name" : "janpmartinek",
      "indices" : [ 3, 16 ],
      "id_str" : "47124592",
      "id" : 47124592
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 36, 49 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27285450515",
  "text" : "RT @janpmartinek: Sincere congrats, @busterbenson ! Btw, the online version of the article is here: http:\/\/bit.ly\/9xT23l Well deserved, man!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 18, 31 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "27281203331",
    "geo" : { },
    "id_str" : "27281516564",
    "in_reply_to_user_id" : 2185,
    "text" : "Sincere congrats, @busterbenson ! Btw, the online version of the article is here: http:\/\/bit.ly\/9xT23l Well deserved, man!",
    "id" : 27281516564,
    "in_reply_to_status_id" : 27281203331,
    "created_at" : "2010-10-13 22:19:43 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Jan P. Mart\u00EDnek",
      "screen_name" : "janpmartinek",
      "protected" : false,
      "id_str" : "47124592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449119131925622784\/hCc_1eYU_normal.png",
      "id" : 47124592,
      "verified" : false
    }
  },
  "id" : 27285450515,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 3, 14 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27287793883",
  "text" : "RT @matthickey: Who wants to do this on Halloween? http:\/\/www.flickr.com\/photos\/docpopular\/4063790568\/sizes\/l\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27286439776",
    "text" : "Who wants to do this on Halloween? http:\/\/www.flickr.com\/photos\/docpopular\/4063790568\/sizes\/l\/",
    "id" : 27286439776,
    "created_at" : "2010-10-13 23:24:19 +0000",
    "user" : {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "protected" : false,
      "id_str" : "8710082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3459148151\/6249cee5120097d6da19a87465b9a670_normal.png",
      "id" : 8710082,
      "verified" : false
    }
  },
  "id" : 27287793883,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Haueter",
      "screen_name" : "chrishaum",
      "indices" : [ 0, 10 ],
      "id_str" : "18823612",
      "id" : 18823612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27103988513",
  "geo" : { },
  "id_str" : "27104330501",
  "in_reply_to_user_id" : 18823612,
  "text" : "@chrishaum Sure! I love to hear ideas.",
  "id" : 27104330501,
  "in_reply_to_status_id" : 27103988513,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "chrishaum",
  "in_reply_to_user_id_str" : "18823612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27105319826",
  "text" : "8:36pm This guy likes his mom. http:\/\/flic.kr\/p\/8Jm2NV",
  "id" : 27105319826,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Haueter",
      "screen_name" : "chrishaum",
      "indices" : [ 0, 10 ],
      "id_str" : "18823612",
      "id" : 18823612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27105496676",
  "geo" : { },
  "id_str" : "27106307743",
  "in_reply_to_user_id" : 18823612,
  "text" : "@chrishaum Oh yeah! This twitter username at gmail.",
  "id" : 27106307743,
  "in_reply_to_status_id" : 27105496676,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "chrishaum",
  "in_reply_to_user_id_str" : "18823612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave McClure",
      "screen_name" : "davemcclure",
      "indices" : [ 3, 15 ],
      "id_str" : "1081",
      "id" : 1081
    }, {
      "name" : "Charlie O'Donnell",
      "screen_name" : "ceonyc",
      "indices" : [ 111, 118 ],
      "id_str" : "768632",
      "id" : 768632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "design",
      "indices" : [ 119, 126 ]
    }, {
      "text" : "warmgun",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27147609252",
  "text" : "RT @davemcclure: \"Need Tech Cofounder? Actually, There's Diff Hire u Should Make 1st\" http:\/\/read.bi\/9qN2D3 by @ceonyc #design #warmgun",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charlie O'Donnell",
        "screen_name" : "ceonyc",
        "indices" : [ 94, 101 ],
        "id_str" : "768632",
        "id" : 768632
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "design",
        "indices" : [ 102, 109 ]
      }, {
        "text" : "warmgun",
        "indices" : [ 110, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27147438762",
    "text" : "\"Need Tech Cofounder? Actually, There's Diff Hire u Should Make 1st\" http:\/\/read.bi\/9qN2D3 by @ceonyc #design #warmgun",
    "id" : 27147438762,
    "created_at" : "2010-10-12 15:12:20 +0000",
    "user" : {
      "name" : "Dave McClure",
      "screen_name" : "davemcclure",
      "protected" : false,
      "id_str" : "1081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459531005599035392\/uWmMxqOr_normal.jpeg",
      "id" : 1081,
      "verified" : true
    }
  },
  "id" : 27147609252,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "MarshallHaas",
      "indices" : [ 0, 13 ],
      "id_str" : "1268491417",
      "id" : 1268491417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27150536322",
  "geo" : { },
  "id_str" : "27151575415",
  "in_reply_to_user_id" : 19028099,
  "text" : "@MarshallHaas Thanks, Marshall!",
  "id" : 27151575415,
  "in_reply_to_status_id" : 27150536322,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27156673476",
  "text" : "And it's back! http:\/\/facebook.com\/healthmonth\n\nApparently Twitter-bullying works. Thank you everyone. Deleting post and following up soon.",
  "id" : 27156673476,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27162376946",
  "text" : "Twitter & the social network: more effective than reason, lawyers, police http:\/\/goo.gl\/fb\/pO3w4 (& how I got my Faceboook page back)",
  "id" : 27162376946,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whois101",
      "screen_name" : "whois101",
      "indices" : [ 0, 9 ],
      "id_str" : "16687325",
      "id" : 16687325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27164514960",
  "geo" : { },
  "id_str" : "27173323281",
  "in_reply_to_user_id" : 16687325,
  "text" : "@whois101 Yup, got the group back too!",
  "id" : 27173323281,
  "in_reply_to_status_id" : 27164514960,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "whois101",
  "in_reply_to_user_id_str" : "16687325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27175369952",
  "geo" : { },
  "id_str" : "27175542752",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin Twitter, I assume, if you're asking that question on here. :)",
  "id" : 27175542752,
  "in_reply_to_status_id" : 27175369952,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27186268623",
  "text" : "Being angry is draining. Snuck out of work to watch The Social Network to relax and really loved it. Go Mark! (the real one)",
  "id" : 27186268623,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 75, 85 ],
      "id_str" : "10015122",
      "id" : 10015122
    }, {
      "name" : "ScottieYahtzee",
      "screen_name" : "ScottieYahtzee",
      "indices" : [ 86, 101 ],
      "id_str" : "15486015",
      "id" : 15486015
    }, {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 102, 112 ],
      "id_str" : "1771141",
      "id" : 1771141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "101010wedding",
      "indices" : [ 40, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61302, -122.344415 ]
  },
  "id_str" : "26995273100",
  "text" : "Happy celebrations to Laurie and Jacob! #101010wedding (@ The Crocodile w\/ @andypixel @scottieyahtzee @samantham) http:\/\/4sq.com\/6Ph0sO",
  "id" : 26995273100,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Kim",
      "screen_name" : "michaelbkim",
      "indices" : [ 3, 15 ],
      "id_str" : "2915391",
      "id" : 2915391
    }, {
      "name" : "AppSumo.com",
      "screen_name" : "AppSumo",
      "indices" : [ 74, 82 ],
      "id_str" : "132021364",
      "id" : 132021364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27043303687",
  "text" : "RT @michaelbkim: I just got KISSmetrics lifetime account for Free! Follow @appsumo and RT for yours! http:\/\/bit.ly\/cTUyHY",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AppSumo.com",
        "screen_name" : "AppSumo",
        "indices" : [ 57, 65 ],
        "id_str" : "132021364",
        "id" : 132021364
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27042498279",
    "text" : "I just got KISSmetrics lifetime account for Free! Follow @appsumo and RT for yours! http:\/\/bit.ly\/cTUyHY",
    "id" : 27042498279,
    "created_at" : "2010-10-11 15:12:52 +0000",
    "user" : {
      "name" : "Michael Kim",
      "screen_name" : "michaelbkim",
      "protected" : false,
      "id_str" : "2915391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1370062673\/image_normal.jpg",
      "id" : 2915391,
      "verified" : false
    }
  },
  "id" : 27043303687,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "babymilestone",
      "indices" : [ 66, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26900658971",
  "text" : "Niko just learned how to pound his arms on the table insistently. #babymilestone http:\/\/flic.kr\/p\/8HFhaR",
  "id" : 26900658971,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 0, 5 ],
      "id_str" : "541",
      "id" : 541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26901015063",
  "geo" : { },
  "id_str" : "26901575399",
  "in_reply_to_user_id" : 541,
  "text" : "@lane Thank you! We are quite entertained by him, as you can probably tell.",
  "id" : 26901575399,
  "in_reply_to_status_id" : 26901015063,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "lane",
  "in_reply_to_user_id_str" : "541",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125, -122.347667 ]
  },
  "id_str" : "26904584944",
  "text" : "8:36pm It's new baby tricks crack up fest over here. http:\/\/flic.kr\/p\/8HFSrB",
  "id" : 26904584944,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ario Jafarzadeh",
      "screen_name" : "ario",
      "indices" : [ 0, 5 ],
      "id_str" : "294",
      "id" : 294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26941562367",
  "geo" : { },
  "id_str" : "26942770280",
  "in_reply_to_user_id" : 294,
  "text" : "@ario I love rivals? Will you be my nemesis? Health Month does give points for moderation though...",
  "id" : 26942770280,
  "in_reply_to_status_id" : 26941562367,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "ario",
  "in_reply_to_user_id_str" : "294",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy",
      "screen_name" : "randem",
      "indices" : [ 3, 10 ],
      "id_str" : "10007692",
      "id" : 10007692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26948761042",
  "text" : "RT @randem: Happy 101010. Or, as they say on the web, \"dark gray\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26946236597",
    "text" : "Happy 101010. Or, as they say on the web, \"dark gray\".",
    "id" : 26946236597,
    "created_at" : "2010-10-10 15:30:32 +0000",
    "user" : {
      "name" : "Randy",
      "screen_name" : "randem",
      "protected" : false,
      "id_str" : "10007692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57352338\/1368168819_f792c91706_normal.jpg",
      "id" : 10007692,
      "verified" : false
    }
  },
  "id" : 26948761042,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 27, 39 ],
      "id_str" : "154236895",
      "id" : 154236895
    }, {
      "name" : "twilio",
      "screen_name" : "twilio",
      "indices" : [ 110, 117 ],
      "id_str" : "15936194",
      "id" : 15936194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26954008924",
  "text" : "I added 10 new features to @healthmonth for 10.10.10. http:\/\/bit.ly\/bVV3uQ including initial integration with @twilio - more coming soon!",
  "id" : 26954008924,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Buie",
      "screen_name" : "ebuie",
      "indices" : [ 0, 6 ],
      "id_str" : "13232092",
      "id" : 13232092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26957077183",
  "geo" : { },
  "id_str" : "26957453949",
  "in_reply_to_user_id" : 13232092,
  "text" : "@ebuie Not at the moment. Refactoring how wild cards work pretty soon though!",
  "id" : 26957453949,
  "in_reply_to_status_id" : 26957077183,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "ebuie",
  "in_reply_to_user_id_str" : "13232092",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 19, 29 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gameful",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26959612683",
  "text" : "Love it so far! RT @avantgame: Secret backdoor to #gameful is open if you know the secret URL! (Or if you are super duper clever) fiero! \\o\/",
  "id" : 26959612683,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enjoymentland",
      "screen_name" : "enjoymentland",
      "indices" : [ 3, 17 ],
      "id_str" : "19808652",
      "id" : 19808652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26966607752",
  "text" : "RT @enjoymentland: Me vs Health Month (and why fitness functions are great) http:\/\/goo.gl\/fb\/JDMLm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26966099591",
    "text" : "Me vs Health Month (and why fitness functions are great) http:\/\/goo.gl\/fb\/JDMLm",
    "id" : 26966099591,
    "created_at" : "2010-10-10 19:51:36 +0000",
    "user" : {
      "name" : "Enjoymentland",
      "screen_name" : "enjoymentland",
      "protected" : false,
      "id_str" : "19808652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/203690467\/enjoymentland-walnut-transparent_normal.png",
      "id" : 19808652,
      "verified" : false
    }
  },
  "id" : 26966607752,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 3, 15 ],
      "id_str" : "154236895",
      "id" : 154236895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26802904748",
  "text" : "RT @healthmonth: Who wants to nominate healthmonth.com for best online game? http:\/\/mashable.com\/awards\/ I'll be your best friend.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26802735216",
    "text" : "Who wants to nominate healthmonth.com for best online game? http:\/\/mashable.com\/awards\/ I'll be your best friend.",
    "id" : 26802735216,
    "created_at" : "2010-10-09 01:24:19 +0000",
    "user" : {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "protected" : false,
      "id_str" : "154236895",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1136999397\/track_meals.400_normal.png",
      "id" : 154236895,
      "verified" : false
    }
  },
  "id" : 26802904748,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sommar",
      "screen_name" : "Sommar",
      "indices" : [ 0, 7 ],
      "id_str" : "80323",
      "id" : 80323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26803752335",
  "geo" : { },
  "id_str" : "26803845348",
  "in_reply_to_user_id" : 80323,
  "text" : "@Sommar Thank you so much. :)",
  "id" : 26803845348,
  "in_reply_to_status_id" : 26803752335,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "Sommar",
  "in_reply_to_user_id_str" : "80323",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lyndi Thompson",
      "screen_name" : "lyndit",
      "indices" : [ 3, 10 ],
      "id_str" : "15411442",
      "id" : 15411442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26854954271",
  "text" : "RT @lyndit: If you cannot do great things, do small things in a great way. \u2013 Napoleon Hill",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26851067259",
    "text" : "If you cannot do great things, do small things in a great way. \u2013 Napoleon Hill",
    "id" : 26851067259,
    "created_at" : "2010-10-09 15:15:07 +0000",
    "user" : {
      "name" : "Lyndi Thompson",
      "screen_name" : "lyndit",
      "protected" : false,
      "id_str" : "15411442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461915130314240000\/DlBgan5B_normal.jpeg",
      "id" : 15411442,
      "verified" : false
    }
  },
  "id" : 26854954271,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hellofuture",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26873698726",
  "text" : "All of a sudden self-driving cars make a lot of sense to me. Let's do this! http:\/\/tcrn.ch\/b0M3Og #hellofuture",
  "id" : 26873698726,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.347667 ]
  },
  "id_str" : "26782521639",
  "text" : "Niko wants to beat someone up. http:\/\/flic.kr\/p\/8Hrb8U",
  "id" : 26782521639,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 129, 139 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 36, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26711350787",
  "text" : "Who are the smartest thinkers about #gamification (game dynamics for non-game experiences)? Why?  http:\/\/bit.ly\/cmmary\n\nMy vote: @avantgame",
  "id" : 26711350787,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26713313543",
  "geo" : { },
  "id_str" : "26713611010",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame That's why you're the best! :) I was hoping someone would coin the word engagification to replace gamification...",
  "id" : 26713611010,
  "in_reply_to_status_id" : 26713313543,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26713313543",
  "geo" : { },
  "id_str" : "26713711916",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame PS. Huge fan of Gameful, can't wait to get my puzzle piece!",
  "id" : 26713711916,
  "in_reply_to_status_id" : 26713313543,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.3475 ]
  },
  "id_str" : "26715573283",
  "text" : "8:36pm Was doot-doot-dooing this guy to sleep http:\/\/flic.kr\/p\/8HhnFd",
  "id" : 26715573283,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "octave kitten",
      "screen_name" : "zombielolita",
      "indices" : [ 0, 13 ],
      "id_str" : "239622110",
      "id" : 239622110
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 37, 48 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26716780682",
  "geo" : { },
  "id_str" : "26717150227",
  "in_reply_to_user_id" : 16366882,
  "text" : "@zombielolita The only thing between @nikobenson and his first iPad, which he already owns, is the ability to control his fingers.",
  "id" : 26717150227,
  "in_reply_to_status_id" : 26716780682,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 122, 131 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26725126058",
  "text" : "One of the clearest and most illuminating articles on positive thinking I've read in a while: \n\nhttp:\/\/bit.ly\/9J3UPH \/via @amyjokim",
  "id" : 26725126058,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P. F. Anderson",
      "screen_name" : "pfanderson",
      "indices" : [ 0, 11 ],
      "id_str" : "5618162",
      "id" : 5618162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26744162913",
  "geo" : { },
  "id_str" : "26746538775",
  "in_reply_to_user_id" : 5618162,
  "text" : "@pfanderson Some guy claimed IP infringement and Facebook took the page down with no attempt at verifying. I'm trying to reason with them...",
  "id" : 26746538775,
  "in_reply_to_status_id" : 26744162913,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "pfanderson",
  "in_reply_to_user_id_str" : "5618162",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26764099352",
  "text" : "Apparently Facebook believes all claims of IP infringement and won't listen to evidence to the contrary without a lawyer getting involved.",
  "id" : 26764099352,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26764194271",
  "text" : "Therefore, some random person named Conrad Schulman at Life Allowance http:\/\/on.fb.me\/aho3Bc can have my Facebook page permanently deleted.",
  "id" : 26764194271,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26764487989",
  "text" : "What should I do?",
  "id" : 26764487989,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26764559239",
  "geo" : { },
  "id_str" : "26765431468",
  "in_reply_to_user_id" : 10600312,
  "text" : "@TomHeadLovesYou 5 days ago, I think. I was trying to reason with Facebook and Conrad before talking about it publicly.",
  "id" : 26765431468,
  "in_reply_to_status_id" : 26764559239,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "_tomhead",
  "in_reply_to_user_id_str" : "10600312",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dunsany",
      "screen_name" : "dunsany",
      "indices" : [ 0, 8 ],
      "id_str" : "14622910",
      "id" : 14622910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26769746888",
  "geo" : { },
  "id_str" : "26769926217",
  "in_reply_to_user_id" : 14622910,
  "text" : "@dunsany Actually, I had just purchased $100 of Facebook ads to point to the page...",
  "id" : 26769926217,
  "in_reply_to_status_id" : 26769746888,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "dunsany",
  "in_reply_to_user_id_str" : "14622910",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordy Mont-Reynaud",
      "screen_name" : "curiousjordy",
      "indices" : [ 0, 13 ],
      "id_str" : "1000",
      "id" : 1000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26773482916",
  "geo" : { },
  "id_str" : "26774013078",
  "in_reply_to_user_id" : 1000,
  "text" : "@curiousjordy Oh cool, thanks. Hopefully one of these leads will get this resolved. It's such a waste of energy!",
  "id" : 26774013078,
  "in_reply_to_status_id" : 26773482916,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "curiousjordy",
  "in_reply_to_user_id_str" : "1000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordy Mont-Reynaud",
      "screen_name" : "curiousjordy",
      "indices" : [ 0, 13 ],
      "id_str" : "1000",
      "id" : 1000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26776726032",
  "geo" : { },
  "id_str" : "26776795770",
  "in_reply_to_user_id" : 1000,
  "text" : "@curiousjordy Yeah, it did have the custom url.",
  "id" : 26776795770,
  "in_reply_to_status_id" : 26776726032,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "curiousjordy",
  "in_reply_to_user_id_str" : "1000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26781956594",
  "text" : "My emails back and forth with Marissa in User Operations at Facebook continue to be an exploration of pre-baked blurbs. I need a hamburger.",
  "id" : 26781956594,
  "created_at" : "2010-10-08 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.347667 ]
  },
  "id_str" : "26616390812",
  "text" : "8:36pm Dinner and Niko dancing party with Tyler and Loren http:\/\/flic.kr\/p\/8H4d4Q",
  "id" : 26616390812,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "threlkelded",
      "indices" : [ 0, 12 ],
      "id_str" : "4979381",
      "id" : 4979381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26621744416",
  "geo" : { },
  "id_str" : "26622242901",
  "in_reply_to_user_id" : 4979381,
  "text" : "@threlkelded What? Where? Snide is not encouraged. I will delete inappropriate comments.",
  "id" : 26622242901,
  "in_reply_to_status_id" : 26621744416,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "threlkelded",
  "in_reply_to_user_id_str" : "4979381",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Erick Schonfeld",
      "screen_name" : "erickschonfeld",
      "indices" : [ 130, 140 ],
      "id_str" : "12798452",
      "id" : 12798452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26654302542",
  "text" : "RT @TechCrunch: Oops! That Facebook Location Patent Forgot To Mention Crowley's Earlier Dodgeball Patent http:\/\/tcrn.ch\/bz5JN9 by @erick ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vip.wordpress.com\/hosting\" rel=\"nofollow\"\u003EWordPress.com VIP\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Erick Schonfeld",
        "screen_name" : "erickschonfeld",
        "indices" : [ 114, 129 ],
        "id_str" : "12798452",
        "id" : 12798452
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26652703960",
    "text" : "Oops! That Facebook Location Patent Forgot To Mention Crowley's Earlier Dodgeball Patent http:\/\/tcrn.ch\/bz5JN9 by @erickschonfeld",
    "id" : 26652703960,
    "created_at" : "2010-10-07 14:20:20 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2176846885\/-5-1_normal.jpeg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 26654302542,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Selvitelle",
      "screen_name" : "bs",
      "indices" : [ 0, 3 ],
      "id_str" : "309073",
      "id" : 309073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26679199499",
  "geo" : { },
  "id_str" : "26679289389",
  "in_reply_to_user_id" : 309073,
  "text" : "@bs Hi! There should be a \"Your team\" menu item in the \"Current game\" menu at the bottom of the page. What's your team's name?",
  "id" : 26679289389,
  "in_reply_to_status_id" : 26679199499,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "bs",
  "in_reply_to_user_id_str" : "309073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Selvitelle",
      "screen_name" : "bs",
      "indices" : [ 0, 3 ],
      "id_str" : "309073",
      "id" : 309073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26681117034",
  "geo" : { },
  "id_str" : "26681339076",
  "in_reply_to_user_id" : 309073,
  "text" : "@bs That doesn't look good! I'll fix that immediately, thanks for letting me know.  :)",
  "id" : 26681339076,
  "in_reply_to_status_id" : 26681117034,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "bs",
  "in_reply_to_user_id_str" : "309073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Selvitelle",
      "screen_name" : "bs",
      "indices" : [ 0, 3 ],
      "id_str" : "309073",
      "id" : 309073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26681117034",
  "geo" : { },
  "id_str" : "26682019915",
  "in_reply_to_user_id" : 309073,
  "text" : "@bs Which version of Chrome and operating system are you on? I'm on 6.0.472.63 on Mac and it looks fine (other than the annoying status bar)",
  "id" : 26682019915,
  "in_reply_to_status_id" : 26681117034,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "bs",
  "in_reply_to_user_id_str" : "309073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 0, 2 ],
      "id_str" : "11222",
      "id" : 11222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26684547224",
  "geo" : { },
  "id_str" : "26685220116",
  "in_reply_to_user_id" : 11222,
  "text" : "@k It's all about creating a personal brand smoke screen so everyone's confused about who you are. Works amazingly well at that goal. :)",
  "id" : 26685220116,
  "in_reply_to_status_id" : 26684547224,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "k",
  "in_reply_to_user_id_str" : "11222",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexia Tsotsis",
      "screen_name" : "alexia",
      "indices" : [ 14, 21 ],
      "id_str" : "18327902",
      "id" : 18327902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26518857293",
  "text" : "\"Awesome!\" RT @alexia: You can't believe how happy it made me to \"Like\" this on Facebook http:\/\/tcrn.ch\/alQElT",
  "id" : 26518857293,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 3, 12 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/Xj6Njrj",
      "expanded_url" : "http:\/\/www.businessinsider.com\/research-shows-6-hours-of-sleep-a-20-minute-commute-and-4-shopping-sprees-per-month-are-the-keys-to-happiness-2010-9",
      "display_url" : "businessinsider.com\/research-shows\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "26556411939",
  "text" : "RT @arainert: Study shows that a happy life is a cocktail of sleep, family, short commute, booze, exercise and er.. TV? http:\/\/t.co\/Xj6Njrj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 125 ],
        "url" : "http:\/\/t.co\/Xj6Njrj",
        "expanded_url" : "http:\/\/www.businessinsider.com\/research-shows-6-hours-of-sleep-a-20-minute-commute-and-4-shopping-sprees-per-month-are-the-keys-to-happiness-2010-9",
        "display_url" : "businessinsider.com\/research-shows\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "26551979372",
    "text" : "Study shows that a happy life is a cocktail of sleep, family, short commute, booze, exercise and er.. TV? http:\/\/t.co\/Xj6Njrj",
    "id" : 26551979372,
    "created_at" : "2010-10-06 13:41:11 +0000",
    "user" : {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "protected" : false,
      "id_str" : "7482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444089158274154496\/ZePPNQzQ_normal.jpeg",
      "id" : 7482,
      "verified" : false
    }
  },
  "id" : 26556411939,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0420\u0430\u0445\u043C\u0435\u0442\u043E\u0432a \u0418\u0440\u0438\u043D\u0430",
      "screen_name" : "chinoisfemme",
      "indices" : [ 0, 13 ],
      "id_str" : "2492292956",
      "id" : 2492292956
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 14, 23 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 60, 72 ],
      "id_str" : "154236895",
      "id" : 154236895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26556832541",
  "geo" : { },
  "id_str" : "26557040628",
  "in_reply_to_user_id" : 8245682,
  "text" : "@chinoisfemme @arainert And almost all of them translate to @healthmonth rules. Pretty neat!",
  "id" : 26557040628,
  "in_reply_to_status_id" : 26556832541,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "angelacgee",
  "in_reply_to_user_id_str" : "8245682",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26577206360",
  "text" : "Most of my anxiety these days is around either A) worried that I won't gain momentum or B) worried that I'll lose momentum.",
  "id" : 26577206360,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ramez Naam",
      "screen_name" : "ramez",
      "indices" : [ 2, 8 ],
      "id_str" : "6044272",
      "id" : 6044272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26577339326",
  "geo" : { },
  "id_str" : "26577744807",
  "in_reply_to_user_id" : 6044272,
  "text" : ". @ramez I guess the logical conclusion is that working for someone else is a way to delegate momentum-making\/losing anxiety.",
  "id" : 26577744807,
  "in_reply_to_status_id" : 26577339326,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "ramez",
  "in_reply_to_user_id_str" : "6044272",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Livia Labate",
      "screen_name" : "livlab",
      "indices" : [ 0, 7 ],
      "id_str" : "769920",
      "id" : 769920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26414485092",
  "geo" : { },
  "id_str" : "26414798941",
  "in_reply_to_user_id" : 769920,
  "text" : "@livlab They have to ask to be sponsored. See the \"invite people\" link on your team page, if they just need to be approved for the team.",
  "id" : 26414798941,
  "in_reply_to_status_id" : 26414485092,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "livlab",
  "in_reply_to_user_id_str" : "769920",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Livia Labate",
      "screen_name" : "livlab",
      "indices" : [ 0, 7 ],
      "id_str" : "769920",
      "id" : 769920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26415053133",
  "geo" : { },
  "id_str" : "26415769633",
  "in_reply_to_user_id" : 769920,
  "text" : "@livlab Only if they applied for sponsorship... or were already sponsored. If you email me with details, I can look into it further.",
  "id" : 26415769633,
  "in_reply_to_status_id" : 26415053133,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "livlab",
  "in_reply_to_user_id_str" : "769920",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 4, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26417193247",
  "text" : "The #gamification thought leader board has been updated with more people. Still no point system or badges though: http:\/\/bit.ly\/cMPQXF",
  "id" : 26417193247,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ross Collicutt",
      "screen_name" : "rcthink",
      "indices" : [ 0, 8 ],
      "id_str" : "16253448",
      "id" : 16253448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26419428633",
  "geo" : { },
  "id_str" : "26420094718",
  "in_reply_to_user_id" : 16253448,
  "text" : "@rcthink Thanks, Ross.  They've been enjoyable to make.  Still lots of work to do, too.",
  "id" : 26420094718,
  "in_reply_to_status_id" : 26419428633,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "rcthink",
  "in_reply_to_user_id_str" : "16253448",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ross Collicutt",
      "screen_name" : "rcthink",
      "indices" : [ 0, 8 ],
      "id_str" : "16253448",
      "id" : 16253448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26422860057",
  "geo" : { },
  "id_str" : "26424075480",
  "in_reply_to_user_id" : 16253448,
  "text" : "@rcthink Yes. Rails is SO much better. Switch!",
  "id" : 26424075480,
  "in_reply_to_status_id" : 26422860057,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "rcthink",
  "in_reply_to_user_id_str" : "16253448",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P. F. Anderson",
      "screen_name" : "pfanderson",
      "indices" : [ 0, 11 ],
      "id_str" : "5618162",
      "id" : 5618162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26405017423",
  "geo" : { },
  "id_str" : "26424173558",
  "in_reply_to_user_id" : 5618162,
  "text" : "@pfanderson That's very kind of you. I learned it all from my previous startup, 43things.com. Fun is motivating.",
  "id" : 26424173558,
  "in_reply_to_status_id" : 26405017423,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "pfanderson",
  "in_reply_to_user_id_str" : "5618162",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6155, -122.349167 ]
  },
  "id_str" : "26425554358",
  "text" : "8:36pm Dark dinner with Brady, Nick Bilton, and friends http:\/\/flic.kr\/p\/8GuRen",
  "id" : 26425554358,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niki Lips",
      "screen_name" : "nikilips",
      "indices" : [ 0, 9 ],
      "id_str" : "30063272",
      "id" : 30063272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26432166270",
  "geo" : { },
  "id_str" : "26433054412",
  "in_reply_to_user_id" : 30063272,
  "text" : "@nikilips I will! Did you already apply?",
  "id" : 26433054412,
  "in_reply_to_status_id" : 26432166270,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "nikilips",
  "in_reply_to_user_id_str" : "30063272",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26472176776",
  "text" : "I got through about half of my inbox, but am taking the rest of the day off to officially celebrate my 2-year anniversary. See you tomorrow!",
  "id" : 26472176776,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 3, 15 ],
      "id_str" : "154236895",
      "id" : 154236895
    }, {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 33, 45 ],
      "id_str" : "154236895",
      "id" : 154236895
    }, {
      "name" : "Streakly",
      "screen_name" : "playstreakly",
      "indices" : [ 70, 83 ],
      "id_str" : "176505241",
      "id" : 176505241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26487547638",
  "text" : "RT @healthmonth: People who like @healthmonth will probably also like @playstreakly http:\/\/bit.ly\/baoZjn - promising new app to record d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Health Month",
        "screen_name" : "healthmonth",
        "indices" : [ 16, 28 ],
        "id_str" : "154236895",
        "id" : 154236895
      }, {
        "name" : "Streakly",
        "screen_name" : "playstreakly",
        "indices" : [ 53, 66 ],
        "id_str" : "176505241",
        "id" : 176505241
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26487528200",
    "text" : "People who like @healthmonth will probably also like @playstreakly http:\/\/bit.ly\/baoZjn - promising new app to record daily streaks.",
    "id" : 26487528200,
    "created_at" : "2010-10-05 20:24:21 +0000",
    "user" : {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "protected" : false,
      "id_str" : "154236895",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1136999397\/track_meals.400_normal.png",
      "id" : 154236895,
      "verified" : false
    }
  },
  "id" : 26487547638,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ross Collicutt",
      "screen_name" : "rcthink",
      "indices" : [ 0, 8 ],
      "id_str" : "16253448",
      "id" : 16253448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26493826125",
  "geo" : { },
  "id_str" : "26497815676",
  "in_reply_to_user_id" : 16253448,
  "text" : "@rcthink No plans to at the moment, but if it makes sense at some point, I might! http:\/\/750words.com uses it.",
  "id" : 26497815676,
  "in_reply_to_status_id" : 26493826125,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "rcthink",
  "in_reply_to_user_id_str" : "16253448",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P. F. Anderson",
      "screen_name" : "pfanderson",
      "indices" : [ 0, 11 ],
      "id_str" : "5618162",
      "id" : 5618162
    }, {
      "name" : "BJ Fogg",
      "screen_name" : "bjfogg",
      "indices" : [ 97, 104 ],
      "id_str" : "1118691",
      "id" : 1118691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26319908389",
  "geo" : { },
  "id_str" : "26328524549",
  "in_reply_to_user_id" : 5618162,
  "text" : "@pfanderson Thanks for the recommendation! For what it's worth, I have been strongly inspired by @bjfogg's behavior grid work.",
  "id" : 26328524549,
  "in_reply_to_status_id" : 26319908389,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "pfanderson",
  "in_reply_to_user_id_str" : "5618162",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 18, 30 ],
      "id_str" : "154236895",
      "id" : 154236895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.347667 ]
  },
  "id_str" : "26331808730",
  "text" : "8:36pm Setting up @healthmonth, my millionth Twitter account http:\/\/flic.kr\/p\/8GfLmA",
  "id" : 26331808730,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Victor Ho",
      "screen_name" : "grok360",
      "indices" : [ 0, 8 ],
      "id_str" : "9871402",
      "id" : 9871402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26333438214",
  "geo" : { },
  "id_str" : "26334225784",
  "in_reply_to_user_id" : 9871402,
  "text" : "@grok360 Oh yes, I'm a supporter!",
  "id" : 26334225784,
  "in_reply_to_status_id" : 26333438214,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "grok360",
  "in_reply_to_user_id_str" : "9871402",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Victor Ho",
      "screen_name" : "grok360",
      "indices" : [ 0, 8 ],
      "id_str" : "9871402",
      "id" : 9871402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26334813129",
  "geo" : { },
  "id_str" : "26341175838",
  "in_reply_to_user_id" : 9871402,
  "text" : "@grok360 Yeah, it's quite the popular club. Can't wait to get my puzzle piece!",
  "id" : 26341175838,
  "in_reply_to_status_id" : 26334813129,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "grok360",
  "in_reply_to_user_id_str" : "9871402",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26379771031",
  "text" : "Scientists! Siblings share 50% of genes, and their children share 25% of genes -- is there any guess about % of shared *expressed* genes?",
  "id" : 26379771031,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 69, 79 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26396985775",
  "text" : "2 years ago today I married this unsuspecting young lady. Thank you, @kellianne, for being amazing! http:\/\/flic.kr\/p\/8Gtshw",
  "id" : 26396985775,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin L. Haas",
      "screen_name" : "delohaas",
      "indices" : [ 0, 9 ],
      "id_str" : "24212532",
      "id" : 24212532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26398193809",
  "geo" : { },
  "id_str" : "26398733455",
  "in_reply_to_user_id" : 24212532,
  "text" : "@delohaas Ten plus four cheers for 10\/4!",
  "id" : 26398733455,
  "in_reply_to_status_id" : 26398193809,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "delohaas",
  "in_reply_to_user_id_str" : "24212532",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rashmi Sinha",
      "screen_name" : "rashmi",
      "indices" : [ 3, 10 ],
      "id_str" : "610873",
      "id" : 610873
    }, {
      "name" : "Sarah Lacy",
      "screen_name" : "sarahcuda",
      "indices" : [ 25, 35 ],
      "id_str" : "5668942",
      "id" : 5668942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http:\/\/t.co\/HkxZBMb",
      "expanded_url" : "http:\/\/techcrunch.com\/2010\/10\/03\/if-web-1-0%E2%80%99s-kryptonite-was-the-bust-web-2-0-kryptonite-was-the-grind\/",
      "display_url" : "techcrunch.com\/2010\/10\/03\/if-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "26402406963",
  "text" : "RT @rashmi: This post by @sarahcuda has a level of honesty that is disarming http:\/\/t.co\/HkxZBMb",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sarah Lacy",
        "screen_name" : "sarahcuda",
        "indices" : [ 13, 23 ],
        "id_str" : "5668942",
        "id" : 5668942
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 84 ],
        "url" : "http:\/\/t.co\/HkxZBMb",
        "expanded_url" : "http:\/\/techcrunch.com\/2010\/10\/03\/if-web-1-0%E2%80%99s-kryptonite-was-the-bust-web-2-0-kryptonite-was-the-grind\/",
        "display_url" : "techcrunch.com\/2010\/10\/03\/if-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "26400758471",
    "text" : "This post by @sarahcuda has a level of honesty that is disarming http:\/\/t.co\/HkxZBMb",
    "id" : 26400758471,
    "created_at" : "2010-10-04 22:27:13 +0000",
    "user" : {
      "name" : "Rashmi Sinha",
      "screen_name" : "rashmi",
      "protected" : false,
      "id_str" : "610873",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/18267682\/rashmi_bio_100_100_normal.jpg",
      "id" : 610873,
      "verified" : false
    }
  },
  "id" : 26402406963,
  "created_at" : "2010-10-04 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6135, -122.344334 ]
  },
  "id_str" : "26233995939",
  "text" : "8:36pm Finishing dinner. I hear a certain baby is not interested in sleeping. http:\/\/flic.kr\/p\/8FVV6f",
  "id" : 26233995939,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Rifkin",
      "screen_name" : "ifindkarma",
      "indices" : [ 3, 14 ],
      "id_str" : "1688",
      "id" : 1688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26277612685",
  "text" : "RT @ifindkarma: How Facebook Can Become Bigger in 5 Years Than Google is Today... http:\/\/techcrunch.com\/2010\/10\/02\/facebook-bigger-google\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26211220186",
    "text" : "How Facebook Can Become Bigger in 5 Years Than Google is Today... http:\/\/techcrunch.com\/2010\/10\/02\/facebook-bigger-google\/",
    "id" : 26211220186,
    "created_at" : "2010-10-02 22:13:52 +0000",
    "user" : {
      "name" : "Adam Rifkin",
      "screen_name" : "ifindkarma",
      "protected" : false,
      "id_str" : "1688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1776795395\/image1327366995_normal.png",
      "id" : 1688,
      "verified" : false
    }
  },
  "id" : 26277612685,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Campbell",
      "screen_name" : "bitdepth",
      "indices" : [ 0, 9 ],
      "id_str" : "7680",
      "id" : 7680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26204534992",
  "geo" : { },
  "id_str" : "26205886955",
  "in_reply_to_user_id" : 7680,
  "text" : "@bitdepth Thank you, Chris! Luckily it's all highly rewarding to make as well. :)",
  "id" : 26205886955,
  "in_reply_to_status_id" : 26204534992,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "bitdepth",
  "in_reply_to_user_id_str" : "7680",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26206516454",
  "geo" : { },
  "id_str" : "26207116371",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Who do you think does it best?",
  "id" : 26207116371,
  "in_reply_to_status_id" : 26206516454,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 3, 12 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26139820850",
  "text" : "RT @amyjokim: what's the long-term viability of a biz based on copying and aggressively marketing inane but addictive game concepts? htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26138932813",
    "text" : "what's the long-term viability of a biz based on copying and aggressively marketing inane but addictive game concepts? http:\/\/bit.ly\/cmrAPJ",
    "id" : 26138932813,
    "created_at" : "2010-10-02 02:42:10 +0000",
    "user" : {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "protected" : false,
      "id_str" : "780991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1789001732\/ajk-headshot2_normal.jpg",
      "id" : 780991,
      "verified" : false
    }
  },
  "id" : 26139820850,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.347667 ]
  },
  "id_str" : "26143735215",
  "text" : "8:36pm Reaping the benefits of visiting the new Seatown right before closing after a fun rollercoaster day http:\/\/flic.kr\/p\/8FCb82",
  "id" : 26143735215,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Livia Labate",
      "screen_name" : "livlab",
      "indices" : [ 0, 7 ],
      "id_str" : "769920",
      "id" : 769920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26143932243",
  "geo" : { },
  "id_str" : "26144284890",
  "in_reply_to_user_id" : 769920,
  "text" : "@livlab It should be there in the \"Your Current Game\" menu, but it's also here: http:\/\/bit.ly\/a4WMdG",
  "id" : 26144284890,
  "in_reply_to_status_id" : 26143932243,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "livlab",
  "in_reply_to_user_id_str" : "769920",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Livia Labate",
      "screen_name" : "livlab",
      "indices" : [ 0, 7 ],
      "id_str" : "769920",
      "id" : 769920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26146132258",
  "geo" : { },
  "id_str" : "26146746916",
  "in_reply_to_user_id" : 769920,
  "text" : "@livlab I think I just beat you to it. She should have an email saying she was sponsored.  :)",
  "id" : 26146746916,
  "in_reply_to_status_id" : 26146132258,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "livlab",
  "in_reply_to_user_id_str" : "769920",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26175688194",
  "geo" : { },
  "id_str" : "26176438624",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver Oh yeah? Is it available somewhere publicly? I'd love to see it.",
  "id" : 26176438624,
  "in_reply_to_status_id" : 26175688194,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26176540853",
  "geo" : { },
  "id_str" : "26177344689",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver Awesome. Thank you. Any other pitch decks that you'd suggest looking at?",
  "id" : 26177344689,
  "in_reply_to_status_id" : 26176540853,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26177905124",
  "geo" : { },
  "id_str" : "26177988546",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver It's pretty damn impressive.",
  "id" : 26177988546,
  "in_reply_to_status_id" : 26177905124,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 103, 112 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26178852051",
  "text" : "Hadn't seen this pitch deck from Mint.com before. They're clearly pros. http:\/\/slidesha.re\/dBQi7O \/thx @rondiver",
  "id" : 26178852051,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ramdan The Viking",
      "screen_name" : "TheRamdan",
      "indices" : [ 0, 10 ],
      "id_str" : "746722298",
      "id" : 746722298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26179127192",
  "geo" : { },
  "id_str" : "26179448734",
  "in_reply_to_user_id" : 76539829,
  "text" : "@theRamdan To get that badge, you need to survive a month at healthmonth.com.",
  "id" : 26179448734,
  "in_reply_to_status_id" : 26179127192,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "ramd4n",
  "in_reply_to_user_id_str" : "76539829",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26184467557",
  "geo" : { },
  "id_str" : "26184874108",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver Yes, read that yesterday. I was a big wesabe fan in the beginning too.",
  "id" : 26184874108,
  "in_reply_to_status_id" : 26184467557,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Cashmore",
      "screen_name" : "petecashmore",
      "indices" : [ 0, 13 ],
      "id_str" : "10955762",
      "id" : 10955762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26107101733",
  "geo" : { },
  "id_str" : "26192564522",
  "in_reply_to_user_id" : 10955762,
  "text" : "@petecashmore Isn't it fun being at the tip of the \"life gaming\" iceberg, knowing how much more fun it will eventually be?",
  "id" : 26192564522,
  "in_reply_to_status_id" : 26107101733,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "petecashmore",
  "in_reply_to_user_id_str" : "10955762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26195998222",
  "text" : "Curious about paper.li's newsletter idea. Here's what it came up with from my #gamification Twitter list: http:\/\/bit.ly\/9eACbF",
  "id" : 26195998222,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthmonth",
      "indices" : [ 48, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26201810418",
  "text" : "I'm giving up on my clever bottom navigation on #healthmonth and moving it to the top. Can navigation be fun? Should I be shot for asking?",
  "id" : 26201810418,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "threlkelded",
      "indices" : [ 0, 12 ],
      "id_str" : "4979381",
      "id" : 4979381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26202326258",
  "geo" : { },
  "id_str" : "26202647308",
  "in_reply_to_user_id" : 4979381,
  "text" : "@threlkelded Thank you! I liked it too, it just confused some people. I'll try to make it better, while making more people happy. Possible?",
  "id" : 26202647308,
  "in_reply_to_status_id" : 26202326258,
  "created_at" : "2010-10-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "threlkelded",
  "in_reply_to_user_id_str" : "4979381",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]