Grailbird.data.tweets_2011_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.322667 ]
  },
  "id_str" : "75768770806816768",
  "text" : "8:36pm Letting the brain relax after a grueling day in the salt mines http:\/\/flic.kr\/p\/9P9i6T",
  "id" : 75768770806816768,
  "created_at" : "2011-06-01 03:40:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whitney Hess",
      "screen_name" : "whitneyhess",
      "indices" : [ 0, 12 ],
      "id_str" : "11963132",
      "id" : 11963132
    }, {
      "name" : "Tony Bacigalupo",
      "screen_name" : "tonybgoode",
      "indices" : [ 104, 115 ],
      "id_str" : "2852911",
      "id" : 2852911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http:\/\/t.co\/nxcNEkC",
      "expanded_url" : "http:\/\/healthmonth.com\/choose\/rules\/12",
      "display_url" : "healthmonth.com\/choose\/rules\/12"
    } ]
  },
  "in_reply_to_status_id_str" : "75758282593144832",
  "geo" : { },
  "id_str" : "75765953044037632",
  "in_reply_to_user_id" : 11963132,
  "text" : "@whitneyhess Looks like you might have started on the wrong link? Try this one: http:\/\/t.co\/nxcNEkC \/cc @tonybgoode",
  "id" : 75765953044037632,
  "in_reply_to_status_id" : 75758282593144832,
  "created_at" : "2011-06-01 03:29:45 +0000",
  "in_reply_to_screen_name" : "whitneyhess",
  "in_reply_to_user_id_str" : "11963132",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    }, {
      "name" : "micah craig",
      "screen_name" : "micahcraig",
      "indices" : [ 4, 15 ],
      "id_str" : "6462772",
      "id" : 6462772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75605208494899200",
  "geo" : { },
  "id_str" : "75605627409403904",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk @micahcraig Thanks. Now the Bieber and Gaga racks make more sense. :)",
  "id" : 75605627409403904,
  "in_reply_to_status_id" : 75605208494899200,
  "created_at" : "2011-05-31 16:52:40 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah craig",
      "screen_name" : "micahcraig",
      "indices" : [ 0, 11 ],
      "id_str" : "6462772",
      "id" : 6462772
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 118, 121 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75601785892515840",
  "geo" : { },
  "id_str" : "75603155852869632",
  "in_reply_to_user_id" : 6462772,
  "text" : "@micahcraig Oh wow. I was trying to imagine scaling that to people who have millions of followers... seems scary. \/cc @rk",
  "id" : 75603155852869632,
  "in_reply_to_status_id" : 75601785892515840,
  "created_at" : "2011-05-31 16:42:51 +0000",
  "in_reply_to_screen_name" : "micahcraig",
  "in_reply_to_user_id_str" : "6462772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75595912663146496",
  "text" : "Is there a post anywhere that talks about the tech design of how Twitter works? IE loading the stream when you're following 100,000+ people.",
  "id" : 75595912663146496,
  "created_at" : "2011-05-31 16:14:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75434347754299392",
  "geo" : { },
  "id_str" : "75443341952688129",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara Niko learned to dance before he could walk, but is still far being Ripley's skills. Keep us updated!",
  "id" : 75443341952688129,
  "in_reply_to_status_id" : 75434347754299392,
  "created_at" : "2011-05-31 06:07:49 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75409723486244864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050817764, -122.3227717827 ]
  },
  "id_str" : "75433729589387264",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara OMG. Cutest thing ever! Can't wait for a baby dance off.",
  "id" : 75433729589387264,
  "in_reply_to_status_id" : 75409723486244864,
  "created_at" : "2011-05-31 05:29:37 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75408284307292160",
  "text" : "8:36pm Back from a Memorial BBQ where this guy was a walking maniac http:\/\/flic.kr\/p\/9NF1V2",
  "id" : 75408284307292160,
  "created_at" : "2011-05-31 03:48:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarahnovotny",
      "screen_name" : "sarahnovotny",
      "indices" : [ 0, 13 ],
      "id_str" : "11547582",
      "id" : 11547582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75259693953585153",
  "geo" : { },
  "id_str" : "75260105813274624",
  "in_reply_to_user_id" : 11547582,
  "text" : "@sarahnovotny I just finished the game 5 minutes ago too! Though, I was disappointed by the \"reward\".",
  "id" : 75260105813274624,
  "in_reply_to_status_id" : 75259693953585153,
  "created_at" : "2011-05-30 17:59:42 +0000",
  "in_reply_to_screen_name" : "sarahnovotny",
  "in_reply_to_user_id_str" : "11547582",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "indices" : [ 0, 11 ],
      "id_str" : "809641",
      "id" : 809641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75251734758428672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6051401677, -122.3228332769 ]
  },
  "id_str" : "75252074866151424",
  "in_reply_to_user_id" : 809641,
  "text" : "@adamloving I think it applies to all forms of communication. (my extreme way of making a subtle point) :)",
  "id" : 75252074866151424,
  "in_reply_to_status_id" : 75251734758428672,
  "created_at" : "2011-05-30 17:27:47 +0000",
  "in_reply_to_screen_name" : "adamloving",
  "in_reply_to_user_id_str" : "809641",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Gehman",
      "screen_name" : "pugetive",
      "indices" : [ 0, 9 ],
      "id_str" : "16355060",
      "id" : 16355060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http:\/\/t.co\/JdzyYOJ",
      "expanded_url" : "http:\/\/healthmonth.com\/teams\/show\/219",
      "display_url" : "healthmonth.com\/teams\/show\/219"
    } ]
  },
  "in_reply_to_status_id_str" : "74952363064037376",
  "geo" : { },
  "id_str" : "75250591395364864",
  "in_reply_to_user_id" : 16355060,
  "text" : "@pugetive Just 1 rule means no sponsorship needed!  You should join our team though: http:\/\/t.co\/JdzyYOJ",
  "id" : 75250591395364864,
  "in_reply_to_status_id" : 74952363064037376,
  "created_at" : "2011-05-30 17:21:53 +0000",
  "in_reply_to_screen_name" : "pugetive",
  "in_reply_to_user_id_str" : "16355060",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60678178, -122.32288008 ]
  },
  "id_str" : "75243158539214849",
  "text" : "When broadcasting opinions, you can either state an attention-getting extreme, or you can speak subtle reason and that nobody retweets.",
  "id" : 75243158539214849,
  "created_at" : "2011-05-30 16:52:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hagel",
      "screen_name" : "jhagel",
      "indices" : [ 65, 72 ],
      "id_str" : "14076943",
      "id" : 14076943
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 73, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 59 ],
      "url" : "http:\/\/t.co\/ZzBAPtP",
      "expanded_url" : "http:\/\/nyti.ms\/k6mIKj",
      "display_url" : "nyti.ms\/k6mIKj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6051103222, -122.3229871878 ]
  },
  "id_str" : "75218088601206785",
  "text" : "By liking this article, I am hurting it http:\/\/t.co\/ZzBAPtP \/via @jhagel #fb",
  "id" : 75218088601206785,
  "created_at" : "2011-05-30 15:12:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.322667 ]
  },
  "id_str" : "75058065124241408",
  "text" : "8:36pm Was putting Niko to sleep but am now watching the end of Dr Who's season 1 http:\/\/flic.kr\/p\/9NikVs",
  "id" : 75058065124241408,
  "created_at" : "2011-05-30 04:36:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 108, 119 ],
      "id_str" : "14258044",
      "id" : 14258044
    }, {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 120, 132 ],
      "id_str" : "154236895",
      "id" : 154236895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75022231427751936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6128789479, -122.3452655714 ]
  },
  "id_str" : "75025377755533313",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Thank you! Yes, very sad not to be there... definitely the next one! Take good notes for us. \/cc @jensmccabe @healthmonth",
  "id" : 75025377755533313,
  "in_reply_to_status_id" : 75022231427751936,
  "created_at" : "2011-05-30 02:26:58 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloToons",
      "indices" : [ 0, 11 ],
      "id_str" : "1099629326",
      "id" : 1099629326
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 82, 92 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "30daysofyoga",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74739396502491136",
  "geo" : { },
  "id_str" : "74753800736489473",
  "in_reply_to_user_id" : 772386,
  "text" : "@willotoons Thank you, Willo! Means a lot coming from you! I &lt;3 you too! Also, @kellianne is doing #30daysofyoga starting soon!",
  "id" : 74753800736489473,
  "in_reply_to_status_id" : 74739396502491136,
  "created_at" : "2011-05-29 08:27:49 +0000",
  "in_reply_to_screen_name" : "WilloLovesYou",
  "in_reply_to_user_id_str" : "772386",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Newman",
      "screen_name" : "dannynewman",
      "indices" : [ 0, 12 ],
      "id_str" : "8273",
      "id" : 8273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74722936262623232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6151410722, -122.3143883228 ]
  },
  "id_str" : "74730162679328768",
  "in_reply_to_user_id" : 8273,
  "text" : "@dannynewman Hi! I'm gonna be in Wallingford at Gasworks Park late afternoon\/eve. Where will you be stationed??",
  "id" : 74730162679328768,
  "in_reply_to_status_id" : 74722936262623232,
  "created_at" : "2011-05-29 06:53:53 +0000",
  "in_reply_to_screen_name" : "dannynewman",
  "in_reply_to_user_id_str" : "8273",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 82, 92 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6151230411, -122.3146499278 ]
  },
  "id_str" : "74720372158758913",
  "text" : "I just received an amazing, sweet, and awe-inspiring present from my lovely wife, @Kellianne.",
  "id" : 74720372158758913,
  "created_at" : "2011-05-29 06:14:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614666, -122.328167 ]
  },
  "id_str" : "74682220840878080",
  "text" : "8:36pm Lots of good people in the same place! http:\/\/flic.kr\/p\/9MSdRP",
  "id" : 74682220840878080,
  "created_at" : "2011-05-29 03:43:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 39, 49 ],
      "id_str" : "1771141",
      "id" : 1771141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6143423, -122.3281509 ]
  },
  "id_str" : "74654094006026240",
  "text" : "Happy birthday, me! (@ Still Liquor w\/ @samantham) http:\/\/4sq.com\/j6Dv64",
  "id" : 74654094006026240,
  "created_at" : "2011-05-29 01:51:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 101, 111 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74619709001175040",
  "geo" : { },
  "id_str" : "74620104234647552",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler Haha, no theme. I made a flash mob joke and they always make me think of pajamas. :) \/cc @kellianne",
  "id" : 74620104234647552,
  "in_reply_to_status_id" : 74619709001175040,
  "created_at" : "2011-05-28 23:36:33 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 0, 11 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74585068315738112",
  "in_reply_to_user_id" : 14120151,
  "text" : "@foursquare API feature request. I send you an authenticated lat\/long, you send me the best guess for where that person is.",
  "id" : 74585068315738112,
  "created_at" : "2011-05-28 21:17:20 +0000",
  "in_reply_to_screen_name" : "foursquare",
  "in_reply_to_user_id_str" : "14120151",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Maberly",
      "screen_name" : "CMaberly",
      "indices" : [ 0, 9 ],
      "id_str" : "128375612",
      "id" : 128375612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74578264496160768",
  "geo" : { },
  "id_str" : "74578868031336448",
  "in_reply_to_user_id" : 128375612,
  "text" : "@CMaberly Awesome! Can you keep one spider in your hair, though? The best one?",
  "id" : 74578868031336448,
  "in_reply_to_status_id" : 74578264496160768,
  "created_at" : "2011-05-28 20:52:42 +0000",
  "in_reply_to_screen_name" : "CMaberly",
  "in_reply_to_user_id_str" : "128375612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hello World",
      "screen_name" : "helloworldim",
      "indices" : [ 0, 13 ],
      "id_str" : "257831711",
      "id" : 257831711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74553624986009600",
  "geo" : { },
  "id_str" : "74554918408683520",
  "in_reply_to_user_id" : 257831711,
  "text" : "@helloworldim Sure! Can you email me some questions? My twitter username at gmail.",
  "id" : 74554918408683520,
  "in_reply_to_status_id" : 74553624986009600,
  "created_at" : "2011-05-28 19:17:32 +0000",
  "in_reply_to_screen_name" : "helloworldim",
  "in_reply_to_user_id_str" : "257831711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hello World",
      "screen_name" : "helloworldim",
      "indices" : [ 0, 13 ],
      "id_str" : "257831711",
      "id" : 257831711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74552614280380417",
  "geo" : { },
  "id_str" : "74552885983191040",
  "in_reply_to_user_id" : 257831711,
  "text" : "@helloworldim Hi! On the 500founders mailing list. :)",
  "id" : 74552885983191040,
  "in_reply_to_status_id" : 74552614280380417,
  "created_at" : "2011-05-28 19:09:27 +0000",
  "in_reply_to_screen_name" : "helloworldim",
  "in_reply_to_user_id_str" : "257831711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74545610019184640",
  "text" : "Seattle friends! My birthday party flash mob is at Still Liquor from 6:30-9 tonight! Bring pillows and zombie pjs. Or a hi-5!",
  "id" : 74545610019184640,
  "created_at" : "2011-05-28 18:40:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rands",
      "screen_name" : "rands",
      "indices" : [ 0, 6 ],
      "id_str" : "30923",
      "id" : 30923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74532946643656704",
  "geo" : { },
  "id_str" : "74533835605426176",
  "in_reply_to_user_id" : 30923,
  "text" : "@rands In the presence of information as well.",
  "id" : 74533835605426176,
  "in_reply_to_status_id" : 74532946643656704,
  "created_at" : "2011-05-28 17:53:45 +0000",
  "in_reply_to_screen_name" : "rands",
  "in_reply_to_user_id_str" : "30923",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "quantifiedself",
      "screen_name" : "quantifiedself",
      "indices" : [ 19, 34 ],
      "id_str" : "35056570",
      "id" : 35056570
    }, {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 63, 72 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "Alex Carmichael",
      "screen_name" : "accarmichael",
      "indices" : [ 74, 87 ],
      "id_str" : "15916492",
      "id" : 15916492
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "qs2011",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6051295761, -122.3225146665 ]
  },
  "id_str" : "74513060525649920",
  "text" : "Wish I could be at @QuantifiedSelf's 1st conference! Great job @agaricus, @accarmichael, and team! Anyone there, please tweet often! #qs2011",
  "id" : 74513060525649920,
  "created_at" : "2011-05-28 16:31:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birthdaypost",
      "indices" : [ 61, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 60 ],
      "url" : "http:\/\/t.co\/HvzQp7W",
      "expanded_url" : "http:\/\/bustr.tumblr.com\/post\/5929491429\/on-being-35",
      "display_url" : "bustr.tumblr.com\/post\/592949142\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60499869, -122.3227843368 ]
  },
  "id_str" : "74495708308307968",
  "text" : "On being 35. Plus, what i want from you. http:\/\/t.co\/HvzQp7W #birthdaypost",
  "id" : 74495708308307968,
  "created_at" : "2011-05-28 15:22:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.3225 ]
  },
  "id_str" : "74319215825395713",
  "text" : "8:36pm Thinking about turning 35 tomorrow. Should I do it? Or is it overrated? http:\/\/flic.kr\/p\/9Mz1v4",
  "id" : 74319215825395713,
  "created_at" : "2011-05-28 03:40:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Veen",
      "screen_name" : "veen",
      "indices" : [ 3, 8 ],
      "id_str" : "414",
      "id" : 414
    }, {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "indices" : [ 85, 97 ],
      "id_str" : "1532061",
      "id" : 1532061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74314963308642304",
  "text" : "RT @veen: \"Every new technology nibbles at what we believe it means to be human.\" \n\u2014 @kevin2kelly",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Kelly",
        "screen_name" : "kevin2kelly",
        "indices" : [ 75, 87 ],
        "id_str" : "1532061",
        "id" : 1532061
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74152201001500675",
    "text" : "\"Every new technology nibbles at what we believe it means to be human.\" \n\u2014 @kevin2kelly",
    "id" : 74152201001500675,
    "created_at" : "2011-05-27 16:37:17 +0000",
    "user" : {
      "name" : "Jeffrey Veen",
      "screen_name" : "veen",
      "protected" : false,
      "id_str" : "414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458690391462531072\/_uAVbURp_normal.jpeg",
      "id" : 414,
      "verified" : false
    }
  },
  "id" : 74314963308642304,
  "created_at" : "2011-05-28 03:24:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen",
      "screen_name" : "ellenthatcher",
      "indices" : [ 0, 14 ],
      "id_str" : "18999752",
      "id" : 18999752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74314480812691456",
  "geo" : { },
  "id_str" : "74314901002256385",
  "in_reply_to_user_id" : 18999752,
  "text" : "@ellenthatcher There's no spam or unwanted email, but depending on busyness I can delete a lot of it when I'm too busy.",
  "id" : 74314901002256385,
  "in_reply_to_status_id" : 74314480812691456,
  "created_at" : "2011-05-28 03:23:47 +0000",
  "in_reply_to_screen_name" : "ellenthatcher",
  "in_reply_to_user_id_str" : "18999752",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen",
      "screen_name" : "ellenthatcher",
      "indices" : [ 0, 14 ],
      "id_str" : "18999752",
      "id" : 18999752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74276656054939650",
  "geo" : { },
  "id_str" : "74303557150576640",
  "in_reply_to_user_id" : 18999752,
  "text" : "@ellenthatcher According to my stats on busterbenson.com, the last month or so I've received ~218 emails\/day and sent ~17\/day.",
  "id" : 74303557150576640,
  "in_reply_to_status_id" : 74276656054939650,
  "created_at" : "2011-05-28 02:38:43 +0000",
  "in_reply_to_screen_name" : "ellenthatcher",
  "in_reply_to_user_id_str" : "18999752",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74163085249748992",
  "geo" : { },
  "id_str" : "74167037269774336",
  "in_reply_to_user_id" : 223715334,
  "text" : "@singlyinc I haven't yet, but plan to soon!  Wish I could see some screenshots of it prior to installation though... are they somewhere?",
  "id" : 74167037269774336,
  "in_reply_to_status_id" : 74163085249748992,
  "created_at" : "2011-05-27 17:36:14 +0000",
  "in_reply_to_screen_name" : "singly",
  "in_reply_to_user_id_str" : "223715334",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Porad",
      "screen_name" : "scottporad",
      "indices" : [ 95, 106 ],
      "id_str" : "15876737",
      "id" : 15876737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 90 ],
      "url" : "http:\/\/t.co\/L2IiFxc",
      "expanded_url" : "http:\/\/www.scottporad.com\/2011\/05\/24\/how-to-handle-email-overload\/",
      "display_url" : "scottporad.com\/2011\/05\/24\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "74161609223839744",
  "text" : "Cool system for filtering and processing email if you get way too much http:\/\/t.co\/L2IiFxc \/by @scottporad",
  "id" : 74161609223839744,
  "created_at" : "2011-05-27 17:14:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 95 ],
      "url" : "http:\/\/t.co\/6SF7sCh",
      "expanded_url" : "http:\/\/singly.com",
      "display_url" : "singly.com"
    }, {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/ZMhrRIT",
      "expanded_url" : "http:\/\/blog.singly.com\/why-were-excited",
      "display_url" : "blog.singly.com\/why-were-excit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "74157335915921408",
  "text" : "That homepage is slick! Congrats! RT @singlyinc: Check out our new website (http:\/\/t.co\/6SF7sCh) and our 1st blog post (http:\/\/t.co\/ZMhrRIT)",
  "id" : 74157335915921408,
  "created_at" : "2011-05-27 16:57:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Talks",
      "screen_name" : "TedTalk",
      "indices" : [ 13, 21 ],
      "id_str" : "65645543",
      "id" : 65645543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 72 ],
      "url" : "http:\/\/t.co\/BOsMdHJ",
      "expanded_url" : "http:\/\/www.ted.com\/talks\/sean_carroll_distant_time_and_the_hint_of_a_multiverse.html",
      "display_url" : "ted.com\/talks\/sean_car\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "74147465678422016",
  "text" : "I loved this @tedtalk about the possible multiverse: http:\/\/t.co\/BOsMdHJ",
  "id" : 74147465678422016,
  "created_at" : "2011-05-27 16:18:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.613833, -122.316667 ]
  },
  "id_str" : "73957228419366912",
  "text" : "8:36pm Keeping this hungry beast out past his bedtime http:\/\/flic.kr\/p\/9MkKFo",
  "id" : 73957228419366912,
  "created_at" : "2011-05-27 03:42:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73852966628622336",
  "geo" : { },
  "id_str" : "73869531914846208",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne You should start a line called mamalegs.",
  "id" : 73869531914846208,
  "in_reply_to_status_id" : 73852966628622336,
  "created_at" : "2011-05-26 21:54:03 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThinkUp App",
      "screen_name" : "thinkupapp",
      "indices" : [ 0, 11 ],
      "id_str" : "625101655",
      "id" : 625101655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73867744503808000",
  "geo" : { },
  "id_str" : "73868577169612800",
  "in_reply_to_user_id" : 100127476,
  "text" : "@thinkupapp That's rad. I want one.",
  "id" : 73868577169612800,
  "in_reply_to_status_id" : 73867744503808000,
  "created_at" : "2011-05-26 21:50:15 +0000",
  "in_reply_to_screen_name" : "thinkup",
  "in_reply_to_user_id_str" : "100127476",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    }, {
      "name" : "Coley Cheng",
      "screen_name" : "c",
      "indices" : [ 11, 13 ],
      "id_str" : "632173",
      "id" : 632173
    }, {
      "name" : "PUBLIC Bikes",
      "screen_name" : "PUBLICBikes",
      "indices" : [ 92, 104 ],
      "id_str" : "30035888",
      "id" : 30035888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73862279589937153",
  "geo" : { },
  "id_str" : "73864064891240448",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne @c Woah those bikes are rad! Can there be a Seattle wing to this bike posse? \/cc @publicbikes",
  "id" : 73864064891240448,
  "in_reply_to_status_id" : 73862279589937153,
  "created_at" : "2011-05-26 21:32:20 +0000",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Insta Gazette",
      "screen_name" : "InstaGazette",
      "indices" : [ 3, 16 ],
      "id_str" : "303332383",
      "id" : 303332383
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 70, 79 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73811261309190144",
  "text" : "RT @InstaGazette: Good morning! Today's theme is 8:36 PM, inspired by @rickwebb who has been taking a photo at 8:36 every day for years. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rick Webb",
        "screen_name" : "RickWebb",
        "indices" : [ 52, 61 ],
        "id_str" : "761628",
        "id" : 761628
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73750441162313728",
    "text" : "Good morning! Today's theme is 8:36 PM, inspired by @rickwebb who has been taking a photo at 8:36 every day for years. http:\/\/ow.ly\/53gjA",
    "id" : 73750441162313728,
    "created_at" : "2011-05-26 14:00:50 +0000",
    "user" : {
      "name" : "Insta Gazette",
      "screen_name" : "InstaGazette",
      "protected" : false,
      "id_str" : "303332383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1365402423\/instagazetteicon_normal.jpg",
      "id" : 303332383,
      "verified" : false
    }
  },
  "id" : 73811261309190144,
  "created_at" : "2011-05-26 18:02:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.322667 ]
  },
  "id_str" : "73605113696104448",
  "text" : "8:36pm Was in a business meeting, now taking off my shoes http:\/\/flic.kr\/p\/9M4Q2s",
  "id" : 73605113696104448,
  "created_at" : "2011-05-26 04:23:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73456235168542720",
  "text" : "Sasquatch attenders! I have 4 spots in an awesome cabin to sell and am willing to do it for 50% or less what I paid... any interest? Pls RT!",
  "id" : 73456235168542720,
  "created_at" : "2011-05-25 18:31:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susannah Fox",
      "screen_name" : "SusannahFox",
      "indices" : [ 128, 140 ],
      "id_str" : "17843236",
      "id" : 17843236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http:\/\/t.co\/5sRTedh",
      "expanded_url" : "http:\/\/www.kk.org\/thetechnium\/archives\/2011\/04\/natural_history.php",
      "display_url" : "kk.org\/thetechnium\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "73449178914754561",
  "text" : "Natural history of a new idea: Wacko, Unproven, Unimportant, Obvious. Or Crazy, Crazy, Crazy, Obvious.\nhttp:\/\/t.co\/5sRTedh\n\/via @susannahfox",
  "id" : 73449178914754561,
  "created_at" : "2011-05-25 18:03:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73252110405353472",
  "geo" : { },
  "id_str" : "73272338522714112",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim His legs are getting slimmer by the day, if you can imagine!\n\nAre you available for Skyping on a Fri or Mon in next couple weeks?",
  "id" : 73272338522714112,
  "in_reply_to_status_id" : 73252110405353472,
  "created_at" : "2011-05-25 06:21:01 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 0, 14 ],
      "id_str" : "820661",
      "id" : 820661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73265956926922753",
  "geo" : { },
  "id_str" : "73271181582667776",
  "in_reply_to_user_id" : 820661,
  "text" : "@daveschappell I love that book! Also, I didn't know you could tweet from Kindle. That's awesome! Does that work Kindle-only or iPhone too?",
  "id" : 73271181582667776,
  "in_reply_to_status_id" : 73265956926922753,
  "created_at" : "2011-05-25 06:16:25 +0000",
  "in_reply_to_screen_name" : "daveschappell",
  "in_reply_to_user_id_str" : "820661",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73247231305728000",
  "text" : "8:36pm He can't walk but he loves to fall http:\/\/flic.kr\/p\/9LHCrZ",
  "id" : 73247231305728000,
  "created_at" : "2011-05-25 04:41:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.fitbit.com\" rel=\"nofollow\"\u003EFitbit\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fitstats",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73162409199677440",
  "text" : "My avg. daily fitbit #fitstats for last week: 5,046 steps and 3.1 miles traveled. http:\/\/www.fitbit.com\/user\/229KX2",
  "id" : 73162409199677440,
  "created_at" : "2011-05-24 23:04:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meredith Modzelewski",
      "screen_name" : "meredithmo",
      "indices" : [ 0, 11 ],
      "id_str" : "17069950",
      "id" : 17069950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73143910460956672",
  "geo" : { },
  "id_str" : "73144595160121344",
  "in_reply_to_user_id" : 17069950,
  "text" : "@meredithmo Oops, yeah, sorry!  Weird!  Hi, Meredith!  :)",
  "id" : 73144595160121344,
  "in_reply_to_status_id" : 73143910460956672,
  "created_at" : "2011-05-24 21:53:25 +0000",
  "in_reply_to_screen_name" : "meredithmo",
  "in_reply_to_user_id_str" : "17069950",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jeremyet",
      "screen_name" : "jeremyet",
      "indices" : [ 3, 12 ],
      "id_str" : "799198",
      "id" : 799198
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 14, 27 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73140005341642752",
  "text" : "RT @jeremyet: @busterbenson All very good questions. I'm finding that producing memorizing devices (Kids) helps with automated backups.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "73135488902496256",
    "geo" : { },
    "id_str" : "73139520085823489",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson All very good questions. I'm finding that producing memorizing devices (Kids) helps with automated backups.",
    "id" : 73139520085823489,
    "in_reply_to_status_id" : 73135488902496256,
    "created_at" : "2011-05-24 21:33:15 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "jeremyet",
      "screen_name" : "jeremyet",
      "protected" : false,
      "id_str" : "799198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2466313693\/image_normal.jpg",
      "id" : 799198,
      "verified" : false
    }
  },
  "id" : 73140005341642752,
  "created_at" : "2011-05-24 21:35:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Longtine",
      "screen_name" : "jlongtine",
      "indices" : [ 0, 10 ],
      "id_str" : "722793",
      "id" : 722793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73138913467830272",
  "geo" : { },
  "id_str" : "73139089372741633",
  "in_reply_to_user_id" : 722793,
  "text" : "@jlongtine Yes but what if we just remembered everything we *wanted* to remember? Like a hard drive with a good trash can.",
  "id" : 73139089372741633,
  "in_reply_to_status_id" : 73138913467830272,
  "created_at" : "2011-05-24 21:31:32 +0000",
  "in_reply_to_screen_name" : "jlongtine",
  "in_reply_to_user_id_str" : "722793",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcelo Calbucci",
      "screen_name" : "calbucci",
      "indices" : [ 130, 139 ],
      "id_str" : "14232711",
      "id" : 14232711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 93 ],
      "url" : "http:\/\/t.co\/G9bQvnR",
      "expanded_url" : "http:\/\/busterbenson.com\/entries?date=2001-05-24",
      "display_url" : "busterbenson.com\/entries?date=2\u2026"
    }, {
      "indices" : [ 105, 124 ],
      "url" : "http:\/\/t.co\/G9bQvnR",
      "expanded_url" : "http:\/\/busterbenson.com\/entries?date=2001-05-24",
      "display_url" : "busterbenson.com\/entries?date=2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "73135861755154432",
  "geo" : { },
  "id_str" : "73137754040569856",
  "in_reply_to_user_id" : 14232711,
  "text" : "I remember almost nothing, but my blog remembers a little: \n\n5 years ago: http:\/\/t.co\/G9bQvnR\n\n10 years: http:\/\/t.co\/G9bQvnR\n\n\/cc @calbucci",
  "id" : 73137754040569856,
  "in_reply_to_status_id" : 73135861755154432,
  "created_at" : "2011-05-24 21:26:14 +0000",
  "in_reply_to_screen_name" : "calbucci",
  "in_reply_to_user_id_str" : "14232711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73135488902496256",
  "text" : "How much of today will you remember 20 years from now? How much of this year? This decade? Why does memory suck?",
  "id" : 73135488902496256,
  "created_at" : "2011-05-24 21:17:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 81 ],
      "url" : "http:\/\/t.co\/XnZIDFn",
      "expanded_url" : "http:\/\/www.geekwire.com\/2011\/buster-benson-sells-locavore-mobile-app-local-dirt",
      "display_url" : "geekwire.com\/2011\/buster-be\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "73089435503296512",
  "text" : "Did I ever tell you that I sold my iPhone app, Locavore? Yup! http:\/\/t.co\/XnZIDFn",
  "id" : 73089435503296512,
  "created_at" : "2011-05-24 18:14:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arielis Talavera",
      "screen_name" : "ArielisT",
      "indices" : [ 0, 9 ],
      "id_str" : "1163522401",
      "id" : 1163522401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73087196042760192",
  "text" : "@arielist It's my guilty pleasure during my Niko days. I'm still on Season 1 but now I have something to look forward too!",
  "id" : 73087196042760192,
  "created_at" : "2011-05-24 18:05:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 26, 36 ],
      "id_str" : "180505807",
      "id" : 180505807
    }, {
      "name" : "The Barbarian Group",
      "screen_name" : "barbariangroup",
      "indices" : [ 42, 57 ],
      "id_str" : "17781506",
      "id" : 17781506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/ExShG0e",
      "expanded_url" : "http:\/\/www.barbariangroup.com\/software\/screenstagram",
      "display_url" : "barbariangroup.com\/software\/scree\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "73064476378791936",
  "text" : "If you have a Mac and use @instagram, the @barbariangroup has just made you the coolest screensaver ever: http:\/\/t.co\/ExShG0e",
  "id" : 73064476378791936,
  "created_at" : "2011-05-24 16:35:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "MarshallHaas",
      "indices" : [ 0, 13 ],
      "id_str" : "1268491417",
      "id" : 1268491417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72887133525917696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6070720429, -122.3207769614 ]
  },
  "id_str" : "72887350677610496",
  "in_reply_to_user_id" : 19028099,
  "text" : "@MarshallHaas Win-win the way I see it! :) Congrats on 9-months, too!",
  "id" : 72887350677610496,
  "in_reply_to_status_id" : 72887133525917696,
  "created_at" : "2011-05-24 04:51:13 +0000",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "MarshallHaas",
      "indices" : [ 0, 13 ],
      "id_str" : "1268491417",
      "id" : 1268491417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72886506590707712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6070720429, -122.3207769614 ]
  },
  "id_str" : "72886864285155328",
  "in_reply_to_user_id" : 19028099,
  "text" : "@MarshallHaas I've missed a few days too. It happens!",
  "id" : 72886864285155328,
  "in_reply_to_status_id" : 72886506590707712,
  "created_at" : "2011-05-24 04:49:17 +0000",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.3225 ]
  },
  "id_str" : "72869848044146688",
  "text" : "8:36pm Tired. I feel like this potted plant that Niko yanked out earlier today. Just want to watch Dr Who. http:\/\/flic.kr\/p\/9LocfR",
  "id" : 72869848044146688,
  "created_at" : "2011-05-24 03:41:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    }, {
      "name" : "Rand Fishkin",
      "screen_name" : "randfish",
      "indices" : [ 86, 95 ],
      "id_str" : "6527972",
      "id" : 6527972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72806995102679041",
  "geo" : { },
  "id_str" : "72807316109533185",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright My wordpress blogs have been hacked many a time over. Not safer there. \/cc @randfish",
  "id" : 72807316109533185,
  "in_reply_to_status_id" : 72806995102679041,
  "created_at" : "2011-05-23 23:33:11 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 51 ],
      "url" : "http:\/\/t.co\/3h9qeHY",
      "expanded_url" : "http:\/\/billguard.com\/secure.html",
      "display_url" : "billguard.com\/secure.html"
    } ]
  },
  "in_reply_to_status_id_str" : "72796200977440768",
  "geo" : { },
  "id_str" : "72796717107519488",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler I don't think so... http:\/\/t.co\/3h9qeHY seems to address that stuff. But I also use mint.com etc.",
  "id" : 72796717107519488,
  "in_reply_to_status_id" : 72796200977440768,
  "created_at" : "2011-05-23 22:51:04 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 25 ],
      "url" : "http:\/\/t.co\/PYfjj1O",
      "expanded_url" : "http:\/\/billguard.com",
      "display_url" : "billguard.com"
    }, {
      "indices" : [ 116, 135 ],
      "url" : "http:\/\/t.co\/KctWrAN",
      "expanded_url" : "http:\/\/techcrunch.com\/2011\/05\/23\/billguard-will-track-hidden-fees-and-billing-errors-on-credit-card-bills\/",
      "display_url" : "techcrunch.com\/2011\/05\/23\/bil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "72792985108086786",
  "text" : "Okay, http:\/\/t.co\/PYfjj1O is ridiculously awesome for lazy bill statement reviewers like myself. Finds bad charges: http:\/\/t.co\/KctWrAN",
  "id" : 72792985108086786,
  "created_at" : "2011-05-23 22:36:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 0, 12 ],
      "id_str" : "930061",
      "id" : 930061
    }, {
      "name" : "coderwall",
      "screen_name" : "coderwall",
      "indices" : [ 50, 60 ],
      "id_str" : "296019552",
      "id" : 296019552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 45 ],
      "url" : "http:\/\/t.co\/Ik7dmqO",
      "expanded_url" : "http:\/\/coderwall.com\/busterbenson",
      "display_url" : "coderwall.com\/busterbenson"
    } ]
  },
  "in_reply_to_status_id_str" : "72724506535411712",
  "geo" : { },
  "id_str" : "72725487104966656",
  "in_reply_to_user_id" : 930061,
  "text" : "@ginatrapani Ooh, me too! http:\/\/t.co\/Ik7dmqO \/cc @coderwall",
  "id" : 72725487104966656,
  "in_reply_to_status_id" : 72724506535411712,
  "created_at" : "2011-05-23 18:08:01 +0000",
  "in_reply_to_screen_name" : "ginatrapani",
  "in_reply_to_user_id_str" : "930061",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Dorsey",
      "screen_name" : "jack",
      "indices" : [ 0, 5 ],
      "id_str" : "12",
      "id" : 12
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72714741965008896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60505845, -122.322809774 ]
  },
  "id_str" : "72715458008186880",
  "in_reply_to_user_id" : 12,
  "text" : "@jack Super impressed by the new features and the pitch. Well done!",
  "id" : 72715458008186880,
  "in_reply_to_status_id" : 72714741965008896,
  "created_at" : "2011-05-23 17:28:10 +0000",
  "in_reply_to_screen_name" : "jack",
  "in_reply_to_user_id_str" : "12",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Dorsey",
      "screen_name" : "jack",
      "indices" : [ 14, 19 ],
      "id_str" : "12",
      "id" : 12
    }, {
      "name" : "Square",
      "screen_name" : "Square",
      "indices" : [ 31, 38 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 73 ],
      "url" : "http:\/\/t.co\/Grfsr86",
      "expanded_url" : "http:\/\/techcrunch.com\/2011\/05\/23\/squares-disruptive-new-ipad-payments-service-will-replace-cash-registers\/",
      "display_url" : "techcrunch.com\/2011\/05\/23\/squ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "72713789631500288",
  "text" : "Mind blown by @jack's pitch of @square's new features http:\/\/t.co\/Grfsr86 (makes me almost wish I still had a bar!)",
  "id" : 72713789631500288,
  "created_at" : "2011-05-23 17:21:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blogsaredead",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/Ql1vqNM",
      "expanded_url" : "http:\/\/bustr.tumblr.com",
      "display_url" : "bustr.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "72708125244932097",
  "text" : "PS. Consolidating my personal blogging onto Tumblr as it seems to be the liveliest platform at the moment: http:\/\/t.co\/Ql1vqNM #blogsaredead",
  "id" : 72708125244932097,
  "created_at" : "2011-05-23 16:59:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh MacLeod",
      "screen_name" : "gapingvoid",
      "indices" : [ 51, 62 ],
      "id_str" : "50193",
      "id" : 50193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 46 ],
      "url" : "http:\/\/t.co\/RIFWQ9B",
      "expanded_url" : "http:\/\/bustr.tumblr.com\/post\/5749324201\/thoughts-on-social-objects",
      "display_url" : "bustr.tumblr.com\/post\/574932420\u2026"
    }, {
      "indices" : [ 76, 95 ],
      "url" : "http:\/\/t.co\/m5o42yQ",
      "expanded_url" : "http:\/\/gapingvoid.com\/so\/",
      "display_url" : "gapingvoid.com\/so\/"
    } ]
  },
  "geo" : { },
  "id_str" : "72707214355333120",
  "text" : "Thoughts on social objects http:\/\/t.co\/RIFWQ9B re: @gapingvoid's great post http:\/\/t.co\/m5o42yQ",
  "id" : 72707214355333120,
  "created_at" : "2011-05-23 16:55:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon MP3",
      "screen_name" : "amazonmp3",
      "indices" : [ 37, 47 ],
      "id_str" : "14740219",
      "id" : 14740219
    }, {
      "name" : "Lady Gaga",
      "screen_name" : "ladygaga",
      "indices" : [ 74, 83 ],
      "id_str" : "14230524",
      "id" : 14230524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/EjC1jIi",
      "expanded_url" : "http:\/\/amzn.to\/mnhVEs",
      "display_url" : "amzn.to\/mnhVEs"
    } ]
  },
  "geo" : { },
  "id_str" : "72543895401152512",
  "text" : "Okay, yeah, I bought it. So what? RT @amazonmp3: Get the entire brand-new @ladygaga album for just $0.99! http:\/\/t.co\/EjC1jIi",
  "id" : 72543895401152512,
  "created_at" : "2011-05-23 06:06:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benny Wong",
      "screen_name" : "bdotdub",
      "indices" : [ 0, 8 ],
      "id_str" : "3032241",
      "id" : 3032241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72538076152463360",
  "geo" : { },
  "id_str" : "72538279794327552",
  "in_reply_to_user_id" : 3032241,
  "text" : "@bdotdub Uh oh. For what?",
  "id" : 72538279794327552,
  "in_reply_to_status_id" : 72538076152463360,
  "created_at" : "2011-05-23 05:44:08 +0000",
  "in_reply_to_screen_name" : "bdotdub",
  "in_reply_to_user_id_str" : "3032241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/timely.is\" rel=\"nofollow\"\u003ETimely by Demandforce\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72537028922839040",
  "text" : "Enjoymentland update! http:\/\/bit.ly\/loM483",
  "id" : 72537028922839040,
  "created_at" : "2011-05-23 05:39:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 0, 6 ],
      "id_str" : "5469512",
      "id" : 5469512
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 116, 125 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72434597341827072",
  "geo" : { },
  "id_str" : "72440294083276800",
  "in_reply_to_user_id" : 5469512,
  "text" : "@micah Not a whole lot anymore, but I do have a birthday coming up. And my preferred meeting spots are bars. :) \/cc @arainert",
  "id" : 72440294083276800,
  "in_reply_to_status_id" : 72434597341827072,
  "created_at" : "2011-05-22 23:14:46 +0000",
  "in_reply_to_screen_name" : "micah",
  "in_reply_to_user_id_str" : "5469512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Neilson",
      "screen_name" : "tylerneilson",
      "indices" : [ 0, 13 ],
      "id_str" : "21419053",
      "id" : 21419053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72432020885737472",
  "geo" : { },
  "id_str" : "72432760383475713",
  "in_reply_to_user_id" : 21419053,
  "text" : "@tylerneilson Awesome! My son's a week older than your daughter... our year has been great but not easy!",
  "id" : 72432760383475713,
  "in_reply_to_status_id" : 72432020885737472,
  "created_at" : "2011-05-22 22:44:50 +0000",
  "in_reply_to_screen_name" : "tylerneilson",
  "in_reply_to_user_id_str" : "21419053",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 68, 84 ],
      "id_str" : "246531241",
      "id" : 246531241
    }, {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 85, 98 ],
      "id_str" : "26166039",
      "id" : 26166039
    }, {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 99, 110 ],
      "id_str" : "14620776",
      "id" : 14620776
    }, {
      "name" : "Todd Gehman",
      "screen_name" : "pugetive",
      "indices" : [ 111, 120 ],
      "id_str" : "16355060",
      "id" : 16355060
    }, {
      "name" : "Aubrey Sabala",
      "screen_name" : "Aubs",
      "indices" : [ 121, 126 ],
      "id_str" : "2781",
      "id" : 2781
    }, {
      "name" : "Marc Quinn",
      "screen_name" : "quantafire",
      "indices" : [ 127, 138 ],
      "id_str" : "8449382",
      "id" : 8449382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthmonth",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71744306561548288",
  "geo" : { },
  "id_str" : "72430075064238080",
  "in_reply_to_user_id" : 246531241,
  "text" : "Anyone trying no alcohol in June? I'll sponsor on #healthmonth. \/cc @ameliagreenhall @MeganWelling @ellenchisa @pugetive @Aubs @quantafire",
  "id" : 72430075064238080,
  "in_reply_to_status_id" : 71744306561548288,
  "created_at" : "2011-05-22 22:34:10 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalya Pemberton",
      "screen_name" : "talof2cities",
      "indices" : [ 0, 13 ],
      "id_str" : "62600226",
      "id" : 62600226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71684481592991744",
  "geo" : { },
  "id_str" : "72429393947017216",
  "in_reply_to_user_id" : 62600226,
  "text" : "@talof2cities Not brave, I just respond to extremes, especially if there's some social challenge component to it. :)",
  "id" : 72429393947017216,
  "in_reply_to_status_id" : 71684481592991744,
  "created_at" : "2011-05-22 22:31:27 +0000",
  "in_reply_to_screen_name" : "talof2cities",
  "in_reply_to_user_id_str" : "62600226",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71685806351319040",
  "geo" : { },
  "id_str" : "72429077423853568",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert To lose some weight without having to exercise more. :)",
  "id" : 72429077423853568,
  "in_reply_to_status_id" : 71685806351319040,
  "created_at" : "2011-05-22 22:30:12 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Mansilla",
      "screen_name" : "mansillaDEV",
      "indices" : [ 0, 12 ],
      "id_str" : "17541722",
      "id" : 17541722
    }, {
      "name" : "hunch",
      "screen_name" : "hunch",
      "indices" : [ 52, 58 ],
      "id_str" : "18715444",
      "id" : 18715444
    }, {
      "name" : "Chris Dixon",
      "screen_name" : "cdixon",
      "indices" : [ 99, 106 ],
      "id_str" : "2529971",
      "id" : 2529971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72398112500621312",
  "geo" : { },
  "id_str" : "72428822632476672",
  "in_reply_to_user_id" : 17541722,
  "text" : "@mansillaDEV That's really cool. Are you displaying @hunch recommendations or something else? \/ cc @cdixon",
  "id" : 72428822632476672,
  "in_reply_to_status_id" : 72398112500621312,
  "created_at" : "2011-05-22 22:29:11 +0000",
  "in_reply_to_screen_name" : "mansillaDEV",
  "in_reply_to_user_id_str" : "17541722",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harscoat",
      "screen_name" : "harscoat",
      "indices" : [ 0, 9 ],
      "id_str" : "18143096",
      "id" : 18143096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72404545191424000",
  "geo" : { },
  "id_str" : "72428471330156544",
  "in_reply_to_user_id" : 18143096,
  "text" : "@harscoat I had to look Swift birds up but they do look quite pretty. Do they fly in flocks or alone?",
  "id" : 72428471330156544,
  "in_reply_to_status_id" : 72404545191424000,
  "created_at" : "2011-05-22 22:27:47 +0000",
  "in_reply_to_screen_name" : "harscoat",
  "in_reply_to_user_id_str" : "18143096",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moon Nock Needle",
      "screen_name" : "googlephonics",
      "indices" : [ 0, 14 ],
      "id_str" : "580219978",
      "id" : 580219978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72406046609645568",
  "geo" : { },
  "id_str" : "72428298680012801",
  "in_reply_to_user_id" : 75925590,
  "text" : "@googlephonics That's awesome! Congrats!",
  "id" : 72428298680012801,
  "in_reply_to_status_id" : 72406046609645568,
  "created_at" : "2011-05-22 22:27:06 +0000",
  "in_reply_to_screen_name" : "betoruizalonso",
  "in_reply_to_user_id_str" : "75925590",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Culver",
      "screen_name" : "bahoo",
      "indices" : [ 0, 6 ],
      "id_str" : "13134132",
      "id" : 13134132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72406278634340352",
  "geo" : { },
  "id_str" : "72428223786516480",
  "in_reply_to_user_id" : 13134132,
  "text" : "@bahoo Yeah, I can't remember the days when weird was an insult. But I did get a weird look from a 14yo who thought it was a bad thing.",
  "id" : 72428223786516480,
  "in_reply_to_status_id" : 72406278634340352,
  "created_at" : "2011-05-22 22:26:48 +0000",
  "in_reply_to_screen_name" : "bahoo",
  "in_reply_to_user_id_str" : "13134132",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "powkang",
      "screen_name" : "powkang",
      "indices" : [ 0, 8 ],
      "id_str" : "16952268",
      "id" : 16952268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72406532033228800",
  "geo" : { },
  "id_str" : "72428041955053568",
  "in_reply_to_user_id" : 16952268,
  "text" : "@powkang You'll do great! Congrats.",
  "id" : 72428041955053568,
  "in_reply_to_status_id" : 72406532033228800,
  "created_at" : "2011-05-22 22:26:05 +0000",
  "in_reply_to_screen_name" : "powkang",
  "in_reply_to_user_id_str" : "16952268",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72403817743908865",
  "text" : "What is the best\/coolest\/most meaningful thing you have to share right now?",
  "id" : 72403817743908865,
  "created_at" : "2011-05-22 20:49:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 113 ],
      "url" : "http:\/\/t.co\/mon9IBY",
      "expanded_url" : "http:\/\/www.techstars.org\/results\/",
      "display_url" : "techstars.org\/results\/"
    } ]
  },
  "geo" : { },
  "id_str" : "72396382849335296",
  "text" : "Only 10 days left to apply to TechStars Seattle! I love their TechStar company tracking page: http:\/\/t.co\/mon9IBY",
  "id" : 72396382849335296,
  "created_at" : "2011-05-22 20:20:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Mansilla",
      "screen_name" : "mansillaDEV",
      "indices" : [ 0, 12 ],
      "id_str" : "17541722",
      "id" : 17541722
    }, {
      "name" : "hunch",
      "screen_name" : "hunch",
      "indices" : [ 111, 117 ],
      "id_str" : "18715444",
      "id" : 18715444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72385799177510912",
  "geo" : { },
  "id_str" : "72394755312582656",
  "in_reply_to_user_id" : 17541722,
  "text" : "@mansillaDEV Looks great! Is it going to be online anywhere? Particularly interested to see how you integrated @hunch taste profiles!",
  "id" : 72394755312582656,
  "in_reply_to_status_id" : 72385799177510912,
  "created_at" : "2011-05-22 20:13:49 +0000",
  "in_reply_to_screen_name" : "mansillaDEV",
  "in_reply_to_user_id_str" : "17541722",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "indices" : [ 3, 7 ],
      "id_str" : "11822502",
      "id" : 11822502
    }, {
      "name" : "Hugh MacLeod",
      "screen_name" : "gapingvoid",
      "indices" : [ 62, 73 ],
      "id_str" : "50193",
      "id" : 50193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72378409996660736",
  "text" : "RT @mko: If you're interested in what builds social networks, @gapingvoid has a refreshingly unique look at Social Objects: http:\/\/gapin ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hugh MacLeod",
        "screen_name" : "gapingvoid",
        "indices" : [ 53, 64 ],
        "id_str" : "50193",
        "id" : 50193
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72353906025439232",
    "text" : "If you're interested in what builds social networks, @gapingvoid has a refreshingly unique look at Social Objects: http:\/\/gapingvoid.com\/so\/",
    "id" : 72353906025439232,
    "created_at" : "2011-05-22 17:31:30 +0000",
    "user" : {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "protected" : false,
      "id_str" : "11822502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000448201166\/85ffba84cba832307672516830358d37_normal.jpeg",
      "id" : 11822502,
      "verified" : false
    }
  },
  "id" : 72378409996660736,
  "created_at" : "2011-05-22 19:08:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 9, 20 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 51, 61 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Disrupt",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 105 ],
      "url" : "http:\/\/t.co\/kEQaMno",
      "expanded_url" : "http:\/\/techcrunch.com\/2011\/05\/22\/watch-the-techcrunch-disrupt-hackathon-live\/",
      "display_url" : "techcrunch.com\/2011\/05\/22\/wat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "72348946722328576",
  "text" : "Watching @TechCrunch #Disrupt Hackathon Live which @kellianne says I can never go to. http:\/\/t.co\/kEQaMno",
  "id" : 72348946722328576,
  "created_at" : "2011-05-22 17:11:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.606833, -122.323167 ]
  },
  "id_str" : "72144468760997888",
  "text" : "8:36pm Still life with Rocktopus while we make low-key birthday plans for next week http:\/\/flic.kr\/p\/9KD2VF",
  "id" : 72144468760997888,
  "created_at" : "2011-05-22 03:39:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 127, 136 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http:\/\/t.co\/45liBaS",
      "expanded_url" : "http:\/\/www.sfgate.com\/cgi-bin\/article.cgi?f=\/g\/a\/2011\/05\/20\/businessinsider-this-is-the-best-way-an-entrepreneur-has-ever-spent-his-fu-money-2011-5.DTL",
      "display_url" : "sfgate.com\/cgi-bin\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "72025623056498688",
  "text" : "It takes a good 5 years to achieve something meaningful. How many of those blocks will you use & how? http:\/\/t.co\/45liBaS \/via @arainert",
  "id" : 72025623056498688,
  "created_at" : "2011-05-21 19:47:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Maberly",
      "screen_name" : "CMaberly",
      "indices" : [ 0, 9 ],
      "id_str" : "128375612",
      "id" : 128375612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71980221561184256",
  "geo" : { },
  "id_str" : "71980814103093248",
  "in_reply_to_user_id" : 128375612,
  "text" : "@CMaberly Thief!",
  "id" : 71980814103093248,
  "in_reply_to_status_id" : 71980221561184256,
  "created_at" : "2011-05-21 16:48:58 +0000",
  "in_reply_to_screen_name" : "CMaberly",
  "in_reply_to_user_id_str" : "128375612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.606166, -122.3235 ]
  },
  "id_str" : "71787429757059072",
  "text" : "8:36pm What does it say about me that I read up on IMAP protocol when my brain is too tired to work? http:\/\/flic.kr\/p\/9Kpi7f",
  "id" : 71787429757059072,
  "created_at" : "2011-05-21 04:00:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71674608532725761",
  "text" : "I think I'm gonna give up alcohol for the next month or so. Is this a good idea or a bad one? And who wants to join?",
  "id" : 71674608532725761,
  "created_at" : "2011-05-20 20:32:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 3, 6 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71619909100118016",
  "text" : "RT @rk: Everyone who works for a startup that may IPO someday *needs* to read this article: http:\/\/read.bi\/iyMYUF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71616498975780864",
    "text" : "Everyone who works for a startup that may IPO someday *needs* to read this article: http:\/\/read.bi\/iyMYUF",
    "id" : 71616498975780864,
    "created_at" : "2011-05-20 16:41:18 +0000",
    "user" : {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "protected" : false,
      "id_str" : "19853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1202040731\/70847_7101903_1567328_n_normal.jpg",
      "id" : 19853,
      "verified" : false
    }
  },
  "id" : 71619909100118016,
  "created_at" : "2011-05-20 16:54:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 0, 4 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71598775759679488",
  "geo" : { },
  "id_str" : "71601108581220354",
  "in_reply_to_user_id" : 259,
  "text" : "@ian I don't think it's supposed to start until 6pm in your local time zone. Will be interesting for Arizona.",
  "id" : 71601108581220354,
  "in_reply_to_status_id" : 71598775759679488,
  "created_at" : "2011-05-20 15:40:09 +0000",
  "in_reply_to_screen_name" : "ian",
  "in_reply_to_user_id_str" : "259",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322834 ]
  },
  "id_str" : "71436788794802176",
  "text" : "8:36pm Cheese, crackers, The Daily Show, blogging, relaxing http:\/\/flic.kr\/p\/9K6CrH",
  "id" : 71436788794802176,
  "created_at" : "2011-05-20 04:47:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.616, -122.339167 ]
  },
  "id_str" : "71057642398822400",
  "text" : "8:36pm Loving Ignite Seattle #14 http:\/\/flic.kr\/p\/9JNWRF",
  "id" : 71057642398822400,
  "created_at" : "2011-05-19 03:40:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Broderick",
      "screen_name" : "MichelleBee",
      "indices" : [ 0, 12 ],
      "id_str" : "1059951",
      "id" : 1059951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71052841149673472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.615443452, -122.339423446 ]
  },
  "id_str" : "71054381268733952",
  "in_reply_to_user_id" : 1059951,
  "text" : "@MichelleBee You do a ton as well! Ps happy birthday! :)",
  "id" : 71054381268733952,
  "in_reply_to_status_id" : 71052841149673472,
  "created_at" : "2011-05-19 03:27:39 +0000",
  "in_reply_to_screen_name" : "MichelleBee",
  "in_reply_to_user_id_str" : "1059951",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarahnovotny",
      "screen_name" : "sarahnovotny",
      "indices" : [ 66, 79 ],
      "id_str" : "11547582",
      "id" : 11547582
    }, {
      "name" : "Ignite Seattle",
      "screen_name" : "ignitesea",
      "indices" : [ 90, 100 ],
      "id_str" : "3567281",
      "id" : 3567281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "is14",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6160522828, -122.3408972654 ]
  },
  "id_str" : "71052985177878528",
  "text" : "Awesome call to action for Seattle to support original geeks from @sarahnovotny #is14 \/cc @ignitesea",
  "id" : 71052985177878528,
  "created_at" : "2011-05-19 03:22:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mehal Shah",
      "screen_name" : "mehals",
      "indices" : [ 26, 33 ],
      "id_str" : "45145208",
      "id" : 45145208
    }, {
      "name" : "Ignite Seattle",
      "screen_name" : "ignitesea",
      "indices" : [ 128, 138 ],
      "id_str" : "3567281",
      "id" : 3567281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "is14",
      "indices" : [ 110, 115 ]
    }, {
      "text" : "ignite",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61647367, -122.34151959 ]
  },
  "id_str" : "71051844604002304",
  "text" : "My mind was just blown by @mehals and clabbers: scrabble with anagrams. And how to play games like a jackass. #is14 #ignite \/cc @ignitesea",
  "id" : 71051844604002304,
  "created_at" : "2011-05-19 03:17:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chase Sterling",
      "screen_name" : "chasesterling",
      "indices" : [ 0, 14 ],
      "id_str" : "20113974",
      "id" : 20113974
    }, {
      "name" : "MeYou Health",
      "screen_name" : "meyouhealth",
      "indices" : [ 35, 47 ],
      "id_str" : "89513927",
      "id" : 89513927
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70927499843993602",
  "geo" : { },
  "id_str" : "70938317084045313",
  "in_reply_to_user_id" : 20113974,
  "text" : "@chasesterling I'd love to see it! @meyouhealth is awesome as well!",
  "id" : 70938317084045313,
  "in_reply_to_status_id" : 70927499843993602,
  "created_at" : "2011-05-18 19:46:27 +0000",
  "in_reply_to_screen_name" : "chasesterling",
  "in_reply_to_user_id_str" : "20113974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andres Moran",
      "screen_name" : "DreMoran",
      "indices" : [ 0, 9 ],
      "id_str" : "8461972",
      "id" : 8461972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70924371232956417",
  "geo" : { },
  "id_str" : "70924659452948480",
  "in_reply_to_user_id" : 8461972,
  "text" : "@DreMoran I totally agree. Good analysis there. Betrayal by the universe... because it doesn't operate by rules of fairness and justice.",
  "id" : 70924659452948480,
  "in_reply_to_status_id" : 70924371232956417,
  "created_at" : "2011-05-18 18:52:11 +0000",
  "in_reply_to_screen_name" : "DreMoran",
  "in_reply_to_user_id_str" : "8461972",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andres Moran",
      "screen_name" : "DreMoran",
      "indices" : [ 0, 9 ],
      "id_str" : "8461972",
      "id" : 8461972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70921281444388864",
  "geo" : { },
  "id_str" : "70923110358061056",
  "in_reply_to_user_id" : 8461972,
  "text" : "@DreMoran In many cases, anger is preceded by fear. But in righteous anger... it seems to be an emotional reaction to injustice\/unfairness.",
  "id" : 70923110358061056,
  "in_reply_to_status_id" : 70921281444388864,
  "created_at" : "2011-05-18 18:46:01 +0000",
  "in_reply_to_screen_name" : "DreMoran",
  "in_reply_to_user_id_str" : "8461972",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joost Plattel",
      "screen_name" : "jplattel",
      "indices" : [ 47, 56 ],
      "id_str" : "16376925",
      "id" : 16376925
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 104, 117 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70922472429588481",
  "text" : "I'm coming up on my 3-year 8:36pm birthday! RT @jplattel: That's 500 photos at 8:36pm for me. Thank you @busterbenson for this awesome idea!",
  "id" : 70922472429588481,
  "created_at" : "2011-05-18 18:43:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andres Moran",
      "screen_name" : "DreMoran",
      "indices" : [ 0, 9 ],
      "id_str" : "8461972",
      "id" : 8461972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70910688779968512",
  "geo" : { },
  "id_str" : "70920588004294657",
  "in_reply_to_user_id" : 8461972,
  "text" : "@DreMoran In the case of anger when you're fighting for something you believe in... what's the primary negative emotion?",
  "id" : 70920588004294657,
  "in_reply_to_status_id" : 70910688779968512,
  "created_at" : "2011-05-18 18:36:00 +0000",
  "in_reply_to_screen_name" : "DreMoran",
  "in_reply_to_user_id_str" : "8461972",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/3W3TPVG",
      "expanded_url" : "http:\/\/blog.jayparkinsonmd.com\/post\/5610559060\/in-the-past-50-years-weve-added-about-7-years-to",
      "display_url" : "blog.jayparkinsonmd.com\/post\/561055906\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "70920411814166528",
  "text" : "How do we increase life expectancy in the US the fastest? Better medicine? No. Self-driving cars. Can't wait! http:\/\/t.co\/3W3TPVG",
  "id" : 70920411814166528,
  "created_at" : "2011-05-18 18:35:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614518687, -122.3336557637 ]
  },
  "id_str" : "70900613415837699",
  "text" : "New positive emotions include but aren't limited to: righteous anger, self-pity, fear during movies and fiction, and pent up sobbing.",
  "id" : 70900613415837699,
  "created_at" : "2011-05-18 17:16:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614518687, -122.3336557637 ]
  },
  "id_str" : "70899692619313152",
  "text" : "Let's reclassify positive and negative emotions based on those that feel good and those that don't.",
  "id" : 70899692619313152,
  "created_at" : "2011-05-18 17:12:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "angryentreprenuer",
      "indices" : [ 56, 74 ]
    }, {
      "text" : "day2",
      "indices" : [ 75, 80 ]
    }, {
      "text" : "grrr",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614518687, -122.3336557637 ]
  },
  "id_str" : "70899260605988866",
  "text" : "Why is anger when you \"know\" you're right feel so good? #angryentreprenuer #day2 #grrr",
  "id" : 70899260605988866,
  "created_at" : "2011-05-18 17:11:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.322334 ]
  },
  "id_str" : "70695743081549824",
  "text" : "8:36pm Eating dinner, and so is Sopor http:\/\/flic.kr\/p\/9JwdGP",
  "id" : 70695743081549824,
  "created_at" : "2011-05-18 03:42:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70539657913450497",
  "text" : "Kellianne and I REALLY wanted to go to Sasquatch this year but can't. We have 2 spots at a condo to fill for great price. Anyone want them?",
  "id" : 70539657913450497,
  "created_at" : "2011-05-17 17:22:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Riccardo",
      "screen_name" : "RifoItaly",
      "indices" : [ 0, 10 ],
      "id_str" : "50579403",
      "id" : 50579403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70397696212615168",
  "geo" : { },
  "id_str" : "70501037244551168",
  "in_reply_to_user_id" : 50579403,
  "text" : "@RifoItaly It's having a little trouble keeping up to speed. Working on performance this week. But try again, it should work.",
  "id" : 70501037244551168,
  "in_reply_to_status_id" : 70397696212615168,
  "created_at" : "2011-05-17 14:48:51 +0000",
  "in_reply_to_screen_name" : "RifoItaly",
  "in_reply_to_user_id_str" : "50579403",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 3, 14 ],
      "id_str" : "1586501",
      "id" : 1586501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/7ibRJS4",
      "expanded_url" : "http:\/\/ind.pn\/mFjELE",
      "display_url" : "ind.pn\/mFjELE"
    } ]
  },
  "geo" : { },
  "id_str" : "70376091159773185",
  "text" : "RT @nickbilton: New science test can tell you how long you'll live (could be bad for society, for a number of reasons) http:\/\/t.co\/7ibRJS4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 122 ],
        "url" : "http:\/\/t.co\/7ibRJS4",
        "expanded_url" : "http:\/\/ind.pn\/mFjELE",
        "display_url" : "ind.pn\/mFjELE"
      } ]
    },
    "geo" : { },
    "id_str" : "70369513702563840",
    "text" : "New science test can tell you how long you'll live (could be bad for society, for a number of reasons) http:\/\/t.co\/7ibRJS4",
    "id" : 70369513702563840,
    "created_at" : "2011-05-17 06:06:14 +0000",
    "user" : {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "protected" : false,
      "id_str" : "1586501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453750282770341888\/SEwjZ2AI_normal.png",
      "id" : 1586501,
      "verified" : true
    }
  },
  "id" : 70376091159773185,
  "created_at" : "2011-05-17 06:32:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.3375 ]
  },
  "id_str" : "70332986851196928",
  "text" : "8:36pm Just heard about vanilla bean infused Makers http:\/\/flic.kr\/p\/9JgcoJ",
  "id" : 70332986851196928,
  "created_at" : "2011-05-17 03:41:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70258277287608320",
  "geo" : { },
  "id_str" : "70259215788290049",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew That's awesome!",
  "id" : 70259215788290049,
  "in_reply_to_status_id" : 70258277287608320,
  "created_at" : "2011-05-16 22:47:57 +0000",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 21, 30 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/vcA0IUi",
      "expanded_url" : "http:\/\/shufflebrain.eventbrite.com",
      "display_url" : "shufflebrain.eventbrite.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60679852, -122.323049 ]
  },
  "id_str" : "70161122841460736",
  "text" : "I learned a ton from @amyjokim about good gamification. 4 seats left for Smart Gamification, closing registration TODAY: http:\/\/t.co\/vcA0IUi",
  "id" : 70161122841460736,
  "created_at" : "2011-05-16 16:18:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 40, 46 ],
      "id_str" : "5814",
      "id" : 5814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 115 ],
      "url" : "http:\/\/t.co\/OkynaPQ",
      "expanded_url" : "http:\/\/thenextweb.com\/industry\/2011\/05\/14\/how-the-internet-is-revolutionizing-education\/",
      "display_url" : "thenextweb.com\/industry\/2011\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60679852, -122.323049 ]
  },
  "id_str" : "70153672172126209",
  "text" : "Great summary of the current players RT @tempo: How the Internet is Revolutionizing Education - http:\/\/t.co\/OkynaPQ",
  "id" : 70153672172126209,
  "created_at" : "2011-05-16 15:48:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave McClure",
      "screen_name" : "davemcclure",
      "indices" : [ 17, 29 ],
      "id_str" : "1081",
      "id" : 1081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 100 ],
      "url" : "http:\/\/t.co\/SN7Aq8g",
      "expanded_url" : "http:\/\/www.baycitizen.org\/books\/story\/go-f-sleep-case-viral-pdf\/",
      "display_url" : "baycitizen.org\/books\/story\/go\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.604492117, -122.3230361248 ]
  },
  "id_str" : "70126615690084352",
  "text" : "#1 on Amazon! RT @davemcclure: 'Go the Fuck to Sleep': The Case of the Viral PDF http:\/\/t.co\/SN7Aq8g",
  "id" : 70126615690084352,
  "created_at" : "2011-05-16 14:01:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.322334 ]
  },
  "id_str" : "69970829630377984",
  "text" : "8:36pm Niko's 1st bday party is over. We're reading beautiful letters to him from before he was born. So good. http:\/\/flic.kr\/p\/9HSxpa",
  "id" : 69970829630377984,
  "created_at" : "2011-05-16 03:42:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "laborwatch",
      "indices" : [ 28, 39 ]
    }, {
      "text" : "tweetsfrom1yearago",
      "indices" : [ 65, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69865334580056064",
  "text" : "\"Castor oil milkshake time! #laborwatch\" - me, 12:14pm 5\/15\/2010 #tweetsfrom1yearago",
  "id" : 69865334580056064,
  "created_at" : "2011-05-15 20:42:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Karnjanaprakorn",
      "screen_name" : "mikekarnj",
      "indices" : [ 3, 13 ],
      "id_str" : "5901702",
      "id" : 5901702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69834175531847680",
  "text" : "RT @mikekarnj: If you work in technology, you should build something to disrupt healthcare, politics, banking, education or any other ar ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69831754499891200",
    "text" : "If you work in technology, you should build something to disrupt healthcare, politics, banking, education or any other archaic institution.",
    "id" : 69831754499891200,
    "created_at" : "2011-05-15 18:29:22 +0000",
    "user" : {
      "name" : "Mike Karnjanaprakorn",
      "screen_name" : "mikekarnj",
      "protected" : false,
      "id_str" : "5901702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000564827914\/74fcbb6221a074a167af16ab2c03abc0_normal.jpeg",
      "id" : 5901702,
      "verified" : false
    }
  },
  "id" : 69834175531847680,
  "created_at" : "2011-05-15 18:38:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seth Priebatsch",
      "screen_name" : "sethpriebatsch",
      "indices" : [ 121, 136 ],
      "id_str" : "28465863",
      "id" : 28465863
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 115 ],
      "url" : "http:\/\/t.co\/nNH7tGi",
      "expanded_url" : "http:\/\/read.bi\/jP1HV1",
      "display_url" : "read.bi\/jP1HV1"
    } ]
  },
  "in_reply_to_status_id_str" : "69817725270241281",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049480371, -122.3229952657 ]
  },
  "id_str" : "69833456758177792",
  "in_reply_to_user_id" : 28465863,
  "text" : "Well-written article on some of the limitations, challenges, and opportunities in #gamification http:\/\/t.co\/nNH7tGi \/via @sethpriebatsch",
  "id" : 69833456758177792,
  "in_reply_to_status_id" : 69817725270241281,
  "created_at" : "2011-05-15 18:36:08 +0000",
  "in_reply_to_screen_name" : "sethpriebatsch",
  "in_reply_to_user_id_str" : "28465863",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 28, 38 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Can Can",
      "screen_name" : "thecancan",
      "indices" : [ 56, 66 ],
      "id_str" : "24484489",
      "id" : 24484489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69642944407281664",
  "text" : "Around this time a year ago @kellianne's water broke at @thecancan during intermission while watching two audience members make out.",
  "id" : 69642944407281664,
  "created_at" : "2011-05-15 05:59:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zero to baby",
      "screen_name" : "zerotobaby",
      "indices" : [ 3, 14 ],
      "id_str" : "73698926",
      "id" : 73698926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69631128646066176",
  "text" : "RT @zerotobaby: Happy Birthday, Baby! http:\/\/goo.gl\/fb\/AlVEm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69629550497247232",
    "text" : "Happy Birthday, Baby! http:\/\/goo.gl\/fb\/AlVEm",
    "id" : 69629550497247232,
    "created_at" : "2011-05-15 05:05:53 +0000",
    "user" : {
      "name" : "Zero to baby",
      "screen_name" : "zerotobaby",
      "protected" : false,
      "id_str" : "73698926",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497222570\/milton-and-esther-8wks-square_normal",
      "id" : 73698926,
      "verified" : false
    }
  },
  "id" : 69631128646066176,
  "created_at" : "2011-05-15 05:12:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Boisvenue",
      "screen_name" : "Travisboisvenue",
      "indices" : [ 0, 16 ],
      "id_str" : "14054915",
      "id" : 14054915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69514246261706752",
  "geo" : { },
  "id_str" : "69612420536082432",
  "in_reply_to_user_id" : 14054915,
  "text" : "@Travisboisvenue Would love to hear more about the presentation! How did it go? Any slides online?",
  "id" : 69612420536082432,
  "in_reply_to_status_id" : 69514246261706752,
  "created_at" : "2011-05-15 03:57:49 +0000",
  "in_reply_to_screen_name" : "Travisboisvenue",
  "in_reply_to_user_id_str" : "14054915",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69550691236061184",
  "geo" : { },
  "id_str" : "69612271415996416",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc I clicked the \"I wish this was on the Kindle\" link from the detail page. I assume they're scrambling around now Kindlizing it, right?",
  "id" : 69612271415996416,
  "in_reply_to_status_id" : 69550691236061184,
  "created_at" : "2011-05-15 03:57:13 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "MarshallHaas",
      "indices" : [ 0, 13 ],
      "id_str" : "1268491417",
      "id" : 1268491417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69554998433943552",
  "geo" : { },
  "id_str" : "69612144051765248",
  "in_reply_to_user_id" : 19028099,
  "text" : "@MarshallHaas Way back when. Via NaNoWriMo and then self-published it. My degree is in creative writing. :)",
  "id" : 69612144051765248,
  "in_reply_to_status_id" : 69554998433943552,
  "created_at" : "2011-05-15 03:56:43 +0000",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.3225 ]
  },
  "id_str" : "69608092270198784",
  "text" : "8:36pm A couple seconds after this he walked 3 steps to the couch! Walking debut maybe tomorrow? http:\/\/flic.kr\/p\/9Hvbr2",
  "id" : 69608092270198784,
  "created_at" : "2011-05-15 03:40:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 124 ],
      "url" : "http:\/\/t.co\/2R6IeqN",
      "expanded_url" : "http:\/\/www.amazon.com\/gp\/product\/0595283535\/ref=as_li_ss_tl?ie=UTF8&tag=mockerybird&linkCode=as2&camp=217145&creative=399349&creativeASIN=0595283535",
      "display_url" : "amazon.com\/gp\/product\/059\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "69534122107871232",
  "text" : "Just received a royalty check for $23.24 from iUniverse for my sales from Man Versus Himself since 2004: http:\/\/t.co\/2R6IeqN Drinks on me!",
  "id" : 69534122107871232,
  "created_at" : "2011-05-14 22:46:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Longtine",
      "screen_name" : "jlongtine",
      "indices" : [ 0, 10 ],
      "id_str" : "722793",
      "id" : 722793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69478776039419904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60681647, -122.32304376 ]
  },
  "id_str" : "69485295933980672",
  "in_reply_to_user_id" : 722793,
  "text" : "@jlongtine I'd love to be walked through the \"proof\" of his prediction. How data leads to certainty is fascinatingly rich.",
  "id" : 69485295933980672,
  "in_reply_to_status_id" : 69478776039419904,
  "created_at" : "2011-05-14 19:32:40 +0000",
  "in_reply_to_screen_name" : "jlongtine",
  "in_reply_to_user_id_str" : "722793",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthmonth",
      "indices" : [ 43, 55 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69464929551400961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60681647, -122.32304376 ]
  },
  "id_str" : "69481215614402561",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim Jen and I are doing the same for #healthmonth mobile. Would love to compare notes.",
  "id" : 69481215614402561,
  "in_reply_to_status_id" : 69464929551400961,
  "created_at" : "2011-05-14 19:16:27 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henry Blodget",
      "screen_name" : "hblodget",
      "indices" : [ 0, 9 ],
      "id_str" : "6730222",
      "id" : 6730222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69461680882581504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60681647, -122.32304376 ]
  },
  "id_str" : "69480605569650690",
  "in_reply_to_user_id" : 6730222,
  "text" : "@hblodget Perfect day for an evening airplane ride heading east. If only to view the rubble line pass below.",
  "id" : 69480605569650690,
  "in_reply_to_status_id" : 69461680882581504,
  "created_at" : "2011-05-14 19:14:01 +0000",
  "in_reply_to_screen_name" : "hblodget",
  "in_reply_to_user_id_str" : "6730222",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Longtine",
      "screen_name" : "jlongtine",
      "indices" : [ 0, 10 ],
      "id_str" : "722793",
      "id" : 722793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69477713982926848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60681647, -122.32304376 ]
  },
  "id_str" : "69478490331807745",
  "in_reply_to_user_id" : 722793,
  "text" : "@jlongtine Yeah, but will it only encourage skepticism and bet-hedging to the rest of us? Certainty has a tough job, but it's not all bad.",
  "id" : 69478490331807745,
  "in_reply_to_status_id" : 69477713982926848,
  "created_at" : "2011-05-14 19:05:37 +0000",
  "in_reply_to_screen_name" : "jlongtine",
  "in_reply_to_user_id_str" : "722793",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Longtine",
      "screen_name" : "jlongtine",
      "indices" : [ 0, 10 ],
      "id_str" : "722793",
      "id" : 722793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69477148649459713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60681647, -122.32304376 ]
  },
  "id_str" : "69477557191442433",
  "in_reply_to_user_id" : 722793,
  "text" : "@jlongtine Poor guy. Our brains just get surer and surer of themselves as we age. I don't want to hear the May 22nd interview. But sorta do.",
  "id" : 69477557191442433,
  "in_reply_to_status_id" : 69477148649459713,
  "created_at" : "2011-05-14 19:01:55 +0000",
  "in_reply_to_screen_name" : "jlongtine",
  "in_reply_to_user_id_str" : "722793",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MacRumors.com",
      "screen_name" : "MacRumors",
      "indices" : [ 92, 102 ],
      "id_str" : "14861285",
      "id" : 14861285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http:\/\/t.co\/SfMGaHR",
      "expanded_url" : "http:\/\/macrumo.rs\/lhDPH1",
      "display_url" : "macrumo.rs\/lhDPH1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60681647, -122.32304376 ]
  },
  "id_str" : "69477042634244096",
  "text" : "A potentially annoying way to never have to answer the phone again http:\/\/t.co\/SfMGaHR \/via @MacRumors",
  "id" : 69477042634244096,
  "created_at" : "2011-05-14 18:59:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 57 ],
      "url" : "http:\/\/t.co\/3BVYRtQ",
      "expanded_url" : "http:\/\/bit.ly\/lLEhnm",
      "display_url" : "bit.ly\/lLEhnm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049836975, -122.323005195 ]
  },
  "id_str" : "69476257250803712",
  "text" : "Mark your calendars for May 21st, 6pm http:\/\/t.co\/3BVYRtQ",
  "id" : 69476257250803712,
  "created_at" : "2011-05-14 18:56:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/IFTvKKS",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=7UCm6uyzNE8",
      "display_url" : "youtube.com\/watch?v=7UCm6u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "69425091095703552",
  "text" : "Very cute cover of the Angry Birds theme song by Pomplamoose http:\/\/t.co\/IFTvKKS",
  "id" : 69425091095703552,
  "created_at" : "2011-05-14 15:33:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322667 ]
  },
  "id_str" : "69245337554006016",
  "text" : "8:36pm Can you hear Niko crying? Cause it's loud. :( http:\/\/flic.kr\/p\/9HgpG1",
  "id" : 69245337554006016,
  "created_at" : "2011-05-14 03:39:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 0, 6 ],
      "id_str" : "5814",
      "id" : 5814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69159375331266560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605013775, -122.32285628 ]
  },
  "id_str" : "69168965997436929",
  "in_reply_to_user_id" : 5814,
  "text" : "@tempo So happy to hear that! Have been following the story in disbelief. What an awful dude.",
  "id" : 69168965997436929,
  "in_reply_to_status_id" : 69159375331266560,
  "created_at" : "2011-05-13 22:35:41 +0000",
  "in_reply_to_screen_name" : "tempo",
  "in_reply_to_user_id_str" : "5814",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 63, 74 ],
      "id_str" : "2384071",
      "id" : 2384071
    }, {
      "name" : "umair haque",
      "screen_name" : "umairh",
      "indices" : [ 79, 86 ],
      "id_str" : "14321959",
      "id" : 14321959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 57 ],
      "url" : "http:\/\/t.co\/NpTnJjb",
      "expanded_url" : "http:\/\/bit.ly\/l25koR",
      "display_url" : "bit.ly\/l25koR"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6048788675, -122.3230687475 ]
  },
  "id_str" : "69165679860908032",
  "text" : "The good life: opulence vs eudaimonia http:\/\/t.co\/NpTnJjb \/via @timoreilly \/by @umairh",
  "id" : 69165679860908032,
  "created_at" : "2011-05-13 22:22:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/timely.is\" rel=\"nofollow\"\u003ETimely by Demandforce\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69099383848845312",
  "text" : "Don't be afraid that being afraid is the only thing that keeps the things you're afraid of from getting you.",
  "id" : 69099383848845312,
  "created_at" : "2011-05-13 17:59:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 3, 12 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69053516282462208",
  "text" : "RT @BuzzFeed: Banksy's real name is... http:\/\/bzfd.it\/m7pBH3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69045152949354497",
    "text" : "Banksy's real name is... http:\/\/bzfd.it\/m7pBH3",
    "id" : 69045152949354497,
    "created_at" : "2011-05-13 14:23:41 +0000",
    "user" : {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "protected" : false,
      "id_str" : "5695632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2852410605\/6e6da28a06cfd7aea20a3cc393ef1182_normal.png",
      "id" : 5695632,
      "verified" : true
    }
  },
  "id" : 69053516282462208,
  "created_at" : "2011-05-13 14:56:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.604833, -122.323 ]
  },
  "id_str" : "68888349015937024",
  "text" : "8:36pm Looking for baby Tylenol to help this sick mama's boy through the night http:\/\/flic.kr\/p\/9GYNMt",
  "id" : 68888349015937024,
  "created_at" : "2011-05-13 04:00:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68826601634275328",
  "geo" : { },
  "id_str" : "68826792198287360",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Kickstarter it, already!  :)",
  "id" : 68826792198287360,
  "in_reply_to_status_id" : 68826601634275328,
  "created_at" : "2011-05-12 23:56:00 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68823390026334208",
  "geo" : { },
  "id_str" : "68825293577658369",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Truly. Hi-5 for teachers of the revolution!",
  "id" : 68825293577658369,
  "in_reply_to_status_id" : 68823390026334208,
  "created_at" : "2011-05-12 23:50:03 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SimpleGeo",
      "screen_name" : "SimpleGeo",
      "indices" : [ 0, 10 ],
      "id_str" : "14373435",
      "id" : 14373435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68819965310021632",
  "geo" : { },
  "id_str" : "68820799326400512",
  "in_reply_to_user_id" : 14373435,
  "text" : "@SimpleGeo Every time you add something to the context call, I just up and down with glee. Now... how is pop. dens. diff from metro score?",
  "id" : 68820799326400512,
  "in_reply_to_status_id" : 68819965310021632,
  "created_at" : "2011-05-12 23:32:11 +0000",
  "in_reply_to_screen_name" : "SimpleGeo",
  "in_reply_to_user_id_str" : "14373435",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "indices" : [ 0, 11 ],
      "id_str" : "809641",
      "id" : 809641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68812214760521728",
  "geo" : { },
  "id_str" : "68813911264215040",
  "in_reply_to_user_id" : 809641,
  "text" : "@adamloving Love the sentiment but man that's some statistical correlation abuse if I ever saw it. :)",
  "id" : 68813911264215040,
  "in_reply_to_status_id" : 68812214760521728,
  "created_at" : "2011-05-12 23:04:49 +0000",
  "in_reply_to_screen_name" : "adamloving",
  "in_reply_to_user_id_str" : "809641",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Jacobs",
      "screen_name" : "evanjacobs",
      "indices" : [ 40, 51 ],
      "id_str" : "14803483",
      "id" : 14803483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/ctqjEUt",
      "expanded_url" : "http:\/\/bit.ly\/kiO5F7",
      "display_url" : "bit.ly\/kiO5F7"
    } ]
  },
  "geo" : { },
  "id_str" : "68797421660016640",
  "text" : "I would love to see this in Seattle. RT @evanjacobs: New blog post: \"Wantrepreneur to Entrepreneur\" http:\/\/t.co\/ctqjEUt",
  "id" : 68797421660016640,
  "created_at" : "2011-05-12 21:59:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    }, {
      "name" : "JesseSchell",
      "screen_name" : "jesseschell",
      "indices" : [ 30, 42 ],
      "id_str" : "11591662",
      "id" : 11591662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68793672522674176",
  "geo" : { },
  "id_str" : "68797285819101184",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim Great links today!  @jesseschell is talking about very exciting stuff here... exactly where we're charging into right now.",
  "id" : 68797285819101184,
  "in_reply_to_status_id" : 68793672522674176,
  "created_at" : "2011-05-12 21:58:45 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68752358837993472",
  "geo" : { },
  "id_str" : "68752412923543552",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler Great! What's the best way to contact them?",
  "id" : 68752412923543552,
  "in_reply_to_status_id" : 68752358837993472,
  "created_at" : "2011-05-12 19:00:27 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i.am.donte",
      "screen_name" : "iamdonte",
      "indices" : [ 0, 9 ],
      "id_str" : "17977759",
      "id" : 17977759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68750971689373696",
  "geo" : { },
  "id_str" : "68751090094587904",
  "in_reply_to_user_id" : 17977759,
  "text" : "@iamdonte Do you recommend that building? What's the best way to contact?",
  "id" : 68751090094587904,
  "in_reply_to_status_id" : 68750971689373696,
  "created_at" : "2011-05-12 18:55:11 +0000",
  "in_reply_to_screen_name" : "iamdonte",
  "in_reply_to_user_id_str" : "17977759",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68750435242086400",
  "text" : "Seattle friends: Anyone have leads on a good 1-bedroom apartment available immediately in Cap Hill under $1300? Friends just moved here!",
  "id" : 68750435242086400,
  "created_at" : "2011-05-12 18:52:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Palloma Swam",
      "screen_name" : "PSwam",
      "indices" : [ 39, 45 ],
      "id_str" : "945710839",
      "id" : 945710839
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 47, 60 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/02ll1IR",
      "expanded_url" : "http:\/\/bit.ly\/iLJPo0",
      "display_url" : "bit.ly\/iLJPo0"
    } ]
  },
  "geo" : { },
  "id_str" : "68735023129444352",
  "text" : "Feynman is my hero! Love this book. RT @pswam: @busterbenson someone else had the same attitude :-) http:\/\/t.co\/02ll1IR",
  "id" : 68735023129444352,
  "created_at" : "2011-05-12 17:51:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/timely.is\" rel=\"nofollow\"\u003ETimely by Demandforce\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 7, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68733227501764608",
  "text" : "Forget #gamification if you must. Just cultivate a playful attitude towards learning and mastery and call it whatever you want.",
  "id" : 68733227501764608,
  "created_at" : "2011-05-12 17:44:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 10, 20 ],
      "id_str" : "13349",
      "id" : 13349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68722987339227136",
  "geo" : { },
  "id_str" : "68729537428594688",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley @ryanchris I'd be willing to mentor him in the ways of being a Buster.",
  "id" : 68729537428594688,
  "in_reply_to_status_id" : 68722987339227136,
  "created_at" : "2011-05-12 17:29:33 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 8, 13 ],
      "id_str" : "418",
      "id" : 418
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 14, 23 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68708892225445888",
  "geo" : { },
  "id_str" : "68710031423574016",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @dens @arainert Yeah, the websites weren't designed for this. Clients for Twitter and email were. Wish web worked, but it's hard.",
  "id" : 68710031423574016,
  "in_reply_to_status_id" : 68708892225445888,
  "created_at" : "2011-05-12 16:12:02 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 10, 15 ],
      "id_str" : "418",
      "id" : 418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68705124310196224",
  "geo" : { },
  "id_str" : "68707451746271233",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert @dens I agree that 2 browsers totally sucks. But do ANY websites on the web handle multiple logins gracefully?",
  "id" : 68707451746271233,
  "in_reply_to_status_id" : 68705124310196224,
  "created_at" : "2011-05-12 16:01:47 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 3, 8 ],
      "id_str" : "418",
      "id" : 418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68707143683026944",
  "text" : "RT @dens: 50 replies to my tweet about Gmail logins: ~40 from people saying they use 2 browsers (ugh) & a few confirming that Goog multi ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "68704294379069440",
    "text" : "50 replies to my tweet about Gmail logins: ~40 from people saying they use 2 browsers (ugh) & a few confirming that Goog multi-acct is buggy",
    "id" : 68704294379069440,
    "created_at" : "2011-05-12 15:49:14 +0000",
    "user" : {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "protected" : false,
      "id_str" : "418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3180393492\/9236f9d84c75e755a98de9d67f8d1460_normal.jpeg",
      "id" : 418,
      "verified" : true
    }
  },
  "id" : 68707143683026944,
  "created_at" : "2011-05-12 16:00:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 98, 109 ],
      "id_str" : "14258044",
      "id" : 14258044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.3225 ]
  },
  "id_str" : "68533407415672833",
  "text" : "8:36pm Singing children's books by memory (thanks Loren for Little Blue Truck!). & flowers thx to @jensmccabe! http:\/\/flic.kr\/p\/9GJmEx",
  "id" : 68533407415672833,
  "created_at" : "2011-05-12 04:30:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy Weese Moll",
      "screen_name" : "joyweesemoll",
      "indices" : [ 0, 13 ],
      "id_str" : "1427181",
      "id" : 1427181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68357488763871232",
  "geo" : { },
  "id_str" : "68367927325368321",
  "in_reply_to_user_id" : 1427181,
  "text" : "@joyweesemoll Uh oh. What's happening? I'm able to log in myself... maybe the problem resolved itself?",
  "id" : 68367927325368321,
  "in_reply_to_status_id" : 68357488763871232,
  "created_at" : "2011-05-11 17:32:38 +0000",
  "in_reply_to_screen_name" : "joyweesemoll",
  "in_reply_to_user_id_str" : "1427181",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68117049548873728",
  "geo" : { },
  "id_str" : "68119872848138240",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright I like site5.com and host all my blogs, development sites, side projects there...",
  "id" : 68119872848138240,
  "in_reply_to_status_id" : 68117049548873728,
  "created_at" : "2011-05-11 01:06:57 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68093047606489088",
  "geo" : { },
  "id_str" : "68094051953541120",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Regardless of what you think of Thiel and his project (not highly), don't you think education is generally ripe for some disruption?",
  "id" : 68094051953541120,
  "in_reply_to_status_id" : 68093047606489088,
  "created_at" : "2011-05-10 23:24:21 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 7, 16 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 17, 27 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68087917297401858",
  "geo" : { },
  "id_str" : "68089137516920833",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc @spangley @kellianne He's not pontificating, we are. He's putting his money and ideas into practice. Only time will tell...",
  "id" : 68089137516920833,
  "in_reply_to_status_id" : 68087917297401858,
  "created_at" : "2011-05-10 23:04:50 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 54, 64 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67795667631878144",
  "text" : "8:36pm Showing this funny video from earlier today to @Kellianne over take out Thai http:\/\/flic.kr\/p\/9GdKGm",
  "id" : 67795667631878144,
  "created_at" : "2011-05-10 03:38:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Statigram",
      "screen_name" : "statigram",
      "indices" : [ 3, 13 ],
      "id_str" : "2203106720",
      "id" : 2203106720
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 24, 34 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 72 ],
      "url" : "http:\/\/t.co\/RFfKIbm",
      "expanded_url" : "http:\/\/statigr.am\/busterbenson",
      "display_url" : "statigr.am\/busterbenson"
    } ]
  },
  "geo" : { },
  "id_str" : "67788249900392448",
  "text" : "My @statigram stats for @instagram are quite pretty: http:\/\/t.co\/RFfKIbm",
  "id" : 67788249900392448,
  "created_at" : "2011-05-10 03:09:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 82 ],
      "url" : "http:\/\/t.co\/8GV7cmX",
      "expanded_url" : "http:\/\/vimeo.com\/22157500",
      "display_url" : "vimeo.com\/22157500"
    } ]
  },
  "geo" : { },
  "id_str" : "67470832670228481",
  "text" : "Freerunning and parkour facility in LA. This video is awesome: http:\/\/t.co\/8GV7cmX",
  "id" : 67470832670228481,
  "created_at" : "2011-05-09 06:07:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 33, 43 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.323167 ]
  },
  "id_str" : "67434445816336384",
  "text" : "8:36pm Happy 1st Mother's day to @Kellianne! http:\/\/flic.kr\/p\/9FQZAg",
  "id" : 67434445816336384,
  "created_at" : "2011-05-09 03:43:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    }, {
      "name" : "Kristen Bell ",
      "screen_name" : "IMKristenBell",
      "indices" : [ 50, 64 ],
      "id_str" : "53297035",
      "id" : 53297035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67089962025230336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60640579, -122.3232727 ]
  },
  "id_str" : "67095144469504002",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin I can't believe I wasn't following @imkristenbell! That's her, right?",
  "id" : 67095144469504002,
  "in_reply_to_status_id" : 67089962025230336,
  "created_at" : "2011-05-08 05:15:03 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 31, 41 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614333, -122.346667 ]
  },
  "id_str" : "67071562163027968",
  "text" : "8:36pm Dinner at Tavolata with @Kellianne's aunt and uncle http:\/\/flic.kr\/p\/9FuFeK",
  "id" : 67071562163027968,
  "created_at" : "2011-05-08 03:41:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.323 ]
  },
  "id_str" : "66709861508976641",
  "text" : "8:36pm Keeping Niko out too late to hang with Kellianne's aunt and uncle http:\/\/flic.kr\/p\/9Fgwj1",
  "id" : 66709861508976641,
  "created_at" : "2011-05-07 03:44:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca Lovell",
      "screen_name" : "lovelletters",
      "indices" : [ 3, 16 ],
      "id_str" : "287833734",
      "id" : 287833734
    }, {
      "name" : "GeekWireNews",
      "screen_name" : "GeekWireNews",
      "indices" : [ 23, 36 ],
      "id_str" : "389204381",
      "id" : 389204381
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2a",
      "indices" : [ 18, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66635752372572161",
  "text" : "RT @lovelletters: #s2a @geekwirenews \"good judgment comes from experience, experience comes from bad judgment.\" word.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GeekWireNews",
        "screen_name" : "GeekWireNews",
        "indices" : [ 5, 18 ],
        "id_str" : "389204381",
        "id" : 389204381
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "s2a",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66329151359037440",
    "text" : "#s2a @geekwirenews \"good judgment comes from experience, experience comes from bad judgment.\" word.",
    "id" : 66329151359037440,
    "created_at" : "2011-05-06 02:31:16 +0000",
    "user" : {
      "name" : "Rebecca Lovell",
      "screen_name" : "lovelletters",
      "protected" : false,
      "id_str" : "287833734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441976155747266561\/lvLgnSTi_normal.jpeg",
      "id" : 287833734,
      "verified" : false
    }
  },
  "id" : 66635752372572161,
  "created_at" : "2011-05-06 22:49:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 0, 6 ],
      "id_str" : "5814",
      "id" : 5814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66618477879898112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60691475, -122.32318639 ]
  },
  "id_str" : "66624731641675776",
  "in_reply_to_user_id" : 5814,
  "text" : "@tempo Me too! Anything in particular inspiring it this round for you?",
  "id" : 66624731641675776,
  "in_reply_to_status_id" : 66618477879898112,
  "created_at" : "2011-05-06 22:05:48 +0000",
  "in_reply_to_screen_name" : "tempo",
  "in_reply_to_user_id_str" : "5814",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 135 ],
      "url" : "http:\/\/t.co\/7Qs2M7W",
      "expanded_url" : "http:\/\/www.ted.com\/talks\/eli_pariser_beware_online_filter_bubbles.html",
      "display_url" : "ted.com\/talks\/eli_pari\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "66599332605992960",
  "text" : "Great TED talk reminder that we need to make sure to not only surround ourselves with people and ideas just like us http:\/\/t.co\/7Qs2M7W",
  "id" : 66599332605992960,
  "created_at" : "2011-05-06 20:24:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Heitzeberg",
      "screen_name" : "jheitzeb",
      "indices" : [ 0, 9 ],
      "id_str" : "6629572",
      "id" : 6629572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66400394728833024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049847421, -122.3227754007 ]
  },
  "id_str" : "66401241307164672",
  "in_reply_to_user_id" : 6629572,
  "text" : "@jheitzeb My first one but agree that it was awesome and inspiring on several fronts. Totally didn't see you there though!",
  "id" : 66401241307164672,
  "in_reply_to_status_id" : 66400394728833024,
  "created_at" : "2011-05-06 07:17:44 +0000",
  "in_reply_to_screen_name" : "jheitzeb",
  "in_reply_to_user_id_str" : "6629572",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.619333, -122.346667 ]
  },
  "id_str" : "66362190965383168",
  "text" : "8:36pm Seattle 2.0 Awards were inspiring! http:\/\/flic.kr\/p\/9EYHvv",
  "id" : 66362190965383168,
  "created_at" : "2011-05-06 04:42:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "King of Caffeine",
      "screen_name" : "kingofcaffeine",
      "indices" : [ 79, 94 ],
      "id_str" : "40097004",
      "id" : 40097004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.619397, -122.346698 ]
  },
  "id_str" : "66309232634494977",
  "text" : "Seattle 2.0 Awards! Snuck in just barely. &300:event (@ Cirque Event Center w\/ @kingofcaffeine) http:\/\/4sq.com\/mBwl6c",
  "id" : 66309232634494977,
  "created_at" : "2011-05-06 01:12:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Gluhanich",
      "screen_name" : "LauraGlu",
      "indices" : [ 0, 9 ],
      "id_str" : "9428232",
      "id" : 9428232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66260369173258240",
  "geo" : { },
  "id_str" : "66261441640022016",
  "in_reply_to_user_id" : 9428232,
  "text" : "@LauraGlu Wow, yeah, that would be really useful to have! \n\nAnd hey, awesome meeting you in SF! That was a great wedding party!",
  "id" : 66261441640022016,
  "in_reply_to_status_id" : 66260369173258240,
  "created_at" : "2011-05-05 22:02:13 +0000",
  "in_reply_to_screen_name" : "LauraGlu",
  "in_reply_to_user_id_str" : "9428232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66259428265033728",
  "text" : "I'm surprised that there's no way to search through friends (ie all my friends named Dave) with either Facebook or Twitter's APIs.",
  "id" : 66259428265033728,
  "created_at" : "2011-05-05 21:54:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66230142451712000",
  "geo" : { },
  "id_str" : "66230320739008512",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara You can count their names on the leaderboard. :)",
  "id" : 66230320739008512,
  "in_reply_to_status_id" : 66230142451712000,
  "created_at" : "2011-05-05 19:58:33 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66229279465283585",
  "geo" : { },
  "id_str" : "66229723499479040",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara A minimum viable product joke app.",
  "id" : 66229723499479040,
  "in_reply_to_status_id" : 66229279465283585,
  "created_at" : "2011-05-05 19:56:11 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 21, 26 ],
      "id_str" : "418",
      "id" : 418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http:\/\/t.co\/4Ytfk3U",
      "expanded_url" : "http:\/\/subscribetoit.com\/",
      "display_url" : "subscribetoit.com"
    } ]
  },
  "geo" : { },
  "id_str" : "66228602496229376",
  "text" : "Tempting, but no. RT @dens: Maybe the worst startup in the history of startups, but whatever, I'm in!  http:\/\/t.co\/4Ytfk3U",
  "id" : 66228602496229376,
  "created_at" : "2011-05-05 19:51:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekWire Startups",
      "screen_name" : "seattle20",
      "indices" : [ 121, 131 ],
      "id_str" : "16055631",
      "id" : 16055631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s2a",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60691475, -122.32318639 ]
  },
  "id_str" : "66168926832295936",
  "text" : "Unexpectedly free to go to Seattle 2.0 Awards tonight but it's sold out. Anyone have a ticket they're not gonna use? \/cc @seattle20 #s2a",
  "id" : 66168926832295936,
  "created_at" : "2011-05-05 15:54:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne Elliott",
      "screen_name" : "zenpeacekeeper",
      "indices" : [ 0, 15 ],
      "id_str" : "35667496",
      "id" : 35667496
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 24, 34 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloToons",
      "indices" : [ 71, 82 ],
      "id_str" : "1099629326",
      "id" : 1099629326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66098836761886720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60691475, -122.32318639 ]
  },
  "id_str" : "66166696712486913",
  "in_reply_to_user_id" : 35667496,
  "text" : "@zenpeacekeeper My wife @Kellianne is doing your 30-days of yoga soon. @willotoons told us how awesome you and your program are.",
  "id" : 66166696712486913,
  "in_reply_to_status_id" : 66098836761886720,
  "created_at" : "2011-05-05 15:45:44 +0000",
  "in_reply_to_screen_name" : "zenpeacekeeper",
  "in_reply_to_user_id_str" : "35667496",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arielis Talavera",
      "screen_name" : "ArielisT",
      "indices" : [ 0, 9 ],
      "id_str" : "1163522401",
      "id" : 1163522401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60691475, -122.32318639 ]
  },
  "id_str" : "66166120796786688",
  "text" : "@arielist There's a new startup-centric mailing list with great local peeps on it that I can add you to if you can handle some extra email.",
  "id" : 66166120796786688,
  "created_at" : "2011-05-05 15:43:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Suster",
      "screen_name" : "msuster",
      "indices" : [ 6, 14 ],
      "id_str" : "5520332",
      "id" : 5520332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http:\/\/t.co\/3P8OPo9",
      "expanded_url" : "http:\/\/techcrunch.com\/2011\/05\/05\/a-few-key-people-really-can-make-a-huge-difference\/",
      "display_url" : "techcrunch.com\/2011\/05\/05\/a-f\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60691475, -122.32318639 ]
  },
  "id_str" : "66163739061260288",
  "text" : "LOVED @msuster's post on how a few key people in Seattle's tech scene can make a huge difference. http:\/\/t.co\/3P8OPo9",
  "id" : 66163739061260288,
  "created_at" : "2011-05-05 15:33:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 46, 57 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66040404516143104",
  "text" : "I just unlocked the \"Healthy Lizard\" badge on @foursquare! http:\/\/4sq.com\/mpYszY",
  "id" : 66040404516143104,
  "created_at" : "2011-05-05 07:23:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66001654725615616",
  "geo" : { },
  "id_str" : "66002020615720960",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley We had such a great time and you + your wedding were SO beautiful. We strongly considered staying forever.",
  "id" : 66002020615720960,
  "in_reply_to_status_id" : 66001654725615616,
  "created_at" : "2011-05-05 04:51:22 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6065, -122.323167 ]
  },
  "id_str" : "65986107518623744",
  "text" : "8:36pm 0-2 for good behavior while flying this trip, but happy to be home now http:\/\/flic.kr\/p\/9EGun8",
  "id" : 65986107518623744,
  "created_at" : "2011-05-05 03:48:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.617188911, -122.3826742172 ]
  },
  "id_str" : "65917448414699520",
  "text" : "The end of an awesome trip! Bye SF! &kb,nb,100:eating (@ Virgin America Terminal w\/ 5 others) http:\/\/4sq.com\/itGX9m",
  "id" : 65917448414699520,
  "created_at" : "2011-05-04 23:15:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caterina Fake",
      "screen_name" : "Caterina",
      "indices" : [ 3, 12 ],
      "id_str" : "5702",
      "id" : 5702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65843520136691712",
  "text" : "RT @Caterina: Reasoning was not designed to pursue the truth. Reasoning was designed by evolution to help us win arguments. http:\/\/bit.l ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65839066154942464",
    "text" : "Reasoning was not designed to pursue the truth. Reasoning was designed by evolution to help us win arguments. http:\/\/bit.ly\/maKQp4",
    "id" : 65839066154942464,
    "created_at" : "2011-05-04 18:03:51 +0000",
    "user" : {
      "name" : "Caterina Fake",
      "screen_name" : "Caterina",
      "protected" : false,
      "id_str" : "5702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000509318185\/d968d62d1bc39f2c82d3fa44db478525_normal.jpeg",
      "id" : 5702,
      "verified" : true
    }
  },
  "id" : 65843520136691712,
  "created_at" : "2011-05-04 18:21:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65677466856992768",
  "text" : "Niko's in a tunnel http:\/\/flic.kr\/p\/9EsbwZ",
  "id" : 65677466856992768,
  "created_at" : "2011-05-04 07:21:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65625684600569857",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.6265124461, -122.8688244008 ]
  },
  "id_str" : "65669440951435264",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim I've been learning to be super grateful as well... beautiful SF wedding and family vacation definitely helps.",
  "id" : 65669440951435264,
  "in_reply_to_status_id" : 65625684600569857,
  "created_at" : "2011-05-04 06:49:49 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.626833, -122.869 ]
  },
  "id_str" : "65621866403995649",
  "text" : "8:36pm Awesome reunion with Katja and Kevin in Healdsburg http:\/\/flic.kr\/p\/9Eq1Xr",
  "id" : 65621866403995649,
  "created_at" : "2011-05-04 03:40:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.629, -122.870667 ]
  },
  "id_str" : "65586848143118336",
  "text" : "Makeshift baby chair http:\/\/flic.kr\/p\/9ErbEj",
  "id" : 65586848143118336,
  "created_at" : "2011-05-04 01:21:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.0694011622, -122.5389178145 ]
  },
  "id_str" : "65483166504333312",
  "text" : "Other than the crazy spectacle of those big startup failures, what impact did they have on the founders' lives \/ future careers?",
  "id" : 65483166504333312,
  "created_at" : "2011-05-03 18:29:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arielis Talavera",
      "screen_name" : "ArielisT",
      "indices" : [ 0, 9 ],
      "id_str" : "1163522401",
      "id" : 1163522401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.0486379036, -122.5319849116 ]
  },
  "id_str" : "65482164686434304",
  "text" : "@arielist Totally. It was a whole different level the first time around. Would also love to see what the founders of each went on to do.",
  "id" : 65482164686434304,
  "created_at" : "2011-05-03 18:25:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hiten Shah",
      "screen_name" : "hnshah",
      "indices" : [ 24, 31 ],
      "id_str" : "3382",
      "id" : 3382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 107 ],
      "url" : "http:\/\/t.co\/DUKe69d",
      "expanded_url" : "http:\/\/kiss.ly\/jNxdVR",
      "display_url" : "kiss.ly\/jNxdVR"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8917162062, -122.5162892606 ]
  },
  "id_str" : "65479129964875779",
  "text" : "This is a fun thread RT @hnshah: What is the all-time greatest failed Internet startup? http:\/\/t.co\/DUKe69d",
  "id" : 65479129964875779,
  "created_at" : "2011-05-03 18:13:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.760833, -122.427834 ]
  },
  "id_str" : "65271793312731136",
  "text" : "8:36pm Finished a delicious dinner with Dante and Tracy and Katie http:\/\/flic.kr\/p\/9E7Z8e",
  "id" : 65271793312731136,
  "created_at" : "2011-05-03 04:29:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65151625345507328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7962393424, -122.4219486096 ]
  },
  "id_str" : "65152223058984960",
  "in_reply_to_user_id" : 21515310,
  "text" : "@richardtalens Awesome! Yes... my email is busterbenson@gmail.com",
  "id" : 65152223058984960,
  "in_reply_to_status_id" : 65151625345507328,
  "created_at" : "2011-05-02 20:34:35 +0000",
  "in_reply_to_screen_name" : "DickTalens",
  "in_reply_to_user_id_str" : "21515310",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephdub",
      "screen_name" : "stephdub",
      "indices" : [ 0, 9 ],
      "id_str" : "14936359",
      "id" : 14936359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.789828, -122.40697193 ]
  },
  "id_str" : "64962097645232128",
  "in_reply_to_user_id" : 14936359,
  "text" : "@stephdub So great to finally meet you in real life. And at such a beautiful event no less!",
  "id" : 64962097645232128,
  "created_at" : "2011-05-02 07:59:05 +0000",
  "in_reply_to_screen_name" : "stephdub",
  "in_reply_to_user_id_str" : "14936359",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7755, -122.437667 ]
  },
  "id_str" : "64903312180383745",
  "text" : "8:36pm I'm the only (seer-)sucker with a bowtie that's not on stage right now. Plus: tuba!! http:\/\/flic.kr\/p\/9DPjwL",
  "id" : 64903312180383745,
  "created_at" : "2011-05-02 04:05:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 25 ],
      "url" : "http:\/\/t.co\/5zlNExM",
      "expanded_url" : "http:\/\/www.nytimes.com\/2011\/05\/02\/world\/asia\/osama-bin-laden-is-killed.html",
      "display_url" : "nytimes.com\/2011\/05\/02\/wor\u2026"
    }, {
      "indices" : [ 26, 45 ],
      "url" : "http:\/\/t.co\/MiDdWti",
      "expanded_url" : "http:\/\/yfrog.com\/h2wcfqaj",
      "display_url" : "yfrog.com\/h2wcfqaj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.789828, -122.40697193 ]
  },
  "id_str" : "64885355513528320",
  "text" : "Woah. http:\/\/t.co\/5zlNExM http:\/\/t.co\/MiDdWti",
  "id" : 64885355513528320,
  "created_at" : "2011-05-02 02:54:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.791845, -122.406829 ]
  },
  "id_str" : "64883223829815296",
  "text" : "Funny fortune to get in the Ritz lobby  @ the Ritz-Carlton Hotel - SF http:\/\/instagr.am\/p\/DxY8s\/",
  "id" : 64883223829815296,
  "created_at" : "2011-05-02 02:45:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8552369364, -122.483332157 ]
  },
  "id_str" : "64820810078093312",
  "text" : "Rare family sighting  @ Campbell Hall & Garden http:\/\/instagr.am\/p\/Dw8kq\/",
  "id" : 64820810078093312,
  "created_at" : "2011-05-01 22:37:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.858166, -122.485834 ]
  },
  "id_str" : "64815727521177600",
  "text" : "Dirty pants from crawling http:\/\/flic.kr\/p\/9DELaF",
  "id" : 64815727521177600,
  "created_at" : "2011-05-01 22:17:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8552369364, -122.4833321571 ]
  },
  "id_str" : "64787380170792960",
  "text" : "Happy wedding day, Ali and Todd! This place is beautiful! (@ Campbell Hall & Garden for Spangleman Wedding) [pic]: http:\/\/4sq.com\/meQPXx",
  "id" : 64787380170792960,
  "created_at" : "2011-05-01 20:24:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.786166, -122.4175 ]
  },
  "id_str" : "64768394762797056",
  "text" : "Baby's first limo. Heading to the wedding! http:\/\/flic.kr\/p\/9DBg5r",
  "id" : 64768394762797056,
  "created_at" : "2011-05-01 19:09:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]