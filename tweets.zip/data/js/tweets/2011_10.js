Grailbird.data.tweets_2011_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/4n6aAwT4",
      "expanded_url" : "http:\/\/instagr.am\/p\/SSnaq\/",
      "display_url" : "instagr.am\/p\/SSnaq\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6044919218, -122.309975387 ]
  },
  "id_str" : "131217759651635200",
  "text" : "Party at the Benson house!  @ \uE036Benson Bungalow http:\/\/t.co\/4n6aAwT4",
  "id" : 131217759651635200,
  "created_at" : "2011-11-01 03:55:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "indices" : [ 0, 4 ],
      "id_str" : "11822502",
      "id" : 11822502
    }, {
      "name" : "Laura Gluhanich",
      "screen_name" : "LauraGlu",
      "indices" : [ 5, 14 ],
      "id_str" : "9428232",
      "id" : 9428232
    }, {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "indices" : [ 15, 21 ],
      "id_str" : "8708232",
      "id" : 8708232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131154177853370370",
  "geo" : { },
  "id_str" : "131181791917785088",
  "in_reply_to_user_id" : 11822502,
  "text" : "@mko @lauraglu @brynn Is \"data-driven diet\" like the hacker's diet or different? And forcing a healthier you is a noble cause! Good luck!",
  "id" : 131181791917785088,
  "in_reply_to_status_id" : 131154177853370370,
  "created_at" : "2011-11-01 01:32:31 +0000",
  "in_reply_to_screen_name" : "mko",
  "in_reply_to_user_id_str" : "11822502",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalya Pemberton",
      "screen_name" : "talof2cities",
      "indices" : [ 0, 13 ],
      "id_str" : "62600226",
      "id" : 62600226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131156726790635521",
  "geo" : { },
  "id_str" : "131181533057916928",
  "in_reply_to_user_id" : 62600226,
  "text" : "@talof2cities But persistence IS playing. Whether or not you succeed is secondary. PS. Happy Halloween!",
  "id" : 131181533057916928,
  "in_reply_to_status_id" : 131156726790635521,
  "created_at" : "2011-11-01 01:31:29 +0000",
  "in_reply_to_screen_name" : "talof2cities",
  "in_reply_to_user_id_str" : "62600226",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Jacobs",
      "screen_name" : "evanjacobs",
      "indices" : [ 11, 22 ],
      "id_str" : "14803483",
      "id" : 14803483
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tsdday",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6084769621, -122.3063650509 ]
  },
  "id_str" : "131150694152536065",
  "text" : "Me too! RT @evanjacobs: Really excited to see what the 10 Seattle TechStars companies have created over the past 10 weeks. #tsdday",
  "id" : 131150694152536065,
  "created_at" : "2011-10-31 23:28:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 0, 2 ],
      "id_str" : "11222",
      "id" : 11222
    }, {
      "name" : "Whitney Hess",
      "screen_name" : "whitneyhess",
      "indices" : [ 59, 71 ],
      "id_str" : "11963132",
      "id" : 11963132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131134378347732992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085575624, -122.3061643501 ]
  },
  "id_str" : "131150280065691648",
  "in_reply_to_user_id" : 11222,
  "text" : "@k What kind of friend stats are you thinking of here? \/cc @whitneyhess",
  "id" : 131150280065691648,
  "in_reply_to_status_id" : 131134378347732992,
  "created_at" : "2011-10-31 23:27:18 +0000",
  "in_reply_to_screen_name" : "k",
  "in_reply_to_user_id_str" : "11222",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whitney Hess",
      "screen_name" : "whitneyhess",
      "indices" : [ 0, 12 ],
      "id_str" : "11963132",
      "id" : 11963132
    }, {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 13, 15 ],
      "id_str" : "11222",
      "id" : 11222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131134925184319488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6084766447, -122.3063316591 ]
  },
  "id_str" : "131147797503283200",
  "in_reply_to_user_id" : 11963132,
  "text" : "@whitneyhess @k We've been working on just that for months! So excited to show it to y'all soon!",
  "id" : 131147797503283200,
  "in_reply_to_status_id" : 131134925184319488,
  "created_at" : "2011-10-31 23:17:26 +0000",
  "in_reply_to_screen_name" : "whitneyhess",
  "in_reply_to_user_id_str" : "11963132",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131132338292801536",
  "text" : "I *dare* you to play healthmonth.com during the holidays. :)",
  "id" : 131132338292801536,
  "created_at" : "2011-10-31 22:16:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jonahlehrer",
      "screen_name" : "jonahlehrer",
      "indices" : [ 50, 62 ],
      "id_str" : "18994661",
      "id" : 18994661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/2TbIijpO",
      "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/books\/2011\/10\/is-self-knowledge-overrated.html",
      "display_url" : "newyorker.com\/online\/blogs\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "131091740626141184",
  "text" : "\"Self-knowledge is surprisingly useless,\" also by @jonahlehrer: http:\/\/t.co\/2TbIijpO  \n\nI disagree. Useless, or just moderately useful?",
  "id" : 131091740626141184,
  "created_at" : "2011-10-31 19:34:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jonahlehrer",
      "screen_name" : "jonahlehrer",
      "indices" : [ 100, 112 ],
      "id_str" : "18994661",
      "id" : 18994661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/SJEiiQ2V",
      "expanded_url" : "http:\/\/scienceblogs.com\/cortex\/2010\/06\/feelings_of_knowing.php",
      "display_url" : "scienceblogs.com\/cortex\/2010\/06\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "131088954786185217",
  "text" : "\"What does it mean to know something without being able to access it?\" \n\nThe feeling of knowing, by @jonahlehrer\nhttp:\/\/t.co\/SJEiiQ2V",
  "id" : 131088954786185217,
  "created_at" : "2011-10-31 19:23:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Umami",
      "screen_name" : "joshumami",
      "indices" : [ 64, 74 ],
      "id_str" : "11815632",
      "id" : 11815632
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 76, 89 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/joshumami\/status\/130911624402960385\/photo\/1",
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/1LMo7sd4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AdEXbcXCAAAfjSY.jpg",
      "id_str" : "130911624407154688",
      "id" : 130911624407154688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AdEXbcXCAAAfjSY.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/1LMo7sd4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130912664456151040",
  "text" : "Answer to my question about a macro lens on a computer screen: \u201C@joshumami: @busterbenson This. http:\/\/t.co\/1LMo7sd4\u201D Thanks, Josh!",
  "id" : 130912664456151040,
  "created_at" : "2011-10-31 07:43:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Betts-LaCroix",
      "screen_name" : "LisaBL",
      "indices" : [ 0, 7 ],
      "id_str" : "12985442",
      "id" : 12985442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130858643179573248",
  "geo" : { },
  "id_str" : "130858938118836224",
  "in_reply_to_user_id" : 12985442,
  "text" : "@LisaBL I do! I like that one a lot.",
  "id" : 130858938118836224,
  "in_reply_to_status_id" : 130858643179573248,
  "created_at" : "2011-10-31 04:09:36 +0000",
  "in_reply_to_screen_name" : "LisaBL",
  "in_reply_to_user_id_str" : "12985442",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "indices" : [ 3, 13 ],
      "id_str" : "14326765",
      "id" : 14326765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/aNlb80C6",
      "expanded_url" : "http:\/\/www.geekwire.com\/2011\/zuckerberg-tech-startups-silicon-valley",
      "display_url" : "geekwire.com\/2011\/zuckerber\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "130858064134934528",
  "text" : "RT @johnhcook: Mark Zuckerberg says you don't need to be in Silicon Valley (and engineers in Seattle stick around longer): http:\/\/t.co\/a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/aNlb80C6",
        "expanded_url" : "http:\/\/www.geekwire.com\/2011\/zuckerberg-tech-startups-silicon-valley",
        "display_url" : "geekwire.com\/2011\/zuckerber\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "130857819439239171",
    "text" : "Mark Zuckerberg says you don't need to be in Silicon Valley (and engineers in Seattle stick around longer): http:\/\/t.co\/aNlb80C6",
    "id" : 130857819439239171,
    "created_at" : "2011-10-31 04:05:10 +0000",
    "user" : {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "protected" : false,
      "id_str" : "14326765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/403089484\/john-headshot_normal.jpg",
      "id" : 14326765,
      "verified" : false
    }
  },
  "id" : 130858064134934528,
  "created_at" : "2011-10-31 04:06:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/GfxPk6or",
      "expanded_url" : "http:\/\/flic.kr\/p\/aAs93c",
      "display_url" : "flic.kr\/p\/aAs93c"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.609, -122.305834 ]
  },
  "id_str" : "130853032719167489",
  "text" : "8:36pm Close-up of my screen. Wonder what a macro lens would pick up. http:\/\/t.co\/GfxPk6or",
  "id" : 130853032719167489,
  "created_at" : "2011-10-31 03:46:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dad",
      "indices" : [ 35, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/0mbVvJxD",
      "expanded_url" : "http:\/\/bustr.tumblr.com\/post\/12134911002\/18-years-ago",
      "display_url" : "bustr.tumblr.com\/post\/121349110\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "130772914432778240",
  "text" : "18 years ago: http:\/\/t.co\/0mbVvJxD #dad",
  "id" : 130772914432778240,
  "created_at" : "2011-10-30 22:27:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 126, 135 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/Pu0L5QS5",
      "expanded_url" : "http:\/\/rickwebb.tumblr.com\/post\/12131722639\/keep-wall-street-occupied-by-ransackedroom-well",
      "display_url" : "rickwebb.tumblr.com\/post\/121317226\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "130767343377846273",
  "text" : "Potentially interesting way to annoy banks sending you all that pre-approved credit card junk mail: http:\/\/t.co\/Pu0L5QS5 \/via @rickwebb",
  "id" : 130767343377846273,
  "created_at" : "2011-10-30 22:05:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not all math",
      "screen_name" : "mathpunk",
      "indices" : [ 0, 9 ],
      "id_str" : "7621482",
      "id" : 7621482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130761596715798528",
  "geo" : { },
  "id_str" : "130761886303141888",
  "in_reply_to_user_id" : 7621482,
  "text" : "@mathpunk Health and education are the two that I think are most important to disrupt right now.",
  "id" : 130761886303141888,
  "in_reply_to_status_id" : 130761596715798528,
  "created_at" : "2011-10-30 21:43:57 +0000",
  "in_reply_to_screen_name" : "mathpunk",
  "in_reply_to_user_id_str" : "7621482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl T. Holscher",
      "screen_name" : "peroty",
      "indices" : [ 0, 7 ],
      "id_str" : "12444",
      "id" : 12444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/JL9qf3lc",
      "expanded_url" : "https:\/\/twitter.com\/#!\/search\/realtime\/%40busterbenson",
      "display_url" : "twitter.com\/#!\/search\/real\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "130756679099887616",
  "geo" : { },
  "id_str" : "130756988807294976",
  "in_reply_to_user_id" : 12444,
  "text" : "@peroty For sure.  You can see the replies here too: http:\/\/t.co\/JL9qf3lc",
  "id" : 130756988807294976,
  "in_reply_to_status_id" : 130756679099887616,
  "created_at" : "2011-10-30 21:24:30 +0000",
  "in_reply_to_screen_name" : "peroty",
  "in_reply_to_user_id_str" : "12444",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ragnar Freyr",
      "screen_name" : "ragnarfreyr",
      "indices" : [ 0, 12 ],
      "id_str" : "16509622",
      "id" : 16509622
    }, {
      "name" : "Mary Maddux",
      "screen_name" : "MeditationOasis",
      "indices" : [ 63, 79 ],
      "id_str" : "50104756",
      "id" : 50104756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130755292894998528",
  "geo" : { },
  "id_str" : "130756258356674561",
  "in_reply_to_user_id" : 16509622,
  "text" : "@ragnarfreyr Thank you! What in particular do you find user on @meditationoasis?",
  "id" : 130756258356674561,
  "in_reply_to_status_id" : 130755292894998528,
  "created_at" : "2011-10-30 21:21:35 +0000",
  "in_reply_to_screen_name" : "ragnarfreyr",
  "in_reply_to_user_id_str" : "16509622",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathalie Lussier",
      "screen_name" : "NathLussier",
      "indices" : [ 0, 12 ],
      "id_str" : "12669672",
      "id" : 12669672
    }, {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "indices" : [ 58, 68 ],
      "id_str" : "25110374",
      "id" : 25110374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130754650046611457",
  "geo" : { },
  "id_str" : "130756151766822912",
  "in_reply_to_user_id" : 12669672,
  "text" : "@NathLussier Looks great! I'll check it out, thanks!  \/cc @unclerush",
  "id" : 130756151766822912,
  "in_reply_to_status_id" : 130754650046611457,
  "created_at" : "2011-10-30 21:21:10 +0000",
  "in_reply_to_screen_name" : "NathLussier",
  "in_reply_to_user_id_str" : "12669672",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Dole",
      "screen_name" : "adamdole",
      "indices" : [ 0, 9 ],
      "id_str" : "14789168",
      "id" : 14789168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130754745148260353",
  "geo" : { },
  "id_str" : "130755291414396929",
  "in_reply_to_user_id" : 14789168,
  "text" : "@adamdole Downloading the Mayo Clinic Meditation app now. Looks well done. Thanks!",
  "id" : 130755291414396929,
  "in_reply_to_status_id" : 130754745148260353,
  "created_at" : "2011-10-30 21:17:45 +0000",
  "in_reply_to_screen_name" : "adamdole",
  "in_reply_to_user_id_str" : "14789168",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole Lazzaro",
      "screen_name" : "NicoleLazzaro",
      "indices" : [ 0, 14 ],
      "id_str" : "7315732",
      "id" : 7315732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130753746799038465",
  "geo" : { },
  "id_str" : "130753944459808768",
  "in_reply_to_user_id" : 7315732,
  "text" : "@NicoleLazzaro I will!  Thank you, Nicole.",
  "id" : 130753944459808768,
  "in_reply_to_status_id" : 130753746799038465,
  "created_at" : "2011-10-30 21:12:24 +0000",
  "in_reply_to_screen_name" : "NicoleLazzaro",
  "in_reply_to_user_id_str" : "7315732",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130752512629284864",
  "text" : "I know I asked this before, but if you have any favorite meditation apps, websites, or programs, please send 'em to me!",
  "id" : 130752512629284864,
  "created_at" : "2011-10-30 21:06:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/r6LoXNRb",
      "expanded_url" : "http:\/\/flic.kr\/p\/aAayFh",
      "display_url" : "flic.kr\/p\/aAayFh"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.613, -122.315667 ]
  },
  "id_str" : "130502456047190016",
  "text" : "8:36pm Another in my series of walking home late http:\/\/t.co\/r6LoXNRb",
  "id" : 130502456047190016,
  "created_at" : "2011-10-30 04:33:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 3, 13 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/3frTJRdf",
      "expanded_url" : "http:\/\/instagr.am\/p\/R9fyI\/",
      "display_url" : "instagr.am\/p\/R9fyI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "130465284833284096",
  "text" : "RT @kellianne: Question: What will your kid be for Halloween?  Answer: Ridiculous! http:\/\/t.co\/3frTJRdf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/3frTJRdf",
        "expanded_url" : "http:\/\/instagr.am\/p\/R9fyI\/",
        "display_url" : "instagr.am\/p\/R9fyI\/"
      } ]
    },
    "geo" : { },
    "id_str" : "130431363601018880",
    "text" : "Question: What will your kid be for Halloween?  Answer: Ridiculous! http:\/\/t.co\/3frTJRdf",
    "id" : 130431363601018880,
    "created_at" : "2011-10-29 23:50:35 +0000",
    "user" : {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "protected" : false,
      "id_str" : "7362142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000797915192\/b8af15473eb3d267e28d19076048ab99_normal.jpeg",
      "id" : 7362142,
      "verified" : false
    }
  },
  "id" : 130465284833284096,
  "created_at" : "2011-10-30 02:05:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/timely.is\" rel=\"nofollow\"\u003ETimely by Demandforce\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130364071668224000",
  "text" : "Your (behavior) habits are often guarded by an army of thought habits.",
  "id" : 130364071668224000,
  "created_at" : "2011-10-29 19:23:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 48, 60 ],
      "id_str" : "930061",
      "id" : 930061
    }, {
      "name" : "Dropbox",
      "screen_name" : "Dropbox",
      "indices" : [ 98, 106 ],
      "id_str" : "14749606",
      "id" : 14749606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/JRukeR7E",
      "expanded_url" : "http:\/\/todotxt.com\/",
      "display_url" : "todotxt.com"
    } ]
  },
  "geo" : { },
  "id_str" : "130138110330810368",
  "text" : "6 years later, I'm finally seeing the beauty of @ginatrapani's http:\/\/t.co\/JRukeR7E, matched with @dropbox public folders.",
  "id" : 130138110330810368,
  "created_at" : "2011-10-29 04:25:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130127432232603648",
  "geo" : { },
  "id_str" : "130127726785994752",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote I'm so philanthropic sometimes.",
  "id" : 130127726785994752,
  "in_reply_to_status_id" : 130127432232603648,
  "created_at" : "2011-10-29 03:44:02 +0000",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/Oc7J45g3",
      "expanded_url" : "http:\/\/www.43things.com\/people\/progress\/erik\/1832452",
      "display_url" : "43things.com\/people\/progres\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "130100205218562048",
  "geo" : { },
  "id_str" : "130122703356166144",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote Oh wait, I just found this: http:\/\/t.co\/Oc7J45g3",
  "id" : 130122703356166144,
  "in_reply_to_status_id" : 130100205218562048,
  "created_at" : "2011-10-29 03:24:04 +0000",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130100205218562048",
  "geo" : { },
  "id_str" : "130122469699878912",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote I don't think I've done that publicly, just with mint.com and spreadsheets and letters to the IRS. :)",
  "id" : 130122469699878912,
  "in_reply_to_status_id" : 130100205218562048,
  "created_at" : "2011-10-29 03:23:08 +0000",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trapper Markelz",
      "screen_name" : "trappermarkelz",
      "indices" : [ 90, 105 ],
      "id_str" : "1032241",
      "id" : 1032241
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whatsyournumber",
      "indices" : [ 46, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/mTwrSoif",
      "expanded_url" : "http:\/\/bbc.in\/t47BNc",
      "display_url" : "bbc.in\/t47BNc"
    } ]
  },
  "geo" : { },
  "id_str" : "129986526347149312",
  "text" : "I'm the 78,547,350,170th person to ever live  #whatsyournumber? http:\/\/t.co\/mTwrSoif \/via @trappermarkelz",
  "id" : 129986526347149312,
  "created_at" : "2011-10-28 18:22:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/JqUA6h29",
      "expanded_url" : "http:\/\/flic.kr\/p\/azDYAA",
      "display_url" : "flic.kr\/p\/azDYAA"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614, -122.327167 ]
  },
  "id_str" : "129765128647348224",
  "text" : "8:36pm Walking home after a productive day despite coming down with a cold http:\/\/t.co\/JqUA6h29",
  "id" : 129765128647348224,
  "created_at" : "2011-10-28 03:43:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/JkG7vG6e",
      "expanded_url" : "http:\/\/blog.habitlabs.com\/post\/11996356994\/15lbs-by-2012-3-weeks-down-10-to-go",
      "display_url" : "blog.habitlabs.com\/post\/119963569\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "129618406344372224",
  "text" : "RT @habitlabs: 15lbs by 2012: week 3. Weight barely moving so far:  \nhttp:\/\/t.co\/JkG7vG6e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/JkG7vG6e",
        "expanded_url" : "http:\/\/blog.habitlabs.com\/post\/11996356994\/15lbs-by-2012-3-weeks-down-10-to-go",
        "display_url" : "blog.habitlabs.com\/post\/119963569\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "129618333204090881",
    "text" : "15lbs by 2012: week 3. Weight barely moving so far:  \nhttp:\/\/t.co\/JkG7vG6e",
    "id" : 129618333204090881,
    "created_at" : "2011-10-27 17:59:53 +0000",
    "user" : {
      "name" : "Habit Labs",
      "screen_name" : "habitlabs_done",
      "protected" : false,
      "id_str" : "250986038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1496138143\/bad-logo_normal.png",
      "id" : 250986038,
      "verified" : false
    }
  },
  "id" : 129618406344372224,
  "created_at" : "2011-10-27 18:00:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 109, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6158877314, -122.3495996079 ]
  },
  "id_str" : "129406457576833024",
  "text" : "\"I don't have the recipe for happiness, but I don't think it has many ingredients\" - Erik Kennedy at Seattle #quantifiedself meetup",
  "id" : 129406457576833024,
  "created_at" : "2011-10-27 03:57:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 47, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/L5FnE639",
      "expanded_url" : "http:\/\/flic.kr\/p\/azpDUS",
      "display_url" : "flic.kr\/p\/azpDUS"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.615833, -122.349667 ]
  },
  "id_str" : "129402371410366464",
  "text" : "8:36pm Only 1 guy stone cold passed out at our #quantifiedself meetup http:\/\/t.co\/L5FnE639",
  "id" : 129402371410366464,
  "created_at" : "2011-10-27 03:41:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QuantifiedSelf",
      "indices" : [ 40, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/947WUHDZ",
      "expanded_url" : "http:\/\/www.meetup.com\/Quantified-Self-Seattle\/events\/36589652\/",
      "display_url" : "meetup.com\/Quantified-Sel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "129330811697774594",
  "text" : "Hey! You should come to our 3rd Seattle #QuantifiedSelf meetup tonight @ 6pm! http:\/\/t.co\/947WUHDZ",
  "id" : 129330811697774594,
  "created_at" : "2011-10-26 22:57:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Rdio",
      "screen_name" : "Rdio",
      "indices" : [ 68, 73 ],
      "id_str" : "54205414",
      "id" : 54205414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129297570886463488",
  "geo" : { },
  "id_str" : "129303029626314752",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves I really enjoyed the soundtrack! Actually looked for it on @rdio this morning...",
  "id" : 129303029626314752,
  "in_reply_to_status_id" : 129297570886463488,
  "created_at" : "2011-10-26 21:06:59 +0000",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/8NdIoiVd",
      "expanded_url" : "http:\/\/blog.habitlabs.com\/post\/11956265524\/grit",
      "display_url" : "blog.habitlabs.com\/post\/119562655\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "129267275827122176",
  "text" : "Grit: http:\/\/t.co\/8NdIoiVd (includes results of the survey that you may have participated in)",
  "id" : 129267275827122176,
  "created_at" : "2011-10-26 18:44:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Fleischer",
      "screen_name" : "DobraWorks",
      "indices" : [ 0, 11 ],
      "id_str" : "14976274",
      "id" : 14976274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129241928175861761",
  "geo" : { },
  "id_str" : "129244253607043072",
  "in_reply_to_user_id" : 14976274,
  "text" : "@DobraWorks Not that would affect that intentionally. What kind of behavior are you seeing exactly?",
  "id" : 129244253607043072,
  "in_reply_to_status_id" : 129241928175861761,
  "created_at" : "2011-10-26 17:13:25 +0000",
  "in_reply_to_screen_name" : "DobraWorks",
  "in_reply_to_user_id_str" : "14976274",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 77, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/Pz0V17az",
      "expanded_url" : "http:\/\/flic.kr\/p\/az6R2t",
      "display_url" : "flic.kr\/p\/az6R2t"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6615, -122.318 ]
  },
  "id_str" : "129047892383105024",
  "text" : "8:36pm Moneyball won the votes but Drive won our moods. Thanks for the help! #fb http:\/\/t.co\/Pz0V17az",
  "id" : 129047892383105024,
  "created_at" : "2011-10-26 04:13:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 75, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6180152042, -122.3377930115 ]
  },
  "id_str" : "129024006635524096",
  "text" : "Does anyone have a good movie recommendation that's still in the theaters? #fb",
  "id" : 129024006635524096,
  "created_at" : "2011-10-26 02:38:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 14, 30 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QuantifiedSelf",
      "indices" : [ 88, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/WVakFnq1",
      "expanded_url" : "http:\/\/www.meetup.com\/Quantified-Self-Seattle\/",
      "display_url" : "meetup.com\/Quantified-Sel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "129011208522182656",
  "text" : "I'm going! RT @ameliagreenhall: I'm making a photo-filled presentation for tmrw night's #QuantifiedSelf Seattle meetup: http:\/\/t.co\/WVakFnq1",
  "id" : 129011208522182656,
  "created_at" : "2011-10-26 01:47:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eli Tucker",
      "screen_name" : "etucker",
      "indices" : [ 0, 8 ],
      "id_str" : "5559292",
      "id" : 5559292
    }, {
      "name" : "Vizify",
      "screen_name" : "vizify",
      "indices" : [ 9, 16 ],
      "id_str" : "295513152",
      "id" : 295513152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128742088958423041",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085215054, -122.3058993521 ]
  },
  "id_str" : "128857500979183616",
  "in_reply_to_user_id" : 5559292,
  "text" : "@etucker @vizify You should make a big call to sign up from my data page but since I was sharing my page I felt a little tricked...",
  "id" : 128857500979183616,
  "in_reply_to_status_id" : 128742088958423041,
  "created_at" : "2011-10-25 15:36:36 +0000",
  "in_reply_to_screen_name" : "etucker",
  "in_reply_to_user_id_str" : "5559292",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vizify",
      "screen_name" : "vizify",
      "indices" : [ 13, 20 ],
      "id_str" : "295513152",
      "id" : 295513152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetsheet",
      "indices" : [ 57, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/vnQT8e3v",
      "expanded_url" : "http:\/\/vizify.com\/tweetsheet\/busterbenson",
      "display_url" : "vizify.com\/tweetsheet\/bus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128719826456821760",
  "text" : "Not sure why @vizify links to that page. This is my real #tweetsheet: http:\/\/t.co\/vnQT8e3v (most-retweeted tweets is pretty interesting)",
  "id" : 128719826456821760,
  "created_at" : "2011-10-25 06:29:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vizify",
      "screen_name" : "vizify",
      "indices" : [ 89, 96 ],
      "id_str" : "295513152",
      "id" : 295513152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TweetSheet",
      "indices" : [ 51, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/BS92xY5p",
      "expanded_url" : "http:\/\/vizify.com\/tweetsheet?c=mb&from=busterbenson",
      "display_url" : "vizify.com\/tweetsheet?c=m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128718761783066624",
  "text" : "So cool! Angry Birds + your tweets * infographic = #TweetSheet  http:\/\/t.co\/BS92xY5p via @vizify",
  "id" : 128718761783066624,
  "created_at" : "2011-10-25 06:25:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/NqL4o8n7",
      "expanded_url" : "http:\/\/flic.kr\/p\/ayPovF",
      "display_url" : "flic.kr\/p\/ayPovF"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.609333, -122.3085 ]
  },
  "id_str" : "128685289538457600",
  "text" : "8:36pm Walking to meet Scott. http:\/\/t.co\/NqL4o8n7",
  "id" : 128685289538457600,
  "created_at" : "2011-10-25 04:12:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    }, {
      "name" : "Leo Babauta",
      "screen_name" : "habitlabs",
      "indices" : [ 71, 81 ],
      "id_str" : "2290777141",
      "id" : 2290777141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128631265564950530",
  "geo" : { },
  "id_str" : "128631505835663361",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall Nicely done! We should record our personal records at @habitlabs and see who can continually beat them week to week.",
  "id" : 128631505835663361,
  "in_reply_to_status_id" : 128631265564950530,
  "created_at" : "2011-10-25 00:38:35 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen",
      "screen_name" : "ellenthatcher",
      "indices" : [ 0, 14 ],
      "id_str" : "18999752",
      "id" : 18999752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128588634537476097",
  "geo" : { },
  "id_str" : "128589329219072002",
  "in_reply_to_user_id" : 18999752,
  "text" : "@ellenthatcher I got them from a psychologist named Angela Lee Duckworth.",
  "id" : 128589329219072002,
  "in_reply_to_status_id" : 128588634537476097,
  "created_at" : "2011-10-24 21:50:59 +0000",
  "in_reply_to_screen_name" : "ellenthatcher",
  "in_reply_to_user_id_str" : "18999752",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Healer",
      "screen_name" : "anewthought",
      "indices" : [ 0, 12 ],
      "id_str" : "18609085",
      "id" : 18609085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128584915108372481",
  "geo" : { },
  "id_str" : "128585105450078209",
  "in_reply_to_user_id" : 18609085,
  "text" : "@anewthought I'm constantly amazed at the level of consistency people have around this. Congrats!",
  "id" : 128585105450078209,
  "in_reply_to_status_id" : 128584915108372481,
  "created_at" : "2011-10-24 21:34:12 +0000",
  "in_reply_to_screen_name" : "anewthought",
  "in_reply_to_user_id_str" : "18609085",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Healer",
      "screen_name" : "anewthought",
      "indices" : [ 3, 15 ],
      "id_str" : "18609085",
      "id" : 18609085
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 17, 30 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128585000865116160",
  "text" : "RT @anewthought: @busterbenson Reached the 365 day milestone yesterday, and still going - thank you *so* much for 750Words!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128584915108372481",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson Reached the 365 day milestone yesterday, and still going - thank you *so* much for 750Words!",
    "id" : 128584915108372481,
    "created_at" : "2011-10-24 21:33:27 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Sam Healer",
      "screen_name" : "anewthought",
      "protected" : false,
      "id_str" : "18609085",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2793636655\/361610d4dfdb1bff4d438b0417054052_normal.jpeg",
      "id" : 18609085,
      "verified" : false
    }
  },
  "id" : 128585000865116160,
  "created_at" : "2011-10-24 21:33:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/8FGMs9p3",
      "expanded_url" : "http:\/\/healthmonth.wufoo.com\/forms\/grit-scale\/",
      "display_url" : "healthmonth.wufoo.com\/forms\/grit-sca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128584597658279936",
  "text" : "Getting some really interesting results from my grit survey so far. Take it and pass it on for best results: http:\/\/t.co\/8FGMs9p3",
  "id" : 128584597658279936,
  "created_at" : "2011-10-24 21:32:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "indices" : [ 3, 12 ],
      "id_str" : "255784266",
      "id" : 255784266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/UNP8vGhL",
      "expanded_url" : "http:\/\/goo.gl\/fb\/LCgcG",
      "display_url" : "goo.gl\/fb\/LCgcG"
    } ]
  },
  "geo" : { },
  "id_str" : "128584086506844160",
  "text" : "RT @geekwire: Are you sacrificing happiness and long-term wealth for short term gains? http:\/\/t.co\/UNP8vGhL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/UNP8vGhL",
        "expanded_url" : "http:\/\/goo.gl\/fb\/LCgcG",
        "display_url" : "goo.gl\/fb\/LCgcG"
      } ]
    },
    "geo" : { },
    "id_str" : "128583482384457728",
    "text" : "Are you sacrificing happiness and long-term wealth for short term gains? http:\/\/t.co\/UNP8vGhL",
    "id" : 128583482384457728,
    "created_at" : "2011-10-24 21:27:45 +0000",
    "user" : {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "protected" : false,
      "id_str" : "255784266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454998478880403457\/BjKnFxtf_normal.png",
      "id" : 255784266,
      "verified" : false
    }
  },
  "id" : 128584086506844160,
  "created_at" : "2011-10-24 21:30:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128344222171529216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085561552, -122.3063177925 ]
  },
  "id_str" : "128565525956665345",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin So excited that you finally met Jimmy James!",
  "id" : 128565525956665345,
  "in_reply_to_status_id" : 128344222171529216,
  "created_at" : "2011-10-24 20:16:24 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128543487485415424",
  "geo" : { },
  "id_str" : "128546221060141058",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie It's surprisingly difficult. I had no idea.",
  "id" : 128546221060141058,
  "in_reply_to_status_id" : 128543487485415424,
  "created_at" : "2011-10-24 18:59:42 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susannah Fox",
      "screen_name" : "SusannahFox",
      "indices" : [ 3, 15 ],
      "id_str" : "17843236",
      "id" : 17843236
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 17, 30 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128538509328908288",
  "text" : "RT @SusannahFox: @busterbenson Done! 30 seconds.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "128536745762496512",
    "geo" : { },
    "id_str" : "128538132974014464",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson Done! 30 seconds.",
    "id" : 128538132974014464,
    "in_reply_to_status_id" : 128536745762496512,
    "created_at" : "2011-10-24 18:27:33 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Susannah Fox",
      "screen_name" : "SusannahFox",
      "protected" : false,
      "id_str" : "17843236",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3781188819\/f3ab6a726fe64f3649312ea37882e588_normal.jpeg",
      "id" : 17843236,
      "verified" : false
    }
  },
  "id" : 128538509328908288,
  "created_at" : "2011-10-24 18:29:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susannah Fox",
      "screen_name" : "SusannahFox",
      "indices" : [ 0, 12 ],
      "id_str" : "17843236",
      "id" : 17843236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128538132974014464",
  "geo" : { },
  "id_str" : "128538442744344576",
  "in_reply_to_user_id" : 17843236,
  "text" : "@SusannahFox Awesome! I may make this a regular twitter exercise. :) Ow, my stomach hurts.",
  "id" : 128538442744344576,
  "in_reply_to_status_id" : 128538132974014464,
  "created_at" : "2011-10-24 18:28:47 +0000",
  "in_reply_to_screen_name" : "SusannahFox",
  "in_reply_to_user_id_str" : "17843236",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kav Latiolais",
      "screen_name" : "kavla",
      "indices" : [ 0, 6 ],
      "id_str" : "28838912",
      "id" : 28838912
    }, {
      "name" : "Behance's 99U",
      "screen_name" : "the99percent",
      "indices" : [ 105, 118 ],
      "id_str" : "716292679",
      "id" : 716292679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128537368524374016",
  "geo" : { },
  "id_str" : "128538177362333696",
  "in_reply_to_user_id" : 28838912,
  "text" : "@kavla Yes, need to read up more on how to build up grit. What is it? Identify weaknesses and train? \/cc @the99percent",
  "id" : 128538177362333696,
  "in_reply_to_status_id" : 128537368524374016,
  "created_at" : "2011-10-24 18:27:44 +0000",
  "in_reply_to_screen_name" : "kavla",
  "in_reply_to_user_id_str" : "28838912",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dolphinplank",
      "indices" : [ 20, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128537958629392384",
  "text" : "I got 2:23, new PR! #dolphinplank",
  "id" : 128537958629392384,
  "created_at" : "2011-10-24 18:26:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/IZwqZZhc",
      "expanded_url" : "http:\/\/yoga.theholisticcare.com\/yoga\/56-dolphin-plank-pose.html",
      "display_url" : "yoga.theholisticcare.com\/yoga\/56-dolphi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128536745762496512",
  "text" : "Everyone, stop what you're doing and do dolphin plank pose for as long as you can right now. And report back. Go! http:\/\/t.co\/IZwqZZhc",
  "id" : 128536745762496512,
  "created_at" : "2011-10-24 18:22:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Behance's 99U",
      "screen_name" : "the99percent",
      "indices" : [ 96, 109 ],
      "id_str" : "716292679",
      "id" : 716292679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/0ILmKLw6",
      "expanded_url" : "http:\/\/the99percent.com\/articles\/7094\/The-Future-of-Self-Improvement-Grit-Is-More-Important-Than-Talent",
      "display_url" : "the99percent.com\/articles\/7094\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128535340884574210",
  "text" : "Some background on the Grit Scale: grit is more important than talent: http:\/\/t.co\/0ILmKLw6 \/by @the99percent",
  "id" : 128535340884574210,
  "created_at" : "2011-10-24 18:16:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/8FGMs9p3",
      "expanded_url" : "http:\/\/healthmonth.wufoo.com\/forms\/grit-scale\/",
      "display_url" : "healthmonth.wufoo.com\/forms\/grit-sca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128526076241657856",
  "text" : "Duplicated the Grit Scale test for people to try out.  Can you fill it out with honest answers? http:\/\/t.co\/8FGMs9p3",
  "id" : 128526076241657856,
  "created_at" : "2011-10-24 17:39:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128506253742841857",
  "text" : "RT @thatdrew: try your best to do something awesome this week.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128503837865676802",
    "text" : "try your best to do something awesome this week.",
    "id" : 128503837865676802,
    "created_at" : "2011-10-24 16:11:17 +0000",
    "user" : {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "protected" : false,
      "id_str" : "10221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449363717671505920\/wKlfNnSY_normal.jpeg",
      "id" : 10221,
      "verified" : false
    }
  },
  "id" : 128506253742841857,
  "created_at" : "2011-10-24 16:20:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Josuweit",
      "screen_name" : "josablack",
      "indices" : [ 0, 10 ],
      "id_str" : "26769877",
      "id" : 26769877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128343784806293504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6084532763, -122.3064601548 ]
  },
  "id_str" : "128347967554985984",
  "in_reply_to_user_id" : 26769877,
  "text" : "@josablack Thank you! How did you find it?",
  "id" : 128347967554985984,
  "in_reply_to_status_id" : 128343784806293504,
  "created_at" : "2011-10-24 05:51:54 +0000",
  "in_reply_to_screen_name" : "josablack",
  "in_reply_to_user_id_str" : "26769877",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suzie Daggett",
      "screen_name" : "SuzieInsight",
      "indices" : [ 0, 13 ],
      "id_str" : "24891221",
      "id" : 24891221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128318125501460480",
  "geo" : { },
  "id_str" : "128320724137033728",
  "in_reply_to_user_id" : 24891221,
  "text" : "@SuzieInsight Sure thing! Done. Looks like a great event! Loved her TED talk.",
  "id" : 128320724137033728,
  "in_reply_to_status_id" : 128318125501460480,
  "created_at" : "2011-10-24 04:03:39 +0000",
  "in_reply_to_screen_name" : "SuzieInsight",
  "in_reply_to_user_id_str" : "24891221",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suzie Daggett",
      "screen_name" : "SuzieInsight",
      "indices" : [ 3, 16 ],
      "id_str" : "24891221",
      "id" : 24891221
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 21, 34 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ojtXjx7j",
      "expanded_url" : "http:\/\/www.seattlesymphony.org\/symphony\/buy\/single\/production.aspx?id=11677&src=t&dateid=11677",
      "display_url" : "seattlesymphony.org\/symphony\/buy\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128320540644614144",
  "text" : "RT @SuzieInsight: Hi @busterbenson Please RT & share? Neuroanatomist Dr Jill Bolte Taylor will speaking Benaroya Hall in Seattle Wed.Nov ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 3, 16 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/ojtXjx7j",
        "expanded_url" : "http:\/\/www.seattlesymphony.org\/symphony\/buy\/single\/production.aspx?id=11677&src=t&dateid=11677",
        "display_url" : "seattlesymphony.org\/symphony\/buy\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "128318125501460480",
    "text" : "Hi @busterbenson Please RT & share? Neuroanatomist Dr Jill Bolte Taylor will speaking Benaroya Hall in Seattle Wed.Nov2 http:\/\/t.co\/ojtXjx7j",
    "id" : 128318125501460480,
    "created_at" : "2011-10-24 03:53:19 +0000",
    "user" : {
      "name" : "Suzie Daggett",
      "screen_name" : "SuzieInsight",
      "protected" : false,
      "id_str" : "24891221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000736949334\/44e7102cf4facd909bbf0b2da7f340f6_normal.jpeg",
      "id" : 24891221,
      "verified" : false
    }
  },
  "id" : 128320540644614144,
  "created_at" : "2011-10-24 04:02:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/yJoY7mPw",
      "expanded_url" : "http:\/\/flic.kr\/p\/ayuvKp",
      "display_url" : "flic.kr\/p\/ayuvKp"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306 ]
  },
  "id_str" : "128315770869518337",
  "text" : "8:36pm Got some Trader Joe's pumpkins! http:\/\/t.co\/yJoY7mPw",
  "id" : 128315770869518337,
  "created_at" : "2011-10-24 03:43:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 19, 29 ],
      "id_str" : "10015122",
      "id" : 10015122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/chG705tU",
      "expanded_url" : "http:\/\/instagr.am\/p\/RPZaO\/",
      "display_url" : "instagr.am\/p\/RPZaO\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6044919218, -122.309975387 ]
  },
  "id_str" : "128265355960389632",
  "text" : "Just spraypainting @andypixel while wearing a fat suit  @ Pixel Palace Hostel and Petting Zoo http:\/\/t.co\/chG705tU",
  "id" : 128265355960389632,
  "created_at" : "2011-10-24 00:23:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/xhaXfaYg",
      "expanded_url" : "http:\/\/flic.kr\/p\/ay98LH",
      "display_url" : "flic.kr\/p\/ay98LH"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.615166, -122.320834 ]
  },
  "id_str" : "127954409962479617",
  "text" : "8:36pm Walking home is so enjoyable after a rain and a fulfilling day of work http:\/\/t.co\/xhaXfaYg",
  "id" : 127954409962479617,
  "created_at" : "2011-10-23 03:48:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "indices" : [ 46, 57 ],
      "id_str" : "10876852",
      "id" : 10876852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/UX1MtnBq",
      "expanded_url" : "http:\/\/healthmonth.com",
      "display_url" : "healthmonth.com"
    }, {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/wphfiNlm",
      "expanded_url" : "http:\/\/thenextweb.com\/apps\/2011\/10\/22\/health-month-the-game-that-will-trick-you-into-a-healthier-lifestyle\/",
      "display_url" : "thenextweb.com\/apps\/2011\/10\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "127829826261364736",
  "text" : "A great overview of http:\/\/t.co\/UX1MtnBq from @TheNextWeb: http:\/\/t.co\/wphfiNlm (free prize inside too, for close readers)",
  "id" : 127829826261364736,
  "created_at" : "2011-10-22 19:33:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen M. Murray",
      "screen_name" : "allenmmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "22118364",
      "id" : 22118364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127622226873823233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6121738988, -122.3170485914 ]
  },
  "id_str" : "127623058193260544",
  "in_reply_to_user_id" : 22118364,
  "text" : "@allenmmurray Deception\/inauthenticity is required?",
  "id" : 127623058193260544,
  "in_reply_to_status_id" : 127622226873823233,
  "created_at" : "2011-10-22 05:51:22 +0000",
  "in_reply_to_screen_name" : "allenmmurray",
  "in_reply_to_user_id_str" : "22118364",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryce Roberts",
      "screen_name" : "bryce",
      "indices" : [ 0, 6 ],
      "id_str" : "6160742",
      "id" : 6160742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127620957002145792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6121047996, -122.3170849723 ]
  },
  "id_str" : "127622223937810433",
  "in_reply_to_user_id" : 6160742,
  "text" : "@bryce I agree but that requires steady hands and a steady mind, and is my night's riddle. PS apologies for the profanity. :)",
  "id" : 127622223937810433,
  "in_reply_to_status_id" : 127620957002145792,
  "created_at" : "2011-10-22 05:48:03 +0000",
  "in_reply_to_screen_name" : "bryce",
  "in_reply_to_user_id_str" : "6160742",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephdub",
      "screen_name" : "stephdub",
      "indices" : [ 0, 9 ],
      "id_str" : "14936359",
      "id" : 14936359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127620613849358337",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612144411, -122.317090722 ]
  },
  "id_str" : "127620839188332544",
  "in_reply_to_user_id" : 14936359,
  "text" : "@stephdub bingo is your nameo.",
  "id" : 127620839188332544,
  "in_reply_to_status_id" : 127620613849358337,
  "created_at" : "2011-10-22 05:42:33 +0000",
  "in_reply_to_screen_name" : "stephdub",
  "in_reply_to_user_id_str" : "14936359",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mat honan",
      "screen_name" : "mat",
      "indices" : [ 1, 5 ],
      "id_str" : "11113",
      "id" : 11113
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetkoan",
      "indices" : [ 65, 75 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127620287356342272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6121311416, -122.3170827921 ]
  },
  "id_str" : "127620617867509760",
  "in_reply_to_user_id" : 11113,
  "text" : ".@mat That might be the crack to the riddle: to do both at once. #tweetkoan",
  "id" : 127620617867509760,
  "in_reply_to_status_id" : 127620287356342272,
  "created_at" : "2011-10-22 05:41:41 +0000",
  "in_reply_to_screen_name" : "mat",
  "in_reply_to_user_id_str" : "11113",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6119768826, -122.3167645484 ]
  },
  "id_str" : "127620017176051712",
  "text" : "Solo bar time question to self: what's a better competitive advantage long term: not giving a shit or caring a fuck ton?",
  "id" : 127620017176051712,
  "created_at" : "2011-10-22 05:39:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Waldman",
      "screen_name" : "arielwaldman",
      "indices" : [ 3, 16 ],
      "id_str" : "814304",
      "id" : 814304
    }, {
      "name" : "Ben Ward",
      "screen_name" : "benward",
      "indices" : [ 52, 60 ],
      "id_str" : "12249",
      "id" : 12249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/29L8WoAA",
      "expanded_url" : "http:\/\/emoscience.tumblr.com\/",
      "display_url" : "emoscience.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "127615262873751552",
  "text" : "RT @arielwaldman: On this sad, lonely Friday night, @benward and I are launching a new tumblr called Emo Science: http:\/\/t.co\/29L8WoAA ( ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Ward",
        "screen_name" : "benward",
        "indices" : [ 34, 42 ],
        "id_str" : "12249",
        "id" : 12249
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/29L8WoAA",
        "expanded_url" : "http:\/\/emoscience.tumblr.com\/",
        "display_url" : "emoscience.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "127606980826251264",
    "text" : "On this sad, lonely Friday night, @benward and I are launching a new tumblr called Emo Science: http:\/\/t.co\/29L8WoAA (submissions welcome!)",
    "id" : 127606980826251264,
    "created_at" : "2011-10-22 04:47:29 +0000",
    "user" : {
      "name" : "Ariel Waldman",
      "screen_name" : "arielwaldman",
      "protected" : false,
      "id_str" : "814304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2530407461\/xujyyx9bdf3wi65o5a60_normal.jpeg",
      "id" : 814304,
      "verified" : false
    }
  },
  "id" : 127615262873751552,
  "created_at" : "2011-10-22 05:20:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/Ae7NbpVo",
      "expanded_url" : "http:\/\/flic.kr\/p\/axV9eL",
      "display_url" : "flic.kr\/p\/axV9eL"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608833, -122.306334 ]
  },
  "id_str" : "127599545659047936",
  "text" : "8:36pm Going out by myself, hoping the white noise fades away a tiny bit http:\/\/t.co\/Ae7NbpVo",
  "id" : 127599545659047936,
  "created_at" : "2011-10-22 04:17:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6084884275, -122.3060702415 ]
  },
  "id_str" : "127586797172695040",
  "text" : "In the battle between parenting and entrepreneuring to exhaust me on a daily basis, the former rarely wins. But today is one of those days.",
  "id" : 127586797172695040,
  "created_at" : "2011-10-22 03:27:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/8g8ugrdY",
      "expanded_url" : "http:\/\/instagr.am\/p\/Q8FJ6\/",
      "display_url" : "instagr.am\/p\/Q8FJ6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "127501854337794050",
  "text" : "Niko opted for watching The Great Punpkin over and over instead of napping today http:\/\/t.co\/8g8ugrdY",
  "id" : 127501854337794050,
  "created_at" : "2011-10-21 21:49:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daring Fireball",
      "screen_name" : "daringfireball",
      "indices" : [ 3, 18 ],
      "id_str" : "10760422",
      "id" : 10760422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/xj6PM8UR",
      "expanded_url" : "http:\/\/df4.us\/iif",
      "display_url" : "df4.us\/iif"
    } ]
  },
  "geo" : { },
  "id_str" : "127460977116590081",
  "text" : "RT @daringfireball: Pre-Order \u2018Steve Jobs\u2019 From Amazon: http:\/\/t.co\/xj6PM8UR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/daringfireball.net\/\" rel=\"nofollow\"\u003EDF Tootbot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/xj6PM8UR",
        "expanded_url" : "http:\/\/df4.us\/iif",
        "display_url" : "df4.us\/iif"
      } ]
    },
    "geo" : { },
    "id_str" : "127413852341141504",
    "text" : "Pre-Order \u2018Steve Jobs\u2019 From Amazon: http:\/\/t.co\/xj6PM8UR",
    "id" : 127413852341141504,
    "created_at" : "2011-10-21 16:00:04 +0000",
    "user" : {
      "name" : "Daring Fireball",
      "screen_name" : "daringfireball",
      "protected" : false,
      "id_str" : "10760422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425948730\/DF-Star-Logo_normal.png",
      "id" : 10760422,
      "verified" : false
    }
  },
  "id" : 127460977116590081,
  "created_at" : "2011-10-21 19:07:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/MTCsvtva",
      "expanded_url" : "http:\/\/flic.kr\/p\/axF4jq",
      "display_url" : "flic.kr\/p\/axF4jq"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.617333, -122.3355 ]
  },
  "id_str" : "127230099530592256",
  "text" : "8:36pm Walking home with my shadow http:\/\/t.co\/MTCsvtva",
  "id" : 127230099530592256,
  "created_at" : "2011-10-21 03:49:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 3, 12 ],
      "id_str" : "15391002",
      "id" : 15391002
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 139, 140 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/niY7ydGO",
      "expanded_url" : "http:\/\/750words.com\/",
      "display_url" : "750words.com"
    } ]
  },
  "geo" : { },
  "id_str" : "127051492489297920",
  "text" : "RT @askotzko: http:\/\/t.co\/niY7ydGO This is my favorite \"bike for the mind\" If you do it consistently, you'll get deep but subtle value \/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 125, 138 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/niY7ydGO",
        "expanded_url" : "http:\/\/750words.com\/",
        "display_url" : "750words.com"
      } ]
    },
    "geo" : { },
    "id_str" : "127030464899842049",
    "text" : "http:\/\/t.co\/niY7ydGO This is my favorite \"bike for the mind\" If you do it consistently, you'll get deep but subtle value \/cc @busterbenson",
    "id" : 127030464899842049,
    "created_at" : "2011-10-20 14:36:37 +0000",
    "user" : {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "protected" : false,
      "id_str" : "15391002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000674361046\/2c9f86caa5294db467ef97a4fed128bf_normal.jpeg",
      "id" : 15391002,
      "verified" : false
    }
  },
  "id" : 127051492489297920,
  "created_at" : "2011-10-20 16:00:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/0e2EkU74",
      "expanded_url" : "http:\/\/flic.kr\/p\/axqz19",
      "display_url" : "flic.kr\/p\/axqz19"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608833, -122.306167 ]
  },
  "id_str" : "126870980298682368",
  "text" : "8:36pm Brain all used up. Watching Tenure on our brand new internets. http:\/\/t.co\/0e2EkU74",
  "id" : 126870980298682368,
  "created_at" : "2011-10-20 04:02:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Oberholtzer",
      "screen_name" : "ilovecharts",
      "indices" : [ 48, 60 ],
      "id_str" : "116498184",
      "id" : 116498184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/NFcB8vyn",
      "expanded_url" : "http:\/\/ilovecharts.tumblr.com\/post\/11673119659\/life-complex-plane",
      "display_url" : "ilovecharts.tumblr.com\/post\/116731196\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "126828835105816577",
  "text" : "Life's complex plane: http:\/\/t.co\/NFcB8vyn \/via @ilovecharts",
  "id" : 126828835105816577,
  "created_at" : "2011-10-20 01:15:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QuantifiedSelf",
      "indices" : [ 37, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/947WUHDZ",
      "expanded_url" : "http:\/\/www.meetup.com\/Quantified-Self-Seattle\/events\/36589652\/",
      "display_url" : "meetup.com\/Quantified-Sel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "126796408970940416",
  "text" : "Mark your calenders! The 3rd Seattle #QuantifiedSelf Meetup is a week from today! RSVP: http:\/\/t.co\/947WUHDZ",
  "id" : 126796408970940416,
  "created_at" : "2011-10-19 23:06:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mat honan",
      "screen_name" : "mat",
      "indices" : [ 0, 4 ],
      "id_str" : "11113",
      "id" : 11113
    }, {
      "name" : "April V. Walters",
      "screen_name" : "aprilini",
      "indices" : [ 38, 47 ],
      "id_str" : "875511",
      "id" : 875511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126792705073360896",
  "geo" : { },
  "id_str" : "126794556070047744",
  "in_reply_to_user_id" : 11113,
  "text" : "@mat Awesome! Sent you an email.  \/cc @aprilini",
  "id" : 126794556070047744,
  "in_reply_to_status_id" : 126792705073360896,
  "created_at" : "2011-10-19 22:59:12 +0000",
  "in_reply_to_screen_name" : "mat",
  "in_reply_to_user_id_str" : "11113",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mat honan",
      "screen_name" : "mat",
      "indices" : [ 0, 4 ],
      "id_str" : "11113",
      "id" : 11113
    }, {
      "name" : "April V. Walters",
      "screen_name" : "aprilini",
      "indices" : [ 5, 14 ],
      "id_str" : "875511",
      "id" : 875511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126727607340367872",
  "geo" : { },
  "id_str" : "126791858553765888",
  "in_reply_to_user_id" : 875511,
  "text" : "@mat @aprilini Fitmodo looks awesome. Count me in. Let me know if I can help.",
  "id" : 126791858553765888,
  "in_reply_to_status_id" : 126727607340367872,
  "created_at" : "2011-10-19 22:48:29 +0000",
  "in_reply_to_screen_name" : "aprilini",
  "in_reply_to_user_id_str" : "875511",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/9kdmvflt",
      "expanded_url" : "http:\/\/blog.habitlabs.com\/post\/11668222203",
      "display_url" : "blog.habitlabs.com\/post\/116682222\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "126785573494071297",
  "text" : "Hello, Habit City: http:\/\/t.co\/9kdmvflt",
  "id" : 126785573494071297,
  "created_at" : "2011-10-19 22:23:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/eDn34jb5",
      "expanded_url" : "http:\/\/flic.kr\/p\/ax9V99",
      "display_url" : "flic.kr\/p\/ax9V99"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6155, -122.320167 ]
  },
  "id_str" : "126508568747839488",
  "text" : "8:36pm Singing Joey for extra points http:\/\/t.co\/eDn34jb5",
  "id" : 126508568747839488,
  "created_at" : "2011-10-19 04:02:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trapper Markelz",
      "screen_name" : "trappermarkelz",
      "indices" : [ 3, 18 ],
      "id_str" : "1032241",
      "id" : 1032241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/RK9obici",
      "expanded_url" : "http:\/\/bit.ly\/pzGh79",
      "display_url" : "bit.ly\/pzGh79"
    } ]
  },
  "geo" : { },
  "id_str" : "126171169714995200",
  "text" : "RT @trappermarkelz: Feynman's \"Rules of Chess\" - http:\/\/t.co\/RK9obici - Brilliance.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/RK9obici",
        "expanded_url" : "http:\/\/bit.ly\/pzGh79",
        "display_url" : "bit.ly\/pzGh79"
      } ]
    },
    "geo" : { },
    "id_str" : "126083086390804480",
    "text" : "Feynman's \"Rules of Chess\" - http:\/\/t.co\/RK9obici - Brilliance.",
    "id" : 126083086390804480,
    "created_at" : "2011-10-17 23:52:04 +0000",
    "user" : {
      "name" : "Trapper Markelz",
      "screen_name" : "trappermarkelz",
      "protected" : false,
      "id_str" : "1032241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3025341826\/2d7fa654f59dac4badbb416d8a267625_normal.jpeg",
      "id" : 1032241,
      "verified" : false
    }
  },
  "id" : 126171169714995200,
  "created_at" : "2011-10-18 05:42:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rachelsmiles",
      "screen_name" : "rachelsmiles",
      "indices" : [ 0, 13 ],
      "id_str" : "11577462",
      "id" : 11577462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126130644140048384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086266796, -122.3060144287 ]
  },
  "id_str" : "126169801763725312",
  "in_reply_to_user_id" : 11577462,
  "text" : "@rachelsmiles That would definitely make me cry. But now I have a goal to work towards!",
  "id" : 126169801763725312,
  "in_reply_to_status_id" : 126130644140048384,
  "created_at" : "2011-10-18 05:36:39 +0000",
  "in_reply_to_screen_name" : "rachelsmiles",
  "in_reply_to_user_id_str" : "11577462",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Dawson",
      "screen_name" : "jeffybrite",
      "indices" : [ 0, 11 ],
      "id_str" : "35402650",
      "id" : 35402650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126159185795751937",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085822118, -122.3060991436 ]
  },
  "id_str" : "126169614131527680",
  "in_reply_to_user_id" : 35402650,
  "text" : "@jeffybrite Ooh I'll check it out. Does it get into neurotransmitters and such?",
  "id" : 126169614131527680,
  "in_reply_to_status_id" : 126159185795751937,
  "created_at" : "2011-10-18 05:35:54 +0000",
  "in_reply_to_screen_name" : "jeffybrite",
  "in_reply_to_user_id_str" : "35402650",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/HTPhfzLZ",
      "expanded_url" : "http:\/\/flic.kr\/p\/awPsXi",
      "display_url" : "flic.kr\/p\/awPsXi"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "126146510437105665",
  "text" : "8:36pm Amelia and Adam came over to give me cooking lessons! http:\/\/t.co\/HTPhfzLZ",
  "id" : 126146510437105665,
  "created_at" : "2011-10-18 04:04:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/tLxkOLKy",
      "expanded_url" : "http:\/\/itunes.apple.com\/us\/app\/fitbit-activity-calorie-tracker\/id462638897",
      "display_url" : "itunes.apple.com\/us\/app\/fitbit-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "126082795142524928",
  "text" : "RT @fonetik: Use Fitbit? Have an iPhone? We made an app for that. http:\/\/t.co\/tLxkOLKy Just a basic v1.0 but the future is wide open!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/tLxkOLKy",
        "expanded_url" : "http:\/\/itunes.apple.com\/us\/app\/fitbit-activity-calorie-tracker\/id462638897",
        "display_url" : "itunes.apple.com\/us\/app\/fitbit-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "126053816931065856",
    "text" : "Use Fitbit? Have an iPhone? We made an app for that. http:\/\/t.co\/tLxkOLKy Just a basic v1.0 but the future is wide open!",
    "id" : 126053816931065856,
    "created_at" : "2011-10-17 21:55:46 +0000",
    "user" : {
      "name" : "barry burton",
      "screen_name" : "barrycburton",
      "protected" : false,
      "id_str" : "26374915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2632816314\/ec8b30285709f4473b99b75c094a9635_normal.png",
      "id" : 26374915,
      "verified" : false
    }
  },
  "id" : 126082795142524928,
  "created_at" : "2011-10-17 23:50:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085944774, -122.3061207492 ]
  },
  "id_str" : "126051225455165441",
  "text" : "What does dopamine feel like? \n\nLike that \"can't stop my hand\" feeling in between potato chips, chocolate covered almonds, fries...",
  "id" : 126051225455165441,
  "created_at" : "2011-10-17 21:45:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126038454072127488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608614679, -122.3064647919 ]
  },
  "id_str" : "126041217141194752",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit That's what I was thinking too! Surprisingly tough, and quick! Might have to get everyone's baseline next week. :)",
  "id" : 126041217141194752,
  "in_reply_to_status_id" : 126038454072127488,
  "created_at" : "2011-10-17 21:05:42 +0000",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judi",
      "screen_name" : "judidec",
      "indices" : [ 0, 8 ],
      "id_str" : "29344406",
      "id" : 29344406
    }, {
      "name" : "rachelsmiles",
      "screen_name" : "rachelsmiles",
      "indices" : [ 9, 22 ],
      "id_str" : "11577462",
      "id" : 11577462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126038793127084033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086240158, -122.3062599602 ]
  },
  "id_str" : "126040934000508929",
  "in_reply_to_user_id" : 29344406,
  "text" : "@judidec @rachelsmiles That would be fun. Might be possible if there were daycare options.",
  "id" : 126040934000508929,
  "in_reply_to_status_id" : 126038793127084033,
  "created_at" : "2011-10-17 21:04:35 +0000",
  "in_reply_to_screen_name" : "judidec",
  "in_reply_to_user_id_str" : "29344406",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/oOe43Yhx",
      "expanded_url" : "http:\/\/www.notyouraveragefitnesstips.com\/six-pack-abs\/how-to-get-washboard-abs-plank-exercises-no-more-crunches",
      "display_url" : "notyouraveragefitnesstips.com\/six-pack-abs\/h\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608710399, -122.305845909 ]
  },
  "id_str" : "126034296170491904",
  "text" : "Wow, planks are tough! Just tried it and barely got to 2 minutes. How long can you go? http:\/\/t.co\/oOe43Yhx",
  "id" : 126034296170491904,
  "created_at" : "2011-10-17 20:38:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086509857, -122.3064733649 ]
  },
  "id_str" : "126022009758031872",
  "text" : "@atownsend0824 That's awesome! Congratulations!",
  "id" : 126022009758031872,
  "created_at" : "2011-10-17 19:49:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/instagram\/id389801252?mt=8&uo=4\" rel=\"nofollow\"\u003EInstagram on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaileen Elise",
      "screen_name" : "kaileenelise",
      "indices" : [ 10, 23 ],
      "id_str" : "32439209",
      "id" : 32439209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/UXCYBb9J",
      "expanded_url" : "http:\/\/750words.com",
      "display_url" : "750words.com"
    }, {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/ew6lYcG5",
      "expanded_url" : "http:\/\/instagr.am\/p\/QbJOf\/",
      "display_url" : "instagr.am\/p\/QbJOf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "125731702231400448",
  "text" : "Thank you @kaileenelise for catching this mention of http:\/\/t.co\/UXCYBb9J in O Magazine: http:\/\/t.co\/ew6lYcG5",
  "id" : 125731702231400448,
  "created_at" : "2011-10-17 00:35:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaileen Elise",
      "screen_name" : "kaileenelise",
      "indices" : [ 0, 13 ],
      "id_str" : "32439209",
      "id" : 32439209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125710928531558401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085644565, -122.306259589 ]
  },
  "id_str" : "125713126883721216",
  "in_reply_to_user_id" : 32439209,
  "text" : "@kaileenelise Wow that's cool! Which edition? Can you take a picture of it?",
  "id" : 125713126883721216,
  "in_reply_to_status_id" : 125710928531558401,
  "created_at" : "2011-10-16 23:21:59 +0000",
  "in_reply_to_screen_name" : "kaileenelise",
  "in_reply_to_user_id_str" : "32439209",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 3, 14 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/O1TtfwPJ",
      "expanded_url" : "http:\/\/techcrunch.com\/2011\/10\/16\/iphone-siri\/",
      "display_url" : "techcrunch.com\/2011\/10\/16\/iph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "125703495230828544",
  "text" : "RT @parislemon: some bigger picture thoughts on Siri, what it ultimately means, and why we care -- Why So\u00A0Siri-ous? http:\/\/t.co\/O1TtfwPJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/O1TtfwPJ",
        "expanded_url" : "http:\/\/techcrunch.com\/2011\/10\/16\/iphone-siri\/",
        "display_url" : "techcrunch.com\/2011\/10\/16\/iph\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "125700323401678848",
    "text" : "some bigger picture thoughts on Siri, what it ultimately means, and why we care -- Why So\u00A0Siri-ous? http:\/\/t.co\/O1TtfwPJ",
    "id" : 125700323401678848,
    "created_at" : "2011-10-16 22:31:07 +0000",
    "user" : {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "protected" : false,
      "id_str" : "652193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430498692018094081\/eNje7vMm_normal.jpeg",
      "id" : 652193,
      "verified" : true
    }
  },
  "id" : 125703495230828544,
  "created_at" : "2011-10-16 22:43:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eliza van gerbig",
      "screen_name" : "elizaIO",
      "indices" : [ 0, 8 ],
      "id_str" : "81391087",
      "id" : 81391087
    }, {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 9, 15 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125671134380310529",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6083531901, -122.3057055044 ]
  },
  "id_str" : "125698829352845312",
  "in_reply_to_user_id" : 81391087,
  "text" : "@elizaIO @sciam I think they have a different role in the gut, mostly to do with appetite regulation. I may be wrong.",
  "id" : 125698829352845312,
  "in_reply_to_status_id" : 125671134380310529,
  "created_at" : "2011-10-16 22:25:10 +0000",
  "in_reply_to_screen_name" : "elizaIO",
  "in_reply_to_user_id_str" : "81391087",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6084444238, -122.3061396681 ]
  },
  "id_str" : "125661043648245760",
  "text" : "In order to make or break a habit, you need to revolt against your subconscious. In order to keep a habit, you need to give in to it again.",
  "id" : 125661043648245760,
  "created_at" : "2011-10-16 19:55:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eliza van gerbig",
      "screen_name" : "elizaIO",
      "indices" : [ 0, 8 ],
      "id_str" : "81391087",
      "id" : 81391087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125635964243681280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085689769, -122.3064398293 ]
  },
  "id_str" : "125641913805189121",
  "in_reply_to_user_id" : 81391087,
  "text" : "@elizaIO I've heard that digesting seratonin and dopamine don't really have an impact... they don't make it back up to the brain.",
  "id" : 125641913805189121,
  "in_reply_to_status_id" : 125635964243681280,
  "created_at" : "2011-10-16 18:39:01 +0000",
  "in_reply_to_screen_name" : "elizaIO",
  "in_reply_to_user_id_str" : "81391087",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 40, 49 ],
      "id_str" : "817386",
      "id" : 817386
    }, {
      "name" : "Alexia Tsotsis",
      "screen_name" : "alexia",
      "indices" : [ 89, 96 ],
      "id_str" : "18327902",
      "id" : 18327902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/wC2wkwTa",
      "expanded_url" : "http:\/\/tcrn.ch\/n3R6Pe",
      "display_url" : "tcrn.ch\/n3R6Pe"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6084866889, -122.3063759824 ]
  },
  "id_str" : "125604716427218944",
  "text" : "Believe it or not, I like this idea! RT @Techmeme: Are Facebook ID Cards In Our Future? (@alexia \/ TechCrunch) http:\/\/t.co\/wC2wkwTa",
  "id" : 125604716427218944,
  "created_at" : "2011-10-16 16:11:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 46, 56 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/vT4kPj48",
      "expanded_url" : "http:\/\/flic.kr\/p\/awbmRs",
      "display_url" : "flic.kr\/p\/awbmRs"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614833, -122.328167 ]
  },
  "id_str" : "125419751714455552",
  "text" : "8:36pm Celebrating the birth of the beautiful @Kellianne! http:\/\/t.co\/vT4kPj48",
  "id" : 125419751714455552,
  "created_at" : "2011-10-16 03:56:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125393696039514112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087029205, -122.3062924839 ]
  },
  "id_str" : "125395162657603586",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne Did the sim get deactivated? That happened to Kellianne's phone and we had to take it to an AT&T store.",
  "id" : 125395162657603586,
  "in_reply_to_status_id" : 125393696039514112,
  "created_at" : "2011-10-16 02:18:31 +0000",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/ClV6KmJe",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/awesomer\/scared-bros-at-a-haunted-house",
      "display_url" : "buzzfeed.com\/awesomer\/scare\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "125304609337118721",
  "text" : "The look of surprise and fear is pretty consistent in these bros: http:\/\/t.co\/ClV6KmJe I want to know what's scaring them.",
  "id" : 125304609337118721,
  "created_at" : "2011-10-15 20:18:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 11, 21 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/XaAp3GsC",
      "expanded_url" : "http:\/\/flic.kr\/p\/avRnk6",
      "display_url" : "flic.kr\/p\/avRnk6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306 ]
  },
  "id_str" : "125057385860562944",
  "text" : "8:36pm Got @kellianne the new iPhone on my account, but can't switch it to her number after 2hrs of trying http:\/\/t.co\/XaAp3GsC",
  "id" : 125057385860562944,
  "created_at" : "2011-10-15 03:56:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Gilbert",
      "screen_name" : "MyBodyTutor",
      "indices" : [ 0, 12 ],
      "id_str" : "17905221",
      "id" : 17905221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124696991149211648",
  "geo" : { },
  "id_str" : "124698118817202177",
  "in_reply_to_user_id" : 17905221,
  "text" : "@MyBodyTutor Just me! Part of it is learning about how my brain reacts to change. :)",
  "id" : 124698118817202177,
  "in_reply_to_status_id" : 124696991149211648,
  "created_at" : "2011-10-14 04:08:42 +0000",
  "in_reply_to_screen_name" : "MyBodyTutor",
  "in_reply_to_user_id_str" : "17905221",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Culver",
      "screen_name" : "bahoo",
      "indices" : [ 3, 9 ],
      "id_str" : "13134132",
      "id" : 13134132
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 11, 24 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124696063176228864",
  "text" : "RT @bahoo: @busterbenson 'Force' is the perfect way to frame it. It's an upstream battle against years of evolutionary 'success.' Dig it.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "124691512285085697",
    "geo" : { },
    "id_str" : "124695878777843712",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson 'Force' is the perfect way to frame it. It's an upstream battle against years of evolutionary 'success.' Dig it.",
    "id" : 124695878777843712,
    "in_reply_to_status_id" : 124691512285085697,
    "created_at" : "2011-10-14 03:59:48 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Jon Culver",
      "screen_name" : "bahoo",
      "protected" : false,
      "id_str" : "13134132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428034453009473536\/uUrMvMiA_normal.jpeg",
      "id" : 13134132,
      "verified" : false
    }
  },
  "id" : 124696063176228864,
  "created_at" : "2011-10-14 04:00:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hi koo girl",
      "screen_name" : "haikugirl",
      "indices" : [ 0, 10 ],
      "id_str" : "580262124",
      "id" : 580262124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124695367978717184",
  "geo" : { },
  "id_str" : "124695879281152000",
  "in_reply_to_user_id" : 12761252,
  "text" : "@haikugirl I'm just trying salads out. I always wanted to start a movement to eat salads as meals. Except for the whole revolted part... :)",
  "id" : 124695879281152000,
  "in_reply_to_status_id" : 124695367978717184,
  "created_at" : "2011-10-14 03:59:49 +0000",
  "in_reply_to_screen_name" : "heatherquintal",
  "in_reply_to_user_id_str" : "12761252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hi koo girl",
      "screen_name" : "haikugirl",
      "indices" : [ 0, 10 ],
      "id_str" : "580262124",
      "id" : 580262124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124694259478695936",
  "geo" : { },
  "id_str" : "124694507152355328",
  "in_reply_to_user_id" : 12761252,
  "text" : "@haikugirl The salads are delicious, once I'm eating them. It's just the thought of them that's revolting. :) Some goes with running.",
  "id" : 124694507152355328,
  "in_reply_to_status_id" : 124694259478695936,
  "created_at" : "2011-10-14 03:54:21 +0000",
  "in_reply_to_screen_name" : "heatherquintal",
  "in_reply_to_user_id_str" : "12761252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/rr9yOekc",
      "expanded_url" : "http:\/\/bustr.tumblr.com\/post\/11424471411\/forcing-it",
      "display_url" : "bustr.tumblr.com\/post\/114244714\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "124691512285085697",
  "text" : "Tell me what you think of this post, on \"forcing\" new behaviors. http:\/\/t.co\/rr9yOekc",
  "id" : 124691512285085697,
  "created_at" : "2011-10-14 03:42:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/acAGZsm4",
      "expanded_url" : "http:\/\/flic.kr\/p\/avB2sx",
      "display_url" : "flic.kr\/p\/avB2sx"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.616166, -122.3375 ]
  },
  "id_str" : "124691342449328128",
  "text" : "8:36pm Finishing a blog post that got really weird by the end http:\/\/t.co\/acAGZsm4",
  "id" : 124691342449328128,
  "created_at" : "2011-10-14 03:41:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 3, 13 ],
      "id_str" : "10609",
      "id" : 10609
    }, {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 55, 64 ],
      "id_str" : "14986129",
      "id" : 14986129
    }, {
      "name" : "tagsavage",
      "screen_name" : "tagsavage",
      "indices" : [ 69, 79 ],
      "id_str" : "13119982",
      "id" : 13119982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/vT7Q4m60",
      "expanded_url" : "http:\/\/amitguptaneedsyou.com\/",
      "display_url" : "amitguptaneedsyou.com"
    } ]
  },
  "geo" : { },
  "id_str" : "124514622807085056",
  "text" : "RT @superamit: One big ole bear hug and a shout out to @irondavy and @tagsavage for designing this website for me \u2192 http:\/\/t.co\/vT7Q4m60",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Cole",
        "screen_name" : "irondavy",
        "indices" : [ 40, 49 ],
        "id_str" : "14986129",
        "id" : 14986129
      }, {
        "name" : "tagsavage",
        "screen_name" : "tagsavage",
        "indices" : [ 54, 64 ],
        "id_str" : "13119982",
        "id" : 13119982
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/vT7Q4m60",
        "expanded_url" : "http:\/\/amitguptaneedsyou.com\/",
        "display_url" : "amitguptaneedsyou.com"
      } ]
    },
    "geo" : { },
    "id_str" : "124514063412768769",
    "text" : "One big ole bear hug and a shout out to @irondavy and @tagsavage for designing this website for me \u2192 http:\/\/t.co\/vT7Q4m60",
    "id" : 124514063412768769,
    "created_at" : "2011-10-13 15:57:20 +0000",
    "user" : {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "protected" : false,
      "id_str" : "10609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2839151893\/f62ce69123d744f68381edfda11ed942_normal.jpeg",
      "id" : 10609,
      "verified" : false
    }
  },
  "id" : 124514622807085056,
  "created_at" : "2011-10-13 15:59:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/LOMQkM3Z",
      "expanded_url" : "http:\/\/tumblr.com\/Za7pnxAdGG7p",
      "display_url" : "tumblr.com\/Za7pnxAdGG7p"
    } ]
  },
  "geo" : { },
  "id_str" : "124507612514492416",
  "text" : "RT @habitlabs: Things people are saying about Habit Labs. - The press page. Now with quotations. http:\/\/t.co\/LOMQkM3Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/LOMQkM3Z",
        "expanded_url" : "http:\/\/tumblr.com\/Za7pnxAdGG7p",
        "display_url" : "tumblr.com\/Za7pnxAdGG7p"
      } ]
    },
    "geo" : { },
    "id_str" : "124501388947505152",
    "text" : "Things people are saying about Habit Labs. - The press page. Now with quotations. http:\/\/t.co\/LOMQkM3Z",
    "id" : 124501388947505152,
    "created_at" : "2011-10-13 15:06:58 +0000",
    "user" : {
      "name" : "Habit Labs",
      "screen_name" : "habitlabs_done",
      "protected" : false,
      "id_str" : "250986038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1496138143\/bad-logo_normal.png",
      "id" : 250986038,
      "verified" : false
    }
  },
  "id" : 124507612514492416,
  "created_at" : "2011-10-13 15:31:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Umami",
      "screen_name" : "joshumami",
      "indices" : [ 116, 126 ],
      "id_str" : "11815632",
      "id" : 11815632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/ppFbthWN",
      "expanded_url" : "http:\/\/www.gottabemobile.com\/2011\/10\/07\/iphone-4s-siri-bluetooth-4-0-awesome-smart-watch\/",
      "display_url" : "gottabemobile.com\/2011\/10\/07\/iph\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086965519, -122.3060221119 ]
  },
  "id_str" : "124364235106037760",
  "text" : "Siri + Bluetooth 4.0 + smart watches or in ear headsets? I'm not the only one daydreaming: http:\/\/t.co\/ppFbthWN \/cc @joshumami",
  "id" : 124364235106037760,
  "created_at" : "2011-10-13 06:01:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Umami",
      "screen_name" : "joshumami",
      "indices" : [ 0, 10 ],
      "id_str" : "11815632",
      "id" : 11815632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124359264725774336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608539847, -122.306000865 ]
  },
  "id_str" : "124360595314192384",
  "in_reply_to_user_id" : 11815632,
  "text" : "@joshumami I definitely will. Siri is the killer feature for me to make the jump.",
  "id" : 124360595314192384,
  "in_reply_to_status_id" : 124359264725774336,
  "created_at" : "2011-10-13 05:47:31 +0000",
  "in_reply_to_screen_name" : "joshumami",
  "in_reply_to_user_id_str" : "11815632",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Umami",
      "screen_name" : "joshumami",
      "indices" : [ 0, 10 ],
      "id_str" : "11815632",
      "id" : 11815632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124358145245069314",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085781144, -122.3058966187 ]
  },
  "id_str" : "124358799413870592",
  "in_reply_to_user_id" : 11815632,
  "text" : "@joshumami Which Bose headsets do you recommend?",
  "id" : 124358799413870592,
  "in_reply_to_status_id" : 124358145245069314,
  "created_at" : "2011-10-13 05:40:22 +0000",
  "in_reply_to_screen_name" : "joshumami",
  "in_reply_to_user_id_str" : "11815632",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Umami",
      "screen_name" : "joshumami",
      "indices" : [ 0, 10 ],
      "id_str" : "11815632",
      "id" : 11815632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086342288, -122.3060745848 ]
  },
  "id_str" : "124357899727290368",
  "in_reply_to_user_id" : 11815632,
  "text" : "@joshumami Thanks for the tips. Was there a way to trigger voice control mode from the headset or did it have to be triggered on phone?",
  "id" : 124357899727290368,
  "created_at" : "2011-10-13 05:36:48 +0000",
  "in_reply_to_screen_name" : "joshumami",
  "in_reply_to_user_id_str" : "11815632",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Umami",
      "screen_name" : "joshumami",
      "indices" : [ 0, 10 ],
      "id_str" : "11815632",
      "id" : 11815632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124349433918914560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086059316, -122.3057104128 ]
  },
  "id_str" : "124350568440414208",
  "in_reply_to_user_id" : 11815632,
  "text" : "@joshumami Lastly, do you think it'll work smoothly with Siri integration in iPhone 4S? Can you imagine an easy way to speak to Siri?",
  "id" : 124350568440414208,
  "in_reply_to_status_id" : 124349433918914560,
  "created_at" : "2011-10-13 05:07:40 +0000",
  "in_reply_to_screen_name" : "joshumami",
  "in_reply_to_user_id_str" : "11815632",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Umami",
      "screen_name" : "joshumami",
      "indices" : [ 0, 10 ],
      "id_str" : "11815632",
      "id" : 11815632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124349433918914560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085542465, -122.3059515824 ]
  },
  "id_str" : "124350159466397698",
  "in_reply_to_user_id" : 11815632,
  "text" : "@joshumami Thanks! 1) how much does Bluetooth affect battery life? 2) do you like it\/use it often? 3) can you talk into it?",
  "id" : 124350159466397698,
  "in_reply_to_status_id" : 124349433918914560,
  "created_at" : "2011-10-13 05:06:02 +0000",
  "in_reply_to_screen_name" : "joshumami",
  "in_reply_to_user_id_str" : "11815632",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/sxDb3yqs",
      "expanded_url" : "http:\/\/flic.kr\/p\/avoArU",
      "display_url" : "flic.kr\/p\/avoArU"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306 ]
  },
  "id_str" : "124328879010746369",
  "text" : "8:36pm I'm that guy who comes home too late to say goodnight to his son this week http:\/\/t.co\/sxDb3yqs",
  "id" : 124328879010746369,
  "created_at" : "2011-10-13 03:41:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "k.",
      "screen_name" : "kstar",
      "indices" : [ 0, 6 ],
      "id_str" : "2038",
      "id" : 2038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124221350402473985",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6144397544, -122.3164364937 ]
  },
  "id_str" : "124319723616874497",
  "in_reply_to_user_id" : 2038,
  "text" : "@kstar Yes! I'll dm you our new address!",
  "id" : 124319723616874497,
  "in_reply_to_status_id" : 124221350402473985,
  "created_at" : "2011-10-13 03:05:06 +0000",
  "in_reply_to_screen_name" : "kstar",
  "in_reply_to_user_id_str" : "2038",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6140331412, -122.3175004637 ]
  },
  "id_str" : "124319403843141632",
  "text" : "Is anyone who has used the Jawbone Bluetooth headset with an iPhone willing to answer some of my naive questions about how it all works?",
  "id" : 124319403843141632,
  "created_at" : "2011-10-13 03:03:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daring Fireball",
      "screen_name" : "daringfireball",
      "indices" : [ 3, 18 ],
      "id_str" : "10760422",
      "id" : 10760422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/4sV0PVyN",
      "expanded_url" : "http:\/\/df4.us\/ifs",
      "display_url" : "df4.us\/ifs"
    } ]
  },
  "geo" : { },
  "id_str" : "124026678010839040",
  "text" : "RT @daringfireball: \u2605 The iPhone 4S: http:\/\/t.co\/4sV0PVyN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/daringfireball.net\/\" rel=\"nofollow\"\u003EDF Tootbot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 37 ],
        "url" : "http:\/\/t.co\/4sV0PVyN",
        "expanded_url" : "http:\/\/df4.us\/ifs",
        "display_url" : "df4.us\/ifs"
      } ]
    },
    "geo" : { },
    "id_str" : "124008915296993280",
    "text" : "\u2605 The iPhone 4S: http:\/\/t.co\/4sV0PVyN",
    "id" : 124008915296993280,
    "created_at" : "2011-10-12 06:30:04 +0000",
    "user" : {
      "name" : "Daring Fireball",
      "screen_name" : "daringfireball",
      "protected" : false,
      "id_str" : "10760422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425948730\/DF-Star-Logo_normal.png",
      "id" : 10760422,
      "verified" : false
    }
  },
  "id" : 124026678010839040,
  "created_at" : "2011-10-12 07:40:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124000257796349952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085012445, -122.3065347191 ]
  },
  "id_str" : "124003562199056384",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb You should've sold it to Apple so they could build the 4SC.",
  "id" : 124003562199056384,
  "in_reply_to_status_id" : 124000257796349952,
  "created_at" : "2011-10-12 06:08:47 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeVore",
      "screen_name" : "crashdev",
      "indices" : [ 3, 12 ],
      "id_str" : "14763501",
      "id" : 14763501
    }, {
      "name" : "Romotive",
      "screen_name" : "Romotive",
      "indices" : [ 89, 98 ],
      "id_str" : "340545195",
      "id" : 340545195
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 99, 112 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    }, {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 113, 124 ],
      "id_str" : "14258044",
      "id" : 14258044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/yItvJq07",
      "expanded_url" : "http:\/\/crashdev.blogspot.com\/2011\/10\/are.html",
      "display_url" : "crashdev.blogspot.com\/2011\/10\/are.ht\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "123992812533448704",
  "text" : "RT @crashdev: Smartphones are the Singularity on little cat feet http:\/\/t.co\/yItvJq07 cc @romotive @busterbenson @jensmccabe",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Romotive",
        "screen_name" : "Romotive",
        "indices" : [ 75, 84 ],
        "id_str" : "340545195",
        "id" : 340545195
      }, {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 85, 98 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      }, {
        "name" : "Jen S. McCabe",
        "screen_name" : "jensmccabe",
        "indices" : [ 99, 110 ],
        "id_str" : "14258044",
        "id" : 14258044
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/yItvJq07",
        "expanded_url" : "http:\/\/crashdev.blogspot.com\/2011\/10\/are.html",
        "display_url" : "crashdev.blogspot.com\/2011\/10\/are.ht\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "123987811127926784",
    "text" : "Smartphones are the Singularity on little cat feet http:\/\/t.co\/yItvJq07 cc @romotive @busterbenson @jensmccabe",
    "id" : 123987811127926784,
    "created_at" : "2011-10-12 05:06:12 +0000",
    "user" : {
      "name" : "Chris DeVore",
      "screen_name" : "crashdev",
      "protected" : false,
      "id_str" : "14763501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1575672961\/CHD_Headshot_normal.png",
      "id" : 14763501,
      "verified" : false
    }
  },
  "id" : 123992812533448704,
  "created_at" : "2011-10-12 05:26:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 130, 139 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6084686729, -122.3065526029 ]
  },
  "id_str" : "123988719702249473",
  "text" : "I'm super excited about the iPhone 4S Siri stuff, but the *real question* is will it be smarter than the Subservient Chicken? \/cc @rickwebb",
  "id" : 123988719702249473,
  "created_at" : "2011-10-12 05:09:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 16, 29 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    }, {
      "name" : "Marie Forleo",
      "screen_name" : "marieforleo",
      "indices" : [ 70, 82 ],
      "id_str" : "16527415",
      "id" : 16527415
    }, {
      "name" : "Enjoymentland",
      "screen_name" : "enjoymentland",
      "indices" : [ 123, 137 ],
      "id_str" : "19808652",
      "id" : 19808652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/CmIKYPhK",
      "expanded_url" : "http:\/\/bit.ly\/pC8wCZ",
      "display_url" : "bit.ly\/pC8wCZ"
    } ]
  },
  "geo" : { },
  "id_str" : "123986510780432384",
  "text" : "RT @willotoons: @busterbenson Hey, look! 750 Words got a shout out on @marieforleo's Q&A Tuesday! http:\/\/t.co\/CmIKYPhK \/cc @enjoymentland",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      }, {
        "name" : "Marie Forleo",
        "screen_name" : "marieforleo",
        "indices" : [ 54, 66 ],
        "id_str" : "16527415",
        "id" : 16527415
      }, {
        "name" : "Enjoymentland",
        "screen_name" : "enjoymentland",
        "indices" : [ 107, 121 ],
        "id_str" : "19808652",
        "id" : 19808652
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/CmIKYPhK",
        "expanded_url" : "http:\/\/bit.ly\/pC8wCZ",
        "display_url" : "bit.ly\/pC8wCZ"
      } ]
    },
    "geo" : { },
    "id_str" : "123969026627080192",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson Hey, look! 750 Words got a shout out on @marieforleo's Q&A Tuesday! http:\/\/t.co\/CmIKYPhK \/cc @enjoymentland",
    "id" : 123969026627080192,
    "created_at" : "2011-10-12 03:51:33 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloLovesYou",
      "protected" : false,
      "id_str" : "772386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2930312012\/24cc863895bcac53f983496ff9c1712d_normal.png",
      "id" : 772386,
      "verified" : false
    }
  },
  "id" : 123986510780432384,
  "created_at" : "2011-10-12 05:01:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 99, 112 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6093780564, -122.3062488423 ]
  },
  "id_str" : "123986393520291841",
  "text" : "Thank you! 200 days is amazing! RT @derellique: I just completed 200 day's of consecutive writing. @busterbenson your program is incredible!",
  "id" : 123986393520291841,
  "created_at" : "2011-10-12 05:00:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloToons",
      "indices" : [ 0, 11 ],
      "id_str" : "1099629326",
      "id" : 1099629326
    }, {
      "name" : "Marie Forleo",
      "screen_name" : "marieforleo",
      "indices" : [ 98, 110 ],
      "id_str" : "16527415",
      "id" : 16527415
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "750words",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123969026627080192",
  "geo" : { },
  "id_str" : "123971892779552769",
  "in_reply_to_user_id" : 772386,
  "text" : "@willotoons That's awesome (and explains the traffic bump). Thx for passing it on. And thank you, @marieforleo, for the mention. #750words",
  "id" : 123971892779552769,
  "in_reply_to_status_id" : 123969026627080192,
  "created_at" : "2011-10-12 04:02:57 +0000",
  "in_reply_to_screen_name" : "WilloLovesYou",
  "in_reply_to_user_id_str" : "772386",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 23, 33 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/IzmeclDO",
      "expanded_url" : "http:\/\/And7YearsAgram.com",
      "display_url" : "And7YearsAgram.com"
    } ]
  },
  "geo" : { },
  "id_str" : "123958160175267840",
  "text" : "Neat way to re-see the @instagram photos you took exactly a year ago: http:\/\/t.co\/IzmeclDO",
  "id" : 123958160175267840,
  "created_at" : "2011-10-12 03:08:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/VebfoOlw",
      "expanded_url" : "http:\/\/blog.habitlabs.com\/post\/11328627947\/1-week-down-12-to-go",
      "display_url" : "blog.habitlabs.com\/post\/113286279\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "123868109269516288",
  "text" : "1 week down, 12 to go! http:\/\/t.co\/VebfoOlw\n\nDown .5lbs since last week...",
  "id" : 123868109269516288,
  "created_at" : "2011-10-11 21:10:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ouch",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123628854760849408",
  "text" : "Working with converting between multiple time zones, and doing calculations between them, has once again reduced my brain to mush. #ouch",
  "id" : 123628854760849408,
  "created_at" : "2011-10-11 05:19:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Sifers",
      "screen_name" : "halfshadows",
      "indices" : [ 0, 12 ],
      "id_str" : "4267",
      "id" : 4267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123618397438226432",
  "geo" : { },
  "id_str" : "123618839790485504",
  "in_reply_to_user_id" : 4267,
  "text" : "@halfshadows Not yet, but it is planned.",
  "id" : 123618839790485504,
  "in_reply_to_status_id" : 123618397438226432,
  "created_at" : "2011-10-11 04:40:02 +0000",
  "in_reply_to_screen_name" : "halfshadows",
  "in_reply_to_user_id_str" : "4267",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/AJabfJOP",
      "expanded_url" : "http:\/\/flic.kr\/p\/auPqku",
      "display_url" : "flic.kr\/p\/auPqku"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.617, -122.3375 ]
  },
  "id_str" : "123604247555211265",
  "text" : "8:36pm Working late, in the zone. Here are a few random things on my desk. http:\/\/t.co\/AJabfJOP",
  "id" : 123604247555211265,
  "created_at" : "2011-10-11 03:42:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123603399865405440",
  "text" : "Do you think the mental work of writing code for years decreases or increases the risk of eventually getting Alzheimer's?",
  "id" : 123603399865405440,
  "created_at" : "2011-10-11 03:38:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Broderick",
      "screen_name" : "MichelleBee",
      "indices" : [ 0, 12 ],
      "id_str" : "1059951",
      "id" : 1059951
    }, {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 36, 48 ],
      "id_str" : "30801469",
      "id" : 30801469
    }, {
      "name" : "Ignite NYC",
      "screen_name" : "ignitenyc",
      "indices" : [ 127, 137 ],
      "id_str" : "15987336",
      "id" : 15987336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123568912305627136",
  "geo" : { },
  "id_str" : "123569866920828929",
  "in_reply_to_user_id" : 1059951,
  "text" : "@MichelleBee Well I AM a BIG fan of @nickcrocker, and would love to spar over the finer points of behavior change any day. \/cc @ignitenyc",
  "id" : 123569866920828929,
  "in_reply_to_status_id" : 123568912305627136,
  "created_at" : "2011-10-11 01:25:26 +0000",
  "in_reply_to_screen_name" : "MichelleBee",
  "in_reply_to_user_id_str" : "1059951",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Broderick",
      "screen_name" : "MichelleBee",
      "indices" : [ 0, 12 ],
      "id_str" : "1059951",
      "id" : 1059951
    }, {
      "name" : "Ignite NYC",
      "screen_name" : "ignitenyc",
      "indices" : [ 13, 23 ],
      "id_str" : "15987336",
      "id" : 15987336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123565982584274944",
  "geo" : { },
  "id_str" : "123566694261194752",
  "in_reply_to_user_id" : 1059951,
  "text" : "@MichelleBee @ignitenyc I strongly disagree w\/both. Losing something, framed another way, can be a gift, or it can be freeing. Who's talk?",
  "id" : 123566694261194752,
  "in_reply_to_status_id" : 123565982584274944,
  "created_at" : "2011-10-11 01:12:50 +0000",
  "in_reply_to_screen_name" : "MichelleBee",
  "in_reply_to_user_id_str" : "1059951",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 3, 14 ],
      "id_str" : "14258044",
      "id" : 14258044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/0NlS8UMj",
      "expanded_url" : "http:\/\/seattlebeta.eventbrite.com\/?discount=demoguest",
      "display_url" : "seattlebeta.eventbrite.com\/?discount=demo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "123486462619549697",
  "text" : "RT @jensmccabe: come hang with team Habit Labs tomorrow night at Seattle Beta: http:\/\/t.co\/0NlS8UMj",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/0NlS8UMj",
        "expanded_url" : "http:\/\/seattlebeta.eventbrite.com\/?discount=demoguest",
        "display_url" : "seattlebeta.eventbrite.com\/?discount=demo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "123486009693437952",
    "text" : "come hang with team Habit Labs tomorrow night at Seattle Beta: http:\/\/t.co\/0NlS8UMj",
    "id" : 123486009693437952,
    "created_at" : "2011-10-10 19:52:13 +0000",
    "user" : {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "protected" : false,
      "id_str" : "14258044",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438553368126976000\/rsowSJ7F_normal.jpeg",
      "id" : 14258044,
      "verified" : false
    }
  },
  "id" : 123486462619549697,
  "created_at" : "2011-10-10 19:54:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/6yrEaBU4",
      "expanded_url" : "http:\/\/flic.kr\/p\/aupmHK",
      "display_url" : "flic.kr\/p\/aupmHK"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608833, -122.3065 ]
  },
  "id_str" : "123241216912531457",
  "text" : "8:36pm Refactoring some thoughts, like a nerd http:\/\/t.co\/6yrEaBU4",
  "id" : 123241216912531457,
  "created_at" : "2011-10-10 03:39:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "indices" : [ 3, 9 ],
      "id_str" : "8708232",
      "id" : 8708232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/DfRTp99l",
      "expanded_url" : "http:\/\/goo.gl\/JRCz8",
      "display_url" : "goo.gl\/JRCz8"
    } ]
  },
  "geo" : { },
  "id_str" : "123240137617453058",
  "text" : "RT @brynn: My friends +elle luna and +Brenden Mulligan put together a site in support of our friend +Amit Gupta, who was... http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/manageflitter.com\" rel=\"nofollow\"\u003EManageFlitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/DfRTp99l",
        "expanded_url" : "http:\/\/goo.gl\/JRCz8",
        "display_url" : "goo.gl\/JRCz8"
      } ]
    },
    "geo" : { },
    "id_str" : "123220551325073408",
    "text" : "My friends +elle luna and +Brenden Mulligan put together a site in support of our friend +Amit Gupta, who was... http:\/\/t.co\/DfRTp99l",
    "id" : 123220551325073408,
    "created_at" : "2011-10-10 02:17:23 +0000",
    "user" : {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "protected" : false,
      "id_str" : "8708232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451517791091167232\/ycYsDdzq_normal.jpeg",
      "id" : 8708232,
      "verified" : false
    }
  },
  "id" : 123240137617453058,
  "created_at" : "2011-10-10 03:35:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Smith",
      "screen_name" : "ChiefDoorman",
      "indices" : [ 21, 34 ],
      "id_str" : "122774170",
      "id" : 122774170
    }, {
      "name" : "GeekWireNews",
      "screen_name" : "GeekWireNews",
      "indices" : [ 39, 52 ],
      "id_str" : "389204381",
      "id" : 389204381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/GE2maMmQ",
      "expanded_url" : "http:\/\/goo.gl\/fb\/NhCVm",
      "display_url" : "goo.gl\/fb\/NhCVm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085953467, -122.306368495 ]
  },
  "id_str" : "123102278323412993",
  "text" : "Insightful post from @chiefdoorman and @GeekWireNews if you're building a web business: What are your golden metrics? http:\/\/t.co\/GE2maMmQ",
  "id" : 123102278323412993,
  "created_at" : "2011-10-09 18:27:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 7, 17 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 22, 33 ],
      "id_str" : "784078",
      "id" : 784078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/BS0eAcOc",
      "expanded_url" : "http:\/\/flic.kr\/p\/au5krF",
      "display_url" : "flic.kr\/p\/au5krF"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.617833, -122.326667 ]
  },
  "id_str" : "122898729014534144",
  "text" : "8:36pm @Kellianne and @Alicetiara didn't let me eat any of this dessert http:\/\/t.co\/BS0eAcOc",
  "id" : 122898729014534144,
  "created_at" : "2011-10-09 04:58:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122787065275498496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6083074433, -122.3056904478 ]
  },
  "id_str" : "122818785211187200",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote Cool! Whatcha doing there? Roof party?",
  "id" : 122818785211187200,
  "in_reply_to_status_id" : 122787065275498496,
  "created_at" : "2011-10-08 23:40:54 +0000",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Gilbert",
      "screen_name" : "MyBodyTutor",
      "indices" : [ 30, 42 ],
      "id_str" : "17905221",
      "id" : 17905221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/2MMvPvS3",
      "expanded_url" : "http:\/\/mybodytutor.com",
      "display_url" : "mybodytutor.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6084974433, -122.3064259933 ]
  },
  "id_str" : "122736863806107648",
  "text" : "After speaking with Adam from @mybodytutor, excited to have his help with losing 15lbs. Check his service out: http:\/\/t.co\/2MMvPvS3",
  "id" : 122736863806107648,
  "created_at" : "2011-10-08 18:15:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 3, 13 ],
      "id_str" : "10609",
      "id" : 10609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/sZRHSCzl",
      "expanded_url" : "http:\/\/sethgodin.typepad.com\/seths_blog\/2011\/10\/eliminating-the-impulse-to-stall.html",
      "display_url" : "sethgodin.typepad.com\/seths_blog\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "122526834435964928",
  "text" : "RT @superamit: Seth Godin, my friend & mentor, and now my hero, offers a profile on his blog + $10K to someone who matches & donates htt ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/sZRHSCzl",
        "expanded_url" : "http:\/\/sethgodin.typepad.com\/seths_blog\/2011\/10\/eliminating-the-impulse-to-stall.html",
        "display_url" : "sethgodin.typepad.com\/seths_blog\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "122391694015606786",
    "text" : "Seth Godin, my friend & mentor, and now my hero, offers a profile on his blog + $10K to someone who matches & donates http:\/\/t.co\/sZRHSCzl",
    "id" : 122391694015606786,
    "created_at" : "2011-10-07 19:23:48 +0000",
    "user" : {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "protected" : false,
      "id_str" : "10609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2839151893\/f62ce69123d744f68381edfda11ed942_normal.jpeg",
      "id" : 10609,
      "verified" : false
    }
  },
  "id" : 122526834435964928,
  "created_at" : "2011-10-08 04:20:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Muller",
      "screen_name" : "amylola",
      "indices" : [ 0, 8 ],
      "id_str" : "6343",
      "id" : 6343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122517763158847488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086051945, -122.3065398327 ]
  },
  "id_str" : "122522693579972608",
  "in_reply_to_user_id" : 6343,
  "text" : "@amylola I'll let you know what I think! Haven't read the books but heard good things!",
  "id" : 122522693579972608,
  "in_reply_to_status_id" : 122517763158847488,
  "created_at" : "2011-10-08 04:04:21 +0000",
  "in_reply_to_screen_name" : "amylola",
  "in_reply_to_user_id_str" : "6343",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/2xq6HmYm",
      "expanded_url" : "http:\/\/flic.kr\/p\/atMiMc",
      "display_url" : "flic.kr\/p\/atMiMc"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608333, -122.306 ]
  },
  "id_str" : "122516701869903875",
  "text" : "8:36pm Watching Golden Compass and thinking about writing something http:\/\/t.co\/2xq6HmYm",
  "id" : 122516701869903875,
  "created_at" : "2011-10-08 03:40:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeVore",
      "screen_name" : "crashdev",
      "indices" : [ 54, 63 ],
      "id_str" : "14763501",
      "id" : 14763501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/GTl5FJOL",
      "expanded_url" : "http:\/\/crashdev.blogspot.com\/2011\/10\/future-of-work-what-happens-when-talent.html",
      "display_url" : "crashdev.blogspot.com\/2011\/10\/future\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085846393, -122.3061084961 ]
  },
  "id_str" : "122504353683738625",
  "text" : "Very interesting argument about the future of work by @crashdev, which seems right to me: http:\/\/t.co\/GTl5FJOL",
  "id" : 122504353683738625,
  "created_at" : "2011-10-08 02:51:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 64, 75 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/Xqguvvw2",
      "expanded_url" : "http:\/\/tcrn.ch\/mTAX6m",
      "display_url" : "tcrn.ch\/mTAX6m"
    } ]
  },
  "geo" : { },
  "id_str" : "122502904593645569",
  "text" : "RT @TechCrunch: Here's To The Crazy One http:\/\/t.co\/Xqguvvw2 by @parislemon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vip.wordpress.com\/hosting\" rel=\"nofollow\"\u003EWordPress.com VIP\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MG Siegler",
        "screen_name" : "parislemon",
        "indices" : [ 48, 59 ],
        "id_str" : "652193",
        "id" : 652193
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 44 ],
        "url" : "http:\/\/t.co\/Xqguvvw2",
        "expanded_url" : "http:\/\/tcrn.ch\/mTAX6m",
        "display_url" : "tcrn.ch\/mTAX6m"
      } ]
    },
    "geo" : { },
    "id_str" : "122486468202610689",
    "text" : "Here's To The Crazy One http:\/\/t.co\/Xqguvvw2 by @parislemon",
    "id" : 122486468202610689,
    "created_at" : "2011-10-08 01:40:24 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2176846885\/-5-1_normal.jpeg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 122502904593645569,
  "created_at" : "2011-10-08 02:45:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 0, 9 ],
      "id_str" : "15391002",
      "id" : 15391002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122466655145177088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6084522643, -122.30577378 ]
  },
  "id_str" : "122474513790287872",
  "in_reply_to_user_id" : 15391002,
  "text" : "@askotzko Yeah, I definitely could, though my thoughts may not be that insightful.",
  "id" : 122474513790287872,
  "in_reply_to_status_id" : 122466655145177088,
  "created_at" : "2011-10-08 00:52:54 +0000",
  "in_reply_to_screen_name" : "askotzko",
  "in_reply_to_user_id_str" : "15391002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 0, 9 ],
      "id_str" : "15391002",
      "id" : 15391002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122437916453646336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086841496, -122.3057227997 ]
  },
  "id_str" : "122466301280129024",
  "in_reply_to_user_id" : 15391002,
  "text" : "@askotzko Thank you! That was my goal. With writing tools it's important that they not get in the way!",
  "id" : 122466301280129024,
  "in_reply_to_status_id" : 122437916453646336,
  "created_at" : "2011-10-08 00:20:16 +0000",
  "in_reply_to_screen_name" : "askotzko",
  "in_reply_to_user_id_str" : "15391002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085844929, -122.3064675429 ]
  },
  "id_str" : "122321617169813504",
  "text" : "Is anyone eligible for a new iPhone but going to wait til at least Dec 1st to buy? I'll trade you eligibilities, and be your best friend!",
  "id" : 122321617169813504,
  "created_at" : "2011-10-07 14:45:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 12, 22 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "MacRumors.com",
      "screen_name" : "MacRumors",
      "indices" : [ 63, 73 ],
      "id_str" : "14861285",
      "id" : 14861285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/56pF8OYB",
      "expanded_url" : "http:\/\/macrumo.rs\/nmPZMV",
      "display_url" : "macrumo.rs\/nmPZMV"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608460422, -122.305841916 ]
  },
  "id_str" : "122286630852755456",
  "text" : "Got one for @kellianne. I'm not eligible til 12\/1 though :( RT @MacRumors: Apple Now Accepting Pre-Orders for iPhone 4S http:\/\/t.co\/56pF8OYB",
  "id" : 122286630852755456,
  "created_at" : "2011-10-07 12:26:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "15lbstogo",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/ntyTYYO2",
      "expanded_url" : "http:\/\/flic.kr\/p\/atxmkp",
      "display_url" : "flic.kr\/p\/atxmkp"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306 ]
  },
  "id_str" : "122156567142481920",
  "text" : "8:36pm Contemplating my dopamine response to that half empty bottle of wine. 1 glass or no glasses? #15lbstogo http:\/\/t.co\/ntyTYYO2",
  "id" : 122156567142481920,
  "created_at" : "2011-10-07 03:49:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Jacoby",
      "screen_name" : "jacobyryan",
      "indices" : [ 0, 11 ],
      "id_str" : "7210762",
      "id" : 7210762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122128682549645313",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085111907, -122.3062829533 ]
  },
  "id_str" : "122154584163614720",
  "in_reply_to_user_id" : 7210762,
  "text" : "@jacobyryan I think you may be right! And it turns out that dopamine sharply dips in such situations too.",
  "id" : 122154584163614720,
  "in_reply_to_status_id" : 122128682549645313,
  "created_at" : "2011-10-07 03:41:37 +0000",
  "in_reply_to_screen_name" : "jacobyryan",
  "in_reply_to_user_id_str" : "7210762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122116753168941056",
  "text" : "Dopamine encodes the difference between the predicted and experienced reward of an event. So should #gamification. They both help you learn.",
  "id" : 122116753168941056,
  "created_at" : "2011-10-07 01:11:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122112234473263104",
  "text" : "Dopamine is the hormone that creates a sense of reward in our brains, but what creates that feeling of dread when, say, looking at a salad?",
  "id" : 122112234473263104,
  "created_at" : "2011-10-07 00:53:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 103, 113 ],
      "id_str" : "10609",
      "id" : 10609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/ZC6rggIx",
      "expanded_url" : "http:\/\/brownbones-estw.eventbrite.com\/",
      "display_url" : "brownbones-estw.eventbrite.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6153794648, -122.3350582878 ]
  },
  "id_str" : "122018797422002176",
  "text" : "If you can, please join me in pitching in to help offset testing costs to find a bone marrow match for @superamit: http:\/\/t.co\/ZC6rggIx",
  "id" : 122018797422002176,
  "created_at" : "2011-10-06 18:42:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CakeHealth",
      "screen_name" : "cakehealth",
      "indices" : [ 3, 14 ],
      "id_str" : "69149255",
      "id" : 69149255
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stevejobs",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122016785829597185",
  "text" : "RT @cakehealth: \u201CDo you want to spend the rest of your life selling sugared water or do you want a chance to change the world?\" #stevejobs",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "stevejobs",
        "indices" : [ 112, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122003399234424832",
    "text" : "\u201CDo you want to spend the rest of your life selling sugared water or do you want a chance to change the world?\" #stevejobs",
    "id" : 122003399234424832,
    "created_at" : "2011-10-06 17:40:51 +0000",
    "user" : {
      "name" : "CakeHealth",
      "screen_name" : "cakehealth",
      "protected" : false,
      "id_str" : "69149255",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1645759513\/heartlogo_normal.png",
      "id" : 69149255,
      "verified" : false
    }
  },
  "id" : 122016785829597185,
  "created_at" : "2011-10-06 18:34:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 57, 67 ],
      "id_str" : "10609",
      "id" : 10609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/roaZHOqL",
      "expanded_url" : "http:\/\/happymonster.co\/2011\/10\/06\/lets-help-amit-gupta-defeat-leukemia\/",
      "display_url" : "happymonster.co\/2011\/10\/06\/let\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.56395196, -122.09556943 ]
  },
  "id_str" : "122012309504786432",
  "text" : "Are you or someone you know from South Asia? Please help @superamit defeat Leukemia by finding a bone marrow match: http:\/\/t.co\/roaZHOqL",
  "id" : 122012309504786432,
  "created_at" : "2011-10-06 18:16:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buster Overload",
      "screen_name" : "busteroverload",
      "indices" : [ 48, 63 ],
      "id_str" : "385142383",
      "id" : 385142383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/wzdxuysD",
      "expanded_url" : "http:\/\/blog.habitlabs.com\/post\/11061804386\/a-90-day-reverse-new-years-resolution",
      "display_url" : "blog.habitlabs.com\/post\/110618043\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.51973915, -121.92541223 ]
  },
  "id_str" : "122010158489534464",
  "text" : "So far, using the MealSnap app to post meals to @busteroverload has been pretty easy. Support me, please? http:\/\/t.co\/wzdxuysD",
  "id" : 122010158489534464,
  "created_at" : "2011-10-06 18:07:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Regales",
      "screen_name" : "bmorerican",
      "indices" : [ 0, 11 ],
      "id_str" : "23912695",
      "id" : 23912695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121803123307188224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.31980639, -121.27695524 ]
  },
  "id_str" : "121830439030755328",
  "in_reply_to_user_id" : 23912695,
  "text" : "@bmorerican Thank you, Rafael!",
  "id" : 121830439030755328,
  "in_reply_to_status_id" : 121803123307188224,
  "created_at" : "2011-10-06 06:13:34 +0000",
  "in_reply_to_screen_name" : "bmorerican",
  "in_reply_to_user_id_str" : "23912695",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Pusateri",
      "screen_name" : "Cruftbox",
      "indices" : [ 0, 9 ],
      "id_str" : "792738",
      "id" : 792738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121613265179652096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.31980639, -121.27695524 ]
  },
  "id_str" : "121830316443836416",
  "in_reply_to_user_id" : 792738,
  "text" : "@Cruftbox Thank you very much, Michael!",
  "id" : 121830316443836416,
  "in_reply_to_status_id" : 121613265179652096,
  "created_at" : "2011-10-06 06:13:05 +0000",
  "in_reply_to_screen_name" : "Cruftbox",
  "in_reply_to_user_id_str" : "792738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 34, 50 ],
      "id_str" : "246531241",
      "id" : 246531241
    }, {
      "name" : "Leo Babauta",
      "screen_name" : "habitlabs",
      "indices" : [ 84, 94 ],
      "id_str" : "2290777141",
      "id" : 2290777141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/lEB6cEj5",
      "expanded_url" : "http:\/\/flic.kr\/p\/athaPF",
      "display_url" : "flic.kr\/p\/athaPF"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.319833, -121.277 ]
  },
  "id_str" : "121792622120538112",
  "text" : "8:36pm Relaxing after celebrating @ameliagreenhall's upcoming birthday at our first @habitlabs offsite http:\/\/t.co\/lEB6cEj5",
  "id" : 121792622120538112,
  "created_at" : "2011-10-06 03:43:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/devices\" rel=\"nofollow\"\u003Etxt\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121772104709443584",
  "text" : "\uF8FF",
  "id" : 121772104709443584,
  "created_at" : "2011-10-06 02:21:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 3, 16 ],
      "id_str" : "14095370",
      "id" : 14095370
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 18, 31 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121613137752498176",
  "text" : "RT @OffbeatAriel: @busterbenson Andreas and I have found that chanting \"fatty, fatty, fatty\" helps with motivation.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "121607096771944448",
    "geo" : { },
    "id_str" : "121612391409647617",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson Andreas and I have found that chanting \"fatty, fatty, fatty\" helps with motivation.",
    "id" : 121612391409647617,
    "in_reply_to_status_id" : 121607096771944448,
    "created_at" : "2011-10-05 15:47:08 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "protected" : false,
      "id_str" : "14095370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456272250744754177\/cdia5MOI_normal.jpeg",
      "id" : 14095370,
      "verified" : false
    }
  },
  "id" : 121613137752498176,
  "created_at" : "2011-10-05 15:50:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/wzdxuysD",
      "expanded_url" : "http:\/\/blog.habitlabs.com\/post\/11061804386\/a-90-day-reverse-new-years-resolution",
      "display_url" : "blog.habitlabs.com\/post\/110618043\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "121607096771944448",
  "text" : "I'm trying to lose 15lbs by New Year's Day! Will you support me by donating $5? Read all about my experiment here: http:\/\/t.co\/wzdxuysD",
  "id" : 121607096771944448,
  "created_at" : "2011-10-05 15:26:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/wV2vvqT6",
      "expanded_url" : "http:\/\/instagr.am\/p\/PJbw5\/",
      "display_url" : "instagr.am\/p\/PJbw5\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61305747, -122.31375424 ]
  },
  "id_str" : "121465733204029440",
  "text" : "Our anniversary brownie is on fire!  @ Margorie Restaurant http:\/\/t.co\/wV2vvqT6",
  "id" : 121465733204029440,
  "created_at" : "2011-10-05 06:04:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 36, 46 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/QzFTUIkV",
      "expanded_url" : "http:\/\/instagr.am\/p\/PI4Ly\/",
      "display_url" : "instagr.am\/p\/PI4Ly\/"
    } ]
  },
  "geo" : { },
  "id_str" : "121431029566279680",
  "text" : "8:36pm 3 years! &lt;3 x infinity to @Kellianne! http:\/\/t.co\/QzFTUIkV",
  "id" : 121431029566279680,
  "created_at" : "2011-10-05 03:46:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/rOTvKw0d",
      "expanded_url" : "http:\/\/flic.kr\/p\/asL9BS",
      "display_url" : "flic.kr\/p\/asL9BS"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "121067003518787584",
  "text" : "8:36pm Watching Notes On A Scandal with my headless wife http:\/\/t.co\/rOTvKw0d",
  "id" : 121067003518787584,
  "created_at" : "2011-10-04 03:39:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/5xWiPoBV",
      "expanded_url" : "http:\/\/flic.kr\/p\/asrK9s",
      "display_url" : "flic.kr\/p\/asrK9s"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306167 ]
  },
  "id_str" : "120705047410642944",
  "text" : "8:36pm Taking a break from unpacking to watch a rom com http:\/\/t.co\/5xWiPoBV",
  "id" : 120705047410642944,
  "created_at" : "2011-10-03 03:41:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/7dGiE1Qt",
      "expanded_url" : "http:\/\/instagr.am\/p\/O7hic\/",
      "display_url" : "instagr.am\/p\/O7hic\/"
    } ]
  },
  "geo" : { },
  "id_str" : "120633544518275072",
  "text" : "What do you think this tiny fenced off tree is all about? http:\/\/t.co\/7dGiE1Qt",
  "id" : 120633544518275072,
  "created_at" : "2011-10-02 22:57:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Muhamad adeel  from ",
      "screen_name" : "SbFrom",
      "indices" : [ 0, 7 ],
      "id_str" : "1253587465",
      "id" : 1253587465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120524338335203328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.613094625, -122.3088117367 ]
  },
  "id_str" : "120602397667110913",
  "in_reply_to_user_id" : 78779800,
  "text" : "@sbfrom Very strange! Which page are you seeing that on?",
  "id" : 120602397667110913,
  "in_reply_to_status_id" : 120524338335203328,
  "created_at" : "2011-10-02 20:53:46 +0000",
  "in_reply_to_screen_name" : "DoYourBestWork",
  "in_reply_to_user_id_str" : "78779800",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/rUlOfaiD",
      "expanded_url" : "http:\/\/flic.kr\/p\/as74Qm",
      "display_url" : "flic.kr\/p\/as74Qm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.617, -122.333834 ]
  },
  "id_str" : "120347135756599296",
  "text" : "8:36pm Was working, now walking home http:\/\/t.co\/rUlOfaiD",
  "id" : 120347135756599296,
  "created_at" : "2011-10-02 03:59:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gmc",
      "screen_name" : "gmc",
      "indices" : [ 3, 7 ],
      "id_str" : "735983",
      "id" : 735983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120253575220830208",
  "text" : "RT @gmc: A habit cannot be tossed out the window; it must be coaxed down the stairs a step at a time. \u2014 Mark Twain",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120248538662846464",
    "text" : "A habit cannot be tossed out the window; it must be coaxed down the stairs a step at a time. \u2014 Mark Twain",
    "id" : 120248538662846464,
    "created_at" : "2011-10-01 21:27:40 +0000",
    "user" : {
      "name" : "Gmc",
      "screen_name" : "gmc",
      "protected" : false,
      "id_str" : "735983",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2765883929\/59be193e66e534286bbc7f5061688a7a_normal.png",
      "id" : 735983,
      "verified" : false
    }
  },
  "id" : 120253575220830208,
  "created_at" : "2011-10-01 21:47:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 15, 25 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/cSFVo5Dd",
      "expanded_url" : "http:\/\/jawbone.com\/speakers\/jambox\/overview",
      "display_url" : "jawbone.com\/speakers\/jambo\u2026"
    }, {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/vDf41lvH",
      "expanded_url" : "http:\/\/curebit.com\/x\/W8Z33",
      "display_url" : "curebit.com\/x\/W8Z33"
    } ]
  },
  "geo" : { },
  "id_str" : "120238659244007424",
  "text" : "I already told @kellianne what I'm getting her for her bday, but you can get one too: http:\/\/t.co\/cSFVo5Dd ($20 off: http:\/\/t.co\/vDf41lvH)",
  "id" : 120238659244007424,
  "created_at" : "2011-10-01 20:48:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/runkeeper.com\" rel=\"nofollow\"\u003ERunKeeper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RunKeeper",
      "indices" : [ 92, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/smdEkhDD",
      "expanded_url" : "http:\/\/rnkpr.com\/awgq16",
      "display_url" : "rnkpr.com\/awgq16"
    } ]
  },
  "geo" : { },
  "id_str" : "120214002574966785",
  "text" : "Just completed a 2.34 mi walk - First walk to work from our new house! http:\/\/t.co\/smdEkhDD #RunKeeper",
  "id" : 120214002574966785,
  "created_at" : "2011-10-01 19:10:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 39, 50 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/5XSCHxHs",
      "expanded_url" : "http:\/\/4sq.com\/nXxBOu",
      "display_url" : "4sq.com\/nXxBOu"
    } ]
  },
  "geo" : { },
  "id_str" : "120213958010486784",
  "text" : "I just unlocked the \"Warm Up\" badge on @foursquare! http:\/\/t.co\/5XSCHxHs",
  "id" : 120213958010486784,
  "created_at" : "2011-10-01 19:10:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trapper Markelz",
      "screen_name" : "trappermarkelz",
      "indices" : [ 27, 42 ],
      "id_str" : "1032241",
      "id" : 1032241
    }, {
      "name" : "co_health",
      "screen_name" : "co_health",
      "indices" : [ 110, 120 ],
      "id_str" : "95529837",
      "id" : 95529837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/B2jHUkC1",
      "expanded_url" : "http:\/\/shar.es\/bas9E",
      "display_url" : "shar.es\/bas9E"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60878974, -122.29766595 ]
  },
  "id_str" : "120097669334052864",
  "text" : "Smart answers, Trapper! RT @trappermarkelz: The strategy behind social health games: http:\/\/t.co\/B2jHUkC1 \/by @co_health",
  "id" : 120097669334052864,
  "created_at" : "2011-10-01 11:28:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Arrington",
      "screen_name" : "arrington",
      "indices" : [ 84, 94 ],
      "id_str" : "37570179",
      "id" : 37570179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/wJoeR9oe",
      "expanded_url" : "http:\/\/uncrunched.com\/2011\/10\/01\/brutal-honesty\/",
      "display_url" : "uncrunched.com\/2011\/10\/01\/bru\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085316, -122.305545608 ]
  },
  "id_str" : "120093460865875968",
  "text" : "\"I ask a hard question. I get 'bullshit, bullshit, polite nonsense bullshit'...\" RT @arrington: Brutal Honesty: http:\/\/t.co\/wJoeR9oe",
  "id" : 120093460865875968,
  "created_at" : "2011-10-01 11:11:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 3, 19 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/ue3dBlRS",
      "expanded_url" : "http:\/\/openreviewquarterly.com\/",
      "display_url" : "openreviewquarterly.com"
    } ]
  },
  "geo" : { },
  "id_str" : "120090625017262080",
  "text" : "RT @ameliagreenhall: Interview, the new issue of the Open Review Quarterly is live: http:\/\/t.co\/ue3dBlRS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/ue3dBlRS",
        "expanded_url" : "http:\/\/openreviewquarterly.com\/",
        "display_url" : "openreviewquarterly.com"
      } ]
    },
    "geo" : { },
    "id_str" : "120031639404417024",
    "text" : "Interview, the new issue of the Open Review Quarterly is live: http:\/\/t.co\/ue3dBlRS",
    "id" : 120031639404417024,
    "created_at" : "2011-10-01 07:05:47 +0000",
    "user" : {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "protected" : false,
      "id_str" : "246531241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446808446180937728\/GZ5tskw1_normal.jpeg",
      "id" : 246531241,
      "verified" : false
    }
  },
  "id" : 120090625017262080,
  "created_at" : "2011-10-01 11:00:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]