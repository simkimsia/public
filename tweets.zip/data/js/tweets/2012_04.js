Grailbird.data.tweets_2012_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/Ef31FPHu",
      "expanded_url" : "http:\/\/instagr.am\/p\/KEbrDdI0N-\/",
      "display_url" : "instagr.am\/p\/KEbrDdI0N-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "197168637893804033",
  "text" : "8:36pm In the dark with Niko, exhausted after a day of no naps and lots of trains tags:8:36pm http:\/\/t.co\/Ef31FPHu",
  "id" : 197168637893804033,
  "created_at" : "2012-05-01 03:40:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sessions",
      "screen_name" : "joinsessions",
      "indices" : [ 58, 71 ],
      "id_str" : "360907906",
      "id" : 360907906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/KhABduD0",
      "expanded_url" : "http:\/\/nyti.ms\/JmtfRw",
      "display_url" : "nyti.ms\/JmtfRw"
    } ]
  },
  "geo" : { },
  "id_str" : "197167937189187585",
  "text" : "How little exercise do we need? http:\/\/t.co\/KhABduD0 \/via @joinsessions",
  "id" : 197167937189187585,
  "created_at" : "2012-05-01 03:37:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Babauta",
      "screen_name" : "zen_habits",
      "indices" : [ 45, 56 ],
      "id_str" : "15859268",
      "id" : 15859268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/RhMA84Vl",
      "expanded_url" : "http:\/\/zenhabits.net\/39th\/",
      "display_url" : "zenhabits.net\/39th\/"
    } ]
  },
  "geo" : { },
  "id_str" : "197108448738017280",
  "text" : "\"Never heard of FOMO? You're missing out.\" - @zen_habits on his 39th lesson: http:\/\/t.co\/RhMA84Vl",
  "id" : 197108448738017280,
  "created_at" : "2012-04-30 23:41:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Metcalf",
      "screen_name" : "robbymet",
      "indices" : [ 0, 9 ],
      "id_str" : "27112594",
      "id" : 27112594
    }, {
      "name" : "GOOD ",
      "screen_name" : "good",
      "indices" : [ 104, 109 ],
      "id_str" : "19621110",
      "id" : 19621110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197101011800829953",
  "geo" : { },
  "id_str" : "197105676860915712",
  "in_reply_to_user_id" : 27112594,
  "text" : "@robbymet Good question. Seems less about saving money and more about spending it on better things. \/cc @GOOD",
  "id" : 197105676860915712,
  "in_reply_to_status_id" : 197101011800829953,
  "created_at" : "2012-04-30 23:30:30 +0000",
  "in_reply_to_screen_name" : "robbymet",
  "in_reply_to_user_id_str" : "27112594",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GOOD ",
      "screen_name" : "good",
      "indices" : [ 38, 43 ],
      "id_str" : "19621110",
      "id" : 19621110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/8neiQwug",
      "expanded_url" : "http:\/\/bit.ly\/Ij8N5Y",
      "display_url" : "bit.ly\/Ij8N5Y"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6150804838, -122.3544173502 ]
  },
  "id_str" : "197044184740397057",
  "text" : "Change habits and give to charity! RT @GOOD: This new microphilanthropy app helps you buy less--and give generously. http:\/\/t.co\/8neiQwug",
  "id" : 197044184740397057,
  "created_at" : "2012-04-30 19:26:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/aKqo8eyS",
      "expanded_url" : "http:\/\/instagr.am\/p\/KDeyyZI0C5\/",
      "display_url" : "instagr.am\/p\/KDeyyZI0C5\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.615071, -122.354059 ]
  },
  "id_str" : "197034908185673729",
  "text" : "Trainspotting dude date  @ Old Spaghetti Factory http:\/\/t.co\/aKqo8eyS",
  "id" : 197034908185673729,
  "created_at" : "2012-04-30 18:49:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/2UrBJgxv",
      "expanded_url" : "http:\/\/www.thedominoproject.com\/2012\/04\/tracts-and-books.html",
      "display_url" : "thedominoproject.com\/2012\/04\/tracts\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "197010922781413376",
  "text" : "Has a non-fiction book ever changed your mind? What about a tweet? What's the best length for persuasive text? http:\/\/t.co\/2UrBJgxv",
  "id" : 197010922781413376,
  "created_at" : "2012-04-30 17:13:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197010568413052928",
  "geo" : { },
  "id_str" : "197010727213608961",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote The cron just sends electrodes to my brain when I need to send another text.",
  "id" : 197010727213608961,
  "in_reply_to_status_id" : 197010568413052928,
  "created_at" : "2012-04-30 17:13:12 +0000",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thunt",
      "screen_name" : "thuntnet",
      "indices" : [ 0, 9 ],
      "id_str" : "73289095",
      "id" : 73289095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197005058439782400",
  "geo" : { },
  "id_str" : "197005348337483776",
  "in_reply_to_user_id" : 73289095,
  "text" : "@thuntnet Thanks! We made all the programs free and limited it to 3 at a time until we figure out our pricing model (probably $5\/program).",
  "id" : 197005348337483776,
  "in_reply_to_status_id" : 197005058439782400,
  "created_at" : "2012-04-30 16:51:49 +0000",
  "in_reply_to_screen_name" : "thuntnet",
  "in_reply_to_user_id_str" : "73289095",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bud.ge\" rel=\"nofollow\"\u003EBudge\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/jmzC7fvC",
      "expanded_url" : "http:\/\/bud.ge\/n\/1s6i",
      "display_url" : "bud.ge\/n\/1s6i"
    } ]
  },
  "geo" : { },
  "id_str" : "197002796216758273",
  "text" : "My secret ingredient for the Pushup Animal program is a new 7:30am alarm http:\/\/t.co\/jmzC7fvC",
  "id" : 197002796216758273,
  "created_at" : "2012-04-30 16:41:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/EpWrLxDf",
      "expanded_url" : "http:\/\/flic.kr\/p\/bRMRkR",
      "display_url" : "flic.kr\/p\/bRMRkR"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "196806273281441792",
  "text" : "8:36pm Falling asleep while Niko and Kellianne read http:\/\/t.co\/EpWrLxDf",
  "id" : 196806273281441792,
  "created_at" : "2012-04-30 03:40:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196720515581362176",
  "geo" : { },
  "id_str" : "196723298665627648",
  "in_reply_to_user_id" : 15275073,
  "text" : "@tberman Tumblr.",
  "id" : 196723298665627648,
  "in_reply_to_status_id" : 196720515581362176,
  "created_at" : "2012-04-29 22:11:04 +0000",
  "in_reply_to_screen_name" : "tberman",
  "in_reply_to_user_id_str" : "15275073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Davide 'Fol' Casali",
      "screen_name" : "Folletto",
      "indices" : [ 0, 9 ],
      "id_str" : "21693",
      "id" : 21693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196719744169152512",
  "geo" : { },
  "id_str" : "196719973299785728",
  "in_reply_to_user_id" : 21693,
  "text" : "@Folletto It's pretty central to an idea that should be launching in the next month or so.",
  "id" : 196719973299785728,
  "in_reply_to_status_id" : 196719744169152512,
  "created_at" : "2012-04-29 21:57:51 +0000",
  "in_reply_to_screen_name" : "Folletto",
  "in_reply_to_user_id_str" : "21693",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Davide 'Fol' Casali",
      "screen_name" : "Folletto",
      "indices" : [ 0, 9 ],
      "id_str" : "21693",
      "id" : 21693
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 120, 130 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196719056152305664",
  "geo" : { },
  "id_str" : "196719399590305792",
  "in_reply_to_user_id" : 21693,
  "text" : "@Folletto Not for that exactly\u2026 but it's my current attempt at combining several different behavior change theories \/cc @avantgame",
  "id" : 196719399590305792,
  "in_reply_to_status_id" : 196719056152305664,
  "created_at" : "2012-04-29 21:55:34 +0000",
  "in_reply_to_screen_name" : "Folletto",
  "in_reply_to_user_id_str" : "21693",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stoked",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/cFdkTDZy",
      "expanded_url" : "http:\/\/habitcourse.com\/",
      "display_url" : "habitcourse.com"
    } ]
  },
  "geo" : { },
  "id_str" : "196713544702627840",
  "text" : "I'm gonna by participating in the 4-week Habit Course, starting tomorrow! You can still sign up: http:\/\/t.co\/cFdkTDZy #stoked",
  "id" : 196713544702627840,
  "created_at" : "2012-04-29 21:32:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/l0W1owRJ",
      "expanded_url" : "http:\/\/bustr.me\/post\/22075184832\/heres-a-bigger-and-cleaner-version-of-the-drawing",
      "display_url" : "bustr.me\/post\/220751848\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "196709014082560000",
  "text" : "Here's a bigger version of the \"how to succeed at anything\" image I drew the other day: http:\/\/t.co\/l0W1owRJ",
  "id" : 196709014082560000,
  "created_at" : "2012-04-29 21:14:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry Bain",
      "screen_name" : "terrybain",
      "indices" : [ 0, 10 ],
      "id_str" : "2367271",
      "id" : 2367271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196651751674347520",
  "geo" : { },
  "id_str" : "196655078353018880",
  "in_reply_to_user_id" : 2367271,
  "text" : "@TerryBain Thank you. That site and the previous video are exactly what I was looking for.",
  "id" : 196655078353018880,
  "in_reply_to_status_id" : 196651751674347520,
  "created_at" : "2012-04-29 17:39:59 +0000",
  "in_reply_to_screen_name" : "terrybain",
  "in_reply_to_user_id_str" : "2367271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196636844761427968",
  "geo" : { },
  "id_str" : "196637123993018369",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Awesome! I'm interested in anything technique-related. I'll take a look at these links too!",
  "id" : 196637123993018369,
  "in_reply_to_status_id" : 196636844761427968,
  "created_at" : "2012-04-29 16:28:38 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196630920139251714",
  "geo" : { },
  "id_str" : "196634436245262337",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim Yeah I'd love to hear it!",
  "id" : 196634436245262337,
  "in_reply_to_status_id" : 196630920139251714,
  "created_at" : "2012-04-29 16:17:57 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196628377040453632",
  "geo" : { },
  "id_str" : "196628688652075008",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim Thanks! I'm researching a hunch about behavior change in humans versus dogs. :)",
  "id" : 196628688652075008,
  "in_reply_to_status_id" : 196628377040453632,
  "created_at" : "2012-04-29 15:55:07 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196627258985824259",
  "text" : "Dog people! I'm looking for good online resources for puppy training... what's the best you've seen?",
  "id" : 196627258985824259,
  "created_at" : "2012-04-29 15:49:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 1, 11 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 54, 65 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/N3ek5HJk",
      "expanded_url" : "http:\/\/bit.ly\/KibBUW",
      "display_url" : "bit.ly\/KibBUW"
    } ]
  },
  "geo" : { },
  "id_str" : "196430084477960192",
  "text" : "\u201C@kellianne: U http:\/\/t.co\/N3ek5HJk\u201D &lt;-- I suspect @nikobenson's handiwork here.",
  "id" : 196430084477960192,
  "created_at" : "2012-04-29 02:45:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Vanderbilt",
      "screen_name" : "ryan_vanderbilt",
      "indices" : [ 0, 16 ],
      "id_str" : "43352336",
      "id" : 43352336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196346924469723138",
  "geo" : { },
  "id_str" : "196355816939470850",
  "in_reply_to_user_id" : 43352336,
  "text" : "@ryan_vanderbilt Thanks! Starting small is such a simple strategy, but it continues to work time and time again.",
  "id" : 196355816939470850,
  "in_reply_to_status_id" : 196346924469723138,
  "created_at" : "2012-04-28 21:50:49 +0000",
  "in_reply_to_screen_name" : "ryan_vanderbilt",
  "in_reply_to_user_id_str" : "43352336",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brennan Novak",
      "screen_name" : "brennannovak",
      "indices" : [ 0, 13 ],
      "id_str" : "17958179",
      "id" : 17958179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196274589775560706",
  "geo" : { },
  "id_str" : "196277719351300096",
  "in_reply_to_user_id" : 17958179,
  "text" : "@brennannovak It looks great!  Will it remind me to check in occasionally?",
  "id" : 196277719351300096,
  "in_reply_to_status_id" : 196274589775560706,
  "created_at" : "2012-04-28 16:40:29 +0000",
  "in_reply_to_screen_name" : "brennannovak",
  "in_reply_to_user_id_str" : "17958179",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PoorYorick",
      "screen_name" : "PoorYorick",
      "indices" : [ 0, 11 ],
      "id_str" : "7622622",
      "id" : 7622622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196259986739953666",
  "geo" : { },
  "id_str" : "196265496784551939",
  "in_reply_to_user_id" : 7622622,
  "text" : "@PoorYorick Agreed!",
  "id" : 196265496784551939,
  "in_reply_to_status_id" : 196259986739953666,
  "created_at" : "2012-04-28 15:51:55 +0000",
  "in_reply_to_screen_name" : "PoorYorick",
  "in_reply_to_user_id_str" : "7622622",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brennan Novak",
      "screen_name" : "brennannovak",
      "indices" : [ 0, 13 ],
      "id_str" : "17958179",
      "id" : 17958179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/EJN3jAoe",
      "expanded_url" : "http:\/\/bit.ly\/IZMwu0",
      "display_url" : "bit.ly\/IZMwu0"
    } ]
  },
  "in_reply_to_status_id_str" : "196262443125702656",
  "geo" : { },
  "id_str" : "196265465855750144",
  "in_reply_to_user_id" : 17958179,
  "text" : "@brennannovak I'm working on it: http:\/\/t.co\/EJN3jAoe",
  "id" : 196265465855750144,
  "in_reply_to_status_id" : 196262443125702656,
  "created_at" : "2012-04-28 15:51:48 +0000",
  "in_reply_to_screen_name" : "brennannovak",
  "in_reply_to_user_id_str" : "17958179",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196260692603584514",
  "text" : "One of the reasons habits are so difficult to change is because of other habits.",
  "id" : 196260692603584514,
  "created_at" : "2012-04-28 15:32:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196258696660131840",
  "text" : "I want a mechanical counter (the kind used to count people) that also tracks time + GPS of each click. iPhone app would work too.",
  "id" : 196258696660131840,
  "created_at" : "2012-04-28 15:24:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bud.ge\" rel=\"nofollow\"\u003EBudge\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/GNx5IZZh",
      "expanded_url" : "http:\/\/21habit.com",
      "display_url" : "21habit.com"
    }, {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/pxr9Jh1R",
      "expanded_url" : "http:\/\/bud.ge\/n\/1qlu",
      "display_url" : "bud.ge\/n\/1qlu"
    } ]
  },
  "geo" : { },
  "id_str" : "196253357516668930",
  "text" : "My secret ingredient is Starting up a new 1,000 pushups in 30 days attempt. Also using http:\/\/t.co\/GNx5IZZh! http:\/\/t.co\/pxr9Jh1R",
  "id" : 196253357516668930,
  "created_at" : "2012-04-28 15:03:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196252163809353730",
  "geo" : { },
  "id_str" : "196252415522123776",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel If you read it, let me know what you think.",
  "id" : 196252415522123776,
  "in_reply_to_status_id" : 196252163809353730,
  "created_at" : "2012-04-28 14:59:56 +0000",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196252163809353730",
  "geo" : { },
  "id_str" : "196252359578484736",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel I do recommend it! It's very clear about the mechanics and application of habit change. Cue -&gt; routine -&gt; reward.",
  "id" : 196252359578484736,
  "in_reply_to_status_id" : 196252163809353730,
  "created_at" : "2012-04-28 14:59:43 +0000",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "196251353499176961",
  "geo" : { },
  "id_str" : "196251681598615552",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel Just read it and actually thought it was pretty good!",
  "id" : 196251681598615552,
  "in_reply_to_status_id" : 196251353499176961,
  "created_at" : "2012-04-28 14:57:01 +0000",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/kdCNWPfY",
      "expanded_url" : "http:\/\/flic.kr\/p\/bChH1y",
      "display_url" : "flic.kr\/p\/bChH1y"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.624333, -122.317167 ]
  },
  "id_str" : "196080865900634112",
  "text" : "8:36pm At a Finishing School meetup http:\/\/t.co\/kdCNWPfY",
  "id" : 196080865900634112,
  "created_at" : "2012-04-28 03:38:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Jacobs",
      "screen_name" : "evanjacobs",
      "indices" : [ 20, 31 ],
      "id_str" : "14803483",
      "id" : 14803483
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 33, 46 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195999509430550528",
  "text" : "Ha, best answer: RT @evanjacobs: @busterbenson 1,000,000 pushups in one lifetime",
  "id" : 195999509430550528,
  "created_at" : "2012-04-27 22:14:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Wang",
      "screen_name" : "brianmwang",
      "indices" : [ 0, 11 ],
      "id_str" : "93478440",
      "id" : 93478440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195992822090956800",
  "geo" : { },
  "id_str" : "195993106657718272",
  "in_reply_to_user_id" : 93478440,
  "text" : "@brianmwang Yeah, something like that. Trying to see if people are more impressed by physical strength or willpower. So far 3:1.",
  "id" : 195993106657718272,
  "in_reply_to_status_id" : 195992822090956800,
  "created_at" : "2012-04-27 21:49:32 +0000",
  "in_reply_to_screen_name" : "brianmwang",
  "in_reply_to_user_id_str" : "93478440",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195990851145568256",
  "text" : "Which is more impressive to you: 100 pushups in 1 set, or 1,000 pushups in 1 month?",
  "id" : 195990851145568256,
  "created_at" : "2012-04-27 21:40:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Coldewey",
      "screen_name" : "krrish",
      "indices" : [ 0, 7 ],
      "id_str" : "1105771",
      "id" : 1105771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195923384679399424",
  "geo" : { },
  "id_str" : "195931812143431680",
  "in_reply_to_user_id" : 1105771,
  "text" : "@krrish Thanks for trying it out! Let me know what you think of it.",
  "id" : 195931812143431680,
  "in_reply_to_status_id" : 195923384679399424,
  "created_at" : "2012-04-27 17:45:58 +0000",
  "in_reply_to_screen_name" : "krrish",
  "in_reply_to_user_id_str" : "1105771",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sliding Autonomy",
      "screen_name" : "SlidingAutonomy",
      "indices" : [ 0, 16 ],
      "id_str" : "455234794",
      "id" : 455234794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194939489334996994",
  "geo" : { },
  "id_str" : "195926855927341056",
  "in_reply_to_user_id" : 455234794,
  "text" : "@SlidingAutonomy Nice! What do I have to do to get included in this small group of testers?",
  "id" : 195926855927341056,
  "in_reply_to_status_id" : 194939489334996994,
  "created_at" : "2012-04-27 17:26:17 +0000",
  "in_reply_to_screen_name" : "SlidingAutonomy",
  "in_reply_to_user_id_str" : "455234794",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Kathleen Peck",
      "screen_name" : "sarahkpeck",
      "indices" : [ 0, 11 ],
      "id_str" : "196745496",
      "id" : 196745496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195722886139486208",
  "geo" : { },
  "id_str" : "195730085553246208",
  "in_reply_to_user_id" : 196745496,
  "text" : "@sarahkpeck I don't think it's possible to avoid having beliefs. Given that they're unavoidable, might as well be aware of them!",
  "id" : 195730085553246208,
  "in_reply_to_status_id" : 195722886139486208,
  "created_at" : "2012-04-27 04:24:23 +0000",
  "in_reply_to_screen_name" : "sarahkpeck",
  "in_reply_to_user_id_str" : "196745496",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/chqbGGgt",
      "expanded_url" : "http:\/\/flic.kr\/p\/bQXAbt",
      "display_url" : "flic.kr\/p\/bQXAbt"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306334 ]
  },
  "id_str" : "195722053175869440",
  "text" : "8:36pm Still light out http:\/\/t.co\/chqbGGgt",
  "id" : 195722053175869440,
  "created_at" : "2012-04-27 03:52:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195670495276974080",
  "geo" : { },
  "id_str" : "195670864912592897",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame Thanks. It's funny because it's true!",
  "id" : 195670864912592897,
  "in_reply_to_status_id" : 195670495276974080,
  "created_at" : "2012-04-27 00:29:04 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195668569260957696",
  "geo" : { },
  "id_str" : "195669225505959937",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey I like that. It's my turn so hard I want to kill myself.",
  "id" : 195669225505959937,
  "in_reply_to_status_id" : 195668569260957696,
  "created_at" : "2012-04-27 00:22:33 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195669051803049985",
  "text" : "Anyone who gives you a # of days before a habit sticks is A) selling you something and B) telling you when your warranty expires on it.",
  "id" : 195669051803049985,
  "created_at" : "2012-04-27 00:21:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195667413176557568",
  "text" : "I wish iPhone games like Draw Something would prevent me from starting too many matches. Now I don't even want to open the app!",
  "id" : 195667413176557568,
  "created_at" : "2012-04-27 00:15:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/8PXFd2rd",
      "expanded_url" : "http:\/\/bit.ly\/IV8UVj",
      "display_url" : "bit.ly\/IV8UVj"
    } ]
  },
  "in_reply_to_status_id_str" : "195624599235461121",
  "geo" : { },
  "id_str" : "195647963018706945",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Niko is http:\/\/t.co\/8PXFd2rd :) Can't wait to get him making stuff! What about Tavi?",
  "id" : 195647963018706945,
  "in_reply_to_status_id" : 195624599235461121,
  "created_at" : "2012-04-26 22:58:04 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DIY",
      "screen_name" : "DIY",
      "indices" : [ 8, 12 ],
      "id_str" : "457744153",
      "id" : 457744153
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 28, 39 ],
      "id_str" : "142467448",
      "id" : 142467448
    }, {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 52, 61 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/9ObSRr4o",
      "expanded_url" : "http:\/\/bit.ly\/IAgNSB",
      "display_url" : "bit.ly\/IAgNSB"
    } ]
  },
  "geo" : { },
  "id_str" : "195616090510987264",
  "text" : "Agreed! @diy looks right up @nikobenson's alley! MT @amyjokim: beautifully designed site + compelling value prop: DIY http:\/\/t.co\/9ObSRr4o",
  "id" : 195616090510987264,
  "created_at" : "2012-04-26 20:51:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "indices" : [ 3, 14 ],
      "id_str" : "8070502",
      "id" : 8070502
    }, {
      "name" : "Tasneem Raja",
      "screen_name" : "tasneemraja",
      "indices" : [ 118, 130 ],
      "id_str" : "56052405",
      "id" : 56052405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/rLK5QKIC",
      "expanded_url" : "http:\/\/motherjones.com\/media\/2012\/04\/silicon-valley-brogrammer-culture-sexist-sxsw",
      "display_url" : "motherjones.com\/media\/2012\/04\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "195590320090644480",
  "text" : "RT @danshapiro: \"Gangbang Interviews\" and \"Bikini Shots\": Silicon Valley\u2019s Brogrammer Problem http:\/\/t.co\/rLK5QKIC by @tasneemraja",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tasneem Raja",
        "screen_name" : "tasneemraja",
        "indices" : [ 102, 114 ],
        "id_str" : "56052405",
        "id" : 56052405
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/rLK5QKIC",
        "expanded_url" : "http:\/\/motherjones.com\/media\/2012\/04\/silicon-valley-brogrammer-culture-sexist-sxsw",
        "display_url" : "motherjones.com\/media\/2012\/04\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "195582636150894592",
    "text" : "\"Gangbang Interviews\" and \"Bikini Shots\": Silicon Valley\u2019s Brogrammer Problem http:\/\/t.co\/rLK5QKIC by @tasneemraja",
    "id" : 195582636150894592,
    "created_at" : "2012-04-26 18:38:28 +0000",
    "user" : {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "protected" : false,
      "id_str" : "8070502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/51828452\/eye_pic_normal.jpg",
      "id" : 8070502,
      "verified" : false
    }
  },
  "id" : 195590320090644480,
  "created_at" : "2012-04-26 19:09:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 3, 11 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/viAtzsr3",
      "expanded_url" : "http:\/\/www.meetup.com\/Quantified-Self-Seattle\/events\/61134552\/",
      "display_url" : "meetup.com\/Quantified-Sel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "195572614553538560",
  "text" : "RT @dreeves: Just announced: Seattle Quantified Self Show + Tell, now at Founder's Co-op, June 13. Please join us! http:\/\/t.co\/viAtzsr3  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quantifiedself",
        "indices" : [ 123, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/viAtzsr3",
        "expanded_url" : "http:\/\/www.meetup.com\/Quantified-Self-Seattle\/events\/61134552\/",
        "display_url" : "meetup.com\/Quantified-Sel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "195555922670665729",
    "text" : "Just announced: Seattle Quantified Self Show + Tell, now at Founder's Co-op, June 13. Please join us! http:\/\/t.co\/viAtzsr3 #quantifiedself",
    "id" : 195555922670665729,
    "created_at" : "2012-04-26 16:52:19 +0000",
    "user" : {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "protected" : false,
      "id_str" : "947851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3053671574\/f10ead459d0886bc28633dd1fef83cb5_normal.jpeg",
      "id" : 947851,
      "verified" : false
    }
  },
  "id" : 195572614553538560,
  "created_at" : "2012-04-26 17:58:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195515497238892545",
  "geo" : { },
  "id_str" : "195517728243728385",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Amazon gets a lot of their deals from Living Social but the types are basically the same.",
  "id" : 195517728243728385,
  "in_reply_to_status_id" : 195515497238892545,
  "created_at" : "2012-04-26 14:20:33 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195503010988834817",
  "geo" : { },
  "id_str" : "195503300710379521",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Good morning to you too! Headed to school?",
  "id" : 195503300710379521,
  "in_reply_to_status_id" : 195503010988834817,
  "created_at" : "2012-04-26 13:23:13 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/5ZRzVTgp",
      "expanded_url" : "http:\/\/dthin.gs\/KdqLGl",
      "display_url" : "dthin.gs\/KdqLGl"
    } ]
  },
  "geo" : { },
  "id_str" : "195502260413931520",
  "text" : "AmazonLocal added some personalization to their deals! http:\/\/t.co\/5ZRzVTgp",
  "id" : 195502260413931520,
  "created_at" : "2012-04-26 13:19:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matkas",
      "screen_name" : "mathkas",
      "indices" : [ 0, 8 ],
      "id_str" : "56975501",
      "id" : 56975501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195442528164642816",
  "geo" : { },
  "id_str" : "195498233328443392",
  "in_reply_to_user_id" : 56975501,
  "text" : "@mathkas Not yet. I'll scan it later today and post it on Twitter.",
  "id" : 195498233328443392,
  "in_reply_to_status_id" : 195442528164642816,
  "created_at" : "2012-04-26 13:03:05 +0000",
  "in_reply_to_screen_name" : "mathkas",
  "in_reply_to_user_id_str" : "56975501",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 0, 7 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195329862733541376",
  "geo" : { },
  "id_str" : "195367929506832384",
  "in_reply_to_user_id" : 15727738,
  "text" : "@cwhogg Thank you, sir!",
  "id" : 195367929506832384,
  "in_reply_to_status_id" : 195329862733541376,
  "created_at" : "2012-04-26 04:25:18 +0000",
  "in_reply_to_screen_name" : "cwhogg",
  "in_reply_to_user_id_str" : "15727738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/HBvfLXzR",
      "expanded_url" : "http:\/\/flic.kr\/p\/bBMPE9",
      "display_url" : "flic.kr\/p\/bBMPE9"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "195356538871885824",
  "text" : "8:36pm Watching Dinosaur Train from our forts http:\/\/t.co\/HBvfLXzR",
  "id" : 195356538871885824,
  "created_at" : "2012-04-26 03:40:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bejon Parsinia",
      "screen_name" : "bejon",
      "indices" : [ 0, 6 ],
      "id_str" : "15489470",
      "id" : 15489470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195307789013368834",
  "geo" : { },
  "id_str" : "195309984047833089",
  "in_reply_to_user_id" : 15489470,
  "text" : "@bejon Thank you, sir!",
  "id" : 195309984047833089,
  "in_reply_to_status_id" : 195307789013368834,
  "created_at" : "2012-04-26 00:35:03 +0000",
  "in_reply_to_screen_name" : "bejon",
  "in_reply_to_user_id_str" : "15489470",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 17, 28 ],
      "id_str" : "2384071",
      "id" : 2384071
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 95, 108 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/2OTNxpmn",
      "expanded_url" : "http:\/\/bit.ly\/I2dO2O",
      "display_url" : "bit.ly\/I2dO2O"
    } ]
  },
  "geo" : { },
  "id_str" : "195306971254104064",
  "text" : "Woah, thanks! RT @timoreilly: How to succeed at anything http:\/\/t.co\/2OTNxpmn Very nicely done @busterbenson!",
  "id" : 195306971254104064,
  "created_at" : "2012-04-26 00:23:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dante Briones",
      "screen_name" : "dantebriones",
      "indices" : [ 0, 13 ],
      "id_str" : "62136032",
      "id" : 62136032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195296190970085376",
  "geo" : { },
  "id_str" : "195306525458309121",
  "in_reply_to_user_id" : 62136032,
  "text" : "@dantebriones He's just a slacker. Practice makes perfect.",
  "id" : 195306525458309121,
  "in_reply_to_status_id" : 195296190970085376,
  "created_at" : "2012-04-26 00:21:18 +0000",
  "in_reply_to_screen_name" : "dantebriones",
  "in_reply_to_user_id_str" : "62136032",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hunter Dyar",
      "screen_name" : "hdyar",
      "indices" : [ 0, 6 ],
      "id_str" : "28364425",
      "id" : 28364425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195258870090838017",
  "geo" : { },
  "id_str" : "195268700658606080",
  "in_reply_to_user_id" : 28364425,
  "text" : "@hdyar I think that's a true statement. :)",
  "id" : 195268700658606080,
  "in_reply_to_status_id" : 195258870090838017,
  "created_at" : "2012-04-25 21:51:00 +0000",
  "in_reply_to_screen_name" : "hdyar",
  "in_reply_to_user_id_str" : "28364425",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195253254416908288",
  "geo" : { },
  "id_str" : "195256150537678851",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon Hm\u2026 yeah, I guess it does. I sympathize with the struggle! :(",
  "id" : 195256150537678851,
  "in_reply_to_status_id" : 195253254416908288,
  "created_at" : "2012-04-25 21:01:08 +0000",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Stone",
      "screen_name" : "LBStone",
      "indices" : [ 0, 8 ],
      "id_str" : "9526102",
      "id" : 9526102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195250647845707777",
  "geo" : { },
  "id_str" : "195251391793602561",
  "in_reply_to_user_id" : 9526102,
  "text" : "@LBStone That's true. I'm thinking more on the level of \"I tried to learn how to juggle but failed\" and tried 9 other times...",
  "id" : 195251391793602561,
  "in_reply_to_status_id" : 195250647845707777,
  "created_at" : "2012-04-25 20:42:14 +0000",
  "in_reply_to_screen_name" : "LBStone",
  "in_reply_to_user_id_str" : "9526102",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195250111528443905",
  "geo" : { },
  "id_str" : "195251135643271168",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb I think individually.",
  "id" : 195251135643271168,
  "in_reply_to_status_id" : 195250111528443905,
  "created_at" : "2012-04-25 20:41:12 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195249148277178368",
  "geo" : { },
  "id_str" : "195249627291852800",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb I'd love to see the list! I think they do exist (I have a bunch too), but that they are worth bringing more attention to.",
  "id" : 195249627291852800,
  "in_reply_to_status_id" : 195249148277178368,
  "created_at" : "2012-04-25 20:35:13 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195249021969907713",
  "text" : "How many things have to really tried to do 10 times, and have failed to do all 10 times?",
  "id" : 195249021969907713,
  "created_at" : "2012-04-25 20:32:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/nPTZ8Vxu",
      "expanded_url" : "http:\/\/instagr.am\/p\/J2x46Xo0PD\/",
      "display_url" : "instagr.am\/p\/J2x46Xo0PD\/"
    } ]
  },
  "geo" : { },
  "id_str" : "195247093311475714",
  "text" : "4 steps to succeed at anything and everything! http:\/\/t.co\/nPTZ8Vxu",
  "id" : 195247093311475714,
  "created_at" : "2012-04-25 20:25:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "consistency",
      "indices" : [ 96, 108 ]
    }, {
      "text" : "behaviorchange",
      "indices" : [ 109, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/UXCYBb9J",
      "expanded_url" : "http:\/\/750words.com",
      "display_url" : "750words.com"
    }, {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/2wzVO407",
      "expanded_url" : "http:\/\/750words.com\/patrons\/note\/2550",
      "display_url" : "750words.com\/patrons\/note\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "195198375715553280",
  "text" : "Notes like this from patrons of http:\/\/t.co\/UXCYBb9J make me really happy: http:\/\/t.co\/2wzVO407 #consistency #behaviorchange",
  "id" : 195198375715553280,
  "created_at" : "2012-04-25 17:11:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/uydRXN9x",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayKIZXLP",
      "display_url" : "tmblr.co\/ZQJvayKIZXLP"
    } ]
  },
  "geo" : { },
  "id_str" : "195180197555867649",
  "text" : "Listening to Headin' For The Top Now from Spiritualized's new album: http:\/\/t.co\/uydRXN9x",
  "id" : 195180197555867649,
  "created_at" : "2012-04-25 15:59:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "195169378566811648",
  "geo" : { },
  "id_str" : "195169522884419584",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Same guy!",
  "id" : 195169522884419584,
  "in_reply_to_status_id" : 195169378566811648,
  "created_at" : "2012-04-25 15:16:54 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "donothing",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/4UO3JLm1",
      "expanded_url" : "http:\/\/calm.com\/",
      "display_url" : "calm.com"
    } ]
  },
  "geo" : { },
  "id_str" : "195167039927754753",
  "text" : "If you've got flash, check this out (and wait a bit for it to load): http:\/\/t.co\/4UO3JLm1 #donothing",
  "id" : 195167039927754753,
  "created_at" : "2012-04-25 15:07:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/HjB3jjXB",
      "expanded_url" : "http:\/\/instagr.am\/p\/J1JNmdI0EB\/",
      "display_url" : "instagr.am\/p\/J1JNmdI0EB\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.613259, -122.344943 ]
  },
  "id_str" : "195017064799412224",
  "text" : "Checkin it out  @ The Upstairs http:\/\/t.co\/HjB3jjXB",
  "id" : 195017064799412224,
  "created_at" : "2012-04-25 05:11:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/bMLpV49j",
      "expanded_url" : "http:\/\/flic.kr\/p\/bQrpVn",
      "display_url" : "flic.kr\/p\/bQrpVn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6145, -122.346667 ]
  },
  "id_str" : "195008109377359872",
  "text" : "8:36pm Talking about believing in magic on date night http:\/\/t.co\/bMLpV49j",
  "id" : 195008109377359872,
  "created_at" : "2012-04-25 04:35:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christiaan ",
      "screen_name" : "chendriksen",
      "indices" : [ 0, 12 ],
      "id_str" : "20089412",
      "id" : 20089412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194901609233387520",
  "geo" : { },
  "id_str" : "194902394335801344",
  "in_reply_to_user_id" : 20089412,
  "text" : "@CHendriksen Nope. As far as I can tell it doesn't do anything other than check you in to the place and tell you how many points you got.",
  "id" : 194902394335801344,
  "in_reply_to_status_id" : 194901609233387520,
  "created_at" : "2012-04-24 21:35:26 +0000",
  "in_reply_to_screen_name" : "chendriksen",
  "in_reply_to_user_id_str" : "20089412",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 15, 26 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "recommended",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/AwHedNLN",
      "expanded_url" : "http:\/\/itunes.apple.com\/us\/app\/checkie\/id382356167?ls=1&mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/checkie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194900310278414336",
  "text" : "People who use @foursquare: check out Checkie: a super fast way to check in with 1-click: http:\/\/t.co\/AwHedNLN #recommended",
  "id" : 194900310278414336,
  "created_at" : "2012-04-24 21:27:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194857824122175488",
  "geo" : { },
  "id_str" : "194860849129717760",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel They could, in theory. But their brands haven't quite risen above the payment plan, especially as their biz models suffer.",
  "id" : 194860849129717760,
  "in_reply_to_status_id" : 194857824122175488,
  "created_at" : "2012-04-24 18:50:21 +0000",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194851682054713344",
  "geo" : { },
  "id_str" : "194853033153265664",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez I didn't know that about Craftsman. That's pretty awesome.",
  "id" : 194853033153265664,
  "in_reply_to_status_id" : 194851682054713344,
  "created_at" : "2012-04-24 18:19:17 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 104 ],
      "url" : "https:\/\/t.co\/dLBLE4vD",
      "expanded_url" : "https:\/\/drive.google.com\/start",
      "display_url" : "drive.google.com\/start"
    } ]
  },
  "geo" : { },
  "id_str" : "194850823774285825",
  "text" : "My Google Drive isn't ready yet. Maybe it had a late night and is a little sleepy. https:\/\/t.co\/dLBLE4vD",
  "id" : 194850823774285825,
  "created_at" : "2012-04-24 18:10:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Assink",
      "screen_name" : "jonassink",
      "indices" : [ 0, 10 ],
      "id_str" : "6604252",
      "id" : 6604252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194850153503539201",
  "geo" : { },
  "id_str" : "194850251834789888",
  "in_reply_to_user_id" : 6604252,
  "text" : "@jonassink Actual products.",
  "id" : 194850251834789888,
  "in_reply_to_status_id" : 194850153503539201,
  "created_at" : "2012-04-24 18:08:14 +0000",
  "in_reply_to_screen_name" : "jonassink",
  "in_reply_to_user_id_str" : "6604252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194849631069413377",
  "text" : "Can you think about any brands that are about caring about giving you long-term value (over a short-term sale)?",
  "id" : 194849631069413377,
  "created_at" : "2012-04-24 18:05:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/Z7Bcr1ha",
      "expanded_url" : "http:\/\/blog.habitlabs.com\/post\/21722194688\/the-habit-onion",
      "display_url" : "blog.habitlabs.com\/post\/217221946\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194840970506928130",
  "text" : "The Habit Onion: http:\/\/t.co\/Z7Bcr1ha",
  "id" : 194840970506928130,
  "created_at" : "2012-04-24 17:31:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shanknits",
      "screen_name" : "shanknits",
      "indices" : [ 0, 10 ],
      "id_str" : "15949989",
      "id" : 15949989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194838034880016384",
  "geo" : { },
  "id_str" : "194840605120135168",
  "in_reply_to_user_id" : 15949989,
  "text" : "@shanknits Not that I'm aware. Which site are you having trouble with?",
  "id" : 194840605120135168,
  "in_reply_to_status_id" : 194838034880016384,
  "created_at" : "2012-04-24 17:29:54 +0000",
  "in_reply_to_screen_name" : "shanknits",
  "in_reply_to_user_id_str" : "15949989",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/HOpBPMkM",
      "expanded_url" : "http:\/\/taylordavidson.com\/writing\/2012\/04\/23\/context-first",
      "display_url" : "taylordavidson.com\/writing\/2012\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194810762697519104",
  "text" : "Yes! --&gt; \"The key is to focus less on the device and more on the individuals using the device.\" http:\/\/t.co\/HOpBPMkM",
  "id" : 194810762697519104,
  "created_at" : "2012-04-24 15:31:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/1FqjRuTP",
      "expanded_url" : "http:\/\/flic.kr\/p\/bBeVPU",
      "display_url" : "flic.kr\/p\/bBeVPU"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "194633559758221312",
  "text" : "8:36pm Guy's night: yogurt, leftovers, and lion rawrs for dinner http:\/\/t.co\/1FqjRuTP",
  "id" : 194633559758221312,
  "created_at" : "2012-04-24 03:47:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ANNE LAMOTT",
      "screen_name" : "ANNELAMOTT",
      "indices" : [ 3, 14 ],
      "id_str" : "389974502",
      "id" : 389974502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194600315415302145",
  "text" : "RT @ANNELAMOTT: You own everything that happened to you. Tell your stories. If people wanted you to write warmly about them, they should ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194580559962439681",
    "text" : "You own everything that happened to you. Tell your stories. If people wanted you to write warmly about them, they should've behaved better.",
    "id" : 194580559962439681,
    "created_at" : "2012-04-24 00:16:35 +0000",
    "user" : {
      "name" : "ANNE LAMOTT",
      "screen_name" : "ANNELAMOTT",
      "protected" : false,
      "id_str" : "389974502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1836893156\/mom_twitter_normal.jpg",
      "id" : 389974502,
      "verified" : true
    }
  },
  "id" : 194600315415302145,
  "created_at" : "2012-04-24 01:35:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 10, 20 ],
      "id_str" : "13349",
      "id" : 13349
    }, {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 21, 23 ],
      "id_str" : "11222",
      "id" : 11222
    }, {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 24, 32 ],
      "id_str" : "15275073",
      "id" : 15275073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194587744419319809",
  "geo" : { },
  "id_str" : "194589718053269505",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley @ryanchris @k @tberman \"He loved this idea.\"",
  "id" : 194589718053269505,
  "in_reply_to_status_id" : 194587744419319809,
  "created_at" : "2012-04-24 00:52:58 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zefrank",
      "screen_name" : "zefrank",
      "indices" : [ 29, 37 ],
      "id_str" : "11340982",
      "id" : 11340982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/Rsi3PZ6H",
      "expanded_url" : "http:\/\/bit.ly\/I5JVm1",
      "display_url" : "bit.ly\/I5JVm1"
    } ]
  },
  "geo" : { },
  "id_str" : "194588768777412608",
  "text" : "So good to have him back! RT @zefrank: episode 7 : \"Thinks Like Me\" : http:\/\/t.co\/Rsi3PZ6H : features stefan bucher!",
  "id" : 194588768777412608,
  "created_at" : "2012-04-24 00:49:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194585375971344384",
  "text" : "Enjoyed the webinar on Leo Babauta's Habit Course. Does anyone know him well enough to intro me? I'd love to help.",
  "id" : 194585375971344384,
  "created_at" : "2012-04-24 00:35:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Babauta",
      "screen_name" : "zen_habits",
      "indices" : [ 9, 20 ],
      "id_str" : "15859268",
      "id" : 15859268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/k1lIP031",
      "expanded_url" : "http:\/\/www.ustream.tv\/channel\/the-habit-course",
      "display_url" : "ustream.tv\/channel\/the-ha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194565076781510656",
  "text" : "Watching @zen_habits on Ustream as he talks about habits. Loving it. http:\/\/t.co\/k1lIP031",
  "id" : 194565076781510656,
  "created_at" : "2012-04-23 23:15:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194554879954534400",
  "geo" : { },
  "id_str" : "194555268263182336",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh That's why I am so obsessed with the intersection of those two points.",
  "id" : 194555268263182336,
  "in_reply_to_status_id" : 194554879954534400,
  "created_at" : "2012-04-23 22:36:05 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Anderegg",
      "screen_name" : "NickAnderegg",
      "indices" : [ 0, 13 ],
      "id_str" : "95100239",
      "id" : 95100239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194538917662433280",
  "geo" : { },
  "id_str" : "194540605911728128",
  "in_reply_to_user_id" : 95100239,
  "text" : "@NickAnderegg Awesome. Post it!",
  "id" : 194540605911728128,
  "in_reply_to_status_id" : 194538917662433280,
  "created_at" : "2012-04-23 21:37:49 +0000",
  "in_reply_to_screen_name" : "NickAnderegg",
  "in_reply_to_user_id_str" : "95100239",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Anderegg",
      "screen_name" : "NickAnderegg",
      "indices" : [ 0, 13 ],
      "id_str" : "95100239",
      "id" : 95100239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194535118260535296",
  "geo" : { },
  "id_str" : "194536157739102208",
  "in_reply_to_user_id" : 95100239,
  "text" : "@NickAnderegg Interesting! I think most of them are pretty common, but I'd be interested in what's different...",
  "id" : 194536157739102208,
  "in_reply_to_status_id" : 194535118260535296,
  "created_at" : "2012-04-23 21:20:08 +0000",
  "in_reply_to_screen_name" : "NickAnderegg",
  "in_reply_to_user_id_str" : "95100239",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joost Plattel",
      "screen_name" : "jplattel",
      "indices" : [ 0, 9 ],
      "id_str" : "16376925",
      "id" : 16376925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194534444252676096",
  "geo" : { },
  "id_str" : "194536051430273025",
  "in_reply_to_user_id" : 16376925,
  "text" : "@jplattel Yes, I highly encourage it. It was fun and enlightening even to myself.",
  "id" : 194536051430273025,
  "in_reply_to_status_id" : 194534444252676096,
  "created_at" : "2012-04-23 21:19:43 +0000",
  "in_reply_to_screen_name" : "jplattel",
  "in_reply_to_user_id_str" : "16376925",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194534190178500608",
  "geo" : { },
  "id_str" : "194535962909478912",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Thank you! It was fun to make.",
  "id" : 194535962909478912,
  "in_reply_to_status_id" : 194534190178500608,
  "created_at" : "2012-04-23 21:19:22 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/8AyTZ35v",
      "expanded_url" : "http:\/\/bustr.me\/post\/21665972078\/what-i-believe-v1",
      "display_url" : "bustr.me\/post\/216659720\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194532668384362497",
  "text" : "A hodgepodge collection of beliefs that occurred to me as I compiled them: http:\/\/t.co\/8AyTZ35v (open to feedback!) (you should do this too)",
  "id" : 194532668384362497,
  "created_at" : "2012-04-23 21:06:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/zGdECGlG",
      "expanded_url" : "http:\/\/bit.ly\/Jm9Eay",
      "display_url" : "bit.ly\/Jm9Eay"
    } ]
  },
  "geo" : { },
  "id_str" : "194509251178274818",
  "text" : "RT @the99percent: \"the best article that will ever be written about the creation of the Huffington Post\" - http:\/\/t.co\/zGdECGlG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/zGdECGlG",
        "expanded_url" : "http:\/\/bit.ly\/Jm9Eay",
        "display_url" : "bit.ly\/Jm9Eay"
      } ]
    },
    "geo" : { },
    "id_str" : "194497117996326913",
    "text" : "\"the best article that will ever be written about the creation of the Huffington Post\" - http:\/\/t.co\/zGdECGlG",
    "id" : 194497117996326913,
    "created_at" : "2012-04-23 18:45:01 +0000",
    "user" : {
      "name" : "99U",
      "screen_name" : "99u",
      "protected" : false,
      "id_str" : "17636894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2995676123\/fa7645dcc7f6d69b442bbcbd0950a0ef_normal.png",
      "id" : 17636894,
      "verified" : true
    }
  },
  "id" : 194509251178274818,
  "created_at" : "2012-04-23 19:33:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan McMinn",
      "screen_name" : "ryanmcminn",
      "indices" : [ 0, 11 ],
      "id_str" : "12061042",
      "id" : 12061042
    }, {
      "name" : "Austin Kleon",
      "screen_name" : "austinkleon",
      "indices" : [ 28, 40 ],
      "id_str" : "9698942",
      "id" : 9698942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194300500374589441",
  "geo" : { },
  "id_str" : "194300840322928640",
  "in_reply_to_user_id" : 12061042,
  "text" : "@ryanmcminn May I recommend @austinkleon's book, \"Steal Like An Artist\"? :)",
  "id" : 194300840322928640,
  "in_reply_to_status_id" : 194300500374589441,
  "created_at" : "2012-04-23 05:45:04 +0000",
  "in_reply_to_screen_name" : "ryanmcminn",
  "in_reply_to_user_id_str" : "12061042",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan McMinn",
      "screen_name" : "ryanmcminn",
      "indices" : [ 0, 11 ],
      "id_str" : "12061042",
      "id" : 12061042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194298921080725504",
  "geo" : { },
  "id_str" : "194299710603927552",
  "in_reply_to_user_id" : 12061042,
  "text" : "@ryanmcminn They do seem pretty slick. But how do you compete with them?",
  "id" : 194299710603927552,
  "in_reply_to_status_id" : 194298921080725504,
  "created_at" : "2012-04-23 05:40:35 +0000",
  "in_reply_to_screen_name" : "ryanmcminn",
  "in_reply_to_user_id_str" : "12061042",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan McMinn",
      "screen_name" : "ryanmcminn",
      "indices" : [ 0, 11 ],
      "id_str" : "12061042",
      "id" : 12061042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194269721108021248",
  "geo" : { },
  "id_str" : "194298395890950145",
  "in_reply_to_user_id" : 12061042,
  "text" : "@ryanmcminn What was the product that you saw?",
  "id" : 194298395890950145,
  "in_reply_to_status_id" : 194269721108021248,
  "created_at" : "2012-04-23 05:35:22 +0000",
  "in_reply_to_screen_name" : "ryanmcminn",
  "in_reply_to_user_id_str" : "12061042",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/ZbAmWRfW",
      "expanded_url" : "http:\/\/flic.kr\/p\/bAVGwf",
      "display_url" : "flic.kr\/p\/bAVGwf"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.609, -122.31 ]
  },
  "id_str" : "194273324564611073",
  "text" : "8:36pm First awesome BBQ of the year http:\/\/t.co\/ZbAmWRfW",
  "id" : 194273324564611073,
  "created_at" : "2012-04-23 03:55:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/0kzxMiHW",
      "expanded_url" : "http:\/\/instagr.am\/p\/Jv0cFfI0Jh\/",
      "display_url" : "instagr.am\/p\/Jv0cFfI0Jh\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.609043, -122.310045 ]
  },
  "id_str" : "194267556071219201",
  "text" : "Sunglasses inside  @ Pixel Palace Hostel and Petting Zoo http:\/\/t.co\/0kzxMiHW",
  "id" : 194267556071219201,
  "created_at" : "2012-04-23 03:32:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric A. Meyer",
      "screen_name" : "meyerweb",
      "indices" : [ 0, 9 ],
      "id_str" : "646533",
      "id" : 646533
    }, {
      "name" : "Chris Dixon",
      "screen_name" : "cdixon",
      "indices" : [ 10, 17 ],
      "id_str" : "2529971",
      "id" : 2529971
    }, {
      "name" : "Derek Powazek",
      "screen_name" : "derekpowazek",
      "indices" : [ 18, 31 ],
      "id_str" : "560734031",
      "id" : 560734031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194235049204391937",
  "geo" : { },
  "id_str" : "194236240059576320",
  "in_reply_to_user_id" : 646533,
  "text" : "@meyerweb @cdixon @derekpowazek Technically, yeah.",
  "id" : 194236240059576320,
  "in_reply_to_status_id" : 194235049204391937,
  "created_at" : "2012-04-23 01:28:23 +0000",
  "in_reply_to_screen_name" : "meyerweb",
  "in_reply_to_user_id_str" : "646533",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dixon",
      "screen_name" : "cdixon",
      "indices" : [ 46, 53 ],
      "id_str" : "2529971",
      "id" : 2529971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/TqYkXbor",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=S0qjK3TWZE8",
      "display_url" : "youtube.com\/watch?v=S0qjK3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194219158022524928",
  "text" : "Great dramatization of Prisoner's Dilemma. RT @cdixon: If you are at all interested in game theory, this is amazing. http:\/\/t.co\/TqYkXbor",
  "id" : 194219158022524928,
  "created_at" : "2012-04-23 00:20:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Pike",
      "screen_name" : "stringfellow",
      "indices" : [ 0, 13 ],
      "id_str" : "702253",
      "id" : 702253
    }, {
      "name" : "Basheera Khan",
      "screen_name" : "Bash",
      "indices" : [ 14, 19 ],
      "id_str" : "64313",
      "id" : 64313
    }, {
      "name" : "James Tauber",
      "screen_name" : "jtauber",
      "indices" : [ 20, 28 ],
      "id_str" : "1583811",
      "id" : 1583811
    }, {
      "name" : "habitualist",
      "screen_name" : "habitualist",
      "indices" : [ 29, 41 ],
      "id_str" : "14289713",
      "id" : 14289713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194197192712519680",
  "geo" : { },
  "id_str" : "194198698140504064",
  "in_reply_to_user_id" : 702253,
  "text" : "@stringfellow @bash @jtauber @habitualist No I haven't seen that yet. Looks interesting though, would love to try it out!",
  "id" : 194198698140504064,
  "in_reply_to_status_id" : 194197192712519680,
  "created_at" : "2012-04-22 22:59:12 +0000",
  "in_reply_to_screen_name" : "stringfellow",
  "in_reply_to_user_id_str" : "702253",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Grant",
      "screen_name" : "flexewebs",
      "indices" : [ 0, 10 ],
      "id_str" : "14322946",
      "id" : 14322946
    }, {
      "name" : "Basheera Khan",
      "screen_name" : "Bash",
      "indices" : [ 11, 16 ],
      "id_str" : "64313",
      "id" : 64313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194186854592028672",
  "geo" : { },
  "id_str" : "194187169055772672",
  "in_reply_to_user_id" : 14322946,
  "text" : "@flexewebs @bash I see where you're coming from. I just DO think it's okay to fail. Difference in approach...",
  "id" : 194187169055772672,
  "in_reply_to_status_id" : 194186854592028672,
  "created_at" : "2012-04-22 22:13:23 +0000",
  "in_reply_to_screen_name" : "flexewebs",
  "in_reply_to_user_id_str" : "14322946",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Grant",
      "screen_name" : "flexewebs",
      "indices" : [ 0, 10 ],
      "id_str" : "14322946",
      "id" : 14322946
    }, {
      "name" : "Basheera Khan",
      "screen_name" : "Bash",
      "indices" : [ 11, 16 ],
      "id_str" : "64313",
      "id" : 64313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194185518534234114",
  "geo" : { },
  "id_str" : "194185913574752256",
  "in_reply_to_user_id" : 14322946,
  "text" : "@flexewebs @bash \"I will\" is a lie. \"I'm gonna try\" is honest. I believe that the best way to change behavior is to face the truth.",
  "id" : 194185913574752256,
  "in_reply_to_status_id" : 194185518534234114,
  "created_at" : "2012-04-22 22:08:24 +0000",
  "in_reply_to_screen_name" : "flexewebs",
  "in_reply_to_user_id_str" : "14322946",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Grant",
      "screen_name" : "flexewebs",
      "indices" : [ 0, 10 ],
      "id_str" : "14322946",
      "id" : 14322946
    }, {
      "name" : "Basheera Khan",
      "screen_name" : "Bash",
      "indices" : [ 115, 120 ],
      "id_str" : "64313",
      "id" : 64313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194180225792344064",
  "geo" : { },
  "id_str" : "194181539033120769",
  "in_reply_to_user_id" : 14322946,
  "text" : "@flexewebs I differ with you there. Trying is all we can do, and failing to succeed is okay. Just keep trying. \/cc @bash",
  "id" : 194181539033120769,
  "in_reply_to_status_id" : 194180225792344064,
  "created_at" : "2012-04-22 21:51:01 +0000",
  "in_reply_to_screen_name" : "flexewebs",
  "in_reply_to_user_id_str" : "14322946",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/cUTX84Fx",
      "expanded_url" : "http:\/\/incubator.quasimondo.com\/moodbattle\/",
      "display_url" : "incubator.quasimondo.com\/moodbattle\/"
    } ]
  },
  "geo" : { },
  "id_str" : "194177926730756097",
  "text" : "Test your smile score here (I got 77): http:\/\/t.co\/cUTX84Fx",
  "id" : 194177926730756097,
  "created_at" : "2012-04-22 21:36:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trapper Markelz",
      "screen_name" : "trappermarkelz",
      "indices" : [ 0, 15 ],
      "id_str" : "1032241",
      "id" : 1032241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194175992590376960",
  "geo" : { },
  "id_str" : "194177524228567041",
  "in_reply_to_user_id" : 1032241,
  "text" : "@trappermarkelz Yeah, someone should make it!",
  "id" : 194177524228567041,
  "in_reply_to_status_id" : 194175992590376960,
  "created_at" : "2012-04-22 21:35:04 +0000",
  "in_reply_to_screen_name" : "trappermarkelz",
  "in_reply_to_user_id_str" : "1032241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali McC",
      "screen_name" : "AliMoonGoddess",
      "indices" : [ 3, 18 ],
      "id_str" : "22517707",
      "id" : 22517707
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 20, 33 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194177462299660288",
  "text" : "RT @AliMoonGoddess: @busterbenson which do you believe came first, the chicken, the egg or the mongoose?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194177209253105664",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson which do you believe came first, the chicken, the egg or the mongoose?",
    "id" : 194177209253105664,
    "created_at" : "2012-04-22 21:33:48 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Ali McC",
      "screen_name" : "AliMoonGoddess",
      "protected" : false,
      "id_str" : "22517707",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443967214438207488\/qnhmm8BB_normal.jpeg",
      "id" : 22517707,
      "verified" : false
    }
  },
  "id" : 194177462299660288,
  "created_at" : "2012-04-22 21:34:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Troy Davis",
      "screen_name" : "troyd",
      "indices" : [ 22, 28 ],
      "id_str" : "14701738",
      "id" : 14701738
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 30, 43 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194175753661845505",
  "text" : "It's getting meta! RT @troyd: @busterbenson what belief do you consider most beneficial to society? most detrimental?",
  "id" : 194175753661845505,
  "created_at" : "2012-04-22 21:28:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Kathleen Peck",
      "screen_name" : "sarahkpeck",
      "indices" : [ 21, 32 ],
      "id_str" : "196745496",
      "id" : 196745496
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 34, 47 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194172985966469120",
  "text" : "Awesome one. Thx. RT @sarahkpeck: @busterbenson ... that the internet is a good thing?",
  "id" : 194172985966469120,
  "created_at" : "2012-04-22 21:17:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Hahn",
      "screen_name" : "EvanHahn",
      "indices" : [ 20, 29 ],
      "id_str" : "15176234",
      "id" : 15176234
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 31, 44 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194172888264343552",
  "text" : "Perfect. Thanks. RT @EvanHahn: @busterbenson Do you believe in fate? Soul mates? Afterlife?",
  "id" : 194172888264343552,
  "created_at" : "2012-04-22 21:16:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194172550132146176",
  "text" : "I need examples of interesting beliefs to add to my belief doc. Ask me questions! (i.e. \"Do you believe in X?)",
  "id" : 194172550132146176,
  "created_at" : "2012-04-22 21:15:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/w6lrCLn8",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayK7RtgN",
      "display_url" : "tmblr.co\/ZQJvayK7RtgN"
    } ]
  },
  "geo" : { },
  "id_str" : "194171433188999168",
  "text" : "I'm not very good at smiling on demand. Can you get better than 77? http:\/\/t.co\/w6lrCLn8",
  "id" : 194171433188999168,
  "created_at" : "2012-04-22 21:10:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/4X9cPApr",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ju_EpCI0Am\/",
      "display_url" : "instagr.am\/p\/Ju_EpCI0Am\/"
    } ]
  },
  "geo" : { },
  "id_str" : "194150234295779328",
  "text" : "Whatcha gonna do bout it? http:\/\/t.co\/4X9cPApr",
  "id" : 194150234295779328,
  "created_at" : "2012-04-22 19:46:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 3, 14 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194141565655064576",
  "text" : "RT @nikobenson: The world is divided into two things: choo and choo track.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194141349170266112",
    "text" : "The world is divided into two things: choo and choo track.",
    "id" : 194141349170266112,
    "created_at" : "2012-04-22 19:11:19 +0000",
    "user" : {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "protected" : false,
      "id_str" : "142467448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000616213793\/9f77fe6693d877565cd97b6a2381c40c_normal.jpeg",
      "id" : 142467448,
      "verified" : false
    }
  },
  "id" : 194141565655064576,
  "created_at" : "2012-04-22 19:12:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/tV3UCvhr",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ju0R4uo0L4\/",
      "display_url" : "instagr.am\/p\/Ju0R4uo0L4\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6098882294, -122.319009304 ]
  },
  "id_str" : "194126720897519618",
  "text" : "Niko's wood chip displacement program at work  @ Seattle University Quad http:\/\/t.co\/tV3UCvhr",
  "id" : 194126720897519618,
  "created_at" : "2012-04-22 18:13:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gonnatry",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/FHqyoJuG",
      "expanded_url" : "http:\/\/gonnatry.com\/to\/make-a-list-of-my-beliefs\/by\/2012-04-23\/507",
      "display_url" : "gonnatry.com\/to\/make-a-list\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194112640631574528",
  "text" : "I'm gonna try to make a list of my beliefs by tomorrow. http:\/\/t.co\/FHqyoJuG #gonnatry",
  "id" : 194112640631574528,
  "created_at" : "2012-04-22 17:17:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Meyers",
      "screen_name" : "jeremymeyers",
      "indices" : [ 0, 13 ],
      "id_str" : "16818880",
      "id" : 16818880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "194109700848099328",
  "geo" : { },
  "id_str" : "194111032506060800",
  "in_reply_to_user_id" : 16818880,
  "text" : "@jeremymeyers That's pretty broad\u2026 which part of the self?",
  "id" : 194111032506060800,
  "in_reply_to_status_id" : 194109700848099328,
  "created_at" : "2012-04-22 17:10:51 +0000",
  "in_reply_to_screen_name" : "jeremymeyers",
  "in_reply_to_user_id_str" : "16818880",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194109289139421189",
  "text" : "Which categories of belief are interesting (to you) to explore? Religion, politics, tech, free will, ghosts, ice cream flavors\u2026 ?",
  "id" : 194109289139421189,
  "created_at" : "2012-04-22 17:03:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/cLIOiKTh",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayK6E47J",
      "display_url" : "tmblr.co\/ZQJvayK6E47J"
    } ]
  },
  "geo" : { },
  "id_str" : "194104522421964801",
  "text" : "Gonna try something today: make a list of things I believe. You should do it too! http:\/\/t.co\/cLIOiKTh",
  "id" : 194104522421964801,
  "created_at" : "2012-04-22 16:44:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/UbIhXICk",
      "expanded_url" : "http:\/\/flic.kr\/p\/bAziqw",
      "display_url" : "flic.kr\/p\/bAziqw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614833, -122.328834 ]
  },
  "id_str" : "193909115100205058",
  "text" : "8:36pm Walking home, head in a weird foggy hyper bouncing place http:\/\/t.co\/UbIhXICk",
  "id" : 193909115100205058,
  "created_at" : "2012-04-22 03:48:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Heitzeberg",
      "screen_name" : "jheitzeb",
      "indices" : [ 0, 9 ],
      "id_str" : "6629572",
      "id" : 6629572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193874839927398400",
  "geo" : { },
  "id_str" : "193896357977800705",
  "in_reply_to_user_id" : 6629572,
  "text" : "@jheitzeb That's what I liked about it too.",
  "id" : 193896357977800705,
  "in_reply_to_status_id" : 193874839927398400,
  "created_at" : "2012-04-22 02:57:48 +0000",
  "in_reply_to_screen_name" : "jheitzeb",
  "in_reply_to_user_id_str" : "6629572",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bucket List Society",
      "screen_name" : "bucketlistsoc",
      "indices" : [ 0, 14 ],
      "id_str" : "452619716",
      "id" : 452619716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193875085780725760",
  "geo" : { },
  "id_str" : "193896240029777921",
  "in_reply_to_user_id" : 452619716,
  "text" : "@bucketlistsoc I agree!",
  "id" : 193896240029777921,
  "in_reply_to_status_id" : 193875085780725760,
  "created_at" : "2012-04-22 02:57:20 +0000",
  "in_reply_to_screen_name" : "bucketlistsoc",
  "in_reply_to_user_id_str" : "452619716",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 126, 135 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/yT7zqrZI",
      "expanded_url" : "http:\/\/paulgraham.com\/todo.html",
      "display_url" : "paulgraham.com\/todo.html"
    } ]
  },
  "geo" : { },
  "id_str" : "193873533485584384",
  "text" : "Don't ignore your dreams; don't work too much; say what you think; cultivate friendships; be happy. http:\/\/t.co\/yT7zqrZI \/via @arainert",
  "id" : 193873533485584384,
  "created_at" : "2012-04-22 01:27:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/lhNt2H0P",
      "expanded_url" : "http:\/\/rdd.me\/tapxiwuc",
      "display_url" : "rdd.me\/tapxiwuc"
    } ]
  },
  "geo" : { },
  "id_str" : "193860659002351616",
  "text" : "\"Why We Havent Met Any Aliens\" http:\/\/t.co\/lhNt2H0P",
  "id" : 193860659002351616,
  "created_at" : "2012-04-22 00:35:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/MyrMfAFI",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayK3AJVi",
      "display_url" : "tmblr.co\/ZQJvayK3AJVi"
    } ]
  },
  "geo" : { },
  "id_str" : "193828499461644288",
  "text" : "Photo:  http:\/\/t.co\/MyrMfAFI",
  "id" : 193828499461644288,
  "created_at" : "2012-04-21 22:28:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/4dPJABIm",
      "expanded_url" : "http:\/\/flic.kr\/p\/bPe3aR",
      "display_url" : "flic.kr\/p\/bPe3aR"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306167 ]
  },
  "id_str" : "193553585634676739",
  "text" : "8:36pm Watching sloth orphanage videos on YouTube with Tyler http:\/\/t.co\/4dPJABIm",
  "id" : 193553585634676739,
  "created_at" : "2012-04-21 04:15:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Kleon",
      "screen_name" : "austinkleon",
      "indices" : [ 56, 68 ],
      "id_str" : "9698942",
      "id" : 9698942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193432057962184705",
  "text" : "\"Write the [tweet] you want to read.\" - paraphrase from @austinkleon's \"Steal Like an Artist\"",
  "id" : 193432057962184705,
  "created_at" : "2012-04-20 20:12:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Calvin Spealman",
      "screen_name" : "ironfroggy",
      "indices" : [ 0, 11 ],
      "id_str" : "5622042",
      "id" : 5622042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193430617038401536",
  "geo" : { },
  "id_str" : "193430917291843584",
  "in_reply_to_user_id" : 5622042,
  "text" : "@ironfroggy True. There's clearly an algorithm behind it - trying to reverse engineer it a bit. And maybe come up with something better\u2026",
  "id" : 193430917291843584,
  "in_reply_to_status_id" : 193430617038401536,
  "created_at" : "2012-04-20 20:08:19 +0000",
  "in_reply_to_screen_name" : "ironfroggy",
  "in_reply_to_user_id_str" : "5622042",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NikeFuel",
      "screen_name" : "NikeFuel",
      "indices" : [ 109, 118 ],
      "id_str" : "466807381",
      "id" : 466807381
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makeitcount",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193430361244569600",
  "text" : "I got 19 Fuel for walking one block, and 18 for running the same block. Shouldn't running be worth more? \/cc @nikefuel #makeitcount",
  "id" : 193430361244569600,
  "created_at" : "2012-04-20 20:06:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Kleon",
      "screen_name" : "austinkleon",
      "indices" : [ 125, 137 ],
      "id_str" : "9698942",
      "id" : 9698942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193419224289521665",
  "text" : "\"Everything that needs to be said has already been said. But since nobody was listening, everything must be said again.\" via @austinkleon",
  "id" : 193419224289521665,
  "created_at" : "2012-04-20 19:21:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 0, 12 ],
      "id_str" : "15019184",
      "id" : 15019184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193413880918196224",
  "geo" : { },
  "id_str" : "193414233357164545",
  "in_reply_to_user_id" : 15019184,
  "text" : "@heyamberrae Names are magic that way.",
  "id" : 193414233357164545,
  "in_reply_to_status_id" : 193413880918196224,
  "created_at" : "2012-04-20 19:02:01 +0000",
  "in_reply_to_screen_name" : "heyamberrae",
  "in_reply_to_user_id_str" : "15019184",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 0, 12 ],
      "id_str" : "15019184",
      "id" : 15019184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193413286157488128",
  "geo" : { },
  "id_str" : "193413756615798784",
  "in_reply_to_user_id" : 15019184,
  "text" : "@heyamberrae That's awesome! Congrats! Do you feel like a new person?",
  "id" : 193413756615798784,
  "in_reply_to_status_id" : 193413286157488128,
  "created_at" : "2012-04-20 19:00:07 +0000",
  "in_reply_to_screen_name" : "heyamberrae",
  "in_reply_to_user_id_str" : "15019184",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193395643459436544",
  "geo" : { },
  "id_str" : "193395809440628736",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez Awesome. Let me know if you need someone to help test it. :)",
  "id" : 193395809440628736,
  "in_reply_to_status_id" : 193395643459436544,
  "created_at" : "2012-04-20 17:48:48 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187617518578438144",
  "geo" : { },
  "id_str" : "193395293604163584",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez You should totally make that.",
  "id" : 193395293604163584,
  "in_reply_to_status_id" : 187617518578438144,
  "created_at" : "2012-04-20 17:46:45 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/fMclVuuO",
      "expanded_url" : "http:\/\/bustr.me\/post\/21441635599\/in-article-after-article-one-theme-emerges-from",
      "display_url" : "bustr.me\/post\/214416355\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "193389958424313856",
  "text" : "Quote from an Atlantic article on digital willpower: http:\/\/t.co\/fMclVuuO",
  "id" : 193389958424313856,
  "created_at" : "2012-04-20 17:25:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Ioan Mitrea",
      "screen_name" : "awarenesss",
      "indices" : [ 11, 22 ],
      "id_str" : "18603224",
      "id" : 18603224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "193365072985325569",
  "geo" : { },
  "id_str" : "193367324441579520",
  "in_reply_to_user_id" : 18603224,
  "text" : "@e_ramirez @awarenesss That was my first instinct too.",
  "id" : 193367324441579520,
  "in_reply_to_status_id" : 193365072985325569,
  "created_at" : "2012-04-20 15:55:37 +0000",
  "in_reply_to_screen_name" : "awarenesss",
  "in_reply_to_user_id_str" : "18603224",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 102, 112 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/b9RkpOk7",
      "expanded_url" : "http:\/\/developers.face.com\/",
      "display_url" : "developers.face.com"
    } ]
  },
  "geo" : { },
  "id_str" : "193361615314370560",
  "text" : "Impressed by this face-detection API: http:\/\/t.co\/b9RkpOk7 What cool things could we do with it? \/via @e_ramirez",
  "id" : 193361615314370560,
  "created_at" : "2012-04-20 15:32:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/445wgbnr",
      "expanded_url" : "http:\/\/bit.ly\/It5z0C",
      "display_url" : "bit.ly\/It5z0C"
    } ]
  },
  "geo" : { },
  "id_str" : "193348491270037504",
  "text" : "\"There are infinitely many infinities, each one infinitely bigger than the last.\" http:\/\/t.co\/445wgbnr",
  "id" : 193348491270037504,
  "created_at" : "2012-04-20 14:40:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/aH8sbOuS",
      "expanded_url" : "http:\/\/flic.kr\/p\/bA61Ro",
      "display_url" : "flic.kr\/p\/bA61Ro"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "193204297050238976",
  "text" : "8:36pm My number one fan http:\/\/t.co\/aH8sbOuS",
  "id" : 193204297050238976,
  "created_at" : "2012-04-20 05:07:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/7B4NMeV2",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayJygZN3",
      "display_url" : "tmblr.co\/ZQJvayJygZN3"
    } ]
  },
  "geo" : { },
  "id_str" : "193174905255231489",
  "text" : "Photo: fitocracy: I like this. http:\/\/t.co\/7B4NMeV2",
  "id" : 193174905255231489,
  "created_at" : "2012-04-20 03:11:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToutApp",
      "screen_name" : "toutapp",
      "indices" : [ 3, 11 ],
      "id_str" : "132017361",
      "id" : 132017361
    }, {
      "name" : "Lifehacker",
      "screen_name" : "lifehacker",
      "indices" : [ 50, 61 ],
      "id_str" : "7144422",
      "id" : 7144422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/A79tCaQA",
      "expanded_url" : "http:\/\/lifehacker.com\/5903086\/email-is-not-broken-we-are",
      "display_url" : "lifehacker.com\/5903086\/email-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "193085091960983552",
  "text" : "RT @toutapp: Email: Email Is Not Broken; We Are - @Lifehacker http:\/\/t.co\/A79tCaQA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lifehacker",
        "screen_name" : "lifehacker",
        "indices" : [ 37, 48 ],
        "id_str" : "7144422",
        "id" : 7144422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/A79tCaQA",
        "expanded_url" : "http:\/\/lifehacker.com\/5903086\/email-is-not-broken-we-are",
        "display_url" : "lifehacker.com\/5903086\/email-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "193082818094579715",
    "text" : "Email: Email Is Not Broken; We Are - @Lifehacker http:\/\/t.co\/A79tCaQA",
    "id" : 193082818094579715,
    "created_at" : "2012-04-19 21:05:05 +0000",
    "user" : {
      "name" : "ToutApp",
      "screen_name" : "toutapp",
      "protected" : false,
      "id_str" : "132017361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3280466456\/414e8b18baa2aa8b02bbae56dfdc2916_normal.png",
      "id" : 132017361,
      "verified" : false
    }
  },
  "id" : 193085091960983552,
  "created_at" : "2012-04-19 21:14:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shauna Causey",
      "screen_name" : "ShaunaCausey",
      "indices" : [ 3, 16 ],
      "id_str" : "15040500",
      "id" : 15040500
    }, {
      "name" : "decide",
      "screen_name" : "decide",
      "indices" : [ 32, 39 ],
      "id_str" : "242611012",
      "id" : 242611012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/bOPi0nle",
      "expanded_url" : "http:\/\/bit.ly\/HTuOHl",
      "display_url" : "bit.ly\/HTuOHl"
    } ]
  },
  "geo" : { },
  "id_str" : "193063263892811776",
  "text" : "RT @ShaunaCausey: New Launch at @Decide today: Technology that predicts the lowest price, or pays you the difference: http:\/\/t.co\/bOPi0nle",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "decide",
        "screen_name" : "decide",
        "indices" : [ 14, 21 ],
        "id_str" : "242611012",
        "id" : 242611012
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/bOPi0nle",
        "expanded_url" : "http:\/\/bit.ly\/HTuOHl",
        "display_url" : "bit.ly\/HTuOHl"
      } ]
    },
    "geo" : { },
    "id_str" : "193018911111913472",
    "text" : "New Launch at @Decide today: Technology that predicts the lowest price, or pays you the difference: http:\/\/t.co\/bOPi0nle",
    "id" : 193018911111913472,
    "created_at" : "2012-04-19 16:51:09 +0000",
    "user" : {
      "name" : "Shauna Causey",
      "screen_name" : "ShaunaCausey",
      "protected" : false,
      "id_str" : "15040500",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1104781830\/shauna_causey_073_lowres_b_normal.jpg",
      "id" : 15040500,
      "verified" : false
    }
  },
  "id" : 193063263892811776,
  "created_at" : "2012-04-19 19:47:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Umami",
      "screen_name" : "joshumami",
      "indices" : [ 0, 10 ],
      "id_str" : "11815632",
      "id" : 11815632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192859156091387905",
  "geo" : { },
  "id_str" : "193011685668302848",
  "in_reply_to_user_id" : 11815632,
  "text" : "@joshumami I think that's getting closer. Logic is the attempt to tie facts together. But even facts get fuzzy around the edges sometimes.",
  "id" : 193011685668302848,
  "in_reply_to_status_id" : 192859156091387905,
  "created_at" : "2012-04-19 16:22:26 +0000",
  "in_reply_to_screen_name" : "joshumami",
  "in_reply_to_user_id_str" : "11815632",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192842960751165440",
  "geo" : { },
  "id_str" : "192852916619583490",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit Isn't that a bit like saying \"this house I built might have hidden rooms\"? Let's bring this up again when we meet next week!",
  "id" : 192852916619583490,
  "in_reply_to_status_id" : 192842960751165440,
  "created_at" : "2012-04-19 05:51:33 +0000",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192837970691235840",
  "geo" : { },
  "id_str" : "192840009840205824",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit What about G\u00F6del's Incompleteness Theorem? Mu? Something from nothing? Before the beginning? Infinity? Isn't logic man made?",
  "id" : 192840009840205824,
  "in_reply_to_status_id" : 192837970691235840,
  "created_at" : "2012-04-19 05:00:15 +0000",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tavis Rudd",
      "screen_name" : "tavisrudd",
      "indices" : [ 0, 10 ],
      "id_str" : "187354174",
      "id" : 187354174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192835422316003329",
  "geo" : { },
  "id_str" : "192837475134214144",
  "in_reply_to_user_id" : 187354174,
  "text" : "@tavisrudd Yeah it's on indefinite hiatus. It's just not in their DNA.",
  "id" : 192837475134214144,
  "in_reply_to_status_id" : 192835422316003329,
  "created_at" : "2012-04-19 04:50:11 +0000",
  "in_reply_to_screen_name" : "tavisrudd",
  "in_reply_to_user_id_str" : "187354174",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192837354032074754",
  "text" : "We live in a universe where logic has been proven wrong. T\/F?",
  "id" : 192837354032074754,
  "created_at" : "2012-04-19 04:49:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 1, 13 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nikefuel",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192834140519940096",
  "geo" : { },
  "id_str" : "192834679697702912",
  "in_reply_to_user_id" : 30801469,
  "text" : ".@nickcrocker Hardware is 9\/10, software is 6\/10 on simplicity\/MVP, 2\/10 on social, 0\/10 on data portability\/API. #nikefuel",
  "id" : 192834679697702912,
  "in_reply_to_status_id" : 192834140519940096,
  "created_at" : "2012-04-19 04:39:04 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192833666353856512",
  "geo" : { },
  "id_str" : "192833903541760001",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker I approved the message but am disappointed that it didn't link to my profile.",
  "id" : 192833903541760001,
  "in_reply_to_status_id" : 192833666353856512,
  "created_at" : "2012-04-19 04:35:59 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.nike.com\" rel=\"nofollow\"\u003ENike Application\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/lkrykiQ3",
      "expanded_url" : "http:\/\/nikeplus.com\/fuelband",
      "display_url" : "nikeplus.com\/fuelband"
    } ]
  },
  "geo" : { },
  "id_str" : "192832866579791874",
  "text" : "I quadrupled my Daily Goal. See how my Nike+ FuelBand helps me blast off: http:\/\/t.co\/lkrykiQ3",
  "id" : 192832866579791874,
  "created_at" : "2012-04-19 04:31:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/k4pwURLE",
      "expanded_url" : "http:\/\/flic.kr\/p\/bzQ9Lq",
      "display_url" : "flic.kr\/p\/bzQ9Lq"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614, -122.317334 ]
  },
  "id_str" : "192830992078209024",
  "text" : "8:36pm On a self-date at Unicorn http:\/\/t.co\/k4pwURLE",
  "id" : 192830992078209024,
  "created_at" : "2012-04-19 04:24:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192801344124497921",
  "geo" : { },
  "id_str" : "192806841305141249",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten I wonder if that's what they used to say about driving, or flying. \"If we were meant to fly God would have made us birds!\"",
  "id" : 192806841305141249,
  "in_reply_to_status_id" : 192801344124497921,
  "created_at" : "2012-04-19 02:48:27 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/tLb4KBsK",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayJv1fuq",
      "display_url" : "tmblr.co\/ZQJvayJv1fuq"
    } ]
  },
  "geo" : { },
  "id_str" : "192788919987879936",
  "text" : "Ambiguous one-sided excerpt from a chat today: http:\/\/t.co\/tLb4KBsK",
  "id" : 192788919987879936,
  "created_at" : "2012-04-19 01:37:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeVore",
      "screen_name" : "crashdev",
      "indices" : [ 8, 17 ],
      "id_str" : "14763501",
      "id" : 14763501
    }, {
      "name" : "Alex Payne",
      "screen_name" : "al3x",
      "indices" : [ 31, 36 ],
      "id_str" : "18713",
      "id" : 18713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/SUre0utn",
      "expanded_url" : "http:\/\/www.crashdev.com\/2012\/04\/human-empowerment.html",
      "display_url" : "crashdev.com\/2012\/04\/human-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192786952314032131",
  "text" : "+100 RT @crashdev: Inspired by @al3x -- a hasty and impassioned defense of our technological future http:\/\/t.co\/SUre0utn",
  "id" : 192786952314032131,
  "created_at" : "2012-04-19 01:29:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingsiwant",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192785633998155776",
  "text" : "To be seen and heard, comfort, fun, connection, sugar, fat, salt, certainty, progress, respect, autonomy, mastery, purpose. #thingsiwant",
  "id" : 192785633998155776,
  "created_at" : "2012-04-19 01:24:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/cc42eX1o",
      "expanded_url" : "http:\/\/flic.kr\/p\/bNsUqV",
      "display_url" : "flic.kr\/p\/bNsUqV"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "192458531272798209",
  "text" : "8:36pm Staying in for date night: ice cream and The New Girl. Glad to be back home! http:\/\/t.co\/cc42eX1o",
  "id" : 192458531272798209,
  "created_at" : "2012-04-18 03:44:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy James Hall",
      "screen_name" : "JimmyJameson",
      "indices" : [ 0, 13 ],
      "id_str" : "35141809",
      "id" : 35141809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192428121109180416",
  "geo" : { },
  "id_str" : "192428405558480897",
  "in_reply_to_user_id" : 35141809,
  "text" : "@JimmyJameson Yes! We're back too! Ready for hanging out and travel tales!",
  "id" : 192428405558480897,
  "in_reply_to_status_id" : 192428121109180416,
  "created_at" : "2012-04-18 01:44:41 +0000",
  "in_reply_to_screen_name" : "JimmyJameson",
  "in_reply_to_user_id_str" : "35141809",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192426652184215552",
  "geo" : { },
  "id_str" : "192427045756739584",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar Woah! Hats off to you. How did you do it??",
  "id" : 192427045756739584,
  "in_reply_to_status_id" : 192426652184215552,
  "created_at" : "2012-04-18 01:39:17 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rob delaney",
      "screen_name" : "robdelaney",
      "indices" : [ 3, 14 ],
      "id_str" : "22084427",
      "id" : 22084427
    }, {
      "name" : "Heather B. Armstrong",
      "screen_name" : "dooce",
      "indices" : [ 23, 29 ],
      "id_str" : "5391882",
      "id" : 5391882
    }, {
      "name" : "Xeni Jardin",
      "screen_name" : "xeni",
      "indices" : [ 101, 106 ],
      "id_str" : "767",
      "id" : 767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192418111968915456",
  "text" : "RT @robdelaney: + 1 RT @dooce: Righteously indignant about the idea of universal healthcare? Go read @xeni's twitter stream and get back ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Heather B. Armstrong",
        "screen_name" : "dooce",
        "indices" : [ 7, 13 ],
        "id_str" : "5391882",
        "id" : 5391882
      }, {
        "name" : "Xeni Jardin",
        "screen_name" : "xeni",
        "indices" : [ 85, 90 ],
        "id_str" : "767",
        "id" : 767
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "192415632749363200",
    "text" : "+ 1 RT @dooce: Righteously indignant about the idea of universal healthcare? Go read @xeni's twitter stream and get back to me.",
    "id" : 192415632749363200,
    "created_at" : "2012-04-18 00:53:56 +0000",
    "user" : {
      "name" : "rob delaney",
      "screen_name" : "robdelaney",
      "protected" : false,
      "id_str" : "22084427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/418220613992345600\/izWms6G5_normal.jpeg",
      "id" : 22084427,
      "verified" : true
    }
  },
  "id" : 192418111968915456,
  "created_at" : "2012-04-18 01:03:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192408134311092225",
  "geo" : { },
  "id_str" : "192410364347031552",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb It was one of those sites that never got much past domain registration and some drawings, but I still think about it sometimes.",
  "id" : 192410364347031552,
  "in_reply_to_status_id" : 192408134311092225,
  "created_at" : "2012-04-18 00:33:00 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192402358653820929",
  "geo" : { },
  "id_str" : "192402511557165057",
  "in_reply_to_user_id" : 204025261,
  "text" : "@Michelle_Furedy Thank you!",
  "id" : 192402511557165057,
  "in_reply_to_status_id" : 192402358653820929,
  "created_at" : "2012-04-18 00:01:48 +0000",
  "in_reply_to_screen_name" : "m_furedy",
  "in_reply_to_user_id_str" : "204025261",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192402069909544961",
  "geo" : { },
  "id_str" : "192402447564673024",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb I like it! I once started a site that would only be open at noon and midnight, and would be generally unusable. Friction is fun!",
  "id" : 192402447564673024,
  "in_reply_to_status_id" : 192402069909544961,
  "created_at" : "2012-04-18 00:01:32 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 22, 31 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "groupmeh",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/2Gw7vyul",
      "expanded_url" : "http:\/\/www.betabeat.com\/2012\/04\/17\/a-call-for-an-anti-social-network\/",
      "display_url" : "betabeat.com\/2012\/04\/17\/a-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192401799196581889",
  "text" : "I think I finally get @rickwebb's idea of the anti-social network that he's been talking about for hears: http:\/\/t.co\/2Gw7vyul #groupmeh",
  "id" : 192401799196581889,
  "created_at" : "2012-04-17 23:58:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/WU6mq5bI",
      "expanded_url" : "http:\/\/bit.ly\/HGK2To",
      "display_url" : "bit.ly\/HGK2To"
    } ]
  },
  "geo" : { },
  "id_str" : "192360694224666624",
  "text" : "RT @the99percent: \"Create things that are hilarious, sad, beautiful, interesting inspiring or simply awesome.\" On getting more FB likes  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/WU6mq5bI",
        "expanded_url" : "http:\/\/bit.ly\/HGK2To",
        "display_url" : "bit.ly\/HGK2To"
      } ]
    },
    "geo" : { },
    "id_str" : "192356508418318336",
    "text" : "\"Create things that are hilarious, sad, beautiful, interesting inspiring or simply awesome.\" On getting more FB likes - http:\/\/t.co\/WU6mq5bI",
    "id" : 192356508418318336,
    "created_at" : "2012-04-17 20:59:00 +0000",
    "user" : {
      "name" : "99U",
      "screen_name" : "99u",
      "protected" : false,
      "id_str" : "17636894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2995676123\/fa7645dcc7f6d69b442bbcbd0950a0ef_normal.png",
      "id" : 17636894,
      "verified" : true
    }
  },
  "id" : 192360694224666624,
  "created_at" : "2012-04-17 21:15:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192344477745168384",
  "geo" : { },
  "id_str" : "192356671547375616",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Ears of fennec fox, eyes of husky pup, cheeks of hamster, fur of chinchilla, poses of meerkat, useless wings of baby penguin.",
  "id" : 192356671547375616,
  "in_reply_to_status_id" : 192344477745168384,
  "created_at" : "2012-04-17 20:59:38 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "indices" : [ 54, 63 ],
      "id_str" : "255784266",
      "id" : 255784266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "startupawards",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/4YzrWWGg",
      "expanded_url" : "http:\/\/www.geekwire.com\/events\/geekwire-presents-seattle-20-startup-awards\/#custom",
      "display_url" : "geekwire.com\/events\/geekwir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192302842109890560",
  "text" : "Wow! Stoked to be nominated for \"Geek of the Year\" by @geekwire. I'm up against some SERIOUS geeks here: http:\/\/t.co\/4YzrWWGg #startupawards",
  "id" : 192302842109890560,
  "created_at" : "2012-04-17 17:25:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NikeFuel",
      "screen_name" : "NikeFuel",
      "indices" : [ 44, 53 ],
      "id_str" : "466807381",
      "id" : 466807381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192276696039301120",
  "text" : "From what I can tell, Nike built an API for @nikefuel band, publicized it, then retreated shortly after the SXSW test. Hope it comes back.",
  "id" : 192276696039301120,
  "created_at" : "2012-04-17 15:41:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NikeFuel",
      "screen_name" : "NikeFuel",
      "indices" : [ 55, 64 ],
      "id_str" : "466807381",
      "id" : 466807381
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 66, 79 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192269303767236611",
  "text" : "Is one planned? Were all the tech blogs misleading us? @NikeFuel: @busterbenson There's not a public API for Nike+ FuelBand at this time.",
  "id" : 192269303767236611,
  "created_at" : "2012-04-17 15:12:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "indices" : [ 0, 4 ],
      "id_str" : "11822502",
      "id" : 11822502
    }, {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 5, 9 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192267871072698368",
  "geo" : { },
  "id_str" : "192268347281387520",
  "in_reply_to_user_id" : 11822502,
  "text" : "@mko @cap Well that is disappointing. Bad support or just vague CS guidance? Hoping the latter.",
  "id" : 192268347281387520,
  "in_reply_to_status_id" : 192267871072698368,
  "created_at" : "2012-04-17 15:08:40 +0000",
  "in_reply_to_screen_name" : "mko",
  "in_reply_to_user_id_str" : "11822502",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    }, {
      "name" : "Path",
      "screen_name" : "path",
      "indices" : [ 27, 32 ],
      "id_str" : "106333951",
      "id" : 106333951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192266855522639874",
  "geo" : { },
  "id_str" : "192267130320863232",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap From what I can tell, @path has access to Nike+ GPS and FuelBand is coming soon\u2026 but no confirmation there.",
  "id" : 192267130320863232,
  "in_reply_to_status_id" : 192266855522639874,
  "created_at" : "2012-04-17 15:03:50 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192266556166778883",
  "geo" : { },
  "id_str" : "192266950016106496",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap Having friends figured out and an API are sort of deal breakers for me\u2026 hope they get sorted soon.",
  "id" : 192266950016106496,
  "in_reply_to_status_id" : 192266556166778883,
  "created_at" : "2012-04-17 15:03:07 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NikeFuel",
      "screen_name" : "NikeFuel",
      "indices" : [ 13, 22 ],
      "id_str" : "466807381",
      "id" : 466807381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192266765877776387",
  "text" : "I heard that @nikefuel was opening up an API for some at SXSW, but can't find any news about it opening more than that. Anybody know?",
  "id" : 192266765877776387,
  "created_at" : "2012-04-17 15:02:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "192264814607859712",
  "geo" : { },
  "id_str" : "192266134169460736",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap Awesome! Do you like it? And how do I add you as a friend?",
  "id" : 192266134169460736,
  "in_reply_to_status_id" : 192264814607859712,
  "created_at" : "2012-04-17 14:59:53 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NikeFuel",
      "screen_name" : "NikeFuel",
      "indices" : [ 7, 16 ],
      "id_str" : "466807381",
      "id" : 466807381
    }, {
      "name" : "John Lowell",
      "screen_name" : "jthomas",
      "indices" : [ 34, 42 ],
      "id_str" : "760181",
      "id" : 760181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192264687205883904",
  "text" : "Got my @nikefuel band courtesy of @jthomas (thank you!). Who else has one?",
  "id" : 192264687205883904,
  "created_at" : "2012-04-17 14:54:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Pink",
      "screen_name" : "DanielPink",
      "indices" : [ 3, 14 ],
      "id_str" : "14378113",
      "id" : 14378113
    }, {
      "name" : "techdirt",
      "screen_name" : "techdirt",
      "indices" : [ 127, 136 ],
      "id_str" : "11382292",
      "id" : 11382292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/fOotnShP",
      "expanded_url" : "http:\/\/www.techdirt.com\/blog\/innovation\/articles\/20120409\/03412518422\/why-netflix-never-implemented-algorithm-that-won-netflix-1-million-challenge.shtml",
      "display_url" : "techdirt.com\/blog\/innovatio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192255216505196544",
  "text" : "RT @DanielPink: Why Netflix Never Implemented The Algorithm That Won The Netflix $1 Million Challenge http:\/\/t.co\/fOotnShP via @Techdirt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "techdirt",
        "screen_name" : "techdirt",
        "indices" : [ 111, 120 ],
        "id_str" : "11382292",
        "id" : 11382292
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/fOotnShP",
        "expanded_url" : "http:\/\/www.techdirt.com\/blog\/innovation\/articles\/20120409\/03412518422\/why-netflix-never-implemented-algorithm-that-won-netflix-1-million-challenge.shtml",
        "display_url" : "techdirt.com\/blog\/innovatio\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "192240535581376514",
    "text" : "Why Netflix Never Implemented The Algorithm That Won The Netflix $1 Million Challenge http:\/\/t.co\/fOotnShP via @Techdirt",
    "id" : 192240535581376514,
    "created_at" : "2012-04-17 13:18:09 +0000",
    "user" : {
      "name" : "Daniel Pink",
      "screen_name" : "DanielPink",
      "protected" : false,
      "id_str" : "14378113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2637496500\/ffbcf4c2dad36342fe310745b9ddefeb_normal.jpeg",
      "id" : 14378113,
      "verified" : true
    }
  },
  "id" : 192255216505196544,
  "created_at" : "2012-04-17 14:16:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 3, 15 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/WeAKTw2I",
      "expanded_url" : "http:\/\/j.mp\/IQxMSp",
      "display_url" : "j.mp\/IQxMSp"
    } ]
  },
  "geo" : { },
  "id_str" : "192083663599579138",
  "text" : "RT @brainpicker: Oh, snap. In one fell swoop, David Shields annihilates Jonathan Franzen http:\/\/t.co\/WeAKTw2I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/WeAKTw2I",
        "expanded_url" : "http:\/\/j.mp\/IQxMSp",
        "display_url" : "j.mp\/IQxMSp"
      } ]
    },
    "geo" : { },
    "id_str" : "192074912373014528",
    "text" : "Oh, snap. In one fell swoop, David Shields annihilates Jonathan Franzen http:\/\/t.co\/WeAKTw2I",
    "id" : 192074912373014528,
    "created_at" : "2012-04-17 02:20:02 +0000",
    "user" : {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "protected" : false,
      "id_str" : "9207632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/125575833\/twitter_normal.jpg",
      "id" : 9207632,
      "verified" : true
    }
  },
  "id" : 192083663599579138,
  "created_at" : "2012-04-17 02:54:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/ZjlUDBuT",
      "expanded_url" : "http:\/\/flic.kr\/p\/bNa6Bt",
      "display_url" : "flic.kr\/p\/bNa6Bt"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.899833, -97.037167 ]
  },
  "id_str" : "192066320991404032",
  "text" : "8:36pm Niko past bedtime in Dallas airport being obsessed with everything remotely \"choo\"-like http:\/\/t.co\/ZjlUDBuT",
  "id" : 192066320991404032,
  "created_at" : "2012-04-17 01:45:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 43, 54 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/VaybZHhX",
      "expanded_url" : "http:\/\/4sq.com\/HN3nlZ",
      "display_url" : "4sq.com\/HN3nlZ"
    } ]
  },
  "geo" : { },
  "id_str" : "191900164515053568",
  "text" : "I just unlocked the \u201C4sqDay 2012\u201D badge on @foursquare! Cupcakes and crowns for all! http:\/\/t.co\/VaybZHhX",
  "id" : 191900164515053568,
  "created_at" : "2012-04-16 14:45:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "MarshallHaas",
      "indices" : [ 0, 13 ],
      "id_str" : "1268491417",
      "id" : 1268491417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/GZZNk6B4",
      "expanded_url" : "http:\/\/bit.ly\/INWyCL",
      "display_url" : "bit.ly\/INWyCL"
    } ]
  },
  "in_reply_to_status_id_str" : "191731133204004865",
  "geo" : { },
  "id_str" : "191877331252543488",
  "in_reply_to_user_id" : 19028099,
  "text" : "@MarshallHaas I once owned http:\/\/t.co\/GZZNk6B4 but let it expire.",
  "id" : 191877331252543488,
  "in_reply_to_status_id" : 191731133204004865,
  "created_at" : "2012-04-16 13:14:55 +0000",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/9j0lnhm5",
      "expanded_url" : "http:\/\/urbanhonking.com\/ideasfordozens\/2012\/04\/15\/ai-unbundled\/",
      "display_url" : "urbanhonking.com\/ideasfordozens\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "191861746573639681",
  "text" : "Great explanation of how AI-inspired tech has evolved over last few decades:  http:\/\/t.co\/9j0lnhm5",
  "id" : 191861746573639681,
  "created_at" : "2012-04-16 12:12:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/7S1I2JdL",
      "expanded_url" : "http:\/\/flic.kr\/p\/bMQcni",
      "display_url" : "flic.kr\/p\/bMQcni"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 26.473999, -80.084 ]
  },
  "id_str" : "191693114333872128",
  "text" : "8:36pm Finishing awesome burgers with this happy guy http:\/\/t.co\/7S1I2JdL",
  "id" : 191693114333872128,
  "created_at" : "2012-04-16 01:02:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Pusateri",
      "screen_name" : "Cruftbox",
      "indices" : [ 0, 9 ],
      "id_str" : "792738",
      "id" : 792738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191653807409741825",
  "geo" : { },
  "id_str" : "191659012973006849",
  "in_reply_to_user_id" : 792738,
  "text" : "@Cruftbox Thanks! I'm interested in any novels that attempt to dramatize the singularity.",
  "id" : 191659012973006849,
  "in_reply_to_status_id" : 191653807409741825,
  "created_at" : "2012-04-15 22:47:24 +0000",
  "in_reply_to_screen_name" : "Cruftbox",
  "in_reply_to_user_id_str" : "792738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 119, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191647440523370499",
  "text" : "Just finished Fire Upon The Deep on the beach (the ideal Kindle environment). Now starting Accelerando. Who's read it? #books",
  "id" : 191647440523370499,
  "created_at" : "2012-04-15 22:01:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/HfNs5iTx",
      "expanded_url" : "http:\/\/flic.kr\/p\/bMtYjV",
      "display_url" : "flic.kr\/p\/bMtYjV"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 26.464333, -80.069 ]
  },
  "id_str" : "191328570344353793",
  "text" : "8:36pm Deliciousness at the best restaurant in Delray http:\/\/t.co\/HfNs5iTx",
  "id" : 191328570344353793,
  "created_at" : "2012-04-15 00:54:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/QH6mEcko",
      "expanded_url" : "http:\/\/instagr.am\/p\/Jadr8Qo0Oi\/",
      "display_url" : "instagr.am\/p\/Jadr8Qo0Oi\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 26.4748158397, -80.0841159791 ]
  },
  "id_str" : "191262130434088960",
  "text" : "Under a banyan with Kathy and Kayla  @ Lake Ida East Park http:\/\/t.co\/QH6mEcko",
  "id" : 191262130434088960,
  "created_at" : "2012-04-14 20:30:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/yMTODuMd",
      "expanded_url" : "http:\/\/flic.kr\/p\/byj2sh",
      "display_url" : "flic.kr\/p\/byj2sh"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 26.473999, -80.0835 ]
  },
  "id_str" : "190979379604635651",
  "text" : "8:36pm This is a nice place to hang out http:\/\/t.co\/yMTODuMd",
  "id" : 190979379604635651,
  "created_at" : "2012-04-14 01:46:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/ww6ave1p",
      "expanded_url" : "http:\/\/instagr.am\/p\/JXtwffo0BN\/",
      "display_url" : "instagr.am\/p\/JXtwffo0BN\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 26.46170655, -80.0719559833 ]
  },
  "id_str" : "190875358529191937",
  "text" : "Thunderstorm and mojitos  @ Cabana http:\/\/t.co\/ww6ave1p",
  "id" : 190875358529191937,
  "created_at" : "2012-04-13 18:53:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/eREEqTQX",
      "expanded_url" : "http:\/\/flic.kr\/p\/bLXxR4",
      "display_url" : "flic.kr\/p\/bLXxR4"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 26.473833, -80.083334 ]
  },
  "id_str" : "190604127083036673",
  "text" : "8:36pm Watching the first episode of Game of Thrones... why not? http:\/\/t.co\/eREEqTQX",
  "id" : 190604127083036673,
  "created_at" : "2012-04-13 00:55:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/uS7DdOW1",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayJYaz0J",
      "display_url" : "tmblr.co\/ZQJvayJYaz0J"
    } ]
  },
  "geo" : { },
  "id_str" : "190543966410780672",
  "text" : "It's Take-a-metaphor-too-far Thursday! http:\/\/t.co\/uS7DdOW1",
  "id" : 190543966410780672,
  "created_at" : "2012-04-12 20:56:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/rT9d5N1j",
      "expanded_url" : "http:\/\/instagr.am\/p\/JVHPO7o0I6\/",
      "display_url" : "instagr.am\/p\/JVHPO7o0I6\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 26.46139, -80.058433 ]
  },
  "id_str" : "190508924338843648",
  "text" : "The VegiFi  @ Burgerfi http:\/\/t.co\/rT9d5N1j",
  "id" : 190508924338843648,
  "created_at" : "2012-04-12 18:37:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 45, 56 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/M4dnDbRQ",
      "expanded_url" : "http:\/\/4sq.com\/HBf2Fg",
      "display_url" : "4sq.com\/HBf2Fg"
    } ]
  },
  "geo" : { },
  "id_str" : "190506293398745088",
  "text" : "I just unlocked the \u201CFlame Broiled\u201D badge on @foursquare! Cheeseburgers all around! http:\/\/t.co\/M4dnDbRQ",
  "id" : 190506293398745088,
  "created_at" : "2012-04-12 18:26:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    }, {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 14, 28 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190448984496668672",
  "geo" : { },
  "id_str" : "190491757853683713",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten @carinnatarvin Kindle actually makes the footnote back and forth a bit easier to navigate. Plus you don't look pretentious!",
  "id" : 190491757853683713,
  "in_reply_to_status_id" : 190448984496668672,
  "created_at" : "2012-04-12 17:29:08 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 54, 65 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/jW3uqVDD",
      "expanded_url" : "http:\/\/4sq.com\/I6ncmE",
      "display_url" : "4sq.com\/I6ncmE"
    } ]
  },
  "geo" : { },
  "id_str" : "190473876919156736",
  "text" : "I just unlocked the Level 2 \"Great Outdoors\" badge on @foursquare! In it to win it! http:\/\/t.co\/jW3uqVDD",
  "id" : 190473876919156736,
  "created_at" : "2012-04-12 16:18:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 48, 59 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/A7NjKnU3",
      "expanded_url" : "http:\/\/4sq.com\/I6neej",
      "display_url" : "4sq.com\/I6neej"
    } ]
  },
  "geo" : { },
  "id_str" : "190473877317627906",
  "text" : "I just unlocked the Level 2 \"Swimmies\" badge on @foursquare! In it to win it! http:\/\/t.co\/A7NjKnU3",
  "id" : 190473877317627906,
  "created_at" : "2012-04-12 16:18:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/VdibYreA",
      "expanded_url" : "http:\/\/instagr.am\/p\/JU2_k7o0C3\/",
      "display_url" : "instagr.am\/p\/JU2_k7o0C3\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 26.461045399, -80.0585746765 ]
  },
  "id_str" : "190473871269437440",
  "text" : "Beach times  @ The Beach @ Delray Beach http:\/\/t.co\/VdibYreA",
  "id" : 190473871269437440,
  "created_at" : "2012-04-12 16:18:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 78, 83 ],
      "id_str" : "528",
      "id" : 528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/7tK6OnXM",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayJXc6A9",
      "display_url" : "tmblr.co\/ZQJvayJXc6A9"
    } ]
  },
  "geo" : { },
  "id_str" : "190448746050490368",
  "text" : "\"A generalized economic theory of social networks\": http:\/\/t.co\/7tK6OnXM \/via @buzz",
  "id" : 190448746050490368,
  "created_at" : "2012-04-12 14:38:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190351888976330752",
  "geo" : { },
  "id_str" : "190444811579424770",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin You're clearly not taking \"infinite\" as literally as I am.",
  "id" : 190444811579424770,
  "in_reply_to_status_id" : 190351888976330752,
  "created_at" : "2012-04-12 14:22:36 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "190242085377540096",
  "geo" : { },
  "id_str" : "190249423408861184",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne Sort of! A much-delayed vacation with key work-related day trips.",
  "id" : 190249423408861184,
  "in_reply_to_status_id" : 190242085377540096,
  "created_at" : "2012-04-12 01:26:11 +0000",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/B3fhEgaF",
      "expanded_url" : "http:\/\/flic.kr\/p\/bxMp4u",
      "display_url" : "flic.kr\/p\/bxMp4u"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 26.473833, -80.083334 ]
  },
  "id_str" : "190241205777469440",
  "text" : "8:36pm Dinner with Kathy and Patrick in Delray Beach, FL http:\/\/t.co\/B3fhEgaF",
  "id" : 190241205777469440,
  "created_at" : "2012-04-12 00:53:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Fogg",
      "screen_name" : "bjfogg",
      "indices" : [ 3, 10 ],
      "id_str" : "1118691",
      "id" : 1118691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/Tupu1rVR",
      "expanded_url" : "http:\/\/tinyhabits.com\/love",
      "display_url" : "tinyhabits.com\/love"
    } ]
  },
  "geo" : { },
  "id_str" : "190233558005194753",
  "text" : "RT @bjfogg: Get happier, fast, by creating Tiny Love Habits. I know it sounds wacky, but I'm convinced this matters: http:\/\/t.co\/Tupu1rVR",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/Tupu1rVR",
        "expanded_url" : "http:\/\/tinyhabits.com\/love",
        "display_url" : "tinyhabits.com\/love"
      } ]
    },
    "geo" : { },
    "id_str" : "189840484674449409",
    "text" : "Get happier, fast, by creating Tiny Love Habits. I know it sounds wacky, but I'm convinced this matters: http:\/\/t.co\/Tupu1rVR",
    "id" : 189840484674449409,
    "created_at" : "2012-04-10 22:21:13 +0000",
    "user" : {
      "name" : "BJ Fogg",
      "screen_name" : "bjfogg",
      "protected" : false,
      "id_str" : "1118691",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2230227057\/widecrop-mugshot-flip_smaller_normal.jpg",
      "id" : 1118691,
      "verified" : false
    }
  },
  "id" : 190233558005194753,
  "created_at" : "2012-04-12 00:23:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/mcpceTMm",
      "expanded_url" : "http:\/\/flic.kr\/p\/bxvKPs",
      "display_url" : "flic.kr\/p\/bxvKPs"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.762166, -75.5085 ]
  },
  "id_str" : "189886545023614976",
  "text" : "8:36pm Learning about acupuncture, reiki, and other fun things with Kellianne's old friends http:\/\/t.co\/mcpceTMm",
  "id" : 189886545023614976,
  "created_at" : "2012-04-11 01:24:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheAtlanticTech",
      "screen_name" : "TheAtlanticTECH",
      "indices" : [ 3, 19 ],
      "id_str" : "141335663",
      "id" : 141335663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/GsKL2px6",
      "expanded_url" : "http:\/\/theatln.tc\/HuXned",
      "display_url" : "theatln.tc\/HuXned"
    } ]
  },
  "geo" : { },
  "id_str" : "189833668674588674",
  "text" : "RT @TheAtlanticTECH: Hillary Clinton has responded to her meme ... with a meme http:\/\/t.co\/GsKL2px6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/GsKL2px6",
        "expanded_url" : "http:\/\/theatln.tc\/HuXned",
        "display_url" : "theatln.tc\/HuXned"
      } ]
    },
    "geo" : { },
    "id_str" : "189824493026426882",
    "text" : "Hillary Clinton has responded to her meme ... with a meme http:\/\/t.co\/GsKL2px6",
    "id" : 189824493026426882,
    "created_at" : "2012-04-10 21:17:40 +0000",
    "user" : {
      "name" : "TheAtlanticTech",
      "screen_name" : "TheAtlanticTECH",
      "protected" : false,
      "id_str" : "141335663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2624579126\/l2f3ixgtu7j2hxm9sq07_normal.png",
      "id" : 141335663,
      "verified" : true
    }
  },
  "id" : 189833668674588674,
  "created_at" : "2012-04-10 21:54:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Betabeat",
      "screen_name" : "betabeat",
      "indices" : [ 3, 12 ],
      "id_str" : "25372760",
      "id" : 25372760
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 49, 58 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Betabeat",
      "screen_name" : "betabeat",
      "indices" : [ 63, 72 ],
      "id_str" : "25372760",
      "id" : 25372760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/gCsaVaw6",
      "expanded_url" : "http:\/\/betabeat.com?p=38352",
      "display_url" : "betabeat.com\/?p=38352"
    } ]
  },
  "geo" : { },
  "id_str" : "189827229251944449",
  "text" : "RT @betabeat: Instagram and the Age of Upsets by @RickWebb via @Betabeat http:\/\/t.co\/gCsaVaw6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rick Webb",
        "screen_name" : "RickWebb",
        "indices" : [ 35, 44 ],
        "id_str" : "761628",
        "id" : 761628
      }, {
        "name" : "Betabeat",
        "screen_name" : "betabeat",
        "indices" : [ 49, 58 ],
        "id_str" : "25372760",
        "id" : 25372760
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/gCsaVaw6",
        "expanded_url" : "http:\/\/betabeat.com?p=38352",
        "display_url" : "betabeat.com\/?p=38352"
      } ]
    },
    "geo" : { },
    "id_str" : "189731654594596864",
    "text" : "Instagram and the Age of Upsets by @RickWebb via @Betabeat http:\/\/t.co\/gCsaVaw6",
    "id" : 189731654594596864,
    "created_at" : "2012-04-10 15:08:46 +0000",
    "user" : {
      "name" : "Betabeat",
      "screen_name" : "betabeat",
      "protected" : false,
      "id_str" : "25372760",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1277222317\/beta_beat_icon_normal.jpg",
      "id" : 25372760,
      "verified" : true
    }
  },
  "id" : 189827229251944449,
  "created_at" : "2012-04-10 21:28:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aubrey Sabala",
      "screen_name" : "Aubs",
      "indices" : [ 7, 12 ],
      "id_str" : "2781",
      "id" : 2781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/du8vazj5",
      "expanded_url" : "http:\/\/flic.kr\/p\/bL8dA6",
      "display_url" : "flic.kr\/p\/bL8dA6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.737, -73.993 ]
  },
  "id_str" : "189527902084276225",
  "text" : "8:36pm @Aubs is telling me about her crazy shoes and snowflake socks http:\/\/t.co\/du8vazj5",
  "id" : 189527902084276225,
  "created_at" : "2012-04-10 01:39:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/PcOw2AhE",
      "expanded_url" : "http:\/\/4sq.com\/IsNrSb",
      "display_url" : "4sq.com\/IsNrSb"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7370212052, -73.992962964 ]
  },
  "id_str" : "189479485291241472",
  "text" : "Who's out and about in NYC tonight? Hi! (@ Mesa Grill) http:\/\/t.co\/PcOw2AhE",
  "id" : 189479485291241472,
  "created_at" : "2012-04-09 22:26:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sessions",
      "screen_name" : "joinsessions",
      "indices" : [ 3, 16 ],
      "id_str" : "360907906",
      "id" : 360907906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 88 ],
      "url" : "https:\/\/t.co\/PKSw1EW5",
      "expanded_url" : "https:\/\/www.joinsessions.com\/",
      "display_url" : "joinsessions.com"
    } ]
  },
  "geo" : { },
  "id_str" : "189477543387213824",
  "text" : "RT @joinsessions: Our new website is up and running! Check it out: https:\/\/t.co\/PKSw1EW5",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 70 ],
        "url" : "https:\/\/t.co\/PKSw1EW5",
        "expanded_url" : "https:\/\/www.joinsessions.com\/",
        "display_url" : "joinsessions.com"
      } ]
    },
    "geo" : { },
    "id_str" : "189409071311491072",
    "text" : "Our new website is up and running! Check it out: https:\/\/t.co\/PKSw1EW5",
    "id" : 189409071311491072,
    "created_at" : "2012-04-09 17:46:56 +0000",
    "user" : {
      "name" : "Sessions",
      "screen_name" : "joinsessions",
      "protected" : false,
      "id_str" : "360907906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000569225412\/dbd0e03c64156367fe37ee996bb4da6b_normal.png",
      "id" : 360907906,
      "verified" : false
    }
  },
  "id" : 189477543387213824,
  "created_at" : "2012-04-09 22:19:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Sefferman",
      "screen_name" : "iseff",
      "indices" : [ 0, 6 ],
      "id_str" : "5500",
      "id" : 5500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189462465644478464",
  "geo" : { },
  "id_str" : "189477068772347906",
  "in_reply_to_user_id" : 5500,
  "text" : "@iseff Thanks! I didn't even know I was a finalist. Sweet!",
  "id" : 189477068772347906,
  "in_reply_to_status_id" : 189462465644478464,
  "created_at" : "2012-04-09 22:17:08 +0000",
  "in_reply_to_screen_name" : "iseff",
  "in_reply_to_user_id_str" : "5500",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 0, 11 ],
      "id_str" : "784078",
      "id" : 784078
    }, {
      "name" : "Aubrey Sabala",
      "screen_name" : "Aubs",
      "indices" : [ 113, 118 ],
      "id_str" : "2781",
      "id" : 2781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189420665525387264",
  "geo" : { },
  "id_str" : "189421340065923072",
  "in_reply_to_user_id" : 784078,
  "text" : "@alicetiara I'm taking the bus TO the Amtrak! Some $57 tickets available... are you in town? Getting dinner with @Aubs if you wanna join!",
  "id" : 189421340065923072,
  "in_reply_to_status_id" : 189420665525387264,
  "created_at" : "2012-04-09 18:35:41 +0000",
  "in_reply_to_screen_name" : "alicetiara",
  "in_reply_to_user_id_str" : "784078",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aubrey Sabala",
      "screen_name" : "Aubs",
      "indices" : [ 0, 5 ],
      "id_str" : "2781",
      "id" : 2781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189418178839973888",
  "geo" : { },
  "id_str" : "189418306665586688",
  "in_reply_to_user_id" : 2781,
  "text" : "@Aubs Yeah!",
  "id" : 189418306665586688,
  "in_reply_to_status_id" : 189418178839973888,
  "created_at" : "2012-04-09 18:23:38 +0000",
  "in_reply_to_screen_name" : "Aubs",
  "in_reply_to_user_id_str" : "2781",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aubrey Sabala",
      "screen_name" : "Aubs",
      "indices" : [ 0, 5 ],
      "id_str" : "2781",
      "id" : 2781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189417175415660545",
  "geo" : { },
  "id_str" : "189417430878126080",
  "in_reply_to_user_id" : 2781,
  "text" : "@Aubs Arriving around 5 or so, staying with Rick probably. Whatcha doing tonight?",
  "id" : 189417430878126080,
  "in_reply_to_status_id" : 189417175415660545,
  "created_at" : "2012-04-09 18:20:09 +0000",
  "in_reply_to_screen_name" : "Aubs",
  "in_reply_to_user_id_str" : "2781",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/ssJs4W66",
      "expanded_url" : "http:\/\/instagr.am\/p\/JNV9Bfo0AD\/",
      "display_url" : "instagr.am\/p\/JNV9Bfo0AD\/"
    } ]
  },
  "geo" : { },
  "id_str" : "189415477750149120",
  "text" : "Do buses actually run in Wilmington, Delaware? Headed to NYC for a day, hopefully.  http:\/\/t.co\/ssJs4W66",
  "id" : 189415477750149120,
  "created_at" : "2012-04-09 18:12:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "facebookbuysinstagram",
      "indices" : [ 0, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/jRxooRR8",
      "expanded_url" : "http:\/\/instagr.am\/p\/JNQaHtI0Nw\/",
      "display_url" : "instagr.am\/p\/JNQaHtI0Nw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "189403358862389248",
  "text" : "#facebookbuysinstagram http:\/\/t.co\/jRxooRR8",
  "id" : 189403358862389248,
  "created_at" : "2012-04-09 17:24:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/iXRKxv8s",
      "expanded_url" : "http:\/\/blog.instagram.com\/post\/20785013897\/instagram-facebook",
      "display_url" : "blog.instagram.com\/post\/207850138\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "189401755770028032",
  "text" : "Facebook buys Instagram for a beeeellion dollars? Cue some disappointed tweeters. http:\/\/t.co\/iXRKxv8s",
  "id" : 189401755770028032,
  "created_at" : "2012-04-09 17:17:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 50, 61 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/e0HBOnQB",
      "expanded_url" : "http:\/\/4sq.com\/Hsk1IE",
      "display_url" : "4sq.com\/Hsk1IE"
    } ]
  },
  "geo" : { },
  "id_str" : "189396580762255361",
  "text" : "I just unlocked the Level 6 \"Fresh Brew\" badge on @foursquare! Huzzah! http:\/\/t.co\/e0HBOnQB",
  "id" : 189396580762255361,
  "created_at" : "2012-04-09 16:57:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexia Tsotsis",
      "screen_name" : "alexia",
      "indices" : [ 9, 16 ],
      "id_str" : "18327902",
      "id" : 18327902
    }, {
      "name" : "Alexia Tsotsis",
      "screen_name" : "alexia",
      "indices" : [ 33, 40 ],
      "id_str" : "18327902",
      "id" : 18327902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/I62PNXSF",
      "expanded_url" : "http:\/\/bit.ly\/IgvEP4",
      "display_url" : "bit.ly\/IgvEP4"
    } ]
  },
  "geo" : { },
  "id_str" : "189371069285666816",
  "text" : "I'm team @alexia on this one. RT @alexia: Silicon Valley Needs To Take Itself More Seriously* http:\/\/t.co\/I62PNXSF",
  "id" : 189371069285666816,
  "created_at" : "2012-04-09 15:15:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaskRabbit",
      "screen_name" : "TaskRabbit",
      "indices" : [ 0, 11 ],
      "id_str" : "21883399",
      "id" : 21883399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189355226925510656",
  "geo" : { },
  "id_str" : "189355416239620098",
  "in_reply_to_user_id" : 21883399,
  "text" : "@TaskRabbit Thanks, I will try that.",
  "id" : 189355416239620098,
  "in_reply_to_status_id" : 189355226925510656,
  "created_at" : "2012-04-09 14:13:43 +0000",
  "in_reply_to_screen_name" : "TaskRabbit",
  "in_reply_to_user_id_str" : "21883399",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Gelman",
      "screen_name" : "JasonGelman",
      "indices" : [ 0, 12 ],
      "id_str" : "220137029",
      "id" : 220137029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189354823638974465",
  "geo" : { },
  "id_str" : "189355109535326210",
  "in_reply_to_user_id" : 220137029,
  "text" : "@jasongelman Thanks for the offer! Someone else already offered... I'll follow up if that dpesn't work out.",
  "id" : 189355109535326210,
  "in_reply_to_status_id" : 189354823638974465,
  "created_at" : "2012-04-09 14:12:30 +0000",
  "in_reply_to_screen_name" : "JasonGelman",
  "in_reply_to_user_id_str" : "220137029",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaskRabbit",
      "screen_name" : "TaskRabbit",
      "indices" : [ 0, 11 ],
      "id_str" : "21883399",
      "id" : 21883399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189353887285784576",
  "geo" : { },
  "id_str" : "189354348072022020",
  "in_reply_to_user_id" : 21883399,
  "text" : "@TaskRabbit I had trouble figuring out which task type to use. Is it shopping? And I couldn't find Niketown on the map step.",
  "id" : 189354348072022020,
  "in_reply_to_status_id" : 189353887285784576,
  "created_at" : "2012-04-09 14:09:29 +0000",
  "in_reply_to_screen_name" : "TaskRabbit",
  "in_reply_to_user_id_str" : "21883399",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaskRabbit",
      "screen_name" : "TaskRabbit",
      "indices" : [ 14, 25 ],
      "id_str" : "21883399",
      "id" : 21883399
    }, {
      "name" : "Zaarly",
      "screen_name" : "zaarly",
      "indices" : [ 29, 36 ],
      "id_str" : "254690342",
      "id" : 254690342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189352516075532288",
  "text" : "Trying to get @taskrabbit or @zaarly to buy me a Nike FuelBand at Niketown in NYC and mail it to me. Anyone know how to do this?",
  "id" : 189352516075532288,
  "created_at" : "2012-04-09 14:02:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/pQt5nYuO",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayJMLNzh",
      "display_url" : "tmblr.co\/ZQJvayJMLNzh"
    } ]
  },
  "geo" : { },
  "id_str" : "189336930406764545",
  "text" : "HOW DO WE CHANGE OURSELVES? http:\/\/t.co\/pQt5nYuO",
  "id" : 189336930406764545,
  "created_at" : "2012-04-09 13:00:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "189196975915286528",
  "geo" : { },
  "id_str" : "189207241461743616",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling He sounds like the anti-Buster to me.",
  "id" : 189207241461743616,
  "in_reply_to_status_id" : 189196975915286528,
  "created_at" : "2012-04-09 04:24:56 +0000",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/gbgWfpM9",
      "expanded_url" : "http:\/\/flic.kr\/p\/bwRfWS",
      "display_url" : "flic.kr\/p\/bwRfWS"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.696333, -75.545167 ]
  },
  "id_str" : "189151326524030976",
  "text" : "8:36pm Headed back to Wilmington after visiting the Jersey Shore http:\/\/t.co\/gbgWfpM9",
  "id" : 189151326524030976,
  "created_at" : "2012-04-09 00:42:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/UvSQX12M",
      "expanded_url" : "http:\/\/instagr.am\/p\/JK3LulI0KI\/",
      "display_url" : "instagr.am\/p\/JK3LulI0KI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "189066215694663680",
  "text" : "First skeptical sand castle http:\/\/t.co\/UvSQX12M",
  "id" : 189066215694663680,
  "created_at" : "2012-04-08 19:04:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/Xu9ccOuZ",
      "expanded_url" : "http:\/\/instagr.am\/p\/JK17kNI0Jd\/",
      "display_url" : "instagr.am\/p\/JK17kNI0Jd\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.9913905998, -74.7969421412 ]
  },
  "id_str" : "189063497794076672",
  "text" : "\"bee!\"  @ North Wildwood 19th St Beach http:\/\/t.co\/Xu9ccOuZ",
  "id" : 189063497794076672,
  "created_at" : "2012-04-08 18:53:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/KfLFK93p",
      "expanded_url" : "http:\/\/nyti.ms\/HXozWZ",
      "display_url" : "nyti.ms\/HXozWZ"
    } ]
  },
  "geo" : { },
  "id_str" : "189025487262195712",
  "text" : "RT @the99percent: How Angry Birds, Tetris, and other Hyperaddictive 'Stupid Games' control our attention - http:\/\/t.co\/KfLFK93p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/KfLFK93p",
        "expanded_url" : "http:\/\/nyti.ms\/HXozWZ",
        "display_url" : "nyti.ms\/HXozWZ"
      } ]
    },
    "geo" : { },
    "id_str" : "189025058709180417",
    "text" : "How Angry Birds, Tetris, and other Hyperaddictive 'Stupid Games' control our attention - http:\/\/t.co\/KfLFK93p",
    "id" : 189025058709180417,
    "created_at" : "2012-04-08 16:21:00 +0000",
    "user" : {
      "name" : "99U",
      "screen_name" : "99u",
      "protected" : false,
      "id_str" : "17636894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2995676123\/fa7645dcc7f6d69b442bbcbd0950a0ef_normal.png",
      "id" : 17636894,
      "verified" : true
    }
  },
  "id" : 189025487262195712,
  "created_at" : "2012-04-08 16:22:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188799496795332609",
  "text" : "What's worth most to you: a twitter fave, a facebook like, a tumblr like, or an instagram like?",
  "id" : 188799496795332609,
  "created_at" : "2012-04-08 01:24:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/MbrH586b",
      "expanded_url" : "http:\/\/flic.kr\/p\/bwx38f",
      "display_url" : "flic.kr\/p\/bwx38f"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.762333, -75.5085 ]
  },
  "id_str" : "188789737367154688",
  "text" : "8:36pm Keeping Niko up late with his family http:\/\/t.co\/MbrH586b",
  "id" : 188789737367154688,
  "created_at" : "2012-04-08 00:45:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188695024832225281",
  "geo" : { },
  "id_str" : "188695500856373248",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie Ooh can't wait! I do love the fitbit but it's the API that's really great about both.",
  "id" : 188695500856373248,
  "in_reply_to_status_id" : 188695024832225281,
  "created_at" : "2012-04-07 18:31:27 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188679591794188288",
  "geo" : { },
  "id_str" : "188694007906439168",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie So that's why my NYC friends seem to have all the luck with them. I'll start recruiting over there.",
  "id" : 188694007906439168,
  "in_reply_to_status_id" : 188679591794188288,
  "created_at" : "2012-04-07 18:25:31 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188677938382766080",
  "text" : "Does anyone have a Nike FuelBand or live in a city selling them, that would send one to me? I'll pay extra!",
  "id" : 188677938382766080,
  "created_at" : "2012-04-07 17:21:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "indices" : [ 0, 4 ],
      "id_str" : "11822502",
      "id" : 11822502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188481152607195136",
  "geo" : { },
  "id_str" : "188595124966662144",
  "in_reply_to_user_id" : 11822502,
  "text" : "@mko Shoot I was trying to look into that yesterday but must not have fixed it. It's still sending?",
  "id" : 188595124966662144,
  "in_reply_to_status_id" : 188481152607195136,
  "created_at" : "2012-04-07 11:52:36 +0000",
  "in_reply_to_screen_name" : "mko",
  "in_reply_to_user_id_str" : "11822502",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/rKmEu3r3",
      "expanded_url" : "http:\/\/amzn.com\/k\/2MHW66U2K2K0L",
      "display_url" : "amzn.com\/k\/2MHW66U2K2K0L"
    } ]
  },
  "geo" : { },
  "id_str" : "188476825419268096",
  "text" : "\"You can do what you decide to do but you cannot decide what you will decide to do.\" http:\/\/t.co\/rKmEu3r3 #Kindle",
  "id" : 188476825419268096,
  "created_at" : "2012-04-07 04:02:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/S2X5FuKm",
      "expanded_url" : "http:\/\/flic.kr\/p\/bKbHmX",
      "display_url" : "flic.kr\/p\/bKbHmX"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.761833, -75.508167 ]
  },
  "id_str" : "188437239112540160",
  "text" : "8:36pm Watching YouTube videos of the train we took today http:\/\/t.co\/S2X5FuKm",
  "id" : 188437239112540160,
  "created_at" : "2012-04-07 01:25:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/Wx8ccKoS",
      "expanded_url" : "http:\/\/instagr.am\/p\/JFaqoOo0PL\/",
      "display_url" : "instagr.am\/p\/JFaqoOo0PL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "188299938877288448",
  "text" : "So ready to ride the choo with GG Pavina! http:\/\/t.co\/Wx8ccKoS",
  "id" : 188299938877288448,
  "created_at" : "2012-04-06 16:19:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/EVoPt2Md",
      "expanded_url" : "http:\/\/instagr.am\/p\/JFaaXhI0PF\/",
      "display_url" : "instagr.am\/p\/JFaaXhI0PF\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7388610569, -75.6322906931 ]
  },
  "id_str" : "188299431836258306",
  "text" : "Steam engine!  @ Wilmington Western Railroad http:\/\/t.co\/EVoPt2Md",
  "id" : 188299431836258306,
  "created_at" : "2012-04-06 16:17:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/CYwHL6Cl",
      "expanded_url" : "http:\/\/instagr.am\/p\/JFVcMCI0Nc\/",
      "display_url" : "instagr.am\/p\/JFVcMCI0Nc\/"
    } ]
  },
  "geo" : { },
  "id_str" : "188288340255195137",
  "text" : "1-bit Niko (this app is sorta awesome) http:\/\/t.co\/CYwHL6Cl",
  "id" : 188288340255195137,
  "created_at" : "2012-04-06 15:33:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/aWnI6UYb",
      "expanded_url" : "http:\/\/instagr.am\/p\/JFRh4TI0Lu\/",
      "display_url" : "instagr.am\/p\/JFRh4TI0Lu\/"
    } ]
  },
  "geo" : { },
  "id_str" : "188279657370632193",
  "text" : "1-bit family http:\/\/t.co\/aWnI6UYb",
  "id" : 188279657370632193,
  "created_at" : "2012-04-06 14:59:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/calOcS7m",
      "expanded_url" : "http:\/\/flic.kr\/p\/bJVoQz",
      "display_url" : "flic.kr\/p\/bJVoQz"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6405, -84.429334 ]
  },
  "id_str" : "188063542468018177",
  "text" : "8:36pm Atlanta airport: where they point up and say \"everything happens for a reason\" to explain why their delays cau http:\/\/t.co\/calOcS7m",
  "id" : 188063542468018177,
  "created_at" : "2012-04-06 00:40:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "188060446119571456",
  "geo" : { },
  "id_str" : "188063498163601408",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley That would be taking too much credit. They're attached.",
  "id" : 188063498163601408,
  "in_reply_to_status_id" : 188060446119571456,
  "created_at" : "2012-04-06 00:40:06 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/aGARmoLd",
      "expanded_url" : "http:\/\/instagr.am\/p\/JDtjqqo0Aq\/",
      "display_url" : "instagr.am\/p\/JDtjqqo0Aq\/"
    } ]
  },
  "geo" : { },
  "id_str" : "188059798221225986",
  "text" : "We missed our connection in ATL but Niko is stoked about getting to ride more trains http:\/\/t.co\/aGARmoLd",
  "id" : 188059798221225986,
  "created_at" : "2012-04-06 00:25:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187951703100882944",
  "geo" : { },
  "id_str" : "187952091233386498",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Cool! I love a revamp.",
  "id" : 187952091233386498,
  "in_reply_to_status_id" : 187951703100882944,
  "created_at" : "2012-04-05 17:17:25 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "indices" : [ 3, 6 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/0fTcV5IR",
      "expanded_url" : "http:\/\/blog.findings.com\/post\/20527246081\/how-we-will-read-clay-shirky",
      "display_url" : "blog.findings.com\/post\/205272460\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "187951721509687297",
  "text" : "RT @ev: Clay Shirky: \u201CBut now it is an act of significant discipline to say, 'I\u2019m going to stare out the window.'\u201D http:\/\/t.co\/0fTcV5IR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/0fTcV5IR",
        "expanded_url" : "http:\/\/blog.findings.com\/post\/20527246081\/how-we-will-read-clay-shirky",
        "display_url" : "blog.findings.com\/post\/205272460\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "187945662208417792",
    "text" : "Clay Shirky: \u201CBut now it is an act of significant discipline to say, 'I\u2019m going to stare out the window.'\u201D http:\/\/t.co\/0fTcV5IR",
    "id" : 187945662208417792,
    "created_at" : "2012-04-05 16:51:52 +0000",
    "user" : {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "protected" : false,
      "id_str" : "20",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000541049107\/3b6dcbd9c0182688457f372b40483e50_normal.jpeg",
      "id" : 20,
      "verified" : true
    }
  },
  "id" : 187951721509687297,
  "created_at" : "2012-04-05 17:15:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187943744799117312",
  "geo" : { },
  "id_str" : "187949769166032897",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez That's awesome! Are you gonna blog it on QS or somewhere else?",
  "id" : 187949769166032897,
  "in_reply_to_status_id" : 187943744799117312,
  "created_at" : "2012-04-05 17:08:11 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/KUItSCuw",
      "expanded_url" : "http:\/\/4sq.com\/HpcEQ1",
      "display_url" : "4sq.com\/HpcEQ1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.3025941849 ]
  },
  "id_str" : "187919455987302401",
  "text" : "Rescheduled flight, went home and back, lost some money and time but all is well again. http:\/\/t.co\/KUItSCuw",
  "id" : 187919455987302401,
  "created_at" : "2012-04-05 15:07:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrej Gregov",
      "screen_name" : "agregov",
      "indices" : [ 94, 102 ],
      "id_str" : "752413",
      "id" : 752413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/nXtGPCXJ",
      "expanded_url" : "http:\/\/bit.ly\/HXYi7C",
      "display_url" : "bit.ly\/HXYi7C"
    } ]
  },
  "geo" : { },
  "id_str" : "187918357130002433",
  "text" : "Keep trying and trying and trying to do what you really want to do. http:\/\/t.co\/nXtGPCXJ \/via @agregov",
  "id" : 187918357130002433,
  "created_at" : "2012-04-05 15:03:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryce Roberts",
      "screen_name" : "bryce",
      "indices" : [ 60, 66 ],
      "id_str" : "6160742",
      "id" : 6160742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/28GCBXMF",
      "expanded_url" : "http:\/\/bit.ly\/I0OzRn",
      "display_url" : "bit.ly\/I0OzRn"
    } ]
  },
  "geo" : { },
  "id_str" : "187916478958411776",
  "text" : "\"The year things get weird.\" I think that's about right. RT @bryce: Web 2.0 Ends With Data Monopolies http:\/\/t.co\/28GCBXMF",
  "id" : 187916478958411776,
  "created_at" : "2012-04-05 14:55:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187907116999262208",
  "geo" : { },
  "id_str" : "187910450330083329",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara I'm surprised my brain continues to function at all (debatable). Must be all the sleep I'm getting.",
  "id" : 187910450330083329,
  "in_reply_to_status_id" : 187907116999262208,
  "created_at" : "2012-04-05 14:31:57 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187910045646864385",
  "text" : "I think babies + startup life has trained me well to just roll with setbacks and have fun on the roller coaster. Wee!",
  "id" : 187910045646864385,
  "created_at" : "2012-04-05 14:30:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187906427162083330",
  "text" : "In better news, Niko learned how to use a drinking fountain and cracked me up.",
  "id" : 187906427162083330,
  "created_at" : "2012-04-05 14:15:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187904863861096448",
  "text" : "This morning has been a comedy of errors. Left bag at home, flight was actually for yesterday, keys are locked in house.",
  "id" : 187904863861096448,
  "created_at" : "2012-04-05 14:09:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Tew",
      "screen_name" : "tewy",
      "indices" : [ 3, 8 ],
      "id_str" : "14370584",
      "id" : 14370584
    }, {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "indices" : [ 88, 99 ],
      "id_str" : "10876852",
      "id" : 10876852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/OVwy25nG",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=t3TAOYXT840",
      "display_url" : "youtube.com\/watch?v=t3TAOY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "187786473171451904",
  "text" : "RT @tewy: lol: what google glasses will really be like to use http:\/\/t.co\/OVwy25nG (via @TheNextWeb)",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Next Web",
        "screen_name" : "TheNextWeb",
        "indices" : [ 78, 89 ],
        "id_str" : "10876852",
        "id" : 10876852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/OVwy25nG",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=t3TAOYXT840",
        "display_url" : "youtube.com\/watch?v=t3TAOY\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "187785923256258560",
    "text" : "lol: what google glasses will really be like to use http:\/\/t.co\/OVwy25nG (via @TheNextWeb)",
    "id" : 187785923256258560,
    "created_at" : "2012-04-05 06:17:07 +0000",
    "user" : {
      "name" : "Alex Tew",
      "screen_name" : "tewy",
      "protected" : false,
      "id_str" : "14370584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3667765732\/d2940d54294a15f012faa0ad4502415a_normal.jpeg",
      "id" : 14370584,
      "verified" : false
    }
  },
  "id" : 187786473171451904,
  "created_at" : "2012-04-05 06:19:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/jzkgeYcl",
      "expanded_url" : "http:\/\/instagr.am\/p\/JBjYBjI0MC\/",
      "display_url" : "instagr.am\/p\/JBjYBjI0MC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "187756033635123200",
  "text" : "Bare branches at night II http:\/\/t.co\/jzkgeYcl",
  "id" : 187756033635123200,
  "created_at" : "2012-04-05 04:18:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/s44uGrLf",
      "expanded_url" : "http:\/\/instagr.am\/p\/JBi0qqo0L8\/",
      "display_url" : "instagr.am\/p\/JBi0qqo0L8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "187754804632760321",
  "text" : "Bare branches at night http:\/\/t.co\/s44uGrLf",
  "id" : 187754804632760321,
  "created_at" : "2012-04-05 04:13:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/wQiCqdmM",
      "expanded_url" : "http:\/\/instagr.am\/p\/JBidDBI0L0\/",
      "display_url" : "instagr.am\/p\/JBidDBI0L0\/"
    } ]
  },
  "geo" : { },
  "id_str" : "187754041634340865",
  "text" : "Cherry blossoms at night http:\/\/t.co\/wQiCqdmM",
  "id" : 187754041634340865,
  "created_at" : "2012-04-05 04:10:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 55, 63 ],
      "id_str" : "958581",
      "id" : 958581
    }, {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 68, 78 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/6zgkbNAU",
      "expanded_url" : "http:\/\/flic.kr\/p\/bvNqsS",
      "display_url" : "flic.kr\/p\/bvNqsS"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612, -122.317167 ]
  },
  "id_str" : "187752879719841793",
  "text" : "8:36pm Just heading home after good conversations with @rdicker and @galenward http:\/\/t.co\/6zgkbNAU",
  "id" : 187752879719841793,
  "created_at" : "2012-04-05 04:05:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187708040353546240",
  "text" : "Who crunched time?",
  "id" : 187708040353546240,
  "created_at" : "2012-04-05 01:07:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Budge",
      "screen_name" : "budge",
      "indices" : [ 24, 30 ],
      "id_str" : "286384512",
      "id" : 286384512
    }, {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 66, 82 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/QybVKY3a",
      "expanded_url" : "http:\/\/bud.ge\/tour",
      "display_url" : "bud.ge\/tour"
    } ]
  },
  "geo" : { },
  "id_str" : "187649278691385345",
  "text" : "Want to know more about @budge? Check out this cool new tour page @ameliagreenhall put together: http:\/\/t.co\/QybVKY3a",
  "id" : 187649278691385345,
  "created_at" : "2012-04-04 21:14:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/MzBRmj8R",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayJ4XwVW",
      "display_url" : "tmblr.co\/ZQJvayJ4XwVW"
    } ]
  },
  "geo" : { },
  "id_str" : "187612880273801218",
  "text" : "The new crazy Google Glasses demo video: http:\/\/t.co\/MzBRmj8R",
  "id" : 187612880273801218,
  "created_at" : "2012-04-04 18:49:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "indices" : [ 0, 4 ],
      "id_str" : "11822502",
      "id" : 11822502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187595629642522624",
  "geo" : { },
  "id_str" : "187602040350965760",
  "in_reply_to_user_id" : 11822502,
  "text" : "@mko Isn't that just an extension of a current obligation you feel to be considerate of other people, rather than something new?",
  "id" : 187602040350965760,
  "in_reply_to_status_id" : 187595629642522624,
  "created_at" : "2012-04-04 18:06:26 +0000",
  "in_reply_to_screen_name" : "mko",
  "in_reply_to_user_id_str" : "11822502",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    }, {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "indices" : [ 5, 9 ],
      "id_str" : "11822502",
      "id" : 11822502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187591992379834370",
  "geo" : { },
  "id_str" : "187592648809394177",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap @mko I don't see how it would create social obligation. It's just another piece of feedback.",
  "id" : 187592648809394177,
  "in_reply_to_status_id" : 187591992379834370,
  "created_at" : "2012-04-04 17:29:07 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "indices" : [ 0, 4 ],
      "id_str" : "11822502",
      "id" : 11822502
    }, {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 5, 9 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187590395377631232",
  "geo" : { },
  "id_str" : "187591686065623040",
  "in_reply_to_user_id" : 11822502,
  "text" : "@mko @cap It would definitely disrupt existing social dynamics. However, is it possible that it might help build better ones?",
  "id" : 187591686065623040,
  "in_reply_to_status_id" : 187590395377631232,
  "created_at" : "2012-04-04 17:25:17 +0000",
  "in_reply_to_screen_name" : "mko",
  "in_reply_to_user_id_str" : "11822502",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187590465422495747",
  "geo" : { },
  "id_str" : "187591310306320384",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc You can guess, but it's subjective. I think having an objective measure would change how we thought about it.",
  "id" : 187591310306320384,
  "in_reply_to_status_id" : 187590465422495747,
  "created_at" : "2012-04-04 17:23:48 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "indices" : [ 0, 4 ],
      "id_str" : "11822502",
      "id" : 11822502
    }, {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 5, 9 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187586584453988352",
  "geo" : { },
  "id_str" : "187589578008440833",
  "in_reply_to_user_id" : 11822502,
  "text" : "@mko @cap I agree that it would be a short-term disaster but that as the novelty wore off it would create new interesting advantages.",
  "id" : 187589578008440833,
  "in_reply_to_status_id" : 187586584453988352,
  "created_at" : "2012-04-04 17:16:55 +0000",
  "in_reply_to_screen_name" : "mko",
  "in_reply_to_user_id_str" : "11822502",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adam tratt",
      "screen_name" : "adamtr",
      "indices" : [ 0, 7 ],
      "id_str" : "9981012",
      "id" : 9981012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187587329244921856",
  "geo" : { },
  "id_str" : "187588732831010816",
  "in_reply_to_user_id" : 9981012,
  "text" : "@adamtr Yeah, wishful thinking I guess. Have you used any heart rate watches + chest straps that would work well over a whole day?",
  "id" : 187588732831010816,
  "in_reply_to_status_id" : 187587329244921856,
  "created_at" : "2012-04-04 17:13:33 +0000",
  "in_reply_to_screen_name" : "adamtr",
  "in_reply_to_user_id_str" : "9981012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Strick v L",
      "screen_name" : "strickvl",
      "indices" : [ 0, 9 ],
      "id_str" : "14439930",
      "id" : 14439930
    }, {
      "name" : "Azumio Inc.",
      "screen_name" : "azumioinc",
      "indices" : [ 17, 27 ],
      "id_str" : "252827423",
      "id" : 252827423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187583844013182976",
  "geo" : { },
  "id_str" : "187584754961485825",
  "in_reply_to_user_id" : 14439930,
  "text" : "@strickvl I love @azumioinc apps and use them regularly. I want something that run all the time though, and lets me know of big jumps.",
  "id" : 187584754961485825,
  "in_reply_to_status_id" : 187583844013182976,
  "created_at" : "2012-04-04 16:57:45 +0000",
  "in_reply_to_screen_name" : "strickvl",
  "in_reply_to_user_id_str" : "14439930",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 3, 7 ],
      "id_str" : "2182141",
      "id" : 2182141
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 9, 22 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "umad",
      "indices" : [ 44, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187583566983598082",
  "text" : "RT @cap: @busterbenson Oh god the trolling\u2026 #umad",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "umad",
        "indices" : [ 35, 40 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "187583100258238465",
    "geo" : { },
    "id_str" : "187583230197776385",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson Oh god the trolling\u2026 #umad",
    "id" : 187583230197776385,
    "in_reply_to_status_id" : 187583100258238465,
    "created_at" : "2012-04-04 16:51:41 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "protected" : false,
      "id_str" : "2182141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460821892371206144\/DCUWsroT_normal.jpeg",
      "id" : 2182141,
      "verified" : false
    }
  },
  "id" : 187583566983598082,
  "created_at" : "2012-04-04 16:53:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Alex Strick v L",
      "screen_name" : "strickvl",
      "indices" : [ 11, 20 ],
      "id_str" : "14439930",
      "id" : 14439930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187582975284756481",
  "geo" : { },
  "id_str" : "187583498931023872",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez @strickvl Cool! Anything launched yet?",
  "id" : 187583498931023872,
  "in_reply_to_status_id" : 187582975284756481,
  "created_at" : "2012-04-04 16:52:45 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187583100258238465",
  "text" : "How would social interactions change (other than being nerdier) if we could see each others' stress levels in real time?",
  "id" : 187583100258238465,
  "created_at" : "2012-04-04 16:51:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Strick v L",
      "screen_name" : "strickvl",
      "indices" : [ 0, 9 ],
      "id_str" : "14439930",
      "id" : 14439930
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 10, 20 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187581774174490624",
  "geo" : { },
  "id_str" : "187582198856159235",
  "in_reply_to_user_id" : 14439930,
  "text" : "@strickvl @e_ramirez Would wearing a strap all day every day be possible? How long does the battery last?",
  "id" : 187582198856159235,
  "in_reply_to_status_id" : 187581774174490624,
  "created_at" : "2012-04-04 16:47:35 +0000",
  "in_reply_to_screen_name" : "strickvl",
  "in_reply_to_user_id_str" : "14439930",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Pusateri",
      "screen_name" : "Cruftbox",
      "indices" : [ 0, 9 ],
      "id_str" : "792738",
      "id" : 792738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187581311521792001",
  "geo" : { },
  "id_str" : "187581806541938689",
  "in_reply_to_user_id" : 792738,
  "text" : "@Cruftbox Awesome. Any tips on best ones?",
  "id" : 187581806541938689,
  "in_reply_to_status_id" : 187581311521792001,
  "created_at" : "2012-04-04 16:46:02 +0000",
  "in_reply_to_screen_name" : "Cruftbox",
  "in_reply_to_user_id_str" : "792738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187581413590183936",
  "text" : "All I really want to know is when my heart rate significantly changes. Find my stress triggers. Bonus points for not triggering when moving.",
  "id" : 187581413590183936,
  "created_at" : "2012-04-04 16:44:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187580413743599617",
  "geo" : { },
  "id_str" : "187581004419055617",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez I was just looking into Polar. Have you used them at all?",
  "id" : 187581004419055617,
  "in_reply_to_status_id" : 187580413743599617,
  "created_at" : "2012-04-04 16:42:51 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 11, 19 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187579568108998657",
  "geo" : { },
  "id_str" : "187579934682791937",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez @mybasis Yes, but I've been waiting years for them to launch. Anyone else to buy in the meantime?",
  "id" : 187579934682791937,
  "in_reply_to_status_id" : 187579568108998657,
  "created_at" : "2012-04-04 16:38:36 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187579265259274240",
  "text" : "I would wear a watch that, instead of the time, constantly displayed my heart rate. Does one exist yet?",
  "id" : 187579265259274240,
  "created_at" : "2012-04-04 16:35:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/3NRu5p9Q",
      "expanded_url" : "http:\/\/flic.kr\/p\/bvxzjJ",
      "display_url" : "flic.kr\/p\/bvxzjJ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.624666, -122.356834 ]
  },
  "id_str" : "187397490348265475",
  "text" : "8:36pm Trying to blend in http:\/\/t.co\/3NRu5p9Q",
  "id" : 187397490348265475,
  "created_at" : "2012-04-04 04:33:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Oberholtzer",
      "screen_name" : "ilovecharts",
      "indices" : [ 85, 97 ],
      "id_str" : "116498184",
      "id" : 116498184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/bg4drcIL",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayJ24FW-",
      "display_url" : "tmblr.co\/ZQJvayJ24FW-"
    } ]
  },
  "geo" : { },
  "id_str" : "187327543379116032",
  "text" : "The knight can visit each chess board square exactly once: http:\/\/t.co\/bg4drcIL \/via @ilovecharts",
  "id" : 187327543379116032,
  "created_at" : "2012-04-03 23:55:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/SRTJRoY6",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayJ1sH4f",
      "display_url" : "tmblr.co\/ZQJvayJ1sH4f"
    } ]
  },
  "geo" : { },
  "id_str" : "187313090042413056",
  "text" : "On motivation: http:\/\/t.co\/SRTJRoY6",
  "id" : 187313090042413056,
  "created_at" : "2012-04-03 22:58:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    }, {
      "name" : "Budge",
      "screen_name" : "budge",
      "indices" : [ 11, 17 ],
      "id_str" : "286384512",
      "id" : 286384512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187274007488372737",
  "geo" : { },
  "id_str" : "187274180784427008",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs On @budge, yes. Why do you ask?",
  "id" : 187274180784427008,
  "in_reply_to_status_id" : 187274007488372737,
  "created_at" : "2012-04-03 20:23:38 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Netted by the Webbys",
      "screen_name" : "nttd",
      "indices" : [ 99, 104 ],
      "id_str" : "71091930",
      "id" : 71091930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/vLiNLe9F",
      "expanded_url" : "http:\/\/shar.es\/pLyAE",
      "display_url" : "shar.es\/pLyAE"
    } ]
  },
  "geo" : { },
  "id_str" : "187268956678144000",
  "text" : "Headfirst and Goal: http:\/\/t.co\/vLiNLe9F (this is where all the people have been coming from) \/thx @nttd",
  "id" : 187268956678144000,
  "created_at" : "2012-04-03 20:02:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "serendipity",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/3I18CzRD",
      "expanded_url" : "http:\/\/bustr.me\/post\/20418085074\/urban-airships-mobile-messaging-gets-smarter",
      "display_url" : "bustr.me\/post\/204180850\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "187250138446696449",
  "text" : "Urban Airship's context-aware mobile messaging gets smarter: http:\/\/t.co\/3I18CzRD #serendipity",
  "id" : 187250138446696449,
  "created_at" : "2012-04-03 18:48:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Budge",
      "screen_name" : "budge",
      "indices" : [ 26, 32 ],
      "id_str" : "286384512",
      "id" : 286384512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/nBxvIu5p",
      "expanded_url" : "http:\/\/bustr.me\/post\/20414381013\/whoa-2-new-programs-now-free",
      "display_url" : "bustr.me\/post\/204143810\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "187227591189610496",
  "text" : "Announcing 2 spankin' new @budge programs: Stretch Animal and Plank Animal: http:\/\/t.co\/nBxvIu5p (plank is my favorite new exercise)",
  "id" : 187227591189610496,
  "created_at" : "2012-04-03 17:18:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    }, {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 11, 15 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "suck",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187211067741581312",
  "geo" : { },
  "id_str" : "187215127924314113",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward @msg It's surprisingly versatile advice, for many an occasion! #suck",
  "id" : 187215127924314113,
  "in_reply_to_status_id" : 187211067741581312,
  "created_at" : "2012-04-03 16:28:59 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thunt",
      "screen_name" : "thuntnet",
      "indices" : [ 0, 9 ],
      "id_str" : "73289095",
      "id" : 73289095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187203368928817152",
  "geo" : { },
  "id_str" : "187204362211295232",
  "in_reply_to_user_id" : 73289095,
  "text" : "@thuntnet You're very welcome!",
  "id" : 187204362211295232,
  "in_reply_to_status_id" : 187203368928817152,
  "created_at" : "2012-04-03 15:46:12 +0000",
  "in_reply_to_screen_name" : "thuntnet",
  "in_reply_to_user_id_str" : "73289095",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ready",
      "screen_name" : "coriready",
      "indices" : [ 0, 10 ],
      "id_str" : "12426422",
      "id" : 12426422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187203043224338432",
  "geo" : { },
  "id_str" : "187203374897315841",
  "in_reply_to_user_id" : 12426422,
  "text" : "@CoriReady A couple months ago. It just popped in my head one day and I had to build it.",
  "id" : 187203374897315841,
  "in_reply_to_status_id" : 187203043224338432,
  "created_at" : "2012-04-03 15:42:17 +0000",
  "in_reply_to_screen_name" : "coriready",
  "in_reply_to_user_id_str" : "12426422",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "serendipity",
      "indices" : [ 79, 91 ]
    }, {
      "text" : "ai",
      "indices" : [ 92, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/ArQQcQFi",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayJ0aw6d",
      "display_url" : "tmblr.co\/ZQJvayJ0aw6d"
    } ]
  },
  "geo" : { },
  "id_str" : "187203238066532354",
  "text" : "2 different kinds of personal assistants from the future: http:\/\/t.co\/ArQQcQFi #serendipity #ai",
  "id" : 187203238066532354,
  "created_at" : "2012-04-03 15:41:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 88, 92 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/DhJXxNWb",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayJ0Zhqd",
      "display_url" : "tmblr.co\/ZQJvayJ0Zhqd"
    } ]
  },
  "geo" : { },
  "id_str" : "187200839184687105",
  "text" : "\"Put yourself out there and give yourself permission to suck\" http:\/\/t.co\/DhJXxNWb \/via @msg",
  "id" : 187200839184687105,
  "created_at" : "2012-04-03 15:32:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/cVFrj69Y",
      "expanded_url" : "http:\/\/bit.ly\/Hc26kE",
      "display_url" : "bit.ly\/Hc26kE"
    } ]
  },
  "geo" : { },
  "id_str" : "187187741602217984",
  "text" : "A big surge of people are coming to http:\/\/t.co\/cVFrj69Y all of a sudden this morning, but no idea why. Still, cool!",
  "id" : 187187741602217984,
  "created_at" : "2012-04-03 14:40:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/qOoVMcym",
      "expanded_url" : "http:\/\/flic.kr\/p\/bJc4Q6",
      "display_url" : "flic.kr\/p\/bJc4Q6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306167 ]
  },
  "id_str" : "187040020769669120",
  "text" : "8:36pm Watching Mad Men while waiting for late night Chinese take-out http:\/\/t.co\/qOoVMcym",
  "id" : 187040020769669120,
  "created_at" : "2012-04-03 04:53:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New Object",
      "screen_name" : "newobject",
      "indices" : [ 0, 10 ],
      "id_str" : "115230056",
      "id" : 115230056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187014824306290688",
  "geo" : { },
  "id_str" : "187016155683233793",
  "in_reply_to_user_id" : 115230056,
  "text" : "@newobject I don't, but he is pretty dismissive of any possibility of quantum theory helping improve chances for free will.",
  "id" : 187016155683233793,
  "in_reply_to_status_id" : 187014824306290688,
  "created_at" : "2012-04-03 03:18:20 +0000",
  "in_reply_to_screen_name" : "newobject",
  "in_reply_to_user_id_str" : "115230056",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Rogers",
      "screen_name" : "spozbo",
      "indices" : [ 0, 7 ],
      "id_str" : "326617601",
      "id" : 326617601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "187010383557562368",
  "geo" : { },
  "id_str" : "187014140911550468",
  "in_reply_to_user_id" : 326617601,
  "text" : "@spozbo Yeah, number. I couldn't find a mass estimation in my brief google research. Half a gallon by volume, though.",
  "id" : 187014140911550468,
  "in_reply_to_status_id" : 187010383557562368,
  "created_at" : "2012-04-03 03:10:20 +0000",
  "in_reply_to_screen_name" : "spozbo",
  "in_reply_to_user_id_str" : "326617601",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "indices" : [ 3, 12 ],
      "id_str" : "22483",
      "id" : 22483
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 14, 27 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187007517140852736",
  "text" : "RT @pinwheel: @busterbenson anti-bacterial soap has some explaining to do.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "187005972827471872",
    "geo" : { },
    "id_str" : "187007319551393793",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson anti-bacterial soap has some explaining to do.",
    "id" : 187007319551393793,
    "in_reply_to_status_id" : 187005972827471872,
    "created_at" : "2012-04-03 02:43:14 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "protected" : false,
      "id_str" : "22483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461213084380434432\/6vLerhEt_normal.png",
      "id" : 22483,
      "verified" : false
    }
  },
  "id" : 187007517140852736,
  "created_at" : "2012-04-03 02:44:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187005972827471872",
  "text" : "Did you know that 90% of the cells of our body are actually not ours, but bacteria?",
  "id" : 187005972827471872,
  "created_at" : "2012-04-03 02:37:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "SuperBetter",
      "screen_name" : "SuperBetter",
      "indices" : [ 33, 45 ],
      "id_str" : "351204906",
      "id" : 351204906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186992188238987264",
  "geo" : { },
  "id_str" : "186993385289166849",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame Can you add that as a @superbetter power up pls?",
  "id" : 186993385289166849,
  "in_reply_to_status_id" : 186992188238987264,
  "created_at" : "2012-04-03 01:47:51 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/uQqR4CYZ",
      "expanded_url" : "http:\/\/bustr.me\/post\/20382230397\/a-1-hour-talk-by-sam-harris-about-the-illusion-of",
      "display_url" : "bustr.me\/post\/203822303\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186991521738915840",
  "text" : "Sam Harris's great 1-hour talk on the illusion of free will: http:\/\/t.co\/uQqR4CYZ\n\nDoes anyone else see the Agent Smith resemblance here?",
  "id" : 186991521738915840,
  "created_at" : "2012-04-03 01:40:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Arnold",
      "screen_name" : "wka",
      "indices" : [ 0, 4 ],
      "id_str" : "677733",
      "id" : 677733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186974649865879552",
  "geo" : { },
  "id_str" : "186974995115802624",
  "in_reply_to_user_id" : 677733,
  "text" : "@wka That's true, but the same probably holds for companies, right?  If not now, in a billion years it will be more likely.",
  "id" : 186974995115802624,
  "in_reply_to_status_id" : 186974649865879552,
  "created_at" : "2012-04-03 00:34:47 +0000",
  "in_reply_to_screen_name" : "wka",
  "in_reply_to_user_id_str" : "677733",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186974054916440065",
  "text" : "\"The soul that allows you to stay on a diet is just as mysterious as the soul that tempts you to eat a hot fudge sundae.\" - Sam Harris",
  "id" : 186974054916440065,
  "created_at" : "2012-04-03 00:31:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186929554269536257",
  "geo" : { },
  "id_str" : "186942865186885634",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk Only because random mutation is a slowly learning system. Tech can evolve with human and market help in fewer generations, right?",
  "id" : 186942865186885634,
  "in_reply_to_status_id" : 186929554269536257,
  "created_at" : "2012-04-02 22:27:06 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 3, 12 ],
      "id_str" : "2391",
      "id" : 2391
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 14, 27 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 28, 38 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186921699080536064",
  "text" : "RT @mulegirl: @busterbenson @tomcoates While scientific metaphors can go too far, or all wrong, Darwinism is all about success in a cont ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      }, {
        "name" : "Tom Coates",
        "screen_name" : "tomcoates",
        "indices" : [ 14, 24 ],
        "id_str" : "12514",
        "id" : 12514
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "186920528601288704",
    "geo" : { },
    "id_str" : "186920859548651521",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson @tomcoates While scientific metaphors can go too far, or all wrong, Darwinism is all about success in a context, which holds.",
    "id" : 186920859548651521,
    "in_reply_to_status_id" : 186920528601288704,
    "created_at" : "2012-04-02 20:59:40 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "protected" : false,
      "id_str" : "2391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464497053972692992\/4tT8tOM6_normal.png",
      "id" : 2391,
      "verified" : false
    }
  },
  "id" : 186921699080536064,
  "created_at" : "2012-04-02 21:03:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186920849901764608",
  "geo" : { },
  "id_str" : "186921662099374083",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates I'm mostly just trying to say that incremental changes don't limit your upside on awesomeness.",
  "id" : 186921662099374083,
  "in_reply_to_status_id" : 186920849901764608,
  "created_at" : "2012-04-02 21:02:51 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186920058918928386",
  "geo" : { },
  "id_str" : "186920528601288704",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates What evidence is there that big refactors handle local maxima or extinction any better than incremental improvements over time?",
  "id" : 186920528601288704,
  "in_reply_to_status_id" : 186920058918928386,
  "created_at" : "2012-04-02 20:58:21 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186919548744773632",
  "text" : "Anyone that thinks that incremental improvements aren't effective enough and big refactors are needed to survive should talk to Darwin.",
  "id" : 186919548744773632,
  "created_at" : "2012-04-02 20:54:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Collin Ferry",
      "screen_name" : "collinferry",
      "indices" : [ 3, 15 ],
      "id_str" : "15227832",
      "id" : 15227832
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 17, 30 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/iuNBAC86",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=pCofmZlC72g",
      "display_url" : "youtube.com\/watch?v=pCofmZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186899297437102081",
  "text" : "RT @collinferry: @busterbenson I watched Sam Harris lecture on the illusion Free Will. Very persuasive. Thus, do we have free will? http ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/iuNBAC86",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=pCofmZlC72g",
        "display_url" : "youtube.com\/watch?v=pCofmZ\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "186897366647975936",
    "geo" : { },
    "id_str" : "186898975339708416",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson I watched Sam Harris lecture on the illusion Free Will. Very persuasive. Thus, do we have free will? http:\/\/t.co\/iuNBAC86",
    "id" : 186898975339708416,
    "in_reply_to_status_id" : 186897366647975936,
    "created_at" : "2012-04-02 19:32:42 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Collin Ferry",
      "screen_name" : "collinferry",
      "protected" : false,
      "id_str" : "15227832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451240643495329793\/MMXBlNqB_normal.jpeg",
      "id" : 15227832,
      "verified" : false
    }
  },
  "id" : 186899297437102081,
  "created_at" : "2012-04-02 19:33:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186897366647975936",
  "text" : "What's your current biggest unanswered question about life? I gotta think about that a bit.",
  "id" : 186897366647975936,
  "created_at" : "2012-04-02 19:26:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 3, 15 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/fxUKv6Mr",
      "expanded_url" : "http:\/\/j.mp\/HOUPcZ",
      "display_url" : "j.mp\/HOUPcZ"
    } ]
  },
  "geo" : { },
  "id_str" : "186896941110665217",
  "text" : "RT @brainpicker: \"Being a scientist requires having faith in uncertainty, finding pleasure in mystery, and learning to cultivate doubt.\" ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/fxUKv6Mr",
        "expanded_url" : "http:\/\/j.mp\/HOUPcZ",
        "display_url" : "j.mp\/HOUPcZ"
      } ]
    },
    "geo" : { },
    "id_str" : "186895815112007680",
    "text" : "\"Being a scientist requires having faith in uncertainty, finding pleasure in mystery, and learning to cultivate doubt.\" http:\/\/t.co\/fxUKv6Mr",
    "id" : 186895815112007680,
    "created_at" : "2012-04-02 19:20:09 +0000",
    "user" : {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "protected" : false,
      "id_str" : "9207632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/125575833\/twitter_normal.jpg",
      "id" : 9207632,
      "verified" : true
    }
  },
  "id" : 186896941110665217,
  "created_at" : "2012-04-02 19:24:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186870984559706112",
  "geo" : { },
  "id_str" : "186872371951579136",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez Yeah, maybe. There is a difference, and the specific words and labels haven't quite sorted themselves out yet. It's mostly silly.",
  "id" : 186872371951579136,
  "in_reply_to_status_id" : 186870984559706112,
  "created_at" : "2012-04-02 17:47:00 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/op6acHvz",
      "expanded_url" : "http:\/\/bustr.me\/post\/20354548499\/no-upside-learn-to-code",
      "display_url" : "bustr.me\/post\/203545484\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186861884291555331",
  "text" : "What do you need in order to be a \"programmer\"? http:\/\/t.co\/op6acHvz",
  "id" : 186861884291555331,
  "created_at" : "2012-04-02 17:05:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186843517904105473",
  "geo" : { },
  "id_str" : "186844132143140865",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Not yet but it's definitely on my list for travel next week.",
  "id" : 186844132143140865,
  "in_reply_to_status_id" : 186843517904105473,
  "created_at" : "2012-04-02 15:54:47 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/qfUfgdDB",
      "expanded_url" : "http:\/\/flic.kr\/p\/buZq5w",
      "display_url" : "flic.kr\/p\/buZq5w"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "186683230844485632",
  "text" : "8:36pm Watching a cheesy romantic comedy with my hiding wife. Morning Glory, or something? http:\/\/t.co\/qfUfgdDB",
  "id" : 186683230844485632,
  "created_at" : "2012-04-02 05:15:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186657852734177280",
  "text" : "RT @neiltyson: Yup. If pasta & antipasta ever touch, they annihilate. For your safety, that's why restaurants never serve them together.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "186530374157991936",
    "text" : "Yup. If pasta & antipasta ever touch, they annihilate. For your safety, that's why restaurants never serve them together.",
    "id" : 186530374157991936,
    "created_at" : "2012-04-01 19:08:01 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 186657852734177280,
  "created_at" : "2012-04-02 03:34:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shrutarshi Basu",
      "screen_name" : "basus",
      "indices" : [ 0, 6 ],
      "id_str" : "9469312",
      "id" : 9469312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186635881401155584",
  "geo" : { },
  "id_str" : "186636443085578240",
  "in_reply_to_user_id" : 9469312,
  "text" : "@basus Increasing productivity is a subtractive process not an addititive one.",
  "id" : 186636443085578240,
  "in_reply_to_status_id" : 186635881401155584,
  "created_at" : "2012-04-02 02:09:30 +0000",
  "in_reply_to_screen_name" : "basus",
  "in_reply_to_user_id_str" : "9469312",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186633553885409280",
  "text" : "The better the productivity app, the worse it works.",
  "id" : 186633553885409280,
  "created_at" : "2012-04-02 01:58:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Headlines alerter",
      "screen_name" : "NewsCrier",
      "indices" : [ 0, 10 ],
      "id_str" : "142677301",
      "id" : 142677301
    }, {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 36, 49 ],
      "id_str" : "14095370",
      "id" : 14095370
    }, {
      "name" : "Headlines alerter",
      "screen_name" : "NewsCrier",
      "indices" : [ 51, 61 ],
      "id_str" : "142677301",
      "id" : 142677301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186632703842590720",
  "in_reply_to_user_id" : 142677301,
  "text" : "@newscrier Please stop mine too! RT @OffbeatAriel: @newscrier stop mentions",
  "id" : 186632703842590720,
  "created_at" : "2012-04-02 01:54:38 +0000",
  "in_reply_to_screen_name" : "NewsCrier",
  "in_reply_to_user_id_str" : "142677301",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 17, 27 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/heh8qjX0",
      "expanded_url" : "http:\/\/instagr.am\/p\/I5ew3do0D9\/",
      "display_url" : "instagr.am\/p\/I5ew3do0D9\/"
    } ]
  },
  "geo" : { },
  "id_str" : "186620060280963072",
  "text" : "Sunday afternoon @instagram question... http:\/\/t.co\/heh8qjX0",
  "id" : 186620060280963072,
  "created_at" : "2012-04-02 01:04:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visnja Zeljeznjak",
      "screen_name" : "luckyisgood",
      "indices" : [ 3, 15 ],
      "id_str" : "97704318",
      "id" : 97704318
    }, {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 89, 101 ],
      "id_str" : "154236895",
      "id" : 154236895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/kRG1E8VF",
      "expanded_url" : "http:\/\/www.healthmonth.com",
      "display_url" : "healthmonth.com"
    } ]
  },
  "geo" : { },
  "id_str" : "186554680418119680",
  "text" : "RT @luckyisgood: Can't stick to your plan or rules of life, universe and everything? Try @healthmonth - http:\/\/t.co\/kRG1E8VF - it works",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Health Month",
        "screen_name" : "healthmonth",
        "indices" : [ 72, 84 ],
        "id_str" : "154236895",
        "id" : 154236895
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/kRG1E8VF",
        "expanded_url" : "http:\/\/www.healthmonth.com",
        "display_url" : "healthmonth.com"
      } ]
    },
    "geo" : { },
    "id_str" : "186534306498363394",
    "text" : "Can't stick to your plan or rules of life, universe and everything? Try @healthmonth - http:\/\/t.co\/kRG1E8VF - it works",
    "id" : 186534306498363394,
    "created_at" : "2012-04-01 19:23:38 +0000",
    "user" : {
      "name" : "Visnja Zeljeznjak",
      "screen_name" : "luckyisgood",
      "protected" : false,
      "id_str" : "97704318",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/437247176477925376\/JoV0YxER_normal.png",
      "id" : 97704318,
      "verified" : false
    }
  },
  "id" : 186554680418119680,
  "created_at" : "2012-04-01 20:44:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beeminder",
      "screen_name" : "bmndr",
      "indices" : [ 0, 6 ],
      "id_str" : "121250669",
      "id" : 121250669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186529228651626498",
  "geo" : { },
  "id_str" : "186544489618354176",
  "in_reply_to_user_id" : 121250669,
  "text" : "@bmndr Don't worry, you'll be getting an invoice. :)",
  "id" : 186544489618354176,
  "in_reply_to_status_id" : 186529228651626498,
  "created_at" : "2012-04-01 20:04:06 +0000",
  "in_reply_to_screen_name" : "bmndr",
  "in_reply_to_user_id_str" : "121250669",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/hRd5sfOc",
      "expanded_url" : "http:\/\/instagr.am\/p\/I4oL1Po0F8\/",
      "display_url" : "instagr.am\/p\/I4oL1Po0F8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "186499870872449024",
  "text" : "\"bee!\" http:\/\/t.co\/hRd5sfOc",
  "id" : 186499870872449024,
  "created_at" : "2012-04-01 17:06:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186481307977650176",
  "geo" : { },
  "id_str" : "186486667782266880",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall My naturopath might be up for that...",
  "id" : 186486667782266880,
  "in_reply_to_status_id" : 186481307977650176,
  "created_at" : "2012-04-01 16:14:21 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Oliveira",
      "screen_name" : "f",
      "indices" : [ 3, 5 ],
      "id_str" : "5511",
      "id" : 5511
    }, {
      "name" : "Dan Porter",
      "screen_name" : "tfadp",
      "indices" : [ 55, 61 ],
      "id_str" : "5506012",
      "id" : 5506012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Od06jD9N",
      "expanded_url" : "http:\/\/venturebeat.com\/2012\/04\/01\/omgpop-ceo-tweets-that-only-employee-not-to-transition-to-zynga-was-the-weakest-one\/",
      "display_url" : "venturebeat.com\/2012\/04\/01\/omg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186460181071269889",
  "text" : "RT @f: Draw Something may be a success, but their CEO (@tfadp) turning into an arrogant a-hole is sad. No excuse for this: http:\/\/t.co\/O ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dan Porter",
        "screen_name" : "tfadp",
        "indices" : [ 48, 54 ],
        "id_str" : "5506012",
        "id" : 5506012
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/Od06jD9N",
        "expanded_url" : "http:\/\/venturebeat.com\/2012\/04\/01\/omgpop-ceo-tweets-that-only-employee-not-to-transition-to-zynga-was-the-weakest-one\/",
        "display_url" : "venturebeat.com\/2012\/04\/01\/omg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "186448590393192448",
    "text" : "Draw Something may be a success, but their CEO (@tfadp) turning into an arrogant a-hole is sad. No excuse for this: http:\/\/t.co\/Od06jD9N",
    "id" : 186448590393192448,
    "created_at" : "2012-04-01 13:43:02 +0000",
    "user" : {
      "name" : "Fred Oliveira",
      "screen_name" : "f",
      "protected" : false,
      "id_str" : "5511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000177056591\/3dab48e019f42e55a89ba5478aafe244_normal.jpeg",
      "id" : 5511,
      "verified" : false
    }
  },
  "id" : 186460181071269889,
  "created_at" : "2012-04-01 14:29:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/jittergram\/id511639656?mt=8&uo=4\" rel=\"nofollow\"\u003EJittergram on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jittergram",
      "indices" : [ 40, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/tQ5vdsRQ",
      "expanded_url" : "http:\/\/www.jittergramapp.com\/#p\/69F73FB8-3234-4B3D-A239-4289B78B6F42",
      "display_url" : "jittergramapp.com\/#p\/69F73FB8-32\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608678, -122.306096 ]
  },
  "id_str" : "186355919007907840",
  "text" : "Kellianne rediscovers Plants vs Zombies #jittergram http:\/\/t.co\/tQ5vdsRQ",
  "id" : 186355919007907840,
  "created_at" : "2012-04-01 07:34:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 12, 21 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 26, 36 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186352040987996161",
  "text" : "I'm on team @anildash and @tomcoates.",
  "id" : 186352040987996161,
  "created_at" : "2012-04-01 07:19:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]