Grailbird.data.tweets_2012_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/fzNAVcut",
      "expanded_url" : "http:\/\/4sq.com\/KOpeZW",
      "display_url" : "4sq.com\/KOpeZW"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.782092981, -122.400572598 ]
  },
  "id_str" : "208296681324814339",
  "text" : "Hello, Twitter! (@ Twitter, Inc. w\/ 3 others) http:\/\/t.co\/fzNAVcut",
  "id" : 208296681324814339,
  "created_at" : "2012-05-31 20:39:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/XhU1d19O",
      "expanded_url" : "http:\/\/instagr.am\/p\/LTFhkNo0E3\/",
      "display_url" : "instagr.am\/p\/LTFhkNo0E3\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.4832700591, -122.14953661 ]
  },
  "id_str" : "208238037795213312",
  "text" : "Hello, Facebook!  @ Facebook HQ http:\/\/t.co\/XhU1d19O",
  "id" : 208238037795213312,
  "created_at" : "2012-05-31 16:46:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "indices" : [ 3, 17 ],
      "id_str" : "14289835",
      "id" : 14289835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/AgHZkpob",
      "expanded_url" : "http:\/\/happiness-project.com\/happiness_project\/2009\/06\/why-im-not-trying-to-keep-things-simple\/",
      "display_url" : "happiness-project.com\/happiness_proj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "208189171146297345",
  "text" : "RT @gretchenrubin: Why I'm NOT trying to keep things simple: http:\/\/t.co\/AgHZkpob",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http:\/\/t.co\/AgHZkpob",
        "expanded_url" : "http:\/\/happiness-project.com\/happiness_project\/2009\/06\/why-im-not-trying-to-keep-things-simple\/",
        "display_url" : "happiness-project.com\/happiness_proj\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "208147182010896384",
    "text" : "Why I'm NOT trying to keep things simple: http:\/\/t.co\/AgHZkpob",
    "id" : 208147182010896384,
    "created_at" : "2012-05-31 10:45:30 +0000",
    "user" : {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "protected" : false,
      "id_str" : "14289835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1436632135\/Gretchenonphone_normal.JPG",
      "id" : 14289835,
      "verified" : true
    }
  },
  "id" : 208189171146297345,
  "created_at" : "2012-05-31 13:32:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Dean",
      "screen_name" : "sgdean",
      "indices" : [ 11, 18 ],
      "id_str" : "12065472",
      "id" : 12065472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/IYJiE2y2",
      "expanded_url" : "http:\/\/bit.ly\/KuuGCA",
      "display_url" : "bit.ly\/KuuGCA"
    } ]
  },
  "geo" : { },
  "id_str" : "208185377901658112",
  "text" : "Awesome RT @sgdean: How many fruits &amp; vegetables do you eat? Using lasers to measure the amt of carotenoids in the skin http:\/\/t.co\/IYJiE2y2",
  "id" : 208185377901658112,
  "created_at" : "2012-05-31 13:17:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ahier",
      "screen_name" : "ahier",
      "indices" : [ 3, 9 ],
      "id_str" : "18244332",
      "id" : 18244332
    }, {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 87, 98 ],
      "id_str" : "2384071",
      "id" : 2384071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/MiS7v0Ix",
      "expanded_url" : "http:\/\/bit.ly\/KUX3ti",
      "display_url" : "bit.ly\/KUX3ti"
    } ]
  },
  "geo" : { },
  "id_str" : "208078167456489472",
  "text" : "RT @ahier: \"Computing will be more and more in the woodwork\" http:\/\/t.co\/MiS7v0Ix Good @TimOReilly interview",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tim O'Reilly",
        "screen_name" : "timoreilly",
        "indices" : [ 76, 87 ],
        "id_str" : "2384071",
        "id" : 2384071
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/MiS7v0Ix",
        "expanded_url" : "http:\/\/bit.ly\/KUX3ti",
        "display_url" : "bit.ly\/KUX3ti"
      } ]
    },
    "geo" : { },
    "id_str" : "207982483717898242",
    "text" : "\"Computing will be more and more in the woodwork\" http:\/\/t.co\/MiS7v0Ix Good @TimOReilly interview",
    "id" : 207982483717898242,
    "created_at" : "2012-05-30 23:51:02 +0000",
    "user" : {
      "name" : "Brian Ahier",
      "screen_name" : "ahier",
      "protected" : false,
      "id_str" : "18244332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463922018644017152\/i7lWxoiM_normal.jpeg",
      "id" : 18244332,
      "verified" : false
    }
  },
  "id" : 208078167456489472,
  "created_at" : "2012-05-31 06:11:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/pKkQYZHM",
      "expanded_url" : "http:\/\/instagr.am\/p\/LRwuGyo0NF\/",
      "display_url" : "instagr.am\/p\/LRwuGyo0NF\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.753703, -122.431388 ]
  },
  "id_str" : "208052085500022785",
  "text" : "8:36pm Ali, Todd, April, and Cam!  @ Copacaberman http:\/\/t.co\/pKkQYZHM",
  "id" : 208052085500022785,
  "created_at" : "2012-05-31 04:27:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew J. Rosenthal",
      "screen_name" : "andrewrosenthal",
      "indices" : [ 9, 25 ],
      "id_str" : "770178408",
      "id" : 770178408
    }, {
      "name" : "Massive Health",
      "screen_name" : "massivehealth",
      "indices" : [ 31, 45 ],
      "id_str" : "224938017",
      "id" : 224938017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208043602646007808",
  "text" : "Just met @andrewrosenthal from @massivehealth and he\u2019s awesome too! SF is full of good people. Good job, SF.",
  "id" : 208043602646007808,
  "created_at" : "2012-05-31 03:53:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asa",
      "screen_name" : "asa",
      "indices" : [ 0, 4 ],
      "id_str" : "407",
      "id" : 407
    }, {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 5, 15 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208018432216662016",
  "geo" : { },
  "id_str" : "208018710122864640",
  "in_reply_to_user_id" : 407,
  "text" : "@asa @the_april Looks like you took the bait! Muhaha",
  "id" : 208018710122864640,
  "in_reply_to_status_id" : 208018432216662016,
  "created_at" : "2012-05-31 02:14:59 +0000",
  "in_reply_to_screen_name" : "asa",
  "in_reply_to_user_id_str" : "407",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 17, 27 ],
      "id_str" : "16644937",
      "id" : 16644937
    }, {
      "name" : "asa",
      "screen_name" : "asa",
      "indices" : [ 28, 32 ],
      "id_str" : "407",
      "id" : 407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208013303224598528",
  "text" : "@BuschBros185154 @the_april @asa What does 185154 signify? Also, how many bros are there?",
  "id" : 208013303224598528,
  "created_at" : "2012-05-31 01:53:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 72, 82 ],
      "id_str" : "16644937",
      "id" : 16644937
    }, {
      "name" : "asa",
      "screen_name" : "asa",
      "indices" : [ 83, 87 ],
      "id_str" : "407",
      "id" : 407
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teamgweeble",
      "indices" : [ 55, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208011303095246849",
  "text" : "@BuschBros185154 Stop hating on Asa. He\u2019s a swell guy. #teamgweeble \/cc @the_april @asa",
  "id" : 208011303095246849,
  "created_at" : "2012-05-31 01:45:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208010378670649346",
  "geo" : { },
  "id_str" : "208010630807044096",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger Nice new profile pic! :)",
  "id" : 208010630807044096,
  "in_reply_to_status_id" : 208010378670649346,
  "created_at" : "2012-05-31 01:42:53 +0000",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 9, 25 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/eGRNF3bw",
      "expanded_url" : "http:\/\/bit.ly\/MZeMSD",
      "display_url" : "bit.ly\/MZeMSD"
    } ]
  },
  "geo" : { },
  "id_str" : "208008401253445636",
  "text" : "Just met @tonystubblebine. Awesome guy working on something really great. Get on the list: http:\/\/t.co\/eGRNF3bw",
  "id" : 208008401253445636,
  "created_at" : "2012-05-31 01:34:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/QROrsVdw",
      "expanded_url" : "http:\/\/4sq.com\/NgficB",
      "display_url" : "4sq.com\/NgficB"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7853823734, -122.4064002901 ]
  },
  "id_str" : "207970158977892355",
  "text" : "I'm at Obvious Corporation (San Francisco, CA) http:\/\/t.co\/QROrsVdw",
  "id" : 207970158977892355,
  "created_at" : "2012-05-30 23:02:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 19, 30 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/XnNQ1Lw4",
      "expanded_url" : "http:\/\/bit.ly\/L3xbwZ",
      "display_url" : "bit.ly\/L3xbwZ"
    } ]
  },
  "geo" : { },
  "id_str" : "207930971784355841",
  "text" : "Sooper excited! RT @foursquare: Put on your fanciest fancy pants. The all new foursquare is coming soon! Get excited! http:\/\/t.co\/XnNQ1Lw4",
  "id" : 207930971784355841,
  "created_at" : "2012-05-30 20:26:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 16, 29 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    }, {
      "name" : "Sarah Judd Welch",
      "screen_name" : "sjw",
      "indices" : [ 132, 136 ],
      "id_str" : "278220302",
      "id" : 278220302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207900756706201600",
  "text" : "RT @mikeoliver: @busterbenson --&gt; tinydiary.co sms notes into a private timeline. Try it out and let me know what you think! Thx @sjw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      }, {
        "name" : "Sarah Judd Welch",
        "screen_name" : "sjw",
        "indices" : [ 116, 120 ],
        "id_str" : "278220302",
        "id" : 278220302
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "207897435081687041",
    "geo" : { },
    "id_str" : "207899067735482368",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson --&gt; tinydiary.co sms notes into a private timeline. Try it out and let me know what you think! Thx @sjw",
    "id" : 207899067735482368,
    "in_reply_to_status_id" : 207897435081687041,
    "created_at" : "2012-05-30 18:19:34 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "mike oliver",
      "screen_name" : "mkolvr",
      "protected" : false,
      "id_str" : "12866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447238271714594816\/TnZPzQEc_normal.jpeg",
      "id" : 12866,
      "verified" : false
    }
  },
  "id" : 207900756706201600,
  "created_at" : "2012-05-30 18:26:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24D5\u24E3",
      "screen_name" : "folktrash",
      "indices" : [ 0, 10 ],
      "id_str" : "15265271",
      "id" : 15265271
    }, {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 87, 93 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207898082053074945",
  "geo" : { },
  "id_str" : "207898709235744769",
  "in_reply_to_user_id" : 15265271,
  "text" : "@folktrash I asked them for Google Spreadsheet channels but nothing available yet. \/cc @ifttt",
  "id" : 207898709235744769,
  "in_reply_to_status_id" : 207898082053074945,
  "created_at" : "2012-05-30 18:18:09 +0000",
  "in_reply_to_screen_name" : "folktrash",
  "in_reply_to_user_id_str" : "15265271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freedom Spice",
      "screen_name" : "imtboo",
      "indices" : [ 0, 7 ],
      "id_str" : "1037851",
      "id" : 1037851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207898028940591104",
  "geo" : { },
  "id_str" : "207898507032539136",
  "in_reply_to_user_id" : 1037851,
  "text" : "@imtboo Ha. I\u2019ll look into that. Thanks. Ideally there would be a more recent implementation.",
  "id" : 207898507032539136,
  "in_reply_to_status_id" : 207898028940591104,
  "created_at" : "2012-05-30 18:17:21 +0000",
  "in_reply_to_screen_name" : "imtboo",
  "in_reply_to_user_id_str" : "1037851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Judd Welch",
      "screen_name" : "sjw",
      "indices" : [ 0, 4 ],
      "id_str" : "278220302",
      "id" : 278220302
    }, {
      "name" : "mikeoliver",
      "screen_name" : "mikeoliver",
      "indices" : [ 5, 16 ],
      "id_str" : "2207298320",
      "id" : 2207298320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207896428427755520",
  "geo" : { },
  "id_str" : "207897435081687041",
  "in_reply_to_user_id" : 278220302,
  "text" : "@sjw @mikeoliver Spill the beans, Mike!",
  "id" : 207897435081687041,
  "in_reply_to_status_id" : 207896428427755520,
  "created_at" : "2012-05-30 18:13:05 +0000",
  "in_reply_to_screen_name" : "sjw",
  "in_reply_to_user_id_str" : "278220302",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207896880624050177",
  "geo" : { },
  "id_str" : "207897330647707648",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner I want to like this idea but it seems a bit messy. Surely there\u2019s an app that does private posts via SMS specifically?",
  "id" : 207897330647707648,
  "in_reply_to_status_id" : 207896880624050177,
  "created_at" : "2012-05-30 18:12:40 +0000",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24D5\u24E3",
      "screen_name" : "folktrash",
      "indices" : [ 0, 10 ],
      "id_str" : "15265271",
      "id" : 15265271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207896655402504192",
  "geo" : { },
  "id_str" : "207896946185220098",
  "in_reply_to_user_id" : 15265271,
  "text" : "@folktrash Almost, but it\u2019s not time stamped and files will get messy pretty quick.",
  "id" : 207896946185220098,
  "in_reply_to_status_id" : 207896655402504192,
  "created_at" : "2012-05-30 18:11:09 +0000",
  "in_reply_to_screen_name" : "folktrash",
  "in_reply_to_user_id_str" : "15265271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tucker Weinmann",
      "screen_name" : "corsairstw",
      "indices" : [ 0, 11 ],
      "id_str" : "699443",
      "id" : 699443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207896489924632576",
  "geo" : { },
  "id_str" : "207896766090186752",
  "in_reply_to_user_id" : 699443,
  "text" : "@corsairstw Maybe, if I created a separate private account\u2026",
  "id" : 207896766090186752,
  "in_reply_to_status_id" : 207896489924632576,
  "created_at" : "2012-05-30 18:10:26 +0000",
  "in_reply_to_screen_name" : "corsairstw",
  "in_reply_to_user_id_str" : "699443",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207896000591970305",
  "text" : "Does anyone know of a journal app I can update via SMS?",
  "id" : 207896000591970305,
  "created_at" : "2012-05-30 18:07:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 0, 8 ],
      "id_str" : "14097392",
      "id" : 14097392
    }, {
      "name" : "Kimberly",
      "screen_name" : "FertilityFlower",
      "indices" : [ 9, 25 ],
      "id_str" : "140362289",
      "id" : 140362289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207834171140358144",
  "geo" : { },
  "id_str" : "207856359427932160",
  "in_reply_to_user_id" : 140362289,
  "text" : "@nireyal @FertilityFlower Thank you! Well I do visit SF often...",
  "id" : 207856359427932160,
  "in_reply_to_status_id" : 207834171140358144,
  "created_at" : "2012-05-30 15:29:52 +0000",
  "in_reply_to_screen_name" : "FertilityFlower",
  "in_reply_to_user_id_str" : "140362289",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/AcahfQA5",
      "expanded_url" : "http:\/\/flic.kr\/p\/c842DE",
      "display_url" : "flic.kr\/p\/c842DE"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614, -122.322667 ]
  },
  "id_str" : "207688715617845249",
  "text" : "8:36pm Attending a gweeble gwobble party http:\/\/t.co\/AcahfQA5",
  "id" : 207688715617845249,
  "created_at" : "2012-05-30 04:23:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teamgweeble",
      "indices" : [ 44, 56 ]
    }, {
      "text" : "teamgwobble",
      "indices" : [ 60, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207662059385663488",
  "text" : "For my birthday will you do me a favor? Add #teamgweeble or #teamgwobble to your next tweet to settle an eternal debate. Thanks.",
  "id" : 207662059385663488,
  "created_at" : "2012-05-30 02:37:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joerandazzo",
      "screen_name" : "joerandazzo",
      "indices" : [ 0, 12 ],
      "id_str" : "15068489",
      "id" : 15068489
    }, {
      "name" : "St. John's ",
      "screen_name" : "StJohnsSeattle",
      "indices" : [ 54, 69 ],
      "id_str" : "455269485",
      "id" : 455269485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207642118586507266",
  "geo" : { },
  "id_str" : "207643790725488640",
  "in_reply_to_user_id" : 15068489,
  "text" : "@joerandazzo Yes! It would be awesome to see you! \/cc @stjohnsseattle",
  "id" : 207643790725488640,
  "in_reply_to_status_id" : 207642118586507266,
  "created_at" : "2012-05-30 01:25:12 +0000",
  "in_reply_to_screen_name" : "joerandazzo",
  "in_reply_to_user_id_str" : "15068489",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207614603516055553",
  "geo" : { },
  "id_str" : "207628593126326272",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne :( :)",
  "id" : 207628593126326272,
  "in_reply_to_status_id" : 207614603516055553,
  "created_at" : "2012-05-30 00:24:48 +0000",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave McClure",
      "screen_name" : "davemcclure",
      "indices" : [ 50, 62 ],
      "id_str" : "1081",
      "id" : 1081
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 64, 68 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207579184934031360",
  "text" : "I'm on Team McClure on this one (FB &gt; $30). RT @davemcclure: @dhh okay done! i say $40, u say $20. let's check market close on 05\/29\/13",
  "id" : 207579184934031360,
  "created_at" : "2012-05-29 21:08:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "indices" : [ 22, 31 ],
      "id_str" : "255784266",
      "id" : 255784266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/hWKggi1j",
      "expanded_url" : "http:\/\/goo.gl\/fb\/VO2Z6",
      "display_url" : "goo.gl\/fb\/VO2Z6"
    } ]
  },
  "geo" : { },
  "id_str" : "207577756890963969",
  "text" : "More of the story: RT @geekwire: Buster Benson looks to sell Health Month, unveils Hipster Habit App http:\/\/t.co\/hWKggi1j",
  "id" : 207577756890963969,
  "created_at" : "2012-05-29 21:02:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Gluhanich",
      "screen_name" : "LauraGlu",
      "indices" : [ 0, 9 ],
      "id_str" : "9428232",
      "id" : 9428232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207569838648991744",
  "geo" : { },
  "id_str" : "207570060712226816",
  "in_reply_to_user_id" : 9428232,
  "text" : "@LauraGlu Yeah, I'm sad too.",
  "id" : 207570060712226816,
  "in_reply_to_status_id" : 207569838648991744,
  "created_at" : "2012-05-29 20:32:13 +0000",
  "in_reply_to_screen_name" : "LauraGlu",
  "in_reply_to_user_id_str" : "9428232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "twilio",
      "screen_name" : "twilio",
      "indices" : [ 22, 29 ],
      "id_str" : "15936194",
      "id" : 15936194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/Wlw6aJB8",
      "expanded_url" : "http:\/\/instagr.am\/p\/LORvZso0OD\/",
      "display_url" : "instagr.am\/p\/LORvZso0OD\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.62341, -122.336045 ]
  },
  "id_str" : "207561336329207809",
  "text" : "Making use of some of @twilio's undocumented (but useful) APIs today  @ Founders Co-op http:\/\/t.co\/Wlw6aJB8",
  "id" : 207561336329207809,
  "created_at" : "2012-05-29 19:57:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 19, 31 ],
      "id_str" : "154236895",
      "id" : 154236895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 128 ],
      "url" : "https:\/\/t.co\/8ZMtgITQ",
      "expanded_url" : "https:\/\/flippa.com\/2745038-health-month-live-healthier-for-fun",
      "display_url" : "flippa.com\/2745038-health\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "207557013826318338",
  "text" : "I'm auctioning off @healthmonth! Know someone who might like to grow a great health-improvement community? https:\/\/t.co\/8ZMtgITQ (pls RT!)",
  "id" : 207557013826318338,
  "created_at" : "2012-05-29 19:40:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/dSxoWRXz",
      "expanded_url" : "http:\/\/www.geekwire.com\/2012\/silly-side-tech-startup-bringing-microsofts-clippy\/",
      "display_url" : "geekwire.com\/2012\/silly-sid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "207552563531362304",
  "text" : "I'm totally considering putting Clippy on my site. http:\/\/t.co\/dSxoWRXz\n\nI'd probably do it if I could make personalize him a bit.",
  "id" : 207552563531362304,
  "created_at" : "2012-05-29 19:22:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crowdfunder",
      "screen_name" : "crowdfunder",
      "indices" : [ 37, 49 ],
      "id_str" : "449253844",
      "id" : 449253844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/YwqJN6vM",
      "expanded_url" : "http:\/\/crowdfunder.com",
      "display_url" : "crowdfunder.com"
    } ]
  },
  "geo" : { },
  "id_str" : "207529189992173568",
  "text" : "I'm excited to see what happens with @crowdfunder: http:\/\/t.co\/YwqJN6vM",
  "id" : 207529189992173568,
  "created_at" : "2012-05-29 17:49:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Kathleen Peck",
      "screen_name" : "sarahkpeck",
      "indices" : [ 0, 11 ],
      "id_str" : "196745496",
      "id" : 196745496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207486555139477506",
  "geo" : { },
  "id_str" : "207493367288958976",
  "in_reply_to_user_id" : 196745496,
  "text" : "@sarahkpeck Yeah, un-doing is even more difficult. Substitution is better than trying to remove something bc otherwise it'll leave a gap.",
  "id" : 207493367288958976,
  "in_reply_to_status_id" : 207486555139477506,
  "created_at" : "2012-05-29 15:27:28 +0000",
  "in_reply_to_screen_name" : "sarahkpeck",
  "in_reply_to_user_id_str" : "196745496",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanner Christensen",
      "screen_name" : "tannerc",
      "indices" : [ 0, 8 ],
      "id_str" : "9161482",
      "id" : 9161482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207482029871341570",
  "geo" : { },
  "id_str" : "207482620899110915",
  "in_reply_to_user_id" : 9161482,
  "text" : "@tannerc It all depends on what you want. I think habit change is a big part of personal growth and knowing yourself.",
  "id" : 207482620899110915,
  "in_reply_to_status_id" : 207482029871341570,
  "created_at" : "2012-05-29 14:44:46 +0000",
  "in_reply_to_screen_name" : "tannerc",
  "in_reply_to_user_id_str" : "9161482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Kathleen Peck",
      "screen_name" : "sarahkpeck",
      "indices" : [ 58, 69 ],
      "id_str" : "196745496",
      "id" : 196745496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/If9PCJOw",
      "expanded_url" : "http:\/\/bit.ly\/LPzt1k",
      "display_url" : "bit.ly\/LPzt1k"
    } ]
  },
  "geo" : { },
  "id_str" : "207481587334524930",
  "text" : "Good place to start if you want a new habit challenge. RT @sarahkpeck: Come streak with me: a challenge http:\/\/t.co\/If9PCJOw",
  "id" : 207481587334524930,
  "created_at" : "2012-05-29 14:40:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "indices" : [ 3, 14 ],
      "id_str" : "8070502",
      "id" : 8070502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/9r6ehsv1",
      "expanded_url" : "http:\/\/www.danshapiro.com\/blog\/2012\/05\/what-if-you-could-only-speak-once-a-year\/",
      "display_url" : "danshapiro.com\/blog\/2012\/05\/w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "207478045748101123",
  "text" : "RT @danshapiro: What if you could only speak once a year? I've learned the surprising answer: http:\/\/t.co\/9r6ehsv1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/9r6ehsv1",
        "expanded_url" : "http:\/\/www.danshapiro.com\/blog\/2012\/05\/what-if-you-could-only-speak-once-a-year\/",
        "display_url" : "danshapiro.com\/blog\/2012\/05\/w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "207322843715862528",
    "text" : "What if you could only speak once a year? I've learned the surprising answer: http:\/\/t.co\/9r6ehsv1",
    "id" : 207322843715862528,
    "created_at" : "2012-05-29 04:09:52 +0000",
    "user" : {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "protected" : false,
      "id_str" : "8070502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/51828452\/eye_pic_normal.jpg",
      "id" : 8070502,
      "verified" : false
    }
  },
  "id" : 207478045748101123,
  "created_at" : "2012-05-29 14:26:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/6KMm15bj",
      "expanded_url" : "http:\/\/flic.kr\/p\/c7pDyu",
      "display_url" : "flic.kr\/p\/c7pDyu"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "207323767918166017",
  "text" : "8:36pm Puffy hair pre-haircut http:\/\/t.co\/6KMm15bj",
  "id" : 207323767918166017,
  "created_at" : "2012-05-29 04:13:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 44, 55 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/JQgYKyyt",
      "expanded_url" : "http:\/\/4sq.com\/JxsF9t",
      "display_url" : "4sq.com\/JxsF9t"
    } ]
  },
  "geo" : { },
  "id_str" : "207255973574885376",
  "text" : "I just unlocked the \"Trainspotter\" badge on @foursquare for checking in at trains and subway stations! http:\/\/t.co\/JQgYKyyt",
  "id" : 207255973574885376,
  "created_at" : "2012-05-28 23:44:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/m9GMwlcJ",
      "expanded_url" : "http:\/\/instagr.am\/p\/LMBSoCo0GU\/",
      "display_url" : "instagr.am\/p\/LMBSoCo0GU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "207243682401882112",
  "text" : "Bikes, buses, and light rails to birthday dinner in Columbia City http:\/\/t.co\/m9GMwlcJ",
  "id" : 207243682401882112,
  "created_at" : "2012-05-28 22:55:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Anderson",
      "screen_name" : "stephenanderson",
      "indices" : [ 0, 16 ],
      "id_str" : "356663",
      "id" : 356663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207236573048221697",
  "geo" : { },
  "id_str" : "207238194020884480",
  "in_reply_to_user_id" : 356663,
  "text" : "@stephenanderson That's what it usually is for me at least. Then every once in a while it's about wanting to say or know something specific.",
  "id" : 207238194020884480,
  "in_reply_to_status_id" : 207236573048221697,
  "created_at" : "2012-05-28 22:33:30 +0000",
  "in_reply_to_screen_name" : "stephenanderson",
  "in_reply_to_user_id_str" : "356663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Anderson",
      "screen_name" : "stephenanderson",
      "indices" : [ 0, 16 ],
      "id_str" : "356663",
      "id" : 356663
    }, {
      "name" : "BigDesign",
      "screen_name" : "BigDesign",
      "indices" : [ 17, 27 ],
      "id_str" : "36380972",
      "id" : 36380972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207235655292551168",
  "geo" : { },
  "id_str" : "207236179286962179",
  "in_reply_to_user_id" : 356663,
  "text" : "@stephenanderson @bigdesign \"make sure we never miss something relevant to our lives\" Too cynical?",
  "id" : 207236179286962179,
  "in_reply_to_status_id" : 207235655292551168,
  "created_at" : "2012-05-28 22:25:30 +0000",
  "in_reply_to_screen_name" : "stephenanderson",
  "in_reply_to_user_id_str" : "356663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andres Moran",
      "screen_name" : "DreMoran",
      "indices" : [ 0, 9 ],
      "id_str" : "8461972",
      "id" : 8461972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207231100731396096",
  "geo" : { },
  "id_str" : "207232065584902145",
  "in_reply_to_user_id" : 8461972,
  "text" : "@DreMoran I put it on Github so that I knew it was clear that these beliefs could change. That made it a bit easier.",
  "id" : 207232065584902145,
  "in_reply_to_status_id" : 207231100731396096,
  "created_at" : "2012-05-28 22:09:09 +0000",
  "in_reply_to_screen_name" : "DreMoran",
  "in_reply_to_user_id_str" : "8461972",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andres Moran",
      "screen_name" : "DreMoran",
      "indices" : [ 0, 9 ],
      "id_str" : "8461972",
      "id" : 8461972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207230463482400768",
  "geo" : { },
  "id_str" : "207230685788909568",
  "in_reply_to_user_id" : 8461972,
  "text" : "@DreMoran Thank you! I'd love to read your belief list if you ever made one. It was fun and difficult to make.",
  "id" : 207230685788909568,
  "in_reply_to_status_id" : 207230463482400768,
  "created_at" : "2012-05-28 22:03:40 +0000",
  "in_reply_to_screen_name" : "DreMoran",
  "in_reply_to_user_id_str" : "8461972",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andres Moran",
      "screen_name" : "DreMoran",
      "indices" : [ 0, 9 ],
      "id_str" : "8461972",
      "id" : 8461972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207229032331354112",
  "geo" : { },
  "id_str" : "207229859905286144",
  "in_reply_to_user_id" : 8461972,
  "text" : "@DreMoran YES!",
  "id" : 207229859905286144,
  "in_reply_to_status_id" : 207229032331354112,
  "created_at" : "2012-05-28 22:00:23 +0000",
  "in_reply_to_screen_name" : "DreMoran",
  "in_reply_to_user_id_str" : "8461972",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andres Moran",
      "screen_name" : "DreMoran",
      "indices" : [ 0, 9 ],
      "id_str" : "8461972",
      "id" : 8461972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207227657723723778",
  "geo" : { },
  "id_str" : "207228044853788672",
  "in_reply_to_user_id" : 8461972,
  "text" : "@DreMoran I believe the phenomenon of soul mates exist, in a subjective way. Not a literal \"we were fated to meet\" kind of way.",
  "id" : 207228044853788672,
  "in_reply_to_status_id" : 207227657723723778,
  "created_at" : "2012-05-28 21:53:10 +0000",
  "in_reply_to_screen_name" : "DreMoran",
  "in_reply_to_user_id_str" : "8461972",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    }, {
      "name" : "Julian Gutman",
      "screen_name" : "juliangutman",
      "indices" : [ 5, 18 ],
      "id_str" : "13503812",
      "id" : 13503812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207214540809699329",
  "geo" : { },
  "id_str" : "207214887712206850",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg @juliangutman Please do! And let me know if I can help.",
  "id" : 207214887712206850,
  "in_reply_to_status_id" : 207214540809699329,
  "created_at" : "2012-05-28 21:00:53 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207200540923408385",
  "geo" : { },
  "id_str" : "207201293410897922",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg Start with the beliefs file and ignore the rest. One file at a time.",
  "id" : 207201293410897922,
  "in_reply_to_status_id" : 207200540923408385,
  "created_at" : "2012-05-28 20:06:52 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207199677978906624",
  "geo" : { },
  "id_str" : "207199956728152064",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg Thank you. You should do it too! :)",
  "id" : 207199956728152064,
  "in_reply_to_status_id" : 207199677978906624,
  "created_at" : "2012-05-28 20:01:33 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207170786203676672",
  "text" : "Gonna start my year with a mean green juice: 1 cucumber, 1 bunch of kale, 4 celery, .5 lemon, 1 knob of ginger root, &amp; 2 apples. Let's go!",
  "id" : 207170786203676672,
  "created_at" : "2012-05-28 18:05:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "happybirthdayme",
      "indices" : [ 34, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/WT11S0BE",
      "expanded_url" : "http:\/\/bustr.me\/post\/23934784635\/on-being-36",
      "display_url" : "bustr.me\/post\/239347846\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "207166385296637954",
  "text" : "On being 36: http:\/\/t.co\/WT11S0BE #happybirthdayme",
  "id" : 207166385296637954,
  "created_at" : "2012-05-28 17:48:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 25, 36 ],
      "id_str" : "142467448",
      "id" : 142467448
    }, {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 85, 95 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/1OlkmRCb",
      "expanded_url" : "http:\/\/instagr.am\/p\/LLXicfo0Lp\/",
      "display_url" : "instagr.am\/p\/LLXicfo0Lp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "207151929481109504",
  "text" : "My 2012 goal of teaching @nikobenson how to draw a face is getting a lot closer! \/cc @ingopixel  http:\/\/t.co\/1OlkmRCb",
  "id" : 207151929481109504,
  "created_at" : "2012-05-28 16:50:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judi",
      "screen_name" : "judidec",
      "indices" : [ 0, 8 ],
      "id_str" : "29344406",
      "id" : 29344406
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 9, 19 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207138307241545728",
  "geo" : { },
  "id_str" : "207138547558391808",
  "in_reply_to_user_id" : 29344406,
  "text" : "@judidec @kellianne If that's against the law, I'm gonna protest by interfering with traffic on a regular basis.",
  "id" : 207138547558391808,
  "in_reply_to_status_id" : 207138307241545728,
  "created_at" : "2012-05-28 15:57:32 +0000",
  "in_reply_to_screen_name" : "judidec",
  "in_reply_to_user_id_str" : "29344406",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Fogg",
      "screen_name" : "bjfogg",
      "indices" : [ 50, 57 ],
      "id_str" : "1118691",
      "id" : 1118691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207120995696386048",
  "text" : "Agreed! Train yourself to respond to triggers. RT @bjfogg: \"Train the routine, not the behavior\" &lt;-- that's one of my secrets to new habits",
  "id" : 207120995696386048,
  "created_at" : "2012-05-28 14:47:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Gauld",
      "screen_name" : "tomgauld",
      "indices" : [ 29, 38 ],
      "id_str" : "46090073",
      "id" : 46090073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/RfQtKjeN",
      "expanded_url" : "http:\/\/bit.ly\/K6ExjZ",
      "display_url" : "bit.ly\/K6ExjZ"
    } ]
  },
  "geo" : { },
  "id_str" : "207115538751700992",
  "text" : "Hello, my favorite comic! RT @tomgauld: I\u2019ve started a tumblr! http:\/\/t.co\/RfQtKjeN",
  "id" : 207115538751700992,
  "created_at" : "2012-05-28 14:26:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/5cqR6bET",
      "expanded_url" : "http:\/\/flic.kr\/p\/c6FpJS",
      "display_url" : "flic.kr\/p\/c6FpJS"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "206954332187394048",
  "text" : "8:36pm Beer, bath, birthday eve http:\/\/t.co\/5cqR6bET",
  "id" : 206954332187394048,
  "created_at" : "2012-05-28 03:45:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/jlBBQ0B1",
      "expanded_url" : "http:\/\/instagr.am\/p\/LJuEcCI0Fu\/",
      "display_url" : "instagr.am\/p\/LJuEcCI0Fu\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6170123598, -122.319116592 ]
  },
  "id_str" : "206920140049231872",
  "text" : "Today is brought to you by found boats and funny faces   @ Cal Anderson Park http:\/\/t.co\/jlBBQ0B1",
  "id" : 206920140049231872,
  "created_at" : "2012-05-28 01:29:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Wang",
      "screen_name" : "brianmwang",
      "indices" : [ 0, 11 ],
      "id_str" : "93478440",
      "id" : 93478440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206900652822106113",
  "geo" : { },
  "id_str" : "206903742069620736",
  "in_reply_to_user_id" : 93478440,
  "text" : "@brianmwang He seemed to have ample disclaimers. Speak up in the comments!",
  "id" : 206903742069620736,
  "in_reply_to_status_id" : 206900652822106113,
  "created_at" : "2012-05-28 00:24:30 +0000",
  "in_reply_to_screen_name" : "brianmwang",
  "in_reply_to_user_id_str" : "93478440",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremie Miller",
      "screen_name" : "jeremie",
      "indices" : [ 0, 8 ],
      "id_str" : "1704421",
      "id" : 1704421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206893124797202434",
  "geo" : { },
  "id_str" : "206900362098114560",
  "in_reply_to_user_id" : 1704421,
  "text" : "@jeremie Wow, I\u2019m sorry to hear that. But you directed bad events to some new good outcomes!",
  "id" : 206900362098114560,
  "in_reply_to_status_id" : 206893124797202434,
  "created_at" : "2012-05-28 00:11:05 +0000",
  "in_reply_to_screen_name" : "jeremie",
  "in_reply_to_user_id_str" : "1704421",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206900014717480960",
  "text" : "You just got a book deal to write a highly promoted book that will be about everything you know. What will you write about?",
  "id" : 206900014717480960,
  "created_at" : "2012-05-28 00:09:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremie Miller",
      "screen_name" : "jeremie",
      "indices" : [ 0, 8 ],
      "id_str" : "1704421",
      "id" : 1704421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206877549723254784",
  "geo" : { },
  "id_str" : "206883810254663681",
  "in_reply_to_user_id" : 1704421,
  "text" : "@jeremie Awesome! What got you started?",
  "id" : 206883810254663681,
  "in_reply_to_status_id" : 206877549723254784,
  "created_at" : "2012-05-27 23:05:18 +0000",
  "in_reply_to_screen_name" : "jeremie",
  "in_reply_to_user_id_str" : "1704421",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 0, 6 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206869887212208128",
  "geo" : { },
  "id_str" : "206870244021633025",
  "in_reply_to_user_id" : 75079616,
  "text" : "@ifttt Yeah, I can see that as I look into it a bit myself. But if you can figure it out, that'll save all of us the trouble! :)",
  "id" : 206870244021633025,
  "in_reply_to_status_id" : 206869887212208128,
  "created_at" : "2012-05-27 22:11:24 +0000",
  "in_reply_to_screen_name" : "IFTTT",
  "in_reply_to_user_id_str" : "75079616",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206866928860532736",
  "geo" : { },
  "id_str" : "206867419480850432",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Which books are you gonna read? You better be done with your bender by Tuesday.",
  "id" : 206867419480850432,
  "in_reply_to_status_id" : 206866928860532736,
  "created_at" : "2012-05-27 22:00:10 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 0, 6 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 97 ],
      "url" : "https:\/\/t.co\/yCug8Aah",
      "expanded_url" : "https:\/\/developers.google.com\/google-apps\/spreadsheets\/",
      "display_url" : "developers.google.com\/google-apps\/sp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206863383188869120",
  "in_reply_to_user_id" : 75079616,
  "text" : "@ifttt Any plans on adding support for adding rows to a Google Spreadsheet? https:\/\/t.co\/yCug8Aah (especially via text!)",
  "id" : 206863383188869120,
  "created_at" : "2012-05-27 21:44:08 +0000",
  "in_reply_to_screen_name" : "IFTTT",
  "in_reply_to_user_id_str" : "75079616",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cohen",
      "screen_name" : "jonathanacohen",
      "indices" : [ 0, 15 ],
      "id_str" : "6528342",
      "id" : 6528342
    }, {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 124, 140 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206859218119163904",
  "geo" : { },
  "id_str" : "206859422889287680",
  "in_reply_to_user_id" : 6528342,
  "text" : "@jonathanacohen We could probably make the PSD file available if you really wanted it. How do you want to customize it? \/cc @ameliagreenhall",
  "id" : 206859422889287680,
  "in_reply_to_status_id" : 206859218119163904,
  "created_at" : "2012-05-27 21:28:24 +0000",
  "in_reply_to_screen_name" : "jonathanacohen",
  "in_reply_to_user_id_str" : "6528342",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206846936374972417",
  "geo" : { },
  "id_str" : "206851879408386048",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin I'll check it out! Thanks.",
  "id" : 206851879408386048,
  "in_reply_to_status_id" : 206846936374972417,
  "created_at" : "2012-05-27 20:58:25 +0000",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/T1DwmfDf",
      "expanded_url" : "http:\/\/movies.netflix.com\/WiMovie\/Forks_Over_Knives\/70185045?trkid=7728649",
      "display_url" : "movies.netflix.com\/WiMovie\/Forks_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206842986917670912",
  "text" : "Just watched \"Forks Over Knives\" on Netflix Instant. Eat plant based whole foods, yo. http:\/\/t.co\/T1DwmfDf",
  "id" : 206842986917670912,
  "created_at" : "2012-05-27 20:23:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick O'Neill",
      "screen_name" : "allnick",
      "indices" : [ 3, 11 ],
      "id_str" : "965651",
      "id" : 965651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/Sk13veBl",
      "expanded_url" : "http:\/\/joekraus.com\/were-creating-a-culture-of-distraction",
      "display_url" : "joekraus.com\/were-creating-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206802770005737473",
  "text" : "RT @allnick: A culture of distraction http:\/\/t.co\/Sk13veBl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/Sk13veBl",
        "expanded_url" : "http:\/\/joekraus.com\/were-creating-a-culture-of-distraction",
        "display_url" : "joekraus.com\/were-creating-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "206798430423613440",
    "text" : "A culture of distraction http:\/\/t.co\/Sk13veBl",
    "id" : 206798430423613440,
    "created_at" : "2012-05-27 17:26:02 +0000",
    "user" : {
      "name" : "Nick O'Neill",
      "screen_name" : "allnick",
      "protected" : false,
      "id_str" : "965651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1675946925\/nickHeadshot_normal.jpg",
      "id" : 965651,
      "verified" : false
    }
  },
  "id" : 206802770005737473,
  "created_at" : "2012-05-27 17:43:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 3, 14 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Indie Game:The Movie",
      "screen_name" : "indiegamemovie",
      "indices" : [ 54, 69 ],
      "id_str" : "111492860",
      "id" : 111492860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/ZRJC4rcv",
      "expanded_url" : "http:\/\/gigaom.com\/video\/indie-game-itunes-vhx-kickstarter-steam\/",
      "display_url" : "gigaom.com\/video\/indie-ga\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206799435697631232",
  "text" : "RT @waxpancake: I make a cameo in this great story on @indiegamemovie\u2019s digital distribution: http:\/\/t.co\/ZRJC4rcv This feels like the f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Indie Game:The Movie",
        "screen_name" : "indiegamemovie",
        "indices" : [ 38, 53 ],
        "id_str" : "111492860",
        "id" : 111492860
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/ZRJC4rcv",
        "expanded_url" : "http:\/\/gigaom.com\/video\/indie-game-itunes-vhx-kickstarter-steam\/",
        "display_url" : "gigaom.com\/video\/indie-ga\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "206784398316675074",
    "text" : "I make a cameo in this great story on @indiegamemovie\u2019s digital distribution: http:\/\/t.co\/ZRJC4rcv This feels like the future of film.",
    "id" : 206784398316675074,
    "created_at" : "2012-05-27 16:30:17 +0000",
    "user" : {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "protected" : false,
      "id_str" : "13461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416642320574844928\/Gz7V2B6r_normal.jpeg",
      "id" : 13461,
      "verified" : false
    }
  },
  "id" : 206799435697631232,
  "created_at" : "2012-05-27 17:30:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "indices" : [ 3, 17 ],
      "id_str" : "19575586",
      "id" : 19575586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/Sln26CqR",
      "expanded_url" : "http:\/\/www.news.com.au\/breaking-news\/world\/german-teen-shouryya-ray-solves-300-year-old-mathematical-riddle-posed-by-sir-isaac-newton\/story-e6frfkui-1226368490521",
      "display_url" : "news.com.au\/breaking-news\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206758254238367744",
  "text" : "RT @hackernewsbot: German teen solves 300-year-old mathematical riddle posed by Sir Isaac Newton... http:\/\/t.co\/Sln26CqR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/news.ycombinator.com\/\" rel=\"nofollow\"\u003EHacker News Bot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/Sln26CqR",
        "expanded_url" : "http:\/\/www.news.com.au\/breaking-news\/world\/german-teen-shouryya-ray-solves-300-year-old-mathematical-riddle-posed-by-sir-isaac-newton\/story-e6frfkui-1226368490521",
        "display_url" : "news.com.au\/breaking-news\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "206681666117316609",
    "text" : "German teen solves 300-year-old mathematical riddle posed by Sir Isaac Newton... http:\/\/t.co\/Sln26CqR",
    "id" : 206681666117316609,
    "created_at" : "2012-05-27 09:42:03 +0000",
    "user" : {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "protected" : false,
      "id_str" : "19575586",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/73596050\/yc500_normal.jpg",
      "id" : 19575586,
      "verified" : false
    }
  },
  "id" : 206758254238367744,
  "created_at" : "2012-05-27 14:46:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "indices" : [ 3, 17 ],
      "id_str" : "19575586",
      "id" : 19575586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/q1sjN3iZ",
      "expanded_url" : "http:\/\/danshipper.com\/stop-taking-yourself-so-seriously",
      "display_url" : "danshipper.com\/stop-taking-yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206757622702014464",
  "text" : "RT @hackernewsbot: Stop Taking Yourself So Seriously... http:\/\/t.co\/q1sjN3iZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/news.ycombinator.com\/\" rel=\"nofollow\"\u003EHacker News Bot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/q1sjN3iZ",
        "expanded_url" : "http:\/\/danshipper.com\/stop-taking-yourself-so-seriously",
        "display_url" : "danshipper.com\/stop-taking-yo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "206666569361788928",
    "text" : "Stop Taking Yourself So Seriously... http:\/\/t.co\/q1sjN3iZ",
    "id" : 206666569361788928,
    "created_at" : "2012-05-27 08:42:04 +0000",
    "user" : {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "protected" : false,
      "id_str" : "19575586",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/73596050\/yc500_normal.jpg",
      "id" : 19575586,
      "verified" : false
    }
  },
  "id" : 206757622702014464,
  "created_at" : "2012-05-27 14:43:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kav Latiolais",
      "screen_name" : "kavla",
      "indices" : [ 0, 6 ],
      "id_str" : "28838912",
      "id" : 28838912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206645175840280576",
  "geo" : { },
  "id_str" : "206645965833256962",
  "in_reply_to_user_id" : 28838912,
  "text" : "@kavla Yes, but not too much right. I think maybe 2-3 servings of up for every serving or right. Give or take to taste.",
  "id" : 206645965833256962,
  "in_reply_to_status_id" : 206645175840280576,
  "created_at" : "2012-05-27 07:20:12 +0000",
  "in_reply_to_screen_name" : "kavla",
  "in_reply_to_user_id_str" : "28838912",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kav Latiolais",
      "screen_name" : "kavla",
      "indices" : [ 1, 7 ],
      "id_str" : "28838912",
      "id" : 28838912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206643522424672256",
  "geo" : { },
  "id_str" : "206644904825335808",
  "in_reply_to_user_id" : 28838912,
  "text" : ".@kavla It\u2019s so simple really, just make all the numbers go up!",
  "id" : 206644904825335808,
  "in_reply_to_status_id" : 206643522424672256,
  "created_at" : "2012-05-27 07:15:59 +0000",
  "in_reply_to_screen_name" : "kavla",
  "in_reply_to_user_id_str" : "28838912",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/0PcVcPlm",
      "expanded_url" : "http:\/\/flic.kr\/p\/c642DU",
      "display_url" : "flic.kr\/p\/c642DU"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612166, -122.317 ]
  },
  "id_str" : "206591278832566272",
  "text" : "8:36pm Solo dinner brain mush times http:\/\/t.co\/0PcVcPlm",
  "id" : 206591278832566272,
  "created_at" : "2012-05-27 03:42:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 48, 60 ],
      "id_str" : "154236895",
      "id" : 154236895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/Fm9ZecxZ",
      "expanded_url" : "http:\/\/tmblr.co\/ZwHqDyMCYKzF",
      "display_url" : "tmblr.co\/ZwHqDyMCYKzF"
    } ]
  },
  "geo" : { },
  "id_str" : "206557435291385856",
  "text" : "Email me if you're interested or have leads! RT @healthmonth: Do any of you lovely people want to buy Health Month? http:\/\/t.co\/Fm9ZecxZ",
  "id" : 206557435291385856,
  "created_at" : "2012-05-27 01:28:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather quintal",
      "screen_name" : "heatherquintal",
      "indices" : [ 0, 15 ],
      "id_str" : "12761252",
      "id" : 12761252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206538678657482752",
  "geo" : { },
  "id_str" : "206554708897300481",
  "in_reply_to_user_id" : 12761252,
  "text" : "@heatherquintal I think they were days I didn\u2019t post right away and then forgot about. I actually though there would be more than 4\/year.",
  "id" : 206554708897300481,
  "in_reply_to_status_id" : 206538678657482752,
  "created_at" : "2012-05-27 01:17:34 +0000",
  "in_reply_to_screen_name" : "heatherquintal",
  "in_reply_to_user_id_str" : "12761252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lifelongproject",
      "indices" : [ 114, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/8tJSpI4w",
      "expanded_url" : "http:\/\/bit.ly\/KjgYCr",
      "display_url" : "bit.ly\/KjgYCr"
    } ]
  },
  "geo" : { },
  "id_str" : "206525737560317952",
  "text" : "I just passed 4 years of doing 8:36pm, for a total of 1,448 days and 16 missed days (1.09%). http:\/\/t.co\/8tJSpI4w #lifelongproject",
  "id" : 206525737560317952,
  "created_at" : "2012-05-26 23:22:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yolo",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/YnzDsNS5",
      "expanded_url" : "http:\/\/dangurewitch.tumblr.com\/post\/23800169130\/recently-it-came-to-my-attention-that-the-word",
      "display_url" : "dangurewitch.tumblr.com\/post\/238001691\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206485950673588224",
  "text" : "YOYOYO OSO YOYOSOLO OWO LOCO PO-PO: http:\/\/t.co\/YnzDsNS5 #yolo",
  "id" : 206485950673588224,
  "created_at" : "2012-05-26 20:44:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206445027243732994",
  "text" : "I'd save my wallet so I could buy another phone quickly.  Plus\u2026 maybe the new one's out!  :)",
  "id" : 206445027243732994,
  "created_at" : "2012-05-26 18:01:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206444803255312385",
  "text" : "41% would save their wallet, 58% their phone. Theory: Phone-savers value their money. Wallet-savers value their time.",
  "id" : 206444803255312385,
  "created_at" : "2012-05-26 18:00:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacob james",
      "screen_name" : "jacoblashes",
      "indices" : [ 3, 15 ],
      "id_str" : "139587142",
      "id" : 139587142
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 17, 30 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206442500599197698",
  "text" : "RT @jacoblashes: @busterbenson In this hypothetical did I remember to download the fire extinguisher app?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "206438762182488064",
    "geo" : { },
    "id_str" : "206442404000182272",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson In this hypothetical did I remember to download the fire extinguisher app?",
    "id" : 206442404000182272,
    "in_reply_to_status_id" : 206438762182488064,
    "created_at" : "2012-05-26 17:51:19 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "jacob james",
      "screen_name" : "jacoblashes",
      "protected" : false,
      "id_str" : "139587142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2190463267\/image_normal.jpg",
      "id" : 139587142,
      "verified" : false
    }
  },
  "id" : 206442500599197698,
  "created_at" : "2012-05-26 17:51:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Robinson",
      "screen_name" : "Julesmarie",
      "indices" : [ 0, 11 ],
      "id_str" : "14144646",
      "id" : 14144646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206439765116071936",
  "geo" : { },
  "id_str" : "206442006145269760",
  "in_reply_to_user_id" : 14144646,
  "text" : "@Julesmarie Yes, iCloud presumably.",
  "id" : 206442006145269760,
  "in_reply_to_status_id" : 206439765116071936,
  "created_at" : "2012-05-26 17:49:44 +0000",
  "in_reply_to_screen_name" : "Julesmarie",
  "in_reply_to_user_id_str" : "14144646",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206441523745792001",
  "geo" : { },
  "id_str" : "206441866005188608",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin What\u2019a not replaceable in your phone?",
  "id" : 206441866005188608,
  "in_reply_to_status_id" : 206441523745792001,
  "created_at" : "2012-05-26 17:49:11 +0000",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206440646028967936",
  "geo" : { },
  "id_str" : "206441532373471232",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne Totally cheating.",
  "id" : 206441532373471232,
  "in_reply_to_status_id" : 206440646028967936,
  "created_at" : "2012-05-26 17:47:51 +0000",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206438886598123520",
  "geo" : { },
  "id_str" : "206439167029288960",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap Can't you re-download your cards from the bank?",
  "id" : 206439167029288960,
  "in_reply_to_status_id" : 206438886598123520,
  "created_at" : "2012-05-26 17:38:27 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206438762182488064",
  "text" : "Your house is burning down and you only have enough time to save your iPhone or your wallet. Which one do you rush back in to save?",
  "id" : 206438762182488064,
  "created_at" : "2012-05-26 17:36:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bud.ge\" rel=\"nofollow\"\u003EBudge\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/7MeGqlSD",
      "expanded_url" : "http:\/\/bud.ge\/n\/2e8v",
      "display_url" : "bud.ge\/n\/2e8v"
    } ]
  },
  "geo" : { },
  "id_str" : "206418179478667268",
  "text" : "My secret ingredient is breaking 1,000 pushups with 1 day to spare. Gonna keep going... http:\/\/t.co\/7MeGqlSD",
  "id" : 206418179478667268,
  "created_at" : "2012-05-26 16:15:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Wingfield",
      "screen_name" : "nickwingfield",
      "indices" : [ 3, 17 ],
      "id_str" : "19476868",
      "id" : 19476868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/b07ojCKT",
      "expanded_url" : "http:\/\/nyti.ms\/LONNdk",
      "display_url" : "nyti.ms\/LONNdk"
    } ]
  },
  "geo" : { },
  "id_str" : "206406920649715713",
  "text" : "RT @nickwingfield: Facebook\u2019s Brilliant Disaster http:\/\/t.co\/b07ojCKT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/b07ojCKT",
        "expanded_url" : "http:\/\/nyti.ms\/LONNdk",
        "display_url" : "nyti.ms\/LONNdk"
      } ]
    },
    "geo" : { },
    "id_str" : "206385741176123392",
    "text" : "Facebook\u2019s Brilliant Disaster http:\/\/t.co\/b07ojCKT",
    "id" : 206385741176123392,
    "created_at" : "2012-05-26 14:06:09 +0000",
    "user" : {
      "name" : "Nick Wingfield",
      "screen_name" : "nickwingfield",
      "protected" : false,
      "id_str" : "19476868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000678821807\/09ff974778387af6846f623f3886684e_normal.jpeg",
      "id" : 19476868,
      "verified" : false
    }
  },
  "id" : 206406920649715713,
  "created_at" : "2012-05-26 15:30:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erick Castro",
      "screen_name" : "castrodisiac",
      "indices" : [ 3, 16 ],
      "id_str" : "74232590",
      "id" : 74232590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/aAOcpB9b",
      "expanded_url" : "http:\/\/mattsko.files.wordpress.com\/2011\/07\/frank-sinatra.jpg",
      "display_url" : "mattsko.files.wordpress.com\/2011\/07\/frank-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206242981223731200",
  "text" : "RT @castrodisiac: You will never in your entire life, ever look this cool.  Getting out of helicopter with a cocktail.  No big whoop. ht ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/aAOcpB9b",
        "expanded_url" : "http:\/\/mattsko.files.wordpress.com\/2011\/07\/frank-sinatra.jpg",
        "display_url" : "mattsko.files.wordpress.com\/2011\/07\/frank-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "206206560119160832",
    "text" : "You will never in your entire life, ever look this cool.  Getting out of helicopter with a cocktail.  No big whoop. http:\/\/t.co\/aAOcpB9b",
    "id" : 206206560119160832,
    "created_at" : "2012-05-26 02:14:09 +0000",
    "user" : {
      "name" : "Erick Castro",
      "screen_name" : "castrodisiac",
      "protected" : false,
      "id_str" : "74232590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465927852848734208\/eelLAbFj_normal.png",
      "id" : 74232590,
      "verified" : false
    }
  },
  "id" : 206242981223731200,
  "created_at" : "2012-05-26 04:38:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/XTVrAzFe",
      "expanded_url" : "http:\/\/instagr.am\/p\/LE2Xh5o0KM\/",
      "display_url" : "instagr.am\/p\/LE2Xh5o0KM\/"
    } ]
  },
  "geo" : { },
  "id_str" : "206234616921722881",
  "text" : "8:36pm Read the choo book or else someone gets hurt http:\/\/t.co\/XTVrAzFe",
  "id" : 206234616921722881,
  "created_at" : "2012-05-26 04:05:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 119 ],
      "url" : "https:\/\/t.co\/M4TV7VNM",
      "expanded_url" : "https:\/\/vimeo.com\/42828824",
      "display_url" : "vimeo.com\/42828824"
    } ]
  },
  "geo" : { },
  "id_str" : "206208712187199489",
  "text" : "If you\u2019re having a tough day, or just wanna be the weird person tearing up in public, watch this: https:\/\/t.co\/M4TV7VNM",
  "id" : 206208712187199489,
  "created_at" : "2012-05-26 02:22:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 19, 31 ],
      "id_str" : "15019184",
      "id" : 15019184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/KCMZdT6t",
      "expanded_url" : "http:\/\/bit.ly\/MEK1Qi",
      "display_url" : "bit.ly\/MEK1Qi"
    } ]
  },
  "geo" : { },
  "id_str" : "206202278288433153",
  "text" : "\u201CHELL YES or NO\u201D - @heyamberrae\u2019s 4 words of wise wisdom http:\/\/t.co\/KCMZdT6t",
  "id" : 206202278288433153,
  "created_at" : "2012-05-26 01:57:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Campbell",
      "screen_name" : "bitdepth",
      "indices" : [ 0, 9 ],
      "id_str" : "7680",
      "id" : 7680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206091473211494400",
  "geo" : { },
  "id_str" : "206091732704706560",
  "in_reply_to_user_id" : 7680,
  "text" : "@bitdepth That's kind of you to say! I've had varying levels of success with both sides of the equation as well.",
  "id" : 206091732704706560,
  "in_reply_to_status_id" : 206091473211494400,
  "created_at" : "2012-05-25 18:37:52 +0000",
  "in_reply_to_screen_name" : "bitdepth",
  "in_reply_to_user_id_str" : "7680",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/Wrhqq5ch",
      "expanded_url" : "http:\/\/hipsterhabitapp.com",
      "display_url" : "hipsterhabitapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "206090205625724928",
  "text" : "One of the reasons I like http:\/\/t.co\/Wrhqq5ch is because it\u2019s designed to actually work but also benefits from being wrapped in a gimmick.",
  "id" : 206090205625724928,
  "created_at" : "2012-05-25 18:31:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 3, 12 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 14, 27 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206078677241438208",
  "text" : "RT @agaricus: @busterbenson Changing a \"thing\" requires changing the context. But the context fights back!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "206076590994624512",
    "geo" : { },
    "id_str" : "206077711561654272",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson Changing a \"thing\" requires changing the context. But the context fights back!",
    "id" : 206077711561654272,
    "in_reply_to_status_id" : 206076590994624512,
    "created_at" : "2012-05-25 17:42:09 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "protected" : false,
      "id_str" : "21678279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/105835994\/agaricus_normal.jpg",
      "id" : 21678279,
      "verified" : false
    }
  },
  "id" : 206078677241438208,
  "created_at" : "2012-05-25 17:46:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206076590994624512",
  "text" : "Every attempt to change creates an equal and opposite force of resistance to change.",
  "id" : 206076590994624512,
  "created_at" : "2012-05-25 17:37:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/1A6avnp8",
      "expanded_url" : "http:\/\/uberconference.com",
      "display_url" : "uberconference.com"
    }, {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/A1KY9X0n",
      "expanded_url" : "http:\/\/uberconference.com\/zGUUeVF2",
      "display_url" : "uberconference.com\/zGUUeVF2"
    } ]
  },
  "geo" : { },
  "id_str" : "206068025785454594",
  "text" : "I like lots about http:\/\/t.co\/1A6avnp8. Looking forward to coming up with more reasons to do conference calls. Sign up! http:\/\/t.co\/A1KY9X0n",
  "id" : 206068025785454594,
  "created_at" : "2012-05-25 17:03:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TAXI",
      "screen_name" : "designtaxi",
      "indices" : [ 3, 14 ],
      "id_str" : "14112296",
      "id" : 14112296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/GK08SLoJ",
      "expanded_url" : "http:\/\/ow.ly\/b9fYQ",
      "display_url" : "ow.ly\/b9fYQ"
    } ]
  },
  "geo" : { },
  "id_str" : "206063812447715329",
  "text" : "RT @designtaxi: 'Hipster Habit App' to help you improve yourself in 30 days http:\/\/t.co\/GK08SLoJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/GK08SLoJ",
        "expanded_url" : "http:\/\/ow.ly\/b9fYQ",
        "display_url" : "ow.ly\/b9fYQ"
      } ]
    },
    "geo" : { },
    "id_str" : "206029587266809858",
    "text" : "'Hipster Habit App' to help you improve yourself in 30 days http:\/\/t.co\/GK08SLoJ",
    "id" : 206029587266809858,
    "created_at" : "2012-05-25 14:30:56 +0000",
    "user" : {
      "name" : "TAXI",
      "screen_name" : "designtaxi",
      "protected" : false,
      "id_str" : "14112296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446325938121216000\/mfMTNQxO_normal.png",
      "id" : 14112296,
      "verified" : true
    }
  },
  "id" : 206063812447715329,
  "created_at" : "2012-05-25 16:46:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rock Health",
      "screen_name" : "Rock_Health",
      "indices" : [ 24, 36 ],
      "id_str" : "161372707",
      "id" : 161372707
    }, {
      "name" : "Sessions",
      "screen_name" : "joinsessions",
      "indices" : [ 58, 71 ],
      "id_str" : "360907906",
      "id" : 360907906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/S39TNoAR",
      "expanded_url" : "http:\/\/bit.ly\/MBjzal",
      "display_url" : "bit.ly\/MBjzal"
    } ]
  },
  "geo" : { },
  "id_str" : "206038250006134786",
  "text" : "This is really cool. RT @Rock_Health: Rock Health Company @joinsessions is Reinventing Personal Coaching http:\/\/t.co\/S39TNoAR",
  "id" : 206038250006134786,
  "created_at" : "2012-05-25 15:05:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 3, 12 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/WjsLDeer",
      "expanded_url" : "http:\/\/www.avc.com\/a_vc\/2012\/05\/fun-friday-routines.html",
      "display_url" : "avc.com\/a_vc\/2012\/05\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206037844261736448",
  "text" : "RT @arainert: Taken individually, they're not exciting but as a whole, people's routines are fascinating &gt; A VC: Fun Friday: Routines ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 123, 143 ],
        "url" : "http:\/\/t.co\/WjsLDeer",
        "expanded_url" : "http:\/\/www.avc.com\/a_vc\/2012\/05\/fun-friday-routines.html",
        "display_url" : "avc.com\/a_vc\/2012\/05\/f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "206030146547875840",
    "text" : "Taken individually, they're not exciting but as a whole, people's routines are fascinating &gt; A VC: Fun Friday: Routines http:\/\/t.co\/WjsLDeer",
    "id" : 206030146547875840,
    "created_at" : "2012-05-25 14:33:09 +0000",
    "user" : {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "protected" : false,
      "id_str" : "7482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444089158274154496\/ZePPNQzQ_normal.jpeg",
      "id" : 7482,
      "verified" : false
    }
  },
  "id" : 206037844261736448,
  "created_at" : "2012-05-25 15:03:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "indices" : [ 55, 63 ],
      "id_str" : "4030",
      "id" : 4030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/MLVLLrip",
      "expanded_url" : "http:\/\/bit.ly\/LlRYr4",
      "display_url" : "bit.ly\/LlRYr4"
    } ]
  },
  "geo" : { },
  "id_str" : "205914013266214912",
  "text" : "\u201CWalk in the shadows until you run out of shadows.\u201D RT @monstro: Serendipitor! The mapping app that leads you astray. http:\/\/t.co\/MLVLLrip",
  "id" : 205914013266214912,
  "created_at" : "2012-05-25 06:51:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205909425939165185",
  "geo" : { },
  "id_str" : "205909951099576320",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Okay phew. :)",
  "id" : 205909951099576320,
  "in_reply_to_status_id" : 205909425939165185,
  "created_at" : "2012-05-25 06:35:32 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205892321772978176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086008316, -122.306148216 ]
  },
  "id_str" : "205909251611312128",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Woohoo! Extra hipster points for tagging a photo of them on Instagram, too. Are you gonna do 5 at once? Hard core.",
  "id" : 205909251611312128,
  "in_reply_to_status_id" : 205892321772978176,
  "created_at" : "2012-05-25 06:32:45 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/9oTCRMPc",
      "expanded_url" : "http:\/\/instagr.am\/p\/LCO4UmI0De\/",
      "display_url" : "instagr.am\/p\/LCO4UmI0De\/"
    } ]
  },
  "geo" : { },
  "id_str" : "205866080835600385",
  "text" : "8:36pm No more dirt! http:\/\/t.co\/9oTCRMPc",
  "id" : 205866080835600385,
  "created_at" : "2012-05-25 03:41:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ash bhoopathy",
      "screen_name" : "ashbhoopathy",
      "indices" : [ 0, 13 ],
      "id_str" : "19888257",
      "id" : 19888257
    }, {
      "name" : "nReduce",
      "screen_name" : "nReduce",
      "indices" : [ 47, 55 ],
      "id_str" : "568897631",
      "id" : 568897631
    }, {
      "name" : "Lizi",
      "screen_name" : "lizibot",
      "indices" : [ 60, 68 ],
      "id_str" : "446725746",
      "id" : 446725746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205823431172820993",
  "geo" : { },
  "id_str" : "205825531910959104",
  "in_reply_to_user_id" : 19888257,
  "text" : "@ashbhoopathy Totally! I\u2019ve also signed up for @nreduce and @lizibot cause they both look awesome.",
  "id" : 205825531910959104,
  "in_reply_to_status_id" : 205823431172820993,
  "created_at" : "2012-05-25 01:00:05 +0000",
  "in_reply_to_screen_name" : "ashbhoopathy",
  "in_reply_to_user_id_str" : "19888257",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lifehacker",
      "screen_name" : "lifehacker",
      "indices" : [ 102, 113 ],
      "id_str" : "7144422",
      "id" : 7144422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HipsterHabitApp",
      "indices" : [ 0, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/ljuuFxNt",
      "expanded_url" : "http:\/\/lifehacker.com\/5913129\/hipster-habit-app-is-a-pocketable-printable-mini+book-designed-to-help-you-create-or-remove-habits-in-30-days",
      "display_url" : "lifehacker.com\/5913129\/hipste\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "205780549460172801",
  "text" : "#HipsterHabitApp Is a Pocketable, Printable Mini-Book Designed to Help You Create Habits in 30 Days - @Lifehacker http:\/\/t.co\/ljuuFxNt",
  "id" : 205780549460172801,
  "created_at" : "2012-05-24 22:01:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rdio",
      "screen_name" : "Rdio",
      "indices" : [ 117, 122 ],
      "id_str" : "54205414",
      "id" : 54205414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205745911484260353",
  "text" : "I just deleted all the music off of my laptop (which, at 7 years old, is on its last legs\u2026 hurry up WWDC). Long live @rdio!",
  "id" : 205745911484260353,
  "created_at" : "2012-05-24 19:43:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "indices" : [ 3, 14 ],
      "id_str" : "8070502",
      "id" : 8070502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/11vkBszF",
      "expanded_url" : "http:\/\/hipsterhabitapp.com\/",
      "display_url" : "hipsterhabitapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "205719204102549504",
  "text" : "RT @danshapiro: Hipster Habit: the first time I've been excited to turn on my printer in a very long time. http:\/\/t.co\/11vkBszF",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/11vkBszF",
        "expanded_url" : "http:\/\/hipsterhabitapp.com\/",
        "display_url" : "hipsterhabitapp.com"
      } ]
    },
    "geo" : { },
    "id_str" : "205712234280796160",
    "text" : "Hipster Habit: the first time I've been excited to turn on my printer in a very long time. http:\/\/t.co\/11vkBszF",
    "id" : 205712234280796160,
    "created_at" : "2012-05-24 17:29:53 +0000",
    "user" : {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "protected" : false,
      "id_str" : "8070502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/51828452\/eye_pic_normal.jpg",
      "id" : 8070502,
      "verified" : false
    }
  },
  "id" : 205719204102549504,
  "created_at" : "2012-05-24 17:57:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 0, 13 ],
      "id_str" : "14471007",
      "id" : 14471007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205714429013274624",
  "geo" : { },
  "id_str" : "205714860334514177",
  "in_reply_to_user_id" : 14471007,
  "text" : "@dianakimball Thank you! It felt good to just put it all down.",
  "id" : 205714860334514177,
  "in_reply_to_status_id" : 205714429013274624,
  "created_at" : "2012-05-24 17:40:19 +0000",
  "in_reply_to_screen_name" : "dianakimball",
  "in_reply_to_user_id_str" : "14471007",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205713652970569728",
  "geo" : { },
  "id_str" : "205714069251043329",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Hah, you're so right. That's exactly why.",
  "id" : 205714069251043329,
  "in_reply_to_status_id" : 205713652970569728,
  "created_at" : "2012-05-24 17:37:10 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hipsterhabitapp",
      "indices" : [ 5, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205713415954644992",
  "text" : "Wow, #hipsterhabitapp is bigger on Tumblr than Twitter today.  Curious.",
  "id" : 205713415954644992,
  "created_at" : "2012-05-24 17:34:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205710383342825473",
  "geo" : { },
  "id_str" : "205710769994735616",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten I think they've started to get it, though. We'll see...",
  "id" : 205710769994735616,
  "in_reply_to_status_id" : 205710383342825473,
  "created_at" : "2012-05-24 17:24:04 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Collette",
      "screen_name" : "sfposhy",
      "indices" : [ 22, 30 ],
      "id_str" : "268453413",
      "id" : 268453413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/MtuVsG6t",
      "expanded_url" : "http:\/\/techcrunch.com\/2012\/05\/24\/facebook-camera\/",
      "display_url" : "techcrunch.com\/2012\/05\/24\/fac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "205710063950770178",
  "text" : "Woah. Interesting! RT @sfposhy: Facebook Camera, what? http:\/\/t.co\/MtuVsG6t",
  "id" : 205710063950770178,
  "created_at" : "2012-05-24 17:21:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205708794892791809",
  "geo" : { },
  "id_str" : "205708983112171520",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Are you red colorblind?  Which colors can you see?",
  "id" : 205708983112171520,
  "in_reply_to_status_id" : 205708794892791809,
  "created_at" : "2012-05-24 17:16:58 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hipsterhabitapp",
      "indices" : [ 121, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/NDqpgbod",
      "expanded_url" : "http:\/\/bustr.me\/post\/23677235713\/the-state-of-behavior-change-and-a-new-free-app",
      "display_url" : "bustr.me\/post\/236772357\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "205706416806309889",
  "text" : "My latest thoughts on behavior change, and a new free app you can print out and put in your wallet: http:\/\/t.co\/NDqpgbod #hipsterhabitapp",
  "id" : 205706416806309889,
  "created_at" : "2012-05-24 17:06:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nina alter",
      "screen_name" : "ninavizz",
      "indices" : [ 32, 41 ],
      "id_str" : "823525",
      "id" : 823525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205703833995853825",
  "text" : "Okay, who's colorblind here? RT @ninavizz: 20% of all humans today are colorblind, with men oddly far out-numbering women.",
  "id" : 205703833995853825,
  "created_at" : "2012-05-24 16:56:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radiolab",
      "screen_name" : "Radiolab",
      "indices" : [ 113, 122 ],
      "id_str" : "28583197",
      "id" : 28583197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/Sur2JK6V",
      "expanded_url" : "http:\/\/www.radiolab.org\/2012\/may\/21\/sky-isnt-blue\/",
      "display_url" : "radiolab.org\/2012\/may\/21\/sk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "205699198157471744",
  "text" : "Did you know Homer (and almost everyone else in the age of the Greeks) was colorblind? http:\/\/t.co\/Sur2JK6V \/via @radiolab",
  "id" : 205699198157471744,
  "created_at" : "2012-05-24 16:38:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 16, 23 ],
      "id_str" : "30495974",
      "id" : 30495974
    }, {
      "name" : "benhuh",
      "screen_name" : "benhuh",
      "indices" : [ 30, 37 ],
      "id_str" : "14112294",
      "id" : 14112294
    }, {
      "name" : "Best Thing This Year",
      "screen_name" : "TBTTY",
      "indices" : [ 105, 111 ],
      "id_str" : "570264874",
      "id" : 570264874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/E8is72s0",
      "expanded_url" : "http:\/\/wp.me\/p4vkk-2tq",
      "display_url" : "wp.me\/p4vkk-2tq"
    } ]
  },
  "geo" : { },
  "id_str" : "205696530265538562",
  "text" : "Great story! RT @berkun: Read @benhuh's wild story of jumping from Corona Arch http:\/\/t.co\/E8is72s0 \/via @tbtty",
  "id" : 205696530265538562,
  "created_at" : "2012-05-24 16:27:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Meyers",
      "screen_name" : "jeremymeyers",
      "indices" : [ 0, 13 ],
      "id_str" : "16818880",
      "id" : 16818880
    }, {
      "name" : "Jonathan Fields",
      "screen_name" : "jonathanfields",
      "indices" : [ 29, 44 ],
      "id_str" : "11752272",
      "id" : 11752272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205667905860407296",
  "geo" : { },
  "id_str" : "205668444274823168",
  "in_reply_to_user_id" : 16818880,
  "text" : "@jeremymeyers I haven't read @jonathanfields's book by the same name yet. Will check it out, thanks!",
  "id" : 205668444274823168,
  "in_reply_to_status_id" : 205667905860407296,
  "created_at" : "2012-05-24 14:35:52 +0000",
  "in_reply_to_screen_name" : "jeremymeyers",
  "in_reply_to_user_id_str" : "16818880",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 3, 15 ],
      "id_str" : "9207632",
      "id" : 9207632
    }, {
      "name" : "wendy macnaughton",
      "screen_name" : "wendymac",
      "indices" : [ 68, 77 ],
      "id_str" : "8412262",
      "id" : 8412262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/GzSR9Iw1",
      "expanded_url" : "http:\/\/j.mp\/KGp6ea",
      "display_url" : "j.mp\/KGp6ea"
    } ]
  },
  "geo" : { },
  "id_str" : "205666988155092992",
  "text" : "RT @brainpicker: New favorite Tumblr: Pen &amp; Ink \u2013\u00A0the brilliant @wendymac illustrates people's unusual tattoo stories http:\/\/t.co\/Gz ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "wendy macnaughton",
        "screen_name" : "wendymac",
        "indices" : [ 51, 60 ],
        "id_str" : "8412262",
        "id" : 8412262
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/GzSR9Iw1",
        "expanded_url" : "http:\/\/j.mp\/KGp6ea",
        "display_url" : "j.mp\/KGp6ea"
      } ]
    },
    "geo" : { },
    "id_str" : "205659709791940608",
    "text" : "New favorite Tumblr: Pen &amp; Ink \u2013\u00A0the brilliant @wendymac illustrates people's unusual tattoo stories http:\/\/t.co\/GzSR9Iw1",
    "id" : 205659709791940608,
    "created_at" : "2012-05-24 14:01:10 +0000",
    "user" : {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "protected" : false,
      "id_str" : "9207632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/125575833\/twitter_normal.jpg",
      "id" : 9207632,
      "verified" : true
    }
  },
  "id" : 205666988155092992,
  "created_at" : "2012-05-24 14:30:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Carmichael",
      "screen_name" : "accarmichael",
      "indices" : [ 107, 120 ],
      "id_str" : "15916492",
      "id" : 15916492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/thA2xJ5u",
      "expanded_url" : "http:\/\/bit.ly\/Kdpymp",
      "display_url" : "bit.ly\/Kdpymp"
    } ]
  },
  "geo" : { },
  "id_str" : "205666689025716224",
  "text" : "Feynman on uncertainty (does not knowing answers to big questions frighten you?) http:\/\/t.co\/thA2xJ5u \/via @accarmichael",
  "id" : 205666689025716224,
  "created_at" : "2012-05-24 14:28:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trapper Markelz",
      "screen_name" : "trappermarkelz",
      "indices" : [ 0, 15 ],
      "id_str" : "1032241",
      "id" : 1032241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205644075356000257",
  "geo" : { },
  "id_str" : "205664348549558272",
  "in_reply_to_user_id" : 1032241,
  "text" : "@trappermarkelz Thank you. We had fun making it.",
  "id" : 205664348549558272,
  "in_reply_to_status_id" : 205644075356000257,
  "created_at" : "2012-05-24 14:19:36 +0000",
  "in_reply_to_screen_name" : "trappermarkelz",
  "in_reply_to_user_id_str" : "1032241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timehop",
      "screen_name" : "timehop",
      "indices" : [ 37, 45 ],
      "id_str" : "436143123",
      "id" : 436143123
    }, {
      "name" : "Timehop",
      "screen_name" : "timehop",
      "indices" : [ 85, 93 ],
      "id_str" : "436143123",
      "id" : 436143123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/2HruSLo5",
      "expanded_url" : "http:\/\/t.imehop.com\/JqtNbq",
      "display_url" : "t.imehop.com\/JqtNbq"
    } ]
  },
  "geo" : { },
  "id_str" : "205538339330334720",
  "text" : "I just hooked up my text messages to @Timehop! Add yours at http:\/\/t.co\/2HruSLo5 via @timehop",
  "id" : 205538339330334720,
  "created_at" : "2012-05-24 05:58:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/F6sJO1wv",
      "expanded_url" : "http:\/\/flic.kr\/p\/c4wVpE",
      "display_url" : "flic.kr\/p\/c4wVpE"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "205515864487899136",
  "text" : "8:36pm Gonna learn iPhone programming for the 2nd time http:\/\/t.co\/F6sJO1wv",
  "id" : 205515864487899136,
  "created_at" : "2012-05-24 04:29:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liene Verzemnieks",
      "screen_name" : "li3n3",
      "indices" : [ 0, 6 ],
      "id_str" : "498467901",
      "id" : 498467901
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hipsterhabitapp",
      "indices" : [ 33, 49 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205467447233486849",
  "geo" : { },
  "id_str" : "205483639931289600",
  "in_reply_to_user_id" : 498467901,
  "text" : "@li3n3 Can you Instagram it with #hipsterhabitapp?",
  "id" : 205483639931289600,
  "in_reply_to_status_id" : 205467447233486849,
  "created_at" : "2012-05-24 02:21:32 +0000",
  "in_reply_to_screen_name" : "li3n3",
  "in_reply_to_user_id_str" : "498467901",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hipsterhabitapp",
      "indices" : [ 7, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/g7Xy7FLl",
      "expanded_url" : "http:\/\/instagr.am\/p\/K_fHxHI0Ka\/",
      "display_url" : "instagr.am\/p\/K_fHxHI0Ka\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.609333038, -122.307502746 ]
  },
  "id_str" : "205479759768072193",
  "text" : "Poetic #hipsterhabitapp   @ Under a tree http:\/\/t.co\/g7Xy7FLl",
  "id" : 205479759768072193,
  "created_at" : "2012-05-24 02:06:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 11, 27 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205446537277489154",
  "geo" : { },
  "id_str" : "205446792781897730",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez @ameliagreenhall Thanks, we're definitely trying to!",
  "id" : 205446792781897730,
  "in_reply_to_status_id" : 205446537277489154,
  "created_at" : "2012-05-23 23:55:07 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liene Verzemnieks",
      "screen_name" : "li3n3",
      "indices" : [ 0, 6 ],
      "id_str" : "498467901",
      "id" : 498467901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205445401694846976",
  "geo" : { },
  "id_str" : "205446457644425216",
  "in_reply_to_user_id" : 498467901,
  "text" : "@li3n3 Did you notice the use of my Simple card as hipster prop? :)",
  "id" : 205446457644425216,
  "in_reply_to_status_id" : 205445401694846976,
  "created_at" : "2012-05-23 23:53:47 +0000",
  "in_reply_to_screen_name" : "li3n3",
  "in_reply_to_user_id_str" : "498467901",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Campbell",
      "screen_name" : "bitdepth",
      "indices" : [ 0, 9 ],
      "id_str" : "7680",
      "id" : 7680
    }, {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 10, 26 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205444370965598209",
  "geo" : { },
  "id_str" : "205446287108214785",
  "in_reply_to_user_id" : 7680,
  "text" : "@bitdepth @ameliagreenhall Ha! I'm gonna quote you on that in our blog post tomorrow if it's alright with you.",
  "id" : 205446287108214785,
  "in_reply_to_status_id" : 205444370965598209,
  "created_at" : "2012-05-23 23:53:06 +0000",
  "in_reply_to_screen_name" : "bitdepth",
  "in_reply_to_user_id_str" : "7680",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Park",
      "screen_name" : "charliepark",
      "indices" : [ 0, 12 ],
      "id_str" : "3225381",
      "id" : 3225381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205444640629997571",
  "geo" : { },
  "id_str" : "205446098880430081",
  "in_reply_to_user_id" : 3225381,
  "text" : "@charliepark Unfortunately, no sway. They're on their own timeline... I just got lucky to get in early.",
  "id" : 205446098880430081,
  "in_reply_to_status_id" : 205444640629997571,
  "created_at" : "2012-05-23 23:52:21 +0000",
  "in_reply_to_screen_name" : "charliepark",
  "in_reply_to_user_id_str" : "3225381",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205445192445202432",
  "geo" : { },
  "id_str" : "205445925588582401",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin Thank you! Send me a picture of it if you print it out and use it at all.",
  "id" : 205445925588582401,
  "in_reply_to_status_id" : 205445192445202432,
  "created_at" : "2012-05-23 23:51:40 +0000",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Park",
      "screen_name" : "charliepark",
      "indices" : [ 0, 12 ],
      "id_str" : "3225381",
      "id" : 3225381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205445260443271168",
  "geo" : { },
  "id_str" : "205445774316806144",
  "in_reply_to_user_id" : 3225381,
  "text" : "@charliepark It's just a fun side project. Will post some more about it tomorrow.",
  "id" : 205445774316806144,
  "in_reply_to_status_id" : 205445260443271168,
  "created_at" : "2012-05-23 23:51:04 +0000",
  "in_reply_to_screen_name" : "charliepark",
  "in_reply_to_user_id_str" : "3225381",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liene Verzemnieks",
      "screen_name" : "li3n3",
      "indices" : [ 0, 6 ],
      "id_str" : "498467901",
      "id" : 498467901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205445401694846976",
  "geo" : { },
  "id_str" : "205445618934628353",
  "in_reply_to_user_id" : 498467901,
  "text" : "@li3n3 It was fun to make! Print it out and take a picture of it and I'll add it to my blog post tomorrow...",
  "id" : 205445618934628353,
  "in_reply_to_status_id" : 205445401694846976,
  "created_at" : "2012-05-23 23:50:27 +0000",
  "in_reply_to_screen_name" : "li3n3",
  "in_reply_to_user_id_str" : "498467901",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    }, {
      "name" : "Simple",
      "screen_name" : "simplify",
      "indices" : [ 24, 33 ],
      "id_str" : "1247402083",
      "id" : 1247402083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205440921037316096",
  "geo" : { },
  "id_str" : "205441114239533057",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort Indeed it IS my @simplify card. Love it so far.",
  "id" : 205441114239533057,
  "in_reply_to_status_id" : 205440921037316096,
  "created_at" : "2012-05-23 23:32:33 +0000",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hipsterhabitapp",
      "indices" : [ 21, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/Wrhqq5ch",
      "expanded_url" : "http:\/\/hipsterhabitapp.com",
      "display_url" : "hipsterhabitapp.com"
    }, {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/G7dBxEhN",
      "expanded_url" : "http:\/\/instagr.am\/p\/K_NLUGI0Bc\/",
      "display_url" : "instagr.am\/p\/K_NLUGI0Bc\/"
    } ]
  },
  "geo" : { },
  "id_str" : "205440552777424897",
  "text" : "Sneak preview of the #hipsterhabitapp we're launching soon: http:\/\/t.co\/Wrhqq5ch  http:\/\/t.co\/G7dBxEhN",
  "id" : 205440552777424897,
  "created_at" : "2012-05-23 23:30:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radiolab",
      "screen_name" : "Radiolab",
      "indices" : [ 11, 20 ],
      "id_str" : "28583197",
      "id" : 28583197
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mantisshrimp",
      "indices" : [ 63, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/iyomKuwH",
      "expanded_url" : "http:\/\/www.radiolab.org\/2012\/may\/21\/",
      "display_url" : "radiolab.org\/2012\/may\/21\/"
    } ]
  },
  "geo" : { },
  "id_str" : "205417198062272512",
  "text" : "The latest @radiolab on color is amazing: http:\/\/t.co\/iyomKuwH #mantisshrimp",
  "id" : 205417198062272512,
  "created_at" : "2012-05-23 21:57:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 21, 33 ],
      "id_str" : "30801469",
      "id" : 30801469
    }, {
      "name" : "Harvard Biz Review",
      "screen_name" : "HarvardBiz",
      "indices" : [ 86, 97 ],
      "id_str" : "14800270",
      "id" : 14800270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/heMnDAeC",
      "expanded_url" : "http:\/\/bit.ly\/Kb5C3z",
      "display_url" : "bit.ly\/Kb5C3z"
    } ]
  },
  "geo" : { },
  "id_str" : "205372528523362304",
  "text" : "Great post, Nick! RT @nickcrocker: I wrote about exercise in life's margins today for @HarvardBiz - http:\/\/t.co\/heMnDAeC",
  "id" : 205372528523362304,
  "created_at" : "2012-05-23 19:00:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/pVjYeYVq",
      "expanded_url" : "http:\/\/flic.kr\/p\/c3Y4rf",
      "display_url" : "flic.kr\/p\/c3Y4rf"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.613666, -122.317 ]
  },
  "id_str" : "205142693821681665",
  "text" : "8:36pm Steak and asparagus and garlic mashed potatoes mmmmm http:\/\/t.co\/pVjYeYVq",
  "id" : 205142693821681665,
  "created_at" : "2012-05-23 03:46:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 31, 41 ],
      "id_str" : "798542",
      "id" : 798542
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 43, 56 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205119589644898304",
  "text" : "I should listen to the pro. RT @helenjane: @busterbenson Step 1: Theme Step 2: Group Puzzle Step 3: Specialty Cocktail Step 4: Snacks",
  "id" : 205119589644898304,
  "created_at" : "2012-05-23 02:14:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205117066284498946",
  "geo" : { },
  "id_str" : "205117398083321857",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane I need more specifics. What would HJ do???",
  "id" : 205117398083321857,
  "in_reply_to_status_id" : 205117066284498946,
  "created_at" : "2012-05-23 02:06:13 +0000",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205116634485100544",
  "geo" : { },
  "id_str" : "205117066229972992",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler The only qualitative difference between me and senior groups is that they're more proactive planners.",
  "id" : 205117066229972992,
  "in_reply_to_status_id" : 205116634485100544,
  "created_at" : "2012-05-23 02:04:54 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205116160721690624",
  "geo" : { },
  "id_str" : "205116374438256640",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley Only if you promise to get in a rowboat right now and start heading up.",
  "id" : 205116374438256640,
  "in_reply_to_status_id" : 205116160721690624,
  "created_at" : "2012-05-23 02:02:09 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205115715395661827",
  "geo" : { },
  "id_str" : "205116118636036096",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler Sounds like fun but maybe too ambitious for last minute on a holiday weekend.",
  "id" : 205116118636036096,
  "in_reply_to_status_id" : 205115715395661827,
  "created_at" : "2012-05-23 02:01:08 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205113769607700480",
  "text" : "How should I celebrate my birthday next Monday? I'm out of practice.",
  "id" : 205113769607700480,
  "created_at" : "2012-05-23 01:51:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maya Baratz",
      "screen_name" : "mbaratz",
      "indices" : [ 3, 11 ],
      "id_str" : "8847052",
      "id" : 8847052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205109388216762368",
  "text" : "RT @mbaratz: The most interesting startups are those that create something meaningful by converting potential energy into kinetic energy.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "205108659267710977",
    "text" : "The most interesting startups are those that create something meaningful by converting potential energy into kinetic energy.",
    "id" : 205108659267710977,
    "created_at" : "2012-05-23 01:31:29 +0000",
    "user" : {
      "name" : "Maya Baratz",
      "screen_name" : "mbaratz",
      "protected" : false,
      "id_str" : "8847052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3315118881\/f01bd5140d9864faaa90162d7ef904cb_normal.jpeg",
      "id" : 8847052,
      "verified" : true
    }
  },
  "id" : 205109388216762368,
  "created_at" : "2012-05-23 01:34:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeVore",
      "screen_name" : "crashdev",
      "indices" : [ 28, 37 ],
      "id_str" : "14763501",
      "id" : 14763501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/ZWJWcvry",
      "expanded_url" : "http:\/\/www.crashdev.com\/2012\/05\/money-power-culture-of-innovation.html",
      "display_url" : "crashdev.com\/2012\/05\/money-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "205105487212056576",
  "text" : "Thought-provoking post from @crashdev: Money, Power + the Culture of Innovation http:\/\/t.co\/ZWJWcvry",
  "id" : 205105487212056576,
  "created_at" : "2012-05-23 01:18:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205062901785051136",
  "text" : "Fill in the blank: I want to ____ every day for the rest of my life.\n\nMy answers: say I love you, take a picture at 8:36pm, do pushups.",
  "id" : 205062901785051136,
  "created_at" : "2012-05-22 22:29:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.branch.com\" rel=\"nofollow\"\u003EBranch Members\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 17, 33 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Branch",
      "screen_name" : "branchinc",
      "indices" : [ 52, 62 ],
      "id_str" : "704256716",
      "id" : 704256716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/NCYwac9p",
      "expanded_url" : "http:\/\/on.branch.com\/JQOlN4",
      "display_url" : "on.branch.com\/JQOlN4"
    } ]
  },
  "geo" : { },
  "id_str" : "205039914730012672",
  "text" : "Participating in @tonystubblebine's conversation on @branchinc about tiny habits:  http:\/\/t.co\/NCYwac9p",
  "id" : 205039914730012672,
  "created_at" : "2012-05-22 20:58:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204971571868205057",
  "text" : "Someone should create a Facebook game that lets you buy Facebook stock with Facebook credits. The circle would be complete.",
  "id" : 204971571868205057,
  "created_at" : "2012-05-22 16:26:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204964295715454976",
  "text" : "If my brain was a car, the gas pedal would be labelled NARRATE! and there would be no brake. Sometimes I just need to step off the gas.",
  "id" : 204964295715454976,
  "created_at" : "2012-05-22 15:57:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "indices" : [ 3, 14 ],
      "id_str" : "419710142",
      "id" : 419710142
    }, {
      "name" : "Nathaniel Mott",
      "screen_name" : "nathanielmott",
      "indices" : [ 80, 94 ],
      "id_str" : "266749531",
      "id" : 266749531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/CDe1LPO3",
      "expanded_url" : "http:\/\/pandodaily.com\/2012\/05\/21\/fitness-tech-needs-to-pick-up-the-pace\/",
      "display_url" : "pandodaily.com\/2012\/05\/21\/fit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "204822411768639489",
  "text" : "RT @PandoDaily: Fitness Tech Needs to Pick Up the Pace http:\/\/t.co\/CDe1LPO3 via @nathanielmott",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nathaniel Mott",
        "screen_name" : "nathanielmott",
        "indices" : [ 64, 78 ],
        "id_str" : "266749531",
        "id" : 266749531
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/CDe1LPO3",
        "expanded_url" : "http:\/\/pandodaily.com\/2012\/05\/21\/fitness-tech-needs-to-pick-up-the-pace\/",
        "display_url" : "pandodaily.com\/2012\/05\/21\/fit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "204789400293474304",
    "text" : "Fitness Tech Needs to Pick Up the Pace http:\/\/t.co\/CDe1LPO3 via @nathanielmott",
    "id" : 204789400293474304,
    "created_at" : "2012-05-22 04:22:52 +0000",
    "user" : {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "protected" : false,
      "id_str" : "419710142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1764819620\/Pando_Twitter_Logo_normal.jpg",
      "id" : 419710142,
      "verified" : false
    }
  },
  "id" : 204822411768639489,
  "created_at" : "2012-05-22 06:34:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204805259745431554",
  "geo" : { },
  "id_str" : "204806761964773376",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort At least pass it on in case you've thought of something that I haven't resisted building yet!",
  "id" : 204806761964773376,
  "in_reply_to_status_id" : 204805259745431554,
  "created_at" : "2012-05-22 05:31:51 +0000",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/b9Pz2l5s",
      "expanded_url" : "http:\/\/flic.kr\/p\/c3n9MW",
      "display_url" : "flic.kr\/p\/c3n9MW"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306 ]
  },
  "id_str" : "204780830688681984",
  "text" : "8:36pm Niko can identify 6\/12 trains by name now. More than I could 6 mo ago too http:\/\/t.co\/b9Pz2l5s",
  "id" : 204780830688681984,
  "created_at" : "2012-05-22 03:48:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 0, 6 ],
      "id_str" : "5469512",
      "id" : 5469512
    }, {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 7, 15 ],
      "id_str" : "9395832",
      "id" : 9395832
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 16, 25 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204766821688160257",
  "geo" : { },
  "id_str" : "204768359114485760",
  "in_reply_to_user_id" : 5469512,
  "text" : "@micah @dcurtis @arainert Just applied!",
  "id" : 204768359114485760,
  "in_reply_to_status_id" : 204766821688160257,
  "created_at" : "2012-05-22 02:59:15 +0000",
  "in_reply_to_screen_name" : "micah",
  "in_reply_to_user_id_str" : "5469512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 84, 93 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 94, 100 ],
      "id_str" : "5469512",
      "id" : 5469512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/SpjD8U0J",
      "expanded_url" : "http:\/\/svbtle.com",
      "display_url" : "svbtle.com"
    } ]
  },
  "geo" : { },
  "id_str" : "204766236133957632",
  "text" : "What does a guy need to do to get accepted as a writer on http:\/\/t.co\/SpjD8U0J? \/cc @arainert @micah",
  "id" : 204766236133957632,
  "created_at" : "2012-05-22 02:50:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 3, 9 ],
      "id_str" : "5469512",
      "id" : 5469512
    }, {
      "name" : "Paul Carr",
      "screen_name" : "paulcarr",
      "indices" : [ 84, 93 ],
      "id_str" : "277245800",
      "id" : 277245800
    }, {
      "name" : "benhuh",
      "screen_name" : "benhuh",
      "indices" : [ 94, 101 ],
      "id_str" : "14112294",
      "id" : 14112294
    }, {
      "name" : "Francisco Dao",
      "screen_name" : "TheMan",
      "indices" : [ 102, 109 ],
      "id_str" : "15388795",
      "id" : 15388795
    }, {
      "name" : "Sarah Lacy",
      "screen_name" : "sarahcuda",
      "indices" : [ 110, 120 ],
      "id_str" : "5668942",
      "id" : 5668942
    }, {
      "name" : "john frankel",
      "screen_name" : "john_frankel",
      "indices" : [ 121, 134 ],
      "id_str" : "30322151",
      "id" : 30322151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "50kings",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/kCJvzp6H",
      "expanded_url" : "http:\/\/hac.im\/Jivrfc",
      "display_url" : "hac.im\/Jivrfc"
    } ]
  },
  "geo" : { },
  "id_str" : "204759167167242240",
  "text" : "RT @micah: What if doing nothing helped you do everything? http:\/\/t.co\/kCJvzp6H cc: @paulcarr @benhuh @theman @sarahcuda @john_frankel # ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Carr",
        "screen_name" : "paulcarr",
        "indices" : [ 73, 82 ],
        "id_str" : "277245800",
        "id" : 277245800
      }, {
        "name" : "benhuh",
        "screen_name" : "benhuh",
        "indices" : [ 83, 90 ],
        "id_str" : "14112294",
        "id" : 14112294
      }, {
        "name" : "Francisco Dao",
        "screen_name" : "TheMan",
        "indices" : [ 91, 98 ],
        "id_str" : "15388795",
        "id" : 15388795
      }, {
        "name" : "Sarah Lacy",
        "screen_name" : "sarahcuda",
        "indices" : [ 99, 109 ],
        "id_str" : "5668942",
        "id" : 5668942
      }, {
        "name" : "john frankel",
        "screen_name" : "john_frankel",
        "indices" : [ 110, 123 ],
        "id_str" : "30322151",
        "id" : 30322151
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "50kings",
        "indices" : [ 124, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/kCJvzp6H",
        "expanded_url" : "http:\/\/hac.im\/Jivrfc",
        "display_url" : "hac.im\/Jivrfc"
      } ]
    },
    "geo" : { },
    "id_str" : "204747974629261312",
    "text" : "What if doing nothing helped you do everything? http:\/\/t.co\/kCJvzp6H cc: @paulcarr @benhuh @theman @sarahcuda @john_frankel #50kings",
    "id" : 204747974629261312,
    "created_at" : "2012-05-22 01:38:15 +0000",
    "user" : {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "protected" : false,
      "id_str" : "5469512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3448729200\/40bc6203b785a621ca0ba4f39570bbc8_normal.jpeg",
      "id" : 5469512,
      "verified" : false
    }
  },
  "id" : 204759167167242240,
  "created_at" : "2012-05-22 02:22:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 0, 6 ],
      "id_str" : "5469512",
      "id" : 5469512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204747974629261312",
  "geo" : { },
  "id_str" : "204759138398502912",
  "in_reply_to_user_id" : 5469512,
  "text" : "@micah Great post there.",
  "id" : 204759138398502912,
  "in_reply_to_status_id" : 204747974629261312,
  "created_at" : "2012-05-22 02:22:37 +0000",
  "in_reply_to_screen_name" : "micah",
  "in_reply_to_user_id_str" : "5469512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 20, 30 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/VGCjX2fX",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayLu-jg-",
      "display_url" : "tmblr.co\/ZQJvayLu-jg-"
    } ]
  },
  "geo" : { },
  "id_str" : "204704705132236800",
  "text" : "Tiny interview with @the_april about her 10+ year habit of taking vitamins when she wakes up: http:\/\/t.co\/VGCjX2fX",
  "id" : 204704705132236800,
  "created_at" : "2012-05-21 22:46:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204663502047154177",
  "geo" : { },
  "id_str" : "204664070228545537",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine I would love to see you carry the torch forward.",
  "id" : 204664070228545537,
  "in_reply_to_status_id" : 204663502047154177,
  "created_at" : "2012-05-21 20:04:51 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204663502047154177",
  "geo" : { },
  "id_str" : "204663892952100864",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine I'll let you know next time I'm down. Was just talking about how dated 43things feels these days.",
  "id" : 204663892952100864,
  "in_reply_to_status_id" : 204663502047154177,
  "created_at" : "2012-05-21 20:04:09 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204662612485603328",
  "geo" : { },
  "id_str" : "204663065680154624",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine Let me know if I can help at all.",
  "id" : 204663065680154624,
  "in_reply_to_status_id" : 204662612485603328,
  "created_at" : "2012-05-21 20:00:51 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 24, 40 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/IjdjHX0E",
      "expanded_url" : "http:\/\/blog.lift.do\/post\/23197749727\/experiments-in-human-potential",
      "display_url" : "blog.lift.do\/post\/231977497\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "204640607677853696",
  "text" : "Excited to see what the @tonystubblebine and Lift.do are working on. Their blog just launched here: http:\/\/t.co\/IjdjHX0E",
  "id" : 204640607677853696,
  "created_at" : "2012-05-21 18:31:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 36, 45 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 52, 59 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tcdiscript",
      "indices" : [ 63, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204636850726510592",
  "text" : "Smartest guy on stage right now! RT @RickWebb: Yeah @harryh at #tcdiscript!",
  "id" : 204636850726510592,
  "created_at" : "2012-05-21 18:16:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    }, {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 97, 108 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204628350101241856",
  "geo" : { },
  "id_str" : "204628805837520896",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten I'm pretty sure it's happening on 6\/11. I'm waiting for a new Macbook Pro too. \/cc @matthickey",
  "id" : 204628805837520896,
  "in_reply_to_status_id" : 204628350101241856,
  "created_at" : "2012-05-21 17:44:43 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204614251527147520",
  "geo" : { },
  "id_str" : "204628355042131969",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel What's your trick for sticking to it? What do you eat?",
  "id" : 204628355042131969,
  "in_reply_to_status_id" : 204614251527147520,
  "created_at" : "2012-05-21 17:42:56 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RescueTime",
      "screen_name" : "rescuetime",
      "indices" : [ 85, 96 ],
      "id_str" : "10803182",
      "id" : 10803182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/WgFmVJbc",
      "expanded_url" : "http:\/\/bustr.me\/post\/23488000653\/calculated-by-rescuetime-details-here",
      "display_url" : "bustr.me\/post\/234880006\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "204627805441507329",
  "text" : "22% of my time was devoted to email in the last 2 week. Some pretty email stats from @rescuetime: http:\/\/t.co\/WgFmVJbc",
  "id" : 204627805441507329,
  "created_at" : "2012-05-21 17:40:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 65, 73 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/3XYGGsmC",
      "expanded_url" : "http:\/\/bustr.me\/post\/23486756587\/via-malfunctions-in-the-hype-machine-indexed",
      "display_url" : "bustr.me\/post\/234867565\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "204622297900916736",
  "text" : "I first learned about this expected vs actual rating system from @rdicker. It works amazingly well. http:\/\/t.co\/3XYGGsmC",
  "id" : 204622297900916736,
  "created_at" : "2012-05-21 17:18:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suzi Steffen",
      "screen_name" : "SuziSteffen",
      "indices" : [ 0, 12 ],
      "id_str" : "16499655",
      "id" : 16499655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204603833614213120",
  "geo" : { },
  "id_str" : "204607536274485248",
  "in_reply_to_user_id" : 16499655,
  "text" : "@SuziSteffen Sounds like a great story. Let me know if you're interested in a short interview!",
  "id" : 204607536274485248,
  "in_reply_to_status_id" : 204603833614213120,
  "created_at" : "2012-05-21 16:20:12 +0000",
  "in_reply_to_screen_name" : "SuziSteffen",
  "in_reply_to_user_id_str" : "16499655",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Swizec",
      "screen_name" : "Swizec",
      "indices" : [ 0, 7 ],
      "id_str" : "15353121",
      "id" : 15353121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204603479912755200",
  "geo" : { },
  "id_str" : "204603607390240769",
  "in_reply_to_user_id" : 15353121,
  "text" : "@Swizec Can I ask you a few questions via email? Email me at busterbenson at gmail if interested.",
  "id" : 204603607390240769,
  "in_reply_to_status_id" : 204603479912755200,
  "created_at" : "2012-05-21 16:04:36 +0000",
  "in_reply_to_screen_name" : "Swizec",
  "in_reply_to_user_id_str" : "15353121",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suzi Steffen",
      "screen_name" : "SuziSteffen",
      "indices" : [ 0, 12 ],
      "id_str" : "16499655",
      "id" : 16499655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204603227990278144",
  "geo" : { },
  "id_str" : "204603436459769857",
  "in_reply_to_user_id" : 16499655,
  "text" : "@SuziSteffen That's really cool! Can I do a quick interview with you? Email me at busterbenson at gmail if interested.",
  "id" : 204603436459769857,
  "in_reply_to_status_id" : 204603227990278144,
  "created_at" : "2012-05-21 16:03:55 +0000",
  "in_reply_to_screen_name" : "SuziSteffen",
  "in_reply_to_user_id_str" : "16499655",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Calvin Spealman",
      "screen_name" : "ironfroggy",
      "indices" : [ 0, 11 ],
      "id_str" : "5622042",
      "id" : 5622042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204602535842029569",
  "geo" : { },
  "id_str" : "204603062977966080",
  "in_reply_to_user_id" : 5622042,
  "text" : "@ironfroggy I think a lot of people feel that way. Streaks are motivating while going, and really demotivating when they end.",
  "id" : 204603062977966080,
  "in_reply_to_status_id" : 204602535842029569,
  "created_at" : "2012-05-21 16:02:26 +0000",
  "in_reply_to_screen_name" : "ironfroggy",
  "in_reply_to_user_id_str" : "5622042",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Parkes",
      "screen_name" : "harryparkes",
      "indices" : [ 0, 12 ],
      "id_str" : "114013",
      "id" : 114013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204601202426646530",
  "geo" : { },
  "id_str" : "204602502069501952",
  "in_reply_to_user_id" : 114013,
  "text" : "@harryparkes How long have you been drinking coffee?  What time(s) of day do you drink it?",
  "id" : 204602502069501952,
  "in_reply_to_status_id" : 204601202426646530,
  "created_at" : "2012-05-21 16:00:12 +0000",
  "in_reply_to_screen_name" : "harryparkes",
  "in_reply_to_user_id_str" : "114013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suzi Steffen",
      "screen_name" : "SuziSteffen",
      "indices" : [ 0, 12 ],
      "id_str" : "16499655",
      "id" : 16499655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204601025242472448",
  "geo" : { },
  "id_str" : "204602412634357761",
  "in_reply_to_user_id" : 16499655,
  "text" : "@SuziSteffen Is that a bike?  What's your daily routine?",
  "id" : 204602412634357761,
  "in_reply_to_status_id" : 204601025242472448,
  "created_at" : "2012-05-21 15:59:51 +0000",
  "in_reply_to_screen_name" : "SuziSteffen",
  "in_reply_to_user_id_str" : "16499655",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Calvin Spealman",
      "screen_name" : "ironfroggy",
      "indices" : [ 0, 11 ],
      "id_str" : "5622042",
      "id" : 5622042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204600700951470081",
  "geo" : { },
  "id_str" : "204602253758308352",
  "in_reply_to_user_id" : 5622042,
  "text" : "@ironfroggy Though, I think I want to really dig in to find out what makes a habit last a year.",
  "id" : 204602253758308352,
  "in_reply_to_status_id" : 204600700951470081,
  "created_at" : "2012-05-21 15:59:13 +0000",
  "in_reply_to_screen_name" : "ironfroggy",
  "in_reply_to_user_id_str" : "5622042",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Calvin Spealman",
      "screen_name" : "ironfroggy",
      "indices" : [ 0, 11 ],
      "id_str" : "5622042",
      "id" : 5622042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204600700951470081",
  "geo" : { },
  "id_str" : "204602137802571777",
  "in_reply_to_user_id" : 5622042,
  "text" : "@ironfroggy Don't be too hard on yourself. Other than brushing teeth, I don't think many people have a habit that qualifies.",
  "id" : 204602137802571777,
  "in_reply_to_status_id" : 204600700951470081,
  "created_at" : "2012-05-21 15:58:45 +0000",
  "in_reply_to_screen_name" : "ironfroggy",
  "in_reply_to_user_id_str" : "5622042",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204601531914403840",
  "geo" : { },
  "id_str" : "204601659719032832",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Yes! But I'm particularly interested in habits started in the last 5 years that have lasted longer than 1 year.",
  "id" : 204601659719032832,
  "in_reply_to_status_id" : 204601531914403840,
  "created_at" : "2012-05-21 15:56:51 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Swizec",
      "screen_name" : "Swizec",
      "indices" : [ 0, 7 ],
      "id_str" : "15353121",
      "id" : 15353121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204601360698716160",
  "geo" : { },
  "id_str" : "204601536763006978",
  "in_reply_to_user_id" : 15353121,
  "text" : "@Swizec What kind of exercise?",
  "id" : 204601536763006978,
  "in_reply_to_status_id" : 204601360698716160,
  "created_at" : "2012-05-21 15:56:22 +0000",
  "in_reply_to_screen_name" : "Swizec",
  "in_reply_to_user_id_str" : "15353121",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204600523549179905",
  "text" : "Do you have a really solid habit that you've been doing daily for longer than a year?",
  "id" : 204600523549179905,
  "created_at" : "2012-05-21 15:52:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204479439818592257",
  "text" : "Facebook needs to add a Like Button to my emails. That would probably cut my email writing down by 50% at least.",
  "id" : 204479439818592257,
  "created_at" : "2012-05-21 07:51:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Howard",
      "screen_name" : "tomhoward",
      "indices" : [ 0, 10 ],
      "id_str" : "14900275",
      "id" : 14900275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204457893859311616",
  "in_reply_to_user_id" : 14900275,
  "text" : "@tomhoward Loving\/relating to your recent set of blog posts. I can relate to a lot of it. Keep it up.",
  "id" : 204457893859311616,
  "created_at" : "2012-05-21 06:25:35 +0000",
  "in_reply_to_screen_name" : "tomhoward",
  "in_reply_to_user_id_str" : "14900275",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204448489822883840",
  "geo" : { },
  "id_str" : "204448697671622656",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg Where do find fresh green juice? Maybe Whole Foods?",
  "id" : 204448697671622656,
  "in_reply_to_status_id" : 204448489822883840,
  "created_at" : "2012-05-21 05:49:02 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204442399647334400",
  "geo" : { },
  "id_str" : "204448014943780867",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg Yeah I'm guessing it's a bit more expensive in NYC than in Seattle. Though, just getting a good juicer is prohibitive for many.",
  "id" : 204448014943780867,
  "in_reply_to_status_id" : 204442399647334400,
  "created_at" : "2012-05-21 05:46:19 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204416876921630721",
  "geo" : { },
  "id_str" : "204441929742684162",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg How often do you drink it? How has it been?",
  "id" : 204441929742684162,
  "in_reply_to_status_id" : 204416876921630721,
  "created_at" : "2012-05-21 05:22:09 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/QerFUSV1",
      "expanded_url" : "http:\/\/instagr.am\/p\/K3_Peko0IM\/",
      "display_url" : "instagr.am\/p\/K3_Peko0IM\/"
    } ]
  },
  "geo" : { },
  "id_str" : "204424602410160128",
  "text" : "8:36pm Lots of triple train rainbow today since it was raining http:\/\/t.co\/QerFUSV1",
  "id" : 204424602410160128,
  "created_at" : "2012-05-21 04:13:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204360642583461889",
  "geo" : { },
  "id_str" : "204382329651740675",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker What does that mean exactly?",
  "id" : 204382329651740675,
  "in_reply_to_status_id" : 204360642583461889,
  "created_at" : "2012-05-21 01:25:19 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204360644772900865",
  "geo" : { },
  "id_str" : "204381918228262913",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten I liked it too. It's just great seeing people make big changes for the better. We should celebrate that more often.",
  "id" : 204381918228262913,
  "in_reply_to_status_id" : 204360644772900865,
  "created_at" : "2012-05-21 01:23:41 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xeni Jardin",
      "screen_name" : "xeni",
      "indices" : [ 3, 8 ],
      "id_str" : "767",
      "id" : 767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204368024386551809",
  "text" : "RT @xeni: Obit writers: cancer isn't a \"battle.\" Cancer is a disease. It's just cancer. It doesn't require use of military metaphor ever ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "204345024266256384",
    "text" : "Obit writers: cancer isn't a \"battle.\" Cancer is a disease. It's just cancer. It doesn't require use of military metaphor every single time.",
    "id" : 204345024266256384,
    "created_at" : "2012-05-20 22:57:04 +0000",
    "user" : {
      "name" : "Xeni Jardin",
      "screen_name" : "xeni",
      "protected" : false,
      "id_str" : "767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461599487866044416\/b-84ZSil_normal.jpeg",
      "id" : 767,
      "verified" : true
    }
  },
  "id" : 204368024386551809,
  "created_at" : "2012-05-21 00:28:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204359765701304320",
  "geo" : { },
  "id_str" : "204364025700691968",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin I think it requires a certain level of desperation. People generally ignore that factor.",
  "id" : 204364025700691968,
  "in_reply_to_status_id" : 204359765701304320,
  "created_at" : "2012-05-21 00:12:35 +0000",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suhail Dutta",
      "screen_name" : "suhaildutta",
      "indices" : [ 41, 53 ],
      "id_str" : "232186980",
      "id" : 232186980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204355298209697792",
  "text" : "Watching \"Fat, Sick, and Nearly Dead\" on @suhaildutta's recommendation. 60-day juice fast entertaining so far. Who's seen it?",
  "id" : 204355298209697792,
  "created_at" : "2012-05-20 23:37:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravi Raman",
      "screen_name" : "YogiRavi",
      "indices" : [ 119, 128 ],
      "id_str" : "17466187",
      "id" : 17466187
    }, {
      "name" : "Mike Torres",
      "screen_name" : "Refocuser",
      "indices" : [ 134, 144 ],
      "id_str" : "21437000",
      "id" : 21437000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/klPB88C6",
      "expanded_url" : "http:\/\/sethigherstandards.com\/2012\/04\/21\/one-powerful-technique-for-improving-your-diet-and-health\/",
      "display_url" : "sethigherstandards.com\/2012\/04\/21\/one\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "204335689330999296",
  "text" : "To change your diet, add lots of good stuff &amp; don't worry about getting rid of bad stuff: http:\/\/t.co\/klPB88C6 \/by @yogiravi \/via @refocuser",
  "id" : 204335689330999296,
  "created_at" : "2012-05-20 22:19:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Savage",
      "screen_name" : "fakedansavage",
      "indices" : [ 3, 17 ],
      "id_str" : "313091751",
      "id" : 313091751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204333679663788032",
  "text" : "RT @fakedansavage: I'm totally willing to tolerate people who don't think that I should be married... so long as they're willing to tole ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "204331576060940289",
    "text" : "I'm totally willing to tolerate people who don't think that I should be married... so long as they're willing to tolerate my marriage.",
    "id" : 204331576060940289,
    "created_at" : "2012-05-20 22:03:38 +0000",
    "user" : {
      "name" : "Dan Savage",
      "screen_name" : "fakedansavage",
      "protected" : false,
      "id_str" : "313091751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465218690334474240\/kQsa_tL7_normal.jpeg",
      "id" : 313091751,
      "verified" : true
    }
  },
  "id" : 204333679663788032,
  "created_at" : "2012-05-20 22:12:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Habit List",
      "screen_name" : "HabitList",
      "indices" : [ 93, 103 ],
      "id_str" : "435126466",
      "id" : 435126466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/urN0hM8k",
      "expanded_url" : "http:\/\/habitlistapp.com\/",
      "display_url" : "habitlistapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "204330545629511680",
  "text" : "Nicely done simple iPhone app to track and remind you about habits: http:\/\/t.co\/urN0hM8k \/cc @habitlist",
  "id" : 204330545629511680,
  "created_at" : "2012-05-20 21:59:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 0, 11 ],
      "id_str" : "14620776",
      "id" : 14620776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204279158430375937",
  "geo" : { },
  "id_str" : "204280483092250624",
  "in_reply_to_user_id" : 14620776,
  "text" : "@ellenchisa Sure! Can you send me some more info or a screenshot?",
  "id" : 204280483092250624,
  "in_reply_to_status_id" : 204279158430375937,
  "created_at" : "2012-05-20 18:40:37 +0000",
  "in_reply_to_screen_name" : "ellenchisa",
  "in_reply_to_user_id_str" : "14620776",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/EyzCuRfa",
      "expanded_url" : "http:\/\/instagr.am\/p\/K1WjAYo0Gn\/",
      "display_url" : "instagr.am\/p\/K1WjAYo0Gn\/"
    } ]
  },
  "geo" : { },
  "id_str" : "204053548827291648",
  "text" : "8:36pm Bathing this dude http:\/\/t.co\/EyzCuRfa",
  "id" : 204053548827291648,
  "created_at" : "2012-05-20 03:38:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Dorsey",
      "screen_name" : "jack",
      "indices" : [ 3, 8 ],
      "id_str" : "12",
      "id" : 12
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jack\/status\/204033310329016320\/photo\/1",
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/3IXASh55",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtTfNvjCEAAB0vL.jpg",
      "id_str" : "204033310333210624",
      "id" : 204033310333210624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtTfNvjCEAAB0vL.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/3IXASh55"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204033704450985987",
  "text" : "RT @jack: Congratulations to Mark and Priscilla! http:\/\/t.co\/3IXASh55",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jack\/status\/204033310329016320\/photo\/1",
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/3IXASh55",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AtTfNvjCEAAB0vL.jpg",
        "id_str" : "204033310333210624",
        "id" : 204033310333210624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtTfNvjCEAAB0vL.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/3IXASh55"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "204033310329016320",
    "text" : "Congratulations to Mark and Priscilla! http:\/\/t.co\/3IXASh55",
    "id" : 204033310329016320,
    "created_at" : "2012-05-20 02:18:27 +0000",
    "user" : {
      "name" : "Jack Dorsey",
      "screen_name" : "jack",
      "protected" : false,
      "id_str" : "12",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448483168580947968\/pL4ejHy4_normal.jpeg",
      "id" : 12,
      "verified" : true
    }
  },
  "id" : 204033704450985987,
  "created_at" : "2012-05-20 02:20:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204024939290951680",
  "geo" : { },
  "id_str" : "204025793830072322",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar Yes! Let's get a dink next week!",
  "id" : 204025793830072322,
  "in_reply_to_status_id" : 204024939290951680,
  "created_at" : "2012-05-20 01:48:34 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stepa Mitaki",
      "screen_name" : "stepamitaki",
      "indices" : [ 0, 12 ],
      "id_str" : "16654164",
      "id" : 16654164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204017632515588096",
  "geo" : { },
  "id_str" : "204018685961183233",
  "in_reply_to_user_id" : 16654164,
  "text" : "@stepamitaki I might have to give it a try.",
  "id" : 204018685961183233,
  "in_reply_to_status_id" : 204017632515588096,
  "created_at" : "2012-05-20 01:20:19 +0000",
  "in_reply_to_screen_name" : "stepamitaki",
  "in_reply_to_user_id_str" : "16654164",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stepa Mitaki",
      "screen_name" : "stepamitaki",
      "indices" : [ 0, 12 ],
      "id_str" : "16654164",
      "id" : 16654164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204014373109370881",
  "geo" : { },
  "id_str" : "204015798661033985",
  "in_reply_to_user_id" : 16654164,
  "text" : "@stepamitaki Now I'm curious. Can I do $1?",
  "id" : 204015798661033985,
  "in_reply_to_status_id" : 204014373109370881,
  "created_at" : "2012-05-20 01:08:51 +0000",
  "in_reply_to_screen_name" : "stepamitaki",
  "in_reply_to_user_id_str" : "16654164",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 24, 36 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204013152516587520",
  "text" : "Someday, I want to do a @kickstarter project. Is there a minimum funding amount? Could I do a $100 dollar project?",
  "id" : 204013152516587520,
  "created_at" : "2012-05-20 00:58:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/TXBvEvCo",
      "expanded_url" : "http:\/\/www.readwriteweb.com\/hack\/2012\/05\/computer-programming-for-all-a-new-standard-of-literacy.php",
      "display_url" : "readwriteweb.com\/hack\/2012\/05\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203976207161761793",
  "text" : "\"What if we were to expand our notion of literacy to encompass not only human languages but also machine languages?\" http:\/\/t.co\/TXBvEvCo",
  "id" : 203976207161761793,
  "created_at" : "2012-05-19 22:31:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quazie",
      "screen_name" : "Quazie",
      "indices" : [ 0, 7 ],
      "id_str" : "7389212",
      "id" : 7389212
    }, {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 28, 39 ],
      "id_str" : "14620776",
      "id" : 14620776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/TYrHECmm",
      "expanded_url" : "http:\/\/highcharts.com",
      "display_url" : "highcharts.com"
    }, {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/G3DyQR4h",
      "expanded_url" : "http:\/\/d3js.org",
      "display_url" : "d3js.org"
    } ]
  },
  "in_reply_to_status_id_str" : "203918553387245568",
  "geo" : { },
  "id_str" : "203933793030111233",
  "in_reply_to_user_id" : 7389212,
  "text" : "@Quazie I mentioned this to @ellenchisa too but I use http:\/\/t.co\/TYrHECmm + http:\/\/t.co\/G3DyQR4h. Stoked that you're doing stuff like this!",
  "id" : 203933793030111233,
  "in_reply_to_status_id" : 203918553387245568,
  "created_at" : "2012-05-19 19:42:59 +0000",
  "in_reply_to_screen_name" : "Quazie",
  "in_reply_to_user_id_str" : "7389212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openpaths",
      "screen_name" : "openpathscc",
      "indices" : [ 0, 12 ],
      "id_str" : "287446892",
      "id" : 287446892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203931217098313729",
  "in_reply_to_user_id" : 287446892,
  "text" : "@openpathscc Do you have any sample code for integrating with the API in ruby?",
  "id" : 203931217098313729,
  "created_at" : "2012-05-19 19:32:45 +0000",
  "in_reply_to_screen_name" : "openpathscc",
  "in_reply_to_user_id_str" : "287446892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "news.yc Popular",
      "screen_name" : "newsycombinator",
      "indices" : [ 40, 56 ],
      "id_str" : "14335498",
      "id" : 14335498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/dsIrpxnZ",
      "expanded_url" : "http:\/\/bit.ly\/JG5fOx",
      "display_url" : "bit.ly\/JG5fOx"
    } ]
  },
  "geo" : { },
  "id_str" : "203880675164684288",
  "text" : "Part 2 in our Tesla vs Edison lesson RT @newsycombinator: Nikola Tesla Wasn't God And Thomas Edison Wasn't The Devil http:\/\/t.co\/dsIrpxnZ",
  "id" : 203880675164684288,
  "created_at" : "2012-05-19 16:11:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hagel",
      "screen_name" : "jhagel",
      "indices" : [ 3, 10 ],
      "id_str" : "14076943",
      "id" : 14076943
    }, {
      "name" : "Hugh MacLeod",
      "screen_name" : "gapingvoid",
      "indices" : [ 71, 82 ],
      "id_str" : "50193",
      "id" : 50193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/BUrfF1WE",
      "expanded_url" : "http:\/\/bit.ly\/JqQCQ5",
      "display_url" : "bit.ly\/JqQCQ5"
    } ]
  },
  "geo" : { },
  "id_str" : "203850077943496704",
  "text" : "RT @jhagel: Empowerment requires narrative - powerful observation from @gapingvoid http:\/\/t.co\/BUrfF1WE",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hugh MacLeod",
        "screen_name" : "gapingvoid",
        "indices" : [ 59, 70 ],
        "id_str" : "50193",
        "id" : 50193
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/BUrfF1WE",
        "expanded_url" : "http:\/\/bit.ly\/JqQCQ5",
        "display_url" : "bit.ly\/JqQCQ5"
      } ]
    },
    "geo" : { },
    "id_str" : "203841450243395584",
    "text" : "Empowerment requires narrative - powerful observation from @gapingvoid http:\/\/t.co\/BUrfF1WE",
    "id" : 203841450243395584,
    "created_at" : "2012-05-19 13:36:03 +0000",
    "user" : {
      "name" : "John Hagel",
      "screen_name" : "jhagel",
      "protected" : false,
      "id_str" : "14076943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000843301492\/c0b254d79d675d95651989d948493e8d_normal.jpeg",
      "id" : 14076943,
      "verified" : false
    }
  },
  "id" : 203850077943496704,
  "created_at" : "2012-05-19 14:10:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Behance's 99U",
      "screen_name" : "the99percent",
      "indices" : [ 20, 33 ],
      "id_str" : "716292679",
      "id" : 716292679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/MbcVhb2T",
      "expanded_url" : "http:\/\/bit.ly\/J9tUYP",
      "display_url" : "bit.ly\/J9tUYP"
    } ]
  },
  "geo" : { },
  "id_str" : "203849859231522817",
  "text" : "Great interview! RT @the99percent: Stillpower: The True Path to Flow, Clarity, and Responsiveness: http:\/\/t.co\/MbcVhb2T",
  "id" : 203849859231522817,
  "created_at" : "2012-05-19 14:09:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/iOB7bUOq",
      "expanded_url" : "http:\/\/flic.kr\/p\/c1ufno",
      "display_url" : "flic.kr\/p\/c1ufno"
    } ]
  },
  "geo" : { },
  "id_str" : "203729385239478272",
  "text" : "8:36pm Stealagraming because I was passed out in Niko's room for the first half of book club http:\/\/t.co\/iOB7bUOq",
  "id" : 203729385239478272,
  "created_at" : "2012-05-19 06:10:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/qgRPTCJf",
      "expanded_url" : "http:\/\/path.com\/p\/20fwIb",
      "display_url" : "path.com\/p\/20fwIb"
    } ]
  },
  "geo" : { },
  "id_str" : "203687745699323904",
  "text" : "Me: Niko, what's my name? Niko: Dan. [vid] \u2014 http:\/\/t.co\/qgRPTCJf",
  "id" : 203687745699323904,
  "created_at" : "2012-05-19 03:25:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 3, 19 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/b9pYR6Vl",
      "expanded_url" : "http:\/\/instagr.am\/p\/KyuDdzLJ3R\/",
      "display_url" : "instagr.am\/p\/KyuDdzLJ3R\/"
    } ]
  },
  "geo" : { },
  "id_str" : "203683312777179136",
  "text" : "RT @ameliagreenhall: I am building my first rails app that is actually more than a static website.  http:\/\/t.co\/b9pYR6Vl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/b9pYR6Vl",
        "expanded_url" : "http:\/\/instagr.am\/p\/KyuDdzLJ3R\/",
        "display_url" : "instagr.am\/p\/KyuDdzLJ3R\/"
      } ]
    },
    "geo" : { },
    "id_str" : "203683117687513088",
    "text" : "I am building my first rails app that is actually more than a static website.  http:\/\/t.co\/b9pYR6Vl",
    "id" : 203683117687513088,
    "created_at" : "2012-05-19 03:06:54 +0000",
    "user" : {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "protected" : false,
      "id_str" : "246531241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446808446180937728\/GZ5tskw1_normal.jpeg",
      "id" : 246531241,
      "verified" : false
    }
  },
  "id" : 203683312777179136,
  "created_at" : "2012-05-19 03:07:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Hooper",
      "screen_name" : "toddhooper",
      "indices" : [ 3, 14 ],
      "id_str" : "14192958",
      "id" : 14192958
    }, {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 21, 31 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/Lix3Sgk2",
      "expanded_url" : "http:\/\/www.geekwire.com\/2012\/betting-retirement-facebook-stock-today\/",
      "display_url" : "geekwire.com\/2012\/betting-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203566437917401088",
  "text" : "RT @toddhooper: From @galenward Why I'm betting my retirement on Facebook stock today: http:\/\/t.co\/Lix3Sgk2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Galen Ward",
        "screen_name" : "galenward",
        "indices" : [ 5, 15 ],
        "id_str" : "2854761",
        "id" : 2854761
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/Lix3Sgk2",
        "expanded_url" : "http:\/\/www.geekwire.com\/2012\/betting-retirement-facebook-stock-today\/",
        "display_url" : "geekwire.com\/2012\/betting-r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "203564033939484672",
    "text" : "From @galenward Why I'm betting my retirement on Facebook stock today: http:\/\/t.co\/Lix3Sgk2",
    "id" : 203564033939484672,
    "created_at" : "2012-05-18 19:13:42 +0000",
    "user" : {
      "name" : "Todd Hooper",
      "screen_name" : "toddhooper",
      "protected" : false,
      "id_str" : "14192958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2361730812\/col42t6v0vyexir7jopq_normal.png",
      "id" : 14192958,
      "verified" : false
    }
  },
  "id" : 203566437917401088,
  "created_at" : "2012-05-18 19:23:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203549789047111680",
  "text" : "Every failure is a special snowflake worthy of appreciation.",
  "id" : 203549789047111680,
  "created_at" : "2012-05-18 18:17:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Sparrow",
      "screen_name" : "ANewBandADay",
      "indices" : [ 0, 13 ],
      "id_str" : "18171079",
      "id" : 18171079
    }, {
      "name" : "Anthony V.",
      "screen_name" : "fascinated",
      "indices" : [ 14, 25 ],
      "id_str" : "5803082",
      "id" : 5803082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203513773187796992",
  "geo" : { },
  "id_str" : "203513997272694784",
  "in_reply_to_user_id" : 18171079,
  "text" : "@ANewBandADay @fascinated Maybe a little bit. If there were real economics behind Klout score, yes.",
  "id" : 203513997272694784,
  "in_reply_to_status_id" : 203513773187796992,
  "created_at" : "2012-05-18 15:54:52 +0000",
  "in_reply_to_screen_name" : "ANewBandADay",
  "in_reply_to_user_id_str" : "18171079",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203512390967496704",
  "text" : "Imagine if your life's work was flattened into a number determined by how many people thought they could profit from you.",
  "id" : 203512390967496704,
  "created_at" : "2012-05-18 15:48:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bud.ge\" rel=\"nofollow\"\u003EBudge\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/HkYcdyJ4",
      "expanded_url" : "http:\/\/bud.ge\/n\/297h",
      "display_url" : "bud.ge\/n\/297h"
    } ]
  },
  "geo" : { },
  "id_str" : "203511201324466176",
  "text" : "My secret ingredient for the Pushup Animal program is my 7:30am alarm (still works!) http:\/\/t.co\/HkYcdyJ4",
  "id" : 203511201324466176,
  "created_at" : "2012-05-18 15:43:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203508765855727616",
  "text" : "Niko thinks I should change my name to Dan.",
  "id" : 203508765855727616,
  "created_at" : "2012-05-18 15:34:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dixon",
      "screen_name" : "cdixon",
      "indices" : [ 0, 7 ],
      "id_str" : "2529971",
      "id" : 2529971
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 8, 15 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Bryce Roberts",
      "screen_name" : "bryce",
      "indices" : [ 16, 22 ],
      "id_str" : "6160742",
      "id" : 6160742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203502792663502849",
  "geo" : { },
  "id_str" : "203503515212054529",
  "in_reply_to_user_id" : 2529971,
  "text" : "@cdixon @harryh @bryce Seems like a case of finding a pattern that is designed to fit the data (and refining it until it is a perfect fit).",
  "id" : 203503515212054529,
  "in_reply_to_status_id" : 203502792663502849,
  "created_at" : "2012-05-18 15:13:13 +0000",
  "in_reply_to_screen_name" : "cdixon",
  "in_reply_to_user_id_str" : "2529971",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 3, 14 ],
      "id_str" : "1586501",
      "id" : 1586501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203491004597280770",
  "text" : "RT @nickbilton: In an alternate universe, the Winklevii twinsies are ringing a NASDAQ bell right now.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "203490249538678784",
    "text" : "In an alternate universe, the Winklevii twinsies are ringing a NASDAQ bell right now.",
    "id" : 203490249538678784,
    "created_at" : "2012-05-18 14:20:30 +0000",
    "user" : {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "protected" : false,
      "id_str" : "1586501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453750282770341888\/SEwjZ2AI_normal.png",
      "id" : 1586501,
      "verified" : true
    }
  },
  "id" : 203491004597280770,
  "created_at" : "2012-05-18 14:23:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203364234048974848",
  "geo" : { },
  "id_str" : "203364706042384385",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb So then what are you going to do about your self-diagnosed attitude problem?",
  "id" : 203364706042384385,
  "in_reply_to_status_id" : 203364234048974848,
  "created_at" : "2012-05-18 06:01:38 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/8JJBzaPy",
      "expanded_url" : "http:\/\/flic.kr\/p\/bZXtp9",
      "display_url" : "flic.kr\/p\/bZXtp9"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "203330516651479042",
  "text" : "8:36pm Waiting for Kellianne to put Niko to sleep so we can watch the new New Girl http:\/\/t.co\/8JJBzaPy",
  "id" : 203330516651479042,
  "created_at" : "2012-05-18 03:45:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebookipodayclosingprice.com\" rel=\"nofollow\"\u003Efacebookipodayclosingprice.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/gUo9H51D",
      "expanded_url" : "http:\/\/www.facebookipodayclosingprice.com",
      "display_url" : "facebookipodayclosingprice.com"
    } ]
  },
  "geo" : { },
  "id_str" : "203263539148898304",
  "text" : "I predict $     148,285,357,909 as the Facebook IPO day closing valuation http:\/\/t.co\/gUo9H51D",
  "id" : 203263539148898304,
  "created_at" : "2012-05-17 23:19:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Peterson",
      "screen_name" : "JonSp",
      "indices" : [ 93, 99 ],
      "id_str" : "844454052",
      "id" : 844454052
    }, {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "indices" : [ 127, 136 ],
      "id_str" : "255784266",
      "id" : 255784266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/zef0gpWW",
      "expanded_url" : "http:\/\/www.geekwire.com\/2012\/open-letter-facebook-millionaires-pay-moms-mortgage\/",
      "display_url" : "geekwire.com\/2012\/open-lett\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203262601130541056",
  "text" : "A beautiful and wise open letter to the 1,000+ Facebook millionaires being born tomorrow, by @jonsp \nhttp:\/\/t.co\/zef0gpWW \/via @geekwire",
  "id" : 203262601130541056,
  "created_at" : "2012-05-17 23:15:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Gold",
      "screen_name" : "heathr",
      "indices" : [ 0, 7 ],
      "id_str" : "678033",
      "id" : 678033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203255389351976960",
  "geo" : { },
  "id_str" : "203255679534895104",
  "in_reply_to_user_id" : 678033,
  "text" : "@heathr Oops sorry. I can't do tonight but would do one in future if you still want me to!",
  "id" : 203255679534895104,
  "in_reply_to_status_id" : 203255389351976960,
  "created_at" : "2012-05-17 22:48:24 +0000",
  "in_reply_to_screen_name" : "heathr",
  "in_reply_to_user_id_str" : "678033",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tavis Rudd",
      "screen_name" : "tavisrudd",
      "indices" : [ 0, 10 ],
      "id_str" : "187354174",
      "id" : 187354174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/EJN3jAoe",
      "expanded_url" : "http:\/\/bit.ly\/IZMwu0",
      "display_url" : "bit.ly\/IZMwu0"
    } ]
  },
  "in_reply_to_status_id_str" : "203181751856668673",
  "geo" : { },
  "id_str" : "203210896699424768",
  "in_reply_to_user_id" : 187354174,
  "text" : "@tavisrudd Yes! I posted it to http:\/\/t.co\/EJN3jAoe (a few posts down).",
  "id" : 203210896699424768,
  "in_reply_to_status_id" : 203181751856668673,
  "created_at" : "2012-05-17 19:50:27 +0000",
  "in_reply_to_screen_name" : "tavisrudd",
  "in_reply_to_user_id_str" : "187354174",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hekler",
      "screen_name" : "ehekler",
      "indices" : [ 0, 8 ],
      "id_str" : "136385823",
      "id" : 136385823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203159391334174724",
  "geo" : { },
  "id_str" : "203160195059302400",
  "in_reply_to_user_id" : 136385823,
  "text" : "@ehekler It's like saying \"Space travel fails not because of physics, but because our space ships are poor.\"",
  "id" : 203160195059302400,
  "in_reply_to_status_id" : 203159391334174724,
  "created_at" : "2012-05-17 16:28:59 +0000",
  "in_reply_to_screen_name" : "ehekler",
  "in_reply_to_user_id_str" : "136385823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hekler",
      "screen_name" : "ehekler",
      "indices" : [ 0, 8 ],
      "id_str" : "136385823",
      "id" : 136385823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203157307767525376",
  "geo" : { },
  "id_str" : "203158226798260224",
  "in_reply_to_user_id" : 136385823,
  "text" : "@ehekler Calling all programs poor is misleading since the best programs of today still fail. But yes, we must continue to try to do better.",
  "id" : 203158226798260224,
  "in_reply_to_status_id" : 203157307767525376,
  "created_at" : "2012-05-17 16:21:10 +0000",
  "in_reply_to_screen_name" : "ehekler",
  "in_reply_to_user_id_str" : "136385823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hekler",
      "screen_name" : "ehekler",
      "indices" : [ 0, 8 ],
      "id_str" : "136385823",
      "id" : 136385823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203155042415542274",
  "geo" : { },
  "id_str" : "203155328433532928",
  "in_reply_to_user_id" : 136385823,
  "text" : "@ehekler I disagree. But might be missing more of the context.",
  "id" : 203155328433532928,
  "in_reply_to_status_id" : 203155042415542274,
  "created_at" : "2012-05-17 16:09:39 +0000",
  "in_reply_to_screen_name" : "ehekler",
  "in_reply_to_user_id_str" : "136385823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Feld",
      "screen_name" : "bfeld",
      "indices" : [ 9, 15 ],
      "id_str" : "3754891",
      "id" : 3754891
    }, {
      "name" : "Big Think",
      "screen_name" : "bigthink",
      "indices" : [ 125, 134 ],
      "id_str" : "18567018",
      "id" : 18567018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/xjRyz4Q5",
      "expanded_url" : "http:\/\/www.bigthink.com\/power-games\/the-machines-have-already-taken-over-seven-questions-with-brad-feld",
      "display_url" : "bigthink.com\/power-games\/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203147991111049217",
  "text" : "Love how @bfeld gives the interviewer the smackdown (politely) several times in these 7 questions: http:\/\/t.co\/xjRyz4Q5 \/via @bigthink",
  "id" : 203147991111049217,
  "created_at" : "2012-05-17 15:40:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "strager",
      "screen_name" : "strager",
      "indices" : [ 0, 8 ],
      "id_str" : "16895899",
      "id" : 16895899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203138451594416128",
  "geo" : { },
  "id_str" : "203138602002153472",
  "in_reply_to_user_id" : 16895899,
  "text" : "@strager Send it to me at busterbenson at gmail.",
  "id" : 203138602002153472,
  "in_reply_to_status_id" : 203138451594416128,
  "created_at" : "2012-05-17 15:03:11 +0000",
  "in_reply_to_screen_name" : "strager",
  "in_reply_to_user_id_str" : "16895899",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 7, 17 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/dc8xVMj5",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=uVrVdtSFK7c&feature=plcp",
      "display_url" : "youtube.com\/watch?v=uVrVdt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "202974728036683776",
  "text" : "I love @neiltyson so much. And also this Big Think series: http:\/\/t.co\/dc8xVMj5",
  "id" : 202974728036683776,
  "created_at" : "2012-05-17 04:12:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Linden",
      "screen_name" : "greglinden",
      "indices" : [ 50, 61 ],
      "id_str" : "87719108",
      "id" : 87719108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/1IgSLgil",
      "expanded_url" : "http:\/\/flic.kr\/p\/bZqu6J",
      "display_url" : "flic.kr\/p\/bZqu6J"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.615333, -122.309334 ]
  },
  "id_str" : "202968078005444608",
  "text" : "8:36pm Walking home after great conversation with @greglinden http:\/\/t.co\/1IgSLgil",
  "id" : 202968078005444608,
  "created_at" : "2012-05-17 03:45:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Gold",
      "screen_name" : "heathr",
      "indices" : [ 0, 7 ],
      "id_str" : "678033",
      "id" : 678033
    }, {
      "name" : "Kevin Marks",
      "screen_name" : "kevinmarks",
      "indices" : [ 8, 19 ],
      "id_str" : "57203",
      "id" : 57203
    }, {
      "name" : "Gmail",
      "screen_name" : "gmail",
      "indices" : [ 108, 114 ],
      "id_str" : "38679388",
      "id" : 38679388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202921056661544962",
  "geo" : { },
  "id_str" : "202921934181236736",
  "in_reply_to_user_id" : 678033,
  "text" : "@heathr @kevinmarks Is it okay if I'm in Seattle? I'd love to hear more! Send me details: [twitter username]@gmail.com",
  "id" : 202921934181236736,
  "in_reply_to_status_id" : 202921056661544962,
  "created_at" : "2012-05-17 00:42:13 +0000",
  "in_reply_to_screen_name" : "heathr",
  "in_reply_to_user_id_str" : "678033",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 22, 35 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/JJVPBYiL",
      "expanded_url" : "http:\/\/bit.ly\/J8YncU",
      "display_url" : "bit.ly\/J8YncU"
    } ]
  },
  "geo" : { },
  "id_str" : "202920203972120576",
  "text" : "That's pretty cute RT @octavekitten: i really want a day maker http:\/\/t.co\/JJVPBYiL",
  "id" : 202920203972120576,
  "created_at" : "2012-05-17 00:35:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kendra Markle",
      "screen_name" : "KendraMarkle",
      "indices" : [ 124, 137 ],
      "id_str" : "5041821",
      "id" : 5041821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202919813440479232",
  "text" : "One possible explanation for why behavior change is so difficult is that it often requires also changing your identity. \/cc @kendramarkle",
  "id" : 202919813440479232,
  "created_at" : "2012-05-17 00:33:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shannon Wilkinson",
      "screen_name" : "shannonmw",
      "indices" : [ 14, 24 ],
      "id_str" : "15313452",
      "id" : 15313452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/6Ao3S0qK",
      "expanded_url" : "http:\/\/bit.ly\/JQLraZ",
      "display_url" : "bit.ly\/JQLraZ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6214828455, -122.3370186606 ]
  },
  "id_str" : "202916948990889985",
  "text" : "Thank you! RT @shannonmw: Have you ever wanted to start (or maintain) a daily writing practice? In Praise of 750 Words: http:\/\/t.co\/6Ao3S0qK",
  "id" : 202916948990889985,
  "created_at" : "2012-05-17 00:22:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cohen",
      "screen_name" : "davidcohen",
      "indices" : [ 3, 14 ],
      "id_str" : "817209",
      "id" : 817209
    }, {
      "name" : "techstars",
      "screen_name" : "techstars",
      "indices" : [ 17, 27 ],
      "id_str" : "14277276",
      "id" : 14277276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/n0gP2cSa",
      "expanded_url" : "http:\/\/apply.techstars.com",
      "display_url" : "apply.techstars.com"
    } ]
  },
  "geo" : { },
  "id_str" : "202912254339985410",
  "text" : "RT @davidcohen: .@TechStars Seattle early deadline is May 25th. Apply now to receive world-class mentorship for your startup and $118k!  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "techstars",
        "screen_name" : "techstars",
        "indices" : [ 1, 11 ],
        "id_str" : "14277276",
        "id" : 14277276
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/n0gP2cSa",
        "expanded_url" : "http:\/\/apply.techstars.com",
        "display_url" : "apply.techstars.com"
      } ]
    },
    "geo" : { },
    "id_str" : "202908811743330306",
    "text" : ".@TechStars Seattle early deadline is May 25th. Apply now to receive world-class mentorship for your startup and $118k! http:\/\/t.co\/n0gP2cSa",
    "id" : 202908811743330306,
    "created_at" : "2012-05-16 23:50:05 +0000",
    "user" : {
      "name" : "David Cohen",
      "screen_name" : "davidcohen",
      "protected" : false,
      "id_str" : "817209",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2895068558\/acd3335b0d7790a63a815153d62c0e8f_normal.png",
      "id" : 817209,
      "verified" : false
    }
  },
  "id" : 202912254339985410,
  "created_at" : "2012-05-17 00:03:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kottke.org",
      "screen_name" : "kottke",
      "indices" : [ 130, 137 ],
      "id_str" : "14120215",
      "id" : 14120215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/d3dmzDEb",
      "expanded_url" : "http:\/\/bit.ly\/L1v2xc",
      "display_url" : "bit.ly\/L1v2xc"
    } ]
  },
  "geo" : { },
  "id_str" : "202910806126497793",
  "text" : "\"And make no mistake about it, you are dumb.  You're a group of incredibly well-educated dumb people.\" \nhttp:\/\/t.co\/d3dmzDEb \/via @kottke",
  "id" : 202910806126497793,
  "created_at" : "2012-05-16 23:58:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/6fzULTeQ",
      "expanded_url" : "http:\/\/flic.kr\/p\/bYTt15",
      "display_url" : "flic.kr\/p\/bYTt15"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.666333, -122.383334 ]
  },
  "id_str" : "202604212197146624",
  "text" : "8:36pm Impromptu double date in Ballard! http:\/\/t.co\/6fzULTeQ",
  "id" : 202604212197146624,
  "created_at" : "2012-05-16 03:39:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan Ribera",
      "screen_name" : "abscondment",
      "indices" : [ 0, 12 ],
      "id_str" : "11182552",
      "id" : 11182552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202573818957545472",
  "geo" : { },
  "id_str" : "202586446610186241",
  "in_reply_to_user_id" : 11182552,
  "text" : "@abscondment Yes please!",
  "id" : 202586446610186241,
  "in_reply_to_status_id" : 202573818957545472,
  "created_at" : "2012-05-16 02:29:07 +0000",
  "in_reply_to_screen_name" : "abscondment",
  "in_reply_to_user_id_str" : "11182552",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EYouTube on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/TcR4qdh2",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=9RExQFZzHXQ&feature=youtube_gdata_player",
      "display_url" : "youtube.com\/watch?v=9RExQF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "202582083649019904",
  "text" : "Richard Dawkins and Neil deGrasse Tyson talk biology and physics for and hour. Highly enjoyable! http:\/\/t.co\/TcR4qdh2",
  "id" : 202582083649019904,
  "created_at" : "2012-05-16 02:11:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "panic",
      "indices" : [ 74, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202512770812489728",
  "text" : "Why do you have to remove the card QUICKLY! from parking meters and ATMs? #panic",
  "id" : 202512770812489728,
  "created_at" : "2012-05-15 21:36:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the listserve",
      "screen_name" : "thelistserve",
      "indices" : [ 17, 30 ],
      "id_str" : "550097026",
      "id" : 550097026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/ayOtAQVl",
      "expanded_url" : "http:\/\/thelistserve.com\/",
      "display_url" : "thelistserve.com"
    }, {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/yVWtfZqI",
      "expanded_url" : "http:\/\/launch.thebestthingthisyear.com\/",
      "display_url" : "launch.thebestthingthisyear.com"
    } ]
  },
  "geo" : { },
  "id_str" : "202511275589255169",
  "text" : "Today's email to @thelistserve just cracked me up. Join the list! http:\/\/t.co\/ayOtAQVl\n\nAnother similar cool project: http:\/\/t.co\/yVWtfZqI",
  "id" : 202511275589255169,
  "created_at" : "2012-05-15 21:30:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 0, 4 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202486592034701313",
  "geo" : { },
  "id_str" : "202486816564187137",
  "in_reply_to_user_id" : 259,
  "text" : "@ian Mostly the former but if the latter was done in a non-annoying way, the latter.",
  "id" : 202486816564187137,
  "in_reply_to_status_id" : 202486592034701313,
  "created_at" : "2012-05-15 19:53:13 +0000",
  "in_reply_to_screen_name" : "ian",
  "in_reply_to_user_id_str" : "259",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202486152798810112",
  "text" : "I have a PDF I want to host somewhere and track downloads in a non-annoying way. Any recommendations?",
  "id" : 202486152798810112,
  "created_at" : "2012-05-15 19:50:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/OOVjC2Ks",
      "expanded_url" : "http:\/\/bustr.me\/post\/23115328284\/transparency-in-the-evolution-of-technology",
      "display_url" : "bustr.me\/post\/231153282\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "202479670933979136",
  "text" : "\"We're becoming more honest [via technology] because it increases the speed at which information can travel\" http:\/\/t.co\/OOVjC2Ks",
  "id" : 202479670933979136,
  "created_at" : "2012-05-15 19:24:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kendra Markle",
      "screen_name" : "KendraMarkle",
      "indices" : [ 0, 13 ],
      "id_str" : "5041821",
      "id" : 5041821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202246019386314754",
  "geo" : { },
  "id_str" : "202248597343961091",
  "in_reply_to_user_id" : 5041821,
  "text" : "@kendramarkle That's pretty interesting! Just when I was starting to think I understood Dopamine a little...",
  "id" : 202248597343961091,
  "in_reply_to_status_id" : 202246019386314754,
  "created_at" : "2012-05-15 04:06:37 +0000",
  "in_reply_to_screen_name" : "KendraMarkle",
  "in_reply_to_user_id_str" : "5041821",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/4Qzd0muM",
      "expanded_url" : "http:\/\/instagr.am\/p\/KofytnI0BR\/",
      "display_url" : "instagr.am\/p\/KofytnI0BR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "202244014819393536",
  "text" : "8:36pm Unleash your inner elephant http:\/\/t.co\/4Qzd0muM",
  "id" : 202244014819393536,
  "created_at" : "2012-05-15 03:48:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan Ribera",
      "screen_name" : "abscondment",
      "indices" : [ 104, 116 ],
      "id_str" : "11182552",
      "id" : 11182552
    }, {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 117, 125 ],
      "id_str" : "15275073",
      "id" : 15275073
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 84, 99 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202233886871257088",
  "geo" : { },
  "id_str" : "202235775776079872",
  "in_reply_to_user_id" : 11182552,
  "text" : "Has anyone heard of someone doing any cool tracking\/graphing of unlocks on Android? #quantifiedself \/cc @abscondment @tberman",
  "id" : 202235775776079872,
  "in_reply_to_status_id" : 202233886871257088,
  "created_at" : "2012-05-15 03:15:40 +0000",
  "in_reply_to_screen_name" : "abscondment",
  "in_reply_to_user_id_str" : "11182552",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202227285208731649",
  "geo" : { },
  "id_str" : "202235403225407491",
  "in_reply_to_user_id" : 15275073,
  "text" : "@tberman Oh yeah, totally. I've never had one so the obvious escapes me.",
  "id" : 202235403225407491,
  "in_reply_to_status_id" : 202227285208731649,
  "created_at" : "2012-05-15 03:14:12 +0000",
  "in_reply_to_screen_name" : "tberman",
  "in_reply_to_user_id_str" : "15275073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202225609781415936",
  "geo" : { },
  "id_str" : "202226200536559616",
  "in_reply_to_user_id" : 15275073,
  "text" : "@tberman Do you suspect that's true or know it's true? If true, that's awesome.",
  "id" : 202226200536559616,
  "in_reply_to_status_id" : 202225609781415936,
  "created_at" : "2012-05-15 02:37:38 +0000",
  "in_reply_to_screen_name" : "tberman",
  "in_reply_to_user_id_str" : "15275073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202222607326646272",
  "geo" : { },
  "id_str" : "202225417220927489",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Yes exactly.",
  "id" : 202225417220927489,
  "in_reply_to_status_id" : 202222607326646272,
  "created_at" : "2012-05-15 02:34:31 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202222234381713409",
  "text" : "I wish there was a way to get the time and lat\/long of every time someone unlocks their phone. Just for myself even.",
  "id" : 202222234381713409,
  "created_at" : "2012-05-15 02:21:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202202434653794305",
  "geo" : { },
  "id_str" : "202202665390845952",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim No but it may or may not be a roomba.",
  "id" : 202202665390845952,
  "in_reply_to_status_id" : 202202434653794305,
  "created_at" : "2012-05-15 01:04:06 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twiddler",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202201400753668096",
  "text" : "You have a dog, a human, a robot, and  a building with a bomb. Who do you send in to diffuse it? #twiddler",
  "id" : 202201400753668096,
  "created_at" : "2012-05-15 00:59:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Inman",
      "screen_name" : "Oatmeal",
      "indices" : [ 27, 35 ],
      "id_str" : "4519121",
      "id" : 4519121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/u8z0Q14z",
      "expanded_url" : "http:\/\/theoatmeal.com\/comics\/tesla",
      "display_url" : "theoatmeal.com\/comics\/tesla"
    } ]
  },
  "geo" : { },
  "id_str" : "202179230916820993",
  "text" : "Entertaining argument from @oatmeal on why Nikola Tesla was the greatest geek who ever lived (and Edison not so much): http:\/\/t.co\/u8z0Q14z",
  "id" : 202179230916820993,
  "created_at" : "2012-05-14 23:30:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/iBc34c12",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayLUavV5",
      "display_url" : "tmblr.co\/ZQJvayLUavV5"
    } ]
  },
  "geo" : { },
  "id_str" : "202158667393531904",
  "text" : "Percent who favor same sex marriage by generation: http:\/\/t.co\/iBc34c12\n\nPeople don't change minds so much as get replaced.",
  "id" : 202158667393531904,
  "created_at" : "2012-05-14 22:09:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Margit Detweiler",
      "screen_name" : "Margit",
      "indices" : [ 34, 41 ],
      "id_str" : "2743601",
      "id" : 2743601
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 48, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/OCj9J0GO",
      "expanded_url" : "http:\/\/whatsyoursystem.tumblr.com\/post\/23048356043\/system-guru-q-a-with-buster-benson-part-1",
      "display_url" : "whatsyoursystem.tumblr.com\/post\/230483560\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "202129290526068736",
  "text" : "A fun interview (pt 1) I did with @Margit about #quantifiedself type things: http:\/\/t.co\/OCj9J0GO",
  "id" : 202129290526068736,
  "created_at" : "2012-05-14 20:12:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Calvin Spealman",
      "screen_name" : "ironfroggy",
      "indices" : [ 0, 11 ],
      "id_str" : "5622042",
      "id" : 5622042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202082954346889216",
  "geo" : { },
  "id_str" : "202083281494212608",
  "in_reply_to_user_id" : 5622042,
  "text" : "@ironfroggy I had the same argument about that. It's just a sensationalist title, but the questions are fun.",
  "id" : 202083281494212608,
  "in_reply_to_status_id" : 202082954346889216,
  "created_at" : "2012-05-14 17:09:43 +0000",
  "in_reply_to_screen_name" : "ironfroggy",
  "in_reply_to_user_id_str" : "5622042",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Murray",
      "screen_name" : "charlesmurray",
      "indices" : [ 15, 29 ],
      "id_str" : "19878055",
      "id" : 19878055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/WixPKP3N",
      "expanded_url" : "http:\/\/refer.ly\/a0jX",
      "display_url" : "refer.ly\/a0jX"
    } ]
  },
  "geo" : { },
  "id_str" : "202082662427533314",
  "text" : "I scored 31 in @charlesmurray's \"Do You Live in a Bubble\" quiz. Sort of interesting. Take it here: http:\/\/t.co\/WixPKP3N",
  "id" : 202082662427533314,
  "created_at" : "2012-05-14 17:07:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i.am.donte",
      "screen_name" : "iamdonte",
      "indices" : [ 0, 9 ],
      "id_str" : "17977759",
      "id" : 17977759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202062204479094784",
  "geo" : { },
  "id_str" : "202063458794086401",
  "in_reply_to_user_id" : 17977759,
  "text" : "@iamdonte HA. That's so like him.",
  "id" : 202063458794086401,
  "in_reply_to_status_id" : 202062204479094784,
  "created_at" : "2012-05-14 15:50:57 +0000",
  "in_reply_to_screen_name" : "iamdonte",
  "in_reply_to_user_id_str" : "17977759",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "geoffclapp",
      "screen_name" : "geoffclapp",
      "indices" : [ 0, 11 ],
      "id_str" : "12118392",
      "id" : 12118392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201904320973778946",
  "geo" : { },
  "id_str" : "201907775343828992",
  "in_reply_to_user_id" : 12118392,
  "text" : "@geoffclapp Blog it! :)",
  "id" : 201907775343828992,
  "in_reply_to_status_id" : 201904320973778946,
  "created_at" : "2012-05-14 05:32:19 +0000",
  "in_reply_to_screen_name" : "geoffclapp",
  "in_reply_to_user_id_str" : "12118392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 35, 46 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/QAWsTahH",
      "expanded_url" : "http:\/\/instagr.am\/p\/KmC-EAI0Ky\/",
      "display_url" : "instagr.am\/p\/KmC-EAI0Ky\/"
    } ]
  },
  "geo" : { },
  "id_str" : "201900842016706560",
  "text" : "Thanks to everyone who helped make @nikobenson feel loved these last 2 days. He's really happy. http:\/\/t.co\/QAWsTahH",
  "id" : 201900842016706560,
  "created_at" : "2012-05-14 05:04:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HSofia",
      "screen_name" : "hsofia",
      "indices" : [ 0, 7 ],
      "id_str" : "14372614",
      "id" : 14372614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201896608315621376",
  "geo" : { },
  "id_str" : "201896924595503104",
  "in_reply_to_user_id" : 14372614,
  "text" : "@hsofia Sorry, I've been tweeting about the hidden role of desperation in behavior change lately. Most people don't acknowledge it.",
  "id" : 201896924595503104,
  "in_reply_to_status_id" : 201896608315621376,
  "created_at" : "2012-05-14 04:49:12 +0000",
  "in_reply_to_screen_name" : "hsofia",
  "in_reply_to_user_id_str" : "14372614",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201882830719025153",
  "geo" : { },
  "id_str" : "201895550235324416",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin I had no idea he would actually understand the request! I need to start asking him more random questions.",
  "id" : 201895550235324416,
  "in_reply_to_status_id" : 201882830719025153,
  "created_at" : "2012-05-14 04:43:44 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/3qUMCQpc",
      "expanded_url" : "http:\/\/www.brainpickings.org\/index.php\/2012\/02\/22\/ira-glass-on-the-secret-of-success\/",
      "display_url" : "brainpickings.org\/index.php\/2012\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "201894829293178881",
  "text" : "How to be successful according to Ira Glass: \"do a lot of work.\" Another example that skips the unacknowledged key. http:\/\/t.co\/3qUMCQpc",
  "id" : 201894829293178881,
  "created_at" : "2012-05-14 04:40:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/mJXPWOhl",
      "expanded_url" : "http:\/\/instagr.am\/p\/Kl6TqFo0G9\/",
      "display_url" : "instagr.am\/p\/Kl6TqFo0G9\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608614, -122.306069 ]
  },
  "id_str" : "201880472308023296",
  "text" : "8:36pm I asked him to make a funny face for 8:36, he rallied tags:8:36pm  @ \uE036Benson Bungalow http:\/\/t.co\/mJXPWOhl",
  "id" : 201880472308023296,
  "created_at" : "2012-05-14 03:43:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/NEiG9LBB",
      "expanded_url" : "http:\/\/instagr.am\/p\/KloguCo0Na\/",
      "display_url" : "instagr.am\/p\/KloguCo0Na\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.621062194, -122.306478024 ]
  },
  "id_str" : "201841189987688448",
  "text" : "Sunny day  @ Miller Playfield http:\/\/t.co\/NEiG9LBB",
  "id" : 201841189987688448,
  "created_at" : "2012-05-14 01:07:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/riOZOSPQ",
      "expanded_url" : "http:\/\/flic.kr\/p\/bX1Taw",
      "display_url" : "flic.kr\/p\/bX1Taw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.305834 ]
  },
  "id_str" : "201532663901851648",
  "text" : "8:36pm Post party fire relaxation time http:\/\/t.co\/riOZOSPQ",
  "id" : 201532663901851648,
  "created_at" : "2012-05-13 04:41:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/bZPa08z8",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ki6SQDo0AS\/",
      "display_url" : "instagr.am\/p\/Ki6SQDo0AS\/"
    } ]
  },
  "geo" : { },
  "id_str" : "201457921354240000",
  "text" : "The backyard is being put to full use http:\/\/t.co\/bZPa08z8",
  "id" : 201457921354240000,
  "created_at" : "2012-05-12 23:44:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 24, 35 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/Jwr6PUtu",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ki55EZI0AG\/",
      "display_url" : "instagr.am\/p\/Ki55EZI0AG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "201456998024351744",
  "text" : "Happy birthday (party), @nikobenson! http:\/\/t.co\/Jwr6PUtu",
  "id" : 201456998024351744,
  "created_at" : "2012-05-12 23:41:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "indices" : [ 3, 17 ],
      "id_str" : "749863",
      "id" : 749863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201411109180293121",
  "text" : "RT @hotdogsladies: The thing that made the web fun and exciting is the \"Subscribe\" button.\nThe thing that keeps it useful and sane is th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/hibariapp.com\" rel=\"nofollow\"\u003EHibari\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "201405517782990849",
    "text" : "The thing that made the web fun and exciting is the \"Subscribe\" button.\nThe thing that keeps it useful and sane is the \"Unsubscribe\" button.",
    "id" : 201405517782990849,
    "created_at" : "2012-05-12 20:16:32 +0000",
    "user" : {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "protected" : false,
      "id_str" : "749863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416379332324372480\/7k5UxDOt_normal.jpeg",
      "id" : 749863,
      "verified" : true
    }
  },
  "id" : 201411109180293121,
  "created_at" : "2012-05-12 20:38:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/TPGhWqPB",
      "expanded_url" : "http:\/\/instagr.am\/p\/KieURjI0Py\/",
      "display_url" : "instagr.am\/p\/KieURjI0Py\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608614, -122.306069 ]
  },
  "id_str" : "201396410782986240",
  "text" : "Getting ready for Niko's 2nd bday party  @ \uE036Benson Bungalow http:\/\/t.co\/TPGhWqPB",
  "id" : 201396410782986240,
  "created_at" : "2012-05-12 19:40:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/ztVE38rj",
      "expanded_url" : "http:\/\/flic.kr\/p\/bWsN4s",
      "display_url" : "flic.kr\/p\/bWsN4s"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.305834 ]
  },
  "id_str" : "201154555302526977",
  "text" : "8:36pm Putting lights up for Niko's party tomorrow http:\/\/t.co\/ztVE38rj",
  "id" : 201154555302526977,
  "created_at" : "2012-05-12 03:39:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EYouTube on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/QVWq97Ro",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=AOaWeObjLyI&feature=youtube_gdata_player",
      "display_url" : "youtube.com\/watch?v=AOaWeO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "201124522701766656",
  "text" : "When Dre and I got tired of spinning them they tried to spin each other http:\/\/t.co\/QVWq97Ro",
  "id" : 201124522701766656,
  "created_at" : "2012-05-12 01:39:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/FgYSRM6v",
      "expanded_url" : "http:\/\/flic.kr\/p\/bVZShw",
      "display_url" : "flic.kr\/p\/bVZShw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.609, -122.33 ]
  },
  "id_str" : "200801194178904066",
  "text" : "8:36pm Just leaving the John Gottman talk on making marriage work http:\/\/t.co\/FgYSRM6v",
  "id" : 200801194178904066,
  "created_at" : "2012-05-11 04:15:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 17, 26 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Walter Smith",
      "screen_name" : "walter_smith",
      "indices" : [ 37, 50 ],
      "id_str" : "14556357",
      "id" : 14556357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200761478922518528",
  "geo" : { },
  "id_str" : "200765639709818880",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall @RickWebb That's by @walter_smith, I believe! (Our neighbor at the old offices!)",
  "id" : 200765639709818880,
  "in_reply_to_status_id" : 200761478922518528,
  "created_at" : "2012-05-11 01:53:53 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200719010214584321",
  "text" : "Spending the day working with my notepad in the sun, taking frequent walk meetings with myself. It's pretty nice!",
  "id" : 200719010214584321,
  "created_at" : "2012-05-10 22:48:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 3, 15 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/2tNnUYsr",
      "expanded_url" : "http:\/\/CNN.com",
      "display_url" : "CNN.com"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/PI74fKDl",
      "expanded_url" : "http:\/\/bit.ly\/JeSb1e",
      "display_url" : "bit.ly\/JeSb1e"
    } ]
  },
  "geo" : { },
  "id_str" : "200622255003287552",
  "text" : "RT @ginatrapani: My http:\/\/t.co\/2tNnUYsr piece: How the \"brogrammer\" thing can be actually useful to women &amp; inclusive companies htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 3, 23 ],
        "url" : "http:\/\/t.co\/2tNnUYsr",
        "expanded_url" : "http:\/\/CNN.com",
        "display_url" : "CNN.com"
      }, {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/PI74fKDl",
        "expanded_url" : "http:\/\/bit.ly\/JeSb1e",
        "display_url" : "bit.ly\/JeSb1e"
      } ]
    },
    "geo" : { },
    "id_str" : "200614001338630144",
    "text" : "My http:\/\/t.co\/2tNnUYsr piece: How the \"brogrammer\" thing can be actually useful to women &amp; inclusive companies http:\/\/t.co\/PI74fKDl",
    "id" : 200614001338630144,
    "created_at" : "2012-05-10 15:51:19 +0000",
    "user" : {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "protected" : false,
      "id_str" : "930061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000094875503\/88ec3120528d2e75172814a05cc19243_normal.png",
      "id" : 930061,
      "verified" : true
    }
  },
  "id" : 200622255003287552,
  "created_at" : "2012-05-10 16:24:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jasper Horn",
      "screen_name" : "JasperHorn",
      "indices" : [ 0, 11 ],
      "id_str" : "50057203",
      "id" : 50057203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200602267060158464",
  "geo" : { },
  "id_str" : "200602876840656896",
  "in_reply_to_user_id" : 50057203,
  "text" : "@JasperHorn Yeah, a bit stretched. But I liked the idea that discarding work could be interpreted as enjoyable rather than wasteful.",
  "id" : 200602876840656896,
  "in_reply_to_status_id" : 200602267060158464,
  "created_at" : "2012-05-10 15:07:07 +0000",
  "in_reply_to_screen_name" : "JasperHorn",
  "in_reply_to_user_id_str" : "50057203",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200592921861427200",
  "geo" : { },
  "id_str" : "200593219979976706",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april But what about the lack of imperfect cookies to eat during the selection process? Seems flawed.",
  "id" : 200593219979976706,
  "in_reply_to_status_id" : 200592921861427200,
  "created_at" : "2012-05-10 14:28:45 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 105, 110 ],
      "id_str" : "528",
      "id" : 528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/1nP0T1yM",
      "expanded_url" : "http:\/\/www.blog.montgomerie.net\/apple-failure-and-perfect-cookies",
      "display_url" : "blog.montgomerie.net\/apple-failure-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "200591039973691392",
  "text" : "How do you get a batch of perfectly sized and round cookies? Eat the outliers: http:\/\/t.co\/1nP0T1yM \/via @buzz",
  "id" : 200591039973691392,
  "created_at" : "2012-05-10 14:20:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trapper Markelz",
      "screen_name" : "trappermarkelz",
      "indices" : [ 3, 18 ],
      "id_str" : "1032241",
      "id" : 1032241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/5RHouCHH",
      "expanded_url" : "http:\/\/bit.ly\/IDIzLR",
      "display_url" : "bit.ly\/IDIzLR"
    } ]
  },
  "geo" : { },
  "id_str" : "200578681217884160",
  "text" : "RT @trappermarkelz: Seth's Blog: Solving the problem isn't the problem - http:\/\/t.co\/5RHouCHH - I love this. Most of the time it does co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/5RHouCHH",
        "expanded_url" : "http:\/\/bit.ly\/IDIzLR",
        "display_url" : "bit.ly\/IDIzLR"
      } ]
    },
    "geo" : { },
    "id_str" : "200570659896700929",
    "text" : "Seth's Blog: Solving the problem isn't the problem - http:\/\/t.co\/5RHouCHH - I love this. Most of the time it does come down to distribution.",
    "id" : 200570659896700929,
    "created_at" : "2012-05-10 12:59:06 +0000",
    "user" : {
      "name" : "Trapper Markelz",
      "screen_name" : "trappermarkelz",
      "protected" : false,
      "id_str" : "1032241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3025341826\/2d7fa654f59dac4badbb416d8a267625_normal.jpeg",
      "id" : 1032241,
      "verified" : false
    }
  },
  "id" : 200578681217884160,
  "created_at" : "2012-05-10 13:30:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "face.com team",
      "screen_name" : "face",
      "indices" : [ 39, 44 ],
      "id_str" : "21102575",
      "id" : 21102575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/aMA0FlUI",
      "expanded_url" : "http:\/\/bit.ly\/JfYm8c",
      "display_url" : "bit.ly\/JfYm8c"
    } ]
  },
  "geo" : { },
  "id_str" : "200578046208651264",
  "text" : "Pretty amazing face recognition app RT @face: KLIK 1.0 Launched! http:\/\/t.co\/aMA0FlUI",
  "id" : 200578046208651264,
  "created_at" : "2012-05-10 13:28:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April V. Walters",
      "screen_name" : "aprilini",
      "indices" : [ 0, 9 ],
      "id_str" : "875511",
      "id" : 875511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200470082558758913",
  "geo" : { },
  "id_str" : "200472533097660416",
  "in_reply_to_user_id" : 875511,
  "text" : "@aprilini I like that better. Can I have a redo?",
  "id" : 200472533097660416,
  "in_reply_to_status_id" : 200470082558758913,
  "created_at" : "2012-05-10 06:29:11 +0000",
  "in_reply_to_screen_name" : "aprilini",
  "in_reply_to_user_id_str" : "875511",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Powazek",
      "screen_name" : "fraying",
      "indices" : [ 0, 8 ],
      "id_str" : "4999",
      "id" : 4999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200464345606537216",
  "geo" : { },
  "id_str" : "200464513936535554",
  "in_reply_to_user_id" : 4999,
  "text" : "@fraying Great answer! I think I just learned something.",
  "id" : 200464513936535554,
  "in_reply_to_status_id" : 200464345606537216,
  "created_at" : "2012-05-10 05:57:19 +0000",
  "in_reply_to_screen_name" : "fraying",
  "in_reply_to_user_id_str" : "4999",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Robinson",
      "screen_name" : "Julesmarie",
      "indices" : [ 0, 11 ],
      "id_str" : "14144646",
      "id" : 14144646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200463835151347713",
  "geo" : { },
  "id_str" : "200464052999303169",
  "in_reply_to_user_id" : 14144646,
  "text" : "@Julesmarie Nice answer.",
  "id" : 200464052999303169,
  "in_reply_to_status_id" : 200463835151347713,
  "created_at" : "2012-05-10 05:55:29 +0000",
  "in_reply_to_screen_name" : "Julesmarie",
  "in_reply_to_user_id_str" : "14144646",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Robinson",
      "screen_name" : "Julesmarie",
      "indices" : [ 3, 14 ],
      "id_str" : "14144646",
      "id" : 14144646
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 16, 29 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200463976562302977",
  "text" : "RT @Julesmarie: @busterbenson \"buttons\" = turn-off when over-done. if there's not a semantic reason to be a \"button\", better off (and fu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "200460969925816321",
    "geo" : { },
    "id_str" : "200463835151347713",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson \"buttons\" = turn-off when over-done. if there's not a semantic reason to be a \"button\", better off (and future-proof) as link",
    "id" : 200463835151347713,
    "in_reply_to_status_id" : 200460969925816321,
    "created_at" : "2012-05-10 05:54:37 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Julia Robinson",
      "screen_name" : "Julesmarie",
      "protected" : false,
      "id_str" : "14144646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3513393497\/dc017cb3dcc1e455a15e9c5e31455a48_normal.jpeg",
      "id" : 14144646,
      "verified" : false
    }
  },
  "id" : 200463976562302977,
  "created_at" : "2012-05-10 05:55:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Gradert",
      "screen_name" : "kaigradert",
      "indices" : [ 0, 11 ],
      "id_str" : "78429421",
      "id" : 78429421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200463047146483712",
  "geo" : { },
  "id_str" : "200463396989186048",
  "in_reply_to_user_id" : 78429421,
  "text" : "@kaigradert I know, but what if it was as simple as that? A nice world to live in.",
  "id" : 200463396989186048,
  "in_reply_to_status_id" : 200463047146483712,
  "created_at" : "2012-05-10 05:52:52 +0000",
  "in_reply_to_screen_name" : "kaigradert",
  "in_reply_to_user_id_str" : "78429421",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Fox",
      "screen_name" : "heychrisfox",
      "indices" : [ 0, 12 ],
      "id_str" : "9354282",
      "id" : 9354282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200461175362830336",
  "geo" : { },
  "id_str" : "200461490875154432",
  "in_reply_to_user_id" : 9354282,
  "text" : "@heychrisfox roundy, pushy?",
  "id" : 200461490875154432,
  "in_reply_to_status_id" : 200461175362830336,
  "created_at" : "2012-05-10 05:45:18 +0000",
  "in_reply_to_screen_name" : "heychrisfox",
  "in_reply_to_user_id_str" : "9354282",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 3, 13 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200461047881150464",
  "text" : "RT @sourjayne: \uD83D\uDCA3\uD83D\uDCA8\uD83D\uDC83",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "200460691113656321",
    "text" : "\uD83D\uDCA3\uD83D\uDCA8\uD83D\uDC83",
    "id" : 200460691113656321,
    "created_at" : "2012-05-10 05:42:07 +0000",
    "user" : {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "protected" : false,
      "id_str" : "4981271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000206791671\/e60aa9ce2c642fda9d5ef9e9c4221840_normal.jpeg",
      "id" : 4981271,
      "verified" : false
    }
  },
  "id" : 200461047881150464,
  "created_at" : "2012-05-10 05:43:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200460969925816321",
  "text" : "What's better: links or buttons?",
  "id" : 200460969925816321,
  "created_at" : "2012-05-10 05:43:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tavis Rudd",
      "screen_name" : "tavisrudd",
      "indices" : [ 0, 10 ],
      "id_str" : "187354174",
      "id" : 187354174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200459634681716736",
  "geo" : { },
  "id_str" : "200460049431273472",
  "in_reply_to_user_id" : 187354174,
  "text" : "@tavisrudd We'll be sharing more soon enough!",
  "id" : 200460049431273472,
  "in_reply_to_status_id" : 200459634681716736,
  "created_at" : "2012-05-10 05:39:34 +0000",
  "in_reply_to_screen_name" : "tavisrudd",
  "in_reply_to_user_id_str" : "187354174",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/instagram\/id389801252?mt=8&uo=4\" rel=\"nofollow\"\u003EInstagram on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 58, 74 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/OsJXuvtD",
      "expanded_url" : "http:\/\/instagr.am\/p\/KbqVYvLJ-n\/",
      "display_url" : "instagr.am\/p\/KbqVYvLJ-n\/"
    } ]
  },
  "geo" : { },
  "id_str" : "200453391170813952",
  "text" : "This might be our best app yet: http:\/\/t.co\/OsJXuvtD \/via @ameliagreenhall",
  "id" : 200453391170813952,
  "created_at" : "2012-05-10 05:13:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/vnGvjal9",
      "expanded_url" : "http:\/\/instagr.am\/p\/KbxOJ7o0BG\/",
      "display_url" : "instagr.am\/p\/KbxOJ7o0BG\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614079, -122.317236713 ]
  },
  "id_str" : "200452842346119169",
  "text" : "Binary cranes say hi.   @ Unicorn http:\/\/t.co\/vnGvjal9",
  "id" : 200452842346119169,
  "created_at" : "2012-05-10 05:10:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/7ye0CFvF",
      "expanded_url" : "http:\/\/flic.kr\/p\/bVtucG",
      "display_url" : "flic.kr\/p\/bVtucG"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.615166, -122.323167 ]
  },
  "id_str" : "200429449592844288",
  "text" : "8:36pm Having lots of ideas for some reason http:\/\/t.co\/7ye0CFvF",
  "id" : 200429449592844288,
  "created_at" : "2012-05-10 03:37:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200417899490443264",
  "geo" : { },
  "id_str" : "200418053031346176",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort I'm at the bar. Come by before you leave!",
  "id" : 200418053031346176,
  "in_reply_to_status_id" : 200417899490443264,
  "created_at" : "2012-05-10 02:52:42 +0000",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/Rdak2WM1",
      "expanded_url" : "http:\/\/instagr.am\/p\/Kbg9AeI0Ly\/",
      "display_url" : "instagr.am\/p\/Kbg9AeI0Ly\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6150209614, -122.322984581 ]
  },
  "id_str" : "200417268025393152",
  "text" : "Feeling thankful for constraints today  @ Linda's Tavern http:\/\/t.co\/Rdak2WM1",
  "id" : 200417268025393152,
  "created_at" : "2012-05-10 02:49:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200411732454285314",
  "text" : "Desperation is the mother of inspiration.",
  "id" : 200411732454285314,
  "created_at" : "2012-05-10 02:27:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tikva Morowati",
      "screen_name" : "tikkers",
      "indices" : [ 3, 11 ],
      "id_str" : "1054551",
      "id" : 1054551
    }, {
      "name" : "Anne Hjortshoj",
      "screen_name" : "annesaurus",
      "indices" : [ 14, 25 ],
      "id_str" : "1244441",
      "id" : 1244441
    }, {
      "name" : "John Ramey",
      "screen_name" : "jpramey",
      "indices" : [ 26, 34 ],
      "id_str" : "14129241",
      "id" : 14129241
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 130, 140 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200411485216833536",
  "text" : "RT @tikkers: .@annesaurus @jpramey No way. That's amazing.... Similarly, Amazon created 43 Things to teach people how to blog. cc @buste ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anne Hjortshoj",
        "screen_name" : "annesaurus",
        "indices" : [ 1, 12 ],
        "id_str" : "1244441",
        "id" : 1244441
      }, {
        "name" : "John Ramey",
        "screen_name" : "jpramey",
        "indices" : [ 13, 21 ],
        "id_str" : "14129241",
        "id" : 14129241
      }, {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 117, 130 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "200398417548152833",
    "geo" : { },
    "id_str" : "200398709492695040",
    "in_reply_to_user_id" : 1244441,
    "text" : ".@annesaurus @jpramey No way. That's amazing.... Similarly, Amazon created 43 Things to teach people how to blog. cc @busterbenson",
    "id" : 200398709492695040,
    "in_reply_to_status_id" : 200398417548152833,
    "created_at" : "2012-05-10 01:35:50 +0000",
    "in_reply_to_screen_name" : "annesaurus",
    "in_reply_to_user_id_str" : "1244441",
    "user" : {
      "name" : "Tikva Morowati",
      "screen_name" : "tikkers",
      "protected" : false,
      "id_str" : "1054551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3480596693\/fa899c9a07727e9a3b07e3885a4a83a9_normal.jpeg",
      "id" : 1054551,
      "verified" : false
    }
  },
  "id" : 200411485216833536,
  "created_at" : "2012-05-10 02:26:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200327396212228097",
  "geo" : { },
  "id_str" : "200328033821925376",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Moblogs are the future! It makes wonder what hacky thing I'm doing now is going to sell for $1B in 9 years.",
  "id" : 200328033821925376,
  "in_reply_to_status_id" : 200327396212228097,
  "created_at" : "2012-05-09 20:54:59 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 3, 13 ],
      "id_str" : "16644937",
      "id" : 16644937
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 15, 28 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200327037754413056",
  "text" : "RT @the_april: @busterbenson \"I only get to send a couple dozen emails a month from the phone\" Hahah. Those were the days.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "200325080251772928",
    "geo" : { },
    "id_str" : "200326762104762369",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson \"I only get to send a couple dozen emails a month from the phone\" Hahah. Those were the days.",
    "id" : 200326762104762369,
    "in_reply_to_status_id" : 200325080251772928,
    "created_at" : "2012-05-09 20:49:56 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "protected" : true,
      "id_str" : "16644937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000328822266\/52679ce9ab7a7a1aaa32005cf4dfb21d_normal.jpeg",
      "id" : 16644937,
      "verified" : false
    }
  },
  "id" : 200327037754413056,
  "created_at" : "2012-05-09 20:51:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200326762104762369",
  "geo" : { },
  "id_str" : "200326991336062977",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april That was my favorite sentence too.  :)  That and my feelings about the future of weblogs.",
  "id" : 200326991336062977,
  "in_reply_to_status_id" : 200326762104762369,
  "created_at" : "2012-05-09 20:50:51 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 98, 108 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/wK1dABFl",
      "expanded_url" : "http:\/\/busterbenson.com\/entries\/view\/13826",
      "display_url" : "busterbenson.com\/entries\/view\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "200325080251772928",
  "text" : "My 2003 blog post on how to post photos from your phone to your \"moblog\". In case you're tired of @instagram: http:\/\/t.co\/wK1dABFl",
  "id" : 200325080251772928,
  "created_at" : "2012-05-09 20:43:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 44, 51 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/HpfV00p7",
      "expanded_url" : "http:\/\/notch.me\/p\/2AlxbVlMlDj6dlDO1ePghq",
      "display_url" : "notch.me\/p\/2AlxbVlMlDj6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "200301603792752640",
  "text" : "Last month I walked 0 miles according to my @fitbit (because I broke it, oops). That's less than a 3-toed sloth. http:\/\/t.co\/HpfV00p7",
  "id" : 200301603792752640,
  "created_at" : "2012-05-09 19:09:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 7, 21 ],
      "id_str" : "820661",
      "id" : 820661
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 33, 44 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/T9VR05ij",
      "expanded_url" : "http:\/\/blog.nosnivelling.com\/2012\/05\/idea-for-foursquare-monetization.html",
      "display_url" : "blog.nosnivelling.com\/2012\/05\/idea-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "200270983918129153",
  "text" : "I love @daveschappell's idea for @foursquare: sell the music of bands playing where you check in: http:\/\/t.co\/T9VR05ij",
  "id" : 200270983918129153,
  "created_at" : "2012-05-09 17:08:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Karnjanaprakorn",
      "screen_name" : "mikekarnj",
      "indices" : [ 56, 66 ],
      "id_str" : "5901702",
      "id" : 5901702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/sxZSRXC9",
      "expanded_url" : "http:\/\/bit.ly\/JwItpr",
      "display_url" : "bit.ly\/JwItpr"
    } ]
  },
  "geo" : { },
  "id_str" : "200221822501912577",
  "text" : "This seems true to me, but it isn't really a paradox RT @mikekarnj: The Learning Paradox http:\/\/t.co\/sxZSRXC9",
  "id" : 200221822501912577,
  "created_at" : "2012-05-09 13:52:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "indices" : [ 3, 12 ],
      "id_str" : "255784266",
      "id" : 255784266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/eRml1Rdn",
      "expanded_url" : "http:\/\/goo.gl\/fb\/jbiX9",
      "display_url" : "goo.gl\/fb\/jbiX9"
    } ]
  },
  "geo" : { },
  "id_str" : "200219954526683138",
  "text" : "RT @geekwire: EveryMove lands $2.6M to create a \u2018mileage rewards program\u2019 for health http:\/\/t.co\/eRml1Rdn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/eRml1Rdn",
        "expanded_url" : "http:\/\/goo.gl\/fb\/jbiX9",
        "display_url" : "goo.gl\/fb\/jbiX9"
      } ]
    },
    "geo" : { },
    "id_str" : "200197288503681025",
    "text" : "EveryMove lands $2.6M to create a \u2018mileage rewards program\u2019 for health http:\/\/t.co\/eRml1Rdn",
    "id" : 200197288503681025,
    "created_at" : "2012-05-09 12:15:27 +0000",
    "user" : {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "protected" : false,
      "id_str" : "255784266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454998478880403457\/BjKnFxtf_normal.png",
      "id" : 255784266,
      "verified" : false
    }
  },
  "id" : 200219954526683138,
  "created_at" : "2012-05-09 13:45:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daryn Nakhuda",
      "screen_name" : "daryn",
      "indices" : [ 0, 6 ],
      "id_str" : "804808",
      "id" : 804808
    }, {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 7, 21 ],
      "id_str" : "820661",
      "id" : 820661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200101127168077824",
  "geo" : { },
  "id_str" : "200105347636146176",
  "in_reply_to_user_id" : 804808,
  "text" : "@daryn @daveschappell They do have a good head start and lots of money. I'll probably lose in reality but win in spirit.",
  "id" : 200105347636146176,
  "in_reply_to_status_id" : 200101127168077824,
  "created_at" : "2012-05-09 06:10:07 +0000",
  "in_reply_to_screen_name" : "daryn",
  "in_reply_to_user_id_str" : "804808",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 3, 17 ],
      "id_str" : "820661",
      "id" : 820661
    }, {
      "name" : "Daryn Nakhuda",
      "screen_name" : "daryn",
      "indices" : [ 26, 32 ],
      "id_str" : "804808",
      "id" : 804808
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 62, 75 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200095678167400448",
  "text" : "RT @daveschappell: It's a @Daryn showdown!  I claim LinkedIn, @busterbenson claims Pinterest.  $1 to the winner!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daryn Nakhuda",
        "screen_name" : "daryn",
        "indices" : [ 7, 13 ],
        "id_str" : "804808",
        "id" : 804808
      }, {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 43, 56 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 47.617830308, -122.3260900435 ]
    },
    "id_str" : "200095403440472064",
    "text" : "It's a @Daryn showdown!  I claim LinkedIn, @busterbenson claims Pinterest.  $1 to the winner!",
    "id" : 200095403440472064,
    "created_at" : "2012-05-09 05:30:36 +0000",
    "user" : {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "protected" : false,
      "id_str" : "820661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3160071838\/28c085d5177f98840fb6b6b0a82203a1_normal.jpeg",
      "id" : 820661,
      "verified" : false
    }
  },
  "id" : 200095678167400448,
  "created_at" : "2012-05-09 05:31:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/3cUghAje",
      "expanded_url" : "http:\/\/flic.kr\/p\/bUVLP9",
      "display_url" : "flic.kr\/p\/bUVLP9"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6175, -122.3265 ]
  },
  "id_str" : "200067647298224130",
  "text" : "8:36pm At the Saint taking inventory of the good things in life http:\/\/t.co\/3cUghAje",
  "id" : 200067647298224130,
  "created_at" : "2012-05-09 03:40:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Soman",
      "screen_name" : "nicksoman",
      "indices" : [ 19, 29 ],
      "id_str" : "47564182",
      "id" : 47564182
    }, {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "indices" : [ 130, 139 ],
      "id_str" : "255784266",
      "id" : 255784266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "founderspromise",
      "indices" : [ 110, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/J71rnlCy",
      "expanded_url" : "http:\/\/www.geekwire.com\/2012\/founders-promise-put-money-angst\/",
      "display_url" : "geekwire.com\/2012\/founders-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "200022590427889664",
  "text" : "Very cool idea. RT @nicksoman: The Founders' Promise: Put your money where your angst is http:\/\/t.co\/J71rnlCy #founderspromise cc @geekwire",
  "id" : 200022590427889664,
  "created_at" : "2012-05-09 00:41:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asha Dornfest",
      "screen_name" : "parenthacks",
      "indices" : [ 0, 12 ],
      "id_str" : "14645531",
      "id" : 14645531
    }, {
      "name" : "Charles Duhigg",
      "screen_name" : "cduhigg",
      "indices" : [ 77, 85 ],
      "id_str" : "20570290",
      "id" : 20570290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199971956383158272",
  "geo" : { },
  "id_str" : "199975045601296384",
  "in_reply_to_user_id" : 14645531,
  "text" : "@parenthacks We haven't met, but agree that my work is greatly reinforced by @cduhigg's articulation of cue, routine, reward! Hello!",
  "id" : 199975045601296384,
  "in_reply_to_status_id" : 199971956383158272,
  "created_at" : "2012-05-08 21:32:20 +0000",
  "in_reply_to_screen_name" : "parenthacks",
  "in_reply_to_user_id_str" : "14645531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Dragonwillow",
      "screen_name" : "MDragonwillow",
      "indices" : [ 0, 14 ],
      "id_str" : "210134652",
      "id" : 210134652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199950686354554880",
  "geo" : { },
  "id_str" : "199953242065604608",
  "in_reply_to_user_id" : 210134652,
  "text" : "@MDragonwillow Can you try logging out and logging back in?  If that doesn't work, try another browser?",
  "id" : 199953242065604608,
  "in_reply_to_status_id" : 199950686354554880,
  "created_at" : "2012-05-08 20:05:42 +0000",
  "in_reply_to_screen_name" : "MDragonwillow",
  "in_reply_to_user_id_str" : "210134652",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "indices" : [ 33, 44 ],
      "id_str" : "809641",
      "id" : 809641
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "linksy",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/uTt0V0aV",
      "expanded_url" : "http:\/\/linksy.me\/r\/465?smid=4fa8444c8a7ea300010000f0",
      "display_url" : "linksy.me\/r\/465?smid=4fa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "199952190083842048",
  "text" : "Super interesting new thing from @adamloving that helps you promote your things. He's doing a \"webinar\": http:\/\/t.co\/uTt0V0aV #linksy",
  "id" : 199952190083842048,
  "created_at" : "2012-05-08 20:01:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "minboxco",
      "screen_name" : "minboxco",
      "indices" : [ 0, 9 ],
      "id_str" : "1359201961",
      "id" : 1359201961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199945456091017217",
  "in_reply_to_user_id" : 499069217,
  "text" : "@minboxco I check you guys at least once a week to see if there's anything to try yet. Need an enthusiastic beta tester? :)",
  "id" : 199945456091017217,
  "created_at" : "2012-05-08 19:34:46 +0000",
  "in_reply_to_screen_name" : "Minbox",
  "in_reply_to_user_id_str" : "499069217",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not All Hyperbole",
      "screen_name" : "Strabd",
      "indices" : [ 0, 7 ],
      "id_str" : "18032208",
      "id" : 18032208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199940506577420289",
  "geo" : { },
  "id_str" : "199942128028221440",
  "in_reply_to_user_id" : 18032208,
  "text" : "@Strabd The HTML and javascript are of course all open source. :) What in particular did you want to read?",
  "id" : 199942128028221440,
  "in_reply_to_status_id" : 199940506577420289,
  "created_at" : "2012-05-08 19:21:32 +0000",
  "in_reply_to_screen_name" : "Strabd",
  "in_reply_to_user_id_str" : "18032208",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phoenix Jones",
      "screen_name" : "ThePhoenixJones",
      "indices" : [ 0, 16 ],
      "id_str" : "241745370",
      "id" : 241745370
    }, {
      "name" : "Rex Velvet",
      "screen_name" : "RexVelvet",
      "indices" : [ 30, 40 ],
      "id_str" : "567772284",
      "id" : 567772284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199733418249035777",
  "geo" : { },
  "id_str" : "199738154390011904",
  "in_reply_to_user_id" : 241745370,
  "text" : "@ThePhoenixJones Why is that? @rexvelvet says you're a fake account. Are you saying I shouldn't trust the villain?",
  "id" : 199738154390011904,
  "in_reply_to_status_id" : 199733418249035777,
  "created_at" : "2012-05-08 05:51:01 +0000",
  "in_reply_to_screen_name" : "ThePhoenixJones",
  "in_reply_to_user_id_str" : "241745370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phoenix Jones",
      "screen_name" : "ThePhoenixJones",
      "indices" : [ 3, 19 ],
      "id_str" : "241745370",
      "id" : 241745370
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 21, 34 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199734141179269120",
  "text" : "RT @ThePhoenixJones: @busterbenson BAD CHOICE",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "199733418249035777",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson BAD CHOICE",
    "id" : 199733418249035777,
    "created_at" : "2012-05-08 05:32:12 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Phoenix Jones",
      "screen_name" : "ThePhoenixJones",
      "protected" : false,
      "id_str" : "241745370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1223153267\/phoenix_normal.jpg",
      "id" : 241745370,
      "verified" : false
    }
  },
  "id" : 199734141179269120,
  "created_at" : "2012-05-08 05:35:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 20, 30 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/hyviDyOm",
      "expanded_url" : "http:\/\/bit.ly\/KhKmYX",
      "display_url" : "bit.ly\/KhKmYX"
    } ]
  },
  "geo" : { },
  "id_str" : "199731621514055681",
  "text" : "Best of luck in SF, @webwright! SF peeps, find a way to meet Tony -- he's awesome. http:\/\/t.co\/hyviDyOm",
  "id" : 199731621514055681,
  "created_at" : "2012-05-08 05:25:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rex Velvet",
      "screen_name" : "RexVelvet",
      "indices" : [ 20, 30 ],
      "id_str" : "567772284",
      "id" : 567772284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199730766094139395",
  "text" : "I think I'm on team @RexVelvet if only because Phoenix Jones doesn't use Twitter. Go Social Villains Alliance!",
  "id" : 199730766094139395,
  "created_at" : "2012-05-08 05:21:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199702431649628161",
  "geo" : { },
  "id_str" : "199721056217481218",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame Probably still only a fraction of the tweets I've retweeted of yours\u2026 so I'm happy to contribute! :)",
  "id" : 199721056217481218,
  "in_reply_to_status_id" : 199702431649628161,
  "created_at" : "2012-05-08 04:43:05 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cat",
      "indices" : [ 48, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/C1Y1wLq7",
      "expanded_url" : "http:\/\/flic.kr\/p\/bUmtVW",
      "display_url" : "flic.kr\/p\/bUmtVW"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "199716879646994432",
  "text" : "8:36pm Slowing this guy down with the Instagram #cat search results http:\/\/t.co\/C1Y1wLq7",
  "id" : 199716879646994432,
  "created_at" : "2012-05-08 04:26:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u0279ds\u0250 \u01DD\u028C\u0250p",
      "screen_name" : "bulletproofexec",
      "indices" : [ 35, 51 ],
      "id_str" : "143882311",
      "id" : 143882311
    }, {
      "name" : "Wren Dougherty",
      "screen_name" : "nancyhd",
      "indices" : [ 131, 139 ],
      "id_str" : "19854731",
      "id" : 19854731
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lifehacking",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/vxxXEDVg",
      "expanded_url" : "http:\/\/bit.ly\/LAmcer",
      "display_url" : "bit.ly\/LAmcer"
    } ]
  },
  "geo" : { },
  "id_str" : "199695947972878337",
  "text" : "I want to start a Mistake Club! RT @bulletproofexec: The Social Power of Sharing Mistakes #lifehacking - http:\/\/t.co\/vxxXEDVg \/via @nancyhd",
  "id" : 199695947972878337,
  "created_at" : "2012-05-08 03:03:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/56gHYhzw",
      "expanded_url" : "http:\/\/bit.ly\/qktU8X",
      "display_url" : "bit.ly\/qktU8X"
    }, {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/IFIS7p80",
      "expanded_url" : "http:\/\/bit.ly\/JauGWB",
      "display_url" : "bit.ly\/JauGWB"
    } ]
  },
  "in_reply_to_status_id_str" : "199688385168814080",
  "geo" : { },
  "id_str" : "199694709206171649",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg http:\/\/t.co\/56gHYhzw though http:\/\/t.co\/IFIS7p80 has a special place in my heart.",
  "id" : 199694709206171649,
  "in_reply_to_status_id" : 199688385168814080,
  "created_at" : "2012-05-08 02:58:23 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199688689989849088",
  "geo" : { },
  "id_str" : "199689615853096961",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april I shop there so rarely that I always forget the coupon. They let you apply them retroactively, I've learned.",
  "id" : 199689615853096961,
  "in_reply_to_status_id" : 199688689989849088,
  "created_at" : "2012-05-08 02:38:09 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Karnjanaprakorn",
      "screen_name" : "mikekarnj",
      "indices" : [ 0, 10 ],
      "id_str" : "5901702",
      "id" : 5901702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199686898950750208",
  "geo" : { },
  "id_str" : "199687724901466112",
  "in_reply_to_user_id" : 5901702,
  "text" : "@mikekarnj How weekly cohort engagement changes week to week and month to month.",
  "id" : 199687724901466112,
  "in_reply_to_status_id" : 199686898950750208,
  "created_at" : "2012-05-08 02:30:38 +0000",
  "in_reply_to_screen_name" : "mikekarnj",
  "in_reply_to_user_id_str" : "5901702",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tristan walker",
      "screen_name" : "tristanwalker",
      "indices" : [ 3, 17 ],
      "id_str" : "18206161",
      "id" : 18206161
    }, {
      "name" : "Quora",
      "screen_name" : "Quora",
      "indices" : [ 139, 140 ],
      "id_str" : "33696409",
      "id" : 33696409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/bAXE7M3W",
      "expanded_url" : "http:\/\/qr.ae\/Raqfw",
      "display_url" : "qr.ae\/Raqfw"
    } ]
  },
  "geo" : { },
  "id_str" : "199686454279028737",
  "text" : "RT @tristanwalker: really great answers! - How effective are the 20% off Bed Bath &amp; Beyond coupons sent via direct mail? 2 Answers:  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.quora.com\/\" rel=\"nofollow\"\u003EQuora\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quora",
        "screen_name" : "Quora",
        "indices" : [ 138, 144 ],
        "id_str" : "33696409",
        "id" : 33696409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/bAXE7M3W",
        "expanded_url" : "http:\/\/qr.ae\/Raqfw",
        "display_url" : "qr.ae\/Raqfw"
      } ]
    },
    "geo" : { },
    "id_str" : "199683830347599872",
    "text" : "really great answers! - How effective are the 20% off Bed Bath &amp; Beyond coupons sent via direct mail? 2 Answers: http:\/\/t.co\/bAXE7M3W @Quora",
    "id" : 199683830347599872,
    "created_at" : "2012-05-08 02:15:09 +0000",
    "user" : {
      "name" : "tristan walker",
      "screen_name" : "tristanwalker",
      "protected" : false,
      "id_str" : "18206161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2336014686\/dlwq9croq965f3l2xkde_normal.png",
      "id" : 18206161,
      "verified" : false
    }
  },
  "id" : 199686454279028737,
  "created_at" : "2012-05-08 02:25:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howard",
      "screen_name" : "digiphile",
      "indices" : [ 3, 13 ],
      "id_str" : "1175221",
      "id" : 1175221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opendata",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/OjRopsHG",
      "expanded_url" : "http:\/\/bit.ly\/J7rBKg",
      "display_url" : "bit.ly\/J7rBKg"
    } ]
  },
  "geo" : { },
  "id_str" : "199681392869773312",
  "text" : "RT @digiphile: \"The explosive growth of the #opendata movement has taught a generation\u2026they have a right to peek behind the curtain\" htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opendata",
        "indices" : [ 29, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/OjRopsHG",
        "expanded_url" : "http:\/\/bit.ly\/J7rBKg",
        "display_url" : "bit.ly\/J7rBKg"
      } ]
    },
    "geo" : { },
    "id_str" : "199536203593289731",
    "text" : "\"The explosive growth of the #opendata movement has taught a generation\u2026they have a right to peek behind the curtain\" http:\/\/t.co\/OjRopsHG",
    "id" : 199536203593289731,
    "created_at" : "2012-05-07 16:28:32 +0000",
    "user" : {
      "name" : "Alex Howard",
      "screen_name" : "digiphile",
      "protected" : false,
      "id_str" : "1175221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3652812617\/0ab8385a2fcfd2a72c792488b118994d_normal.jpeg",
      "id" : 1175221,
      "verified" : false
    }
  },
  "id" : 199681392869773312,
  "created_at" : "2012-05-08 02:05:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Collette",
      "screen_name" : "sfposhy",
      "indices" : [ 0, 8 ],
      "id_str" : "268453413",
      "id" : 268453413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199679324062883841",
  "geo" : { },
  "id_str" : "199680813690916866",
  "in_reply_to_user_id" : 268453413,
  "text" : "@sfposhy You're welcome! I'm probably only 1 or 2 songs further in than you. Liking it so far!",
  "id" : 199680813690916866,
  "in_reply_to_status_id" : 199679324062883841,
  "created_at" : "2012-05-08 02:03:10 +0000",
  "in_reply_to_screen_name" : "sfposhy",
  "in_reply_to_user_id_str" : "268453413",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/UagOswWQ",
      "expanded_url" : "http:\/\/www.npr.org\/2012\/05\/06\/151227631\/first-listen-beach-house-bloom",
      "display_url" : "npr.org\/2012\/05\/06\/151\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "199678714081067010",
  "text" : "I'm a day late to this, but the new Beach House album is available for streaming: http:\/\/t.co\/UagOswWQ",
  "id" : 199678714081067010,
  "created_at" : "2012-05-08 01:54:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrej Gregov",
      "screen_name" : "agregov",
      "indices" : [ 0, 8 ],
      "id_str" : "752413",
      "id" : 752413
    }, {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 9, 20 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199662297692639232",
  "in_reply_to_user_id" : 752413,
  "text" : "@agregov @rgcottrell What's the best way to send beta feedback?",
  "id" : 199662297692639232,
  "created_at" : "2012-05-08 00:49:35 +0000",
  "in_reply_to_screen_name" : "agregov",
  "in_reply_to_user_id_str" : "752413",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/7ADKg0Bi",
      "expanded_url" : "http:\/\/instagr.am\/p\/KWHpXLI0KV\/",
      "display_url" : "instagr.am\/p\/KWHpXLI0KV\/"
    } ]
  },
  "geo" : { },
  "id_str" : "199657661623570433",
  "text" : "Working on technique http:\/\/t.co\/7ADKg0Bi",
  "id" : 199657661623570433,
  "created_at" : "2012-05-08 00:31:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199588772864737280",
  "geo" : { },
  "id_str" : "199622545018859523",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley AWWWWWWWWWESOME.",
  "id" : 199622545018859523,
  "in_reply_to_status_id" : 199588772864737280,
  "created_at" : "2012-05-07 22:11:38 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199562325274005504",
  "in_reply_to_user_id" : 761628,
  "text" : "@rickwebb Happy birthday!",
  "id" : 199562325274005504,
  "created_at" : "2012-05-07 18:12:20 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 3, 12 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "collaboration",
      "indices" : [ 27, 41 ]
    }, {
      "text" : "collaboration",
      "indices" : [ 71, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199552287981568000",
  "text" : "RT @amyjokim: so many good #collaboration essays this morning! I think #collaboration is driving the next wave of connected gaming - wha ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "collaboration",
        "indices" : [ 13, 27 ]
      }, {
        "text" : "collaboration",
        "indices" : [ 57, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "199551764691824641",
    "text" : "so many good #collaboration essays this morning! I think #collaboration is driving the next wave of connected gaming - what do YOU think?",
    "id" : 199551764691824641,
    "created_at" : "2012-05-07 17:30:22 +0000",
    "user" : {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "protected" : false,
      "id_str" : "780991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1789001732\/ajk-headshot2_normal.jpg",
      "id" : 780991,
      "verified" : false
    }
  },
  "id" : 199552287981568000,
  "created_at" : "2012-05-07 17:32:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199550097988653057",
  "geo" : { },
  "id_str" : "199551080491778048",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc You're supposed to just do at least a couple, just to keep the habit going but not enough to tire yourself out.",
  "id" : 199551080491778048,
  "in_reply_to_status_id" : 199550097988653057,
  "created_at" : "2012-05-07 17:27:39 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 95, 111 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199547468688531459",
  "geo" : { },
  "id_str" : "199548326599868416",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc I think I want to make a level that's just 33 pushups a day for 30 days = 1000 pushups. @cjlikearockstar did it.",
  "id" : 199548326599868416,
  "in_reply_to_status_id" : 199547468688531459,
  "created_at" : "2012-05-07 17:16:43 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 26, 36 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/gHZJDPmf",
      "expanded_url" : "http:\/\/www.slideshare.net\/helenjane1",
      "display_url" : "slideshare.net\/helenjane1"
    } ]
  },
  "geo" : { },
  "id_str" : "199538970940538880",
  "text" : "Wow, beautiful slides! RT @helenjane: My slides from Friday's talk about healing from bad internet feelings are up here http:\/\/t.co\/gHZJDPmf",
  "id" : 199538970940538880,
  "created_at" : "2012-05-07 16:39:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/2mg8Y1wT",
      "expanded_url" : "http:\/\/instagr.am\/p\/KT4X_TI0No\/",
      "display_url" : "instagr.am\/p\/KT4X_TI0No\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608614, -122.306069 ]
  },
  "id_str" : "199343028891168769",
  "text" : "8:36pm Lots of running today  @ \uE036Benson Bungalow http:\/\/t.co\/2mg8Y1wT",
  "id" : 199343028891168769,
  "created_at" : "2012-05-07 03:40:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 0, 2 ],
      "id_str" : "11222",
      "id" : 11222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199327146903207936",
  "geo" : { },
  "id_str" : "199328624518774784",
  "in_reply_to_user_id" : 11222,
  "text" : "@k I got about halfway done and then got distracted while I waited for people to update their bios! I'll pick it back up.",
  "id" : 199328624518774784,
  "in_reply_to_status_id" : 199327146903207936,
  "created_at" : "2012-05-07 02:43:42 +0000",
  "in_reply_to_screen_name" : "k",
  "in_reply_to_user_id_str" : "11222",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199317280834850818",
  "text" : "Anyone know any handy dandy gems or web services that can take a list of tweets (or sentences) and pull out trending topics?",
  "id" : 199317280834850818,
  "created_at" : "2012-05-07 01:58:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/8SOsYyuE",
      "expanded_url" : "http:\/\/mobile.theweek.com\/article\/index\/227616\/the-13-year-old-ceo-who-invented-a-cure-for-hiccups",
      "display_url" : "mobile.theweek.com\/article\/index\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "199288178392305666",
  "text" : "This is cute: http:\/\/t.co\/8SOsYyuE",
  "id" : 199288178392305666,
  "created_at" : "2012-05-07 00:02:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    }, {
      "name" : "ryan",
      "screen_name" : "Quality",
      "indices" : [ 67, 75 ],
      "id_str" : "2451996565",
      "id" : 2451996565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199186466310590465",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger Nice grab on the domain, twitter handle, and idea for @quality... need an extra tester?",
  "id" : 199186466310590465,
  "created_at" : "2012-05-06 17:18:48 +0000",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/NzH6CPk6",
      "expanded_url" : "http:\/\/takeaswig.com\/three-key-principles-of-designing-home-run-products",
      "display_url" : "takeaswig.com\/three-key-prin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "199185450882179072",
  "text" : "3 key to designing home run products: provide a novel form of self-expression, make it stupid simple, make it rewarding http:\/\/t.co\/NzH6CPk6",
  "id" : 199185450882179072,
  "created_at" : "2012-05-06 17:14:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 13, 24 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/Aoe0GW2U",
      "expanded_url" : "http:\/\/foursquare.com\/history",
      "display_url" : "foursquare.com\/history"
    } ]
  },
  "geo" : { },
  "id_str" : "199181625861488642",
  "text" : "According to @foursquare's http:\/\/t.co\/Aoe0GW2U, my first check-in was on March 18th, 2005, to Piecora's Pizza (thanks to Dodgeball import).",
  "id" : 199181625861488642,
  "created_at" : "2012-05-06 16:59:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalya Pemberton",
      "screen_name" : "talof2cities",
      "indices" : [ 0, 13 ],
      "id_str" : "62600226",
      "id" : 62600226
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 14, 24 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "supermoon",
      "indices" : [ 25, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199171011495739392",
  "geo" : { },
  "id_str" : "199171477180907520",
  "in_reply_to_user_id" : 62600226,
  "text" : "@talof2cities @kellianne #supermoon was calling all the critters out of their homes.",
  "id" : 199171477180907520,
  "in_reply_to_status_id" : 199171011495739392,
  "created_at" : "2012-05-06 16:19:15 +0000",
  "in_reply_to_screen_name" : "talof2cities",
  "in_reply_to_user_id_str" : "62600226",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy S Lea",
      "screen_name" : "WendySLea",
      "indices" : [ 52, 62 ],
      "id_str" : "6894212",
      "id" : 6894212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/RnpzI50T",
      "expanded_url" : "http:\/\/bit.ly\/IRdJ3S",
      "display_url" : "bit.ly\/IRdJ3S"
    } ]
  },
  "geo" : { },
  "id_str" : "199170385915293696",
  "text" : "Except they're so much better than Yelp already. RT @WendySLea: The Yelpification Of Foursquare http:\/\/t.co\/RnpzI50T",
  "id" : 199170385915293696,
  "created_at" : "2012-05-06 16:14:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198988524001828864",
  "geo" : { },
  "id_str" : "199023306421174272",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Yeah I should probably do that huh.",
  "id" : 199023306421174272,
  "in_reply_to_status_id" : 198988524001828864,
  "created_at" : "2012-05-06 06:30:28 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198983110900191232",
  "geo" : { },
  "id_str" : "199023177790263296",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim Thank you! And I see you just did your tedx talk! How did it go? Will it be online?",
  "id" : 199023177790263296,
  "in_reply_to_status_id" : 198983110900191232,
  "created_at" : "2012-05-06 06:29:57 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    }, {
      "name" : "Leo Babauta",
      "screen_name" : "habitlabs",
      "indices" : [ 54, 64 ],
      "id_str" : "2290777141",
      "id" : 2290777141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/EJN3jAoe",
      "expanded_url" : "http:\/\/bit.ly\/IZMwu0",
      "display_url" : "bit.ly\/IZMwu0"
    } ]
  },
  "in_reply_to_status_id_str" : "198969130437722112",
  "geo" : { },
  "id_str" : "198981319663943681",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Because I'm no longer a 1-person company. @habitlabs and http:\/\/t.co\/EJN3jAoe are where it's at!",
  "id" : 198981319663943681,
  "in_reply_to_status_id" : 198969130437722112,
  "created_at" : "2012-05-06 03:43:38 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/FyFN9DaU",
      "expanded_url" : "http:\/\/instagr.am\/p\/KRTpLFI0E8\/",
      "display_url" : "instagr.am\/p\/KRTpLFI0E8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "198980455947702274",
  "text" : "8:36pm Help hook boat? http:\/\/t.co\/FyFN9DaU",
  "id" : 198980455947702274,
  "created_at" : "2012-05-06 03:40:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanner Christensen",
      "screen_name" : "tannerc",
      "indices" : [ 33, 41 ],
      "id_str" : "9161482",
      "id" : 9161482
    }, {
      "name" : "Lauryn Ballesteros",
      "screen_name" : "heylaurynbee",
      "indices" : [ 46, 59 ],
      "id_str" : "104859844",
      "id" : 104859844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 23, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/fNIe2kDd",
      "expanded_url" : "http:\/\/bit.ly\/JD7ihl",
      "display_url" : "bit.ly\/JD7ihl"
    } ]
  },
  "geo" : { },
  "id_str" : "198924241012408321",
  "text" : "Agreed. Thanks for the #ff tip,  @tannerc! RT @heylaurynbee: F*&amp;! the rules - http:\/\/t.co\/fNIe2kDd",
  "id" : 198924241012408321,
  "created_at" : "2012-05-05 23:56:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Jew",
      "screen_name" : "nancyjew",
      "indices" : [ 0, 9 ],
      "id_str" : "965418434",
      "id" : 965418434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198910086654083073",
  "geo" : { },
  "id_str" : "198921282199355395",
  "in_reply_to_user_id" : 15850163,
  "text" : "@NancyJew Ha. I know the phenomenon well. In you experience does punishment or negative reinforcement provide better results?",
  "id" : 198921282199355395,
  "in_reply_to_status_id" : 198910086654083073,
  "created_at" : "2012-05-05 23:45:04 +0000",
  "in_reply_to_screen_name" : "NicCageMatch",
  "in_reply_to_user_id_str" : "15850163",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Jew",
      "screen_name" : "nancyjew",
      "indices" : [ 0, 9 ],
      "id_str" : "965418434",
      "id" : 965418434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198889396328595456",
  "geo" : { },
  "id_str" : "198901241319919616",
  "in_reply_to_user_id" : 15850163,
  "text" : "@NancyJew Ah, I get it now. Thanks and apologies for misusing the term!",
  "id" : 198901241319919616,
  "in_reply_to_status_id" : 198889396328595456,
  "created_at" : "2012-05-05 22:25:25 +0000",
  "in_reply_to_screen_name" : "NicCageMatch",
  "in_reply_to_user_id_str" : "15850163",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 0, 10 ],
      "id_str" : "10609",
      "id" : 10609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198877168820961280",
  "geo" : { },
  "id_str" : "198887102333722625",
  "in_reply_to_user_id" : 10609,
  "text" : "@superamit You're welcome! I'm very stoked that you like it.",
  "id" : 198887102333722625,
  "in_reply_to_status_id" : 198877168820961280,
  "created_at" : "2012-05-05 21:29:14 +0000",
  "in_reply_to_screen_name" : "superamit",
  "in_reply_to_user_id_str" : "10609",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Jew",
      "screen_name" : "nancyjew",
      "indices" : [ 0, 9 ],
      "id_str" : "965418434",
      "id" : 965418434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198878372326158336",
  "geo" : { },
  "id_str" : "198878721908813826",
  "in_reply_to_user_id" : 15850163,
  "text" : "@NancyJew Interesting, thanks! What's a good example of removing a negative condition to encourage behavior? Dog-training example is okay.",
  "id" : 198878721908813826,
  "in_reply_to_status_id" : 198878372326158336,
  "created_at" : "2012-05-05 20:55:56 +0000",
  "in_reply_to_screen_name" : "NicCageMatch",
  "in_reply_to_user_id_str" : "15850163",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Jew",
      "screen_name" : "nancyjew",
      "indices" : [ 0, 9 ],
      "id_str" : "965418434",
      "id" : 965418434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198875473579737088",
  "in_reply_to_user_id" : 15850163,
  "text" : "@NancyJew How do you think of them differently?",
  "id" : 198875473579737088,
  "created_at" : "2012-05-05 20:43:02 +0000",
  "in_reply_to_screen_name" : "NicCageMatch",
  "in_reply_to_user_id_str" : "15850163",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Explore",
      "screen_name" : "Explorer",
      "indices" : [ 0, 9 ],
      "id_str" : "498328279",
      "id" : 498328279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/zdnNJcOO",
      "expanded_url" : "http:\/\/bustr.me\/post\/22463474050\/a-more-realistic-cynical-take-on-things-taken",
      "display_url" : "bustr.me\/post\/224634740\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "198781352181628928",
  "geo" : { },
  "id_str" : "198855630881165312",
  "in_reply_to_user_id" : 498328279,
  "text" : "@Explorer I added a couple extra steps, since I thought the original trivialized the \"change something\" step a bit: http:\/\/t.co\/zdnNJcOO",
  "id" : 198855630881165312,
  "in_reply_to_status_id" : 198781352181628928,
  "created_at" : "2012-05-05 19:24:11 +0000",
  "in_reply_to_screen_name" : "Explorer",
  "in_reply_to_user_id_str" : "498328279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/U4GVfjwY",
      "expanded_url" : "http:\/\/instagr.am\/p\/KQaS2ao0EK\/",
      "display_url" : "instagr.am\/p\/KQaS2ao0EK\/"
    } ]
  },
  "geo" : { },
  "id_str" : "198854580598091777",
  "text" : "A more realistic (cynical?) take on things http:\/\/t.co\/U4GVfjwY",
  "id" : 198854580598091777,
  "created_at" : "2012-05-05 19:20:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/wCdlhLkY",
      "expanded_url" : "http:\/\/flic.kr\/p\/bEnv5W",
      "display_url" : "flic.kr\/p\/bEnv5W"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.632666, -122.357334 ]
  },
  "id_str" : "198618521440239616",
  "text" : "8:36pm Hanging with friends pre-movie http:\/\/t.co\/wCdlhLkY",
  "id" : 198618521440239616,
  "created_at" : "2012-05-05 03:42:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198610548340961280",
  "text" : "Dog food marinated in fish sauce. Rolled in cayenne pepper.",
  "id" : 198610548340961280,
  "created_at" : "2012-05-05 03:10:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 27, 34 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 36, 49 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198605697951350787",
  "text" : "Best answer so far! Ew. RT @harryh: @busterbenson dry dog food",
  "id" : 198605697951350787,
  "created_at" : "2012-05-05 02:51:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 0, 6 ],
      "id_str" : "5469512",
      "id" : 5469512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198603100565671936",
  "geo" : { },
  "id_str" : "198603677441863681",
  "in_reply_to_user_id" : 5469512,
  "text" : "@micah That's pretty cool. But they're in flavorless coating I think, right?",
  "id" : 198603677441863681,
  "in_reply_to_status_id" : 198603100565671936,
  "created_at" : "2012-05-05 02:43:01 +0000",
  "in_reply_to_screen_name" : "micah",
  "in_reply_to_user_id_str" : "5469512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 0, 6 ],
      "id_str" : "5469512",
      "id" : 5469512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198600276943454208",
  "geo" : { },
  "id_str" : "198601469954490370",
  "in_reply_to_user_id" : 5469512,
  "text" : "@micah That would definitely work! Do they exist?",
  "id" : 198601469954490370,
  "in_reply_to_status_id" : 198600276943454208,
  "created_at" : "2012-05-05 02:34:14 +0000",
  "in_reply_to_screen_name" : "micah",
  "in_reply_to_user_id_str" : "5469512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198600072735367169",
  "text" : "Can you think of a small, cheap, bad tasting, pill-like food item that could be used as self-applied negative reinforcement on-the-go?",
  "id" : 198600072735367169,
  "created_at" : "2012-05-05 02:28:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198526921259225088",
  "geo" : { },
  "id_str" : "198595349902925824",
  "in_reply_to_user_id" : 204025261,
  "text" : "@Michelle_Furedy You're welcome! And great re-meeting you in person yesterday!",
  "id" : 198595349902925824,
  "in_reply_to_status_id" : 198526921259225088,
  "created_at" : "2012-05-05 02:09:55 +0000",
  "in_reply_to_screen_name" : "m_furedy",
  "in_reply_to_user_id_str" : "204025261",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "indices" : [ 3, 14 ],
      "id_str" : "8070502",
      "id" : 8070502
    }, {
      "name" : "Best Thing This Year",
      "screen_name" : "TBTTY",
      "indices" : [ 25, 31 ],
      "id_str" : "570264874",
      "id" : 570264874
    }, {
      "name" : "Best Thing This Year",
      "screen_name" : "TBTTY",
      "indices" : [ 110, 116 ],
      "id_str" : "570264874",
      "id" : 570264874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/MgXurMJK",
      "expanded_url" : "http:\/\/launch.thebestthingthisyear.com\/?lrRef=FVvBl",
      "display_url" : "launch.thebestthingthisyear.com\/?lrRef=FVvBl"
    } ]
  },
  "geo" : { },
  "id_str" : "198545605369405440",
  "text" : "RT @danshapiro: I joined @TBTTY, a mailing list where you can only post once a year. http:\/\/t.co\/MgXurMJK via @TBTTY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Best Thing This Year",
        "screen_name" : "TBTTY",
        "indices" : [ 9, 15 ],
        "id_str" : "570264874",
        "id" : 570264874
      }, {
        "name" : "Best Thing This Year",
        "screen_name" : "TBTTY",
        "indices" : [ 94, 100 ],
        "id_str" : "570264874",
        "id" : 570264874
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/MgXurMJK",
        "expanded_url" : "http:\/\/launch.thebestthingthisyear.com\/?lrRef=FVvBl",
        "display_url" : "launch.thebestthingthisyear.com\/?lrRef=FVvBl"
      } ]
    },
    "geo" : { },
    "id_str" : "198185204077182976",
    "text" : "I joined @TBTTY, a mailing list where you can only post once a year. http:\/\/t.co\/MgXurMJK via @TBTTY",
    "id" : 198185204077182976,
    "created_at" : "2012-05-03 23:00:09 +0000",
    "user" : {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "protected" : false,
      "id_str" : "8070502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/51828452\/eye_pic_normal.jpg",
      "id" : 8070502,
      "verified" : false
    }
  },
  "id" : 198545605369405440,
  "created_at" : "2012-05-04 22:52:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 47, 63 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/CscFi8Bq",
      "expanded_url" : "http:\/\/bit.ly\/J5loJq",
      "display_url" : "bit.ly\/J5loJq"
    } ]
  },
  "geo" : { },
  "id_str" : "198525876667809793",
  "text" : "\"Offline first, mobile enabled.\" Well said! RT @ameliagreenhall: Yes! This is exactly what am excited about building: http:\/\/t.co\/CscFi8Bq",
  "id" : 198525876667809793,
  "created_at" : "2012-05-04 21:33:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matias Corea",
      "screen_name" : "matiascorea",
      "indices" : [ 25, 37 ],
      "id_str" : "38500106",
      "id" : 38500106
    }, {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 117, 121 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198490666286858241",
  "text" : "Them's fightin' words RT @matiascorea: \"Change cannot be planned, just recognized after the fact\" \u2014Jad Abrumad  \/via @msg",
  "id" : 198490666286858241,
  "created_at" : "2012-05-04 19:13:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 0, 11 ],
      "id_str" : "14620776",
      "id" : 14620776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198489130508886016",
  "geo" : { },
  "id_str" : "198490195794984961",
  "in_reply_to_user_id" : 14620776,
  "text" : "@ellenchisa I've tossed that idea around a bit. Would be pretty great if we had the time to put together.",
  "id" : 198490195794984961,
  "in_reply_to_status_id" : 198489130508886016,
  "created_at" : "2012-05-04 19:12:05 +0000",
  "in_reply_to_screen_name" : "ellenchisa",
  "in_reply_to_user_id_str" : "14620776",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "indices" : [ 22, 33 ],
      "id_str" : "419710142",
      "id" : 419710142
    }, {
      "name" : "Trevor Gilbert",
      "screen_name" : "trevoragilbert",
      "indices" : [ 125, 140 ],
      "id_str" : "54185484",
      "id" : 54185484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/IeqkzOHx",
      "expanded_url" : "http:\/\/bit.ly\/L8aN5r",
      "display_url" : "bit.ly\/L8aN5r"
    } ]
  },
  "geo" : { },
  "id_str" : "198487279822577664",
  "text" : "Interesting theory RT @PandoDaily: Press Any Button to Continue: A Story of Seattle\u2019s Gaming Success http:\/\/t.co\/IeqkzOHx by @trevoragilbert",
  "id" : 198487279822577664,
  "created_at" : "2012-05-04 19:00:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber Seattle",
      "screen_name" : "Uber_SEA",
      "indices" : [ 13, 22 ],
      "id_str" : "272162235",
      "id" : 272162235
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gwawards",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/sWSAszrc",
      "expanded_url" : "http:\/\/flic.kr\/p\/bE7Euh",
      "display_url" : "flic.kr\/p\/bE7Euh"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.325334 ]
  },
  "id_str" : "198271216753192960",
  "text" : "8:36pm In my @uber_sea on the way home from #gwawards, happy to have seen some of my fave start-uppers http:\/\/t.co\/sWSAszrc",
  "id" : 198271216753192960,
  "created_at" : "2012-05-04 04:41:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/Zcqojyrg",
      "expanded_url" : "http:\/\/instagr.am\/p\/KMDXgPo0Gm\/",
      "display_url" : "instagr.am\/p\/KMDXgPo0Gm\/"
    } ]
  },
  "geo" : { },
  "id_str" : "198267194948333568",
  "text" : "I didn't win but I was first on the list!  http:\/\/t.co\/Zcqojyrg",
  "id" : 198267194948333568,
  "created_at" : "2012-05-04 04:25:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcelo Calbucci",
      "screen_name" : "calbucci",
      "indices" : [ 66, 75 ],
      "id_str" : "14232711",
      "id" : 14232711
    }, {
      "name" : "Randy Stewart",
      "screen_name" : "stewtopia",
      "indices" : [ 76, 86 ],
      "id_str" : "5651",
      "id" : 5651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gwawards",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/DE3p80bW",
      "expanded_url" : "http:\/\/4sq.com\/K5oyQ4",
      "display_url" : "4sq.com\/K5oyQ4"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6215250123, -122.3481488228 ]
  },
  "id_str" : "198223697759318016",
  "text" : "GeekWire Startup Awards! #gwawards (@ Experience Music Project w\/ @calbucci @stewtopia) http:\/\/t.co\/DE3p80bW",
  "id" : 198223697759318016,
  "created_at" : "2012-05-04 01:33:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Curtis",
      "screen_name" : "dcurtisfeed",
      "indices" : [ 3, 15 ],
      "id_str" : "388479404",
      "id" : 388479404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/SuMWBfDL",
      "expanded_url" : "http:\/\/dcurt.is\/facebooks-numbers",
      "display_url" : "dcurt.is\/facebooks-numb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "198211182912479233",
  "text" : "RT @dcurtisfeed: Facebook's numbers\n\nhttp:\/\/t.co\/SuMWBfDL\n\n(Took a while to compile these, but I find them fascinating.)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 40 ],
        "url" : "http:\/\/t.co\/SuMWBfDL",
        "expanded_url" : "http:\/\/dcurt.is\/facebooks-numbers",
        "display_url" : "dcurt.is\/facebooks-numb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "198210349076451330",
    "text" : "Facebook's numbers\n\nhttp:\/\/t.co\/SuMWBfDL\n\n(Took a while to compile these, but I find them fascinating.)",
    "id" : 198210349076451330,
    "created_at" : "2012-05-04 00:40:04 +0000",
    "user" : {
      "name" : "Dustin Curtis",
      "screen_name" : "dcurtisfeed",
      "protected" : true,
      "id_str" : "388479404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1582126038\/png_normal.png",
      "id" : 388479404,
      "verified" : false
    }
  },
  "id" : 198211182912479233,
  "created_at" : "2012-05-04 00:43:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/eLe9ajNY",
      "expanded_url" : "http:\/\/arstechnica.com\/business\/news\/2012\/05\/exclusive-building-ruby-ios-applications-with-rubymotion.ars",
      "display_url" : "arstechnica.com\/business\/news\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "198210144675434496",
  "text" : "Have any of you Ruby developers out there tried RubyMotion yet? http:\/\/t.co\/eLe9ajNY",
  "id" : 198210144675434496,
  "created_at" : "2012-05-04 00:39:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacob james",
      "screen_name" : "jacoblashes",
      "indices" : [ 0, 12 ],
      "id_str" : "139587142",
      "id" : 139587142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198103549119442944",
  "geo" : { },
  "id_str" : "198103933749702657",
  "in_reply_to_user_id" : 139587142,
  "text" : "@jacoblashes If there was a quick drop off around the corner, would it be tattling on the sidewalk to warn you about it?",
  "id" : 198103933749702657,
  "in_reply_to_status_id" : 198103549119442944,
  "created_at" : "2012-05-03 17:37:13 +0000",
  "in_reply_to_screen_name" : "jacoblashes",
  "in_reply_to_user_id_str" : "139587142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill S.",
      "screen_name" : "outseide",
      "indices" : [ 0, 9 ],
      "id_str" : "143694663",
      "id" : 143694663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198100968108343297",
  "geo" : { },
  "id_str" : "198101886908379136",
  "in_reply_to_user_id" : 143694663,
  "text" : "@outseide Compassion seems to instruct me to say nothing\u2026 to let the past go and hope for the best for everyone involved.",
  "id" : 198101886908379136,
  "in_reply_to_status_id" : 198100968108343297,
  "created_at" : "2012-05-03 17:29:05 +0000",
  "in_reply_to_screen_name" : "outseide",
  "in_reply_to_user_id_str" : "143694663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill S.",
      "screen_name" : "outseide",
      "indices" : [ 0, 9 ],
      "id_str" : "143694663",
      "id" : 143694663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "198100580219101184",
  "geo" : { },
  "id_str" : "198100784687235072",
  "in_reply_to_user_id" : 143694663,
  "text" : "@outseide Maybe that's part of it. I feel like it will reflect back on me as being vindictive and petty.",
  "id" : 198100784687235072,
  "in_reply_to_status_id" : 198100580219101184,
  "created_at" : "2012-05-03 17:24:42 +0000",
  "in_reply_to_screen_name" : "outseide",
  "in_reply_to_user_id_str" : "143694663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/X97ACkR4",
      "expanded_url" : "http:\/\/bustr.me\/post\/22327002049\/in-the-book-training-the-emotional-brain-i",
      "display_url" : "bustr.me\/post\/223270020\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "198100616680181763",
  "text" : "6 emotional styles: http:\/\/t.co\/X97ACkR4",
  "id" : 198100616680181763,
  "created_at" : "2012-05-03 17:24:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198098579636764672",
  "text" : "Why does it feel like poor form to proactively spread info about bad behavior by other people to those who might benefit from its use?",
  "id" : 198098579636764672,
  "created_at" : "2012-05-03 17:15:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "indices" : [ 27, 37 ],
      "id_str" : "14326765",
      "id" : 14326765
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gwawards",
      "indices" : [ 54, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/tRbAiB2w",
      "expanded_url" : "http:\/\/www.geekwire.com\/events\/geekwire-presents-seattle-20-startup-awards\/",
      "display_url" : "geekwire.com\/events\/geekwir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "198096686898356224",
  "text" : "I'm going! Who else is? RT @johnhcook: We'll be using #gwawards for the big GeekWire Startup Awards bash tonight. 6pm! http:\/\/t.co\/tRbAiB2w",
  "id" : 198096686898356224,
  "created_at" : "2012-05-03 17:08:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Deterding",
      "screen_name" : "dingstweets",
      "indices" : [ 3, 15 ],
      "id_str" : "14435477",
      "id" : 14435477
    }, {
      "name" : "Institute of Play",
      "screen_name" : "instituteofplay",
      "indices" : [ 139, 140 ],
      "id_str" : "14947998",
      "id" : 14947998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/2JNLPsNL",
      "expanded_url" : "http:\/\/j.mp\/IHZtx3",
      "display_url" : "j.mp\/IHZtx3"
    } ]
  },
  "geo" : { },
  "id_str" : "198067906377031681",
  "text" : "RT @dingstweets: GOGOYU, a video game where your power bar is fuelled by real-world steps measured by a Fitbit http:\/\/t.co\/2JNLPsNL via  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Institute of Play",
        "screen_name" : "instituteofplay",
        "indices" : [ 119, 135 ],
        "id_str" : "14947998",
        "id" : 14947998
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/2JNLPsNL",
        "expanded_url" : "http:\/\/j.mp\/IHZtx3",
        "display_url" : "j.mp\/IHZtx3"
      } ]
    },
    "geo" : { },
    "id_str" : "198060946340577282",
    "text" : "GOGOYU, a video game where your power bar is fuelled by real-world steps measured by a Fitbit http:\/\/t.co\/2JNLPsNL via @instituteofplay",
    "id" : 198060946340577282,
    "created_at" : "2012-05-03 14:46:24 +0000",
    "user" : {
      "name" : "Sebastian Deterding",
      "screen_name" : "dingstweets",
      "protected" : false,
      "id_str" : "14435477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/279099712\/GMDH02_00721_normal.png",
      "id" : 14435477,
      "verified" : false
    }
  },
  "id" : 198067906377031681,
  "created_at" : "2012-05-03 15:14:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Anderson",
      "screen_name" : "stephenanderson",
      "indices" : [ 0, 16 ],
      "id_str" : "356663",
      "id" : 356663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197902903011315713",
  "geo" : { },
  "id_str" : "197903822738300928",
  "in_reply_to_user_id" : 356663,
  "text" : "@stephenanderson Ah I get it.",
  "id" : 197903822738300928,
  "in_reply_to_status_id" : 197902903011315713,
  "created_at" : "2012-05-03 04:22:02 +0000",
  "in_reply_to_screen_name" : "stephenanderson",
  "in_reply_to_user_id_str" : "356663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Anderson",
      "screen_name" : "stephenanderson",
      "indices" : [ 0, 16 ],
      "id_str" : "356663",
      "id" : 356663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197900740134584320",
  "geo" : { },
  "id_str" : "197901407448338432",
  "in_reply_to_user_id" : 356663,
  "text" : "@stephenanderson Flow perhaps?",
  "id" : 197901407448338432,
  "in_reply_to_status_id" : 197900740134584320,
  "created_at" : "2012-05-03 04:12:27 +0000",
  "in_reply_to_screen_name" : "stephenanderson",
  "in_reply_to_user_id_str" : "356663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/SNWWX8vU",
      "expanded_url" : "http:\/\/flic.kr\/p\/bSJCM6",
      "display_url" : "flic.kr\/p\/bSJCM6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "197893498807132160",
  "text" : "8:36pm Ingo! http:\/\/t.co\/SNWWX8vU",
  "id" : 197893498807132160,
  "created_at" : "2012-05-03 03:41:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 15, 24 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "Jason Jacobs",
      "screen_name" : "jjacobs22",
      "indices" : [ 97, 107 ],
      "id_str" : "14850356",
      "id" : 14850356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/83FRonRy",
      "expanded_url" : "http:\/\/bit.ly\/IAxjk8",
      "display_url" : "bit.ly\/IAxjk8"
    } ]
  },
  "geo" : { },
  "id_str" : "197883599251447808",
  "text" : "I want one! RT @agaricus: \"...a shirt that knows when you're slacking off on your workout.\" \/via @jjacobs22 http:\/\/t.co\/83FRonRy",
  "id" : 197883599251447808,
  "created_at" : "2012-05-03 03:01:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    }, {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 81, 97 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197859404333326336",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april To see if we can be trained to associate a tiny treat with the habit. @ameliagreenhall and I like orange too.",
  "id" : 197859404333326336,
  "created_at" : "2012-05-03 01:25:32 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah craig",
      "screen_name" : "micahcraig",
      "indices" : [ 0, 11 ],
      "id_str" : "6462772",
      "id" : 6462772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197849878674669568",
  "geo" : { },
  "id_str" : "197850724955209728",
  "in_reply_to_user_id" : 6462772,
  "text" : "@micahcraig Personally, I don't think it matters if the trigger is internal or external. The key is that you do the habit without struggle.",
  "id" : 197850724955209728,
  "in_reply_to_status_id" : 197849878674669568,
  "created_at" : "2012-05-03 00:51:03 +0000",
  "in_reply_to_screen_name" : "micahcraig",
  "in_reply_to_user_id_str" : "6462772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not all math",
      "screen_name" : "mathpunk",
      "indices" : [ 0, 9 ],
      "id_str" : "7621482",
      "id" : 7621482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197848242153734145",
  "geo" : { },
  "id_str" : "197848691778916352",
  "in_reply_to_user_id" : 7621482,
  "text" : "@mathpunk I've heard that a couple times. And usually I have that reaction to things too. Not sure how to get around that.",
  "id" : 197848691778916352,
  "in_reply_to_status_id" : 197848242153734145,
  "created_at" : "2012-05-03 00:42:58 +0000",
  "in_reply_to_screen_name" : "mathpunk",
  "in_reply_to_user_id_str" : "7621482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/FvSLKIdJ",
      "expanded_url" : "http:\/\/instagr.am\/p\/KJQlrpI0Et\/",
      "display_url" : "instagr.am\/p\/KJQlrpI0Et\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6237378053, -122.336111069 ]
  },
  "id_str" : "197847748597399553",
  "text" : "Just noticed that my habits are becoming increasingly iPhone alarm triggered  @ Habit Labs HQ http:\/\/t.co\/FvSLKIdJ",
  "id" : 197847748597399553,
  "created_at" : "2012-05-03 00:39:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fillintheblank",
      "indices" : [ 56, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197838495723683841",
  "text" : "Quick survey: \"I'm desperate for more ____ in my life.\" #fillintheblank",
  "id" : 197838495723683841,
  "created_at" : "2012-05-03 00:02:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 3, 19 ],
      "id_str" : "246531241",
      "id" : 246531241
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 66, 79 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197829220301406208",
  "text" : "RT @ameliagreenhall: Started a meditation+bribery experiment with @busterbenson. Alarm at 2pm. Immediately meditate for 10 min. Immediat ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 45, 58 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197829080899518464",
    "text" : "Started a meditation+bribery experiment with @busterbenson. Alarm at 2pm. Immediately meditate for 10 min. Immediately eat a tic-tac.",
    "id" : 197829080899518464,
    "created_at" : "2012-05-02 23:25:03 +0000",
    "user" : {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "protected" : false,
      "id_str" : "246531241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446808446180937728\/GZ5tskw1_normal.jpeg",
      "id" : 246531241,
      "verified" : false
    }
  },
  "id" : 197829220301406208,
  "created_at" : "2012-05-02 23:25:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197790478870122496",
  "geo" : { },
  "id_str" : "197814847503728642",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame And maybe all help you change products should start with the question \"what are you desperately seeking?\"",
  "id" : 197814847503728642,
  "in_reply_to_status_id" : 197790478870122496,
  "created_at" : "2012-05-02 22:28:29 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Krauska",
      "screen_name" : "gregkrauska",
      "indices" : [ 0, 12 ],
      "id_str" : "19000518",
      "id" : 19000518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197791520080924672",
  "geo" : { },
  "id_str" : "197814216990789632",
  "in_reply_to_user_id" : 19000518,
  "text" : "@gregkrauska No research. Just a hunch.",
  "id" : 197814216990789632,
  "in_reply_to_status_id" : 197791520080924672,
  "created_at" : "2012-05-02 22:25:59 +0000",
  "in_reply_to_screen_name" : "gregkrauska",
  "in_reply_to_user_id_str" : "19000518",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 44, 55 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/wtBinlRD",
      "expanded_url" : "http:\/\/4sq.com\/Kvfq4B",
      "display_url" : "4sq.com\/Kvfq4B"
    } ]
  },
  "geo" : { },
  "id_str" : "197799067378651136",
  "text" : "I just unlocked the \"Century Club\" badge on @foursquare! http:\/\/t.co\/wtBinlRD",
  "id" : 197799067378651136,
  "created_at" : "2012-05-02 21:25:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "geoffclapp",
      "screen_name" : "geoffclapp",
      "indices" : [ 3, 14 ],
      "id_str" : "12118392",
      "id" : 12118392
    }, {
      "name" : "Lifehacker",
      "screen_name" : "lifehacker",
      "indices" : [ 95, 106 ],
      "id_str" : "7144422",
      "id" : 7144422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/NPs96HQw",
      "expanded_url" : "http:\/\/lifehacker.com\/5585217\/what-caffeine-actually-does-to-your-brain",
      "display_url" : "lifehacker.com\/5585217\/what-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "197790140679192577",
  "text" : "RT @geoffclapp: Nice \"over coffee\" reading. Zing!  What Caffeine Actually Does to Your Brain - @Lifehacker http:\/\/t.co\/NPs96HQw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lifehacker",
        "screen_name" : "lifehacker",
        "indices" : [ 79, 90 ],
        "id_str" : "7144422",
        "id" : 7144422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/NPs96HQw",
        "expanded_url" : "http:\/\/lifehacker.com\/5585217\/what-caffeine-actually-does-to-your-brain",
        "display_url" : "lifehacker.com\/5585217\/what-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "197785946320678912",
    "text" : "Nice \"over coffee\" reading. Zing!  What Caffeine Actually Does to Your Brain - @Lifehacker http:\/\/t.co\/NPs96HQw",
    "id" : 197785946320678912,
    "created_at" : "2012-05-02 20:33:38 +0000",
    "user" : {
      "name" : "geoffclapp",
      "screen_name" : "geoffclapp",
      "protected" : false,
      "id_str" : "12118392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2720530979\/f2cc797a0dd566445606ab6b5a462b57_normal.png",
      "id" : 12118392,
      "verified" : false
    }
  },
  "id" : 197790140679192577,
  "created_at" : "2012-05-02 20:50:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197766696889614336",
  "text" : "Desperation comes from feeling trapped. One way to feel trapped is to repeatedly fail. Fear of failure prevents desperation from growing.",
  "id" : 197766696889614336,
  "created_at" : "2012-05-02 19:17:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197766009178947586",
  "text" : "The unacknowledged key to habit change is desperation. Tools and plans can't create desperation, they can only channel it.",
  "id" : 197766009178947586,
  "created_at" : "2012-05-02 19:14:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tristan walker",
      "screen_name" : "tristanwalker",
      "indices" : [ 0, 14 ],
      "id_str" : "18206161",
      "id" : 18206161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197704643088887808",
  "geo" : { },
  "id_str" : "197759391322222594",
  "in_reply_to_user_id" : 18206161,
  "text" : "@tristanwalker Bummed that you're leaving Foursquare! But excited to see what you do next\u2026 best of luck!",
  "id" : 197759391322222594,
  "in_reply_to_status_id" : 197704643088887808,
  "created_at" : "2012-05-02 18:48:07 +0000",
  "in_reply_to_screen_name" : "tristanwalker",
  "in_reply_to_user_id_str" : "18206161",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wren Dougherty",
      "screen_name" : "nancyhd",
      "indices" : [ 3, 11 ],
      "id_str" : "19854731",
      "id" : 19854731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/Wm3ncaCc",
      "expanded_url" : "http:\/\/shar.es\/2qLHA",
      "display_url" : "shar.es\/2qLHA"
    } ]
  },
  "geo" : { },
  "id_str" : "197756207740620800",
  "text" : "RT @nancyhd: Apple Store now sells Sanofi\u2019s iPhone glucose meter http:\/\/t.co\/Wm3ncaCc - cool, but still dependent on expensive test stri ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/Wm3ncaCc",
        "expanded_url" : "http:\/\/shar.es\/2qLHA",
        "display_url" : "shar.es\/2qLHA"
      } ]
    },
    "geo" : { },
    "id_str" : "197753864185847810",
    "text" : "Apple Store now sells Sanofi\u2019s iPhone glucose meter http:\/\/t.co\/Wm3ncaCc - cool, but still dependent on expensive test strips...",
    "id" : 197753864185847810,
    "created_at" : "2012-05-02 18:26:09 +0000",
    "user" : {
      "name" : "Wren Dougherty",
      "screen_name" : "nancyhd",
      "protected" : false,
      "id_str" : "19854731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1451822893\/profilepic_normal.jpg",
      "id" : 19854731,
      "verified" : false
    }
  },
  "id" : 197756207740620800,
  "created_at" : "2012-05-02 18:35:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SoundCloud",
      "screen_name" : "SoundCloud",
      "indices" : [ 67, 78 ],
      "id_str" : "5943942",
      "id" : 5943942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/NpUCGy6p",
      "expanded_url" : "http:\/\/soundcloud.com\/metric-band\/youth-without-youth?utm_source=soundcloud&utm_campaign=wtshare&utm_medium=twitter&utm_content=http:\/\/soundcloud.com\/metric-band\/youth-without-youth",
      "display_url" : "soundcloud.com\/metric-band\/yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "197700689282072576",
  "text" : "A new Metric song! \"Youth Without Youth\" http:\/\/t.co\/NpUCGy6p \/via @soundcloud",
  "id" : 197700689282072576,
  "created_at" : "2012-05-02 14:54:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeVore",
      "screen_name" : "crashdev",
      "indices" : [ 3, 12 ],
      "id_str" : "14763501",
      "id" : 14763501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/tKd0wZDu",
      "expanded_url" : "http:\/\/www.geekwire.com\/2012\/seattle-vcs-invest-15m-techstars-supporting-years-startup-incubation\/",
      "display_url" : "geekwire.com\/2012\/seattle-v\u2026"
    }, {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/Yb0asfve",
      "expanded_url" : "http:\/\/apply.techstars.com\/",
      "display_url" : "apply.techstars.com"
    } ]
  },
  "geo" : { },
  "id_str" : "197587454415486976",
  "text" : "RT @crashdev: PNW startups, we want you!! Seattle VCs invest in TechStars: http:\/\/t.co\/tKd0wZDu APPLY NOW! http:\/\/t.co\/Yb0asfve",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/tKd0wZDu",
        "expanded_url" : "http:\/\/www.geekwire.com\/2012\/seattle-vcs-invest-15m-techstars-supporting-years-startup-incubation\/",
        "display_url" : "geekwire.com\/2012\/seattle-v\u2026"
      }, {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/Yb0asfve",
        "expanded_url" : "http:\/\/apply.techstars.com\/",
        "display_url" : "apply.techstars.com"
      } ]
    },
    "geo" : { },
    "id_str" : "197560323526496256",
    "text" : "PNW startups, we want you!! Seattle VCs invest in TechStars: http:\/\/t.co\/tKd0wZDu APPLY NOW! http:\/\/t.co\/Yb0asfve",
    "id" : 197560323526496256,
    "created_at" : "2012-05-02 05:37:06 +0000",
    "user" : {
      "name" : "Chris DeVore",
      "screen_name" : "crashdev",
      "protected" : false,
      "id_str" : "14763501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1575672961\/CHD_Headshot_normal.png",
      "id" : 14763501,
      "verified" : false
    }
  },
  "id" : 197587454415486976,
  "created_at" : "2012-05-02 07:24:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The ParisLemon Feed",
      "screen_name" : "lemonfeed",
      "indices" : [ 3, 13 ],
      "id_str" : "134665872",
      "id" : 134665872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/kkmCxZ2j",
      "expanded_url" : "http:\/\/goo.gl\/fb\/Ygkyq",
      "display_url" : "goo.gl\/fb\/Ygkyq"
    } ]
  },
  "geo" : { },
  "id_str" : "197587293828165632",
  "text" : "RT @lemonfeed: iWatch http:\/\/t.co\/kkmCxZ2j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 7, 27 ],
        "url" : "http:\/\/t.co\/kkmCxZ2j",
        "expanded_url" : "http:\/\/goo.gl\/fb\/Ygkyq",
        "display_url" : "goo.gl\/fb\/Ygkyq"
      } ]
    },
    "geo" : { },
    "id_str" : "197565028059189248",
    "text" : "iWatch http:\/\/t.co\/kkmCxZ2j",
    "id" : 197565028059189248,
    "created_at" : "2012-05-02 05:55:47 +0000",
    "user" : {
      "name" : "The ParisLemon Feed",
      "screen_name" : "lemonfeed",
      "protected" : false,
      "id_str" : "134665872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2405378480\/wyfe7zgoz04cynk6zld0_normal.jpeg",
      "id" : 134665872,
      "verified" : false
    }
  },
  "id" : 197587293828165632,
  "created_at" : "2012-05-02 07:24:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/WEhfJbUV",
      "expanded_url" : "http:\/\/flic.kr\/p\/bSs2Za",
      "display_url" : "flic.kr\/p\/bSs2Za"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608, -122.299667 ]
  },
  "id_str" : "197548310008049665",
  "text" : "8:36pm Burgers and tots http:\/\/t.co\/WEhfJbUV",
  "id" : 197548310008049665,
  "created_at" : "2012-05-02 04:49:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Ostrowski",
      "screen_name" : "chadoh",
      "indices" : [ 0, 7 ],
      "id_str" : "28033358",
      "id" : 28033358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197511655498846208",
  "geo" : { },
  "id_str" : "197512614266408960",
  "in_reply_to_user_id" : 28033358,
  "text" : "@chadoh Interesting! Any idea what changed in a delayed manner?",
  "id" : 197512614266408960,
  "in_reply_to_status_id" : 197511655498846208,
  "created_at" : "2012-05-02 02:27:31 +0000",
  "in_reply_to_screen_name" : "chadoh",
  "in_reply_to_user_id_str" : "28033358",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Park",
      "screen_name" : "charliepark",
      "indices" : [ 0, 12 ],
      "id_str" : "3225381",
      "id" : 3225381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197487995945889792",
  "geo" : { },
  "id_str" : "197494873119653888",
  "in_reply_to_user_id" : 3225381,
  "text" : "@charliepark Let me know if you do write it up. I'll likely do the same as I think about it some more...",
  "id" : 197494873119653888,
  "in_reply_to_status_id" : 197487995945889792,
  "created_at" : "2012-05-02 01:17:01 +0000",
  "in_reply_to_screen_name" : "charliepark",
  "in_reply_to_user_id_str" : "3225381",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sammy Larbi",
      "screen_name" : "codeodor",
      "indices" : [ 0, 9 ],
      "id_str" : "7853992",
      "id" : 7853992
    }, {
      "name" : "BJ Fogg",
      "screen_name" : "bjfogg",
      "indices" : [ 28, 35 ],
      "id_str" : "1118691",
      "id" : 1118691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197486427343306753",
  "geo" : { },
  "id_str" : "197487117021085696",
  "in_reply_to_user_id" : 7853992,
  "text" : "@codeodor Oh yeah, I'd love @bjfogg's data on the matter. BJ, are iPhone alarms a reliable trigger for starting tiny habits?",
  "id" : 197487117021085696,
  "in_reply_to_status_id" : 197486427343306753,
  "created_at" : "2012-05-02 00:46:12 +0000",
  "in_reply_to_screen_name" : "codeodor",
  "in_reply_to_user_id_str" : "7853992",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Babauta",
      "screen_name" : "zen_habits",
      "indices" : [ 8, 19 ],
      "id_str" : "15859268",
      "id" : 15859268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197485943404511232",
  "text" : "I asked @zen_habits about whether phone alarms are good triggers for starting daily habits. I think so, he's not so sure. Thoughts?",
  "id" : 197485943404511232,
  "created_at" : "2012-05-02 00:41:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jorge Sanz",
      "screen_name" : "xurxosanz",
      "indices" : [ 0, 10 ],
      "id_str" : "14291056",
      "id" : 14291056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/Q4TfmZZc",
      "expanded_url" : "http:\/\/750words.com\/help\/request_helpand",
      "display_url" : "750words.com\/help\/request_h\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "197390411671670784",
  "geo" : { },
  "id_str" : "197410873348849664",
  "in_reply_to_user_id" : 14291056,
  "text" : "@xurxosanz Go to http:\/\/t.co\/Q4TfmZZc we can fix it for ya!",
  "id" : 197410873348849664,
  "in_reply_to_status_id" : 197390411671670784,
  "created_at" : "2012-05-01 19:43:14 +0000",
  "in_reply_to_screen_name" : "xurxosanz",
  "in_reply_to_user_id_str" : "14291056",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grandin Donovan",
      "screen_name" : "grandin",
      "indices" : [ 0, 8 ],
      "id_str" : "812245",
      "id" : 812245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197290799296299008",
  "geo" : { },
  "id_str" : "197335141285236736",
  "in_reply_to_user_id" : 812245,
  "text" : "@grandin Yes, it's still the best place and I do read them all but haven't had much time to work on it of late. Hope to fix that soon!",
  "id" : 197335141285236736,
  "in_reply_to_status_id" : 197290799296299008,
  "created_at" : "2012-05-01 14:42:18 +0000",
  "in_reply_to_screen_name" : "grandin",
  "in_reply_to_user_id_str" : "812245",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/a5iTEELR",
      "expanded_url" : "http:\/\/www.geekwire.com\/2012\/seomoz-raises-18-million-brad-feld-joining-board-deal-closed\/",
      "display_url" : "geekwire.com\/2012\/seomoz-ra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "197334785515991042",
  "text" : "The SEO company I can actually love. http:\/\/t.co\/a5iTEELR",
  "id" : 197334785515991042,
  "created_at" : "2012-05-01 14:40:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "news.yc Popular",
      "screen_name" : "newsycombinator",
      "indices" : [ 45, 61 ],
      "id_str" : "14335498",
      "id" : 14335498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/vmF4N7tf",
      "expanded_url" : "http:\/\/bit.ly\/InB9gy",
      "display_url" : "bit.ly\/InB9gy"
    } ]
  },
  "geo" : { },
  "id_str" : "197332578091544576",
  "text" : "This small detail makes a huge difference RT @newsycombinator: Why Instagram is so fast at uploading photos http:\/\/t.co\/vmF4N7tf",
  "id" : 197332578091544576,
  "created_at" : "2012-05-01 14:32:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 3, 13 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/avantgame\/status\/197307680073859074\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/wHpmhfke",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Arz6SiaCQAIvbUz.png",
      "id_str" : "197307680078053378",
      "id" : 197307680078053378,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Arz6SiaCQAIvbUz.png",
      "sizes" : [ {
        "h" : 793,
        "resize" : "fit",
        "w" : 883
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 539,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 793,
        "resize" : "fit",
        "w" : 883
      } ],
      "display_url" : "pic.twitter.com\/wHpmhfke"
    } ],
    "hashtags" : [ {
      "text" : "ThankYouGame",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/Qt61pp18",
      "expanded_url" : "http:\/\/www.facebook.com\/ownTV\/app_219838831450129",
      "display_url" : "facebook.com\/ownTV\/app_2198\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "197308929343094785",
  "text" : "RT @avantgame: It only took 10 hours to spread gratitude to our first million! play #ThankYouGame with us http:\/\/t.co\/Qt61pp18 http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/avantgame\/status\/197307680073859074\/photo\/1",
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/wHpmhfke",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Arz6SiaCQAIvbUz.png",
        "id_str" : "197307680078053378",
        "id" : 197307680078053378,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Arz6SiaCQAIvbUz.png",
        "sizes" : [ {
          "h" : 793,
          "resize" : "fit",
          "w" : 883
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 305,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 539,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 793,
          "resize" : "fit",
          "w" : 883
        } ],
        "display_url" : "pic.twitter.com\/wHpmhfke"
      } ],
      "hashtags" : [ {
        "text" : "ThankYouGame",
        "indices" : [ 69, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/Qt61pp18",
        "expanded_url" : "http:\/\/www.facebook.com\/ownTV\/app_219838831450129",
        "display_url" : "facebook.com\/ownTV\/app_2198\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "197307680073859074",
    "text" : "It only took 10 hours to spread gratitude to our first million! play #ThankYouGame with us http:\/\/t.co\/Qt61pp18 http:\/\/t.co\/wHpmhfke",
    "id" : 197307680073859074,
    "created_at" : "2012-05-01 12:53:12 +0000",
    "user" : {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "protected" : false,
      "id_str" : "681813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000116152853\/47c4501ee2d80e97b423129fe0db016a_normal.jpeg",
      "id" : 681813,
      "verified" : false
    }
  },
  "id" : 197308929343094785,
  "created_at" : "2012-05-01 12:58:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]