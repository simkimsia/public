Grailbird.data.tweets_2012_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/Sz0CzQIq",
      "expanded_url" : "http:\/\/flic.kr\/p\/coG1p1",
      "display_url" : "flic.kr\/p\/coG1p1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "219287571094704130",
  "text" : "8:36pm Working on slides http:\/\/t.co\/Sz0CzQIq",
  "id" : 219287571094704130,
  "created_at" : "2012-07-01 04:33:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Azumio Inc.",
      "screen_name" : "azumioinc",
      "indices" : [ 0, 10 ],
      "id_str" : "252827423",
      "id" : 252827423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219233900545847297",
  "geo" : { },
  "id_str" : "219272738567766017",
  "in_reply_to_user_id" : 252827423,
  "text" : "@azumioinc That's awesome. Now if only I could access that export programatically!",
  "id" : 219272738567766017,
  "in_reply_to_status_id" : 219233900545847297,
  "created_at" : "2012-07-01 03:34:29 +0000",
  "in_reply_to_screen_name" : "azumioinc",
  "in_reply_to_user_id_str" : "252827423",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sessions",
      "screen_name" : "joinsessions",
      "indices" : [ 3, 16 ],
      "id_str" : "360907906",
      "id" : 360907906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/tj9abzni",
      "expanded_url" : "http:\/\/nyti.ms\/KTJVGK",
      "display_url" : "nyti.ms\/KTJVGK"
    } ]
  },
  "geo" : { },
  "id_str" : "219232022231654400",
  "text" : "RT @joinsessions: All calories are not alike! Small changes in diet can bring huge benefits. http:\/\/t.co\/tj9abzni",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/tj9abzni",
        "expanded_url" : "http:\/\/nyti.ms\/KTJVGK",
        "display_url" : "nyti.ms\/KTJVGK"
      } ]
    },
    "geo" : { },
    "id_str" : "219229762038669312",
    "text" : "All calories are not alike! Small changes in diet can bring huge benefits. http:\/\/t.co\/tj9abzni",
    "id" : 219229762038669312,
    "created_at" : "2012-07-01 00:43:43 +0000",
    "user" : {
      "name" : "Sessions",
      "screen_name" : "joinsessions",
      "protected" : false,
      "id_str" : "360907906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000569225412\/dbd0e03c64156367fe37ee996bb4da6b_normal.png",
      "id" : 360907906,
      "verified" : false
    }
  },
  "id" : 219232022231654400,
  "created_at" : "2012-07-01 00:52:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219228206895607808",
  "text" : "Nothing is black-and-white, including this statement.",
  "id" : 219228206895607808,
  "created_at" : "2012-07-01 00:37:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Burkeman",
      "screen_name" : "oliverburkeman",
      "indices" : [ 73, 88 ],
      "id_str" : "112037009",
      "id" : 112037009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/jogaacdk",
      "expanded_url" : "http:\/\/bit.ly\/N8lDpG",
      "display_url" : "bit.ly\/N8lDpG"
    } ]
  },
  "geo" : { },
  "id_str" : "219224097689845762",
  "text" : "This is hilarious. What are your unsung skills? http:\/\/t.co\/jogaacdk \/by @oliverburkeman",
  "id" : 219224097689845762,
  "created_at" : "2012-07-01 00:21:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Bold Academy",
      "screen_name" : "BoldAcademy",
      "indices" : [ 56, 68 ],
      "id_str" : "502177948",
      "id" : 502177948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/DFKWmgPu",
      "expanded_url" : "http:\/\/instagr.am\/p\/Mg6tq_o0Ct\/",
      "display_url" : "instagr.am\/p\/Mg6tq_o0Ct\/"
    } ]
  },
  "geo" : { },
  "id_str" : "219192103241134080",
  "text" : "List of behavior change projects I've worked on, for my @boldacademy talk next week http:\/\/t.co\/DFKWmgPu",
  "id" : 219192103241134080,
  "created_at" : "2012-06-30 22:14:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/RpCtzbod",
      "expanded_url" : "http:\/\/flic.kr\/p\/comjUb",
      "display_url" : "flic.kr\/p\/comjUb"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.595333, -122.306667 ]
  },
  "id_str" : "219089242238889984",
  "text" : "8:36pm from last night. Eating with Joe and Venessa helping them raise money for their new food truck, Pickle http:\/\/t.co\/RpCtzbod",
  "id" : 219089242238889984,
  "created_at" : "2012-06-30 15:25:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Ariely",
      "screen_name" : "danariely",
      "indices" : [ 3, 13 ],
      "id_str" : "17997789",
      "id" : 17997789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/ETFO8kCx",
      "expanded_url" : "http:\/\/read.bi\/LGijpT",
      "display_url" : "read.bi\/LGijpT"
    } ]
  },
  "geo" : { },
  "id_str" : "218883364885770240",
  "text" : "RT @danariely: 54 Smart Thinkers Everyone Should Follow On Twitter.  Why #3? http:\/\/t.co\/ETFO8kCx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/ETFO8kCx",
        "expanded_url" : "http:\/\/read.bi\/LGijpT",
        "display_url" : "read.bi\/LGijpT"
      } ]
    },
    "geo" : { },
    "id_str" : "218875123476865025",
    "text" : "54 Smart Thinkers Everyone Should Follow On Twitter.  Why #3? http:\/\/t.co\/ETFO8kCx",
    "id" : 218875123476865025,
    "created_at" : "2012-06-30 01:14:30 +0000",
    "user" : {
      "name" : "Dan Ariely",
      "screen_name" : "danariely",
      "protected" : false,
      "id_str" : "17997789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3079991122\/885ba5efe97fcfd916001b8374d0d75c_normal.jpeg",
      "id" : 17997789,
      "verified" : false
    }
  },
  "id" : 218883364885770240,
  "created_at" : "2012-06-30 01:47:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 0, 8 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/QYugOvuu",
      "expanded_url" : "http:\/\/bit.ly\/MH9Dhl",
      "display_url" : "bit.ly\/MH9Dhl"
    } ]
  },
  "in_reply_to_status_id_str" : "218859207791869953",
  "geo" : { },
  "id_str" : "218862737143513088",
  "in_reply_to_user_id" : 9395832,
  "text" : "@dcurtis That\u2019s awesome! You should host that file on Github, like this:  http:\/\/t.co\/QYugOvuu\n\nI\u2019m gonna add predictions.txt soon too.",
  "id" : 218862737143513088,
  "in_reply_to_status_id" : 218859207791869953,
  "created_at" : "2012-06-30 00:25:17 +0000",
  "in_reply_to_screen_name" : "dcurtis",
  "in_reply_to_user_id_str" : "9395832",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Bold Academy",
      "screen_name" : "BoldAcademy",
      "indices" : [ 0, 12 ],
      "id_str" : "502177948",
      "id" : 502177948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218853954698756096",
  "geo" : { },
  "id_str" : "218854765122162688",
  "in_reply_to_user_id" : 502177948,
  "text" : "@BoldAcademy Looking forward to next week! See you Wednesday!",
  "id" : 218854765122162688,
  "in_reply_to_status_id" : 218853954698756096,
  "created_at" : "2012-06-29 23:53:36 +0000",
  "in_reply_to_screen_name" : "BoldAcademy",
  "in_reply_to_user_id_str" : "502177948",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Gretsch",
      "screen_name" : "greggretsch",
      "indices" : [ 3, 15 ],
      "id_str" : "26802954",
      "id" : 26802954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218846461448818688",
  "text" : "RT @greggretsch: Since release of iPhone 5 years ago, market caps of companies most affected - $AAPL +376%; $GOOG +9%; $RIMM -85%; $NOK -89%",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218052452820336641",
    "text" : "Since release of iPhone 5 years ago, market caps of companies most affected - $AAPL +376%; $GOOG +9%; $RIMM -85%; $NOK -89%",
    "id" : 218052452820336641,
    "created_at" : "2012-06-27 18:45:30 +0000",
    "user" : {
      "name" : "Greg Gretsch",
      "screen_name" : "greggretsch",
      "protected" : false,
      "id_str" : "26802954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2830249059\/2aa66234b10e1395adb4a956b2246ce4_normal.png",
      "id" : 26802954,
      "verified" : false
    }
  },
  "id" : 218846461448818688,
  "created_at" : "2012-06-29 23:20:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 0, 10 ],
      "id_str" : "10015122",
      "id" : 10015122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218753010921246724",
  "geo" : { },
  "id_str" : "218757248602746881",
  "in_reply_to_user_id" : 10015122,
  "text" : "@andypixel How are you wearing pants??",
  "id" : 218757248602746881,
  "in_reply_to_status_id" : 218753010921246724,
  "created_at" : "2012-06-29 17:26:07 +0000",
  "in_reply_to_screen_name" : "andypixel",
  "in_reply_to_user_id_str" : "10015122",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218750559254093825",
  "geo" : { },
  "id_str" : "218751154551656451",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara Interesting. And do you believe that that\u2019s true for everyone all the time?",
  "id" : 218751154551656451,
  "in_reply_to_status_id" : 218750559254093825,
  "created_at" : "2012-06-29 17:01:54 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Love",
      "screen_name" : "andrewtlove",
      "indices" : [ 0, 12 ],
      "id_str" : "18132818",
      "id" : 18132818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218748387015667712",
  "geo" : { },
  "id_str" : "218750165505417216",
  "in_reply_to_user_id" : 18132818,
  "text" : "@andrewtlove I disagree. That\u2019s just the best we can do. The best way to know what\u2019s inside a locked box is not to observe its cover.",
  "id" : 218750165505417216,
  "in_reply_to_status_id" : 218748387015667712,
  "created_at" : "2012-06-29 16:57:58 +0000",
  "in_reply_to_screen_name" : "andrewtlove",
  "in_reply_to_user_id_str" : "18132818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Love",
      "screen_name" : "andrewtlove",
      "indices" : [ 0, 12 ],
      "id_str" : "18132818",
      "id" : 18132818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218745554673471488",
  "geo" : { },
  "id_str" : "218745972421963776",
  "in_reply_to_user_id" : 18132818,
  "text" : "@andrewtlove True self.",
  "id" : 218745972421963776,
  "in_reply_to_status_id" : 218745554673471488,
  "created_at" : "2012-06-29 16:41:18 +0000",
  "in_reply_to_screen_name" : "andrewtlove",
  "in_reply_to_user_id_str" : "18132818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218744853750747136",
  "geo" : { },
  "id_str" : "218745938632650754",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara Yeah. But don\u2019t you think some contexts are more you than others?",
  "id" : 218745938632650754,
  "in_reply_to_status_id" : 218744853750747136,
  "created_at" : "2012-06-29 16:41:10 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 0, 10 ],
      "id_str" : "10015122",
      "id" : 10015122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218744754861645824",
  "geo" : { },
  "id_str" : "218745608222150656",
  "in_reply_to_user_id" : 10015122,
  "text" : "@andypixel When you\u2019re wearing pants.",
  "id" : 218745608222150656,
  "in_reply_to_status_id" : 218744754861645824,
  "created_at" : "2012-06-29 16:39:51 +0000",
  "in_reply_to_screen_name" : "andypixel",
  "in_reply_to_user_id_str" : "10015122",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218744524812451841",
  "text" : "When are you most like yourself?",
  "id" : 218744524812451841,
  "created_at" : "2012-06-29 16:35:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Moody",
      "screen_name" : "notaustintexas",
      "indices" : [ 0, 15 ],
      "id_str" : "597623360",
      "id" : 597623360
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 24, 31 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218730208973422594",
  "geo" : { },
  "id_str" : "218731782697263104",
  "in_reply_to_user_id" : 597623360,
  "text" : "@notaustintexas I think @Fitbit's a better product overall.",
  "id" : 218731782697263104,
  "in_reply_to_status_id" : 218730208973422594,
  "created_at" : "2012-06-29 15:44:55 +0000",
  "in_reply_to_screen_name" : "notaustintexas",
  "in_reply_to_user_id_str" : "597623360",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Path",
      "screen_name" : "path",
      "indices" : [ 31, 36 ],
      "id_str" : "106333951",
      "id" : 106333951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/GK37lMRD",
      "expanded_url" : "http:\/\/blog.path.com\/post\/26138738807\/fuelband",
      "display_url" : "blog.path.com\/post\/261387388\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218714998514515970",
  "text" : "Connected up Nike+ FuelBand to @path: http:\/\/t.co\/GK37lMRD",
  "id" : 218714998514515970,
  "created_at" : "2012-06-29 14:38:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Hickl",
      "screen_name" : "andyhickl",
      "indices" : [ 3, 13 ],
      "id_str" : "9684932",
      "id" : 9684932
    }, {
      "name" : "A.R.O., Inc.",
      "screen_name" : "arodotcom",
      "indices" : [ 58, 68 ],
      "id_str" : "361415887",
      "id" : 361415887
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Saga",
      "indices" : [ 71, 76 ]
    }, {
      "text" : "googleNow",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/dTPVkgIL",
      "expanded_url" : "http:\/\/getsaga.com",
      "display_url" : "getsaga.com"
    } ]
  },
  "geo" : { },
  "id_str" : "218588717915451392",
  "text" : "RT @andyhickl: If you'd like Google Now later, you'd like @arodotcom's #Saga, uh, soon. http:\/\/t.co\/dTPVkgIL #googleNow",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "A.R.O., Inc.",
        "screen_name" : "arodotcom",
        "indices" : [ 43, 53 ],
        "id_str" : "361415887",
        "id" : 361415887
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Saga",
        "indices" : [ 56, 61 ]
      }, {
        "text" : "googleNow",
        "indices" : [ 94, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/dTPVkgIL",
        "expanded_url" : "http:\/\/getsaga.com",
        "display_url" : "getsaga.com"
      } ]
    },
    "geo" : { },
    "id_str" : "218473469288005633",
    "text" : "If you'd like Google Now later, you'd like @arodotcom's #Saga, uh, soon. http:\/\/t.co\/dTPVkgIL #googleNow",
    "id" : 218473469288005633,
    "created_at" : "2012-06-28 22:38:28 +0000",
    "user" : {
      "name" : "Andy Hickl",
      "screen_name" : "andyhickl",
      "protected" : false,
      "id_str" : "9684932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459115796598231040\/A7Ej1u5h_normal.jpeg",
      "id" : 9684932,
      "verified" : false
    }
  },
  "id" : 218588717915451392,
  "created_at" : "2012-06-29 06:16:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 20, 29 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Rdio",
      "screen_name" : "Rdio",
      "indices" : [ 53, 58 ],
      "id_str" : "54205414",
      "id" : 54205414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/rRQzjPZF",
      "expanded_url" : "http:\/\/flic.kr\/p\/cnCf2C",
      "display_url" : "flic.kr\/p\/cnCf2C"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "218549984772100097",
  "text" : "8:36pm Grateful for @spangley's Shoes Are For Gazing @rdio playlist. I like the new design too. http:\/\/t.co\/rRQzjPZF",
  "id" : 218549984772100097,
  "created_at" : "2012-06-29 03:42:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218492416330702848",
  "geo" : { },
  "id_str" : "218493107849801729",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc On first try it seemed just as fast, and I like the UI. I use Chrome on my computers, so syncing is nice. We\u2019ll see though\u2026",
  "id" : 218493107849801729,
  "in_reply_to_status_id" : 218492416330702848,
  "created_at" : "2012-06-28 23:56:30 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218490161187655680",
  "text" : "The new Chrome iPhone app is slick. It is replacing Safari in my dock for now...",
  "id" : 218490161187655680,
  "created_at" : "2012-06-28 23:44:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 19, 30 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/beja1oxg",
      "expanded_url" : "http:\/\/blog.foursquare.com\/2012\/06\/28\/developer-preview-build-your-app-directly-into-foursquare-with-our-new-connected-apps-platform\/",
      "display_url" : "blog.foursquare.com\/2012\/06\/28\/dev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218464286127816705",
  "text" : "Super stoked about @foursquare's new connected apps API. Hoping I get some time to play around with it soon: http:\/\/t.co\/beja1oxg",
  "id" : 218464286127816705,
  "created_at" : "2012-06-28 22:01:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/9uSkiZXl",
      "expanded_url" : "http:\/\/www.facebook.com\/questions\/10150980020933647\/?qa_ref=ssp",
      "display_url" : "facebook.com\/questions\/1015\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218456693837803521",
  "text" : "I need some new shirts, but no time to shop. Can you find some ideas for me please? :) http:\/\/t.co\/9uSkiZXl",
  "id" : 218456693837803521,
  "created_at" : "2012-06-28 21:31:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Gold",
      "screen_name" : "heathr",
      "indices" : [ 0, 7 ],
      "id_str" : "678033",
      "id" : 678033
    }, {
      "name" : "Budge",
      "screen_name" : "budge",
      "indices" : [ 39, 45 ],
      "id_str" : "286384512",
      "id" : 286384512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218352212932440066",
  "geo" : { },
  "id_str" : "218455736009760769",
  "in_reply_to_user_id" : 678033,
  "text" : "@heathr Have you tried Plank Animal on @budge yet? :)",
  "id" : 218455736009760769,
  "in_reply_to_status_id" : 218352212932440066,
  "created_at" : "2012-06-28 21:28:00 +0000",
  "in_reply_to_screen_name" : "heathr",
  "in_reply_to_user_id_str" : "678033",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TED News",
      "screen_name" : "TEDNews",
      "indices" : [ 3, 11 ],
      "id_str" : "36843988",
      "id" : 36843988
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 109, 119 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/LwCc5V9o",
      "expanded_url" : "http:\/\/showmethescience.com",
      "display_url" : "showmethescience.com"
    } ]
  },
  "geo" : { },
  "id_str" : "218345956108804097",
  "text" : "RT @TEDNews: Want to see the science that says online gaming boosts happiness? Head to: http:\/\/t.co\/LwCc5V9o @avantgame",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jane McGonigal",
        "screen_name" : "avantgame",
        "indices" : [ 96, 106 ],
        "id_str" : "681813",
        "id" : 681813
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/LwCc5V9o",
        "expanded_url" : "http:\/\/showmethescience.com",
        "display_url" : "showmethescience.com"
      } ]
    },
    "geo" : { },
    "id_str" : "218332676569051195",
    "text" : "Want to see the science that says online gaming boosts happiness? Head to: http:\/\/t.co\/LwCc5V9o @avantgame",
    "id" : 218332676569051195,
    "created_at" : "2012-06-28 13:19:01 +0000",
    "user" : {
      "name" : "TED News",
      "screen_name" : "TEDNews",
      "protected" : false,
      "id_str" : "36843988",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3279174286\/5de7d7794205fc0ba09bdf54e6c16707_normal.png",
      "id" : 36843988,
      "verified" : true
    }
  },
  "id" : 218345956108804097,
  "created_at" : "2012-06-28 14:11:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "peter ha",
      "screen_name" : "ThePeterHa",
      "indices" : [ 36, 47 ],
      "id_str" : "5749162",
      "id" : 5749162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/U5ZglaCp",
      "expanded_url" : "http:\/\/bit.ly\/OApQYl",
      "display_url" : "bit.ly\/OApQYl"
    } ]
  },
  "geo" : { },
  "id_str" : "218211236456833025",
  "text" : "Catching up on this crazy stuff: RT @ThePeterHa: Project Glass Is The Future Of Google http:\/\/t.co\/U5ZglaCp",
  "id" : 218211236456833025,
  "created_at" : "2012-06-28 05:16:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Wayland",
      "screen_name" : "bradwayland",
      "indices" : [ 0, 12 ],
      "id_str" : "14178713",
      "id" : 14178713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218177298669649922",
  "geo" : { },
  "id_str" : "218202841834192896",
  "in_reply_to_user_id" : 14178713,
  "text" : "@bradwayland Just that I have narrowed it down to a couple people and am working with them directly.",
  "id" : 218202841834192896,
  "in_reply_to_status_id" : 218177298669649922,
  "created_at" : "2012-06-28 04:43:06 +0000",
  "in_reply_to_screen_name" : "bradwayland",
  "in_reply_to_user_id_str" : "14178713",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/dGFCPnmJ",
      "expanded_url" : "http:\/\/flic.kr\/p\/cn7qwo",
      "display_url" : "flic.kr\/p\/cn7qwo"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6215, -122.337 ]
  },
  "id_str" : "218201227836657664",
  "text" : "8:36pm Working late on too many different projects http:\/\/t.co\/dGFCPnmJ",
  "id" : 218201227836657664,
  "created_at" : "2012-06-28 04:36:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Wright",
      "screen_name" : "larrywright",
      "indices" : [ 0, 12 ],
      "id_str" : "10286",
      "id" : 10286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218068410897154048",
  "geo" : { },
  "id_str" : "218080487388876802",
  "in_reply_to_user_id" : 10286,
  "text" : "@larrywright Not yet. I'll check it out though, thanks for the tip.",
  "id" : 218080487388876802,
  "in_reply_to_status_id" : 218068410897154048,
  "created_at" : "2012-06-27 20:36:54 +0000",
  "in_reply_to_screen_name" : "larrywright",
  "in_reply_to_user_id_str" : "10286",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218064965570015233",
  "text" : "I\u2019m using Fireworks for the first time and sort of digging it.",
  "id" : 218064965570015233,
  "created_at" : "2012-06-27 19:35:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Wang",
      "screen_name" : "brianmwang",
      "indices" : [ 0, 11 ],
      "id_str" : "93478440",
      "id" : 93478440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217989826207678467",
  "geo" : { },
  "id_str" : "218000200655044610",
  "in_reply_to_user_id" : 93478440,
  "text" : "@brianmwang Yes that\u2019s been happening to me too all day. Let me know if you find the cause or fix.",
  "id" : 218000200655044610,
  "in_reply_to_status_id" : 217989826207678467,
  "created_at" : "2012-06-27 15:17:52 +0000",
  "in_reply_to_screen_name" : "brianmwang",
  "in_reply_to_user_id_str" : "93478440",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217845746467217408",
  "geo" : { },
  "id_str" : "217846710465069059",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Say konichiwa to my people!",
  "id" : 217846710465069059,
  "in_reply_to_status_id" : 217845746467217408,
  "created_at" : "2012-06-27 05:07:57 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "indices" : [ 67, 76 ],
      "id_str" : "22483",
      "id" : 22483
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 78, 91 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217838799693156353",
  "text" : "So maybe rotate my restrictions each weekday, and weekends off? RT @pinwheel: @busterbenson Sure\u2026But not at the same time.",
  "id" : 217838799693156353,
  "created_at" : "2012-06-27 04:36:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217833011675283456",
  "text" : "Disclaimer: I know enough about myself to know that I couldn\u2019t become that even if I wanted.",
  "id" : 217833011675283456,
  "created_at" : "2012-06-27 04:13:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217832052609916928",
  "text" : "Should I become an organic gluten-free raw food vegan locavore?",
  "id" : 217832052609916928,
  "created_at" : "2012-06-27 04:09:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/heZI3Lbt",
      "expanded_url" : "http:\/\/instagr.am\/p\/MXMy7rI0Ia\/",
      "display_url" : "instagr.am\/p\/MXMy7rI0Ia\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.675829, -122.316397 ]
  },
  "id_str" : "217824229071126529",
  "text" : "8:36pm This place is converting us  @ Thrive http:\/\/t.co\/heZI3Lbt",
  "id" : 217824229071126529,
  "created_at" : "2012-06-27 03:38:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber Seattle",
      "screen_name" : "Uber_SEA",
      "indices" : [ 34, 43 ],
      "id_str" : "272162235",
      "id" : 272162235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217775187725266944",
  "text" : "Training us to like it cloudy. RT @Uber_SEA: It's currently partly cloudy in Seattle. Enter the code UBERELLA &amp; get 50% off a ride today!",
  "id" : 217775187725266944,
  "created_at" : "2012-06-27 00:23:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sage Catharsis",
      "screen_name" : "Graizur",
      "indices" : [ 0, 8 ],
      "id_str" : "29274115",
      "id" : 29274115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217747621727567872",
  "geo" : { },
  "id_str" : "217753222734024704",
  "in_reply_to_user_id" : 29274115,
  "text" : "@Graizur Thanks for the advice.",
  "id" : 217753222734024704,
  "in_reply_to_status_id" : 217747621727567872,
  "created_at" : "2012-06-26 22:56:28 +0000",
  "in_reply_to_screen_name" : "Graizur",
  "in_reply_to_user_id_str" : "29274115",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sage Catharsis",
      "screen_name" : "Graizur",
      "indices" : [ 0, 8 ],
      "id_str" : "29274115",
      "id" : 29274115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217745141962772480",
  "geo" : { },
  "id_str" : "217745956651794433",
  "in_reply_to_user_id" : 29274115,
  "text" : "@Graizur I don\u2019t get it. What are you trying to say?",
  "id" : 217745956651794433,
  "in_reply_to_status_id" : 217745141962772480,
  "created_at" : "2012-06-26 22:27:36 +0000",
  "in_reply_to_screen_name" : "Graizur",
  "in_reply_to_user_id_str" : "29274115",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217742435290320898",
  "text" : "Do you think back in the day that mammals\u2019 lizard brains were as obsessed with their new cerebral cortexes as we are now with our phones?",
  "id" : 217742435290320898,
  "created_at" : "2012-06-26 22:13:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Nwakalo",
      "screen_name" : "Chris_NWA",
      "indices" : [ 0, 10 ],
      "id_str" : "33425369",
      "id" : 33425369
    }, {
      "name" : "Marie Forleo",
      "screen_name" : "marieforleo",
      "indices" : [ 11, 23 ],
      "id_str" : "16527415",
      "id" : 16527415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217725640495996928",
  "geo" : { },
  "id_str" : "217741203540684800",
  "in_reply_to_user_id" : 33425369,
  "text" : "@Chris_NWA @marieforleo Thanks! I\u2019ve used both in the past and have nothing against them. Building APIs was the deciding factor.",
  "id" : 217741203540684800,
  "in_reply_to_status_id" : 217725640495996928,
  "created_at" : "2012-06-26 22:08:43 +0000",
  "in_reply_to_screen_name" : "Chris_NWA",
  "in_reply_to_user_id_str" : "33425369",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 16, 27 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/lkaVwCRc",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=qrQbkjhrANs&hd=1",
      "display_url" : "youtube.com\/watch?v=qrQbkj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217485391962439681",
  "text" : "AKA Amazing! RT @waxpancake: Robot and Frank = best romantic comedy\/jewelry heist\/robot-senior buddy film this year. http:\/\/t.co\/lkaVwCRc",
  "id" : 217485391962439681,
  "created_at" : "2012-06-26 05:12:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/6y5zThbP",
      "expanded_url" : "http:\/\/instagr.am\/p\/MUoe3jI0L0\/",
      "display_url" : "instagr.am\/p\/MUoe3jI0L0\/"
    } ]
  },
  "geo" : { },
  "id_str" : "217462880294019072",
  "text" : "8:36pm Funny faces pt 835, toad edition http:\/\/t.co\/6y5zThbP",
  "id" : 217462880294019072,
  "created_at" : "2012-06-26 03:42:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keegan Jones",
      "screen_name" : "keeg",
      "indices" : [ 35, 40 ],
      "id_str" : "770505",
      "id" : 770505
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 47, 57 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217422393923211264",
  "text" : "Neat! I never use their camera. RT @keeg: Cool @instagram 2.5 trick: Long press on the camera button to access your camera roll.",
  "id" : 217422393923211264,
  "created_at" : "2012-06-26 01:01:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217412582397579264",
  "text" : "Wow, I have a 100+ non-spam messages in my \"Other Messages\" folder on Facebook that I didn't know about.",
  "id" : 217412582397579264,
  "created_at" : "2012-06-26 00:22:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Morga",
      "screen_name" : "AliciaMorga",
      "indices" : [ 41, 53 ],
      "id_str" : "19053875",
      "id" : 19053875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/BWrroqLM",
      "expanded_url" : "http:\/\/bit.ly\/MTIeUW",
      "display_url" : "bit.ly\/MTIeUW"
    } ]
  },
  "geo" : { },
  "id_str" : "217340017352261632",
  "text" : "Great article on the quantified life! RT @AliciaMorga: \"They will regard the doctor as more consultant than oracle.\"  http:\/\/t.co\/BWrroqLM",
  "id" : 217340017352261632,
  "created_at" : "2012-06-25 19:34:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/jsQch4OJ",
      "expanded_url" : "http:\/\/nedhardy.com\/2012\/06\/18\/dads-secret-graduation-present-to-daughter-took-13-years-to-make\/",
      "display_url" : "nedhardy.com\/2012\/06\/18\/dad\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217335125468397568",
  "text" : "RT @HygeiaKate: I love this: Dad\u2019s Secret Graduation Present To Daughter Took 13 Years To Make http:\/\/t.co\/jsQch4OJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/jsQch4OJ",
        "expanded_url" : "http:\/\/nedhardy.com\/2012\/06\/18\/dads-secret-graduation-present-to-daughter-took-13-years-to-make\/",
        "display_url" : "nedhardy.com\/2012\/06\/18\/dad\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "217331134537793536",
    "text" : "I love this: Dad\u2019s Secret Graduation Present To Daughter Took 13 Years To Make http:\/\/t.co\/jsQch4OJ",
    "id" : 217331134537793536,
    "created_at" : "2012-06-25 18:59:14 +0000",
    "user" : {
      "name" : "Kate Gulbransen",
      "screen_name" : "KateIn140",
      "protected" : false,
      "id_str" : "62413270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851000272\/TwitterHi_normal.jpg",
      "id" : 62413270,
      "verified" : false
    }
  },
  "id" : 217335125468397568,
  "created_at" : "2012-06-25 19:15:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217322591914958851",
  "geo" : { },
  "id_str" : "217333776840261633",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb That\u2019s rad.",
  "id" : 217333776840261633,
  "in_reply_to_status_id" : 217322591914958851,
  "created_at" : "2012-06-25 19:09:44 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Burkeman",
      "screen_name" : "oliverburkeman",
      "indices" : [ 0, 15 ],
      "id_str" : "112037009",
      "id" : 112037009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217148683563700225",
  "geo" : { },
  "id_str" : "217277782001065984",
  "in_reply_to_user_id" : 112037009,
  "text" : "@oliverburkeman I ordered it! Shipping cost as much as the book. Too bad Kindle version can't be available worldwide.",
  "id" : 217277782001065984,
  "in_reply_to_status_id" : 217148683563700225,
  "created_at" : "2012-06-25 15:27:14 +0000",
  "in_reply_to_screen_name" : "oliverburkeman",
  "in_reply_to_user_id_str" : "112037009",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/G1MsB09L",
      "expanded_url" : "http:\/\/instagr.am\/p\/MSDfeco0P7\/",
      "display_url" : "instagr.am\/p\/MSDfeco0P7\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.611202, -122.316686511 ]
  },
  "id_str" : "217100182007975936",
  "text" : "8:36pm Bad mood time out  @ Canon http:\/\/t.co\/G1MsB09L",
  "id" : 217100182007975936,
  "created_at" : "2012-06-25 03:41:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/dCCmWxxQ",
      "expanded_url" : "http:\/\/scriggity.com\/simplicity",
      "display_url" : "scriggity.com\/simplicity"
    } ]
  },
  "geo" : { },
  "id_str" : "217089439950835713",
  "text" : "RT @thatdrew: simplicity. http:\/\/t.co\/dCCmWxxQ",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 32 ],
        "url" : "http:\/\/t.co\/dCCmWxxQ",
        "expanded_url" : "http:\/\/scriggity.com\/simplicity",
        "display_url" : "scriggity.com\/simplicity"
      } ]
    },
    "geo" : { },
    "id_str" : "217084025175670784",
    "text" : "simplicity. http:\/\/t.co\/dCCmWxxQ",
    "id" : 217084025175670784,
    "created_at" : "2012-06-25 02:37:19 +0000",
    "user" : {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "protected" : false,
      "id_str" : "10221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449363717671505920\/wKlfNnSY_normal.jpeg",
      "id" : 10221,
      "verified" : false
    }
  },
  "id" : 217089439950835713,
  "created_at" : "2012-06-25 02:58:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sammy Larbi",
      "screen_name" : "codeodor",
      "indices" : [ 0, 9 ],
      "id_str" : "7853992",
      "id" : 7853992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217073607820582912",
  "geo" : { },
  "id_str" : "217074294008709120",
  "in_reply_to_user_id" : 7853992,
  "text" : "@codeodor I think the excerpt from the book explained well. Failure sucks. But fearing it at all costs will only make it worse.",
  "id" : 217074294008709120,
  "in_reply_to_status_id" : 217073607820582912,
  "created_at" : "2012-06-25 01:58:39 +0000",
  "in_reply_to_screen_name" : "codeodor",
  "in_reply_to_user_id_str" : "7853992",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sammy Larbi",
      "screen_name" : "codeodor",
      "indices" : [ 0, 9 ],
      "id_str" : "7853992",
      "id" : 7853992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217071772384759813",
  "geo" : { },
  "id_str" : "217072183627890688",
  "in_reply_to_user_id" : 7853992,
  "text" : "@codeodor It\u2019s true. I think failure only becomes really interesting when it stops seeming interesting from the outside.",
  "id" : 217072183627890688,
  "in_reply_to_status_id" : 217071772384759813,
  "created_at" : "2012-06-25 01:50:16 +0000",
  "in_reply_to_screen_name" : "codeodor",
  "in_reply_to_user_id_str" : "7853992",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/Qxle8kqi",
      "expanded_url" : "http:\/\/instagr.am\/p\/MRu8pcI0Dh\/",
      "display_url" : "instagr.am\/p\/MRu8pcI0Dh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "217054980404809728",
  "text" : "Hitting the town for some exciting errands http:\/\/t.co\/Qxle8kqi",
  "id" : 217054980404809728,
  "created_at" : "2012-06-25 00:41:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217042098350866432",
  "geo" : { },
  "id_str" : "217043445691330561",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar This'll be a good discussion! But don't you agree that too much positivity can re-enforce fear and anxiety of the unknown?",
  "id" : 217043445691330561,
  "in_reply_to_status_id" : 217042098350866432,
  "created_at" : "2012-06-24 23:56:04 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/sLx82iWU",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/lifeandstyle\/2012\/jun\/15\/happiness-is-being-a-loser-burkeman",
      "display_url" : "guardian.co.uk\/lifeandstyle\/2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "217041367958958083",
  "geo" : { },
  "id_str" : "217041643197579265",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar Hah, yes. I'd love to discuss! But first, read this excerpt for background: http:\/\/t.co\/sLx82iWU",
  "id" : 217041643197579265,
  "in_reply_to_status_id" : 217041367958958083,
  "created_at" : "2012-06-24 23:48:54 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Burkeman",
      "screen_name" : "oliverburkeman",
      "indices" : [ 0, 15 ],
      "id_str" : "112037009",
      "id" : 112037009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217038835484340224",
  "in_reply_to_user_id" : 112037009,
  "text" : "@oliverburkeman Very excited about your new book. Any way for someone in the US to get it before November?",
  "id" : 217038835484340224,
  "created_at" : "2012-06-24 23:37:45 +0000",
  "in_reply_to_screen_name" : "oliverburkeman",
  "in_reply_to_user_id_str" : "112037009",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/sLx82iWU",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/lifeandstyle\/2012\/jun\/15\/happiness-is-being-a-loser-burkeman",
      "display_url" : "guardian.co.uk\/lifeandstyle\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217037627495428097",
  "text" : "\"The worst thing about any future event that you feel anxious about is usually your exaggerated belief in its horror.\" http:\/\/t.co\/sLx82iWU",
  "id" : 217037627495428097,
  "created_at" : "2012-06-24 23:32:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/FggH5dJp",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayO2RaNe",
      "display_url" : "tmblr.co\/ZQJvayO2RaNe"
    } ]
  },
  "geo" : { },
  "id_str" : "217025321529122816",
  "text" : "\"Ease up on all this positive thinking and learn instead to bathe in insecurity, uncertainty, and failure\": http:\/\/t.co\/FggH5dJp",
  "id" : 217025321529122816,
  "created_at" : "2012-06-24 22:44:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Deterding",
      "screen_name" : "dingstweets",
      "indices" : [ 0, 12 ],
      "id_str" : "14435477",
      "id" : 14435477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217019321149431810",
  "in_reply_to_user_id" : 14435477,
  "text" : "@dingstweets Just saw your TEDx talk from last Nov and was SUPER surprised\/excited to get the shout out at the end. Thank you!",
  "id" : 217019321149431810,
  "created_at" : "2012-06-24 22:20:12 +0000",
  "in_reply_to_screen_name" : "dingstweets",
  "in_reply_to_user_id_str" : "14435477",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Dart",
      "screen_name" : "joeldart",
      "indices" : [ 0, 9 ],
      "id_str" : "65407254",
      "id" : 65407254
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216999075189506049",
  "geo" : { },
  "id_str" : "217000115062308866",
  "in_reply_to_user_id" : 65407254,
  "text" : "@joeldart Not really, but I can see how it might be interpreted that way.",
  "id" : 217000115062308866,
  "in_reply_to_status_id" : 216999075189506049,
  "created_at" : "2012-06-24 21:03:53 +0000",
  "in_reply_to_screen_name" : "joeldart",
  "in_reply_to_user_id_str" : "65407254",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Obituaries",
      "screen_name" : "NYTObits",
      "indices" : [ 17, 26 ],
      "id_str" : "16929470",
      "id" : 16929470
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obitoftheday",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/IqMNsDfU",
      "expanded_url" : "http:\/\/bit.ly\/NpsOJa",
      "display_url" : "bit.ly\/NpsOJa"
    } ]
  },
  "geo" : { },
  "id_str" : "216995132224966656",
  "text" : "#obitoftheday RT @NYTObits: Lesley Brown, Mother of First Test-Tube Baby, Dies at 64 http:\/\/t.co\/IqMNsDfU",
  "id" : 216995132224966656,
  "created_at" : "2012-06-24 20:44:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216984659630899202",
  "text" : "Stop trying to be someone else.",
  "id" : 216984659630899202,
  "created_at" : "2012-06-24 20:02:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 3, 14 ],
      "id_str" : "3452941",
      "id" : 3452941
    }, {
      "name" : "Matthew Inman",
      "screen_name" : "Oatmeal",
      "indices" : [ 39, 47 ],
      "id_str" : "4519121",
      "id" : 4519121
    }, {
      "name" : "Vdoi is \u2665",
      "screen_name" : "Charlescarreon",
      "indices" : [ 102, 117 ],
      "id_str" : "1911753090",
      "id" : 1911753090
    }, {
      "name" : "cwGabriel",
      "screen_name" : "cwgabriel",
      "indices" : [ 124, 134 ],
      "id_str" : "14464369",
      "id" : 14464369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Y7beFfeK",
      "expanded_url" : "http:\/\/blogs.seattletimes.com\/monica-guzman\/2012\/06\/23\/showdown-why-seattle-cartoonist-the-oatmeals-brilliant-joke-may-have-backfired\/",
      "display_url" : "blogs.seattletimes.com\/monica-guzman\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "216982697740992513",
  "text" : "RT @moniguzman: Why Seattle cartoonist @oatmeal's brilliant joke may have backfired, w\/ thoughts from @charlescarreon &amp; @cwgabriel h ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew Inman",
        "screen_name" : "Oatmeal",
        "indices" : [ 23, 31 ],
        "id_str" : "4519121",
        "id" : 4519121
      }, {
        "name" : "Vdoi is \u2665",
        "screen_name" : "Charlescarreon",
        "indices" : [ 86, 101 ],
        "id_str" : "1911753090",
        "id" : 1911753090
      }, {
        "name" : "cwGabriel",
        "screen_name" : "cwgabriel",
        "indices" : [ 108, 118 ],
        "id_str" : "14464369",
        "id" : 14464369
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/Y7beFfeK",
        "expanded_url" : "http:\/\/blogs.seattletimes.com\/monica-guzman\/2012\/06\/23\/showdown-why-seattle-cartoonist-the-oatmeals-brilliant-joke-may-have-backfired\/",
        "display_url" : "blogs.seattletimes.com\/monica-guzman\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "216949385425203200",
    "text" : "Why Seattle cartoonist @oatmeal's brilliant joke may have backfired, w\/ thoughts from @charlescarreon &amp; @cwgabriel http:\/\/t.co\/Y7beFfeK",
    "id" : 216949385425203200,
    "created_at" : "2012-06-24 17:42:18 +0000",
    "user" : {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "protected" : false,
      "id_str" : "3452941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454510513251037184\/83aM56tP_normal.jpeg",
      "id" : 3452941,
      "verified" : false
    }
  },
  "id" : 216982697740992513,
  "created_at" : "2012-06-24 19:54:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/h4dueNxn",
      "expanded_url" : "http:\/\/instagr.am\/p\/MPf1kbI0Iw\/",
      "display_url" : "instagr.am\/p\/MPf1kbI0Iw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "216740322171035648",
  "text" : "8:36pm He just unlocked \"night night, [fill in the blank]\" in his brain http:\/\/t.co\/h4dueNxn",
  "id" : 216740322171035648,
  "created_at" : "2012-06-24 03:51:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216724995420848128",
  "geo" : { },
  "id_str" : "216728015294574592",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus Maybe create a trash folder and put that and stocks in there.",
  "id" : 216728015294574592,
  "in_reply_to_status_id" : 216724995420848128,
  "created_at" : "2012-06-24 03:02:40 +0000",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HSofia",
      "screen_name" : "hsofia",
      "indices" : [ 0, 7 ],
      "id_str" : "14372614",
      "id" : 14372614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216697470720290816",
  "geo" : { },
  "id_str" : "216698803997253633",
  "in_reply_to_user_id" : 14372614,
  "text" : "@hsofia You have stocks on your dock? Replace replace!",
  "id" : 216698803997253633,
  "in_reply_to_status_id" : 216697470720290816,
  "created_at" : "2012-06-24 01:06:35 +0000",
  "in_reply_to_screen_name" : "hsofia",
  "in_reply_to_user_id_str" : "14372614",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216697550248488960",
  "geo" : { },
  "id_str" : "216698694819516416",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Yeah, replace that with Tweetbot to have the same lineup that I do.",
  "id" : 216698694819516416,
  "in_reply_to_status_id" : 216697550248488960,
  "created_at" : "2012-06-24 01:06:09 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Assink",
      "screen_name" : "jonassink",
      "indices" : [ 0, 10 ],
      "id_str" : "6604252",
      "id" : 6604252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216697002464002048",
  "geo" : { },
  "id_str" : "216698509812961281",
  "in_reply_to_user_id" : 6604252,
  "text" : "@jonassink You should just go ahead and replace it now.",
  "id" : 216698509812961281,
  "in_reply_to_status_id" : 216697002464002048,
  "created_at" : "2012-06-24 01:05:25 +0000",
  "in_reply_to_screen_name" : "jonassink",
  "in_reply_to_user_id_str" : "6604252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216696553249841154",
  "text" : "If you had to remove an app from your iPhone dock, which would it be?",
  "id" : 216696553249841154,
  "created_at" : "2012-06-24 00:57:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/7chl2lqs",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayN_MBCe",
      "display_url" : "tmblr.co\/ZQJvayN_MBCe"
    } ]
  },
  "geo" : { },
  "id_str" : "216663772956344320",
  "text" : "Great animated trailer for a new book \"Antidote: Happiness for people who can't stand positive thinking\": http:\/\/t.co\/7chl2lqs",
  "id" : 216663772956344320,
  "created_at" : "2012-06-23 22:47:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Obituaries",
      "screen_name" : "NYTObits",
      "indices" : [ 17, 26 ],
      "id_str" : "16929470",
      "id" : 16929470
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obitoftheday",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/aJavV14G",
      "expanded_url" : "http:\/\/bit.ly\/O78jWg",
      "display_url" : "bit.ly\/O78jWg"
    } ]
  },
  "geo" : { },
  "id_str" : "216634831176605696",
  "text" : "#obitoftheday RT @NYTObits: Richard Adler, Collaborator on \u2018Pajama Game\u2019 and \u2018Damn Yankees,\u2019 Dies at 90 http:\/\/t.co\/aJavV14G",
  "id" : 216634831176605696,
  "created_at" : "2012-06-23 20:52:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Kathleen Peck",
      "screen_name" : "sarahkpeck",
      "indices" : [ 0, 11 ],
      "id_str" : "196745496",
      "id" : 196745496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216613328301195264",
  "geo" : { },
  "id_str" : "216615302216159233",
  "in_reply_to_user_id" : 196745496,
  "text" : "@sarahkpeck Exactly.",
  "id" : 216615302216159233,
  "in_reply_to_status_id" : 216613328301195264,
  "created_at" : "2012-06-23 19:34:47 +0000",
  "in_reply_to_screen_name" : "sarahkpeck",
  "in_reply_to_user_id_str" : "196745496",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216611771832741889",
  "text" : "I wish my iPhone had 2 unlock sliders. One would say \"I know what I'm gonna do\" and the other would say \"I have no idea why I'm doing this\".",
  "id" : 216611771832741889,
  "created_at" : "2012-06-23 19:20:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216603903498792960",
  "text" : "Behavior change is a skill, like learning to play the guitar. You gotta practice. And it's your subconscious that is the guitar.",
  "id" : 216603903498792960,
  "created_at" : "2012-06-23 18:49:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "milkshakepants",
      "indices" : [ 0, 15 ],
      "id_str" : "12835992",
      "id" : 12835992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216401216446533633",
  "geo" : { },
  "id_str" : "216550887647215617",
  "in_reply_to_user_id" : 12835992,
  "text" : "@milkshakepants Solstice is the longest day but some friends throw a party on the latest day, which comes a few days later\u2026",
  "id" : 216550887647215617,
  "in_reply_to_status_id" : 216401216446533633,
  "created_at" : "2012-06-23 15:18:49 +0000",
  "in_reply_to_screen_name" : "milkshakepants",
  "in_reply_to_user_id_str" : "12835992",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/uLPfGqmM",
      "expanded_url" : "http:\/\/flic.kr\/p\/cj1kUu",
      "display_url" : "flic.kr\/p\/cj1kUu"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.617666, -122.352167 ]
  },
  "id_str" : "216384032064282624",
  "text" : "8:36pm Celebrating latest day of the year with Dickers and this guy is hitting his wall http:\/\/t.co\/uLPfGqmM",
  "id" : 216384032064282624,
  "created_at" : "2012-06-23 04:15:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 0, 8 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216334645015486464",
  "geo" : { },
  "id_str" : "216343540047953920",
  "in_reply_to_user_id" : 958581,
  "text" : "@rdicker Okay, we will!",
  "id" : 216343540047953920,
  "in_reply_to_status_id" : 216334645015486464,
  "created_at" : "2012-06-23 01:34:54 +0000",
  "in_reply_to_screen_name" : "rdicker",
  "in_reply_to_user_id_str" : "958581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 0, 8 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216330931890421763",
  "geo" : { },
  "id_str" : "216333403107237888",
  "in_reply_to_user_id" : 958581,
  "text" : "@rdicker Agreed. If it comes out we\u2019ll come by for a bit!",
  "id" : 216333403107237888,
  "in_reply_to_status_id" : 216330931890421763,
  "created_at" : "2012-06-23 00:54:37 +0000",
  "in_reply_to_screen_name" : "rdicker",
  "in_reply_to_user_id_str" : "958581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Swizec",
      "screen_name" : "Swizec",
      "indices" : [ 0, 7 ],
      "id_str" : "15353121",
      "id" : 15353121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216329072282845184",
  "geo" : { },
  "id_str" : "216329358544080896",
  "in_reply_to_user_id" : 15353121,
  "text" : "@Swizec Why not? There\u2019s nothing wrong with in following people!",
  "id" : 216329358544080896,
  "in_reply_to_status_id" : 216329072282845184,
  "created_at" : "2012-06-23 00:38:32 +0000",
  "in_reply_to_screen_name" : "Swizec",
  "in_reply_to_user_id_str" : "15353121",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216328263151267841",
  "text" : "I got 44 tweets in the last 15 minutes. How many did you get?",
  "id" : 216328263151267841,
  "created_at" : "2012-06-23 00:34:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216321759476064256",
  "text" : "Fill in the blank: my kingdom for _____.",
  "id" : 216321759476064256,
  "created_at" : "2012-06-23 00:08:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/kN8Hol79",
      "expanded_url" : "http:\/\/www.wired.com\/business\/2012\/06\/why-we-lie-cheat-go-to-prison-and-eat-chocolate-cake-10-questions-with-dan-ariely\/",
      "display_url" : "wired.com\/business\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "216298429662498816",
  "text" : "We lie and cheat if 1) there's motivation 2) there's gray area in interpretation and 3) we can rationalize it\nhttp:\/\/t.co\/kN8Hol79",
  "id" : 216298429662498816,
  "created_at" : "2012-06-22 22:35:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/7leTsPrL",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayNvjbc2",
      "display_url" : "tmblr.co\/ZQJvayNvjbc2"
    } ]
  },
  "geo" : { },
  "id_str" : "216257999717675008",
  "text" : "What's in your empire hand? http:\/\/t.co\/7leTsPrL",
  "id" : 216257999717675008,
  "created_at" : "2012-06-22 19:54:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216219499278516224",
  "geo" : { },
  "id_str" : "216220601289949184",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg Good call. Duh.",
  "id" : 216220601289949184,
  "in_reply_to_status_id" : 216219499278516224,
  "created_at" : "2012-06-22 17:26:23 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216218933575950337",
  "text" : "Can someone make a Chrome plugin that allows only 1 tab and 1 window to be open at a time? Is that possible?",
  "id" : 216218933575950337,
  "created_at" : "2012-06-22 17:19:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Galligan",
      "screen_name" : "mg",
      "indices" : [ 40, 43 ],
      "id_str" : "607",
      "id" : 607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/wdmqV7Fj",
      "expanded_url" : "http:\/\/mgalligan.com\/post\/25648656268\/notifications-no-more-a-post-mortem",
      "display_url" : "mgalligan.com\/post\/256486562\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "216218668554649600",
  "text" : "Notifications no more: a post mortem by @mg http:\/\/t.co\/wdmqV7Fj",
  "id" : 216218668554649600,
  "created_at" : "2012-06-22 17:18:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Kathleen Peck",
      "screen_name" : "sarahkpeck",
      "indices" : [ 3, 14 ],
      "id_str" : "196745496",
      "id" : 196745496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/TDBCOOat",
      "expanded_url" : "http:\/\/bit.ly\/LjSH1S",
      "display_url" : "bit.ly\/LjSH1S"
    } ]
  },
  "geo" : { },
  "id_str" : "216188479900622849",
  "text" : "RT @sarahkpeck: It's okay. http:\/\/t.co\/TDBCOOat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 31 ],
        "url" : "http:\/\/t.co\/TDBCOOat",
        "expanded_url" : "http:\/\/bit.ly\/LjSH1S",
        "display_url" : "bit.ly\/LjSH1S"
      } ]
    },
    "geo" : { },
    "id_str" : "216183038357413889",
    "text" : "It's okay. http:\/\/t.co\/TDBCOOat",
    "id" : 216183038357413889,
    "created_at" : "2012-06-22 14:57:07 +0000",
    "user" : {
      "name" : "Sarah Kathleen Peck",
      "screen_name" : "sarahkpeck",
      "protected" : false,
      "id_str" : "196745496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000818335805\/0896697225422c65a0eec95f19efde78_normal.jpeg",
      "id" : 196745496,
      "verified" : false
    }
  },
  "id" : 216188479900622849,
  "created_at" : "2012-06-22 15:18:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Obituaries",
      "screen_name" : "NYTObits",
      "indices" : [ 17, 26 ],
      "id_str" : "16929470",
      "id" : 16929470
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obitoftheday",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/acAkO6kv",
      "expanded_url" : "http:\/\/bit.ly\/PI0O6G",
      "display_url" : "bit.ly\/PI0O6G"
    } ]
  },
  "geo" : { },
  "id_str" : "216187791195910144",
  "text" : "#obitoftheday RT @NYTObits: Andrew Sarris, one of the most influential film critics\/champion of auteur theory http:\/\/t.co\/acAkO6kv",
  "id" : 216187791195910144,
  "created_at" : "2012-06-22 15:16:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fetchnotes",
      "screen_name" : "fetchnotes",
      "indices" : [ 66, 77 ],
      "id_str" : "280073926",
      "id" : 280073926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/kQcp8PmN",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayNujdZq",
      "display_url" : "tmblr.co\/ZQJvayNujdZq"
    } ]
  },
  "geo" : { },
  "id_str" : "216184029228179456",
  "text" : "Documents are dead, long live the note! http:\/\/t.co\/kQcp8PmN \/via @fetchnotes",
  "id" : 216184029228179456,
  "created_at" : "2012-06-22 15:01:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Medina",
      "screen_name" : "medinism",
      "indices" : [ 14, 23 ],
      "id_str" : "15898775",
      "id" : 15898775
    }, {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "indices" : [ 121, 132 ],
      "id_str" : "419710142",
      "id" : 419710142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/8AnPGgh2",
      "expanded_url" : "http:\/\/pandodaily.com\/2012\/06\/21\/startup-delusion-and-embracing-the-schlep\/",
      "display_url" : "pandodaily.com\/2012\/06\/21\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "216044128633503745",
  "text" : "Awesome post, @medinism. I make this mistake often. \"Startup Delusion and Embracing the Schlep\" http:\/\/t.co\/8AnPGgh2 via @pandodaily",
  "id" : 216044128633503745,
  "created_at" : "2012-06-22 05:45:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew J. Rosenthal",
      "screen_name" : "andrewrosenthal",
      "indices" : [ 0, 16 ],
      "id_str" : "770178408",
      "id" : 770178408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216015925529415682",
  "geo" : { },
  "id_str" : "216037568477806592",
  "in_reply_to_user_id" : 15792969,
  "text" : "@andrewrosenthal I draw the line at sharing my footsie pajamas with the world. :)",
  "id" : 216037568477806592,
  "in_reply_to_status_id" : 216015925529415682,
  "created_at" : "2012-06-22 05:19:04 +0000",
  "in_reply_to_screen_name" : "rosenthal",
  "in_reply_to_user_id_str" : "15792969",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/NrCijDGB",
      "expanded_url" : "http:\/\/flic.kr\/p\/ciuHmf",
      "display_url" : "flic.kr\/p\/ciuHmf"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "216014926643335170",
  "text" : "8:36pm In my pjs re-renting Wanderlust from iTunes because I didn't finish it in time. I am dog tired. http:\/\/t.co\/NrCijDGB",
  "id" : 216014926643335170,
  "created_at" : "2012-06-22 03:49:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beeminder",
      "screen_name" : "bmndr",
      "indices" : [ 0, 6 ],
      "id_str" : "121250669",
      "id" : 121250669
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 7, 15 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "indices" : [ 16, 27 ],
      "id_str" : "809641",
      "id" : 809641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215983271710961665",
  "geo" : { },
  "id_str" : "215988277746995200",
  "in_reply_to_user_id" : 121250669,
  "text" : "@bmndr @dreeves @adamloving I\u2019m starting to believe that competition\/comparison of any kind only ends in fear\/guilt-based motivation.",
  "id" : 215988277746995200,
  "in_reply_to_status_id" : 215983271710961665,
  "created_at" : "2012-06-22 02:03:12 +0000",
  "in_reply_to_screen_name" : "bmndr",
  "in_reply_to_user_id_str" : "121250669",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beeminder",
      "screen_name" : "bmndr",
      "indices" : [ 0, 6 ],
      "id_str" : "121250669",
      "id" : 121250669
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 7, 15 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "indices" : [ 16, 27 ],
      "id_str" : "809641",
      "id" : 809641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215983271710961665",
  "geo" : { },
  "id_str" : "215987764930420736",
  "in_reply_to_user_id" : 121250669,
  "text" : "@bmndr @dreeves @adamloving The best daily goal is to simply show up. Put whatever you can in the pot (steps, minutes, whatever you track).",
  "id" : 215987764930420736,
  "in_reply_to_status_id" : 215983271710961665,
  "created_at" : "2012-06-22 02:01:10 +0000",
  "in_reply_to_screen_name" : "bmndr",
  "in_reply_to_user_id_str" : "121250669",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "indices" : [ 0, 11 ],
      "id_str" : "809641",
      "id" : 809641
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 12, 20 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Daniel Reeves",
      "screen_name" : "dreev",
      "indices" : [ 21, 27 ],
      "id_str" : "2040631",
      "id" : 2040631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215670078325272577",
  "geo" : { },
  "id_str" : "215976657272586240",
  "in_reply_to_user_id" : 809641,
  "text" : "@adamloving @dreeves @dreev Totals so that number goes up. Also, highlight streaks when they exist, hide when they don't.",
  "id" : 215976657272586240,
  "in_reply_to_status_id" : 215670078325272577,
  "created_at" : "2012-06-22 01:17:02 +0000",
  "in_reply_to_screen_name" : "adamloving",
  "in_reply_to_user_id_str" : "809641",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "indices" : [ 0, 11 ],
      "id_str" : "809641",
      "id" : 809641
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 12, 20 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Daniel Reeves",
      "screen_name" : "dreev",
      "indices" : [ 21, 27 ],
      "id_str" : "2040631",
      "id" : 2040631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215670078325272577",
  "geo" : { },
  "id_str" : "215976315176751105",
  "in_reply_to_user_id" : 809641,
  "text" : "@adamloving @dreeves @dreev Chiming in late but wanted to say I'm a big fan of trailing 30-day totals (not averages).",
  "id" : 215976315176751105,
  "in_reply_to_status_id" : 215670078325272577,
  "created_at" : "2012-06-22 01:15:40 +0000",
  "in_reply_to_screen_name" : "adamloving",
  "in_reply_to_user_id_str" : "809641",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215931570635292673",
  "geo" : { },
  "id_str" : "215950329718636544",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar Thanks, Chris. I propose we all celebrate with a nap.",
  "id" : 215950329718636544,
  "in_reply_to_status_id" : 215931570635292673,
  "created_at" : "2012-06-21 23:32:25 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215709095620132865",
  "text" : "For the most part, pinball makes no sense.",
  "id" : 215709095620132865,
  "created_at" : "2012-06-21 07:33:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 70, 81 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 83, 88 ],
      "id_str" : "541",
      "id" : 541
    }, {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "indices" : [ 94, 103 ],
      "id_str" : "22483",
      "id" : 22483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215708546594127873",
  "text" : "Learning about pinball history while playing pinball in Portland with @waxpancake, @lane, and @pinwheel.",
  "id" : 215708546594127873,
  "created_at" : "2012-06-21 07:31:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215656138086154243",
  "geo" : { },
  "id_str" : "215670699510075392",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake I would come wherever you are! Name a time and place!",
  "id" : 215670699510075392,
  "in_reply_to_status_id" : 215656138086154243,
  "created_at" : "2012-06-21 05:01:16 +0000",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 0, 5 ],
      "id_str" : "541",
      "id" : 541
    }, {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "indices" : [ 6, 15 ],
      "id_str" : "22483",
      "id" : 22483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215645288206041091",
  "geo" : { },
  "id_str" : "215652142428590080",
  "in_reply_to_user_id" : 541,
  "text" : "@lane @pinwheel I\u2019m at a table in the back with a friend!",
  "id" : 215652142428590080,
  "in_reply_to_status_id" : 215645288206041091,
  "created_at" : "2012-06-21 03:47:32 +0000",
  "in_reply_to_screen_name" : "lane",
  "in_reply_to_user_id_str" : "541",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/UXCU3B0z",
      "expanded_url" : "http:\/\/750words.com",
      "display_url" : "750words.com"
    }, {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/AheP7WSB",
      "expanded_url" : "http:\/\/instagr.am\/p\/MHwnMcI0N3\/",
      "display_url" : "instagr.am\/p\/MHwnMcI0N3\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52218, -122.681421 ]
  },
  "id_str" : "215651232440795138",
  "text" : "8:36pm Liene, who has written http:\/\/t.co\/UXCU3B0z 851 days in a row and counting! Woah.   @ Clyde Common http:\/\/t.co\/AheP7WSB",
  "id" : 215651232440795138,
  "created_at" : "2012-06-21 03:43:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/1JkJOFq2",
      "expanded_url" : "http:\/\/4sq.com\/M7qhVR",
      "display_url" : "4sq.com\/M7qhVR"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52218, -122.681421 ]
  },
  "id_str" : "215646780711370752",
  "text" : "Are you in Portland? Come join! (@ Clyde Common w\/ 8 others) http:\/\/t.co\/1JkJOFq2",
  "id" : 215646780711370752,
  "created_at" : "2012-06-21 03:26:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "indices" : [ 0, 9 ],
      "id_str" : "22483",
      "id" : 22483
    }, {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 10, 15 ],
      "id_str" : "541",
      "id" : 541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215644844356415490",
  "geo" : { },
  "id_str" : "215645038040977410",
  "in_reply_to_user_id" : 22483,
  "text" : "@pinwheel @lane Come to Clyde Commons! Headed there now\u2026",
  "id" : 215645038040977410,
  "in_reply_to_status_id" : 215644844356415490,
  "created_at" : "2012-06-21 03:19:18 +0000",
  "in_reply_to_screen_name" : "pinwheel",
  "in_reply_to_user_id_str" : "22483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "maybetoofriendly",
      "indices" : [ 80, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215644787389382658",
  "text" : "Portland is so friendly that the hotel front desk lady offered her couch to me. #maybetoofriendly?",
  "id" : 215644787389382658,
  "created_at" : "2012-06-21 03:18:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hotel Tonight",
      "screen_name" : "HotelTonight",
      "indices" : [ 9, 22 ],
      "id_str" : "19448539",
      "id" : 19448539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215643987833405440",
  "text" : "Twitter, @hoteltonight is the perfect enabler for non-planners. Thanks for the tip!",
  "id" : 215643987833405440,
  "created_at" : "2012-06-21 03:15:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "indices" : [ 0, 9 ],
      "id_str" : "22483",
      "id" : 22483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215639879579729921",
  "geo" : { },
  "id_str" : "215641229323538433",
  "in_reply_to_user_id" : 22483,
  "text" : "@pinwheel Thanks, decided to bite the bullet when they offered a big discount. Will know where I\u2019m going soon!",
  "id" : 215641229323538433,
  "in_reply_to_status_id" : 215639879579729921,
  "created_at" : "2012-06-21 03:04:10 +0000",
  "in_reply_to_screen_name" : "pinwheel",
  "in_reply_to_user_id_str" : "22483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215640797100519424",
  "geo" : { },
  "id_str" : "215641018475872256",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean Nah, bit the bullet when the nice front desk people gave me a huge discount. Thanks though!",
  "id" : 215641018475872256,
  "in_reply_to_status_id" : 215640797100519424,
  "created_at" : "2012-06-21 03:03:19 +0000",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renee DiResta",
      "screen_name" : "noUpside",
      "indices" : [ 0, 9 ],
      "id_str" : "24254084",
      "id" : 24254084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215637300669988864",
  "geo" : { },
  "id_str" : "215639800500322305",
  "in_reply_to_user_id" : 24254084,
  "text" : "@noUpside Ooh, didn\u2019t know about that! Will check. Thanks.",
  "id" : 215639800500322305,
  "in_reply_to_status_id" : 215637300669988864,
  "created_at" : "2012-06-21 02:58:29 +0000",
  "in_reply_to_screen_name" : "noUpside",
  "in_reply_to_user_id_str" : "24254084",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notaplanner",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215636808858480640",
  "text" : "Twitter! I\u2019m in Portland for the night and everything\u2019s booked except one $350 room. Anyone have a spare couch? :) #notaplanner",
  "id" : 215636808858480640,
  "created_at" : "2012-06-21 02:46:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alison Agosti",
      "screen_name" : "AlisonAgosti",
      "indices" : [ 3, 16 ],
      "id_str" : "14990751",
      "id" : 14990751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215556652248743936",
  "text" : "RT @AlisonAgosti: In space, no one can hear you scream for ice cream.\n\nEven if we all do it.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215556390217990145",
    "text" : "In space, no one can hear you scream for ice cream.\n\nEven if we all do it.",
    "id" : 215556390217990145,
    "created_at" : "2012-06-20 21:27:02 +0000",
    "user" : {
      "name" : "Alison Agosti",
      "screen_name" : "AlisonAgosti",
      "protected" : false,
      "id_str" : "14990751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000514953263\/3d2604c361dd90b9a3f540097d52b6f1_normal.jpeg",
      "id" : 14990751,
      "verified" : false
    }
  },
  "id" : 215556652248743936,
  "created_at" : "2012-06-20 21:28:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amtrak",
      "screen_name" : "Amtrak",
      "indices" : [ 0, 7 ],
      "id_str" : "119166791",
      "id" : 119166791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215540037356494848",
  "geo" : { },
  "id_str" : "215540283641823233",
  "in_reply_to_user_id" : 119166791,
  "text" : "@Amtrak Of course! Send me a link to it too when you do.",
  "id" : 215540283641823233,
  "in_reply_to_status_id" : 215540037356494848,
  "created_at" : "2012-06-20 20:23:02 +0000",
  "in_reply_to_screen_name" : "Amtrak",
  "in_reply_to_user_id_str" : "119166791",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/rXt8Q42c",
      "expanded_url" : "http:\/\/instagr.am\/p\/MG79aWI0N4\/",
      "display_url" : "instagr.am\/p\/MG79aWI0N4\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.9973122095, -122.780849281 ]
  },
  "id_str" : "215535546573926401",
  "text" : "Mt Rainier is pretty  @ Amtrak Cascades http:\/\/t.co\/rXt8Q42c",
  "id" : 215535546573926401,
  "created_at" : "2012-06-20 20:04:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Obituaries",
      "screen_name" : "NYTObits",
      "indices" : [ 17, 26 ],
      "id_str" : "16929470",
      "id" : 16929470
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obitoftheday",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/4yuWEa7E",
      "expanded_url" : "http:\/\/bit.ly\/MjaQLE",
      "display_url" : "bit.ly\/MjaQLE"
    } ]
  },
  "geo" : { },
  "id_str" : "215534397754052608",
  "text" : "#obitoftheday RT @NYTObits: Victor Spinetti Dies at 82; Actor in All 3 Beatles\u2019 Films http:\/\/t.co\/4yuWEa7E",
  "id" : 215534397754052608,
  "created_at" : "2012-06-20 19:59:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "twilio",
      "screen_name" : "twilio",
      "indices" : [ 0, 7 ],
      "id_str" : "15936194",
      "id" : 15936194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215530350967930881",
  "geo" : { },
  "id_str" : "215532872231157760",
  "in_reply_to_user_id" : 15936194,
  "text" : "@twilio Thanks. Email sent.",
  "id" : 215532872231157760,
  "in_reply_to_status_id" : 215530350967930881,
  "created_at" : "2012-06-20 19:53:35 +0000",
  "in_reply_to_screen_name" : "twilio",
  "in_reply_to_user_id_str" : "15936194",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : " Jason Levine \u2615",
      "screen_name" : "delfuego",
      "indices" : [ 0, 9 ],
      "id_str" : "677703",
      "id" : 677703
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 10, 19 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 20, 27 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215528265304125441",
  "geo" : { },
  "id_str" : "215529655200002048",
  "in_reply_to_user_id" : 677703,
  "text" : "@delfuego @anildash @torrez Totally! You guys are funny.",
  "id" : 215529655200002048,
  "in_reply_to_status_id" : 215528265304125441,
  "created_at" : "2012-06-20 19:40:48 +0000",
  "in_reply_to_screen_name" : "delfuego",
  "in_reply_to_user_id_str" : "677703",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215527403303342080",
  "text" : "One of the paradoxes of behavior change that I\u2019ve noticed is that caring too much about success often leads to increased odds of failure.",
  "id" : 215527403303342080,
  "created_at" : "2012-06-20 19:31:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "twilio",
      "screen_name" : "twilio",
      "indices" : [ 0, 7 ],
      "id_str" : "15936194",
      "id" : 15936194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215524712011415552",
  "in_reply_to_user_id" : 15936194,
  "text" : "@twilio I\u2019m getting a charge error on every card I try to pay with. Is there a known problem on your side? I need to recharge my funds soon!",
  "id" : 215524712011415552,
  "created_at" : "2012-06-20 19:21:10 +0000",
  "in_reply_to_screen_name" : "twilio",
  "in_reply_to_user_id_str" : "15936194",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Kottke",
      "screen_name" : "jkottke",
      "indices" : [ 17, 25 ],
      "id_str" : "1305941",
      "id" : 1305941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/FoWnI913",
      "expanded_url" : "http:\/\/bit.ly\/M7esRR",
      "display_url" : "bit.ly\/M7esRR"
    } ]
  },
  "geo" : { },
  "id_str" : "215518238434525184",
  "text" : "Great summary by @jkottke on all the pieces you need to compete with the iPad. It\u2019s quite daunting.  http:\/\/t.co\/FoWnI913",
  "id" : 215518238434525184,
  "created_at" : "2012-06-20 18:55:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "indices" : [ 0, 9 ],
      "id_str" : "22483",
      "id" : 22483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215514227505508353",
  "geo" : { },
  "id_str" : "215516577418850305",
  "in_reply_to_user_id" : 22483,
  "text" : "@pinwheel I\u2019m gonna be out somewhere this evening! I\u2019ll let you know. Would love to see ya!",
  "id" : 215516577418850305,
  "in_reply_to_status_id" : 215514227505508353,
  "created_at" : "2012-06-20 18:48:50 +0000",
  "in_reply_to_screen_name" : "pinwheel",
  "in_reply_to_user_id_str" : "22483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/jabfxy9e",
      "expanded_url" : "http:\/\/4sq.com\/M74e3I",
      "display_url" : "4sq.com\/M74e3I"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.598342908, -122.3297810555 ]
  },
  "id_str" : "215501618731421696",
  "text" : "SEA -&gt; PDX for the day. (@ King Street Station - Seattle Amtrak (SEA) w\/ 5 others) http:\/\/t.co\/jabfxy9e",
  "id" : 215501618731421696,
  "created_at" : "2012-06-20 17:49:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/fV5aiwqg",
      "expanded_url" : "http:\/\/flic.kr\/p\/chpYAf",
      "display_url" : "flic.kr\/p\/chpYAf"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "215288611166363650",
  "text" : "8:36pm Books before bed http:\/\/t.co\/fV5aiwqg",
  "id" : 215288611166363650,
  "created_at" : "2012-06-20 03:42:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215287020275245057",
  "geo" : { },
  "id_str" : "215287741791993856",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg Jobs, Zuck, Bezos, are the easy ones.",
  "id" : 215287741791993856,
  "in_reply_to_status_id" : 215287020275245057,
  "created_at" : "2012-06-20 03:39:32 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215282121537896448",
  "geo" : { },
  "id_str" : "215285302619668483",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg Any leader who\u2019s more interested in solving a human problem than anything else. It\u2019s difficult to stay focused at early stage cos.",
  "id" : 215285302619668483,
  "in_reply_to_status_id" : 215282121537896448,
  "created_at" : "2012-06-20 03:29:50 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215279088951238657",
  "text" : "I resent declarations of business success for simply growing, raising money, or even making money unless there\u2019s also LOTS of heart in it.",
  "id" : 215279088951238657,
  "created_at" : "2012-06-20 03:05:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doodlers Anonymous",
      "screen_name" : "doodlers",
      "indices" : [ 3, 12 ],
      "id_str" : "16826020",
      "id" : 16826020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/BbRdk3Lb",
      "expanded_url" : "http:\/\/ow.ly\/bF3RC",
      "display_url" : "ow.ly\/bF3RC"
    } ]
  },
  "geo" : { },
  "id_str" : "215236178687950848",
  "text" : "RT @doodlers: 12 drawings a day (a hand-drawn animation on used paper from the copy room) EPIC! http:\/\/t.co\/BbRdk3Lb",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/BbRdk3Lb",
        "expanded_url" : "http:\/\/ow.ly\/bF3RC",
        "display_url" : "ow.ly\/bF3RC"
      } ]
    },
    "geo" : { },
    "id_str" : "215088876157546496",
    "text" : "12 drawings a day (a hand-drawn animation on used paper from the copy room) EPIC! http:\/\/t.co\/BbRdk3Lb",
    "id" : 215088876157546496,
    "created_at" : "2012-06-19 14:29:18 +0000",
    "user" : {
      "name" : "Doodlers Anonymous",
      "screen_name" : "doodlers",
      "protected" : false,
      "id_str" : "16826020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/62277154\/Untitled-2_normal.jpg",
      "id" : 16826020,
      "verified" : false
    }
  },
  "id" : 215236178687950848,
  "created_at" : "2012-06-20 00:14:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kottke.org",
      "screen_name" : "kottke",
      "indices" : [ 56, 63 ],
      "id_str" : "14120215",
      "id" : 14120215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/vGBC0bq8",
      "expanded_url" : "http:\/\/kottke.org\/12\/06\/holy-levitating-slinky",
      "display_url" : "kottke.org\/12\/06\/holy-lev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "215172558205616131",
  "text" : "Holy levitating slinky [vid]: http:\/\/t.co\/vGBC0bq8 \/via @kottke \n\nIt makes sense but it's triply to watch.",
  "id" : 215172558205616131,
  "created_at" : "2012-06-19 20:01:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215155616073793537",
  "geo" : { },
  "id_str" : "215157032146317312",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid I totally agree. My order is \u201Cprocessing\u201D and not estimated to arrive for another 3 weeks at least.",
  "id" : 215157032146317312,
  "in_reply_to_status_id" : 215155616073793537,
  "created_at" : "2012-06-19 19:00:08 +0000",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bennett",
      "screen_name" : "Caesar_X",
      "indices" : [ 0, 9 ],
      "id_str" : "14270791",
      "id" : 14270791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215140522233303041",
  "geo" : { },
  "id_str" : "215140962316468224",
  "in_reply_to_user_id" : 14270791,
  "text" : "@Caesar_X That made me laugh! Thank you.",
  "id" : 215140962316468224,
  "in_reply_to_status_id" : 215140522233303041,
  "created_at" : "2012-06-19 17:56:17 +0000",
  "in_reply_to_screen_name" : "Caesar_X",
  "in_reply_to_user_id_str" : "14270791",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215138601858641920",
  "text" : "I\u2019d rather have a broken foot than a broken work computer. At least, today.",
  "id" : 215138601858641920,
  "created_at" : "2012-06-19 17:46:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Obituaries",
      "screen_name" : "NYTObits",
      "indices" : [ 17, 26 ],
      "id_str" : "16929470",
      "id" : 16929470
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obitoftheday",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/FIkRItoh",
      "expanded_url" : "http:\/\/bit.ly\/Plyk2i",
      "display_url" : "bit.ly\/Plyk2i"
    } ]
  },
  "geo" : { },
  "id_str" : "215135343199010817",
  "text" : "#obitoftheday RT @NYTObits: Erica Kennedy, whose novel \"Bling\" brought chick-lit to a black audience http:\/\/t.co\/FIkRItoh",
  "id" : 215135343199010817,
  "created_at" : "2012-06-19 17:33:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Morga",
      "screen_name" : "AliciaMorga",
      "indices" : [ 85, 97 ],
      "id_str" : "19053875",
      "id" : 19053875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/kGgw4bMM",
      "expanded_url" : "http:\/\/bit.ly\/NMWoOv",
      "display_url" : "bit.ly\/NMWoOv"
    } ]
  },
  "geo" : { },
  "id_str" : "215128532588838912",
  "text" : "Alicia\u2019s mini book helped remind me of my values as an entrepreneur. Recommended! RT @AliciaMorga: Lessons learned:  http:\/\/t.co\/kGgw4bMM",
  "id" : 215128532588838912,
  "created_at" : "2012-06-19 17:06:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/gpyUx4yS",
      "expanded_url" : "http:\/\/vook.com",
      "display_url" : "vook.com"
    } ]
  },
  "geo" : { },
  "id_str" : "215110673410166784",
  "text" : "Has anyone used http:\/\/t.co\/gpyUx4yS?",
  "id" : 215110673410166784,
  "created_at" : "2012-06-19 15:55:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Morga",
      "screen_name" : "AliciaMorga",
      "indices" : [ 0, 12 ],
      "id_str" : "19053875",
      "id" : 19053875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215106742625898496",
  "geo" : { },
  "id_str" : "215107313688772609",
  "in_reply_to_user_id" : 19053875,
  "text" : "@AliciaMorga Have you written up the experience anywhere? I'm about to start researching similar things and would love any advice.",
  "id" : 215107313688772609,
  "in_reply_to_status_id" : 215106742625898496,
  "created_at" : "2012-06-19 15:42:34 +0000",
  "in_reply_to_screen_name" : "AliciaMorga",
  "in_reply_to_user_id_str" : "19053875",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan D. Gantz, CPK",
      "screen_name" : "sixfoot6",
      "indices" : [ 0, 9 ],
      "id_str" : "822030",
      "id" : 822030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215102172600352769",
  "geo" : { },
  "id_str" : "215102401114415105",
  "in_reply_to_user_id" : 822030,
  "text" : "@sixfoot6 You definitely should. I have a special place in my heart for projects that use themselves to get built.",
  "id" : 215102401114415105,
  "in_reply_to_status_id" : 215102172600352769,
  "created_at" : "2012-06-19 15:23:03 +0000",
  "in_reply_to_screen_name" : "sixfoot6",
  "in_reply_to_user_id_str" : "822030",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Morga",
      "screen_name" : "AliciaMorga",
      "indices" : [ 0, 12 ],
      "id_str" : "19053875",
      "id" : 19053875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215096834421563393",
  "geo" : { },
  "id_str" : "215099496193990657",
  "in_reply_to_user_id" : 19053875,
  "text" : "@AliciaMorga Bought it! Are you using the iBooks Author tool to write these?",
  "id" : 215099496193990657,
  "in_reply_to_status_id" : 215096834421563393,
  "created_at" : "2012-06-19 15:11:30 +0000",
  "in_reply_to_screen_name" : "AliciaMorga",
  "in_reply_to_user_id_str" : "19053875",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan D. Gantz, CPK",
      "screen_name" : "sixfoot6",
      "indices" : [ 0, 9 ],
      "id_str" : "822030",
      "id" : 822030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215091210916855808",
  "geo" : { },
  "id_str" : "215097989604179972",
  "in_reply_to_user_id" : 822030,
  "text" : "@sixfoot6 It\u2019s really slick. So many live blogging tools suck. Well done. Now I just wish I had something to live blog.",
  "id" : 215097989604179972,
  "in_reply_to_status_id" : 215091210916855808,
  "created_at" : "2012-06-19 15:05:31 +0000",
  "in_reply_to_screen_name" : "sixfoot6",
  "in_reply_to_user_id_str" : "822030",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MacRumors.com",
      "screen_name" : "MacRumors",
      "indices" : [ 8, 18 ],
      "id_str" : "14861285",
      "id" : 14861285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/p6gkdSad",
      "expanded_url" : "http:\/\/bit.ly\/KQP6DK",
      "display_url" : "bit.ly\/KQP6DK"
    } ]
  },
  "geo" : { },
  "id_str" : "215088631210180608",
  "text" : "Wow. RT @MacRumors: Teardown of New MacBook Pro\u2019s Retina Display Reveals \u2018Engineering Marvel\u2019 http:\/\/t.co\/p6gkdSad",
  "id" : 215088631210180608,
  "created_at" : "2012-06-19 14:28:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 106, 116 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214964466226446336",
  "geo" : { },
  "id_str" : "214964788336410624",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Something to do with chia seeds, oatmeal, and mason jars. I\u2019ll let you know more tomorrow. \/cc @kellianne",
  "id" : 214964788336410624,
  "in_reply_to_status_id" : 214964466226446336,
  "created_at" : "2012-06-19 06:16:14 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/1bBEjSDP",
      "expanded_url" : "http:\/\/flic.kr\/p\/cgSQPf",
      "display_url" : "flic.kr\/p\/cgSQPf"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "214961059528839169",
  "text" : "8:36pm Was sleeping in Niko's room. Now helping Kellianne with some crazy new breakfast idea. http:\/\/t.co\/1bBEjSDP",
  "id" : 214961059528839169,
  "created_at" : "2012-06-19 06:01:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214908631219585024",
  "geo" : { },
  "id_str" : "214909356225986561",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin I know, that was unfair. I feel bad now for my negative knee jerk reaction. I\u2019m sure it\u2019s a great product.",
  "id" : 214909356225986561,
  "in_reply_to_status_id" : 214908631219585024,
  "created_at" : "2012-06-19 02:35:58 +0000",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/azOFlUIo",
      "expanded_url" : "http:\/\/instagr.am\/p\/MCYwiQI0HO\/",
      "display_url" : "instagr.am\/p\/MCYwiQI0HO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "214894974041456641",
  "text" : "Hands up if you like trains http:\/\/t.co\/azOFlUIo",
  "id" : 214894974041456641,
  "created_at" : "2012-06-19 01:38:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214868301426335745",
  "text" : "Watching the Microsoft Surface launch is like watching an old ex tell you about how they fixed all those things you dumped them for.",
  "id" : 214868301426335745,
  "created_at" : "2012-06-18 23:52:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Duhigg",
      "screen_name" : "cduhigg",
      "indices" : [ 3, 11 ],
      "id_str" : "20570290",
      "id" : 20570290
    }, {
      "name" : "Ed Yong ",
      "screen_name" : "edyong209",
      "indices" : [ 103, 113 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214800030110982144",
  "text" : "RT @cduhigg: Tunes without composers: music naturally evolves on DarwinTunes http:\/\/bit.ly\/NHt7oz from @edyong209",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ed Yong ",
        "screen_name" : "edyong209",
        "indices" : [ 90, 100 ],
        "id_str" : "19767193",
        "id" : 19767193
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "214798352188059648",
    "text" : "Tunes without composers: music naturally evolves on DarwinTunes http:\/\/bit.ly\/NHt7oz from @edyong209",
    "id" : 214798352188059648,
    "created_at" : "2012-06-18 19:14:52 +0000",
    "user" : {
      "name" : "Charles Duhigg",
      "screen_name" : "cduhigg",
      "protected" : false,
      "id_str" : "20570290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/79455504\/topics_duhigg_190_normal.jpg",
      "id" : 20570290,
      "verified" : true
    }
  },
  "id" : 214800030110982144,
  "created_at" : "2012-06-18 19:21:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214799530758115328",
  "text" : "Spread-Too-Thin-O-Meter: 10",
  "id" : 214799530758115328,
  "created_at" : "2012-06-18 19:19:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chelsea Howe",
      "screen_name" : "manojalpa",
      "indices" : [ 26, 36 ],
      "id_str" : "19923765",
      "id" : 19923765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/gM8kGBWJ",
      "expanded_url" : "http:\/\/bit.ly\/N0HzC0",
      "display_url" : "bit.ly\/N0HzC0"
    } ]
  },
  "geo" : { },
  "id_str" : "214790160418734082",
  "text" : "Awesome post, Chelsea! RT @manojalpa: Right, I wrote this thing: Gameful Design vs. Gamification - http:\/\/t.co\/gM8kGBWJ",
  "id" : 214790160418734082,
  "created_at" : "2012-06-18 18:42:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 3, 14 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214729589648392193",
  "text" : "RT @seanbonner: Think Tank vs. Think-And-Action Tank",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "214716180924080131",
    "text" : "Think Tank vs. Think-And-Action Tank",
    "id" : 214716180924080131,
    "created_at" : "2012-06-18 13:48:21 +0000",
    "user" : {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "protected" : false,
      "id_str" : "765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416764038962348032\/rQuyO9H-_normal.png",
      "id" : 765,
      "verified" : false
    }
  },
  "id" : 214729589648392193,
  "created_at" : "2012-06-18 14:41:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Obituaries",
      "screen_name" : "NYTObits",
      "indices" : [ 17, 26 ],
      "id_str" : "16929470",
      "id" : 16929470
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obitoftheday",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/6gkaa356",
      "expanded_url" : "http:\/\/bit.ly\/M5XEXo",
      "display_url" : "bit.ly\/M5XEXo"
    } ]
  },
  "geo" : { },
  "id_str" : "214568636034191360",
  "text" : "#obitoftheday RT @NYTObits: Bob Chappuis, Halfback Rescued in World War II, Dies at 89 http:\/\/t.co\/6gkaa356",
  "id" : 214568636034191360,
  "created_at" : "2012-06-18 04:02:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/2ykyB6tR",
      "expanded_url" : "http:\/\/instagr.am\/p\/MACEDjo0FH\/",
      "display_url" : "instagr.am\/p\/MACEDjo0FH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "214563846352941056",
  "text" : "8:36pm Niko wanted to end Father's Day dinner early so we could play more of this  http:\/\/t.co\/2ykyB6tR",
  "id" : 214563846352941056,
  "created_at" : "2012-06-18 03:43:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poquitos Seattle",
      "screen_name" : "vivapoquitos",
      "indices" : [ 30, 43 ],
      "id_str" : "212326224",
      "id" : 212326224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/UTWWYOPe",
      "expanded_url" : "http:\/\/path.com\/p\/5heRL",
      "display_url" : "path.com\/p\/5heRL"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614222, -122.319127 ]
  },
  "id_str" : "214538221776945154",
  "text" : "Bus tunnel (with Kellianne at @vivapoquitos) [vid] \u2014 http:\/\/t.co\/UTWWYOPe",
  "id" : 214538221776945154,
  "created_at" : "2012-06-18 02:01:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quazie",
      "screen_name" : "Quazie",
      "indices" : [ 0, 7 ],
      "id_str" : "7389212",
      "id" : 7389212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214491592063582208",
  "geo" : { },
  "id_str" : "214494873376653313",
  "in_reply_to_user_id" : 7389212,
  "text" : "@Quazie You'll have to verify for me that it works, but there's now a quiet mode setting on the account page.",
  "id" : 214494873376653313,
  "in_reply_to_status_id" : 214491592063582208,
  "created_at" : "2012-06-17 23:08:57 +0000",
  "in_reply_to_screen_name" : "Quazie",
  "in_reply_to_user_id_str" : "7389212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quazie",
      "screen_name" : "Quazie",
      "indices" : [ 0, 7 ],
      "id_str" : "7389212",
      "id" : 7389212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214491592063582208",
  "geo" : { },
  "id_str" : "214493376920305666",
  "in_reply_to_user_id" : 7389212,
  "text" : "@Quazie That's weird. I have no idea but I'll look into it.",
  "id" : 214493376920305666,
  "in_reply_to_status_id" : 214491592063582208,
  "created_at" : "2012-06-17 23:03:00 +0000",
  "in_reply_to_screen_name" : "Quazie",
  "in_reply_to_user_id_str" : "7389212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quazie",
      "screen_name" : "Quazie",
      "indices" : [ 0, 7 ],
      "id_str" : "7389212",
      "id" : 7389212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214490720298479616",
  "geo" : { },
  "id_str" : "214491152978690048",
  "in_reply_to_user_id" : 7389212,
  "text" : "@Quazie Can you send me a screenshot?",
  "id" : 214491152978690048,
  "in_reply_to_status_id" : 214490720298479616,
  "created_at" : "2012-06-17 22:54:10 +0000",
  "in_reply_to_screen_name" : "Quazie",
  "in_reply_to_user_id_str" : "7389212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quazie",
      "screen_name" : "Quazie",
      "indices" : [ 0, 7 ],
      "id_str" : "7389212",
      "id" : 7389212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214488943046037505",
  "geo" : { },
  "id_str" : "214489055067516928",
  "in_reply_to_user_id" : 7389212,
  "text" : "@Quazie I can add that for ya. Give me a bit.",
  "id" : 214489055067516928,
  "in_reply_to_status_id" : 214488943046037505,
  "created_at" : "2012-06-17 22:45:50 +0000",
  "in_reply_to_screen_name" : "Quazie",
  "in_reply_to_user_id_str" : "7389212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quazie",
      "screen_name" : "Quazie",
      "indices" : [ 0, 7 ],
      "id_str" : "7389212",
      "id" : 7389212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214487182998646784",
  "geo" : { },
  "id_str" : "214487795207651329",
  "in_reply_to_user_id" : 7389212,
  "text" : "@Quazie AWESOME. :) Let me know what you think of it after you use it a bit. I'm trying to keep it as simple as possible while being useful.",
  "id" : 214487795207651329,
  "in_reply_to_status_id" : 214487182998646784,
  "created_at" : "2012-06-17 22:40:50 +0000",
  "in_reply_to_screen_name" : "Quazie",
  "in_reply_to_user_id_str" : "7389212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quazie",
      "screen_name" : "Quazie",
      "indices" : [ 0, 7 ],
      "id_str" : "7389212",
      "id" : 7389212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214486559775408129",
  "geo" : { },
  "id_str" : "214486823685193728",
  "in_reply_to_user_id" : 7389212,
  "text" : "@Quazie Yeah, it's completely private. No social stuff at all, other than a list of people who've updated recently.",
  "id" : 214486823685193728,
  "in_reply_to_status_id" : 214486559775408129,
  "created_at" : "2012-06-17 22:36:58 +0000",
  "in_reply_to_screen_name" : "Quazie",
  "in_reply_to_user_id_str" : "7389212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quazie",
      "screen_name" : "Quazie",
      "indices" : [ 0, 7 ],
      "id_str" : "7389212",
      "id" : 7389212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/ZwsjY1DS",
      "expanded_url" : "http:\/\/peabrain.co",
      "display_url" : "peabrain.co"
    } ]
  },
  "in_reply_to_status_id_str" : "214484962227929088",
  "geo" : { },
  "id_str" : "214485270517661696",
  "in_reply_to_user_id" : 7389212,
  "text" : "@Quazie No fear of updating wrong account, easier to search\/tag, more visualization. I updated the logged out homepage: http:\/\/t.co\/ZwsjY1DS",
  "id" : 214485270517661696,
  "in_reply_to_status_id" : 214484962227929088,
  "created_at" : "2012-06-17 22:30:48 +0000",
  "in_reply_to_screen_name" : "Quazie",
  "in_reply_to_user_id_str" : "7389212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Davis",
      "screen_name" : "kaisdavis",
      "indices" : [ 0, 10 ],
      "id_str" : "63337932",
      "id" : 63337932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214483221814059008",
  "geo" : { },
  "id_str" : "214483559816237056",
  "in_reply_to_user_id" : 63337932,
  "text" : "@kaisdavis Thanks! It's very new so let me know how you end up using it, and any other feedback you have.",
  "id" : 214483559816237056,
  "in_reply_to_status_id" : 214483221814059008,
  "created_at" : "2012-06-17 22:24:00 +0000",
  "in_reply_to_screen_name" : "kaisdavis",
  "in_reply_to_user_id_str" : "63337932",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/c1l8PQcg",
      "expanded_url" : "http:\/\/peabrain.co\/users\/sign_up",
      "display_url" : "peabrain.co\/users\/sign_up"
    } ]
  },
  "in_reply_to_status_id_str" : "214459278252187648",
  "geo" : { },
  "id_str" : "214459502362230787",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez Ooh, I'd love your feedback specifically. You can sign up here, it's open: http:\/\/t.co\/c1l8PQcg",
  "id" : 214459502362230787,
  "in_reply_to_status_id" : 214459278252187648,
  "created_at" : "2012-06-17 20:48:24 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/2C3aC8FN",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayNapkgS",
      "display_url" : "tmblr.co\/ZQJvayNapkgS"
    } ]
  },
  "geo" : { },
  "id_str" : "214457418367770626",
  "text" : "Screenshot of a new tiny project, Peabrain: http:\/\/t.co\/2C3aC8FN",
  "id" : 214457418367770626,
  "created_at" : "2012-06-17 20:40:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    }, {
      "name" : "Fetchnotes",
      "screen_name" : "fetchnotes",
      "indices" : [ 32, 43 ],
      "id_str" : "280073926",
      "id" : 280073926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214449713049636865",
  "geo" : { },
  "id_str" : "214450952390983680",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg Another similar product is @fetchnotes. I'm focused on using it to track and remember important things, not as todo or task list.",
  "id" : 214450952390983680,
  "in_reply_to_status_id" : 214449713049636865,
  "created_at" : "2012-06-17 20:14:26 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/ZwsjY1DS",
      "expanded_url" : "http:\/\/peabrain.co",
      "display_url" : "peabrain.co"
    } ]
  },
  "in_reply_to_status_id_str" : "214447502110363649",
  "geo" : { },
  "id_str" : "214447850229211136",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg I'm working on a side project that you might like: http:\/\/t.co\/ZwsjY1DS It's a private sms journal that tracks and visualizes stuff.",
  "id" : 214447850229211136,
  "in_reply_to_status_id" : 214447502110363649,
  "created_at" : "2012-06-17 20:02:06 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214446012759162880",
  "geo" : { },
  "id_str" : "214446804945743872",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg Ooh, I haven't seen that one before. I'll check it out. What would the perfect tool be to help you systemize this?",
  "id" : 214446804945743872,
  "in_reply_to_status_id" : 214446012759162880,
  "created_at" : "2012-06-17 19:57:57 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@sweden \/ Helena",
      "screen_name" : "sweden",
      "indices" : [ 3, 10 ],
      "id_str" : "19663706",
      "id" : 19663706
    }, {
      "name" : "Sonja",
      "screen_name" : "hejsonja",
      "indices" : [ 104, 113 ],
      "id_str" : "23215997",
      "id" : 23215997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/LMqgjdXw",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=5HADIO5dhXU",
      "display_url" : "youtube.com\/watch?v=5HADIO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "214435804930506752",
  "text" : "RT @sweden: I made a video for you, where I talk a little about this week. http:\/\/t.co\/LMqgjdXw LOVE \/\/ @hejsonja",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sonja",
        "screen_name" : "hejsonja",
        "indices" : [ 92, 101 ],
        "id_str" : "23215997",
        "id" : 23215997
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/LMqgjdXw",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=5HADIO5dhXU",
        "display_url" : "youtube.com\/watch?v=5HADIO\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "214432198848286721",
    "text" : "I made a video for you, where I talk a little about this week. http:\/\/t.co\/LMqgjdXw LOVE \/\/ @hejsonja",
    "id" : 214432198848286721,
    "created_at" : "2012-06-17 18:59:54 +0000",
    "user" : {
      "name" : "@sweden \/ Helena",
      "screen_name" : "sweden",
      "protected" : false,
      "id_str" : "19663706",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465746880391938048\/3B3xbTNL_normal.png",
      "id" : 19663706,
      "verified" : false
    }
  },
  "id" : 214435804930506752,
  "created_at" : "2012-06-17 19:14:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/WHMi9hlb",
      "expanded_url" : "http:\/\/instagr.am\/p\/L_CSwsI0E2\/",
      "display_url" : "instagr.am\/p\/L_CSwsI0E2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "214423546720559104",
  "text" : "Father's Day portrait http:\/\/t.co\/WHMi9hlb",
  "id" : 214423546720559104,
  "created_at" : "2012-06-17 18:25:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cal Henderson",
      "screen_name" : "iamcal",
      "indices" : [ 23, 30 ],
      "id_str" : "6104",
      "id" : 6104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/MnaL0T6W",
      "expanded_url" : "http:\/\/bit.ly\/KEFkcv",
      "display_url" : "bit.ly\/KEFkcv"
    } ]
  },
  "geo" : { },
  "id_str" : "214386112460894208",
  "text" : "Amazing stuff, Cal! RT @iamcal: My latest project: World of MapCraft http:\/\/t.co\/MnaL0T6W",
  "id" : 214386112460894208,
  "created_at" : "2012-06-17 15:56:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "indices" : [ 3, 17 ],
      "id_str" : "19575586",
      "id" : 19575586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/Uo26YOiM",
      "expanded_url" : "http:\/\/www.empiricalzeal.com\/2012\/06\/11\/the-crayola-fication-of-the-world-how-we-gave-colors-names-and-it-messed-with-our-brains-part-ii\/",
      "display_url" : "empiricalzeal.com\/2012\/06\/11\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "214223541439168512",
  "text" : "RT @hackernewsbot: How we gave colors names and it messed with our brains (part II)... http:\/\/t.co\/Uo26YOiM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/news.ycombinator.com\/\" rel=\"nofollow\"\u003EHacker News Bot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/Uo26YOiM",
        "expanded_url" : "http:\/\/www.empiricalzeal.com\/2012\/06\/11\/the-crayola-fication-of-the-world-how-we-gave-colors-names-and-it-messed-with-our-brains-part-ii\/",
        "display_url" : "empiricalzeal.com\/2012\/06\/11\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "214171029285773312",
    "text" : "How we gave colors names and it messed with our brains (part II)... http:\/\/t.co\/Uo26YOiM",
    "id" : 214171029285773312,
    "created_at" : "2012-06-17 01:42:07 +0000",
    "user" : {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "protected" : false,
      "id_str" : "19575586",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/73596050\/yc500_normal.jpg",
      "id" : 19575586,
      "verified" : false
    }
  },
  "id" : 214223541439168512,
  "created_at" : "2012-06-17 05:10:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 79, 89 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214214257913503745",
  "text" : "Apparently a lot of pretty weather happened tonight all over the country. \/via @instagram.",
  "id" : 214214257913503745,
  "created_at" : "2012-06-17 04:33:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sointense",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/W76d0Yh0",
      "expanded_url" : "http:\/\/instagr.am\/p\/L9dnUQI0DZ\/",
      "display_url" : "instagr.am\/p\/L9dnUQI0DZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "214202031924191232",
  "text" : "8:36pm Double rainbow #sointense http:\/\/t.co\/W76d0Yh0",
  "id" : 214202031924191232,
  "created_at" : "2012-06-17 03:45:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Khomenko",
      "screen_name" : "akhomenko",
      "indices" : [ 0, 10 ],
      "id_str" : "46498656",
      "id" : 46498656
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 11, 22 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Bastian Greshake",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 23, 39 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214148344686182400",
  "geo" : { },
  "id_str" : "214151812746452992",
  "in_reply_to_user_id" : 46498656,
  "text" : "@akhomenko @openSNPorg @gedankenstuecke That\u2019s exactly what I was looking for. Thanks for the tip off.",
  "id" : 214151812746452992,
  "in_reply_to_status_id" : 214148344686182400,
  "created_at" : "2012-06-17 00:25:45 +0000",
  "in_reply_to_screen_name" : "akhomenko",
  "in_reply_to_user_id_str" : "46498656",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Linden",
      "screen_name" : "greglinden",
      "indices" : [ 82, 93 ],
      "id_str" : "87719108",
      "id" : 87719108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 76 ],
      "url" : "https:\/\/t.co\/oGszVOp8",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ZKOI_lVDPpw",
      "display_url" : "youtube.com\/watch?v=ZKOI_l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "214140147032272896",
  "text" : "Coffee grounds + balloon + air = versatile robot hand! https:\/\/t.co\/oGszVOp8 \/via @greglinden",
  "id" : 214140147032272896,
  "created_at" : "2012-06-16 23:39:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Urban",
      "screen_name" : "allisonurban",
      "indices" : [ 0, 13 ],
      "id_str" : "15741355",
      "id" : 15741355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214135643176046593",
  "geo" : { },
  "id_str" : "214135903394861056",
  "in_reply_to_user_id" : 15741355,
  "text" : "@allisonurban Cool, let me know when you do!",
  "id" : 214135903394861056,
  "in_reply_to_status_id" : 214135643176046593,
  "created_at" : "2012-06-16 23:22:32 +0000",
  "in_reply_to_screen_name" : "allisonurban",
  "in_reply_to_user_id_str" : "15741355",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 0, 7 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "100Plus",
      "screen_name" : "100Plus",
      "indices" : [ 33, 41 ],
      "id_str" : "40635897",
      "id" : 40635897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214133790187065344",
  "geo" : { },
  "id_str" : "214133981690597376",
  "in_reply_to_user_id" : 15727738,
  "text" : "@cwhogg Ooh, let me play! :) \/cc @100plus",
  "id" : 214133981690597376,
  "in_reply_to_status_id" : 214133790187065344,
  "created_at" : "2012-06-16 23:14:54 +0000",
  "in_reply_to_screen_name" : "cwhogg",
  "in_reply_to_user_id_str" : "15727738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/Iwa64SBO",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayNXFwlh",
      "display_url" : "tmblr.co\/ZQJvayNXFwlh"
    } ]
  },
  "geo" : { },
  "id_str" : "214132146644844547",
  "text" : "Why I'm doing \/public: http:\/\/t.co\/Iwa64SBO",
  "id" : 214132146644844547,
  "created_at" : "2012-06-16 23:07:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "indices" : [ 0, 4 ],
      "id_str" : "11822502",
      "id" : 11822502
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 10, 18 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214130468294107137",
  "geo" : { },
  "id_str" : "214130601165455361",
  "in_reply_to_user_id" : 11822502,
  "text" : "@mko Yup, @23andme.",
  "id" : 214130601165455361,
  "in_reply_to_status_id" : 214130468294107137,
  "created_at" : "2012-06-16 23:01:28 +0000",
  "in_reply_to_screen_name" : "mko",
  "in_reply_to_user_id_str" : "11822502",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Fine",
      "screen_name" : "samuelfine",
      "indices" : [ 0, 11 ],
      "id_str" : "200236063",
      "id" : 200236063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214128510527217665",
  "geo" : { },
  "id_str" : "214130355106619392",
  "in_reply_to_user_id" : 200236063,
  "text" : "@samuelfine I'm optimistic that we have more to gain by learning about\/sharing our genome than to lose. But I'm crazy like that.",
  "id" : 214130355106619392,
  "in_reply_to_status_id" : 214128510527217665,
  "created_at" : "2012-06-16 23:00:29 +0000",
  "in_reply_to_screen_name" : "samuelfine",
  "in_reply_to_user_id_str" : "200236063",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shrutarshi Basu",
      "screen_name" : "basus",
      "indices" : [ 0, 6 ],
      "id_str" : "9469312",
      "id" : 9469312
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 13, 21 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214127333370634240",
  "geo" : { },
  "id_str" : "214127851081957377",
  "in_reply_to_user_id" : 9469312,
  "text" : "@basus Yeah, @23andme has a raw data export option.",
  "id" : 214127851081957377,
  "in_reply_to_status_id" : 214127333370634240,
  "created_at" : "2012-06-16 22:50:32 +0000",
  "in_reply_to_screen_name" : "basus",
  "in_reply_to_user_id_str" : "9469312",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Fine",
      "screen_name" : "samuelfine",
      "indices" : [ 0, 11 ],
      "id_str" : "200236063",
      "id" : 200236063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214126750949588993",
  "geo" : { },
  "id_str" : "214126982978469888",
  "in_reply_to_user_id" : 200236063,
  "text" : "@samuelfine Yeah, I want to know anything that anyone can figure out about my genome as soon as possible.",
  "id" : 214126982978469888,
  "in_reply_to_status_id" : 214126750949588993,
  "created_at" : "2012-06-16 22:47:05 +0000",
  "in_reply_to_screen_name" : "samuelfine",
  "in_reply_to_user_id_str" : "200236063",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shrutarshi Basu",
      "screen_name" : "basus",
      "indices" : [ 0, 6 ],
      "id_str" : "9469312",
      "id" : 9469312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214126520854249472",
  "geo" : { },
  "id_str" : "214126812291268609",
  "in_reply_to_user_id" : 9469312,
  "text" : "@basus As long as they're willing to submit a pull request for new major features, that sounds awesome.",
  "id" : 214126812291268609,
  "in_reply_to_status_id" : 214126520854249472,
  "created_at" : "2012-06-16 22:46:24 +0000",
  "in_reply_to_screen_name" : "basus",
  "in_reply_to_user_id_str" : "9469312",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214126382802939906",
  "text" : "I just uploaded my genome to my public Github repository, but unfortunately it's too big to view in their code browser.",
  "id" : 214126382802939906,
  "created_at" : "2012-06-16 22:44:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214124841392021504",
  "geo" : { },
  "id_str" : "214125301825945600",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Not at all! Can I have some visitation rights with my clone when he grows up a bit?",
  "id" : 214125301825945600,
  "in_reply_to_status_id" : 214124841392021504,
  "created_at" : "2012-06-16 22:40:24 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 33, 41 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214124538731044864",
  "text" : "I just downloaded my genome from @23andme. Is there any compelling reason NOT to make it public?",
  "id" : 214124538731044864,
  "created_at" : "2012-06-16 22:37:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 10, 17 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214064536163074048",
  "geo" : { },
  "id_str" : "214065973110648834",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley @harryh Wow. That\u2019s sort of why this whole project is so interesting.",
  "id" : 214065973110648834,
  "in_reply_to_status_id" : 214064536163074048,
  "created_at" : "2012-06-16 18:44:39 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "@sweden \/ Helena",
      "screen_name" : "sweden",
      "indices" : [ 60, 67 ],
      "id_str" : "19663706",
      "id" : 19663706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214061981685129216",
  "geo" : { },
  "id_str" : "214062515884261376",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh No, I\u2019ve only been following sporadically. How many @sweden occupants ago was that? Yikes, but also hope they don\u2019t censor.",
  "id" : 214062515884261376,
  "in_reply_to_status_id" : 214061981685129216,
  "created_at" : "2012-06-16 18:30:55 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@sweden \/ Helena",
      "screen_name" : "sweden",
      "indices" : [ 12, 19 ],
      "id_str" : "19663706",
      "id" : 19663706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214060893934329856",
  "text" : "The current @sweden is really good.",
  "id" : 214060893934329856,
  "created_at" : "2012-06-16 18:24:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@sweden \/ Helena",
      "screen_name" : "sweden",
      "indices" : [ 3, 10 ],
      "id_str" : "19663706",
      "id" : 19663706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214058633670041601",
  "text" : "RT @sweden: It looked like a wing placed in what appeared to me as one of my moms sauces, but I knew it wasn't, even though her sauce wa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213983717545353216",
    "text" : "It looked like a wing placed in what appeared to me as one of my moms sauces, but I knew it wasn't, even though her sauce was disgusting.",
    "id" : 213983717545353216,
    "created_at" : "2012-06-16 13:17:48 +0000",
    "user" : {
      "name" : "@sweden \/ Helena",
      "screen_name" : "sweden",
      "protected" : false,
      "id_str" : "19663706",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465746880391938048\/3B3xbTNL_normal.png",
      "id" : 19663706,
      "verified" : false
    }
  },
  "id" : 214058633670041601,
  "created_at" : "2012-06-16 18:15:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@sweden \/ Helena",
      "screen_name" : "sweden",
      "indices" : [ 3, 10 ],
      "id_str" : "19663706",
      "id" : 19663706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214058623863750656",
  "text" : "RT @sweden: As a kid I once took a dead bird, placed it in a plastic bag, dug it down. After a few weeks, dug it up, just to see what it ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213980236797317121",
    "text" : "As a kid I once took a dead bird, placed it in a plastic bag, dug it down. After a few weeks, dug it up, just to see what it looked like.",
    "id" : 213980236797317121,
    "created_at" : "2012-06-16 13:03:58 +0000",
    "user" : {
      "name" : "@sweden \/ Helena",
      "screen_name" : "sweden",
      "protected" : false,
      "id_str" : "19663706",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465746880391938048\/3B3xbTNL_normal.png",
      "id" : 19663706,
      "verified" : false
    }
  },
  "id" : 214058623863750656,
  "created_at" : "2012-06-16 18:15:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213844875173576705",
  "geo" : { },
  "id_str" : "213847332465291264",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Woah. Portlandia fan fiction?",
  "id" : 213847332465291264,
  "in_reply_to_status_id" : 213844875173576705,
  "created_at" : "2012-06-16 04:15:51 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/DDDOLvYJ",
      "expanded_url" : "http:\/\/flic.kr\/p\/ceW6Eu",
      "display_url" : "flic.kr\/p\/ceW6Eu"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "213839731178475520",
  "text" : "8:36pm Just said bye to Ariel and Tavi, now hanging on the porch http:\/\/t.co\/DDDOLvYJ",
  "id" : 213839731178475520,
  "created_at" : "2012-06-16 03:45:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213814107944660997",
  "text" : "Remember when we were all kids?",
  "id" : 213814107944660997,
  "created_at" : "2012-06-16 02:03:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213715954193022977",
  "geo" : { },
  "id_str" : "213717427354222592",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc DO IT! Start a kickstarter to raise funds to buy one.",
  "id" : 213717427354222592,
  "in_reply_to_status_id" : 213715954193022977,
  "created_at" : "2012-06-15 19:39:40 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213714668441714688",
  "geo" : { },
  "id_str" : "213715100421459968",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc They mention July for the 2nd run of coats, so I think yes!",
  "id" : 213715100421459968,
  "in_reply_to_status_id" : 213714668441714688,
  "created_at" : "2012-06-15 19:30:25 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/y67gDy1X",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/hansr\/griz-coat\/posts",
      "display_url" : "kickstarter.com\/projects\/hansr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "213713919632609280",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc You should get one of these: http:\/\/t.co\/y67gDy1X",
  "id" : 213713919632609280,
  "created_at" : "2012-06-15 19:25:43 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/EZjQKXwu",
      "expanded_url" : "http:\/\/instagr.am\/p\/L5sdDMo0Mg\/",
      "display_url" : "instagr.am\/p\/L5sdDMo0Mg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "213671658509176832",
  "text" : "Don't put baby in a box http:\/\/t.co\/EZjQKXwu",
  "id" : 213671658509176832,
  "created_at" : "2012-06-15 16:37:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Cheng",
      "screen_name" : "jackcheng",
      "indices" : [ 69, 79 ],
      "id_str" : "146703",
      "id" : 146703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/GTaAFIuv",
      "expanded_url" : "http:\/\/blog.jackcheng.com\/post\/25160553986\/the-slow-web",
      "display_url" : "blog.jackcheng.com\/post\/251605539\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "213653479447724032",
  "text" : "Super interesting musings on \"the slow web\" http:\/\/t.co\/GTaAFIuv \/by @jackcheng",
  "id" : 213653479447724032,
  "created_at" : "2012-06-15 15:25:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/jWWFRmA1",
      "expanded_url" : "http:\/\/flic.kr\/p\/ceAyob",
      "display_url" : "flic.kr\/p\/ceAyob"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608166, -122.327334 ]
  },
  "id_str" : "213480336364027904",
  "text" : "8:36pm Allison bought me this drink which I drank http:\/\/t.co\/jWWFRmA1",
  "id" : 213480336364027904,
  "created_at" : "2012-06-15 03:57:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213472136424202241",
  "geo" : { },
  "id_str" : "213472666127056896",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Someone else mentioned eye-tracking inputs too. That might be fun.",
  "id" : 213472666127056896,
  "in_reply_to_status_id" : 213472136424202241,
  "created_at" : "2012-06-15 03:27:04 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213470900622860288",
  "geo" : { },
  "id_str" : "213471860921352193",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez We don\u2019t think of thoughts as real yet, but in order to capture them we\u2019d have to make them real somehow. Could be tough though.",
  "id" : 213471860921352193,
  "in_reply_to_status_id" : 213470900622860288,
  "created_at" : "2012-06-15 03:23:52 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213469196980457473",
  "text" : "Cave wall -&gt; stone tablet -&gt; papyrus -&gt; printing press -&gt; keyboard -&gt; multi-touch -&gt; ??? (mind-readers in 20 years?)",
  "id" : 213469196980457473,
  "created_at" : "2012-06-15 03:13:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin McKean",
      "screen_name" : "emckean",
      "indices" : [ 3, 11 ],
      "id_str" : "5380022",
      "id" : 5380022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/b2xXyFcl",
      "expanded_url" : "http:\/\/bit.ly\/MShpVf",
      "display_url" : "bit.ly\/MShpVf"
    } ]
  },
  "geo" : { },
  "id_str" : "213466538836111362",
  "text" : "RT @emckean: \"We want to eliminate willpower as a factor in achieving goals.\" &lt;-- huge: help make it happen at Lift! http:\/\/t.co\/b2xXyFcl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/b2xXyFcl",
        "expanded_url" : "http:\/\/bit.ly\/MShpVf",
        "display_url" : "bit.ly\/MShpVf"
      } ]
    },
    "geo" : { },
    "id_str" : "213316662965972992",
    "text" : "\"We want to eliminate willpower as a factor in achieving goals.\" &lt;-- huge: help make it happen at Lift! http:\/\/t.co\/b2xXyFcl",
    "id" : 213316662965972992,
    "created_at" : "2012-06-14 17:07:10 +0000",
    "user" : {
      "name" : "Erin McKean",
      "screen_name" : "emckean",
      "protected" : false,
      "id_str" : "5380022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458703432178626560\/0kuUS4tI_normal.jpeg",
      "id" : 5380022,
      "verified" : false
    }
  },
  "id" : 213466538836111362,
  "created_at" : "2012-06-15 03:02:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiffany Conroy",
      "screen_name" : "theophani",
      "indices" : [ 3, 13 ],
      "id_str" : "14992855",
      "id" : 14992855
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "waaa",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/HhLrBIm7",
      "expanded_url" : "http:\/\/weareallaweso.me",
      "display_url" : "weareallaweso.me"
    } ]
  },
  "geo" : { },
  "id_str" : "213466439032643585",
  "text" : "RT @theophani: Dear male developer, Do you want more women speakers at confs? Then please RT this speaker resource I'm building: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "waaa",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/HhLrBIm7",
        "expanded_url" : "http:\/\/weareallaweso.me",
        "display_url" : "weareallaweso.me"
      } ]
    },
    "geo" : { },
    "id_str" : "212947947627876352",
    "text" : "Dear male developer, Do you want more women speakers at confs? Then please RT this speaker resource I'm building: http:\/\/t.co\/HhLrBIm7 #waaa",
    "id" : 212947947627876352,
    "created_at" : "2012-06-13 16:42:01 +0000",
    "user" : {
      "name" : "Tiffany Conroy",
      "screen_name" : "theophani",
      "protected" : false,
      "id_str" : "14992855",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1427969078\/image_normal.jpg",
      "id" : 14992855,
      "verified" : false
    }
  },
  "id" : 213466439032643585,
  "created_at" : "2012-06-15 03:02:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213326147495276544",
  "geo" : { },
  "id_str" : "213382092371922946",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew Does the window mount obscure your driving vision at all?",
  "id" : 213382092371922946,
  "in_reply_to_status_id" : 213326147495276544,
  "created_at" : "2012-06-14 21:27:09 +0000",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Broderick",
      "screen_name" : "MichelleBee",
      "indices" : [ 0, 12 ],
      "id_str" : "1059951",
      "id" : 1059951
    }, {
      "name" : "Mike Colman",
      "screen_name" : "mike_colman",
      "indices" : [ 13, 25 ],
      "id_str" : "18039123",
      "id" : 18039123
    }, {
      "name" : "Uber Seattle",
      "screen_name" : "Uber_SEA",
      "indices" : [ 26, 35 ],
      "id_str" : "272162235",
      "id" : 272162235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213294783404314625",
  "geo" : { },
  "id_str" : "213304822483533824",
  "in_reply_to_user_id" : 1059951,
  "text" : "@MichelleBee @mike_colman @uber_sea Yes! I'd love to know what Uber uses.",
  "id" : 213304822483533824,
  "in_reply_to_status_id" : 213294783404314625,
  "created_at" : "2012-06-14 16:20:07 +0000",
  "in_reply_to_screen_name" : "MichelleBee",
  "in_reply_to_user_id_str" : "1059951",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Grimes",
      "screen_name" : "jasongrimes",
      "indices" : [ 0, 12 ],
      "id_str" : "7675672",
      "id" : 7675672
    }, {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "indices" : [ 13, 23 ],
      "id_str" : "14326765",
      "id" : 14326765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213036074522521600",
  "geo" : { },
  "id_str" : "213291603849256962",
  "in_reply_to_user_id" : 7675672,
  "text" : "@jasongrimes @johnhcook I think meditation is a no-brainer (ha) when it comes to productivity.",
  "id" : 213291603849256962,
  "in_reply_to_status_id" : 213036074522521600,
  "created_at" : "2012-06-14 15:27:35 +0000",
  "in_reply_to_screen_name" : "jasongrimes",
  "in_reply_to_user_id_str" : "7675672",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    }, {
      "name" : "Jimmy James Hall",
      "screen_name" : "JimmyJameson",
      "indices" : [ 17, 30 ],
      "id_str" : "35141809",
      "id" : 35141809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213291359526850560",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar @JimmyJameson Are we still on for drinks tonight? I'm ready!",
  "id" : 213291359526850560,
  "created_at" : "2012-06-14 15:26:37 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213290502936739840",
  "text" : "What's the best product that mounts an iPhone to your car dash, now that turn by turn is working?",
  "id" : 213290502936739840,
  "created_at" : "2012-06-14 15:23:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jennifero",
      "screen_name" : "oldmeal",
      "indices" : [ 22, 30 ],
      "id_str" : "422237108",
      "id" : 422237108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/yfRqYqdr",
      "expanded_url" : "http:\/\/instagr.am\/p\/LzehF3o0Oq\/",
      "display_url" : "instagr.am\/p\/LzehF3o0Oq\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6215213537, -122.312517 ]
  },
  "id_str" : "212797526540169216",
  "text" : "I love this tattoo on @oldmeal's arm: Phil Collins, Paul Simon, Huey Lewis, Mark Twain as Mt Rushmo  @ Smith http:\/\/t.co\/yfRqYqdr",
  "id" : 212797526540169216,
  "created_at" : "2012-06-13 06:44:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212717969053188098",
  "geo" : { },
  "id_str" : "212723041761902593",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin That\u2019s awesome! Now I want to use Edmodo.",
  "id" : 212723041761902593,
  "in_reply_to_status_id" : 212717969053188098,
  "created_at" : "2012-06-13 01:48:20 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 49, 60 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/Rbj2AzMP",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayNHR5QZ",
      "display_url" : "tmblr.co\/ZQJvayNHR5QZ"
    } ]
  },
  "geo" : { },
  "id_str" : "212702440737357824",
  "text" : "Snake, meet your tail: http:\/\/t.co\/Rbj2AzMP \/via @parislemon",
  "id" : 212702440737357824,
  "created_at" : "2012-06-13 00:26:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212601607001616384",
  "geo" : { },
  "id_str" : "212602239292948480",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote Yeah good question! Probably worth it, considering. Or maybe they\u2019re calling it \u201Cpick a booger to refresh\u201D to get around it?",
  "id" : 212602239292948480,
  "in_reply_to_status_id" : 212601607001616384,
  "created_at" : "2012-06-12 17:48:18 +0000",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212596249440944129",
  "text" : "The pull to refresh animation in iOS 6\u2019s Mail app is like a little booger.",
  "id" : 212596249440944129,
  "created_at" : "2012-06-12 17:24:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/jRQFPqJO",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayNFaGY3",
      "display_url" : "tmblr.co\/ZQJvayNFaGY3"
    } ]
  },
  "geo" : { },
  "id_str" : "212573336834818048",
  "text" : "\"Read obituaries. They're just like biographies, only shorter.\" http:\/\/t.co\/jRQFPqJO",
  "id" : 212573336834818048,
  "created_at" : "2012-06-12 15:53:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ario Jafarzadeh",
      "screen_name" : "ario",
      "indices" : [ 16, 21 ],
      "id_str" : "294",
      "id" : 294
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cool",
      "indices" : [ 96, 101 ]
    }, {
      "text" : "instacrt",
      "indices" : [ 102, 111 ]
    }, {
      "text" : "fb",
      "indices" : [ 112, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/hIAmjSiB",
      "expanded_url" : "http:\/\/instacrt.com\/",
      "display_url" : "instacrt.com"
    } ]
  },
  "geo" : { },
  "id_str" : "212430922983800834",
  "text" : "REALLY cool. RT @ario: Cool idea, cool app, cool site, cool product video. http:\/\/t.co\/hIAmjSiB #cool #instacrt #fb",
  "id" : 212430922983800834,
  "created_at" : "2012-06-12 06:27:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Feld",
      "screen_name" : "bfeld",
      "indices" : [ 83, 89 ],
      "id_str" : "3754891",
      "id" : 3754891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/nCqf3GgW",
      "expanded_url" : "http:\/\/youtu.be\/4x4d8IX_0kI",
      "display_url" : "youtu.be\/4x4d8IX_0kI"
    } ]
  },
  "geo" : { },
  "id_str" : "212386022623944705",
  "text" : "\"People mentioned that they might feel chased if the Joggobot was behind them.\" RT @bfeld: Joggobot: http:\/\/t.co\/nCqf3GgW",
  "id" : 212386022623944705,
  "created_at" : "2012-06-12 03:29:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aubrey Sabala",
      "screen_name" : "Aubs",
      "indices" : [ 0, 5 ],
      "id_str" : "2781",
      "id" : 2781
    }, {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "indices" : [ 6, 10 ],
      "id_str" : "11822502",
      "id" : 11822502
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 37, 46 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 130 ],
      "url" : "https:\/\/t.co\/T9VUABZV",
      "expanded_url" : "https:\/\/foursquare.com\/mobile\/",
      "display_url" : "foursquare.com\/mobile\/"
    } ]
  },
  "in_reply_to_status_id_str" : "212377390230417408",
  "geo" : { },
  "id_str" : "212377860936183811",
  "in_reply_to_user_id" : 2781,
  "text" : "@Aubs @mko If you want the hack that @rickwebb brought to my attention, bookmark this page to your homepage: https:\/\/t.co\/T9VUABZV",
  "id" : 212377860936183811,
  "in_reply_to_status_id" : 212377390230417408,
  "created_at" : "2012-06-12 02:56:42 +0000",
  "in_reply_to_screen_name" : "Aubs",
  "in_reply_to_user_id_str" : "2781",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aubrey Sabala",
      "screen_name" : "Aubs",
      "indices" : [ 0, 5 ],
      "id_str" : "2781",
      "id" : 2781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212375919866806272",
  "geo" : { },
  "id_str" : "212376095415214080",
  "in_reply_to_user_id" : 2781,
  "text" : "@Aubs The check in.",
  "id" : 212376095415214080,
  "in_reply_to_status_id" : 212375919866806272,
  "created_at" : "2012-06-12 02:49:41 +0000",
  "in_reply_to_screen_name" : "Aubs",
  "in_reply_to_user_id_str" : "2781",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212365337553940480",
  "text" : "Does Apple have more credit card numbers than Amazon?",
  "id" : 212365337553940480,
  "created_at" : "2012-06-12 02:06:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kimberly dawn",
      "screen_name" : "hiitskim",
      "indices" : [ 19, 28 ],
      "id_str" : "26148025",
      "id" : 26148025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/Veoobqkp",
      "expanded_url" : "http:\/\/4sq.com\/KykO6N",
      "display_url" : "4sq.com\/KykO6N"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6141997815, -122.3190182503 ]
  },
  "id_str" : "212362084187508736",
  "text" : "I'm at Poquitos w\/ @hiitskim http:\/\/t.co\/Veoobqkp",
  "id" : 212362084187508736,
  "created_at" : "2012-06-12 01:54:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iOS6",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/FgCG4B7U",
      "expanded_url" : "http:\/\/4sq.com\/L13IDo",
      "display_url" : "4sq.com\/L13IDo"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6170123598, -122.3191165924 ]
  },
  "id_str" : "212341262915866624",
  "text" : "\"Siri, check in on Foursquare\" at least opened the app. Opening to the check in page would be amazing. #iOS6 http:\/\/t.co\/FgCG4B7U",
  "id" : 212341262915866624,
  "created_at" : "2012-06-12 00:31:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Furedy",
      "screen_name" : "m_furedy",
      "indices" : [ 0, 9 ],
      "id_str" : "204025261",
      "id" : 204025261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212319051500896259",
  "geo" : { },
  "id_str" : "212319224654344192",
  "in_reply_to_user_id" : 204025261,
  "text" : "@m_furedy I tend to just wait for the next non-interrupting moment to post. Even if that's a couple hours away.",
  "id" : 212319224654344192,
  "in_reply_to_status_id" : 212319051500896259,
  "created_at" : "2012-06-11 23:03:42 +0000",
  "in_reply_to_screen_name" : "m_furedy",
  "in_reply_to_user_id_str" : "204025261",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Furedy",
      "screen_name" : "m_furedy",
      "indices" : [ 0, 9 ],
      "id_str" : "204025261",
      "id" : 204025261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212305772246335489",
  "geo" : { },
  "id_str" : "212310212386881536",
  "in_reply_to_user_id" : 204025261,
  "text" : "@m_furedy Thank you! They're fun to do\u2026 why don't you give it a try?",
  "id" : 212310212386881536,
  "in_reply_to_status_id" : 212305772246335489,
  "created_at" : "2012-06-11 22:27:53 +0000",
  "in_reply_to_screen_name" : "m_furedy",
  "in_reply_to_user_id_str" : "204025261",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212289609546219522",
  "geo" : { },
  "id_str" : "212289916636368896",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Yeah, I think that's the slot the retina one now fills. It's a super hybrid of Air and Pro.",
  "id" : 212289916636368896,
  "in_reply_to_status_id" : 212289609546219522,
  "created_at" : "2012-06-11 21:07:14 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212288492078768129",
  "geo" : { },
  "id_str" : "212289042941886464",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Not for Air. Kellianne has a 13\" Air though and I use it and it's plenty of screen.",
  "id" : 212289042941886464,
  "in_reply_to_status_id" : 212288492078768129,
  "created_at" : "2012-06-11 21:03:46 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212286689396260866",
  "geo" : { },
  "id_str" : "212286913594392577",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten The 13\" Air is probably for you then!",
  "id" : 212286913594392577,
  "in_reply_to_status_id" : 212286689396260866,
  "created_at" : "2012-06-11 20:55:18 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212284057101414400",
  "geo" : { },
  "id_str" : "212284884222349312",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Let me know if you have any questions. I just spent a while looking at all the updates.",
  "id" : 212284884222349312,
  "in_reply_to_status_id" : 212284057101414400,
  "created_at" : "2012-06-11 20:47:15 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212282698755096576",
  "geo" : { },
  "id_str" : "212283192445648897",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Are you getting the new retina one too? It\u2019s pricey but looks pretty amazing.",
  "id" : 212283192445648897,
  "in_reply_to_status_id" : 212282698755096576,
  "created_at" : "2012-06-11 20:40:31 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "indices" : [ 19, 28 ],
      "id_str" : "255784266",
      "id" : 255784266
    }, {
      "name" : "Best Thing This Year",
      "screen_name" : "TBTTY",
      "indices" : [ 49, 55 ],
      "id_str" : "570264874",
      "id" : 570264874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/Wjrrjpuy",
      "expanded_url" : "http:\/\/membership.thebestthingthisyear.com\/",
      "display_url" : "membership.thebestthingthisyear.com"
    } ]
  },
  "geo" : { },
  "id_str" : "212281012384829441",
  "text" : "The 8:36pm post on @geekwire was first posted to @tbtty http:\/\/t.co\/Wjrrjpuy which you should all subscribe to.",
  "id" : 212281012384829441,
  "created_at" : "2012-06-11 20:31:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "indices" : [ 18, 27 ],
      "id_str" : "255784266",
      "id" : 255784266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/07bhBlJ6",
      "expanded_url" : "http:\/\/goo.gl\/fb\/5i6Sq",
      "display_url" : "goo.gl\/fb\/5i6Sq"
    } ]
  },
  "geo" : { },
  "id_str" : "212277590851981315",
  "text" : "I guest-posted on @geekwire about 4 years of doing 8:36pm! \"What I\u2019ve learned taking photos every day at 8:36 p.m.\" http:\/\/t.co\/07bhBlJ6",
  "id" : 212277590851981315,
  "created_at" : "2012-06-11 20:18:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212269450496458755",
  "text" : "New MacBook Pro (with retina) purchased! I hope the 3-5 week ship date is an under-promise.",
  "id" : 212269450496458755,
  "created_at" : "2012-06-11 19:45:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meredith Modzelewski",
      "screen_name" : "meredithmo",
      "indices" : [ 0, 11 ],
      "id_str" : "17069950",
      "id" : 17069950
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 12, 22 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212254650416635904",
  "geo" : { },
  "id_str" : "212261510418939904",
  "in_reply_to_user_id" : 17069950,
  "text" : "@meredithmo @kellianne I have always understood it as a divvy it up kinda deal. There are many interpretations and extremes around though.",
  "id" : 212261510418939904,
  "in_reply_to_status_id" : 212254650416635904,
  "created_at" : "2012-06-11 19:14:22 +0000",
  "in_reply_to_screen_name" : "meredithmo",
  "in_reply_to_user_id_str" : "17069950",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 8, 17 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212234262114598912",
  "text" : "YAY! RT @RickWebb: THIRD LAPTOP LINE???",
  "id" : 212234262114598912,
  "created_at" : "2012-06-11 17:26:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 8, 19 ],
      "id_str" : "1586501",
      "id" : 1586501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212229742328414208",
  "text" : "Wow. RT @nickbilton: Tim Cook: Customers have now downloaded 30 billion apps. Apple has also forked over $5 billion to app makers.",
  "id" : 212229742328414208,
  "created_at" : "2012-06-11 17:08:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeVore",
      "screen_name" : "crashdev",
      "indices" : [ 25, 34 ],
      "id_str" : "14763501",
      "id" : 14763501
    }, {
      "name" : "techstars",
      "screen_name" : "techstars",
      "indices" : [ 66, 76 ],
      "id_str" : "14277276",
      "id" : 14277276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Seattle",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/0Ro0G6zp",
      "expanded_url" : "http:\/\/bit.ly\/LUP26h",
      "display_url" : "bit.ly\/LUP26h"
    } ]
  },
  "geo" : { },
  "id_str" : "212193949933240320",
  "text" : "Calling all startups! RT @crashdev: Get your applications in! The @TechStars #Seattle application deadline is this Fri. http:\/\/t.co\/0Ro0G6zp",
  "id" : 212193949933240320,
  "created_at" : "2012-06-11 14:45:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/KqdqX2qF",
      "expanded_url" : "http:\/\/instagr.am\/p\/LucuiNI0K5\/",
      "display_url" : "instagr.am\/p\/LucuiNI0K5\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.611202, -122.316686511 ]
  },
  "id_str" : "212089058833334272",
  "text" : "My personality according to the Personality app  @ Canon http:\/\/t.co\/KqdqX2qF",
  "id" : 212089058833334272,
  "created_at" : "2012-06-11 07:49:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 20, 31 ],
      "id_str" : "1586501",
      "id" : 1586501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/Si8JhyUF",
      "expanded_url" : "http:\/\/bit.ly\/MxOpOB",
      "display_url" : "bit.ly\/MxOpOB"
    } ]
  },
  "geo" : { },
  "id_str" : "212084268644573184",
  "text" : "This is so good! RT @nickbilton: Swedes\u2019 Twitter Voice: Anyone, Saying (Blush) Almost Anything. http:\/\/t.co\/Si8JhyUF",
  "id" : 212084268644573184,
  "created_at" : "2012-06-11 07:30:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212081190725881856",
  "geo" : { },
  "id_str" : "212084065191469057",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar Let\u2019s share break downs on Thurs at Vito\u2019s!",
  "id" : 212084065191469057,
  "in_reply_to_status_id" : 212081190725881856,
  "created_at" : "2012-06-11 07:29:16 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/W6FZbh6P",
      "expanded_url" : "http:\/\/4sq.com\/LTmRVr",
      "display_url" : "4sq.com\/LTmRVr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.611202, -122.316686511 ]
  },
  "id_str" : "212079797982076928",
  "text" : "Talking to strangers. (@ Canon w\/ 2 others) http:\/\/t.co\/W6FZbh6P",
  "id" : 212079797982076928,
  "created_at" : "2012-06-11 07:12:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/ZdS3IRlU",
      "expanded_url" : "http:\/\/flic.kr\/p\/cdrtis",
      "display_url" : "flic.kr\/p\/cdrtis"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612166, -122.334334 ]
  },
  "id_str" : "212065141892718592",
  "text" : "8:36pm Was watching an epicly long series of previews before Prometheus, which I ended up liking http:\/\/t.co\/ZdS3IRlU",
  "id" : 212065141892718592,
  "created_at" : "2012-06-11 06:14:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Koriann",
      "screen_name" : "kbiceling",
      "indices" : [ 0, 10 ],
      "id_str" : "7747172",
      "id" : 7747172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212008757788545028",
  "geo" : { },
  "id_str" : "212009245665800193",
  "in_reply_to_user_id" : 7747172,
  "text" : "@kbiceling Not offhand. Do you remember anything else that might jog my (bad) memory a bit? Approximate date? Medium?",
  "id" : 212009245665800193,
  "in_reply_to_status_id" : 212008757788545028,
  "created_at" : "2012-06-11 02:31:57 +0000",
  "in_reply_to_screen_name" : "kbiceling",
  "in_reply_to_user_id_str" : "7747172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212006504553922561",
  "text" : "Niko still refuses to say his own name but I did just hear him point to his legs and say \u201Cknee cold!\u201D I\u2019m counting that.",
  "id" : 212006504553922561,
  "created_at" : "2012-06-11 02:21:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 115, 122 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 123, 132 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211911674595262465",
  "geo" : { },
  "id_str" : "211912882017927168",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc It might just be me but I\u2019m just as interested in knowing about people\/places in NYC and SF as Seattle. \/cc @harryh @arainert",
  "id" : 211912882017927168,
  "in_reply_to_status_id" : 211911674595262465,
  "created_at" : "2012-06-10 20:09:02 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 113, 120 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 121, 130 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "allnew4sq",
      "indices" : [ 43, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211899625299382273",
  "text" : "I like seeing what everyone\u2019s up to in the #allnew4sq. Count my vote for keeping global view as the default. \/cc @harryh @arainert",
  "id" : 211899625299382273,
  "created_at" : "2012-06-10 19:16:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/p3DoqfxY",
      "expanded_url" : "http:\/\/4sq.com\/OciE0G",
      "display_url" : "4sq.com\/OciE0G"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4499299668, -122.2603869438 ]
  },
  "id_str" : "211893862170505216",
  "text" : "Choo-spotting a day early so I can watch WWDC tomorrow. (@ The Old Spaghetti Factory) http:\/\/t.co\/p3DoqfxY",
  "id" : 211893862170505216,
  "created_at" : "2012-06-10 18:53:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/BGiG2CFA",
      "expanded_url" : "http:\/\/flic.kr\/p\/bVGhLM",
      "display_url" : "flic.kr\/p\/bVGhLM"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "211664748142526465",
  "text" : "8:36pm Impromptu toddler jam http:\/\/t.co\/BGiG2CFA",
  "id" : 211664748142526465,
  "created_at" : "2012-06-10 03:43:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 11, 22 ],
      "id_str" : "784078",
      "id" : 784078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211582320862429184",
  "geo" : { },
  "id_str" : "211585414375538690",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne @alicetiara Maybe they\u2019re not checking Twitter for announcements of proper conduct. Which is further proof of their foolishness.",
  "id" : 211585414375538690,
  "in_reply_to_status_id" : 211582320862429184,
  "created_at" : "2012-06-09 22:27:48 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Collette",
      "screen_name" : "sfposhy",
      "indices" : [ 0, 8 ],
      "id_str" : "268453413",
      "id" : 268453413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211498447260491778",
  "geo" : { },
  "id_str" : "211502934582771715",
  "in_reply_to_user_id" : 268453413,
  "text" : "@sfposhy It\u2019s so bad!",
  "id" : 211502934582771715,
  "in_reply_to_status_id" : 211498447260491778,
  "created_at" : "2012-06-09 17:00:03 +0000",
  "in_reply_to_screen_name" : "sfposhy",
  "in_reply_to_user_id_str" : "268453413",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211495587185561603",
  "geo" : { },
  "id_str" : "211497191485874176",
  "in_reply_to_user_id" : 15275073,
  "text" : "@tberman Truly. Though I can\u2019t say I\u2019m not a little jealous of her title as President of Sparkling Beverages.",
  "id" : 211497191485874176,
  "in_reply_to_status_id" : 211495587185561603,
  "created_at" : "2012-06-09 16:37:14 +0000",
  "in_reply_to_screen_name" : "tberman",
  "in_reply_to_user_id_str" : "15275073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/ztk4SuMa",
      "expanded_url" : "http:\/\/www.usatoday.com\/money\/industries\/food\/story\/2012-06-07\/coke-q-and-a-coca-cola-mayor-bloomberg\/55453016\/1",
      "display_url" : "usatoday.com\/money\/industri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "211494573690728449",
  "text" : "\"When my son gets home from school, he needs a pick-up with calories and great taste.\" - Coke exec http:\/\/t.co\/ztk4SuMa",
  "id" : 211494573690728449,
  "created_at" : "2012-06-09 16:26:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 3, 12 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/uUWu7v0A",
      "expanded_url" : "http:\/\/bit.ly\/O3PNvp",
      "display_url" : "bit.ly\/O3PNvp"
    } ]
  },
  "geo" : { },
  "id_str" : "211487178432315392",
  "text" : "RT @amyjokim: Pixar's 22 Rules of Storytelling http:\/\/t.co\/uUWu7v0A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 53 ],
        "url" : "http:\/\/t.co\/uUWu7v0A",
        "expanded_url" : "http:\/\/bit.ly\/O3PNvp",
        "display_url" : "bit.ly\/O3PNvp"
      } ]
    },
    "geo" : { },
    "id_str" : "211483484454260736",
    "text" : "Pixar's 22 Rules of Storytelling http:\/\/t.co\/uUWu7v0A",
    "id" : 211483484454260736,
    "created_at" : "2012-06-09 15:42:46 +0000",
    "user" : {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "protected" : false,
      "id_str" : "780991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1789001732\/ajk-headshot2_normal.jpg",
      "id" : 780991,
      "verified" : false
    }
  },
  "id" : 211487178432315392,
  "created_at" : "2012-06-09 15:57:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/1IPnkDxF",
      "expanded_url" : "http:\/\/flic.kr\/p\/ccMHAU",
      "display_url" : "flic.kr\/p\/ccMHAU"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306334 ]
  },
  "id_str" : "211301696465412098",
  "text" : "8:36pm Just getting home http:\/\/t.co\/1IPnkDxF",
  "id" : 211301696465412098,
  "created_at" : "2012-06-09 03:40:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McAllister",
      "screen_name" : "ianmcall",
      "indices" : [ 0, 9 ],
      "id_str" : "2035631",
      "id" : 2035631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211276420033421313",
  "geo" : { },
  "id_str" : "211285178193154049",
  "in_reply_to_user_id" : 2035631,
  "text" : "@ianmcall Thanks for that link, by the way. I was cracking up though the whole thing.",
  "id" : 211285178193154049,
  "in_reply_to_status_id" : 211276420033421313,
  "created_at" : "2012-06-09 02:34:46 +0000",
  "in_reply_to_screen_name" : "ianmcall",
  "in_reply_to_user_id_str" : "2035631",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McAllister",
      "screen_name" : "ianmcall",
      "indices" : [ 3, 12 ],
      "id_str" : "2035631",
      "id" : 2035631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/otEPENUM",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/life\/low_concept\/2012\/06\/what_kind_of_muppet_are_you_chaos_or_order_.html?tid=sm_tw_button_chunky",
      "display_url" : "slate.com\/articles\/life\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "211274145055514626",
  "text" : "RT @ianmcall: Trying to decide if I'm a chaos muppet or an order muppet. Friends, can you help me decide?  http:\/\/t.co\/otEPENUM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/otEPENUM",
        "expanded_url" : "http:\/\/www.slate.com\/articles\/life\/low_concept\/2012\/06\/what_kind_of_muppet_are_you_chaos_or_order_.html?tid=sm_tw_button_chunky",
        "display_url" : "slate.com\/articles\/life\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "211268793106833409",
    "text" : "Trying to decide if I'm a chaos muppet or an order muppet. Friends, can you help me decide?  http:\/\/t.co\/otEPENUM",
    "id" : 211268793106833409,
    "created_at" : "2012-06-09 01:29:40 +0000",
    "user" : {
      "name" : "Ian McAllister",
      "screen_name" : "ianmcall",
      "protected" : false,
      "id_str" : "2035631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000663434072\/cec1bb4f2e8f3c6f72b7b00781c0f0dd_normal.jpeg",
      "id" : 2035631,
      "verified" : false
    }
  },
  "id" : 211274145055514626,
  "created_at" : "2012-06-09 01:50:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McAllister",
      "screen_name" : "ianmcall",
      "indices" : [ 0, 9 ],
      "id_str" : "2035631",
      "id" : 2035631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211268793106833409",
  "geo" : { },
  "id_str" : "211273908358348800",
  "in_reply_to_user_id" : 2035631,
  "text" : "@ianmcall If you have to know, you\u2019re an order muppet.",
  "id" : 211273908358348800,
  "in_reply_to_status_id" : 211268793106833409,
  "created_at" : "2012-06-09 01:49:59 +0000",
  "in_reply_to_screen_name" : "ianmcall",
  "in_reply_to_user_id_str" : "2035631",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rands",
      "screen_name" : "rands",
      "indices" : [ 52, 58 ],
      "id_str" : "30923",
      "id" : 30923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/A7ze8xod",
      "expanded_url" : "http:\/\/bit.ly\/KpbXpP",
      "display_url" : "bit.ly\/KpbXpP"
    } ]
  },
  "geo" : { },
  "id_str" : "211176041413226497",
  "text" : "Because everything is unique. Sort of a cop out. RT @rands: How do we know that every snowflake is unique? http:\/\/t.co\/A7ze8xod",
  "id" : 211176041413226497,
  "created_at" : "2012-06-08 19:21:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Think",
      "screen_name" : "bigthink",
      "indices" : [ 3, 12 ],
      "id_str" : "18567018",
      "id" : 18567018
    }, {
      "name" : "Jason Gots",
      "screen_name" : "jgots",
      "indices" : [ 58, 64 ],
      "id_str" : "26034189",
      "id" : 26034189
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "art",
      "indices" : [ 86, 90 ]
    }, {
      "text" : "science",
      "indices" : [ 91, 99 ]
    }, {
      "text" : "storytelling",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/qyUY3tmz",
      "expanded_url" : "http:\/\/ow.ly\/brUxd",
      "display_url" : "ow.ly\/brUxd"
    } ]
  },
  "geo" : { },
  "id_str" : "211120323913977856",
  "text" : "RT @bigthink: Radiolab's Jad Abumrad on Digital Shamanism @jgots http:\/\/t.co\/qyUY3tmz #art #science #storytelling",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Gots",
        "screen_name" : "jgots",
        "indices" : [ 44, 50 ],
        "id_str" : "26034189",
        "id" : 26034189
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "art",
        "indices" : [ 72, 76 ]
      }, {
        "text" : "science",
        "indices" : [ 77, 85 ]
      }, {
        "text" : "storytelling",
        "indices" : [ 86, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/qyUY3tmz",
        "expanded_url" : "http:\/\/ow.ly\/brUxd",
        "display_url" : "ow.ly\/brUxd"
      } ]
    },
    "geo" : { },
    "id_str" : "211115651442552833",
    "text" : "Radiolab's Jad Abumrad on Digital Shamanism @jgots http:\/\/t.co\/qyUY3tmz #art #science #storytelling",
    "id" : 211115651442552833,
    "created_at" : "2012-06-08 15:21:08 +0000",
    "user" : {
      "name" : "Big Think",
      "screen_name" : "bigthink",
      "protected" : false,
      "id_str" : "18567018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1142353176\/logo_normal.png",
      "id" : 18567018,
      "verified" : false
    }
  },
  "id" : 211120323913977856,
  "created_at" : "2012-06-08 15:39:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bailey",
      "screen_name" : "chriscognito",
      "indices" : [ 3, 16 ],
      "id_str" : "4168801",
      "id" : 4168801
    }, {
      "name" : "Kare Anderson",
      "screen_name" : "KareAnderson",
      "indices" : [ 139, 140 ],
      "id_str" : "819284",
      "id" : 819284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/d4tHtWHY",
      "expanded_url" : "http:\/\/blogs.hbr.org\/cs\/2012\/06\/what_captures_your_attention_c.html",
      "display_url" : "blogs.hbr.org\/cs\/2012\/06\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "211119284770967552",
  "text" : "RT @chriscognito: The greatest gift we can give is our full attention: What Captures Your Attention Controls Your Life http:\/\/t.co\/d4tHt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kare Anderson",
        "screen_name" : "KareAnderson",
        "indices" : [ 126, 139 ],
        "id_str" : "819284",
        "id" : 819284
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/d4tHtWHY",
        "expanded_url" : "http:\/\/blogs.hbr.org\/cs\/2012\/06\/what_captures_your_attention_c.html",
        "display_url" : "blogs.hbr.org\/cs\/2012\/06\/wha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "211114224338993153",
    "text" : "The greatest gift we can give is our full attention: What Captures Your Attention Controls Your Life http:\/\/t.co\/d4tHtWHY via @KareAnderson",
    "id" : 211114224338993153,
    "created_at" : "2012-06-08 15:15:28 +0000",
    "user" : {
      "name" : "Chris Bailey",
      "screen_name" : "chriscognito",
      "protected" : false,
      "id_str" : "4168801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2507978854\/x87fpbk5s7ax3iyk13mx_normal.jpeg",
      "id" : 4168801,
      "verified" : false
    }
  },
  "id" : 211119284770967552,
  "created_at" : "2012-06-08 15:35:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Fine",
      "screen_name" : "samuelfine",
      "indices" : [ 0, 11 ],
      "id_str" : "200236063",
      "id" : 200236063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/UXCU3B0z",
      "expanded_url" : "http:\/\/750words.com",
      "display_url" : "750words.com"
    } ]
  },
  "in_reply_to_status_id_str" : "211111971666403332",
  "geo" : { },
  "id_str" : "211118557835169793",
  "in_reply_to_user_id" : 200236063,
  "text" : "@samuelfine I think Pair is pretty great too. My experiment is about private journaling, like a micro version of http:\/\/t.co\/UXCU3B0z.",
  "id" : 211118557835169793,
  "in_reply_to_status_id" : 211111971666403332,
  "created_at" : "2012-06-08 15:32:41 +0000",
  "in_reply_to_screen_name" : "samuelfine",
  "in_reply_to_user_id_str" : "200236063",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/o3dUivDy",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayM-4nJr",
      "display_url" : "tmblr.co\/ZQJvayM-4nJr"
    } ]
  },
  "geo" : { },
  "id_str" : "211110590620512257",
  "text" : "A tiny private sms journaling experiment: http:\/\/t.co\/o3dUivDy",
  "id" : 211110590620512257,
  "created_at" : "2012-06-08 15:01:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fancy",
      "screen_name" : "thefancy",
      "indices" : [ 51, 60 ],
      "id_str" : "1730261",
      "id" : 1730261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210962605903327232",
  "text" : "Woah, I\u2019m sorry for tweeting all of those links to @thefancy. I was just playing around on the site and had no clue it was doing that. Bad!",
  "id" : 210962605903327232,
  "created_at" : "2012-06-08 05:12:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/UFqRqJ9K",
      "expanded_url" : "http:\/\/flic.kr\/p\/ccwtDL",
      "display_url" : "flic.kr\/p\/ccwtDL"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.305834 ]
  },
  "id_str" : "210939159710400513",
  "text" : "8:36pm Downloading some apps from the \"creative cloud\" http:\/\/t.co\/UFqRqJ9K",
  "id" : 210939159710400513,
  "created_at" : "2012-06-08 03:39:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jonahlehrer",
      "screen_name" : "jonahlehrer",
      "indices" : [ 50, 62 ],
      "id_str" : "18994661",
      "id" : 18994661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/ZoIeUeom",
      "expanded_url" : "http:\/\/bit.ly\/Kfy1I0",
      "display_url" : "bit.ly\/Kfy1I0"
    } ]
  },
  "geo" : { },
  "id_str" : "210884911438114818",
  "text" : "I learned at least 3 things from this article. RT @jonahlehrer: Why don\u2019t more people believe in science?\nhttp:\/\/t.co\/ZoIeUeom",
  "id" : 210884911438114818,
  "created_at" : "2012-06-08 00:04:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezra Butler",
      "screen_name" : "ezrabutler",
      "indices" : [ 0, 11 ],
      "id_str" : "14582941",
      "id" : 14582941
    }, {
      "name" : "Aza Raskin",
      "screen_name" : "aza",
      "indices" : [ 12, 16 ],
      "id_str" : "13370272",
      "id" : 13370272
    }, {
      "name" : "The Kernel",
      "screen_name" : "KernelMag",
      "indices" : [ 17, 27 ],
      "id_str" : "412227503",
      "id" : 412227503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210823145878327296",
  "geo" : { },
  "id_str" : "210825483879841792",
  "in_reply_to_user_id" : 14582941,
  "text" : "@ezrabutler @aza @KernelMag You\u2019re asking good questions! I\u2019d love to be part of the conversation if it gets sparked.",
  "id" : 210825483879841792,
  "in_reply_to_status_id" : 210823145878327296,
  "created_at" : "2012-06-07 20:08:06 +0000",
  "in_reply_to_screen_name" : "ezrabutler",
  "in_reply_to_user_id_str" : "14582941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    }, {
      "name" : "Jimmy James Hall",
      "screen_name" : "JimmyJameson",
      "indices" : [ 17, 30 ],
      "id_str" : "35141809",
      "id" : 35141809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210623536954478594",
  "geo" : { },
  "id_str" : "210627801794101248",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar @JimmyJameson Count me in! Calendar is marked!",
  "id" : 210627801794101248,
  "in_reply_to_status_id" : 210623536954478594,
  "created_at" : "2012-06-07 07:02:35 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Arrington",
      "screen_name" : "arrington",
      "indices" : [ 3, 13 ],
      "id_str" : "37570179",
      "id" : 37570179
    }, {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "indices" : [ 94, 105 ],
      "id_str" : "419710142",
      "id" : 419710142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/2dAJondQ",
      "expanded_url" : "http:\/\/pandodaily.com\/2012\/06\/06\/foursquare-redesign-so-what-if-the-check-in-is-dead\/",
      "display_url" : "pandodaily.com\/2012\/06\/06\/fou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "210614351806205954",
  "text" : "RT @arrington: Foursquare Redesign: So What if the Check-In is Dead? http:\/\/t.co\/2dAJondQ via @pandodaily",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pando",
        "screen_name" : "PandoDaily",
        "indices" : [ 79, 90 ],
        "id_str" : "419710142",
        "id" : 419710142
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/2dAJondQ",
        "expanded_url" : "http:\/\/pandodaily.com\/2012\/06\/06\/foursquare-redesign-so-what-if-the-check-in-is-dead\/",
        "display_url" : "pandodaily.com\/2012\/06\/06\/fou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "210613701567451136",
    "text" : "Foursquare Redesign: So What if the Check-In is Dead? http:\/\/t.co\/2dAJondQ via @pandodaily",
    "id" : 210613701567451136,
    "created_at" : "2012-06-07 06:06:34 +0000",
    "user" : {
      "name" : "Michael Arrington",
      "screen_name" : "arrington",
      "protected" : false,
      "id_str" : "37570179",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000654181704\/52e1a4162ad05f167fca1432630dac1c_normal.jpeg",
      "id" : 37570179,
      "verified" : true
    }
  },
  "id" : 210614351806205954,
  "created_at" : "2012-06-07 06:09:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Sundqvist",
      "screen_name" : "ecologythinking",
      "indices" : [ 0, 16 ],
      "id_str" : "52667079",
      "id" : 52667079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210606648409079808",
  "geo" : { },
  "id_str" : "210606937321119744",
  "in_reply_to_user_id" : 52667079,
  "text" : "@ecologythinking It's similar to the Facebook or Instagram like buttons. It's a the easiest way to let someone know that you approve.",
  "id" : 210606937321119744,
  "in_reply_to_status_id" : 210606648409079808,
  "created_at" : "2012-06-07 05:39:41 +0000",
  "in_reply_to_screen_name" : "ecologythinking",
  "in_reply_to_user_id_str" : "52667079",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210605148379168768",
  "geo" : { },
  "id_str" : "210605680615366656",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler I think the point of hearting is similar to the point of high-5ing.  Intrinsic!  You have the new app, right?",
  "id" : 210605680615366656,
  "in_reply_to_status_id" : 210605148379168768,
  "created_at" : "2012-06-07 05:34:41 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "allnew4sq",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210602810201489408",
  "text" : "I'm already addicted to the #allnew4sq heart button. I dare you to check in.",
  "id" : 210602810201489408,
  "created_at" : "2012-06-07 05:23:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210602380566343682",
  "geo" : { },
  "id_str" : "210602581381222400",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara I did! It cracked me up. I'm still too anxious to actually use Airtime, apparently.",
  "id" : 210602581381222400,
  "in_reply_to_status_id" : 210602380566343682,
  "created_at" : "2012-06-07 05:22:22 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210600516181430272",
  "geo" : { },
  "id_str" : "210601382087102464",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara I actually seem to be somewhat addicted to Clear.  Mostly for random things people mention that I want to remember, and grocery lists.",
  "id" : 210601382087102464,
  "in_reply_to_status_id" : 210600516181430272,
  "created_at" : "2012-06-07 05:17:36 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "allnew4s",
      "indices" : [ 15, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/73qouNzq",
      "expanded_url" : "http:\/\/instagr.am\/p\/LjyniJI0NC\/",
      "display_url" : "instagr.am\/p\/LjyniJI0NC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "210589083456651265",
  "text" : "Installing the #allnew4s....... http:\/\/t.co\/73qouNzq",
  "id" : 210589083456651265,
  "created_at" : "2012-06-07 04:28:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/odgYKkM0",
      "expanded_url" : "http:\/\/flic.kr\/p\/ccfnPY",
      "display_url" : "flic.kr\/p\/ccfnPY"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608833, -122.306 ]
  },
  "id_str" : "210582721347584000",
  "text" : "8:36pm Checking out the garden http:\/\/t.co\/odgYKkM0",
  "id" : 210582721347584000,
  "created_at" : "2012-06-07 04:03:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 37, 42 ],
      "id_str" : "418",
      "id" : 418
    }, {
      "name" : "Sonos",
      "screen_name" : "Sonos",
      "indices" : [ 94, 100 ],
      "id_str" : "16727022",
      "id" : 16727022
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "allnew4sq",
      "indices" : [ 23, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086616703, -122.3061219604 ]
  },
  "id_str" : "210571888701865984",
  "text" : "'Twas the night before #allnew4sq RT @dens: Uh oh, Ludacris' \"Roll Out\" playing on the office @Sonos. Superfans should know what that means.",
  "id" : 210571888701865984,
  "created_at" : "2012-06-07 03:20:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JB",
      "screen_name" : "jbtec",
      "indices" : [ 0, 6 ],
      "id_str" : "14174697",
      "id" : 14174697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210568200138657792",
  "geo" : { },
  "id_str" : "210569096419491840",
  "in_reply_to_user_id" : 14174697,
  "text" : "@jbtec Don\u2019t most highly respected athletes downplay competition and emphasize mastery of a particular talent?",
  "id" : 210569096419491840,
  "in_reply_to_status_id" : 210568200138657792,
  "created_at" : "2012-06-07 03:09:19 +0000",
  "in_reply_to_screen_name" : "jbtec",
  "in_reply_to_user_id_str" : "14174697",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210563090251644929",
  "geo" : { },
  "id_str" : "210565735217500161",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim Would need to blog it out to explain, though.",
  "id" : 210565735217500161,
  "in_reply_to_status_id" : 210563090251644929,
  "created_at" : "2012-06-07 02:55:58 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210563090251644929",
  "geo" : { },
  "id_str" : "210565538919874560",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim I\u2019d argue that both war and college admissions are effects of competition, not causes of it.",
  "id" : 210565538919874560,
  "in_reply_to_status_id" : 210563090251644929,
  "created_at" : "2012-06-07 02:55:11 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210561959265968128",
  "geo" : { },
  "id_str" : "210562858734452736",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane That was my first reaction too!",
  "id" : 210562858734452736,
  "in_reply_to_status_id" : 210561959265968128,
  "created_at" : "2012-06-07 02:44:32 +0000",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Love",
      "screen_name" : "andrewtlove",
      "indices" : [ 24, 36 ],
      "id_str" : "18132818",
      "id" : 18132818
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 38, 51 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210561743829741569",
  "text" : "Close but no cigar. :) \u201C@andrewtlove: @busterbenson  Restate this blurb without revealing it\u2019s origin.\u201D",
  "id" : 210561743829741569,
  "created_at" : "2012-06-07 02:40:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210561111253196801",
  "text" : "Competitiveness is motivation generated by the fear that someone is better than you. T\/F?",
  "id" : 210561111253196801,
  "created_at" : "2012-06-07 02:37:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 3, 12 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/BIpKjdgy",
      "expanded_url" : "http:\/\/bit.ly\/Kyzb1g",
      "display_url" : "bit.ly\/Kyzb1g"
    } ]
  },
  "geo" : { },
  "id_str" : "210558929279791107",
  "text" : "RT @amyjokim: Abundance changes the basic rules, making hoarding and secrecy much less interesting than generosity and transparency. htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/BIpKjdgy",
        "expanded_url" : "http:\/\/bit.ly\/Kyzb1g",
        "display_url" : "bit.ly\/Kyzb1g"
      } ]
    },
    "geo" : { },
    "id_str" : "210557301935980544",
    "text" : "Abundance changes the basic rules, making hoarding and secrecy much less interesting than generosity and transparency. http:\/\/t.co\/BIpKjdgy",
    "id" : 210557301935980544,
    "created_at" : "2012-06-07 02:22:27 +0000",
    "user" : {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "protected" : false,
      "id_str" : "780991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1789001732\/ajk-headshot2_normal.jpg",
      "id" : 780991,
      "verified" : false
    }
  },
  "id" : 210558929279791107,
  "created_at" : "2012-06-07 02:28:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210556922204651520",
  "text" : "Paraphrase this tweet in your own words without referencing it.",
  "id" : 210556922204651520,
  "created_at" : "2012-06-07 02:20:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210550934454009857",
  "text" : "My brain wants to have its feet rubbed.",
  "id" : 210550934454009857,
  "created_at" : "2012-06-07 01:57:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/ZbhZJQIf",
      "expanded_url" : "http:\/\/bit.ly\/Ltoira",
      "display_url" : "bit.ly\/Ltoira"
    } ]
  },
  "geo" : { },
  "id_str" : "210470134463209472",
  "text" : "Favorite new tumblr: http:\/\/t.co\/ZbhZJQIf",
  "id" : 210470134463209472,
  "created_at" : "2012-06-06 20:36:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Metric",
      "screen_name" : "Metric",
      "indices" : [ 16, 23 ],
      "id_str" : "19722029",
      "id" : 19722029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/xZdjxFfs",
      "expanded_url" : "http:\/\/ilovemetric.com",
      "display_url" : "ilovemetric.com"
    } ]
  },
  "geo" : { },
  "id_str" : "210390788297867265",
  "text" : "The new awesome @metric album streaming on http:\/\/t.co\/xZdjxFfs. I'm a sucker for everything they release.",
  "id" : 210390788297867265,
  "created_at" : "2012-06-06 15:20:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/23Bz9diS",
      "expanded_url" : "http:\/\/flic.kr\/p\/bUBMB6",
      "display_url" : "flic.kr\/p\/bUBMB6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614333, -122.346834 ]
  },
  "id_str" : "210264603224051712",
  "text" : "8:36pm Double date night with Jimmy and Michelle at my fave restaurant: Tavolata! http:\/\/t.co\/23Bz9diS",
  "id" : 210264603224051712,
  "created_at" : "2012-06-06 06:59:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210095457756651521",
  "geo" : { },
  "id_str" : "210100118819586050",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez I tried the grilled chicken but there was also some ground beef. It even smelled like chicken, it was weird.",
  "id" : 210100118819586050,
  "in_reply_to_status_id" : 210095457756651521,
  "created_at" : "2012-06-05 20:05:46 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/jB2Te3YD",
      "expanded_url" : "http:\/\/bustr.me\/post\/24487387084\/fire-and-ice",
      "display_url" : "bustr.me\/post\/244873870\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "210099879899435008",
  "text" : "I hold with those who favor fire. http:\/\/t.co\/jB2Te3YD",
  "id" : 210099879899435008,
  "created_at" : "2012-06-05 20:04:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210089208927371264",
  "geo" : { },
  "id_str" : "210089510871109632",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara Ha! I think I left it open on my home computer. I promise to reply when I get home. :)",
  "id" : 210089510871109632,
  "in_reply_to_status_id" : 210089208927371264,
  "created_at" : "2012-06-05 19:23:37 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Biz Stone",
      "screen_name" : "biz",
      "indices" : [ 48, 52 ],
      "id_str" : "13",
      "id" : 13
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/MrWmXHLo",
      "expanded_url" : "http:\/\/bit.ly\/MdK6eq",
      "display_url" : "bit.ly\/MdK6eq"
    } ]
  },
  "geo" : { },
  "id_str" : "210089254750126083",
  "text" : "I tasted some! I couldn\u2019t believe it wasn\u2019t\u2026 RT @biz: Obvious Goes Beyond http:\/\/t.co\/MrWmXHLo",
  "id" : 210089254750126083,
  "created_at" : "2012-06-05 19:22:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/9BKkQ7cD",
      "expanded_url" : "http:\/\/vooza.com",
      "display_url" : "vooza.com"
    } ]
  },
  "geo" : { },
  "id_str" : "210075746167820288",
  "text" : "RT @jasonfried: Vooza is the web app you didn't even know you needed. What does it do? Find out here: http:\/\/t.co\/9BKkQ7cD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/9BKkQ7cD",
        "expanded_url" : "http:\/\/vooza.com",
        "display_url" : "vooza.com"
      } ]
    },
    "geo" : { },
    "id_str" : "210064568523833344",
    "text" : "Vooza is the web app you didn't even know you needed. What does it do? Find out here: http:\/\/t.co\/9BKkQ7cD",
    "id" : 210064568523833344,
    "created_at" : "2012-06-05 17:44:30 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 210075746167820288,
  "created_at" : "2012-06-05 18:28:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "indices" : [ 17, 26 ],
      "id_str" : "255784266",
      "id" : 255784266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/ozw1jaYG",
      "expanded_url" : "http:\/\/bit.ly\/MzsxbS",
      "display_url" : "bit.ly\/MzsxbS"
    } ]
  },
  "geo" : { },
  "id_str" : "210075142339051521",
  "text" : "This is cool: RT @geekwire: Introducing GeekWire\u2019s new resource center for startups http:\/\/t.co\/ozw1jaYG",
  "id" : 210075142339051521,
  "created_at" : "2012-06-05 18:26:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 128 ],
      "url" : "https:\/\/t.co\/oXqOf49e",
      "expanded_url" : "https:\/\/www.thelevelup.com\/join\/?promotion_code=68529",
      "display_url" : "thelevelup.com\/join\/?promotio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "210071877052403712",
  "text" : "I'm surprised how enjoyable the LevelUp experience is. If you haven't tried it, use this code for $5 free: https:\/\/t.co\/oXqOf49e",
  "id" : 210071877052403712,
  "created_at" : "2012-06-05 18:13:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/POBUy4XA",
      "expanded_url" : "http:\/\/flic.kr\/p\/bUfYcc",
      "display_url" : "flic.kr\/p\/bUfYcc"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "209853087337287680",
  "text" : "8:36pm Just working http:\/\/t.co\/POBUy4XA",
  "id" : 209853087337287680,
  "created_at" : "2012-06-05 03:44:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Guillebeau",
      "screen_name" : "chrisguillebeau",
      "indices" : [ 22, 38 ],
      "id_str" : "10373972",
      "id" : 10373972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209793359924051970",
  "text" : "I wish I was going to @chrisguillebeau\u2019s talk tonight at Town Hall on his new book, $100 Startup. If you go, take good notes!",
  "id" : 209793359924051970,
  "created_at" : "2012-06-04 23:46:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209792824261091329",
  "text" : "I\u2019m really happy it\u2019s becoming more acceptable for non-.com domains to be taken seriously. If only to screw over domain squatter biz models.",
  "id" : 209792824261091329,
  "created_at" : "2012-06-04 23:44:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Metcalf",
      "screen_name" : "robbymet",
      "indices" : [ 0, 9 ],
      "id_str" : "27112594",
      "id" : 27112594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209770553492504577",
  "geo" : { },
  "id_str" : "209770789040431105",
  "in_reply_to_user_id" : 27112594,
  "text" : "@robbymet For that particular case, I highly recommend the app called Checkie. Quickest checkins ever.",
  "id" : 209770789040431105,
  "in_reply_to_status_id" : 209770553492504577,
  "created_at" : "2012-06-04 22:17:08 +0000",
  "in_reply_to_screen_name" : "robbymet",
  "in_reply_to_user_id_str" : "27112594",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209710498567036931",
  "text" : "One of the problems with the mobile revolution is that opening an app is too much work for most things apps want to help you with.",
  "id" : 209710498567036931,
  "created_at" : "2012-06-04 18:17:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/oz0fRKhZ",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayMkyB8w",
      "display_url" : "tmblr.co\/ZQJvayMkyB8w"
    } ]
  },
  "geo" : { },
  "id_str" : "209696020836257793",
  "text" : "What do you want to remember? http:\/\/t.co\/oz0fRKhZ",
  "id" : 209696020836257793,
  "created_at" : "2012-06-04 17:20:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Grigg",
      "screen_name" : "egrigg9000",
      "indices" : [ 0, 11 ],
      "id_str" : "820129",
      "id" : 820129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209686443956781056",
  "geo" : { },
  "id_str" : "209687886507945984",
  "in_reply_to_user_id" : 820129,
  "text" : "@egrigg9000 I wanna see that!",
  "id" : 209687886507945984,
  "in_reply_to_status_id" : 209686443956781056,
  "created_at" : "2012-06-04 16:47:42 +0000",
  "in_reply_to_screen_name" : "egrigg9000",
  "in_reply_to_user_id_str" : "820129",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh MacLeod",
      "screen_name" : "gapingvoid",
      "indices" : [ 56, 67 ],
      "id_str" : "50193",
      "id" : 50193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/6MQFeyUc",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayMkcCD0",
      "display_url" : "tmblr.co\/ZQJvayMkcCD0"
    } ]
  },
  "geo" : { },
  "id_str" : "209661044296134656",
  "text" : "My take on \"mastery\": http:\/\/t.co\/6MQFeyUc \/inspired by @gapingvoid's recent post",
  "id" : 209661044296134656,
  "created_at" : "2012-06-04 15:01:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Carson",
      "screen_name" : "ryancarson",
      "indices" : [ 49, 60 ],
      "id_str" : "14763",
      "id" : 14763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/beeVFCov",
      "expanded_url" : "http:\/\/bit.ly\/M5sD4w",
      "display_url" : "bit.ly\/M5sD4w"
    } ]
  },
  "geo" : { },
  "id_str" : "209658637382189057",
  "text" : "This just blew my mind. I want to learn more! RT @ryancarson: Wow. \u201COur universe may exist inside a black hole.\u201D http:\/\/t.co\/beeVFCov",
  "id" : 209658637382189057,
  "created_at" : "2012-06-04 14:51:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hodgman",
      "screen_name" : "hodgman",
      "indices" : [ 3, 11 ],
      "id_str" : "14348594",
      "id" : 14348594
    }, {
      "name" : "Xeni Jardin",
      "screen_name" : "xeni",
      "indices" : [ 16, 21 ],
      "id_str" : "767",
      "id" : 767
    }, {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 48, 59 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/tfhhDDJr",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/06\/03\/nyt-men-invented-the-inter.html",
      "display_url" : "boingboing.net\/2012\/06\/03\/nyt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "209653962125750273",
  "text" : "RT @hodgman: GO @xeni: http:\/\/t.co\/tfhhDDJr via @BoingBoing",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Xeni Jardin",
        "screen_name" : "xeni",
        "indices" : [ 3, 8 ],
        "id_str" : "767",
        "id" : 767
      }, {
        "name" : "Boing Boing",
        "screen_name" : "BoingBoing",
        "indices" : [ 35, 46 ],
        "id_str" : "5971922",
        "id" : 5971922
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 10, 30 ],
        "url" : "http:\/\/t.co\/tfhhDDJr",
        "expanded_url" : "http:\/\/boingboing.net\/2012\/06\/03\/nyt-men-invented-the-inter.html",
        "display_url" : "boingboing.net\/2012\/06\/03\/nyt\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "209634312201584642",
    "text" : "GO @xeni: http:\/\/t.co\/tfhhDDJr via @BoingBoing",
    "id" : 209634312201584642,
    "created_at" : "2012-06-04 13:14:49 +0000",
    "user" : {
      "name" : "John Hodgman",
      "screen_name" : "hodgman",
      "protected" : false,
      "id_str" : "14348594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/423577280745439232\/bg3_uk5V_normal.jpeg",
      "id" : 14348594,
      "verified" : true
    }
  },
  "id" : 209653962125750273,
  "created_at" : "2012-06-04 14:32:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209554663786299392",
  "geo" : { },
  "id_str" : "209560887932092417",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates I was gonna retweet that but it sounded too good to be true. :)",
  "id" : 209560887932092417,
  "in_reply_to_status_id" : 209554663786299392,
  "created_at" : "2012-06-04 08:23:03 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/lfvjzIew",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayMjw8E4",
      "display_url" : "tmblr.co\/ZQJvayMjw8E4"
    } ]
  },
  "geo" : { },
  "id_str" : "209552151087812608",
  "text" : "How do you make an idea feel \"real\"? http:\/\/t.co\/lfvjzIew",
  "id" : 209552151087812608,
  "created_at" : "2012-06-04 07:48:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209549322046550016",
  "text" : "Having a little human creature brings out all kinds of weird old emotions, and invents new ones. It's one of the perks, I think.",
  "id" : 209549322046550016,
  "created_at" : "2012-06-04 07:37:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Orchard",
      "screen_name" : "lmorchard",
      "indices" : [ 0, 10 ],
      "id_str" : "8882",
      "id" : 8882
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 11, 21 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209529334724177920",
  "geo" : { },
  "id_str" : "209531096990367744",
  "in_reply_to_user_id" : 12514,
  "text" : "@lmorchard @tomcoates Smarts should be in the software, not the hardware.",
  "id" : 209531096990367744,
  "in_reply_to_status_id" : 209529334724177920,
  "created_at" : "2012-06-04 06:24:41 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 69, 79 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209529284790980608",
  "text" : "Leap Year wasn't as bad as the reviews said. Amy Adams reminds me of @kellianne a bit, who I haven't seen in 3 days. That probably helped.",
  "id" : 209529284790980608,
  "created_at" : "2012-06-04 06:17:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209521419137191936",
  "geo" : { },
  "id_str" : "209522232496623616",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar Plenty of fear, just no ability to fake it til I make it.",
  "id" : 209522232496623616,
  "in_reply_to_status_id" : 209521419137191936,
  "created_at" : "2012-06-04 05:49:27 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209519663896469504",
  "text" : "My advantage, and maybe curse, is that nobody else would ever really come up with the ideas I come up with.",
  "id" : 209519663896469504,
  "created_at" : "2012-06-04 05:39:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209472498448875520",
  "geo" : { },
  "id_str" : "209495284902932483",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley I vote for A.",
  "id" : 209495284902932483,
  "in_reply_to_status_id" : 209472498448875520,
  "created_at" : "2012-06-04 04:02:22 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/rSre0iOu",
      "expanded_url" : "http:\/\/flic.kr\/p\/caYTCb",
      "display_url" : "flic.kr\/p\/caYTCb"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "209491007706898432",
  "text" : "8:36pm The flower book gets pulled from the archives http:\/\/t.co\/rSre0iOu",
  "id" : 209491007706898432,
  "created_at" : "2012-06-04 03:45:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    }, {
      "name" : "Jimmy James Hall",
      "screen_name" : "JimmyJameson",
      "indices" : [ 17, 30 ],
      "id_str" : "35141809",
      "id" : 35141809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209232747376545792",
  "geo" : { },
  "id_str" : "209483946319294464",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar @JimmyJameson Pick a place and time, I will be there!",
  "id" : 209483946319294464,
  "in_reply_to_status_id" : 209232747376545792,
  "created_at" : "2012-06-04 03:17:19 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 19, 26 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209434672340541440",
  "geo" : { },
  "id_str" : "209440519812681731",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates I think @fitbit could come out with a wristband and clean them out. Nike\u2019s lack of API and terrible website will be their end.",
  "id" : 209440519812681731,
  "in_reply_to_status_id" : 209434672340541440,
  "created_at" : "2012-06-04 00:24:45 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209433253352976384",
  "geo" : { },
  "id_str" : "209434386700046337",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Yeah. I was shocked at how many people were wearing them in SF when I visited last week. Almost every nerd I saw (incl. myself).",
  "id" : 209434386700046337,
  "in_reply_to_status_id" : 209433253352976384,
  "created_at" : "2012-06-04 00:00:23 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209427584411373568",
  "text" : "What should I tweet about? \n\nA) Niko\nB) aspirational riddles\nC) something meta\n\n(as much as I love those topics, I need to mix things up)",
  "id" : 209427584411373568,
  "created_at" : "2012-06-03 23:33:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LISA CURRIE",
      "screen_name" : "lisacurriEEE",
      "indices" : [ 0, 13 ],
      "id_str" : "1894655173",
      "id" : 1894655173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209425984951291906",
  "geo" : { },
  "id_str" : "209426506655612929",
  "in_reply_to_user_id" : 385436920,
  "text" : "@lisacurriEEE Yeah, it\u2019s pretty fun having a mini me.",
  "id" : 209426506655612929,
  "in_reply_to_status_id" : 209425984951291906,
  "created_at" : "2012-06-03 23:29:04 +0000",
  "in_reply_to_screen_name" : "scribblediary",
  "in_reply_to_user_id_str" : "385436920",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/NSGE0Reg",
      "expanded_url" : "http:\/\/instagr.am\/p\/LbftIzI0HL\/",
      "display_url" : "instagr.am\/p\/LbftIzI0HL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "209421601450639361",
  "text" : "Niko rode his bike so much yesterday that the seat hurts today.  http:\/\/t.co\/NSGE0Reg",
  "id" : 209421601450639361,
  "created_at" : "2012-06-03 23:09:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh MacLeod",
      "screen_name" : "gapingvoid",
      "indices" : [ 26, 37 ],
      "id_str" : "50193",
      "id" : 50193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/CjdJKKHx",
      "expanded_url" : "http:\/\/gapingvoid.com\/2012\/05\/31\/on-mastery\/",
      "display_url" : "gapingvoid.com\/2012\/05\/31\/on-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "209374036243922945",
  "text" : "I like it. On Mastery, by @gapingvoid http:\/\/t.co\/CjdJKKHx",
  "id" : 209374036243922945,
  "created_at" : "2012-06-03 20:00:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209371227364659200",
  "geo" : { },
  "id_str" : "209371545058029568",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Just might! After 3:30 or so okay?",
  "id" : 209371545058029568,
  "in_reply_to_status_id" : 209371227364659200,
  "created_at" : "2012-06-03 19:50:40 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 9, 20 ],
      "id_str" : "142467448",
      "id" : 142467448
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 47, 57 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 75, 84 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209348860135477251",
  "text" : "I\u2019ve had @nikobenson for the last 3 days while @kellianne is in Boston for @rickwebb\u2019s birthday. Brain has reverted to 2-yo levels.",
  "id" : 209348860135477251,
  "created_at" : "2012-06-03 18:20:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Becker",
      "screen_name" : "jedwardbecker",
      "indices" : [ 0, 14 ],
      "id_str" : "22091098",
      "id" : 22091098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209337364651323393",
  "geo" : { },
  "id_str" : "209338815825985537",
  "in_reply_to_user_id" : 22091098,
  "text" : "@jedwardbecker Looks great! I\u2019ll be signing up. Email me at this username at gmail?",
  "id" : 209338815825985537,
  "in_reply_to_status_id" : 209337364651323393,
  "created_at" : "2012-06-03 17:40:37 +0000",
  "in_reply_to_screen_name" : "jedwardbecker",
  "in_reply_to_user_id_str" : "22091098",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209328838616948736",
  "text" : "What do you want to remember about the last year or so? Where are those memories best captured? How easy will it be to remember them again?",
  "id" : 209328838616948736,
  "created_at" : "2012-06-03 17:00:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/aqc41ATe",
      "expanded_url" : "http:\/\/flic.kr\/p\/cahiZA",
      "display_url" : "flic.kr\/p\/cahiZA"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.613333, -122.3105 ]
  },
  "id_str" : "209141138328784896",
  "text" : "8:36pm Was putting this guy to bed http:\/\/t.co\/aqc41ATe",
  "id" : 209141138328784896,
  "created_at" : "2012-06-03 04:35:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seth Godin",
      "screen_name" : "ThisIsSethsBlog",
      "indices" : [ 64, 80 ],
      "id_str" : "17825445",
      "id" : 17825445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/BSNl0OmZ",
      "expanded_url" : "http:\/\/sethgodin.typepad.com\/seths_blog\/2012\/05\/you-will-be-judged-or-you-will-be-ignored.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed:%20typepad\/sethsmainblog%20(Seth's%20Blog",
      "display_url" : "sethgodin.typepad.com\/seths_blog\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "209115274824261632",
  "text" : "\"You will be (mis-)judged or you will be ignored. Up to you.\" - @thisissethsblog http:\/\/t.co\/BSNl0OmZ)",
  "id" : 209115274824261632,
  "created_at" : "2012-06-03 02:52:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Jacobs",
      "screen_name" : "evanjacobs",
      "indices" : [ 0, 11 ],
      "id_str" : "14803483",
      "id" : 14803483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209012419601776645",
  "geo" : { },
  "id_str" : "209054876666306560",
  "in_reply_to_user_id" : 14803483,
  "text" : "@evanjacobs I did see it and got excited til I actually downloaded it. Seems more like an ad than an app.",
  "id" : 209054876666306560,
  "in_reply_to_status_id" : 209012419601776645,
  "created_at" : "2012-06-02 22:52:21 +0000",
  "in_reply_to_screen_name" : "evanjacobs",
  "in_reply_to_user_id_str" : "14803483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason",
      "screen_name" : "Jason",
      "indices" : [ 99, 105 ],
      "id_str" : "3840",
      "id" : 3840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/hDGmFFKc",
      "expanded_url" : "http:\/\/bit.ly\/L9cC0v",
      "display_url" : "bit.ly\/L9cC0v"
    } ]
  },
  "geo" : { },
  "id_str" : "208984727355539456",
  "text" : "A soccer ball that generates energy when you kick it. So awesome! Video: http:\/\/t.co\/hDGmFFKc \/via @jason",
  "id" : 208984727355539456,
  "created_at" : "2012-06-02 18:13:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hunter Walk",
      "screen_name" : "hunterwalk",
      "indices" : [ 3, 14 ],
      "id_str" : "46063",
      "id" : 46063
    }, {
      "name" : "Brad Feld",
      "screen_name" : "bfeld",
      "indices" : [ 139, 140 ],
      "id_str" : "3754891",
      "id" : 3754891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208981753103257600",
  "text" : "RT @hunterwalk: Life: Spend as much time as possible with PEOPLE you love in a PLACE you want to be on a THING you are passionate about. ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brad Feld",
        "screen_name" : "bfeld",
        "indices" : [ 126, 132 ],
        "id_str" : "3754891",
        "id" : 3754891
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208955384352882688",
    "text" : "Life: Spend as much time as possible with PEOPLE you love in a PLACE you want to be on a THING you are passionate about. (via @bfeld)",
    "id" : 208955384352882688,
    "created_at" : "2012-06-02 16:17:00 +0000",
    "user" : {
      "name" : "Hunter Walk",
      "screen_name" : "hunterwalk",
      "protected" : false,
      "id_str" : "46063",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3530636661\/448f950491b7c174df124e6ce8d7ba79_normal.png",
      "id" : 46063,
      "verified" : false
    }
  },
  "id" : 208981753103257600,
  "created_at" : "2012-06-02 18:01:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/5gcrNblX",
      "expanded_url" : "http:\/\/www.amazon.com\/gp\/aw\/d\/1439192812\/ref=redir_mdp_mobile?ref_=as_li_ss_til&tag=braipick-20&linkCode=as4&camp=213381&adid=1ZMR9Z8K1Q0PAS7PW1DS&creative=390973&creativeASIN=1439192812",
      "display_url" : "amazon.com\/gp\/aw\/d\/143919\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "208969489797226496",
  "text" : "Just bought The Magic of Reality for Niko (and myself). A new Richard Dawkins book. http:\/\/t.co\/5gcrNblX",
  "id" : 208969489797226496,
  "created_at" : "2012-06-02 17:13:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Felton",
      "screen_name" : "feltron",
      "indices" : [ 24, 32 ],
      "id_str" : "14892191",
      "id" : 14892191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/ywwLxxg4",
      "expanded_url" : "http:\/\/instagr.am\/p\/LW3c83I0HE\/",
      "display_url" : "instagr.am\/p\/LW3c83I0HE\/"
    } ]
  },
  "geo" : { },
  "id_str" : "208770646728130561",
  "text" : "8:36pm Taking a look at @feltron's latest report, beautiful as always http:\/\/t.co\/ywwLxxg4",
  "id" : 208770646728130561,
  "created_at" : "2012-06-02 04:02:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Ries",
      "screen_name" : "ericries",
      "indices" : [ 3, 12 ],
      "id_str" : "14278978",
      "id" : 14278978
    }, {
      "name" : "Derek Sivers",
      "screen_name" : "sivers",
      "indices" : [ 21, 28 ],
      "id_str" : "2206131",
      "id" : 2206131
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeanStartup",
      "indices" : [ 58, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/OhhsgPq8",
      "expanded_url" : "http:\/\/sivers.org\/book\/LeanStartup",
      "display_url" : "sivers.org\/book\/LeanStart\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "208635923821379584",
  "text" : "RT @ericries: Thanks @sivers for this incredibly detailed #LeanStartup summary + kind words: http:\/\/t.co\/OhhsgPq8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Derek Sivers",
        "screen_name" : "sivers",
        "indices" : [ 7, 14 ],
        "id_str" : "2206131",
        "id" : 2206131
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeanStartup",
        "indices" : [ 44, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/OhhsgPq8",
        "expanded_url" : "http:\/\/sivers.org\/book\/LeanStartup",
        "display_url" : "sivers.org\/book\/LeanStart\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "208634731502370817",
    "text" : "Thanks @sivers for this incredibly detailed #LeanStartup summary + kind words: http:\/\/t.co\/OhhsgPq8",
    "id" : 208634731502370817,
    "created_at" : "2012-06-01 19:02:50 +0000",
    "user" : {
      "name" : "Eric Ries",
      "screen_name" : "ericries",
      "protected" : false,
      "id_str" : "14278978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769304611\/image1327092761_normal.png",
      "id" : 14278978,
      "verified" : true
    }
  },
  "id" : 208635923821379584,
  "created_at" : "2012-06-01 19:07:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff McKean",
      "screen_name" : "jmckean",
      "indices" : [ 57, 65 ],
      "id_str" : "7409332",
      "id" : 7409332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208634876935667713",
  "text" : "1 second head start for every 100 friends difference? RT @jmckean: Handicap by # friends?",
  "id" : 208634876935667713,
  "created_at" : "2012-06-01 19:03:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 36, 46 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "instagramduel",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208633633429405697",
  "text" : "2 people take a picture and post to @instagram, then put their phones down. 1st to get a like wins. #instagramduel",
  "id" : 208633633429405697,
  "created_at" : "2012-06-01 18:58:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/HmfEeuxc",
      "expanded_url" : "http:\/\/instagr.am\/p\/LV23-WI0BN\/",
      "display_url" : "instagr.am\/p\/LV23-WI0BN\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.615071, -122.354059 ]
  },
  "id_str" : "208628381082857472",
  "text" : "Happy to be back on the choo program  @ Old Spaghetti Factory http:\/\/t.co\/HmfEeuxc",
  "id" : 208628381082857472,
  "created_at" : "2012-06-01 18:37:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]