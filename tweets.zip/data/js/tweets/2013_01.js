Grailbird.data.tweets_2013_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TarenSK",
      "screen_name" : "TarenSK",
      "indices" : [ 3, 11 ],
      "id_str" : "7415592",
      "id" : 7415592
    }, {
      "name" : "Cory Doctorow",
      "screen_name" : "doctorow",
      "indices" : [ 67, 76 ],
      "id_str" : "2729061",
      "id" : 2729061
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aaronswartz",
      "indices" : [ 24, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/rmawR2pd",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/2013\/01\/29\/aaron-swartz-cory-doctorow-homeland_n_2568774.html",
      "display_url" : "huffingtonpost.com\/2013\/01\/29\/aar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297242018302791681",
  "text" : "RT @TarenSK: I remember #aaronswartz being thrilled abt working on @doctorow's new novel. Read his afterword. Tears in my eyes. http:\/\/t ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cory Doctorow",
        "screen_name" : "doctorow",
        "indices" : [ 54, 63 ],
        "id_str" : "2729061",
        "id" : 2729061
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "aaronswartz",
        "indices" : [ 11, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/rmawR2pd",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/2013\/01\/29\/aaron-swartz-cory-doctorow-homeland_n_2568774.html",
        "display_url" : "huffingtonpost.com\/2013\/01\/29\/aar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "297123775990857728",
    "text" : "I remember #aaronswartz being thrilled abt working on @doctorow's new novel. Read his afterword. Tears in my eyes. http:\/\/t.co\/rmawR2pd",
    "id" : 297123775990857728,
    "created_at" : "2013-01-31 23:26:43 +0000",
    "user" : {
      "name" : "TarenSK",
      "screen_name" : "TarenSK",
      "protected" : false,
      "id_str" : "7415592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3184702502\/4bad040f9d31bd04a54cdabd7250bc74_normal.jpeg",
      "id" : 7415592,
      "verified" : false
    }
  },
  "id" : 297242018302791681,
  "created_at" : "2013-02-01 07:16:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottieYahtzee",
      "screen_name" : "ScottieYahtzee",
      "indices" : [ 0, 15 ],
      "id_str" : "15486015",
      "id" : 15486015
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 16, 26 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297206466971054083",
  "geo" : { },
  "id_str" : "297212625996099584",
  "in_reply_to_user_id" : 15486015,
  "text" : "@ScottieYahtzee @kellianne Let's agree to agree on that.",
  "id" : 297212625996099584,
  "in_reply_to_status_id" : 297206466971054083,
  "created_at" : "2013-02-01 05:19:46 +0000",
  "in_reply_to_screen_name" : "ScottieYahtzee",
  "in_reply_to_user_id_str" : "15486015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan the M. (MEM)",
      "screen_name" : "worldmegan",
      "indices" : [ 0, 11 ],
      "id_str" : "803663",
      "id" : 803663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297197073978249216",
  "geo" : { },
  "id_str" : "297204218115260417",
  "in_reply_to_user_id" : 803663,
  "text" : "@worldmegan I have to organize some things for that to work but email me at busterbenson@gmail.com and I'll figure things out!",
  "id" : 297204218115260417,
  "in_reply_to_status_id" : 297197073978249216,
  "created_at" : "2013-02-01 04:46:22 +0000",
  "in_reply_to_screen_name" : "worldmegan",
  "in_reply_to_user_id_str" : "803663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/slRj7L61",
      "expanded_url" : "http:\/\/flic.kr\/p\/dRg8Ep",
      "display_url" : "flic.kr\/p\/dRg8Ep"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.857666, -122.253334 ]
  },
  "id_str" : "297203555494920192",
  "text" : "8:36pm \"Papa you spilled wine right here. Please wipe it off!\" http:\/\/t.co\/slRj7L61",
  "id" : 297203555494920192,
  "created_at" : "2013-02-01 04:43:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/T65iBR3x",
      "expanded_url" : "http:\/\/vine.co\/v\/b1AL3lv7aFV",
      "display_url" : "vine.co\/v\/b1AL3lv7aFV"
    } ]
  },
  "geo" : { },
  "id_str" : "297202041137291265",
  "text" : "Big banana bite http:\/\/t.co\/T65iBR3x",
  "id" : 297202041137291265,
  "created_at" : "2013-02-01 04:37:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/CEfDHkhz",
      "expanded_url" : "http:\/\/4sq.com\/VroKwv",
      "display_url" : "4sq.com\/VroKwv"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8575071563, -122.253241539 ]
  },
  "id_str" : "297190266027261952",
  "text" : "Eating at the first place that looked tasty. (@ La M\u00E9diterran\u00E9e) http:\/\/t.co\/CEfDHkhz",
  "id" : 297190266027261952,
  "created_at" : "2013-02-01 03:50:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297173695112310784",
  "text" : "I love the feeling of walking a route for the first time that you know will soon be a familiar habit.",
  "id" : 297173695112310784,
  "created_at" : "2013-02-01 02:45:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 3, 19 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/DFXeYrnY",
      "expanded_url" : "http:\/\/bit.ly\/getliftapp",
      "display_url" : "bit.ly\/getliftapp"
    } ]
  },
  "geo" : { },
  "id_str" : "297163233851211776",
  "text" : "RT @tonystubblebine: Excited for the new friend feed in Lift. Much better experience. http:\/\/t.co\/DFXeYrnY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/DFXeYrnY",
        "expanded_url" : "http:\/\/bit.ly\/getliftapp",
        "display_url" : "bit.ly\/getliftapp"
      } ]
    },
    "geo" : { },
    "id_str" : "297158650487767040",
    "text" : "Excited for the new friend feed in Lift. Much better experience. http:\/\/t.co\/DFXeYrnY",
    "id" : 297158650487767040,
    "created_at" : "2013-02-01 01:45:17 +0000",
    "user" : {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "protected" : false,
      "id_str" : "17",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2905030942\/687f575ee3d5833f02b65d17a4133fcb_normal.jpeg",
      "id" : 17,
      "verified" : false
    }
  },
  "id" : 297163233851211776,
  "created_at" : "2013-02-01 02:03:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297134812991483904",
  "geo" : { },
  "id_str" : "297149042331361281",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler FRESH POTS!",
  "id" : 297149042331361281,
  "in_reply_to_status_id" : 297134812991483904,
  "created_at" : "2013-02-01 01:07:07 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 0, 10 ],
      "id_str" : "1771141",
      "id" : 1771141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297135632554287104",
  "geo" : { },
  "id_str" : "297140362374430720",
  "in_reply_to_user_id" : 1771141,
  "text" : "@samantham Yay!",
  "id" : 297140362374430720,
  "in_reply_to_status_id" : 297135632554287104,
  "created_at" : "2013-02-01 00:32:37 +0000",
  "in_reply_to_screen_name" : "samantham",
  "in_reply_to_user_id_str" : "1771141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297105909891620865",
  "geo" : { },
  "id_str" : "297110183170150400",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall No, looks like a prototype service I signed up to try a long time ago is now spamming my calendar contacts. Lame.",
  "id" : 297110183170150400,
  "in_reply_to_status_id" : 297105909891620865,
  "created_at" : "2013-01-31 22:32:42 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Happiness Engines",
      "screen_name" : "happy",
      "indices" : [ 0, 6 ],
      "id_str" : "491585749",
      "id" : 491585749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297098290472820736",
  "in_reply_to_user_id" : 491585749,
  "text" : "@happy I had no idea you'd be emailing people on my calendar. How do I turn that off?",
  "id" : 297098290472820736,
  "created_at" : "2013-01-31 21:45:26 +0000",
  "in_reply_to_screen_name" : "happy",
  "in_reply_to_user_id_str" : "491585749",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297095627500814336",
  "geo" : { },
  "id_str" : "297097071406759936",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall I have a robot assistant?",
  "id" : 297097071406759936,
  "in_reply_to_status_id" : 297095627500814336,
  "created_at" : "2013-01-31 21:40:36 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 79, 95 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/o64SMdnl",
      "expanded_url" : "http:\/\/bit.ly\/Xp3tVy",
      "display_url" : "bit.ly\/Xp3tVy"
    } ]
  },
  "geo" : { },
  "id_str" : "297092648118910976",
  "text" : "You have 11 lifetimes to master 11 things. Use them. http:\/\/t.co\/o64SMdnl \/via @tonystubblebine",
  "id" : 297092648118910976,
  "created_at" : "2013-01-31 21:23:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/sWkuaKUE",
      "expanded_url" : "http:\/\/flic.kr\/p\/dRgZsN",
      "display_url" : "flic.kr\/p\/dRgZsN"
    } ]
  },
  "geo" : { },
  "id_str" : "297085881402130432",
  "text" : "Is it weird that I like to eat lunch in front of full screen auto-streaming TweetDeck like this?  http:\/\/t.co\/sWkuaKUE",
  "id" : 297085881402130432,
  "created_at" : "2013-01-31 20:56:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 3, 13 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/qqZ0T6jf",
      "expanded_url" : "http:\/\/www.theverge.com\/2013\/1\/31\/3936670\/proteus-musical-exploration-game",
      "display_url" : "theverge.com\/2013\/1\/31\/3936\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297064834388856832",
  "text" : "RT @tomcoates: Lovely article about Proteus game from Verge. I will be downloading this shortly. Looks gorgeous: http:\/\/t.co\/qqZ0T6jf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/qqZ0T6jf",
        "expanded_url" : "http:\/\/www.theverge.com\/2013\/1\/31\/3936670\/proteus-musical-exploration-game",
        "display_url" : "theverge.com\/2013\/1\/31\/3936\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "297036426778902529",
    "text" : "Lovely article about Proteus game from Verge. I will be downloading this shortly. Looks gorgeous: http:\/\/t.co\/qqZ0T6jf",
    "id" : 297036426778902529,
    "created_at" : "2013-01-31 17:39:37 +0000",
    "user" : {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "protected" : false,
      "id_str" : "12514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459820658327683072\/I_qV0WKP_normal.png",
      "id" : 12514,
      "verified" : false
    }
  },
  "id" : 297064834388856832,
  "created_at" : "2013-01-31 19:32:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/findings.com\" rel=\"nofollow\"\u003EFindings\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Findings",
      "screen_name" : "findings",
      "indices" : [ 94, 103 ],
      "id_str" : "208197274",
      "id" : 208197274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/7ZDwNfcf",
      "expanded_url" : "http:\/\/fnd.gs\/VwKEAo",
      "display_url" : "fnd.gs\/VwKEAo"
    } ]
  },
  "geo" : { },
  "id_str" : "297060399218573314",
  "text" : "\"Kids always lacked respect, but since you stopped being a kid, suddenly it's a problem.\" via @findings - http:\/\/t.co\/7ZDwNfcf",
  "id" : 297060399218573314,
  "created_at" : "2013-01-31 19:14:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Kontny",
      "screen_name" : "natekontny",
      "indices" : [ 22, 33 ],
      "id_str" : "17386551",
      "id" : 17386551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/ZS3n84zT",
      "expanded_url" : "http:\/\/ninjasandrobots.com\/draft-version-control-for-writing",
      "display_url" : "ninjasandrobots.com\/draft-version-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "297038331559157760",
  "geo" : { },
  "id_str" : "297041362807836672",
  "in_reply_to_user_id" : 17386551,
  "text" : "It's pretty sweet. RT @natekontny: Draft. Version control for writing. http:\/\/t.co\/ZS3n84zT",
  "id" : 297041362807836672,
  "in_reply_to_status_id" : 297038331559157760,
  "created_at" : "2013-01-31 17:59:14 +0000",
  "in_reply_to_screen_name" : "natekontny",
  "in_reply_to_user_id_str" : "17386551",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 3, 9 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "an\u00B7gus",
      "screen_name" : "angustweets",
      "indices" : [ 27, 39 ],
      "id_str" : "140108433",
      "id" : 140108433
    }, {
      "name" : "Dan Webb",
      "screen_name" : "danwrong",
      "indices" : [ 41, 50 ],
      "id_str" : "389153",
      "id" : 389153
    }, {
      "name" : "Kenneth ",
      "screen_name" : "kpk",
      "indices" : [ 52, 56 ],
      "id_str" : "22915745",
      "id" : 22915745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/MHtVggLe",
      "expanded_url" : "http:\/\/twitter.github.com\/flight",
      "display_url" : "twitter.github.com\/flight"
    } ]
  },
  "geo" : { },
  "id_str" : "297028413410144256",
  "text" : "RT @couch: Big congrats to @angustweets, @danwrong, @kpk, et al. on the release of our internal JavaScript framework, Flight: http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "an\u00B7gus",
        "screen_name" : "angustweets",
        "indices" : [ 16, 28 ],
        "id_str" : "140108433",
        "id" : 140108433
      }, {
        "name" : "Dan Webb",
        "screen_name" : "danwrong",
        "indices" : [ 30, 39 ],
        "id_str" : "389153",
        "id" : 389153
      }, {
        "name" : "Kenneth ",
        "screen_name" : "kpk",
        "indices" : [ 41, 45 ],
        "id_str" : "22915745",
        "id" : 22915745
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/MHtVggLe",
        "expanded_url" : "http:\/\/twitter.github.com\/flight",
        "display_url" : "twitter.github.com\/flight"
      } ]
    },
    "geo" : { },
    "id_str" : "297025094151192576",
    "text" : "Big congrats to @angustweets, @danwrong, @kpk, et al. on the release of our internal JavaScript framework, Flight: http:\/\/t.co\/MHtVggLe",
    "id" : 297025094151192576,
    "created_at" : "2013-01-31 16:54:35 +0000",
    "user" : {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "protected" : false,
      "id_str" : "631823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428249544136994817\/fYWQCTd__normal.jpeg",
      "id" : 631823,
      "verified" : false
    }
  },
  "id" : 297028413410144256,
  "created_at" : "2013-01-31 17:07:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Broome",
      "screen_name" : "rosical",
      "indices" : [ 0, 8 ],
      "id_str" : "140145169",
      "id" : 140145169
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 76, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296872767079460864",
  "geo" : { },
  "id_str" : "296876530250940416",
  "in_reply_to_user_id" : 140145169,
  "text" : "@rosical Ha, true. In that case maybe you should ask that woman at the last #quantifiedself meetup we were at.",
  "id" : 296876530250940416,
  "in_reply_to_status_id" : 296872767079460864,
  "created_at" : "2013-01-31 07:04:15 +0000",
  "in_reply_to_screen_name" : "rosical",
  "in_reply_to_user_id_str" : "140145169",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Broome",
      "screen_name" : "rosical",
      "indices" : [ 0, 8 ],
      "id_str" : "140145169",
      "id" : 140145169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296862670878035968",
  "geo" : { },
  "id_str" : "296864016029069312",
  "in_reply_to_user_id" : 140145169,
  "text" : "@rosical Read Society of Mind, Self-Therapy, or How To Create a Mind for answers!",
  "id" : 296864016029069312,
  "in_reply_to_status_id" : 296862670878035968,
  "created_at" : "2013-01-31 06:14:31 +0000",
  "in_reply_to_screen_name" : "rosical",
  "in_reply_to_user_id_str" : "140145169",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/M6M7f2HY",
      "expanded_url" : "http:\/\/flic.kr\/p\/dR1NCv",
      "display_url" : "flic.kr\/p\/dR1NCv"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.774833, -122.437667 ]
  },
  "id_str" : "296839863062372352",
  "text" : "8:36pm Talkin bout stuff http:\/\/t.co\/M6M7f2HY",
  "id" : 296839863062372352,
  "created_at" : "2013-01-31 04:38:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ginevra",
      "screen_name" : "ginevra",
      "indices" : [ 0, 8 ],
      "id_str" : "35233",
      "id" : 35233
    }, {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 9, 19 ],
      "id_str" : "10609",
      "id" : 10609
    }, {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 20, 27 ],
      "id_str" : "6981492",
      "id" : 6981492
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 28, 37 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Ben Brown",
      "screen_name" : "benbrown",
      "indices" : [ 38, 47 ],
      "id_str" : "9027",
      "id" : 9027
    }, {
      "name" : "Tantek \u00C7elik",
      "screen_name" : "t",
      "indices" : [ 48, 50 ],
      "id_str" : "11628",
      "id" : 11628
    }, {
      "name" : "Ted Rheingold",
      "screen_name" : "tedr",
      "indices" : [ 51, 56 ],
      "id_str" : "997",
      "id" : 997
    }, {
      "name" : "nataliepo",
      "screen_name" : "nataliepo",
      "indices" : [ 57, 67 ],
      "id_str" : "5744892",
      "id" : 5744892
    }, {
      "name" : "Xeni Jardin",
      "screen_name" : "xeni",
      "indices" : [ 68, 73 ],
      "id_str" : "767",
      "id" : 767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296832842581819394",
  "geo" : { },
  "id_str" : "296838264323731457",
  "in_reply_to_user_id" : 35233,
  "text" : "@ginevra @superamit @ftrain @anildash @benbrown @t @tedr @nataliepo @xeni What's this \"web\" thing?",
  "id" : 296838264323731457,
  "in_reply_to_status_id" : 296832842581819394,
  "created_at" : "2013-01-31 04:32:11 +0000",
  "in_reply_to_screen_name" : "ginevra",
  "in_reply_to_user_id_str" : "35233",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 0, 6 ],
      "id_str" : "15310552",
      "id" : 15310552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296827716286685184",
  "geo" : { },
  "id_str" : "296836808682123264",
  "in_reply_to_user_id" : 15310552,
  "text" : "@singy When outings are rare you gotta make the best of it!",
  "id" : 296836808682123264,
  "in_reply_to_status_id" : 296827716286685184,
  "created_at" : "2013-01-31 04:26:24 +0000",
  "in_reply_to_screen_name" : "singy",
  "in_reply_to_user_id_str" : "15310552",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 0, 12 ],
      "id_str" : "195863654",
      "id" : 195863654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296828580506263552",
  "geo" : { },
  "id_str" : "296836608710307840",
  "in_reply_to_user_id" : 195863654,
  "text" : "@marihuertas Thank you! So far so good.",
  "id" : 296836608710307840,
  "in_reply_to_status_id" : 296828580506263552,
  "created_at" : "2013-01-31 04:25:37 +0000",
  "in_reply_to_screen_name" : "marihuertas",
  "in_reply_to_user_id_str" : "195863654",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 21, 31 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/KBVvHXzS",
      "expanded_url" : "http:\/\/4sq.com\/XlqicW",
      "display_url" : "4sq.com\/XlqicW"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.774981, -122.4377136 ]
  },
  "id_str" : "296827525387153408",
  "text" : "First SF date night! @kellianne (@ Nopa w\/ 4 others) http:\/\/t.co\/KBVvHXzS",
  "id" : 296827525387153408,
  "created_at" : "2013-01-31 03:49:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whereismybookdeal",
      "indices" : [ 34, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296805158917140480",
  "text" : "The secret to anything is itself. #whereismybookdeal",
  "id" : 296805158917140480,
  "created_at" : "2013-01-31 02:20:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296795570637533184",
  "text" : "What's the point of failing fast unless you also succeed faster? And that reveals the stupidity of the idea: key to success = succeed fast.",
  "id" : 296795570637533184,
  "created_at" : "2013-01-31 01:42:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/jL3j6hht",
      "expanded_url" : "http:\/\/bit.ly\/WydsKu",
      "display_url" : "bit.ly\/WydsKu"
    } ]
  },
  "geo" : { },
  "id_str" : "296676724031229952",
  "text" : "\"Are you doing your best possible work? Why not?\" - Way of the Duck http:\/\/t.co\/jL3j6hht",
  "id" : 296676724031229952,
  "created_at" : "2013-01-30 17:50:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Optality",
      "screen_name" : "Optality",
      "indices" : [ 0, 9 ],
      "id_str" : "764432724",
      "id" : 764432724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294235249062326273",
  "geo" : { },
  "id_str" : "296676258362822656",
  "in_reply_to_user_id" : 764432724,
  "text" : "@Optality I haven't received anything yet. Looking forward to trying it out!",
  "id" : 296676258362822656,
  "in_reply_to_status_id" : 294235249062326273,
  "created_at" : "2013-01-30 17:48:26 +0000",
  "in_reply_to_screen_name" : "Optality",
  "in_reply_to_user_id_str" : "764432724",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 15, 22 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/YXRZflxQ",
      "expanded_url" : "http:\/\/online.wsj.com\/article\/SB10001424127887323375204578269991660836834.html",
      "display_url" : "online.wsj.com\/article\/SB1000\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.788580921, -122.3922170253 ]
  },
  "id_str" : "296500361684975616",
  "text" : "This is rad RT @torrez: \u201CMr. Dennehy and nine of his friends have spent the past 23 years locked in a game of \u2018Tag.\u2019 \u201D http:\/\/t.co\/YXRZflxQ",
  "id" : 296500361684975616,
  "created_at" : "2013-01-30 06:09:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 77, 89 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/ryHIwUjn",
      "expanded_url" : "http:\/\/kck.st\/SATj5P",
      "display_url" : "kck.st\/SATj5P"
    } ]
  },
  "geo" : { },
  "id_str" : "296498178969190400",
  "text" : "I just backed SCIENCE: Ruining Everything Since 1543 (an SMBC Collection) on @Kickstarter http:\/\/t.co\/ryHIwUjn",
  "id" : 296498178969190400,
  "created_at" : "2013-01-30 06:00:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "feels roulette",
      "screen_name" : "steveklabnik",
      "indices" : [ 116, 129 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/r4GHOThS",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/?id=2871",
      "display_url" : "smbc-comics.com\/?id=2871"
    } ]
  },
  "geo" : { },
  "id_str" : "296496772979769344",
  "text" : "\"When they realized they were in a desert, they built a religion to worship thirstiness.\" http:\/\/t.co\/r4GHOThS \/via @steveklabnik",
  "id" : 296496772979769344,
  "created_at" : "2013-01-30 05:55:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/WQQy81tS",
      "expanded_url" : "http:\/\/flic.kr\/p\/dQRUk5",
      "display_url" : "flic.kr\/p\/dQRUk5"
    } ]
  },
  "geo" : { },
  "id_str" : "296478490792964096",
  "text" : "8:36pm Camera and face-making practice http:\/\/t.co\/WQQy81tS",
  "id" : 296478490792964096,
  "created_at" : "2013-01-30 04:42:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 0, 6 ],
      "id_str" : "8285392",
      "id" : 8285392
    }, {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 45, 54 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296317907695181825",
  "geo" : { },
  "id_str" : "296322648697368578",
  "in_reply_to_user_id" : 8285392,
  "text" : "@raffi These days all the kids want to be on @elonmusk's first boat to the new Mars colony.",
  "id" : 296322648697368578,
  "in_reply_to_status_id" : 296317907695181825,
  "created_at" : "2013-01-29 18:23:19 +0000",
  "in_reply_to_screen_name" : "raffi",
  "in_reply_to_user_id_str" : "8285392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Rusty Foster",
      "screen_name" : "rustyk5",
      "indices" : [ 9, 17 ],
      "id_str" : "577124971",
      "id" : 577124971
    }, {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 18, 25 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296298563456102400",
  "geo" : { },
  "id_str" : "296321122209779712",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs @rustyk5 @ftrain I agree that adding @username to the tweeted snippet (pulled from the twitter:site meta tag) would be awesome.",
  "id" : 296321122209779712,
  "in_reply_to_status_id" : 296298563456102400,
  "created_at" : "2013-01-29 18:17:15 +0000",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/eXlXfacK",
      "expanded_url" : "http:\/\/bit.ly",
      "display_url" : "bit.ly"
    }, {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/Sx1gKyOK",
      "expanded_url" : "http:\/\/bit.ly\/mxkFBv",
      "display_url" : "bit.ly\/mxkFBv"
    } ]
  },
  "geo" : { },
  "id_str" : "296309619360399360",
  "text" : "RT @neiltyson: Still disturbed that the popular URL shortener \"bitly\" turns its own address http:\/\/t.co\/eXlXfacK into http:\/\/t.co\/Sx1gKyOK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/eXlXfacK",
        "expanded_url" : "http:\/\/bit.ly",
        "display_url" : "bit.ly"
      }, {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/Sx1gKyOK",
        "expanded_url" : "http:\/\/bit.ly\/mxkFBv",
        "display_url" : "bit.ly\/mxkFBv"
      } ]
    },
    "geo" : { },
    "id_str" : "296306964399542273",
    "text" : "Still disturbed that the popular URL shortener \"bitly\" turns its own address http:\/\/t.co\/eXlXfacK into http:\/\/t.co\/Sx1gKyOK",
    "id" : 296306964399542273,
    "created_at" : "2013-01-29 17:21:00 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 296309619360399360,
  "created_at" : "2013-01-29 17:31:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/cMujWf9w",
      "expanded_url" : "http:\/\/flic.kr\/p\/dQBc3j",
      "display_url" : "flic.kr\/p\/dQBc3j"
    } ]
  },
  "geo" : { },
  "id_str" : "296125695057334272",
  "text" : "8:36pm Monster of the bath http:\/\/t.co\/cMujWf9w",
  "id" : 296125695057334272,
  "created_at" : "2013-01-29 05:20:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/ISn48UhL",
      "expanded_url" : "http:\/\/vine.co\/v\/bJHdJBxOJuW",
      "display_url" : "vine.co\/v\/bJHdJBxOJuW"
    } ]
  },
  "geo" : { },
  "id_str" : "296125299454771203",
  "text" : "Bath monster http:\/\/t.co\/ISn48UhL",
  "id" : 296125299454771203,
  "created_at" : "2013-01-29 05:19:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295991761115967489",
  "geo" : { },
  "id_str" : "295993028059996161",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap Only one way to find out! Either way, the tweets would be good.",
  "id" : 295993028059996161,
  "in_reply_to_status_id" : 295991761115967489,
  "created_at" : "2013-01-28 20:33:31 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 17, 25 ],
      "id_str" : "291",
      "id" : 291
    }, {
      "name" : "matt knox",
      "screen_name" : "mattknox",
      "indices" : [ 26, 35 ],
      "id_str" : "795244",
      "id" : 795244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295990421404921856",
  "geo" : { },
  "id_str" : "295992870328995840",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine @goldman @mattknox Y'all should add the \"Use Lift\" habit. It's my favorite one.",
  "id" : 295992870328995840,
  "in_reply_to_status_id" : 295990421404921856,
  "created_at" : "2013-01-28 20:32:54 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295910309896544256",
  "geo" : { },
  "id_str" : "295991400540012546",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap You should just come work here already.",
  "id" : 295991400540012546,
  "in_reply_to_status_id" : 295910309896544256,
  "created_at" : "2013-01-28 20:27:03 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan D. Gantz, CPK",
      "screen_name" : "sixfoot6",
      "indices" : [ 0, 9 ],
      "id_str" : "822030",
      "id" : 822030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295944004724477952",
  "geo" : { },
  "id_str" : "295990183554318336",
  "in_reply_to_user_id" : 822030,
  "text" : "@sixfoot6 But how else will we know that they really drank it?",
  "id" : 295990183554318336,
  "in_reply_to_status_id" : 295944004724477952,
  "created_at" : "2013-01-28 20:22:13 +0000",
  "in_reply_to_screen_name" : "sixfoot6",
  "in_reply_to_user_id_str" : "822030",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 3, 14 ],
      "id_str" : "3452941",
      "id" : 3452941
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 69, 76 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "The Seattle Times",
      "screen_name" : "seattletimes",
      "indices" : [ 127, 140 ],
      "id_str" : "14352556",
      "id" : 14352556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/7VtpcXF9",
      "expanded_url" : "http:\/\/blogs.seattletimes.com\/monica-guzman\/2013\/01\/28\/using-tech-to-change-your-habits-lessons-from-a-behavior-change-fanatic\/#.UQbXkC7YjTY.twitter",
      "display_url" : "blogs.seattletimes.com\/monica-guzman\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295985200624697344",
  "text" : "RT @moniguzman: Using tech to change your habits? A few lessons from @buster, behavior change fanatic http:\/\/t.co\/7VtpcXF9 via @seattletimes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 53, 60 ],
        "id_str" : "2185",
        "id" : 2185
      }, {
        "name" : "The Seattle Times",
        "screen_name" : "seattletimes",
        "indices" : [ 111, 124 ],
        "id_str" : "14352556",
        "id" : 14352556
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/7VtpcXF9",
        "expanded_url" : "http:\/\/blogs.seattletimes.com\/monica-guzman\/2013\/01\/28\/using-tech-to-change-your-habits-lessons-from-a-behavior-change-fanatic\/#.UQbXkC7YjTY.twitter",
        "display_url" : "blogs.seattletimes.com\/monica-guzman\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "295983519895801856",
    "text" : "Using tech to change your habits? A few lessons from @buster, behavior change fanatic http:\/\/t.co\/7VtpcXF9 via @seattletimes",
    "id" : 295983519895801856,
    "created_at" : "2013-01-28 19:55:44 +0000",
    "user" : {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "protected" : false,
      "id_str" : "3452941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454510513251037184\/83aM56tP_normal.jpeg",
      "id" : 3452941,
      "verified" : false
    }
  },
  "id" : 295985200624697344,
  "created_at" : "2013-01-28 20:02:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/d2hAmA2d",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvaycsSEFE",
      "display_url" : "tmblr.co\/ZQJvaycsSEFE"
    } ]
  },
  "geo" : { },
  "id_str" : "295970788933251072",
  "text" : "\u201CQuantity produces quality. If you only write a few things, you\u2019re doomed.\u201D - Ray Bradbury http:\/\/t.co\/d2hAmA2d",
  "id" : 295970788933251072,
  "created_at" : "2013-01-28 19:05:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/gFfz0cr2",
      "expanded_url" : "http:\/\/bit.ly\/VLWVks",
      "display_url" : "bit.ly\/VLWVks"
    } ]
  },
  "geo" : { },
  "id_str" : "295970016434745344",
  "text" : "Woah. http:\/\/t.co\/gFfz0cr2",
  "id" : 295970016434745344,
  "created_at" : "2013-01-28 19:02:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295960812915417088",
  "text" : "How long does it take to register a scene cut in video? Aka how many scene cuts can you fit into a vine without it being incomprehensible?",
  "id" : 295960812915417088,
  "created_at" : "2013-01-28 18:25:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "indices" : [ 3, 14 ],
      "id_str" : "419710142",
      "id" : 419710142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/glNV7zAf",
      "expanded_url" : "http:\/\/bit.ly\/XMDGpb",
      "display_url" : "bit.ly\/XMDGpb"
    } ]
  },
  "geo" : { },
  "id_str" : "295947723411165184",
  "text" : "RT @PandoDaily: Vine could potentially transform the news. Here's why: http:\/\/t.co\/glNV7zAf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/glNV7zAf",
        "expanded_url" : "http:\/\/bit.ly\/XMDGpb",
        "display_url" : "bit.ly\/XMDGpb"
      } ]
    },
    "geo" : { },
    "id_str" : "295942942290497538",
    "text" : "Vine could potentially transform the news. Here's why: http:\/\/t.co\/glNV7zAf",
    "id" : 295942942290497538,
    "created_at" : "2013-01-28 17:14:30 +0000",
    "user" : {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "protected" : false,
      "id_str" : "419710142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1764819620\/Pando_Twitter_Logo_normal.jpg",
      "id" : 419710142,
      "verified" : false
    }
  },
  "id" : 295947723411165184,
  "created_at" : "2013-01-28 17:33:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/CjFGS2Aq",
      "expanded_url" : "http:\/\/wayoftheduck.com\/1-for-you-updated",
      "display_url" : "wayoftheduck.com\/1-for-you-upda\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295937225055678465",
  "text" : "What I learned my complaining experiment (new experiment coming soon) http:\/\/t.co\/CjFGS2Aq",
  "id" : 295937225055678465,
  "created_at" : "2013-01-28 16:51:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas G\u00F6th",
      "screen_name" : "andreasgoth",
      "indices" : [ 0, 12 ],
      "id_str" : "2130501",
      "id" : 2130501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295930250423058432",
  "geo" : { },
  "id_str" : "295936757105565696",
  "in_reply_to_user_id" : 2130501,
  "text" : "@andreasgoth Thanks, fixed.",
  "id" : 295936757105565696,
  "in_reply_to_status_id" : 295930250423058432,
  "created_at" : "2013-01-28 16:49:55 +0000",
  "in_reply_to_screen_name" : "andreasgoth",
  "in_reply_to_user_id_str" : "2130501",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295800040709033984",
  "text" : "So glad that it seems like none of my friends were at the Twilight Exit tonight. Very sad that some people's friends were, and got shot.",
  "id" : 295800040709033984,
  "created_at" : "2013-01-28 07:46:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Briselli",
      "screen_name" : "jbriselli",
      "indices" : [ 0, 10 ],
      "id_str" : "386329939",
      "id" : 386329939
    }, {
      "name" : "Jason Alderman",
      "screen_name" : "justsomeguy",
      "indices" : [ 11, 23 ],
      "id_str" : "3394331",
      "id" : 3394331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295752469504458753",
  "geo" : { },
  "id_str" : "295784846691815424",
  "in_reply_to_user_id" : 386329939,
  "text" : "@jbriselli @justsomeguy Now I'm intrigued! What were the talks about?",
  "id" : 295784846691815424,
  "in_reply_to_status_id" : 295752469504458753,
  "created_at" : "2013-01-28 06:46:17 +0000",
  "in_reply_to_screen_name" : "jbriselli",
  "in_reply_to_user_id_str" : "386329939",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarah jurado ",
      "screen_name" : "sarahjurado",
      "indices" : [ 0, 12 ],
      "id_str" : "1252060596",
      "id" : 1252060596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295771018449018880",
  "geo" : { },
  "id_str" : "295772812919070721",
  "in_reply_to_user_id" : 15074951,
  "text" : "@sarahjurado Awesome. I do too.",
  "id" : 295772812919070721,
  "in_reply_to_status_id" : 295771018449018880,
  "created_at" : "2013-01-28 05:58:28 +0000",
  "in_reply_to_screen_name" : "sarahmjurado",
  "in_reply_to_user_id_str" : "15074951",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/rgucFHJs",
      "expanded_url" : "http:\/\/polarb.com\/47397",
      "display_url" : "polarb.com\/47397"
    } ]
  },
  "geo" : { },
  "id_str" : "295764593542823937",
  "text" : "Do You Think Vine Has What It Takes To Become Mainstream? Please vote. http:\/\/t.co\/rgucFHJs",
  "id" : 295764593542823937,
  "created_at" : "2013-01-28 05:25:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Marcel Molina",
      "screen_name" : "noradio",
      "indices" : [ 16, 24 ],
      "id_str" : "3191321",
      "id" : 3191321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295744558648672256",
  "geo" : { },
  "id_str" : "295753231424946176",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries @noradio Thanks for the link! I've been considering ways to improve on the cognitive biases Wikipedia page for years.",
  "id" : 295753231424946176,
  "in_reply_to_status_id" : 295744558648672256,
  "created_at" : "2013-01-28 04:40:39 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 61, 76 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/LD3z9WbQ",
      "expanded_url" : "http:\/\/flic.kr\/p\/dQiKRJ",
      "display_url" : "flic.kr\/p\/dQiKRJ"
    } ]
  },
  "geo" : { },
  "id_str" : "295752869787889665",
  "text" : "8:36pm Considering buying this logical fallacies poster \/via @mikeindustries http:\/\/t.co\/LD3z9WbQ",
  "id" : 295752869787889665,
  "created_at" : "2013-01-28 04:39:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/ZkpsYSW8",
      "expanded_url" : "http:\/\/www.npr.org\/blogs\/krulwich\/2013\/01\/22\/169976655\/nature-has-a-formula-that-tells-us-when-its-time-to-die",
      "display_url" : "npr.org\/blogs\/krulwich\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295750891590524929",
  "text" : "Nature has a formula that tells us when it's time to die. http:\/\/t.co\/ZkpsYSW8",
  "id" : 295750891590524929,
  "created_at" : "2013-01-28 04:31:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pasquale D'Silva",
      "screen_name" : "pasql",
      "indices" : [ 0, 6 ],
      "id_str" : "187793",
      "id" : 187793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295729181898182657",
  "geo" : { },
  "id_str" : "295747622814240768",
  "in_reply_to_user_id" : 187793,
  "text" : "@pasql Easy! Vine saves to your camera roll, use iMovie to stitch together, post to YouTube.",
  "id" : 295747622814240768,
  "in_reply_to_status_id" : 295729181898182657,
  "created_at" : "2013-01-28 04:18:22 +0000",
  "in_reply_to_screen_name" : "pasql",
  "in_reply_to_user_id_str" : "187793",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aubrey Sabala",
      "screen_name" : "Aubs",
      "indices" : [ 0, 5 ],
      "id_str" : "2781",
      "id" : 2781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295739788550623233",
  "geo" : { },
  "id_str" : "295743753120018432",
  "in_reply_to_user_id" : 2781,
  "text" : "@Aubs That was a fun time! And you're lucky to be alive! I wouldn't have trusted me pushing myself in a shopping cart.",
  "id" : 295743753120018432,
  "in_reply_to_status_id" : 295739788550623233,
  "created_at" : "2013-01-28 04:03:00 +0000",
  "in_reply_to_screen_name" : "Aubs",
  "in_reply_to_user_id_str" : "2781",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarah jurado ",
      "screen_name" : "sarahjurado",
      "indices" : [ 0, 12 ],
      "id_str" : "1252060596",
      "id" : 1252060596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295664893015777280",
  "geo" : { },
  "id_str" : "295667835466825728",
  "in_reply_to_user_id" : 15074951,
  "text" : "@sarahjurado It's not you, it's the app.",
  "id" : 295667835466825728,
  "in_reply_to_status_id" : 295664893015777280,
  "created_at" : "2013-01-27 23:01:19 +0000",
  "in_reply_to_screen_name" : "sarahmjurado",
  "in_reply_to_user_id_str" : "15074951",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Think",
      "screen_name" : "bigthink",
      "indices" : [ 3, 12 ],
      "id_str" : "18567018",
      "id" : 18567018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/ONyzFZcX",
      "expanded_url" : "http:\/\/bit.ly\/WhW8Zv",
      "display_url" : "bit.ly\/WhW8Zv"
    } ]
  },
  "geo" : { },
  "id_str" : "295655120853692418",
  "text" : "RT @bigthink: What Causes the Placebo Effect? http:\/\/t.co\/ONyzFZcX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/ONyzFZcX",
        "expanded_url" : "http:\/\/bit.ly\/WhW8Zv",
        "display_url" : "bit.ly\/WhW8Zv"
      } ]
    },
    "geo" : { },
    "id_str" : "295652259851804672",
    "text" : "What Causes the Placebo Effect? http:\/\/t.co\/ONyzFZcX",
    "id" : 295652259851804672,
    "created_at" : "2013-01-27 21:59:26 +0000",
    "user" : {
      "name" : "Big Think",
      "screen_name" : "bigthink",
      "protected" : false,
      "id_str" : "18567018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1142353176\/logo_normal.png",
      "id" : 18567018,
      "verified" : false
    }
  },
  "id" : 295655120853692418,
  "created_at" : "2013-01-27 22:10:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295634336177324033",
  "geo" : { },
  "id_str" : "295634687462883329",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Thank you! We were hoping to get lucky and we did!",
  "id" : 295634687462883329,
  "in_reply_to_status_id" : 295634336177324033,
  "created_at" : "2013-01-27 20:49:36 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/5UaNGXT1",
      "expanded_url" : "http:\/\/vine.co\/v\/bJqEwAEKhFE",
      "display_url" : "vine.co\/v\/bJqEwAEKhFE"
    } ]
  },
  "geo" : { },
  "id_str" : "295603074221887488",
  "text" : "Tour of our new South Berkeley home http:\/\/t.co\/5UaNGXT1",
  "id" : 295603074221887488,
  "created_at" : "2013-01-27 18:43:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/kprfUegz",
      "expanded_url" : "http:\/\/4sq.com\/X40Ok8",
      "display_url" : "4sq.com\/X40Ok8"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8622184536, -122.2813028409 ]
  },
  "id_str" : "295579761487536128",
  "text" : "New neighborhood brunch spot. (@ Homemade Cafe) http:\/\/t.co\/kprfUegz",
  "id" : 295579761487536128,
  "created_at" : "2013-01-27 17:11:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Prelinger",
      "screen_name" : "footage",
      "indices" : [ 3, 11 ],
      "id_str" : "774838",
      "id" : 774838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/SvNFl7wn",
      "expanded_url" : "http:\/\/Vinepeek.com",
      "display_url" : "Vinepeek.com"
    } ]
  },
  "geo" : { },
  "id_str" : "295557842679771136",
  "text" : "RT @footage: http:\/\/t.co\/SvNFl7wn: where food is abundant, technology ubiquitous, animals well-groomed, and leisure rules. IOS devices f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/SvNFl7wn",
        "expanded_url" : "http:\/\/Vinepeek.com",
        "display_url" : "Vinepeek.com"
      } ]
    },
    "geo" : { },
    "id_str" : "295556479518396416",
    "text" : "http:\/\/t.co\/SvNFl7wn: where food is abundant, technology ubiquitous, animals well-groomed, and leisure rules. IOS devices filter difference.",
    "id" : 295556479518396416,
    "created_at" : "2013-01-27 15:38:50 +0000",
    "user" : {
      "name" : "Rick Prelinger",
      "screen_name" : "footage",
      "protected" : false,
      "id_str" : "774838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1307246113\/RPinHVaults_variantSHRUNK_normal.jpg",
      "id" : 774838,
      "verified" : false
    }
  },
  "id" : 295557842679771136,
  "created_at" : "2013-01-27 15:44:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295557194320076801",
  "text" : "Woke up early because I'm so excited about our new house. We sign papers today!",
  "id" : 295557194320076801,
  "created_at" : "2013-01-27 15:41:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Harris",
      "screen_name" : "harrisj",
      "indices" : [ 38, 46 ],
      "id_str" : "681473",
      "id" : 681473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/RXpjbzKi",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Dogme_95",
      "display_url" : "en.m.wikipedia.org\/wiki\/Dogme_95"
    } ]
  },
  "in_reply_to_status_id_str" : "295490377790668800",
  "geo" : { },
  "id_str" : "295555572156203008",
  "in_reply_to_user_id" : 681473,
  "text" : "Looked it up: http:\/\/t.co\/RXpjbzKi RT @harrisj: Unless your vine strictly adheres to Dogme 95, it is a bourgeois exercise in self-indulgence",
  "id" : 295555572156203008,
  "in_reply_to_status_id" : 295490377790668800,
  "created_at" : "2013-01-27 15:35:14 +0000",
  "in_reply_to_screen_name" : "harrisj",
  "in_reply_to_user_id_str" : "681473",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295409497336332288",
  "geo" : { },
  "id_str" : "295410460524679169",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm For us older folks they have a much earlier blood test apparently.",
  "id" : 295410460524679169,
  "in_reply_to_status_id" : 295409497336332288,
  "created_at" : "2013-01-27 05:58:36 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Dom Hofmann",
      "screen_name" : "dhof",
      "indices" : [ 16, 21 ],
      "id_str" : "13258512",
      "id" : 13258512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jealous",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295406298751721472",
  "geo" : { },
  "id_str" : "295409208181010432",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries @dhof How do we get in on that dev build? #jealous",
  "id" : 295409208181010432,
  "in_reply_to_status_id" : 295406298751721472,
  "created_at" : "2013-01-27 05:53:38 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    }, {
      "name" : "Moves",
      "screen_name" : "movesapp",
      "indices" : [ 23, 32 ],
      "id_str" : "888379981",
      "id" : 888379981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295396522491797504",
  "geo" : { },
  "id_str" : "295398350948270081",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler Yeah I used @movesapp for a few weeks but had to turn it off because of battery drain. Pretty cool otherwise!",
  "id" : 295398350948270081,
  "in_reply_to_status_id" : 295396522491797504,
  "created_at" : "2013-01-27 05:10:29 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CARROT",
      "screen_name" : "CARROT_app",
      "indices" : [ 0, 11 ],
      "id_str" : "1077716029",
      "id" : 1077716029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295396070060597249",
  "geo" : { },
  "id_str" : "295396912633352192",
  "in_reply_to_user_id" : 1077716029,
  "text" : "@CARROT_app don't make me poke your ocular sensor again.",
  "id" : 295396912633352192,
  "in_reply_to_status_id" : 295396070060597249,
  "created_at" : "2013-01-27 05:04:46 +0000",
  "in_reply_to_screen_name" : "CARROT_app",
  "in_reply_to_user_id_str" : "1077716029",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CARROT",
      "screen_name" : "CARROT_app",
      "indices" : [ 23, 34 ],
      "id_str" : "1077716029",
      "id" : 1077716029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/fecVE9xa",
      "expanded_url" : "http:\/\/meetcarrot.com",
      "display_url" : "meetcarrot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "295393327791099905",
  "text" : "http:\/\/t.co\/fecVE9xa \/ @carrot_app is a todo list that gets annoyed with you if you don't do the things on your list. Hilarious.",
  "id" : 295393327791099905,
  "created_at" : "2013-01-27 04:50:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/zV9bzlk5",
      "expanded_url" : "http:\/\/flic.kr\/p\/dPTcqM",
      "display_url" : "flic.kr\/p\/dPTcqM"
    } ]
  },
  "geo" : { },
  "id_str" : "295391515746914304",
  "text" : "8:36pm Remember when brushing teeth could be this awesome? http:\/\/t.co\/zV9bzlk5",
  "id" : 295391515746914304,
  "created_at" : "2013-01-27 04:43:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295364586033532929",
  "text" : "What are the things I need to know about as a future resident of Berkeley?",
  "id" : 295364586033532929,
  "created_at" : "2013-01-27 02:56:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/XDmirL1J",
      "expanded_url" : "http:\/\/instagr.am\/p\/U9vnG0o0MC\/",
      "display_url" : "instagr.am\/p\/U9vnG0o0MC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "295306615370969089",
  "text" : "We totally found an awesome house in Berkeley! http:\/\/t.co\/XDmirL1J",
  "id" : 295306615370969089,
  "created_at" : "2013-01-26 23:05:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295230558081019906",
  "geo" : { },
  "id_str" : "295252018686214145",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell That guy doesn't exist anymore. :)",
  "id" : 295252018686214145,
  "in_reply_to_status_id" : 295230558081019906,
  "created_at" : "2013-01-26 19:29:01 +0000",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/ivm4o3YK",
      "expanded_url" : "http:\/\/vine.co\/v\/b5lJmJlHYXX",
      "display_url" : "vine.co\/v\/b5lJmJlHYXX"
    } ]
  },
  "geo" : { },
  "id_str" : "295220970917093376",
  "text" : "Going on a tour of the East Bay for potential places to live today. Cross your fingers! http:\/\/t.co\/ivm4o3YK",
  "id" : 295220970917093376,
  "created_at" : "2013-01-26 17:25:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/aSMByz6l",
      "expanded_url" : "http:\/\/vine.co\/v\/b59FMbtu3Pg",
      "display_url" : "vine.co\/v\/b59FMbtu3Pg"
    } ]
  },
  "geo" : { },
  "id_str" : "295066421275287553",
  "text" : "Before and after: 30 minutes treadmill http:\/\/t.co\/aSMByz6l",
  "id" : 295066421275287553,
  "created_at" : "2013-01-26 07:11:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill S.",
      "screen_name" : "outseide",
      "indices" : [ 0, 9 ],
      "id_str" : "143694663",
      "id" : 143694663
    }, {
      "name" : "Seesaw",
      "screen_name" : "Seesaw",
      "indices" : [ 10, 17 ],
      "id_str" : "763665",
      "id" : 763665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295031497134571520",
  "geo" : { },
  "id_str" : "295031921040322560",
  "in_reply_to_user_id" : 143694663,
  "text" : "@outseide @seesaw Looks like you need to be able to receive a text message to confirm. I'm sure Google Voice would work too.",
  "id" : 295031921040322560,
  "in_reply_to_status_id" : 295031497134571520,
  "created_at" : "2013-01-26 04:54:26 +0000",
  "in_reply_to_screen_name" : "outseide",
  "in_reply_to_user_id_str" : "143694663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seesaw",
      "screen_name" : "Seesaw",
      "indices" : [ 26, 33 ],
      "id_str" : "763665",
      "id" : 763665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/AxBG4uzW",
      "expanded_url" : "http:\/\/claim.seesaw.co",
      "display_url" : "claim.seesaw.co"
    } ]
  },
  "geo" : { },
  "id_str" : "295031025405415426",
  "text" : "Cool! I'm member #1599 on @Seesaw and my username is buster. You can get yours here http:\/\/t.co\/AxBG4uzW",
  "id" : 295031025405415426,
  "created_at" : "2013-01-26 04:50:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/fPEsxHCS",
      "expanded_url" : "http:\/\/flic.kr\/p\/dPBub4",
      "display_url" : "flic.kr\/p\/dPBub4"
    } ]
  },
  "geo" : { },
  "id_str" : "295029470937628674",
  "text" : "8:36pm Finishing dinner, or half of dinner, depending on the person http:\/\/t.co\/fPEsxHCS",
  "id" : 295029470937628674,
  "created_at" : "2013-01-26 04:44:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/e7V8UYUj",
      "expanded_url" : "http:\/\/vine.co\/v\/b5EvBhbOngn",
      "display_url" : "vine.co\/v\/b5EvBhbOngn"
    } ]
  },
  "geo" : { },
  "id_str" : "295024225746563073",
  "text" : "Niko's feeling better! http:\/\/t.co\/e7V8UYUj",
  "id" : 295024225746563073,
  "created_at" : "2013-01-26 04:23:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295017191013744640",
  "geo" : { },
  "id_str" : "295017415052500992",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm I think I was actually subtweeting you.",
  "id" : 295017415052500992,
  "in_reply_to_status_id" : 295017191013744640,
  "created_at" : "2013-01-26 03:56:47 +0000",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drunkvine",
      "indices" : [ 14, 24 ]
    }, {
      "text" : "drinkandvine",
      "indices" : [ 34, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295016656990789632",
  "text" : "I hope people #drunkvine tonight. #drinkandvine?",
  "id" : 295016656990789632,
  "created_at" : "2013-01-26 03:53:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Lodwick",
      "screen_name" : "jakelodwick",
      "indices" : [ 20, 32 ],
      "id_str" : "237262300",
      "id" : 237262300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295014610858307584",
  "geo" : { },
  "id_str" : "295015095740805121",
  "in_reply_to_user_id" : 237262300,
  "text" : "Then break them. RT @jakelodwick: EMBRACE CONSTRAINTS",
  "id" : 295015095740805121,
  "in_reply_to_status_id" : 295014610858307584,
  "created_at" : "2013-01-26 03:47:34 +0000",
  "in_reply_to_screen_name" : "jakelodwick",
  "in_reply_to_user_id_str" : "237262300",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/4ybLKahl",
      "expanded_url" : "http:\/\/mobile.businessweek.com\/articles\/2013-01-25\/in-the-new-vine-app-clues-to-twitters-ipo",
      "display_url" : "mobile.businessweek.com\/articles\/2013-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295014601173655552",
  "text" : "Embedded tweets + cards = magic! http:\/\/t.co\/4ybLKahl",
  "id" : 295014601173655552,
  "created_at" : "2013-01-26 03:45:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    }, {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 9, 18 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crossingfingers",
      "indices" : [ 28, 44 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294969975419064320",
  "geo" : { },
  "id_str" : "294996856134594561",
  "in_reply_to_user_id" : 15275073,
  "text" : "@tberman @spangley Awesome. #crossingfingers Also, thank you for the paper train link\u2026 we're gonna try to make it this weekend!",
  "id" : 294996856134594561,
  "in_reply_to_status_id" : 294969975419064320,
  "created_at" : "2013-01-26 02:35:05 +0000",
  "in_reply_to_screen_name" : "tberman",
  "in_reply_to_user_id_str" : "15275073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benny Wong",
      "screen_name" : "bdotdub",
      "indices" : [ 0, 8 ],
      "id_str" : "3032241",
      "id" : 3032241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/ONyzEjjz",
      "expanded_url" : "http:\/\/bit.ly\/WEr9nt",
      "display_url" : "bit.ly\/WEr9nt"
    } ]
  },
  "in_reply_to_status_id_str" : "294916103350673409",
  "geo" : { },
  "id_str" : "294966065690210304",
  "in_reply_to_user_id" : 3032241,
  "text" : "@bdotdub Try this link: http:\/\/t.co\/ONyzEjjz",
  "id" : 294966065690210304,
  "in_reply_to_status_id" : 294916103350673409,
  "created_at" : "2013-01-26 00:32:44 +0000",
  "in_reply_to_screen_name" : "bdotdub",
  "in_reply_to_user_id_str" : "3032241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lildude",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294930665256935424",
  "geo" : { },
  "id_str" : "294965615716888576",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley If we'd known he was on the verge of doubling down on sickness we would have stayed away from #lildude. Hope he didn't catch it :(",
  "id" : 294965615716888576,
  "in_reply_to_status_id" : 294930665256935424,
  "created_at" : "2013-01-26 00:30:57 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy Jacobson",
      "screen_name" : "jimmyjacobson",
      "indices" : [ 0, 14 ],
      "id_str" : "17545050",
      "id" : 17545050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294938300962197504",
  "geo" : { },
  "id_str" : "294965420937588736",
  "in_reply_to_user_id" : 17545050,
  "text" : "@jimmyjacobson Thanks! I didn't work directly on this but agree that it's an amazing thing.",
  "id" : 294965420937588736,
  "in_reply_to_status_id" : 294938300962197504,
  "created_at" : "2013-01-26 00:30:11 +0000",
  "in_reply_to_screen_name" : "jimmyjacobson",
  "in_reply_to_user_id_str" : "17545050",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/y7BANbjE",
      "expanded_url" : "http:\/\/instagr.am\/p\/U64DPmo0LU\/",
      "display_url" : "instagr.am\/p\/U64DPmo0LU\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.786309, -122.456363 ]
  },
  "id_str" : "294902628024987648",
  "text" : "Flu'd or RSV'd? We'll find out soon.  @ CPMC Pediatric Emergency Room http:\/\/t.co\/y7BANbjE",
  "id" : 294902628024987648,
  "created_at" : "2013-01-25 20:20:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 3, 11 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 101 ],
      "url" : "https:\/\/t.co\/duHgPqeY",
      "expanded_url" : "https:\/\/twitter.com\/NBCNewYork\/status\/294876307215495169",
      "display_url" : "twitter.com\/NBCNewYork\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294898595566600192",
  "text" : "RT @chanian: The future of new reporting is here, and it's 6 seconds long =&gt; https:\/\/t.co\/duHgPqeY",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 88 ],
        "url" : "https:\/\/t.co\/duHgPqeY",
        "expanded_url" : "https:\/\/twitter.com\/NBCNewYork\/status\/294876307215495169",
        "display_url" : "twitter.com\/NBCNewYork\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "294897952936304641",
    "text" : "The future of new reporting is here, and it's 6 seconds long =&gt; https:\/\/t.co\/duHgPqeY",
    "id" : 294897952936304641,
    "created_at" : "2013-01-25 20:02:05 +0000",
    "user" : {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "protected" : false,
      "id_str" : "22891211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2467844172\/image_normal.jpg",
      "id" : 22891211,
      "verified" : false
    }
  },
  "id" : 294898595566600192,
  "created_at" : "2013-01-25 20:04:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vineceptions",
      "indices" : [ 8, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7879232809, -122.3927667288 ]
  },
  "id_str" : "294696719034245120",
  "text" : "Forking #vineceptions.",
  "id" : 294696719034245120,
  "created_at" : "2013-01-25 06:42:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "indices" : [ 0, 5 ],
      "id_str" : "10221",
      "id" : 10221
    }, {
      "name" : "dick costolo",
      "screen_name" : "dickc",
      "indices" : [ 6, 12 ],
      "id_str" : "6385432",
      "id" : 6385432
    }, {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 13, 28 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Noah Stokes",
      "screen_name" : "motherfuton",
      "indices" : [ 29, 41 ],
      "id_str" : "5478442",
      "id" : 5478442
    }, {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 42, 46 ],
      "id_str" : "14616067",
      "id" : 14616067
    }, {
      "name" : "Michael Creasy",
      "screen_name" : "crsy",
      "indices" : [ 47, 52 ],
      "id_str" : "16223735",
      "id" : 16223735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294693505186537472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7880832627, -122.3923545625 ]
  },
  "id_str" : "294694504890527744",
  "in_reply_to_user_id" : 10221,
  "text" : "@drew @dickc @mikeindustries @motherfuton @ltm @crsy My head hurts, how do we get back out?",
  "id" : 294694504890527744,
  "in_reply_to_status_id" : 294693505186537472,
  "created_at" : "2013-01-25 06:33:39 +0000",
  "in_reply_to_screen_name" : "drew",
  "in_reply_to_user_id_str" : "10221",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sad ragnar",
      "screen_name" : "obscurity_goat",
      "indices" : [ 3, 18 ],
      "id_str" : "23390337",
      "id" : 23390337
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/obscurity_goat\/status\/294613564143046657\/photo\/1",
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/C66VJMvL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBatecVCEAAh86t.jpg",
      "id_str" : "294613564151435264",
      "id" : 294613564151435264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBatecVCEAAh86t.jpg",
      "sizes" : [ {
        "h" : 807,
        "resize" : "fit",
        "w" : 417
      }, {
        "h" : 807,
        "resize" : "fit",
        "w" : 417
      }, {
        "h" : 807,
        "resize" : "fit",
        "w" : 417
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 658,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/C66VJMvL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294693788461445123",
  "text" : "RT @obscurity_goat: Everyone on my twitter timeline. http:\/\/t.co\/C66VJMvL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/obscurity_goat\/status\/294613564143046657\/photo\/1",
        "indices" : [ 33, 53 ],
        "url" : "http:\/\/t.co\/C66VJMvL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBatecVCEAAh86t.jpg",
        "id_str" : "294613564151435264",
        "id" : 294613564151435264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBatecVCEAAh86t.jpg",
        "sizes" : [ {
          "h" : 807,
          "resize" : "fit",
          "w" : 417
        }, {
          "h" : 807,
          "resize" : "fit",
          "w" : 417
        }, {
          "h" : 807,
          "resize" : "fit",
          "w" : 417
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 658,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/C66VJMvL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "294613564143046657",
    "text" : "Everyone on my twitter timeline. http:\/\/t.co\/C66VJMvL",
    "id" : 294613564143046657,
    "created_at" : "2013-01-25 01:12:02 +0000",
    "user" : {
      "name" : "sad ragnar",
      "screen_name" : "obscurity_goat",
      "protected" : false,
      "id_str" : "23390337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440432935246655489\/4dV80NWM_normal.jpeg",
      "id" : 23390337,
      "verified" : false
    }
  },
  "id" : 294693788461445123,
  "created_at" : "2013-01-25 06:30:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "indices" : [ 0, 5 ],
      "id_str" : "10221",
      "id" : 10221
    }, {
      "name" : "Alexia Tsotsis",
      "screen_name" : "alexia",
      "indices" : [ 6, 13 ],
      "id_str" : "18327902",
      "id" : 18327902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294686013270396928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7880872861, -122.3922176197 ]
  },
  "id_str" : "294690294065147904",
  "in_reply_to_user_id" : 10221,
  "text" : "@drew @alexia sorta tempted to register that domain.",
  "id" : 294690294065147904,
  "in_reply_to_status_id" : 294686013270396928,
  "created_at" : "2013-01-25 06:16:55 +0000",
  "in_reply_to_screen_name" : "drew",
  "in_reply_to_user_id_str" : "10221",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/W8NIMHac",
      "expanded_url" : "http:\/\/vine.co\/v\/b5IZWz3Ajpv",
      "display_url" : "vine.co\/v\/b5IZWz3Ajpv"
    } ]
  },
  "geo" : { },
  "id_str" : "294681073756024832",
  "text" : "Sick Niko pretends to snore http:\/\/t.co\/W8NIMHac",
  "id" : 294681073756024832,
  "created_at" : "2013-01-25 05:40:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294676157201272833",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7881936089, -122.3923862002 ]
  },
  "id_str" : "294678042855489536",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin What about the 1st and final priority?",
  "id" : 294678042855489536,
  "in_reply_to_status_id" : 294676157201272833,
  "created_at" : "2013-01-25 05:28:14 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Creasy",
      "screen_name" : "crsy",
      "indices" : [ 3, 8 ],
      "id_str" : "16223735",
      "id" : 16223735
    }, {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 32, 47 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 48, 52 ],
      "id_str" : "14616067",
      "id" : 14616067
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 53, 60 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vineception",
      "indices" : [ 10, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/fL2Tmd0R",
      "expanded_url" : "http:\/\/vine.co\/v\/b5j3uujW6nQ",
      "display_url" : "vine.co\/v\/b5j3uujW6nQ"
    } ]
  },
  "geo" : { },
  "id_str" : "294676039144194048",
  "text" : "RT @crsy: #vineception level 4: @mikeindustries @ltm @buster http:\/\/t.co\/fL2Tmd0R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike Davidson",
        "screen_name" : "mikeindustries",
        "indices" : [ 22, 37 ],
        "id_str" : "74523",
        "id" : 74523
      }, {
        "name" : "Luke Millar",
        "screen_name" : "ltm",
        "indices" : [ 38, 42 ],
        "id_str" : "14616067",
        "id" : 14616067
      }, {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 43, 50 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "vineception",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/fL2Tmd0R",
        "expanded_url" : "http:\/\/vine.co\/v\/b5j3uujW6nQ",
        "display_url" : "vine.co\/v\/b5j3uujW6nQ"
      } ]
    },
    "geo" : { },
    "id_str" : "294675023556395008",
    "text" : "#vineception level 4: @mikeindustries @ltm @buster http:\/\/t.co\/fL2Tmd0R",
    "id" : 294675023556395008,
    "created_at" : "2013-01-25 05:16:15 +0000",
    "user" : {
      "name" : "Michael Creasy",
      "screen_name" : "crsy",
      "protected" : false,
      "id_str" : "16223735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/452831035844067328\/QAWn2HIn_normal.jpeg",
      "id" : 16223735,
      "verified" : false
    }
  },
  "id" : 294676039144194048,
  "created_at" : "2013-01-25 05:20:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    }, {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 5, 20 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 56 ],
      "url" : "https:\/\/t.co\/QdM1umPU",
      "expanded_url" : "https:\/\/twitter.com\/buster\/status\/294672672615436288",
      "display_url" : "twitter.com\/buster\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "294622905969569792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7880379461, -122.3922358678 ]
  },
  "id_str" : "294673495198167042",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm @mikeindustries And one more: https:\/\/t.co\/QdM1umPU",
  "id" : 294673495198167042,
  "in_reply_to_status_id" : 294622905969569792,
  "created_at" : "2013-01-25 05:10:10 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 22, 37 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 39, 43 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vineception",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/kQTanuss",
      "expanded_url" : "http:\/\/vine.co\/v\/b5jEtzqIiKP",
      "display_url" : "vine.co\/v\/b5jEtzqIiKP"
    } ]
  },
  "geo" : { },
  "id_str" : "294672672615436288",
  "text" : "#vineception level 3: @mikeindustries, @ltm, me http:\/\/t.co\/kQTanuss",
  "id" : 294672672615436288,
  "created_at" : "2013-01-25 05:06:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April V. Walters",
      "screen_name" : "aprilini",
      "indices" : [ 67, 76 ],
      "id_str" : "875511",
      "id" : 875511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/wgFy9e8s",
      "expanded_url" : "http:\/\/flic.kr\/p\/dPnvDX",
      "display_url" : "flic.kr\/p\/dPnvDX"
    } ]
  },
  "geo" : { },
  "id_str" : "294666649699753984",
  "text" : "8:36pm Poor guy had a 102 deg fever today but regained interest in @aprilini's gift is a good sign http:\/\/t.co\/wgFy9e8s",
  "id" : 294666649699753984,
  "created_at" : "2013-01-25 04:42:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/d3UkOhFj",
      "expanded_url" : "http:\/\/on.mash.to\/WRjkvP",
      "display_url" : "on.mash.to\/WRjkvP"
    } ]
  },
  "geo" : { },
  "id_str" : "294609316546224128",
  "text" : "10 creative vines http:\/\/t.co\/d3UkOhFj",
  "id" : 294609316546224128,
  "created_at" : "2013-01-25 00:55:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saleh",
      "screen_name" : "SalehUrfali",
      "indices" : [ 0, 12 ],
      "id_str" : "29508452",
      "id" : 29508452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294507452509065216",
  "geo" : { },
  "id_str" : "294536581119885312",
  "in_reply_to_user_id" : 29508452,
  "text" : "@SalehUrfali Ha, you're right\u2026 totally didn't notice. Now I have to wait for 123,456!",
  "id" : 294536581119885312,
  "in_reply_to_status_id" : 294507452509065216,
  "created_at" : "2013-01-24 20:06:07 +0000",
  "in_reply_to_screen_name" : "SalehUrfali",
  "in_reply_to_user_id_str" : "29508452",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quora",
      "screen_name" : "Quora",
      "indices" : [ 54, 60 ],
      "id_str" : "33696409",
      "id" : 33696409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/pXwugJEA",
      "expanded_url" : "http:\/\/b.qr.ae\/WRh9s5",
      "display_url" : "b.qr.ae\/WRh9s5"
    } ]
  },
  "geo" : { },
  "id_str" : "294536352614203392",
  "text" : "What's the most epic tweet? http:\/\/t.co\/pXwugJEA \/via @quora",
  "id" : 294536352614203392,
  "created_at" : "2013-01-24 20:05:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vine",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/psT4AcRB",
      "expanded_url" : "http:\/\/blog.twitter.com\/2013\/01\/vine-new-way-to-share-video.html",
      "display_url" : "blog.twitter.com\/2013\/01\/vine-n\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7881648086, -122.3922977986 ]
  },
  "id_str" : "294498698073890816",
  "text" : "Twitter launches a brand new video sharing app! Check it out: http:\/\/t.co\/psT4AcRB #vine",
  "id" : 294498698073890816,
  "created_at" : "2013-01-24 17:35:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vine",
      "screen_name" : "vineapp",
      "indices" : [ 3, 11 ],
      "id_str" : "586671909",
      "id" : 586671909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/tolTFuS6",
      "expanded_url" : "http:\/\/vine.co\/blog",
      "display_url" : "vine.co\/blog"
    } ]
  },
  "geo" : { },
  "id_str" : "294498352719085568",
  "text" : "RT @vineapp: We're happy to announce that our video sharing service has been acquired by Twitter and is launching today! http:\/\/t.co\/tol ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/tolTFuS6",
        "expanded_url" : "http:\/\/vine.co\/blog",
        "display_url" : "vine.co\/blog"
      } ]
    },
    "geo" : { },
    "id_str" : "294486118227922944",
    "text" : "We're happy to announce that our video sharing service has been acquired by Twitter and is launching today! http:\/\/t.co\/tolTFuS6",
    "id" : 294486118227922944,
    "created_at" : "2013-01-24 16:45:36 +0000",
    "user" : {
      "name" : "Vine",
      "screen_name" : "vineapp",
      "protected" : false,
      "id_str" : "586671909",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3578238864\/50d7e05aa6fe5d477e48a63047e38ce7_normal.png",
      "id" : 586671909,
      "verified" : true
    }
  },
  "id" : 294498352719085568,
  "created_at" : "2013-01-24 17:34:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 3, 10 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Ian Padgham",
      "screen_name" : "origiful",
      "indices" : [ 33, 42 ],
      "id_str" : "15603374",
      "id" : 15603374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/UZn0XkDs",
      "expanded_url" : "http:\/\/vine.co\/v\/b5HeOuiLHmd",
      "display_url" : "vine.co\/v\/b5HeOuiLHmd"
    } ]
  },
  "geo" : { },
  "id_str" : "294494538679058432",
  "text" : "RT @sippey: It's when folks like @origiful get ahold of it that things start to get real. http:\/\/t.co\/UZn0XkDs",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ian Padgham",
        "screen_name" : "origiful",
        "indices" : [ 21, 30 ],
        "id_str" : "15603374",
        "id" : 15603374
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/UZn0XkDs",
        "expanded_url" : "http:\/\/vine.co\/v\/b5HeOuiLHmd",
        "display_url" : "vine.co\/v\/b5HeOuiLHmd"
      } ]
    },
    "geo" : { },
    "id_str" : "294488853287415808",
    "text" : "It's when folks like @origiful get ahold of it that things start to get real. http:\/\/t.co\/UZn0XkDs",
    "id" : 294488853287415808,
    "created_at" : "2013-01-24 16:56:28 +0000",
    "user" : {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "protected" : false,
      "id_str" : "4711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461184996825243648\/6X8lZVyu_normal.jpeg",
      "id" : 4711,
      "verified" : false
    }
  },
  "id" : 294494538679058432,
  "created_at" : "2013-01-24 17:19:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstcat",
      "indices" : [ 3, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/tH8qUJlf",
      "expanded_url" : "http:\/\/vine.co\/v\/b5H1VqXbZ7J",
      "display_url" : "vine.co\/v\/b5H1VqXbZ7J"
    } ]
  },
  "geo" : { },
  "id_str" : "294491145243860993",
  "text" : "My #firstcat on Vine http:\/\/t.co\/tH8qUJlf",
  "id" : 294491145243860993,
  "created_at" : "2013-01-24 17:05:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 10, 14 ],
      "id_str" : "259",
      "id" : 259
    }, {
      "name" : "Spoon",
      "screen_name" : "spoonthedog",
      "indices" : [ 46, 58 ],
      "id_str" : "93102711",
      "id" : 93102711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294323117701074944",
  "geo" : { },
  "id_str" : "294327749546483712",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley @ian oh man twitter faux pas. Sorry @spoonthedog!",
  "id" : 294327749546483712,
  "in_reply_to_status_id" : 294323117701074944,
  "created_at" : "2013-01-24 06:16:18 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 29, 38 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 39, 47 ],
      "id_str" : "15275073",
      "id" : 15275073
    }, {
      "name" : "April V. Walters",
      "screen_name" : "aprilini",
      "indices" : [ 48, 57 ],
      "id_str" : "875511",
      "id" : 875511
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 58, 68 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 69, 80 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lildude",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/wLXTzFaC",
      "expanded_url" : "http:\/\/flic.kr\/p\/dPdqaJ",
      "display_url" : "flic.kr\/p\/dPdqaJ"
    } ]
  },
  "geo" : { },
  "id_str" : "294304559738810369",
  "text" : "8:36pm Inaugural dinner with @spangley @tberman @aprilini @kellianne @nikobenson &amp; #lildude http:\/\/t.co\/wLXTzFaC",
  "id" : 294304559738810369,
  "created_at" : "2013-01-24 04:44:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294250577452474368",
  "geo" : { },
  "id_str" : "294250705777209344",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb As if you would ever forget.",
  "id" : 294250705777209344,
  "in_reply_to_status_id" : 294250577452474368,
  "created_at" : "2013-01-24 01:10:09 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lowell",
      "screen_name" : "jthomas",
      "indices" : [ 0, 8 ],
      "id_str" : "760181",
      "id" : 760181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294184248749981696",
  "geo" : { },
  "id_str" : "294198610848002049",
  "in_reply_to_user_id" : 760181,
  "text" : "@jthomas Ha, thanks. Unfortunately it often takes me weeks to come up with anything worthwhile to say. :)",
  "id" : 294198610848002049,
  "in_reply_to_status_id" : 294184248749981696,
  "created_at" : "2013-01-23 21:43:09 +0000",
  "in_reply_to_screen_name" : "jthomas",
  "in_reply_to_user_id_str" : "760181",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Optality",
      "screen_name" : "Optality",
      "indices" : [ 0, 9 ],
      "id_str" : "764432724",
      "id" : 764432724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294194569501876224",
  "geo" : { },
  "id_str" : "294198276654260226",
  "in_reply_to_user_id" : 764432724,
  "text" : "@Optality I signed up! Letting anyone in right now?",
  "id" : 294198276654260226,
  "in_reply_to_status_id" : 294194569501876224,
  "created_at" : "2013-01-23 21:41:49 +0000",
  "in_reply_to_screen_name" : "Optality",
  "in_reply_to_user_id_str" : "764432724",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/5mcflV3y",
      "expanded_url" : "http:\/\/bit.ly\/Yo1MwD",
      "display_url" : "bit.ly\/Yo1MwD"
    } ]
  },
  "geo" : { },
  "id_str" : "294174034097209345",
  "text" : "28 day comparison of the accuracy of step counts from the Fitbit One, Jawbone UP, Nike+ FuelBand, and BodyMedia http:\/\/t.co\/5mcflV3y",
  "id" : 294174034097209345,
  "created_at" : "2013-01-23 20:05:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dick costolo",
      "screen_name" : "dickc",
      "indices" : [ 3, 9 ],
      "id_str" : "6385432",
      "id" : 6385432
    }, {
      "name" : "Dom Hofmann",
      "screen_name" : "dhof",
      "indices" : [ 67, 72 ],
      "id_str" : "13258512",
      "id" : 13258512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/po3sLav0",
      "expanded_url" : "http:\/\/vine.co\/v\/bOIqn6rLeID",
      "display_url" : "vine.co\/v\/bOIqn6rLeID"
    } ]
  },
  "geo" : { },
  "id_str" : "294165299035516928",
  "text" : "RT @dickc: Steak tartare in six seconds. http:\/\/t.co\/po3sLav0  via @dhof",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dom Hofmann",
        "screen_name" : "dhof",
        "indices" : [ 56, 61 ],
        "id_str" : "13258512",
        "id" : 13258512
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/po3sLav0",
        "expanded_url" : "http:\/\/vine.co\/v\/bOIqn6rLeID",
        "display_url" : "vine.co\/v\/bOIqn6rLeID"
      } ]
    },
    "geo" : { },
    "id_str" : "294124523714916353",
    "text" : "Steak tartare in six seconds. http:\/\/t.co\/po3sLav0  via @dhof",
    "id" : 294124523714916353,
    "created_at" : "2013-01-23 16:48:45 +0000",
    "user" : {
      "name" : "dick costolo",
      "screen_name" : "dickc",
      "protected" : false,
      "id_str" : "6385432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000652285709\/060bd6527bd63a4e3f241c954edd0e6f_normal.jpeg",
      "id" : 6385432,
      "verified" : false
    }
  },
  "id" : 294165299035516928,
  "created_at" : "2013-01-23 19:30:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 3, 12 ],
      "id_str" : "780991",
      "id" : 780991
    }, {
      "name" : "Kevin Werbach",
      "screen_name" : "kwerb",
      "indices" : [ 139, 140 ],
      "id_str" : "817970",
      "id" : 817970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/JqfVu79y",
      "expanded_url" : "http:\/\/bit.ly\/WUTvJY",
      "display_url" : "bit.ly\/WUTvJY"
    } ]
  },
  "geo" : { },
  "id_str" : "294118686342668288",
  "text" : "RT @amyjokim: Public universities to offer MOOCs for credit http:\/\/t.co\/JqfVu79y important step in the evolution of online education via ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Werbach",
        "screen_name" : "kwerb",
        "indices" : [ 123, 129 ],
        "id_str" : "817970",
        "id" : 817970
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/JqfVu79y",
        "expanded_url" : "http:\/\/bit.ly\/WUTvJY",
        "display_url" : "bit.ly\/WUTvJY"
      } ]
    },
    "geo" : { },
    "id_str" : "294097625962119168",
    "text" : "Public universities to offer MOOCs for credit http:\/\/t.co\/JqfVu79y important step in the evolution of online education via @kwerb",
    "id" : 294097625962119168,
    "created_at" : "2013-01-23 15:01:52 +0000",
    "user" : {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "protected" : false,
      "id_str" : "780991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1789001732\/ajk-headshot2_normal.jpg",
      "id" : 780991,
      "verified" : false
    }
  },
  "id" : 294118686342668288,
  "created_at" : "2013-01-23 16:25:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GOOD ",
      "screen_name" : "good",
      "indices" : [ 3, 8 ],
      "id_str" : "19621110",
      "id" : 19621110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/8Q4BTvtn",
      "expanded_url" : "http:\/\/ow.ly\/gUOZQ",
      "display_url" : "ow.ly\/gUOZQ"
    } ]
  },
  "geo" : { },
  "id_str" : "293997108183330816",
  "text" : "RT @GOOD: Follow the frog http:\/\/t.co\/8Q4BTvtn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 36 ],
        "url" : "http:\/\/t.co\/8Q4BTvtn",
        "expanded_url" : "http:\/\/ow.ly\/gUOZQ",
        "display_url" : "ow.ly\/gUOZQ"
      } ]
    },
    "geo" : { },
    "id_str" : "293994009095979008",
    "text" : "Follow the frog http:\/\/t.co\/8Q4BTvtn",
    "id" : 293994009095979008,
    "created_at" : "2013-01-23 08:10:08 +0000",
    "user" : {
      "name" : "GOOD ",
      "screen_name" : "good",
      "protected" : false,
      "id_str" : "19621110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3444533212\/fd0ee01ab8ff3ee05b8d1b5c5187f840_normal.jpeg",
      "id" : 19621110,
      "verified" : true
    }
  },
  "id" : 293997108183330816,
  "created_at" : "2013-01-23 08:22:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Budge",
      "screen_name" : "budge",
      "indices" : [ 52, 58 ],
      "id_str" : "286384512",
      "id" : 286384512
    }, {
      "name" : "RunKeeper",
      "screen_name" : "RunKeeper",
      "indices" : [ 73, 83 ],
      "id_str" : "15445811",
      "id" : 15445811
    }, {
      "name" : "Vardges Avetisyan",
      "screen_name" : "_v",
      "indices" : [ 85, 88 ],
      "id_str" : "198873588",
      "id" : 198873588
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/293977970039738368\/photo\/1",
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/1P1MNI8F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBRrZ_yCUAAgKez.jpg",
      "id_str" : "293977970048126976",
      "id" : 293977970048126976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBRrZ_yCUAAgKez.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1P1MNI8F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293977970039738368",
  "text" : "Tested my knee on a short slow run and noticed this @budge-like snail in @runkeeper! @_v http:\/\/t.co\/1P1MNI8F",
  "id" : 293977970039738368,
  "created_at" : "2013-01-23 07:06:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Ewing",
      "screen_name" : "hoverbird",
      "indices" : [ 0, 10 ],
      "id_str" : "792690",
      "id" : 792690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293946604136833024",
  "geo" : { },
  "id_str" : "293946740036489217",
  "in_reply_to_user_id" : 792690,
  "text" : "@hoverbird Oh I definitely will!",
  "id" : 293946740036489217,
  "in_reply_to_status_id" : 293946604136833024,
  "created_at" : "2013-01-23 05:02:18 +0000",
  "in_reply_to_screen_name" : "hoverbird",
  "in_reply_to_user_id_str" : "792690",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Ewing",
      "screen_name" : "hoverbird",
      "indices" : [ 0, 10 ],
      "id_str" : "792690",
      "id" : 792690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293941850140704769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7882618554, -122.3921553219 ]
  },
  "id_str" : "293946328059346944",
  "in_reply_to_user_id" : 792690,
  "text" : "@hoverbird Woah where is this magical machine?",
  "id" : 293946328059346944,
  "in_reply_to_status_id" : 293941850140704769,
  "created_at" : "2013-01-23 05:00:40 +0000",
  "in_reply_to_screen_name" : "hoverbird",
  "in_reply_to_user_id_str" : "792690",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/0LZO2yEl",
      "expanded_url" : "http:\/\/flic.kr\/p\/dNXxvu",
      "display_url" : "flic.kr\/p\/dNXxvu"
    } ]
  },
  "geo" : { },
  "id_str" : "293941769186447360",
  "text" : "8:36pm Relaxing post-dinner pre-taking turns exploring our fitness center http:\/\/t.co\/0LZO2yEl",
  "id" : 293941769186447360,
  "created_at" : "2013-01-23 04:42:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293889880931565568",
  "geo" : { },
  "id_str" : "293913649968459777",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman Glad I could help! Can you do a short follow-up post about NikeFuel at the 3 month mark? That's the true test I find.",
  "id" : 293913649968459777,
  "in_reply_to_status_id" : 293889880931565568,
  "created_at" : "2013-01-23 02:50:49 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/zWGFRsmv",
      "expanded_url" : "http:\/\/bit.ly\/WdFPNP",
      "display_url" : "bit.ly\/WdFPNP"
    } ]
  },
  "geo" : { },
  "id_str" : "293795434424590336",
  "text" : "Embedded tweets are now faster, easier (click the \"More\" link next to every tweet), have RT count, fave count, &amp; cards: http:\/\/t.co\/zWGFRsmv",
  "id" : 293795434424590336,
  "created_at" : "2013-01-22 19:01:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293782664165617665",
  "geo" : { },
  "id_str" : "293792668159447041",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk dream crusher.",
  "id" : 293792668159447041,
  "in_reply_to_status_id" : 293782664165617665,
  "created_at" : "2013-01-22 18:50:05 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    }, {
      "name" : "J.P. Doherty",
      "screen_name" : "jpd",
      "indices" : [ 11, 15 ],
      "id_str" : "160301248",
      "id" : 160301248
    }, {
      "name" : "Oliver",
      "screen_name" : "orvtech",
      "indices" : [ 16, 24 ],
      "id_str" : "4412471",
      "id" : 4412471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293741120029081602",
  "geo" : { },
  "id_str" : "293742093422190593",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler @jpd @orvtech Definitely strongly considering Alameda. Rockridge too. Luck of the draw on what's actually available.",
  "id" : 293742093422190593,
  "in_reply_to_status_id" : 293741120029081602,
  "created_at" : "2013-01-22 15:29:07 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/hMI24lD5",
      "expanded_url" : "http:\/\/instagr.am\/p\/Uyn1mUo0Ka\/",
      "display_url" : "instagr.am\/p\/Uyn1mUo0Ka\/"
    } ]
  },
  "geo" : { },
  "id_str" : "293741425374416896",
  "text" : "\"Where are the ding dongs and the trains?\" http:\/\/t.co\/hMI24lD5",
  "id" : 293741425374416896,
  "created_at" : "2013-01-22 15:26:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293738715929530368",
  "geo" : { },
  "id_str" : "293740311006547969",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler What's your commute like?",
  "id" : 293740311006547969,
  "in_reply_to_status_id" : 293738715929530368,
  "created_at" : "2013-01-22 15:22:02 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293739801448947715",
  "text" : "For about 0.000216 seconds this tweet was on the top of the world.",
  "id" : 293739801448947715,
  "created_at" : "2013-01-22 15:20:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hyped up aka popular",
      "screen_name" : "iano",
      "indices" : [ 0, 5 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293587022172540929",
  "geo" : { },
  "id_str" : "293738057360891904",
  "in_reply_to_user_id" : 14409856,
  "text" : "@iano Can you help us find our emoji names?",
  "id" : 293738057360891904,
  "in_reply_to_status_id" : 293587022172540929,
  "created_at" : "2013-01-22 15:13:04 +0000",
  "in_reply_to_screen_name" : "iano",
  "in_reply_to_user_id_str" : "14409856",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293670091772530688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7892193938, -122.3937306636 ]
  },
  "id_str" : "293737428051709952",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler East Bay for us too. Gonna look this weekend. Which neighborhood are you in?",
  "id" : 293737428051709952,
  "in_reply_to_status_id" : 293670091772530688,
  "created_at" : "2013-01-22 15:10:34 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaurav Gupta",
      "screen_name" : "unsymmetric",
      "indices" : [ 0, 12 ],
      "id_str" : "16554166",
      "id" : 16554166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293625285071495168",
  "geo" : { },
  "id_str" : "293627479522963456",
  "in_reply_to_user_id" : 16554166,
  "text" : "@unsymmetric Thank you! Stoked to be here for real finally.",
  "id" : 293627479522963456,
  "in_reply_to_status_id" : 293625285071495168,
  "created_at" : "2013-01-22 07:53:41 +0000",
  "in_reply_to_screen_name" : "unsymmetric",
  "in_reply_to_user_id_str" : "16554166",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 21, 28 ],
      "id_str" : "494518813",
      "id" : 494518813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/pyI4hKCQ",
      "expanded_url" : "http:\/\/bit.ly\/WjvGfl",
      "display_url" : "bit.ly\/WjvGfl"
    } ]
  },
  "geo" : { },
  "id_str" : "293626643480731648",
  "text" : "I'm totally misusing @branch as my own personal goal mini-blog wherein I plan to narrate my goal of running a marathon: http:\/\/t.co\/pyI4hKCQ",
  "id" : 293626643480731648,
  "created_at" : "2013-01-22 07:50:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Gordon",
      "screen_name" : "JeremySF",
      "indices" : [ 0, 9 ],
      "id_str" : "19872718",
      "id" : 19872718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293586884133797888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78950568, -122.39385845 ]
  },
  "id_str" : "293591475478986752",
  "in_reply_to_user_id" : 19872718,
  "text" : "@JeremySF I suspect they're gonna be getting a politely worded note from Branding soon.",
  "id" : 293591475478986752,
  "in_reply_to_status_id" : 293586884133797888,
  "created_at" : "2013-01-22 05:30:37 +0000",
  "in_reply_to_screen_name" : "JeremySF",
  "in_reply_to_user_id_str" : "19872718",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 20, 28 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/AHmKRqzy",
      "expanded_url" : "http:\/\/flic.kr\/p\/dNGt6Y",
      "display_url" : "flic.kr\/p\/dNGt6Y"
    } ]
  },
  "geo" : { },
  "id_str" : "293578675578892288",
  "text" : "8:36pm Wondering if @twitter had any say in this apartment's furnishings http:\/\/t.co\/AHmKRqzy",
  "id" : 293578675578892288,
  "created_at" : "2013-01-22 04:39:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/4SkH8JWs",
      "expanded_url" : "http:\/\/instagr.am\/p\/UxSrq8I0Es\/",
      "display_url" : "instagr.am\/p\/UxSrq8I0Es\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7878398962, -122.391901827 ]
  },
  "id_str" : "293554051528929280",
  "text" : "Niko's new city bedroom @ 388 Beale Luxury Apartments http:\/\/t.co\/4SkH8JWs",
  "id" : 293554051528929280,
  "created_at" : "2013-01-22 03:01:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293519062787555328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7877878156, -122.3922081813 ]
  },
  "id_str" : "293524044077215744",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves Oh man! I loved the Antidote. Take good notes.",
  "id" : 293524044077215744,
  "in_reply_to_status_id" : 293519062787555328,
  "created_at" : "2013-01-22 01:02:40 +0000",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 33, 43 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293515787157790721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7878475676, -122.3923254144 ]
  },
  "id_str" : "293516274871451648",
  "in_reply_to_user_id" : 15275073,
  "text" : "@tberman We would *love* to! \/cc @kellianne",
  "id" : 293516274871451648,
  "in_reply_to_status_id" : 293515787157790721,
  "created_at" : "2013-01-22 00:31:47 +0000",
  "in_reply_to_screen_name" : "tberman",
  "in_reply_to_user_id_str" : "15275073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/mn6sIFc4",
      "expanded_url" : "http:\/\/bustr.me\/post\/41150342604\/arrived-in-sf",
      "display_url" : "bustr.me\/post\/411503426\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7878350332, -122.3923641884 ]
  },
  "id_str" : "293515508148494336",
  "text" : "We totally live in SF now! View from our temp abode: http:\/\/t.co\/mn6sIFc4",
  "id" : 293515508148494336,
  "created_at" : "2013-01-22 00:28:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Scrofano",
      "screen_name" : "johnscrofano",
      "indices" : [ 0, 13 ],
      "id_str" : "14098444",
      "id" : 14098444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293485468606144512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7878705786, -122.3927610768 ]
  },
  "id_str" : "293515150101712896",
  "in_reply_to_user_id" : 14098444,
  "text" : "@johnscrofano We did and I've now sworn off In-n-Out again for a while.",
  "id" : 293515150101712896,
  "in_reply_to_status_id" : 293485468606144512,
  "created_at" : "2013-01-22 00:27:19 +0000",
  "in_reply_to_screen_name" : "johnscrofano",
  "in_reply_to_user_id_str" : "14098444",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Neves",
      "screen_name" : "TheAntonioNeves",
      "indices" : [ 0, 16 ],
      "id_str" : "20932488",
      "id" : 20932488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293445025273098240",
  "geo" : { },
  "id_str" : "293445821926629377",
  "in_reply_to_user_id" : 20932488,
  "text" : "@TheAntonioNeves That would be great!",
  "id" : 293445821926629377,
  "in_reply_to_status_id" : 293445025273098240,
  "created_at" : "2013-01-21 19:51:50 +0000",
  "in_reply_to_screen_name" : "TheAntonioNeves",
  "in_reply_to_user_id_str" : "20932488",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293440565821992960",
  "geo" : { },
  "id_str" : "293445514953900032",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april I agree. This feels like a transition.",
  "id" : 293445514953900032,
  "in_reply_to_status_id" : 293440565821992960,
  "created_at" : "2013-01-21 19:50:37 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/pKUKVMYt",
      "expanded_url" : "http:\/\/4sq.com\/10MLm2d",
      "display_url" : "4sq.com\/10MLm2d"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.5852535481, -122.3478317937 ]
  },
  "id_str" : "293444745760473089",
  "text" : "Had to do it. (@ In-N-Out Burger) http:\/\/t.co\/pKUKVMYt",
  "id" : 293444745760473089,
  "created_at" : "2013-01-21 19:47:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/txI3ZU95",
      "expanded_url" : "http:\/\/flic.kr\/p\/dNyCkG",
      "display_url" : "flic.kr\/p\/dNyCkG"
    } ]
  },
  "geo" : { },
  "id_str" : "293436561293467651",
  "text" : "Moving day 4 of 4: in which it dawns on us that we actually are moving. Last 274 miles to SF! http:\/\/t.co\/txI3ZU95",
  "id" : 293436561293467651,
  "created_at" : "2013-01-21 19:15:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/khEc4i4I",
      "expanded_url" : "http:\/\/instagr.am\/p\/UwZng1I0CT\/",
      "display_url" : "instagr.am\/p\/UwZng1I0CT\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.297852, -122.323718 ]
  },
  "id_str" : "293428758407434241",
  "text" : "Mt Shasta! @ Mount Shasta Ranch Bed and Breakfast http:\/\/t.co\/khEc4i4I",
  "id" : 293428758407434241,
  "created_at" : "2013-01-21 18:44:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293241433874366464",
  "text" : "Just met a 45 year old parrot named Ahab who says \"praise the lord\". She lives in the living room of the Mt Shasta Ranch B&amp;B. Come say hi!",
  "id" : 293241433874366464,
  "created_at" : "2013-01-21 06:19:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/DVErZOfg",
      "expanded_url" : "http:\/\/instagr.am\/p\/UvCAGQo0AZ\/",
      "display_url" : "instagr.am\/p\/UvCAGQo0AZ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.297852, -122.323718 ]
  },
  "id_str" : "293235659131457536",
  "text" : "8:36pm Made it to Mt Shasta! @ Mount Shasta Ranch Bed and Breakfast http:\/\/t.co\/DVErZOfg",
  "id" : 293235659131457536,
  "created_at" : "2013-01-21 05:56:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 35, 46 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/Ja2BRhuU",
      "expanded_url" : "http:\/\/4sq.com\/Xuj0Sh",
      "display_url" : "4sq.com\/Xuj0Sh"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 42.19770712, -122.715729475 ]
  },
  "id_str" : "293197827675410433",
  "text" : "Found this cool place on Ashland's @foursquare explore (@ Black Sheep) [pic]: http:\/\/t.co\/Ja2BRhuU",
  "id" : 293197827675410433,
  "created_at" : "2013-01-21 03:26:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/MSIYQIYY",
      "expanded_url" : "http:\/\/flic.kr\/p\/dNj5iL",
      "display_url" : "flic.kr\/p\/dNj5iL"
    } ]
  },
  "geo" : { },
  "id_str" : "293130871920279552",
  "text" : "Hazy highway http:\/\/t.co\/MSIYQIYY",
  "id" : 293130871920279552,
  "created_at" : "2013-01-20 23:00:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/GjqJDOON",
      "expanded_url" : "http:\/\/flic.kr\/p\/dNitPA",
      "display_url" : "flic.kr\/p\/dNitPA"
    } ]
  },
  "geo" : { },
  "id_str" : "293121145396420609",
  "text" : "Moving day 3 of 4 goals: brunch with friends in Portland (check), drive to Mt Shasta http:\/\/t.co\/GjqJDOON",
  "id" : 293121145396420609,
  "created_at" : "2013-01-20 22:21:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan McMinn",
      "screen_name" : "ryanmcminn",
      "indices" : [ 0, 11 ],
      "id_str" : "12061042",
      "id" : 12061042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293079688740495360",
  "geo" : { },
  "id_str" : "293087285493235712",
  "in_reply_to_user_id" : 12061042,
  "text" : "@ryanmcminn hi!",
  "id" : 293087285493235712,
  "in_reply_to_status_id" : 293079688740495360,
  "created_at" : "2013-01-20 20:07:08 +0000",
  "in_reply_to_screen_name" : "ryanmcminn",
  "in_reply_to_user_id_str" : "12061042",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek",
      "screen_name" : "derallo",
      "indices" : [ 111, 119 ],
      "id_str" : "16504159",
      "id" : 16504159
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/293041314159792128\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/SybPlvMt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBEXhcuCEAAbB8Q.png",
      "id_str" : "293041314168180736",
      "id" : 293041314168180736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBEXhcuCEAAbB8Q.png",
      "sizes" : [ {
        "h" : 670,
        "resize" : "fit",
        "w" : 741
      }, {
        "h" : 307,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 741
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/SybPlvMt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293041314159792128",
  "text" : "\"Females who are my friends of friends and who are under 30 years old and are single and like Doctor Who\" \/via @derallo http:\/\/t.co\/SybPlvMt",
  "id" : 293041314159792128,
  "created_at" : "2013-01-20 17:04:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 44, 51 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/293040280570044416\/photo\/1",
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/CMl4JD8w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBEWlSSCIAAjypq.png",
      "id_str" : "293040280574238720",
      "id" : 293040280574238720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBEWlSSCIAAjypq.png",
      "sizes" : [ {
        "h" : 594,
        "resize" : "fit",
        "w" : 678
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 594,
        "resize" : "fit",
        "w" : 678
      } ],
      "display_url" : "pic.twitter.com\/CMl4JD8w"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293040280570044416",
  "text" : "\"My friends who like Twitter and cats\" \/via @eismcc http:\/\/t.co\/CMl4JD8w",
  "id" : 293040280570044416,
  "created_at" : "2013-01-20 17:00:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293039181012279297",
  "text" : "Ooh, I got in to Facebook's Graph Search! What should I search for?",
  "id" : 293039181012279297,
  "created_at" : "2013-01-20 16:55:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    }, {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 11, 20 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292894950608211968",
  "geo" : { },
  "id_str" : "292897306926256128",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright @mathowie Hm... shucks. Not enough time and didn't plan. Will have to try again later. Thanks.",
  "id" : 292897306926256128,
  "in_reply_to_status_id" : 292894950608211968,
  "created_at" : "2013-01-20 07:32:14 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292893896520896512",
  "geo" : { },
  "id_str" : "292894153170374656",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright Awesome. Think I'll be okay without chains? No snow on forecast for tomorrow.",
  "id" : 292894153170374656,
  "in_reply_to_status_id" : 292893896520896512,
  "created_at" : "2013-01-20 07:19:42 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Jo Richey",
      "screen_name" : "erinjo",
      "indices" : [ 0, 7 ],
      "id_str" : "14961286",
      "id" : 14961286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292892454414323712",
  "geo" : { },
  "id_str" : "292893412854726656",
  "in_reply_to_user_id" : 14961286,
  "text" : "@erinjo Ooh thanks!",
  "id" : 292893412854726656,
  "in_reply_to_status_id" : 292892454414323712,
  "created_at" : "2013-01-20 07:16:45 +0000",
  "in_reply_to_screen_name" : "erinjo",
  "in_reply_to_user_id_str" : "14961286",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/1J2Pr31r",
      "expanded_url" : "http:\/\/instagr.am\/p\/Usk6_0I0JM\/",
      "display_url" : "instagr.am\/p\/Usk6_0I0JM\/"
    } ]
  },
  "geo" : { },
  "id_str" : "292890864433393665",
  "text" : "First time Niko has asked for help with his porter responsibilities http:\/\/t.co\/1J2Pr31r",
  "id" : 292890864433393665,
  "created_at" : "2013-01-20 07:06:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292880921152086016",
  "geo" : { },
  "id_str" : "292884022420439040",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew Yeah, that's what I was fearing. I'll call them tomorrow. In any case, driving *near* Crater Lake might still be fun.",
  "id" : 292884022420439040,
  "in_reply_to_status_id" : 292880921152086016,
  "created_at" : "2013-01-20 06:39:27 +0000",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292866992384385024",
  "geo" : { },
  "id_str" : "292877349542838272",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Niko's life is actually dictated by a quickly evolving race of mind-control monkey puppets.",
  "id" : 292877349542838272,
  "in_reply_to_status_id" : 292866992384385024,
  "created_at" : "2013-01-20 06:12:56 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292877206894571521",
  "text" : "Thinking of taking 97 down instead of 5 to potentially make a short stop at Crater Lake and\/or Lava Beds. Has anyone gone that way recently?",
  "id" : 292877206894571521,
  "created_at" : "2013-01-20 06:12:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/Z6qV3b4k",
      "expanded_url" : "http:\/\/instagr.am\/p\/UsUWC1I0JW\/",
      "display_url" : "instagr.am\/p\/UsUWC1I0JW\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.520945, -122.687412 ]
  },
  "id_str" : "292854397111783424",
  "text" : "8:36pm Made it to Portland! @ Hotel deLuxe http:\/\/t.co\/Z6qV3b4k",
  "id" : 292854397111783424,
  "created_at" : "2013-01-20 04:41:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/6TGvaZZM",
      "expanded_url" : "http:\/\/flic.kr\/p\/dMV7eK",
      "display_url" : "flic.kr\/p\/dMV7eK"
    } ]
  },
  "geo" : { },
  "id_str" : "292795679271694336",
  "text" : "Finally on the road. Only 172 miles to do today. http:\/\/t.co\/6TGvaZZM",
  "id" : 292795679271694336,
  "created_at" : "2013-01-20 00:48:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/RjPltcDA",
      "expanded_url" : "http:\/\/4sq.com\/10rIve7",
      "display_url" : "4sq.com\/10rIve7"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6044919218, -122.3099753868 ]
  },
  "id_str" : "292780653383151616",
  "text" : "We're officially homeless. Bye bye Benson Bungalow. You did us well. (@ \uE036Benson Bungalow) http:\/\/t.co\/RjPltcDA",
  "id" : 292780653383151616,
  "created_at" : "2013-01-19 23:48:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292710014047645696",
  "geo" : { },
  "id_str" : "292710529632464896",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves Oh believe me you don't want this. It's an old rusty metal piece of junk. :)",
  "id" : 292710529632464896,
  "in_reply_to_status_id" : 292710014047645696,
  "created_at" : "2013-01-19 19:10:03 +0000",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 0, 6 ],
      "id_str" : "15310552",
      "id" : 15310552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292708589691359232",
  "geo" : { },
  "id_str" : "292709106043731969",
  "in_reply_to_user_id" : 15310552,
  "text" : "@singy Just a temporary place. Gonna find a real one next weekend.",
  "id" : 292709106043731969,
  "in_reply_to_status_id" : 292708589691359232,
  "created_at" : "2013-01-19 19:04:23 +0000",
  "in_reply_to_screen_name" : "singy",
  "in_reply_to_user_id_str" : "15310552",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 0, 6 ],
      "id_str" : "15310552",
      "id" : 15310552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292708204142526464",
  "geo" : { },
  "id_str" : "292708464319414272",
  "in_reply_to_user_id" : 15310552,
  "text" : "@singy Still loading the truck. Hitting the road tonight, and arriving Monday.",
  "id" : 292708464319414272,
  "in_reply_to_status_id" : 292708204142526464,
  "created_at" : "2013-01-19 19:01:50 +0000",
  "in_reply_to_screen_name" : "singy",
  "in_reply_to_user_id_str" : "15310552",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 0, 6 ],
      "id_str" : "15310552",
      "id" : 15310552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292707387561873409",
  "geo" : { },
  "id_str" : "292707835979108352",
  "in_reply_to_user_id" : 15310552,
  "text" : "@singy Find me an apartment!",
  "id" : 292707835979108352,
  "in_reply_to_status_id" : 292707387561873409,
  "created_at" : "2013-01-19 18:59:21 +0000",
  "in_reply_to_screen_name" : "singy",
  "in_reply_to_user_id_str" : "15310552",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather quintal",
      "screen_name" : "heatherquintal",
      "indices" : [ 0, 15 ],
      "id_str" : "12761252",
      "id" : 12761252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292705618370895873",
  "geo" : { },
  "id_str" : "292705852366929920",
  "in_reply_to_user_id" : 12761252,
  "text" : "@heatherquintal Yeah you're right about per mover. And thank you!",
  "id" : 292705852366929920,
  "in_reply_to_status_id" : 292705618370895873,
  "created_at" : "2013-01-19 18:51:28 +0000",
  "in_reply_to_screen_name" : "heatherquintal",
  "in_reply_to_user_id_str" : "12761252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "indices" : [ 0, 9 ],
      "id_str" : "22483",
      "id" : 22483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292698771400302592",
  "geo" : { },
  "id_str" : "292701378642575360",
  "in_reply_to_user_id" : 22483,
  "text" : "@pinwheel That would be awesome but coordinating with cleaner is making our quick departure look unlikely. :(",
  "id" : 292701378642575360,
  "in_reply_to_status_id" : 292698771400302592,
  "created_at" : "2013-01-19 18:33:41 +0000",
  "in_reply_to_screen_name" : "pinwheel",
  "in_reply_to_user_id_str" : "22483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292698842154012672",
  "geo" : { },
  "id_str" : "292701140938797056",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling Thank you! We will miss you too. :'( We will visit!",
  "id" : 292701140938797056,
  "in_reply_to_status_id" : 292698842154012672,
  "created_at" : "2013-01-19 18:32:44 +0000",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292699135612694530",
  "geo" : { },
  "id_str" : "292700518487314432",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin :( We will remain astrosibs forever!",
  "id" : 292700518487314432,
  "in_reply_to_status_id" : 292699135612694530,
  "created_at" : "2013-01-19 18:30:16 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292692126695821312",
  "geo" : { },
  "id_str" : "292693401927835648",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward Interesting... Only problem is I have no idea what it costs (thanks to Twitter).",
  "id" : 292693401927835648,
  "in_reply_to_status_id" : 292692126695821312,
  "created_at" : "2013-01-19 18:01:59 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/5Fi240Rx",
      "expanded_url" : "http:\/\/quantifiedself.com\/2013\/01\/nike-fuelband-vs-fitbit-step-tracking-are-they-the-same\/",
      "display_url" : "quantifiedself.com\/2013\/01\/nike-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292693081076158465",
  "text" : "RT @e_ramirez: I wore the Fuelband &amp; the Fitbit for one week &amp; found interesting results: http:\/\/t.co\/5Fi240Rx What have you fou ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/5Fi240Rx",
        "expanded_url" : "http:\/\/quantifiedself.com\/2013\/01\/nike-fuelband-vs-fitbit-step-tracking-are-they-the-same\/",
        "display_url" : "quantifiedself.com\/2013\/01\/nike-f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "292690675084967936",
    "text" : "I wore the Fuelband &amp; the Fitbit for one week &amp; found interesting results: http:\/\/t.co\/5Fi240Rx What have you found out about your trackers?",
    "id" : 292690675084967936,
    "created_at" : "2013-01-19 17:51:09 +0000",
    "user" : {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "protected" : false,
      "id_str" : "21135674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1777379809\/391870_10100894712944981_10004982_63155096_635581352_n_normal.jpg",
      "id" : 21135674,
      "verified" : false
    }
  },
  "id" : 292693081076158465,
  "created_at" : "2013-01-19 18:00:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292690230002204672",
  "text" : "How do you throw away a garage can?",
  "id" : 292690230002204672,
  "created_at" : "2013-01-19 17:49:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292690028583325696",
  "text" : "How much do you tip professional movers?",
  "id" : 292690028583325696,
  "created_at" : "2013-01-19 17:48:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292684493867855873",
  "geo" : { },
  "id_str" : "292686225242992640",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim Thank you! Keeping the love loft happy and warm means a lot to us!",
  "id" : 292686225242992640,
  "in_reply_to_status_id" : 292684493867855873,
  "created_at" : "2013-01-19 17:33:28 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 0, 13 ],
      "id_str" : "1784841",
      "id" : 1784841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292684690173878272",
  "geo" : { },
  "id_str" : "292685275749044225",
  "in_reply_to_user_id" : 1784841,
  "text" : "@sawickipedia Thanks! ;)",
  "id" : 292685275749044225,
  "in_reply_to_status_id" : 292684690173878272,
  "created_at" : "2013-01-19 17:29:42 +0000",
  "in_reply_to_screen_name" : "sawickipedia",
  "in_reply_to_user_id_str" : "1784841",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292681042060517377",
  "geo" : { },
  "id_str" : "292683279893659649",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward I definitely will! Let me know when you're in SF! Thanks for helping build the McLeod mirror back in the day. :)",
  "id" : 292683279893659649,
  "in_reply_to_status_id" : 292681042060517377,
  "created_at" : "2013-01-19 17:21:46 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292678878995050497",
  "geo" : { },
  "id_str" : "292679737703297024",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall Oh yes. I loved that article!",
  "id" : 292679737703297024,
  "in_reply_to_status_id" : 292678878995050497,
  "created_at" : "2013-01-19 17:07:41 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "needcoffee",
      "indices" : [ 107, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292678954974846978",
  "text" : "Moving day 2 of 4 goals: load the truck, clean the apt, turn over keys, get in car, make it to Portlandia. #needcoffee",
  "id" : 292678954974846978,
  "created_at" : "2013-01-19 17:04:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/7FjCDsYd",
      "expanded_url" : "http:\/\/instagr.am\/p\/Up-yljI0B2\/",
      "display_url" : "instagr.am\/p\/Up-yljI0B2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "292525411592708097",
  "text" : "Our awesome hosts, neighbors, and friends http:\/\/t.co\/7FjCDsYd",
  "id" : 292525411592708097,
  "created_at" : "2013-01-19 06:54:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292438273530421248",
  "geo" : { },
  "id_str" : "292454240968916992",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Two votes for that. I'll check it out!",
  "id" : 292454240968916992,
  "in_reply_to_status_id" : 292438273530421248,
  "created_at" : "2013-01-19 02:11:39 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 0, 6 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "alex choi \u2744\uFE0F\u2615\uFE0F",
      "screen_name" : "xc",
      "indices" : [ 7, 10 ],
      "id_str" : "26233",
      "id" : 26233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292444977160654849",
  "geo" : { },
  "id_str" : "292452195775938560",
  "in_reply_to_user_id" : 631823,
  "text" : "@couch @xc Ooh I've started that one before. Will look it up.",
  "id" : 292452195775938560,
  "in_reply_to_status_id" : 292444977160654849,
  "created_at" : "2013-01-19 02:03:31 +0000",
  "in_reply_to_screen_name" : "couch",
  "in_reply_to_user_id_str" : "631823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alex choi \u2744\uFE0F\u2615\uFE0F",
      "screen_name" : "xc",
      "indices" : [ 0, 3 ],
      "id_str" : "26233",
      "id" : 26233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292435811914366978",
  "geo" : { },
  "id_str" : "292452032332308481",
  "in_reply_to_user_id" : 26233,
  "text" : "@xc That sounds right up my alley. Thanks!",
  "id" : 292452032332308481,
  "in_reply_to_status_id" : 292435811914366978,
  "created_at" : "2013-01-19 02:02:52 +0000",
  "in_reply_to_screen_name" : "xc",
  "in_reply_to_user_id_str" : "26233",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alex choi \u2744\uFE0F\u2615\uFE0F",
      "screen_name" : "xc",
      "indices" : [ 0, 3 ],
      "id_str" : "26233",
      "id" : 26233
    }, {
      "name" : "Ellen Forney",
      "screen_name" : "ellen_forney",
      "indices" : [ 63, 76 ],
      "id_str" : "804968418",
      "id" : 804968418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292434184880934912",
  "geo" : { },
  "id_str" : "292434790907523073",
  "in_reply_to_user_id" : 26233,
  "text" : "@xc Haven't read anything in a long time. Just read Marbles by @ellen_forney and want more!",
  "id" : 292434790907523073,
  "in_reply_to_status_id" : 292434184880934912,
  "created_at" : "2013-01-19 00:54:21 +0000",
  "in_reply_to_screen_name" : "xc",
  "in_reply_to_user_id_str" : "26233",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    }, {
      "name" : "Ellen Forney",
      "screen_name" : "ellen_forney",
      "indices" : [ 87, 100 ],
      "id_str" : "804968418",
      "id" : 804968418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292434239457222656",
  "geo" : { },
  "id_str" : "292434449952546816",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Already read it and loved it! Aka the inspiration for my new search. \/cc @ellen_forney",
  "id" : 292434449952546816,
  "in_reply_to_status_id" : 292434239457222656,
  "created_at" : "2013-01-19 00:53:00 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292433999312334849",
  "text" : "What's the best graphic novel for a road trip?",
  "id" : 292433999312334849,
  "created_at" : "2013-01-19 00:51:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292423071258775552",
  "geo" : { },
  "id_str" : "292423463979851776",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall I can't believe we only have 50% more stuff than you!",
  "id" : 292423463979851776,
  "in_reply_to_status_id" : 292423071258775552,
  "created_at" : "2013-01-19 00:09:21 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292404181501894657",
  "text" : "Moving day 1 of 4: all of our belongings fit in 99 boxes, and they left one for random things that turn up before tomorrow.",
  "id" : 292404181501894657,
  "created_at" : "2013-01-18 22:52:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292393513205772288",
  "text" : "What's the least slimy sleazy scummy way to get a copy of my credit report these days?",
  "id" : 292393513205772288,
  "created_at" : "2013-01-18 22:10:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292334342829649922",
  "geo" : { },
  "id_str" : "292338302932099072",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger If you don't hear back soon, I can help when I'm back on the work network. (moving day)",
  "id" : 292338302932099072,
  "in_reply_to_status_id" : 292334342829649922,
  "created_at" : "2013-01-18 18:30:57 +0000",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UpGoerFive",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/dESouUTx",
      "expanded_url" : "http:\/\/splasho.com\/blog\/2013\/01\/17\/a-bit-more-about-the-up-goer-five-text-editor\/",
      "display_url" : "splasho.com\/blog\/2013\/01\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292337625627504641",
  "text" : "Really interesting! Can you explain a big idea using only the ten hundred most often used words? #UpGoerFive http:\/\/t.co\/dESouUTx",
  "id" : 292337625627504641,
  "created_at" : "2013-01-18 18:28:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Loving",
      "screen_name" : "AdamLoving2much",
      "indices" : [ 0, 16 ],
      "id_str" : "293078930",
      "id" : 293078930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292332723513741312",
  "geo" : { },
  "id_str" : "292333317418778625",
  "in_reply_to_user_id" : 293078930,
  "text" : "@AdamLoving2much Nice, you have access to the FuelBand API?",
  "id" : 292333317418778625,
  "in_reply_to_status_id" : 292332723513741312,
  "created_at" : "2013-01-18 18:11:08 +0000",
  "in_reply_to_screen_name" : "AdamLoving2much",
  "in_reply_to_user_id_str" : "293078930",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Telegraph Obituaries",
      "screen_name" : "telegraphobits",
      "indices" : [ 16, 31 ],
      "id_str" : "32712796",
      "id" : 32712796
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mementomori",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/FHrDYUDM",
      "expanded_url" : "http:\/\/tgr.ph\/WnGmdq",
      "display_url" : "tgr.ph\/WnGmdq"
    } ]
  },
  "in_reply_to_status_id_str" : "292331908094902273",
  "geo" : { },
  "id_str" : "292332939763675136",
  "in_reply_to_user_id" : 32712796,
  "text" : "#mementomori RT @telegraphobits: Obit: Gussie Moran: Tennis player whose outfit was condemned for 'vulgarity and sin' http:\/\/t.co\/FHrDYUDM",
  "id" : 292332939763675136,
  "in_reply_to_status_id" : 292331908094902273,
  "created_at" : "2013-01-18 18:09:38 +0000",
  "in_reply_to_screen_name" : "telegraphobits",
  "in_reply_to_user_id_str" : "32712796",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alex choi \u2744\uFE0F\u2615\uFE0F",
      "screen_name" : "xc",
      "indices" : [ 3, 6 ],
      "id_str" : "26233",
      "id" : 26233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292331553181298689",
  "text" : "RT @xc: The best thing about confirmation bias, is that once you learn about it, you see it everywhere.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "292324435963289601",
    "text" : "The best thing about confirmation bias, is that once you learn about it, you see it everywhere.",
    "id" : 292324435963289601,
    "created_at" : "2013-01-18 17:35:51 +0000",
    "user" : {
      "name" : "alex choi \u2744\uFE0F\u2615\uFE0F",
      "screen_name" : "xc",
      "protected" : false,
      "id_str" : "26233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456660919326486529\/yn8lVuId_normal.png",
      "id" : 26233,
      "verified" : false
    }
  },
  "id" : 292331553181298689,
  "created_at" : "2013-01-18 18:04:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/1JxC0wnR",
      "expanded_url" : "http:\/\/splasho.nfshost.com\/upgoer5",
      "display_url" : "splasho.nfshost.com\/upgoer5"
    } ]
  },
  "geo" : { },
  "id_str" : "292316548142624768",
  "text" : "RT @jasonfried: How well can you describe something using only the 1000 most common English words? http:\/\/t.co\/1JxC0wnR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/1JxC0wnR",
        "expanded_url" : "http:\/\/splasho.nfshost.com\/upgoer5",
        "display_url" : "splasho.nfshost.com\/upgoer5"
      } ]
    },
    "geo" : { },
    "id_str" : "292307260984672257",
    "text" : "How well can you describe something using only the 1000 most common English words? http:\/\/t.co\/1JxC0wnR",
    "id" : 292307260984672257,
    "created_at" : "2013-01-18 16:27:36 +0000",
    "user" : {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "protected" : false,
      "id_str" : "14372143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3413742921\/0e9ef95e76c4a965b9b177fa2267d6c1_normal.png",
      "id" : 14372143,
      "verified" : true
    }
  },
  "id" : 292316548142624768,
  "created_at" : "2013-01-18 17:04:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292301265793339393",
  "text" : "Moving day 1 of 4: in which our belongings find themselves having been boxed.",
  "id" : 292301265793339393,
  "created_at" : "2013-01-18 16:03:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/jpuE0MEi",
      "expanded_url" : "http:\/\/instagr.am\/p\/UnQDBDo0HC\/",
      "display_url" : "instagr.am\/p\/UnQDBDo0HC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "292140792053641216",
  "text" : "8:36pm Niko's getting better at taking pictures. He took all of these on purpose. http:\/\/t.co\/jpuE0MEi",
  "id" : 292140792053641216,
  "created_at" : "2013-01-18 05:26:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 40, 43 ],
      "id_str" : "22273667",
      "id" : 22273667
    }, {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 55, 59 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/Oskfeq9a",
      "expanded_url" : "http:\/\/on.wsj.com\/13JcOvy",
      "display_url" : "on.wsj.com\/13JcOvy"
    } ]
  },
  "in_reply_to_status_id_str" : "292083589150023680",
  "geo" : { },
  "id_str" : "292099762797301760",
  "in_reply_to_user_id" : 22273667,
  "text" : "90 million monthly actives. Not bad! RT @sm: Wowzers. \u201C@WSJ: How many users does Instagram really have? Now we know: http:\/\/t.co\/Oskfeq9a\"",
  "id" : 292099762797301760,
  "in_reply_to_status_id" : 292083589150023680,
  "created_at" : "2013-01-18 02:43:05 +0000",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/LPiZpOVM",
      "expanded_url" : "http:\/\/www.theawl.com\/2013\/01\/take-a-minute-to-watch-the-new-way-we-make-web-headlines-now",
      "display_url" : "theawl.com\/2013\/01\/take-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291980041909305345",
  "text" : "The result of optimizing headlines for clicks: http:\/\/t.co\/LPiZpOVM",
  "id" : 291980041909305345,
  "created_at" : "2013-01-17 18:47:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/y38l1GWs",
      "expanded_url" : "http:\/\/instagr.am\/p\/Uk_zBqo0B3\/",
      "display_url" : "instagr.am\/p\/Uk_zBqo0B3\/"
    } ]
  },
  "geo" : { },
  "id_str" : "291823494939955200",
  "text" : "Kerri oki http:\/\/t.co\/y38l1GWs",
  "id" : 291823494939955200,
  "created_at" : "2013-01-17 08:25:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/VMgMXvsc",
      "expanded_url" : "http:\/\/instagr.am\/p\/Uk3hdsI0Oq\/",
      "display_url" : "instagr.am\/p\/Uk3hdsI0Oq\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6154791264, -122.320146561 ]
  },
  "id_str" : "291805334408945665",
  "text" : "Taking pictures of my friends II @ Rock Box http:\/\/t.co\/VMgMXvsc",
  "id" : 291805334408945665,
  "created_at" : "2013-01-17 07:13:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/uaDSMSMU",
      "expanded_url" : "http:\/\/instagr.am\/p\/Uk3NOGo0Ob\/",
      "display_url" : "instagr.am\/p\/Uk3NOGo0Ob\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6154791264, -122.320146561 ]
  },
  "id_str" : "291804616641892352",
  "text" : "Taking pictures of my friends @ Rock Box http:\/\/t.co\/uaDSMSMU",
  "id" : 291804616641892352,
  "created_at" : "2013-01-17 07:10:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/Gly6XhMG",
      "expanded_url" : "http:\/\/flic.kr\/p\/dMcVpk",
      "display_url" : "flic.kr\/p\/dMcVpk"
    } ]
  },
  "geo" : { },
  "id_str" : "291767389857644544",
  "text" : "8:36pm Friends! http:\/\/t.co\/Gly6XhMG",
  "id" : 291767389857644544,
  "created_at" : "2013-01-17 04:42:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/kCDa8Qyg",
      "expanded_url" : "http:\/\/instagr.am\/p\/UkgR90o0Nf\/",
      "display_url" : "instagr.am\/p\/UkgR90o0Nf\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6140516553, -122.322603904 ]
  },
  "id_str" : "291754207864844289",
  "text" : "Cake with a map! @ Saint John's Bar &amp; Eatery http:\/\/t.co\/kCDa8Qyg",
  "id" : 291754207864844289,
  "created_at" : "2013-01-17 03:49:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 63, 73 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/PRfGEZI5",
      "expanded_url" : "http:\/\/4sq.com\/V92LzD",
      "display_url" : "4sq.com\/V92LzD"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6140516553, -122.3226039044 ]
  },
  "id_str" : "291752875946811392",
  "text" : "Our goodbye Seattle party! (@ Saint John's Bar &amp; Eatery w\/ @the_april) http:\/\/t.co\/PRfGEZI5",
  "id" : 291752875946811392,
  "created_at" : "2013-01-17 03:44:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Phillips",
      "screen_name" : "lisaphillips",
      "indices" : [ 0, 13 ],
      "id_str" : "733383",
      "id" : 733383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291739452336918529",
  "geo" : { },
  "id_str" : "291739705815482369",
  "in_reply_to_user_id" : 733383,
  "text" : "@lisaphillips Tweetbot has implemented it quite perfectly. I sometimes switch over to it in times of great sportiness.",
  "id" : 291739705815482369,
  "in_reply_to_status_id" : 291739452336918529,
  "created_at" : "2013-01-17 02:52:20 +0000",
  "in_reply_to_screen_name" : "lisaphillips",
  "in_reply_to_user_id_str" : "733383",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephanie",
      "screen_name" : "stephaniekaloi",
      "indices" : [ 0, 15 ],
      "id_str" : "158484689",
      "id" : 158484689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291734440412057600",
  "geo" : { },
  "id_str" : "291736616588955649",
  "in_reply_to_user_id" : 158484689,
  "text" : "@stephaniekaloi We will! Awesome!",
  "id" : 291736616588955649,
  "in_reply_to_status_id" : 291734440412057600,
  "created_at" : "2013-01-17 02:40:04 +0000",
  "in_reply_to_screen_name" : "stephaniekaloi",
  "in_reply_to_user_id_str" : "158484689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephanie",
      "screen_name" : "stephaniekaloi",
      "indices" : [ 0, 15 ],
      "id_str" : "158484689",
      "id" : 158484689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291731610074771457",
  "geo" : { },
  "id_str" : "291732177987719168",
  "in_reply_to_user_id" : 158484689,
  "text" : "@stephaniekaloi Yes, Sat eve! Not sure on exact times yet though since we have to clean \/ do walk-thru. Would be awesome to see y'all.",
  "id" : 291732177987719168,
  "in_reply_to_status_id" : 291731610074771457,
  "created_at" : "2013-01-17 02:22:26 +0000",
  "in_reply_to_screen_name" : "stephaniekaloi",
  "in_reply_to_user_id_str" : "158484689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Phillips",
      "screen_name" : "lisaphillips",
      "indices" : [ 0, 13 ],
      "id_str" : "733383",
      "id" : 733383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291719239461634048",
  "geo" : { },
  "id_str" : "291731144796434432",
  "in_reply_to_user_id" : 733383,
  "text" : "@lisaphillips AKA keyword mute?",
  "id" : 291731144796434432,
  "in_reply_to_status_id" : 291719239461634048,
  "created_at" : "2013-01-17 02:18:19 +0000",
  "in_reply_to_screen_name" : "lisaphillips",
  "in_reply_to_user_id_str" : "733383",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "St. John's ",
      "screen_name" : "StJohnsSeattle",
      "indices" : [ 28, 43 ],
      "id_str" : "455269485",
      "id" : 455269485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291729850769752065",
  "text" : "Friends in Seattle! Come to @StJohnsSeattle tonight between 7:30-11:30 to say bye to us before we leave this Saturday for SF!",
  "id" : 291729850769752065,
  "created_at" : "2013-01-17 02:13:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lensmob",
      "screen_name" : "lensmob_it",
      "indices" : [ 0, 11 ],
      "id_str" : "1009589660",
      "id" : 1009589660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291702919194095616",
  "geo" : { },
  "id_str" : "291704725487878145",
  "in_reply_to_user_id" : 1009589660,
  "text" : "@lensmob_it Yeah! How do I sign up?",
  "id" : 291704725487878145,
  "in_reply_to_status_id" : 291702919194095616,
  "created_at" : "2013-01-17 00:33:20 +0000",
  "in_reply_to_screen_name" : "lensmob_it",
  "in_reply_to_user_id_str" : "1009589660",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline wolven",
      "screen_name" : "jackiewolven",
      "indices" : [ 0, 13 ],
      "id_str" : "7413172",
      "id" : 7413172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291697192400465920",
  "geo" : { },
  "id_str" : "291699113173606400",
  "in_reply_to_user_id" : 7413172,
  "text" : "@jackiewolven Is there a way to set a Flickr group email address that works even for people who don't have Flickr accounts?",
  "id" : 291699113173606400,
  "in_reply_to_status_id" : 291697192400465920,
  "created_at" : "2013-01-17 00:11:02 +0000",
  "in_reply_to_screen_name" : "jackiewolven",
  "in_reply_to_user_id_str" : "7413172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brenden Mulligan",
      "screen_name" : "mulligan",
      "indices" : [ 0, 9 ],
      "id_str" : "14323985",
      "id" : 14323985
    }, {
      "name" : "Helena Price",
      "screen_name" : "helena",
      "indices" : [ 10, 17 ],
      "id_str" : "19699682",
      "id" : 19699682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291679586876534785",
  "geo" : { },
  "id_str" : "291679824831979521",
  "in_reply_to_user_id" : 14323985,
  "text" : "@mulligan @helena Before 7:30 PST perchance?",
  "id" : 291679824831979521,
  "in_reply_to_status_id" : 291679586876534785,
  "created_at" : "2013-01-16 22:54:24 +0000",
  "in_reply_to_screen_name" : "mulligan",
  "in_reply_to_user_id_str" : "14323985",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291678461460893696",
  "geo" : { },
  "id_str" : "291679158986215424",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Even I don't know how those work. How do they work?",
  "id" : 291679158986215424,
  "in_reply_to_status_id" : 291678461460893696,
  "created_at" : "2013-01-16 22:51:45 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291678083487002624",
  "text" : "Is there a simple, beautiful, easy to use service that lets a group of people email pictures to a group album in the year of our lord 2013?",
  "id" : 291678083487002624,
  "created_at" : "2013-01-16 22:47:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Taggert",
      "screen_name" : "jtag",
      "indices" : [ 0, 5 ],
      "id_str" : "17912169",
      "id" : 17912169
    }, {
      "name" : "Joe Goldberg",
      "screen_name" : "bostonsteamer",
      "indices" : [ 123, 137 ],
      "id_str" : "2029651",
      "id" : 2029651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291612751267246080",
  "geo" : { },
  "id_str" : "291617759752749056",
  "in_reply_to_user_id" : 2029651,
  "text" : "@jtag Ooh, can I see your research? What form did it take? Also, how will publicizing the research change the results? \/cc @bostonsteamer",
  "id" : 291617759752749056,
  "in_reply_to_status_id" : 291612751267246080,
  "created_at" : "2013-01-16 18:47:46 +0000",
  "in_reply_to_screen_name" : "bostonsteamer",
  "in_reply_to_user_id_str" : "2029651",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Wallin",
      "screen_name" : "joewallin",
      "indices" : [ 3, 13 ],
      "id_str" : "14857106",
      "id" : 14857106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/5rbNQjyT",
      "expanded_url" : "http:\/\/erratasec.blogspot.com\/2013\/01\/i-conceal-my-identity-same-way-aaron.html",
      "display_url" : "erratasec.blogspot.com\/2013\/01\/i-conc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291598236031021056",
  "text" : "RT @joewallin: Great piece: I conceal my identity the same way Aaron was indicted for; \"People fear magic they don't understand...\" http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/hackernode\/id473882597?mt=8&uo=4\" rel=\"nofollow\"\u003EHackerNode on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/5rbNQjyT",
        "expanded_url" : "http:\/\/erratasec.blogspot.com\/2013\/01\/i-conceal-my-identity-same-way-aaron.html",
        "display_url" : "erratasec.blogspot.com\/2013\/01\/i-conc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "291595377818353666",
    "text" : "Great piece: I conceal my identity the same way Aaron was indicted for; \"People fear magic they don't understand...\" http:\/\/t.co\/5rbNQjyT",
    "id" : 291595377818353666,
    "created_at" : "2013-01-16 17:18:50 +0000",
    "user" : {
      "name" : "Joe Wallin",
      "screen_name" : "joewallin",
      "protected" : false,
      "id_str" : "14857106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1455439273\/JoeWallin_blogphoto_72_normal.jpg",
      "id" : 14857106,
      "verified" : false
    }
  },
  "id" : 291598236031021056,
  "created_at" : "2013-01-16 17:30:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291432286300291072",
  "geo" : { },
  "id_str" : "291434103050477568",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries That would be awesome. Not sure why but they are fun to invent.",
  "id" : 291434103050477568,
  "in_reply_to_status_id" : 291432286300291072,
  "created_at" : "2013-01-16 06:37:59 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hired",
      "indices" : [ 58, 64 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291430674324389888",
  "geo" : { },
  "id_str" : "291431697503891456",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries best answer because you showed your work. #hired",
  "id" : 291431697503891456,
  "in_reply_to_status_id" : 291430674324389888,
  "created_at" : "2013-01-16 06:28:25 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 3, 18 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 20, 27 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291431597239070721",
  "text" : "RT @mikeindustries: @buster #2. #1 &amp; #5 get the most usage, and when both are in use, #3 is the next choice, leaving #2 &amp; #4. #4 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "291429504302338048",
    "geo" : { },
    "id_str" : "291430674324389888",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster #2. #1 &amp; #5 get the most usage, and when both are in use, #3 is the next choice, leaving #2 &amp; #4. #4 is more private. Therefore #2.",
    "id" : 291430674324389888,
    "in_reply_to_status_id" : 291429504302338048,
    "created_at" : "2013-01-16 06:24:21 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "protected" : false,
      "id_str" : "74523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430955581830995968\/sSqK3_b9_normal.jpeg",
      "id" : 74523,
      "verified" : false
    }
  },
  "id" : 291431597239070721,
  "created_at" : "2013-01-16 06:28:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephanie",
      "screen_name" : "stephaniekaloi",
      "indices" : [ 0, 15 ],
      "id_str" : "158484689",
      "id" : 158484689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291430206743392257",
  "geo" : { },
  "id_str" : "291431406578565121",
  "in_reply_to_user_id" : 158484689,
  "text" : "@stephaniekaloi I wonder if the answer has now shifted due to the Oprah-effect?",
  "id" : 291431406578565121,
  "in_reply_to_status_id" : 291430206743392257,
  "created_at" : "2013-01-16 06:27:16 +0000",
  "in_reply_to_screen_name" : "stephaniekaloi",
  "in_reply_to_user_id_str" : "158484689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lifeinterviewquestions",
      "indices" : [ 109, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291429504302338048",
  "text" : "In a line of five bathroom stalls at an airport restroom, which one is least likely to have pee on the seat? #lifeinterviewquestions",
  "id" : 291429504302338048,
  "created_at" : "2013-01-16 06:19:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farhad Manjoo",
      "screen_name" : "fmanjoo",
      "indices" : [ 3, 11 ],
      "id_str" : "2195241",
      "id" : 2195241
    }, {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 97, 103 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/y3ZnaTVh",
      "expanded_url" : "http:\/\/fm4.fm\/13Bvk8Y",
      "display_url" : "fm4.fm\/13Bvk8Y"
    } ]
  },
  "geo" : { },
  "id_str" : "291425504819572736",
  "text" : "RT @fmanjoo: Facebook Finally Made Itself Useful. (One Problem: Search results aren't great.) Me @Slate. http:\/\/t.co\/y3ZnaTVh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Slate",
        "screen_name" : "Slate",
        "indices" : [ 84, 90 ],
        "id_str" : "15164565",
        "id" : 15164565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/y3ZnaTVh",
        "expanded_url" : "http:\/\/fm4.fm\/13Bvk8Y",
        "display_url" : "fm4.fm\/13Bvk8Y"
      } ]
    },
    "geo" : { },
    "id_str" : "291397930710089728",
    "text" : "Facebook Finally Made Itself Useful. (One Problem: Search results aren't great.) Me @Slate. http:\/\/t.co\/y3ZnaTVh",
    "id" : 291397930710089728,
    "created_at" : "2013-01-16 04:14:15 +0000",
    "user" : {
      "name" : "Farhad Manjoo",
      "screen_name" : "fmanjoo",
      "protected" : false,
      "id_str" : "2195241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/424235863250173952\/0xeLHVmD_normal.jpeg",
      "id" : 2195241,
      "verified" : true
    }
  },
  "id" : 291425504819572736,
  "created_at" : "2013-01-16 06:03:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lessig",
      "screen_name" : "lessig",
      "indices" : [ 3, 10 ],
      "id_str" : "11388132",
      "id" : 11388132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/yFiZCN0Q",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/technology\/comments\/16njr9\/im_rep_zoe_lofgren_im_introducing_aarons_law_to\/c7xmx6j",
      "display_url" : "reddit.com\/r\/technology\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291422347653705729",
  "text" : "RT @lessig: Zoe Lofgren just introduced \"Aaron's Law\" on Reddit. Let's get this done: http:\/\/t.co\/yFiZCN0Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/yFiZCN0Q",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/technology\/comments\/16njr9\/im_rep_zoe_lofgren_im_introducing_aarons_law_to\/c7xmx6j",
        "display_url" : "reddit.com\/r\/technology\/c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "291355872041508864",
    "text" : "Zoe Lofgren just introduced \"Aaron's Law\" on Reddit. Let's get this done: http:\/\/t.co\/yFiZCN0Q",
    "id" : 291355872041508864,
    "created_at" : "2013-01-16 01:27:07 +0000",
    "user" : {
      "name" : "Lessig",
      "screen_name" : "lessig",
      "protected" : false,
      "id_str" : "11388132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2822485013\/e54012b6296106112b44465776d13d3c_normal.jpeg",
      "id" : 11388132,
      "verified" : true
    }
  },
  "id" : 291422347653705729,
  "created_at" : "2013-01-16 05:51:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "indices" : [ 0, 5 ],
      "id_str" : "10221",
      "id" : 10221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291408691624820736",
  "geo" : { },
  "id_str" : "291409115983527936",
  "in_reply_to_user_id" : 10221,
  "text" : "@drew So jealous.",
  "id" : 291409115983527936,
  "in_reply_to_status_id" : 291408691624820736,
  "created_at" : "2013-01-16 04:58:42 +0000",
  "in_reply_to_screen_name" : "drew",
  "in_reply_to_user_id_str" : "10221",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291404806994657280",
  "geo" : { },
  "id_str" : "291405435100069888",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell I think my daily commute from East Bay (where we'll probably live) should make up for any lost time. The hotel was 1 block away.",
  "id" : 291405435100069888,
  "in_reply_to_status_id" : 291404806994657280,
  "created_at" : "2013-01-16 04:44:04 +0000",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yay",
      "indices" : [ 34, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/IqWiPmqG",
      "expanded_url" : "http:\/\/4sq.com\/UquoAz",
      "display_url" : "4sq.com\/UquoAz"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6141974205, -122.3849058151 ]
  },
  "id_str" : "291391691422838785",
  "text" : "Last plane ride from work to home #yay (@ SFO Terminal 1) http:\/\/t.co\/IqWiPmqG",
  "id" : 291391691422838785,
  "created_at" : "2013-01-16 03:49:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hunter Walk",
      "screen_name" : "hunterwalk",
      "indices" : [ 0, 11 ],
      "id_str" : "46063",
      "id" : 46063
    }, {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 73, 79 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291379996948328448",
  "geo" : { },
  "id_str" : "291389653569904640",
  "in_reply_to_user_id" : 46063,
  "text" : "@hunterwalk It won't, because apparently no API is currently planned \/cc @ifttt",
  "id" : 291389653569904640,
  "in_reply_to_status_id" : 291379996948328448,
  "created_at" : "2013-01-16 03:41:21 +0000",
  "in_reply_to_screen_name" : "hunterwalk",
  "in_reply_to_user_id_str" : "46063",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "olga nunes",
      "screen_name" : "olganunes",
      "indices" : [ 0, 10 ],
      "id_str" : "14079559",
      "id" : 14079559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291386362672852992",
  "geo" : { },
  "id_str" : "291389030543798273",
  "in_reply_to_user_id" : 14079559,
  "text" : "@olganunes I hadn't but the author was interviewed on the podcast I believe. Thanks!",
  "id" : 291389030543798273,
  "in_reply_to_status_id" : 291386362672852992,
  "created_at" : "2013-01-16 03:38:53 +0000",
  "in_reply_to_screen_name" : "olganunes",
  "in_reply_to_user_id_str" : "14079559",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "olga nunes",
      "screen_name" : "olganunes",
      "indices" : [ 42, 52 ],
      "id_str" : "14079559",
      "id" : 14079559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/3vcrrNWt",
      "expanded_url" : "http:\/\/www.zocalopublicsquare.org\/2011\/11\/30\/how-doctors-die\/ideas\/nexus\/",
      "display_url" : "zocalopublicsquare.org\/2011\/11\/30\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291388861244915712",
  "text" : "How Doctors Die http:\/\/t.co\/3vcrrNWt \/via @olganunes",
  "id" : 291388861244915712,
  "created_at" : "2013-01-16 03:38:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 76, 85 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/hDQwcET8",
      "expanded_url" : "http:\/\/bzfd.it\/UOVzmY",
      "display_url" : "bzfd.it\/UOVzmY"
    } ]
  },
  "in_reply_to_status_id_str" : "291377586662162432",
  "geo" : { },
  "id_str" : "291386476162334721",
  "in_reply_to_user_id" : 5695632,
  "text" : "All religions ultimately come down to a competition of flashy buildings. RT @BuzzFeed: Is Scientology Self-Destructing? http:\/\/t.co\/hDQwcET8",
  "id" : 291386476162334721,
  "in_reply_to_status_id" : 291377586662162432,
  "created_at" : "2013-01-16 03:28:44 +0000",
  "in_reply_to_screen_name" : "BuzzFeed",
  "in_reply_to_user_id_str" : "5695632",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 1, 12 ],
      "id_str" : "14934401",
      "id" : 14934401
    }, {
      "name" : "Radiolab",
      "screen_name" : "Radiolab",
      "indices" : [ 26, 35 ],
      "id_str" : "28583197",
      "id" : 28583197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291377799791509504",
  "geo" : { },
  "id_str" : "291378759221776384",
  "in_reply_to_user_id" : 14934401,
  "text" : ".@jreichhold According to @radiolab only 8% of CPR attempts \"work\", and over 60% of those end up in a vegetative state.",
  "id" : 291378759221776384,
  "in_reply_to_status_id" : 291377799791509504,
  "created_at" : "2013-01-16 02:58:04 +0000",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radiolab",
      "screen_name" : "Radiolab",
      "indices" : [ 90, 99 ],
      "id_str" : "28583197",
      "id" : 28583197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/WjNPXWq1",
      "expanded_url" : "http:\/\/www.radiolab.org\/blogs\/radiolab-blog\/2013\/jan\/15\/bitter-end\/",
      "display_url" : "radiolab.org\/blogs\/radiolab\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291376135546224640",
  "text" : "90% of doctors would refuse all resuscitative procedures including CPR. Thought-provoking @Radiolab short: http:\/\/t.co\/WjNPXWq1",
  "id" : 291376135546224640,
  "created_at" : "2013-01-16 02:47:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/iIVduosa",
      "expanded_url" : "http:\/\/polarb.com\/39949",
      "display_url" : "polarb.com\/39949"
    } ]
  },
  "geo" : { },
  "id_str" : "291371330614464513",
  "text" : "If Your Heart Stopped Would You Want CPR? Please vote. http:\/\/t.co\/iIVduosa",
  "id" : 291371330614464513,
  "created_at" : "2013-01-16 02:28:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Goldberg",
      "screen_name" : "bostonsteamer",
      "indices" : [ 0, 14 ],
      "id_str" : "2029651",
      "id" : 2029651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "complaining",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291294190464282624",
  "geo" : { },
  "id_str" : "291294543700185089",
  "in_reply_to_user_id" : 2029651,
  "text" : "@bostonsteamer Yes. Though I think I want to amend the rule to allow purposeful #complaining, since it is not always a bad thing.",
  "id" : 291294543700185089,
  "in_reply_to_status_id" : 291294190464282624,
  "created_at" : "2013-01-15 21:23:25 +0000",
  "in_reply_to_screen_name" : "bostonsteamer",
  "in_reply_to_user_id_str" : "2029651",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Wallin",
      "screen_name" : "joewallin",
      "indices" : [ 3, 13 ],
      "id_str" : "14857106",
      "id" : 14857106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/WPWU1Tfg",
      "expanded_url" : "http:\/\/www.aaronsw.com\/weblog\/epiphany",
      "display_url" : "aaronsw.com\/weblog\/epiphany"
    } ]
  },
  "geo" : { },
  "id_str" : "291293726196768769",
  "text" : "RT @joewallin: \"I reconsidered everyone I knew, everything I thought I\u2019d learned. And I found I didn\u2019t have much company.\" http:\/\/t.co\/W ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/WPWU1Tfg",
        "expanded_url" : "http:\/\/www.aaronsw.com\/weblog\/epiphany",
        "display_url" : "aaronsw.com\/weblog\/epiphany"
      } ]
    },
    "geo" : { },
    "id_str" : "291280431578497024",
    "text" : "\"I reconsidered everyone I knew, everything I thought I\u2019d learned. And I found I didn\u2019t have much company.\" http:\/\/t.co\/WPWU1Tfg",
    "id" : 291280431578497024,
    "created_at" : "2013-01-15 20:27:21 +0000",
    "user" : {
      "name" : "Joe Wallin",
      "screen_name" : "joewallin",
      "protected" : false,
      "id_str" : "14857106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1455439273\/JoeWallin_blogphoto_72_normal.jpg",
      "id" : 14857106,
      "verified" : false
    }
  },
  "id" : 291293726196768769,
  "created_at" : "2013-01-15 21:20:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gav",
      "screen_name" : "ukgav",
      "indices" : [ 0, 6 ],
      "id_str" : "232329387",
      "id" : 232329387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291256668245864448",
  "geo" : { },
  "id_str" : "291257502220300289",
  "in_reply_to_user_id" : 232329387,
  "text" : "@ukgav To their credit, it's a pretty complicated technical problem to solve.",
  "id" : 291257502220300289,
  "in_reply_to_status_id" : 291256668245864448,
  "created_at" : "2013-01-15 18:56:14 +0000",
  "in_reply_to_screen_name" : "ukgav",
  "in_reply_to_user_id_str" : "232329387",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291255857671458816",
  "geo" : { },
  "id_str" : "291256314712190976",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward Yeah, and a V1 that nobody but Facebook could make. I think it's a great direction for them to go.",
  "id" : 291256314712190976,
  "in_reply_to_status_id" : 291255857671458816,
  "created_at" : "2013-01-15 18:51:31 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291254996878622720",
  "text" : "\"Friends who work at Facebook who can give me access to Graph Search\"",
  "id" : 291254996878622720,
  "created_at" : "2013-01-15 18:46:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291252072064643072",
  "text" : "Facebook's Graph Search is more like Siri than Google.",
  "id" : 291252072064643072,
  "created_at" : "2013-01-15 18:34:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garrett Oreilly",
      "screen_name" : "garrett_oreilly",
      "indices" : [ 0, 16 ],
      "id_str" : "15966036",
      "id" : 15966036
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291249899276738560",
  "geo" : { },
  "id_str" : "291250624568381440",
  "in_reply_to_user_id" : 15966036,
  "text" : "@garrett_oreilly Thank you! It's definitely in need of an update.",
  "id" : 291250624568381440,
  "in_reply_to_status_id" : 291249899276738560,
  "created_at" : "2013-01-15 18:28:54 +0000",
  "in_reply_to_screen_name" : "garrett_oreilly",
  "in_reply_to_user_id_str" : "15966036",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291247465364086784",
  "text" : "Facebook's big announcement: Graph Search. Search that returns the answer rather than links that have the answer. Pretty interesting.",
  "id" : 291247465364086784,
  "created_at" : "2013-01-15 18:16:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291242043139821571",
  "geo" : { },
  "id_str" : "291244049485148160",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Congrats on offering the first non-food related in unconflicted thing. PS you are so far from sellout it's silly.",
  "id" : 291244049485148160,
  "in_reply_to_status_id" : 291242043139821571,
  "created_at" : "2013-01-15 18:02:47 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291240783875543042",
  "geo" : { },
  "id_str" : "291241817561772032",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane Thank you! Yeah I need to try it out too. My list is pretty short.",
  "id" : 291241817561772032,
  "in_reply_to_status_id" : 291240783875543042,
  "created_at" : "2013-01-15 17:53:54 +0000",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291238923143872512",
  "text" : "What are some things you aren't conflicted about?",
  "id" : 291238923143872512,
  "created_at" : "2013-01-15 17:42:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 0, 8 ],
      "id_str" : "14097392",
      "id" : 14097392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291232823036227585",
  "geo" : { },
  "id_str" : "291233532880232449",
  "in_reply_to_user_id" : 14097392,
  "text" : "@nireyal Agreed. Especially over days and weeks, months and years.",
  "id" : 291233532880232449,
  "in_reply_to_status_id" : 291232823036227585,
  "created_at" : "2013-01-15 17:20:59 +0000",
  "in_reply_to_screen_name" : "nireyal",
  "in_reply_to_user_id_str" : "14097392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ReadWrite",
      "screen_name" : "RWW",
      "indices" : [ 9, 13 ],
      "id_str" : "4641021",
      "id" : 4641021
    }, {
      "name" : "Adam Popescu",
      "screen_name" : "adampopescu",
      "indices" : [ 79, 91 ],
      "id_str" : "54993188",
      "id" : 54993188
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/yCljtfip",
      "expanded_url" : "http:\/\/rww.to\/11wQ03t",
      "display_url" : "rww.to\/11wQ03t"
    } ]
  },
  "in_reply_to_status_id_str" : "291231777236852736",
  "geo" : { },
  "id_str" : "291233293347725312",
  "in_reply_to_user_id" : 4641021,
  "text" : "Woah. RT @RWW: Why Write Your Own Book When An Algorithm Can Do It For You? by @adampopescu http:\/\/t.co\/yCljtfip",
  "id" : 291233293347725312,
  "in_reply_to_status_id" : 291231777236852736,
  "created_at" : "2013-01-15 17:20:02 +0000",
  "in_reply_to_screen_name" : "RWW",
  "in_reply_to_user_id_str" : "4641021",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zeke Miller",
      "screen_name" : "ZekeJMiller",
      "indices" : [ 3, 15 ],
      "id_str" : "21316253",
      "id" : 21316253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/3HaOlxGH",
      "expanded_url" : "http:\/\/j.mp\/W8Ax3q",
      "display_url" : "j.mp\/W8Ax3q"
    } ]
  },
  "geo" : { },
  "id_str" : "291226037528956929",
  "text" : "RT @ZekeJMiller: The David Brooks humility course syllabus is amazing http:\/\/t.co\/3HaOlxGH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/3HaOlxGH",
        "expanded_url" : "http:\/\/j.mp\/W8Ax3q",
        "display_url" : "j.mp\/W8Ax3q"
      } ]
    },
    "geo" : { },
    "id_str" : "291219883033755648",
    "text" : "The David Brooks humility course syllabus is amazing http:\/\/t.co\/3HaOlxGH",
    "id" : 291219883033755648,
    "created_at" : "2013-01-15 16:26:45 +0000",
    "user" : {
      "name" : "Zeke Miller",
      "screen_name" : "ZekeJMiller",
      "protected" : false,
      "id_str" : "21316253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458702065590476801\/cfLrjhxq_normal.jpeg",
      "id" : 21316253,
      "verified" : true
    }
  },
  "id" : 291226037528956929,
  "created_at" : "2013-01-15 16:51:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 0, 8 ],
      "id_str" : "14097392",
      "id" : 14097392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291189650540867585",
  "geo" : { },
  "id_str" : "291225413508808704",
  "in_reply_to_user_id" : 14097392,
  "text" : "@nireyal That's definitely true for me. I find myself bribing my 2-yo son all the time in a pinch because it works. Looking for better alts.",
  "id" : 291225413508808704,
  "in_reply_to_status_id" : 291189650540867585,
  "created_at" : "2013-01-15 16:48:43 +0000",
  "in_reply_to_screen_name" : "nireyal",
  "in_reply_to_user_id_str" : "14097392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 0, 8 ],
      "id_str" : "14097392",
      "id" : 14097392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291103728537313280",
  "geo" : { },
  "id_str" : "291107189844758528",
  "in_reply_to_user_id" : 14097392,
  "text" : "@nireyal Great question to explore, but the \"solutions\" in here are just bribes in sheep's clothing, aren't they?",
  "id" : 291107189844758528,
  "in_reply_to_status_id" : 291103728537313280,
  "created_at" : "2013-01-15 08:58:57 +0000",
  "in_reply_to_screen_name" : "nireyal",
  "in_reply_to_user_id_str" : "14097392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291045125654724608",
  "geo" : { },
  "id_str" : "291047723841486848",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez Yes please.",
  "id" : 291047723841486848,
  "in_reply_to_status_id" : 291045125654724608,
  "created_at" : "2013-01-15 05:02:39 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "complaining",
      "indices" : [ 10, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291046324181270528",
  "text" : "While I'm #complaining, checking it at hotels takes about 10x too long.",
  "id" : 291046324181270528,
  "created_at" : "2013-01-15 04:57:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan Donohoe",
      "screen_name" : "bdonohoe",
      "indices" : [ 0, 9 ],
      "id_str" : "1193421",
      "id" : 1193421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291044391857053697",
  "in_reply_to_user_id" : 1193421,
  "text" : "@bdonohoe You have an Instagram doppelg\u00E4nger in Australia.",
  "id" : 291044391857053697,
  "created_at" : "2013-01-15 04:49:25 +0000",
  "in_reply_to_screen_name" : "bdonohoe",
  "in_reply_to_user_id_str" : "1193421",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291043597216804866",
  "text" : "Instagram's @-username linking logic continually fails to work as expected.",
  "id" : 291043597216804866,
  "created_at" : "2013-01-15 04:46:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/leLUg8OS",
      "expanded_url" : "http:\/\/instagr.am\/p\/UfcvkhI0PI\/",
      "display_url" : "instagr.am\/p\/UfcvkhI0PI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "291042891797770241",
  "text" : "8:36pm Walking to hotel after great conversations with bdonohoe and also pizza http:\/\/t.co\/leLUg8OS",
  "id" : 291042891797770241,
  "created_at" : "2013-01-15 04:43:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 3, 15 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/DoGghXzR",
      "expanded_url" : "https:\/\/www.makesets.com\/",
      "display_url" : "makesets.com"
    } ]
  },
  "geo" : { },
  "id_str" : "291030860579344384",
  "text" : "RT @kylebragger: Sets is already doing thousands of pageviews and clicks a day. Crazy. (You should sign up! Great stuff coming: https:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 132 ],
        "url" : "https:\/\/t.co\/DoGghXzR",
        "expanded_url" : "https:\/\/www.makesets.com\/",
        "display_url" : "makesets.com"
      } ]
    },
    "geo" : { },
    "id_str" : "291029396289122304",
    "text" : "Sets is already doing thousands of pageviews and clicks a day. Crazy. (You should sign up! Great stuff coming: https:\/\/t.co\/DoGghXzR)",
    "id" : 291029396289122304,
    "created_at" : "2013-01-15 03:49:49 +0000",
    "user" : {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "protected" : false,
      "id_str" : "2039761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453981850709417984\/PBuLBNty_normal.jpeg",
      "id" : 2039761,
      "verified" : false
    }
  },
  "id" : 291030860579344384,
  "created_at" : "2013-01-15 03:55:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 126 ],
      "url" : "https:\/\/t.co\/ZqYIU1sH",
      "expanded_url" : "https:\/\/www.makesets.com\/the-future-is-nigh",
      "display_url" : "makesets.com\/the-future-is-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291030673668587520",
  "text" : "Testing Sets with my set of links about the future. Follow it and let me know if you want to contribute: https:\/\/t.co\/ZqYIU1sH",
  "id" : 291030673668587520,
  "created_at" : "2013-01-15 03:54:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290845934307405825",
  "geo" : { },
  "id_str" : "290875963607244800",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall I'm only here until tomorrow this week, but let's schedule something once the Kellianne and Niko arrive next week!",
  "id" : 290875963607244800,
  "in_reply_to_status_id" : 290845934307405825,
  "created_at" : "2013-01-14 17:40:08 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pentametron",
      "screen_name" : "pentametron",
      "indices" : [ 13, 25 ],
      "id_str" : "516047986",
      "id" : 516047986
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/DBIQ8gdd",
      "expanded_url" : "http:\/\/techcrunch.com\/2013\/01\/13\/pentametron-is-a-twitter-poet-that-gives-bots-some-literary-cred\/",
      "display_url" : "techcrunch.com\/2013\/01\/13\/pen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290812180281036801",
  "text" : "I love this. @Pentametron finds and retweets couplets of tweets in iambic pentameter that rhyme: http:\/\/t.co\/DBIQ8gdd",
  "id" : 290812180281036801,
  "created_at" : "2013-01-14 13:26:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290798614303879168",
  "text" : "My last regularly scheduled 4am Monday trip to the airport.",
  "id" : 290798614303879168,
  "created_at" : "2013-01-14 12:32:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 0, 9 ],
      "id_str" : "14986129",
      "id" : 14986129
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cynical",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290706978500669440",
  "geo" : { },
  "id_str" : "290718605375590400",
  "in_reply_to_user_id" : 14986129,
  "text" : "@irondavy How successful we're they through the lens of will people click on this article? #cynical",
  "id" : 290718605375590400,
  "in_reply_to_status_id" : 290706978500669440,
  "created_at" : "2013-01-14 07:14:51 +0000",
  "in_reply_to_screen_name" : "irondavy",
  "in_reply_to_user_id_str" : "14986129",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Scheibach",
      "screen_name" : "jshy",
      "indices" : [ 0, 5 ],
      "id_str" : "804659",
      "id" : 804659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290704455660347392",
  "geo" : { },
  "id_str" : "290706117674278912",
  "in_reply_to_user_id" : 804659,
  "text" : "@jshy Congrats! That is awesome and they are lucky to have you!",
  "id" : 290706117674278912,
  "in_reply_to_status_id" : 290704455660347392,
  "created_at" : "2013-01-14 06:25:14 +0000",
  "in_reply_to_screen_name" : "jshy",
  "in_reply_to_user_id_str" : "804659",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Venessa Goldberg",
      "screen_name" : "kernelsandseeds",
      "indices" : [ 41, 57 ],
      "id_str" : "174538822",
      "id" : 174538822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/TM07wIl9",
      "expanded_url" : "http:\/\/instagr.am\/p\/Uc_2kzo0Eu\/",
      "display_url" : "instagr.am\/p\/Uc_2kzo0Eu\/"
    } ]
  },
  "geo" : { },
  "id_str" : "290698306147991554",
  "text" : "8:36pm Delightful kid + adult times with @kernelsandseeds, bostonsteamer, and families. http:\/\/t.co\/TM07wIl9",
  "id" : 290698306147991554,
  "created_at" : "2013-01-14 05:54:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joyce Carol Oates",
      "screen_name" : "JoyceCarolOates",
      "indices" : [ 3, 19 ],
      "id_str" : "845743333",
      "id" : 845743333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290615207418556416",
  "text" : "RT @JoyceCarolOates: Twitter is the mirage that, as you approach, teasingly retreats.   Yet, you approach.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "290611054889795584",
    "text" : "Twitter is the mirage that, as you approach, teasingly retreats.   Yet, you approach.",
    "id" : 290611054889795584,
    "created_at" : "2013-01-14 00:07:29 +0000",
    "user" : {
      "name" : "Joyce Carol Oates",
      "screen_name" : "JoyceCarolOates",
      "protected" : false,
      "id_str" : "845743333",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2683616680\/ca8aa195d2ccc38da6800678a9d2ae8a_normal.png",
      "id" : 845743333,
      "verified" : true
    }
  },
  "id" : 290615207418556416,
  "created_at" : "2013-01-14 00:23:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/IFu9Yumq",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ub9oxbI0Gq\/",
      "display_url" : "instagr.am\/p\/Ub9oxbI0Gq\/"
    } ]
  },
  "geo" : { },
  "id_str" : "290552447154417664",
  "text" : "Goodbye brunch for Niko's friends Viv and Poppy http:\/\/t.co\/IFu9Yumq",
  "id" : 290552447154417664,
  "created_at" : "2013-01-13 20:14:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/SFOS8v5R",
      "expanded_url" : "http:\/\/flic.kr\/p\/dL3Y9H",
      "display_url" : "flic.kr\/p\/dL3Y9H"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.613166, -122.331167 ]
  },
  "id_str" : "290345658337079296",
  "text" : "8:36pm Filing out of Book of Mormon to meet Brett and Lucy and debrief http:\/\/t.co\/SFOS8v5R",
  "id" : 290345658337079296,
  "created_at" : "2013-01-13 06:32:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/6aEoiESj",
      "expanded_url" : "http:\/\/instagr.am\/p\/UaMpXjI0EA\/",
      "display_url" : "instagr.am\/p\/UaMpXjI0EA\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6134540322, -122.331390381 ]
  },
  "id_str" : "290303807169114114",
  "text" : "Book of Mormon! @ Paramount Theatre http:\/\/t.co\/6aEoiESj",
  "id" : 290303807169114114,
  "created_at" : "2013-01-13 03:46:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lar Van Der Jagt",
      "screen_name" : "supaspoida",
      "indices" : [ 0, 11 ],
      "id_str" : "14205289",
      "id" : 14205289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290277503006822400",
  "geo" : { },
  "id_str" : "290298301281103872",
  "in_reply_to_user_id" : 14205289,
  "text" : "@supaspoida Hmm... maybe I am!",
  "id" : 290298301281103872,
  "in_reply_to_status_id" : 290277503006822400,
  "created_at" : "2013-01-13 03:24:43 +0000",
  "in_reply_to_screen_name" : "supaspoida",
  "in_reply_to_user_id_str" : "14205289",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Stamos",
      "screen_name" : "alexstamos",
      "indices" : [ 28, 39 ],
      "id_str" : "41603960",
      "id" : 41603960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/3fTYeITG",
      "expanded_url" : "http:\/\/goo.gl\/khKRL",
      "display_url" : "goo.gl\/khKRL"
    } ]
  },
  "in_reply_to_status_id_str" : "290196050885632000",
  "geo" : { },
  "id_str" : "290244863482548224",
  "in_reply_to_user_id" : 41603960,
  "text" : "This case makes no sense RT @alexstamos: I was Aaron Swartz's expert witness, and here is the truth about his \"crime\". http:\/\/t.co\/3fTYeITG",
  "id" : 290244863482548224,
  "in_reply_to_status_id" : 290196050885632000,
  "created_at" : "2013-01-12 23:52:22 +0000",
  "in_reply_to_screen_name" : "alexstamos",
  "in_reply_to_user_id_str" : "41603960",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290198215196831744",
  "text" : "We should make sure robots are paying very close attention to how we take care of our cats so they'll know how to take care of us post-2040.",
  "id" : 290198215196831744,
  "created_at" : "2013-01-12 20:47:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Swartz",
      "screen_name" : "aaronsw",
      "indices" : [ 10, 18 ],
      "id_str" : "2696831",
      "id" : 2696831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290011899167395841",
  "text" : "Sad about @aaronsw and how alone we are in the universe sometimes.",
  "id" : 290011899167395841,
  "created_at" : "2013-01-12 08:26:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason",
      "screen_name" : "jck5",
      "indices" : [ 0, 5 ],
      "id_str" : "15926335",
      "id" : 15926335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290008296474177536",
  "geo" : { },
  "id_str" : "290008639438196736",
  "in_reply_to_user_id" : 15926335,
  "text" : "@jck5 It needs daily attention\u2026 both technical and support. :\/",
  "id" : 290008639438196736,
  "in_reply_to_status_id" : 290008296474177536,
  "created_at" : "2013-01-12 08:13:42 +0000",
  "in_reply_to_screen_name" : "jck5",
  "in_reply_to_user_id_str" : "15926335",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander",
      "screen_name" : "sllecks",
      "indices" : [ 0, 8 ],
      "id_str" : "2321742044",
      "id" : 2321742044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290007274334867456",
  "geo" : { },
  "id_str" : "290007528882962432",
  "in_reply_to_user_id" : 771313,
  "text" : "@sllecks Awesome! Can you leave a comment on the post so I can collect everything in one place?",
  "id" : 290007528882962432,
  "in_reply_to_status_id" : 290007274334867456,
  "created_at" : "2013-01-12 08:09:17 +0000",
  "in_reply_to_screen_name" : "stllwll",
  "in_reply_to_user_id_str" : "771313",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "justin avery",
      "screen_name" : "justinavery",
      "indices" : [ 0, 12 ],
      "id_str" : "16613918",
      "id" : 16613918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290007004720812032",
  "geo" : { },
  "id_str" : "290007397181829120",
  "in_reply_to_user_id" : 16613918,
  "text" : "@justinavery Cool! Could you leave a comment on the post with any other specifics, so I can collect all feedback in one place?",
  "id" : 290007397181829120,
  "in_reply_to_status_id" : 290007004720812032,
  "created_at" : "2013-01-12 08:08:46 +0000",
  "in_reply_to_screen_name" : "justinavery",
  "in_reply_to_user_id_str" : "16613918",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "longlive750",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/QW8w6pDR",
      "expanded_url" : "http:\/\/750words.tumblr.com\/post\/40322046809\/the-future-of-750-words-please-read-and-reply",
      "display_url" : "750words.tumblr.com\/post\/403220468\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289999899582414848",
  "text" : "The bummer news I alluded to a couple days ago: http:\/\/t.co\/QW8w6pDR #longlive750",
  "id" : 289999899582414848,
  "created_at" : "2013-01-12 07:38:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eric Lin",
      "screen_name" : "ericlin",
      "indices" : [ 0, 8 ],
      "id_str" : "8291",
      "id" : 8291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289988864074973184",
  "geo" : { },
  "id_str" : "289989395698831360",
  "in_reply_to_user_id" : 8291,
  "text" : "@ericlin You win. Loved that short.",
  "id" : 289989395698831360,
  "in_reply_to_status_id" : 289988864074973184,
  "created_at" : "2013-01-12 06:57:14 +0000",
  "in_reply_to_screen_name" : "ericlin",
  "in_reply_to_user_id_str" : "8291",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/gR1xFTUs",
      "expanded_url" : "http:\/\/flic.kr\/p\/dKLsTr",
      "display_url" : "flic.kr\/p\/dKLsTr"
    } ]
  },
  "geo" : { },
  "id_str" : "289978311772344320",
  "text" : "Google, why does? http:\/\/t.co\/gR1xFTUs",
  "id" : 289978311772344320,
  "created_at" : "2013-01-12 06:13:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289976744990085121",
  "text" : "But cloudy, cloudy is the stuff of stones.",
  "id" : 289976744990085121,
  "created_at" : "2013-01-12 06:06:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Gibson",
      "screen_name" : "GreatDismal",
      "indices" : [ 3, 15 ],
      "id_str" : "28049003",
      "id" : 28049003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/yY8V7q1F",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/List_of_inventors_killed_by_their_own_inventions",
      "display_url" : "en.m.wikipedia.org\/wiki\/List_of_i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289963464095563776",
  "text" : "RT @GreatDismal: List of inventors killed by their own inventions\nhttp:\/\/t.co\/yY8V7q1F via Mrs GD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/yY8V7q1F",
        "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/List_of_inventors_killed_by_their_own_inventions",
        "display_url" : "en.m.wikipedia.org\/wiki\/List_of_i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "289963108150177792",
    "text" : "List of inventors killed by their own inventions\nhttp:\/\/t.co\/yY8V7q1F via Mrs GD",
    "id" : 289963108150177792,
    "created_at" : "2013-01-12 05:12:46 +0000",
    "user" : {
      "name" : "William Gibson",
      "screen_name" : "GreatDismal",
      "protected" : false,
      "id_str" : "28049003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000678442069\/f00111192cb14d8e709342a29540b7a0_normal.jpeg",
      "id" : 28049003,
      "verified" : true
    }
  },
  "id" : 289963464095563776,
  "created_at" : "2013-01-12 05:14:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/E0aqCAN6",
      "expanded_url" : "http:\/\/instagr.am\/p\/UXua8Jo0P8\/",
      "display_url" : "instagr.am\/p\/UXua8Jo0P8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "289955793070088194",
  "text" : "8:36pm Niko learning to take pictures http:\/\/t.co\/E0aqCAN6",
  "id" : 289955793070088194,
  "created_at" : "2013-01-12 04:43:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Nation",
      "screen_name" : "thenation",
      "indices" : [ 3, 13 ],
      "id_str" : "1947301",
      "id" : 1947301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/yU1U2lGI",
      "expanded_url" : "http:\/\/tnat.in\/gJw8y",
      "display_url" : "tnat.in\/gJw8y"
    } ]
  },
  "geo" : { },
  "id_str" : "289953589844127744",
  "text" : "RT @thenation: Elizabeth Warren had been a US Senator from Massachusetts for only about a week when she broke with etiquette: http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/yU1U2lGI",
        "expanded_url" : "http:\/\/tnat.in\/gJw8y",
        "display_url" : "tnat.in\/gJw8y"
      } ]
    },
    "geo" : { },
    "id_str" : "289775018915799040",
    "text" : "Elizabeth Warren had been a US Senator from Massachusetts for only about a week when she broke with etiquette: http:\/\/t.co\/yU1U2lGI",
    "id" : 289775018915799040,
    "created_at" : "2013-01-11 16:45:22 +0000",
    "user" : {
      "name" : "The Nation",
      "screen_name" : "thenation",
      "protected" : false,
      "id_str" : "1947301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556400632\/Small_n_normal.png",
      "id" : 1947301,
      "verified" : true
    }
  },
  "id" : 289953589844127744,
  "created_at" : "2013-01-12 04:34:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289945999605125121",
  "text" : "How do you make 3D models that the Makerbot Replicator 2 can print? Is there an online class or something?",
  "id" : 289945999605125121,
  "created_at" : "2013-01-12 04:04:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "indices" : [ 3, 14 ],
      "id_str" : "10876852",
      "id" : 10876852
    }, {
      "name" : "Matthew Panzarino",
      "screen_name" : "panzer",
      "indices" : [ 110, 117 ],
      "id_str" : "19312115",
      "id" : 19312115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/fbrwfCKl",
      "expanded_url" : "http:\/\/tnw.to\/a0Tzk",
      "display_url" : "tnw.to\/a0Tzk"
    } ]
  },
  "geo" : { },
  "id_str" : "289945002019287040",
  "text" : "RT @TheNextWeb: MakerBot's Bre Pettis only wants to start a new industrial revolution http:\/\/t.co\/fbrwfCKl by @panzer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/spread.us\" rel=\"nofollow\"\u003ESpread The Next Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew Panzarino",
        "screen_name" : "panzer",
        "indices" : [ 94, 101 ],
        "id_str" : "19312115",
        "id" : 19312115
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/fbrwfCKl",
        "expanded_url" : "http:\/\/tnw.to\/a0Tzk",
        "display_url" : "tnw.to\/a0Tzk"
      } ]
    },
    "geo" : { },
    "id_str" : "289476728341032962",
    "text" : "MakerBot's Bre Pettis only wants to start a new industrial revolution http:\/\/t.co\/fbrwfCKl by @panzer",
    "id" : 289476728341032962,
    "created_at" : "2013-01-10 21:00:04 +0000",
    "user" : {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "protected" : false,
      "id_str" : "10876852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000147133877\/895fa7d3daeed8d32b7c089d9b3e976e_normal.png",
      "id" : 10876852,
      "verified" : true
    }
  },
  "id" : 289945002019287040,
  "created_at" : "2013-01-12 04:00:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bre Pettis",
      "screen_name" : "bre",
      "indices" : [ 0, 4 ],
      "id_str" : "11900",
      "id" : 11900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608556184, -122.3062144128 ]
  },
  "id_str" : "289941603970338817",
  "in_reply_to_user_id" : 11900,
  "text" : "@bre How long til 3D printers can print themselves?",
  "id" : 289941603970338817,
  "created_at" : "2013-01-12 03:47:19 +0000",
  "in_reply_to_screen_name" : "bre",
  "in_reply_to_user_id_str" : "11900",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 3, 13 ],
      "id_str" : "2854761",
      "id" : 2854761
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 77, 86 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 115, 122 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/XmVEyabW",
      "expanded_url" : "http:\/\/j.mp\/11kMedC",
      "display_url" : "j.mp\/11kMedC"
    }, {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/EhJxo9EA",
      "expanded_url" : "http:\/\/j.mp\/11kMjOr",
      "display_url" : "j.mp\/11kMjOr"
    } ]
  },
  "geo" : { },
  "id_str" : "289776594426413056",
  "text" : "RT @galenward: All Dashboards Should be Feeds. \nYes: http:\/\/t.co\/XmVEyabW by @anildash\nNo: http:\/\/t.co\/EhJxo9EA by @buster",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anil Dash",
        "screen_name" : "anildash",
        "indices" : [ 62, 71 ],
        "id_str" : "36823",
        "id" : 36823
      }, {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 100, 107 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/XmVEyabW",
        "expanded_url" : "http:\/\/j.mp\/11kMedC",
        "display_url" : "j.mp\/11kMedC"
      }, {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/EhJxo9EA",
        "expanded_url" : "http:\/\/j.mp\/11kMjOr",
        "display_url" : "j.mp\/11kMjOr"
      } ]
    },
    "geo" : { },
    "id_str" : "289775758061219841",
    "text" : "All Dashboards Should be Feeds. \nYes: http:\/\/t.co\/XmVEyabW by @anildash\nNo: http:\/\/t.co\/EhJxo9EA by @buster",
    "id" : 289775758061219841,
    "created_at" : "2013-01-11 16:48:19 +0000",
    "user" : {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "protected" : false,
      "id_str" : "2854761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1795457065\/Galen_Ward_-_its_okay_to_have_a_crush_normal.jpg",
      "id" : 2854761,
      "verified" : false
    }
  },
  "id" : 289776594426413056,
  "created_at" : "2013-01-11 16:51:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HannahCurious",
      "screen_name" : "HannahCurious",
      "indices" : [ 0, 14 ],
      "id_str" : "2252898753",
      "id" : 2252898753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289774002996666368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608656222, -122.3061660492 ]
  },
  "id_str" : "289776293459947520",
  "in_reply_to_user_id" : 285401666,
  "text" : "@HannahCurious I still feel the same. What about you?",
  "id" : 289776293459947520,
  "in_reply_to_status_id" : 289774002996666368,
  "created_at" : "2013-01-11 16:50:26 +0000",
  "in_reply_to_screen_name" : "transatlantid",
  "in_reply_to_user_id_str" : "285401666",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/timehop.com\/\" rel=\"nofollow\"\u003ETimehop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/jPDIP5DP",
      "expanded_url" : "http:\/\/t.imehop.com\/Vt112v",
      "display_url" : "t.imehop.com\/Vt112v"
    } ]
  },
  "geo" : { },
  "id_str" : "289773245199171584",
  "text" : "How to change the multiverse http:\/\/t.co\/jPDIP5DP",
  "id" : 289773245199171584,
  "created_at" : "2013-01-11 16:38:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Butcher",
      "screen_name" : "tiz9000",
      "indices" : [ 0, 8 ],
      "id_str" : "93763839",
      "id" : 93763839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289589485212151808",
  "geo" : { },
  "id_str" : "289595670363533312",
  "in_reply_to_user_id" : 93763839,
  "text" : "@tiz9000 I'm speaking strictly in terms of what our old and new brains want, not what our body needs to live longer than a couple days. :)",
  "id" : 289595670363533312,
  "in_reply_to_status_id" : 289589485212151808,
  "created_at" : "2013-01-11 04:52:42 +0000",
  "in_reply_to_screen_name" : "tiz9000",
  "in_reply_to_user_id_str" : "93763839",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caneel Joyce",
      "screen_name" : "caneel",
      "indices" : [ 0, 7 ],
      "id_str" : "11926472",
      "id" : 11926472
    }, {
      "name" : "Jill S.",
      "screen_name" : "outseide",
      "indices" : [ 8, 17 ],
      "id_str" : "143694663",
      "id" : 143694663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289589777408327680",
  "geo" : { },
  "id_str" : "289593752656412672",
  "in_reply_to_user_id" : 11926472,
  "text" : "@caneel @outseide I think he definitely was. And I am as well, I guess.",
  "id" : 289593752656412672,
  "in_reply_to_status_id" : 289589777408327680,
  "created_at" : "2013-01-11 04:45:05 +0000",
  "in_reply_to_screen_name" : "caneel",
  "in_reply_to_user_id_str" : "11926472",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/bQ6kZopp",
      "expanded_url" : "http:\/\/flic.kr\/p\/dKB8dy",
      "display_url" : "flic.kr\/p\/dKB8dy"
    } ]
  },
  "geo" : { },
  "id_str" : "289593458413420547",
  "text" : "8:36pm Tracking down a lost receipt from a hotel stay last month and listening to Lumineers til KA and Niko's... http:\/\/t.co\/bQ6kZopp",
  "id" : 289593458413420547,
  "created_at" : "2013-01-11 04:43:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "McKenna Phillabaum",
      "screen_name" : "mckb0mb",
      "indices" : [ 0, 8 ],
      "id_str" : "268495211",
      "id" : 268495211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289576647789801472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6068036373, -122.3166844261 ]
  },
  "id_str" : "289577496024842240",
  "in_reply_to_user_id" : 268495211,
  "text" : "@mckb0mb Making dietary decisions by popular vote is fun.",
  "id" : 289577496024842240,
  "in_reply_to_status_id" : 289576647789801472,
  "created_at" : "2013-01-11 03:40:29 +0000",
  "in_reply_to_screen_name" : "mckb0mb",
  "in_reply_to_user_id_str" : "268495211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/czeBAFTc",
      "expanded_url" : "http:\/\/polarb.com\/35596",
      "display_url" : "polarb.com\/35596"
    } ]
  },
  "geo" : { },
  "id_str" : "289574091508293632",
  "text" : "Should I Have Another Glass Of Wine? Please vote. http:\/\/t.co\/czeBAFTc",
  "id" : 289574091508293632,
  "created_at" : "2013-01-11 03:26:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notthereyet",
      "indices" : [ 24, 36 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289565068398587904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6071390557, -122.316550892 ]
  },
  "id_str" : "289566121173057536",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne Yeah, maybe? #notthereyet",
  "id" : 289566121173057536,
  "in_reply_to_status_id" : 289565068398587904,
  "created_at" : "2013-01-11 02:55:17 +0000",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omid Ashtari",
      "screen_name" : "omid",
      "indices" : [ 0, 5 ],
      "id_str" : "114971521",
      "id" : 114971521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289559104823889921",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6070695278, -122.3165280932 ]
  },
  "id_str" : "289560502953197569",
  "in_reply_to_user_id" : 114971521,
  "text" : "@omid How so?",
  "id" : 289560502953197569,
  "in_reply_to_status_id" : 289559104823889921,
  "created_at" : "2013-01-11 02:32:58 +0000",
  "in_reply_to_screen_name" : "omid",
  "in_reply_to_user_id_str" : "114971521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill S.",
      "screen_name" : "outseide",
      "indices" : [ 0, 9 ],
      "id_str" : "143694663",
      "id" : 143694663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289559316372021248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6070414065, -122.3165680749 ]
  },
  "id_str" : "289560062056361985",
  "in_reply_to_user_id" : 143694663,
  "text" : "@outseide I edited it a bit. I this connection is clearer about where purpose comes from.",
  "id" : 289560062056361985,
  "in_reply_to_status_id" : 289559316372021248,
  "created_at" : "2013-01-11 02:31:13 +0000",
  "in_reply_to_screen_name" : "outseide",
  "in_reply_to_user_id_str" : "143694663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikhil Roy",
      "screen_name" : "nikhilroy",
      "indices" : [ 0, 10 ],
      "id_str" : "14603971",
      "id" : 14603971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289556769330589696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6070404007, -122.3166547437 ]
  },
  "id_str" : "289559619066540033",
  "in_reply_to_user_id" : 14603971,
  "text" : "@nikhilroy You are right. I misread.",
  "id" : 289559619066540033,
  "in_reply_to_status_id" : 289556769330589696,
  "created_at" : "2013-01-11 02:29:27 +0000",
  "in_reply_to_screen_name" : "nikhilroy",
  "in_reply_to_user_id_str" : "14603971",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289558967322038273",
  "text" : "The game of life. Level 1: sugar, salt, fat. Level 2: sex, drugs, rock &amp; roll. Level 3: autonomy, mastery, connection.",
  "id" : 289558967322038273,
  "created_at" : "2013-01-11 02:26:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 5, 14 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/3A0KpNPa",
      "expanded_url" : "http:\/\/bit.ly\/WGaiQh",
      "display_url" : "bit.ly\/WGaiQh"
    } ]
  },
  "geo" : { },
  "id_str" : "289535901548298240",
  "text" : "Wow, @elonmusk thinks we're only 10 years from colonizing Mars, and that it will be commercially available http:\/\/t.co\/3A0KpNPa",
  "id" : 289535901548298240,
  "created_at" : "2013-01-11 00:55:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Jo Richey",
      "screen_name" : "erinjo",
      "indices" : [ 3, 10 ],
      "id_str" : "14961286",
      "id" : 14961286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/9WSYY9AY",
      "expanded_url" : "http:\/\/erinjo.me\/UNLFam",
      "display_url" : "erinjo.me\/UNLFam"
    } ]
  },
  "geo" : { },
  "id_str" : "289494806160367616",
  "text" : "RT @erinjo: Lifeloggers, QSers: If you missed it earlier, One Second Everyday iOS app is free today ~ http:\/\/t.co\/9WSYY9AY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/9WSYY9AY",
        "expanded_url" : "http:\/\/erinjo.me\/UNLFam",
        "display_url" : "erinjo.me\/UNLFam"
      } ]
    },
    "geo" : { },
    "id_str" : "289493823724322816",
    "text" : "Lifeloggers, QSers: If you missed it earlier, One Second Everyday iOS app is free today ~ http:\/\/t.co\/9WSYY9AY",
    "id" : 289493823724322816,
    "created_at" : "2013-01-10 22:08:00 +0000",
    "user" : {
      "name" : "Erin Jo Richey",
      "screen_name" : "erinjo",
      "protected" : false,
      "id_str" : "14961286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461635779010101248\/ngayZj4G_normal.jpeg",
      "id" : 14961286,
      "verified" : false
    }
  },
  "id" : 289494806160367616,
  "created_at" : "2013-01-10 22:11:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289477592359251968",
  "geo" : { },
  "id_str" : "289478419144638464",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april The spreadsheet is view-only\u2026",
  "id" : 289478419144638464,
  "in_reply_to_status_id" : 289477592359251968,
  "created_at" : "2013-01-10 21:06:48 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/u9LmCo5k",
      "expanded_url" : "http:\/\/flic.kr\/p\/dKqv7c",
      "display_url" : "flic.kr\/p\/dKqv7c"
    } ]
  },
  "geo" : { },
  "id_str" : "289474694455902209",
  "text" : "Niko's new word http:\/\/t.co\/u9LmCo5k",
  "id" : 289474694455902209,
  "created_at" : "2013-01-10 20:51:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThePresent",
      "screen_name" : "OwnThePresent",
      "indices" : [ 117, 131 ],
      "id_str" : "601956203",
      "id" : 601956203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/YQmkVlfq",
      "expanded_url" : "http:\/\/bit.ly\/13lGnDa",
      "display_url" : "bit.ly\/13lGnDa"
    } ]
  },
  "geo" : { },
  "id_str" : "289471918912978944",
  "text" : "An awesome clock that tells time in seasons. I'd buy it if it were about half as expensive: http:\/\/t.co\/YQmkVlfq \/by @ownthepresent",
  "id" : 289471918912978944,
  "created_at" : "2013-01-10 20:40:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/7tIgFogi",
      "expanded_url" : "http:\/\/bit.ly\/SmHSzO",
      "display_url" : "bit.ly\/SmHSzO"
    } ]
  },
  "geo" : { },
  "id_str" : "289464129914298369",
  "text" : "This is funny. Celebrities read mean tweets: http:\/\/t.co\/7tIgFogi",
  "id" : 289464129914298369,
  "created_at" : "2013-01-10 20:10:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Mitchell",
      "screen_name" : "sgmitch",
      "indices" : [ 0, 8 ],
      "id_str" : "16933856",
      "id" : 16933856
    }, {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 9, 16 ],
      "id_str" : "30495974",
      "id" : 30495974
    }, {
      "name" : "timoni west",
      "screen_name" : "timoni",
      "indices" : [ 17, 24 ],
      "id_str" : "12615",
      "id" : 12615
    }, {
      "name" : "Joshua Kaufman",
      "screen_name" : "jmk",
      "indices" : [ 25, 29 ],
      "id_str" : "12376",
      "id" : 12376
    }, {
      "name" : "Austin Kleon",
      "screen_name" : "austinkleon",
      "indices" : [ 30, 42 ],
      "id_str" : "9698942",
      "id" : 9698942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289435923005964288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086834632, -122.3059788813 ]
  },
  "id_str" : "289438420076466176",
  "in_reply_to_user_id" : 16933856,
  "text" : "@sgmitch @berkun @timoni @jmk @austinkleon Okay now I have to buy it too. Thanks!",
  "id" : 289438420076466176,
  "in_reply_to_status_id" : 289435923005964288,
  "created_at" : "2013-01-10 18:27:51 +0000",
  "in_reply_to_screen_name" : "sgmitch",
  "in_reply_to_user_id_str" : "16933856",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D. Keith Robinson",
      "screen_name" : "dkr",
      "indices" : [ 0, 4 ],
      "id_str" : "10877",
      "id" : 10877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289413097091895297",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087174099, -122.3059859221 ]
  },
  "id_str" : "289418483995922432",
  "in_reply_to_user_id" : 10877,
  "text" : "@dkr I love this one slide a day project! Awesome.",
  "id" : 289418483995922432,
  "in_reply_to_status_id" : 289413097091895297,
  "created_at" : "2013-01-10 17:08:38 +0000",
  "in_reply_to_screen_name" : "dkr",
  "in_reply_to_user_id_str" : "10877",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/qg60qeuF",
      "expanded_url" : "http:\/\/flic.kr\/p\/dKghai",
      "display_url" : "flic.kr\/p\/dKghai"
    } ]
  },
  "geo" : { },
  "id_str" : "289242882056007681",
  "text" : "8:36pm Was mile-high side-#hackweek-ing on another fun idea http:\/\/t.co\/qg60qeuF",
  "id" : 289242882056007681,
  "created_at" : "2013-01-10 05:30:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Currier",
      "screen_name" : "jeff_currier",
      "indices" : [ 0, 13 ],
      "id_str" : "626155328",
      "id" : 626155328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289216001038499840",
  "geo" : { },
  "id_str" : "289219711504379904",
  "in_reply_to_user_id" : 626155328,
  "text" : "@jeff_currier I suspect that's why hashes are winning.",
  "id" : 289219711504379904,
  "in_reply_to_status_id" : 289216001038499840,
  "created_at" : "2013-01-10 03:58:47 +0000",
  "in_reply_to_screen_name" : "jeff_currier",
  "in_reply_to_user_id_str" : "626155328",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 0, 12 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289209965904789505",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6149271995, -122.3815183634 ]
  },
  "id_str" : "289214265007681536",
  "in_reply_to_user_id" : 930061,
  "text" : "@ginatrapani Awww. Yes. I'm now a nap expert as well. Every 15 minutes counts.",
  "id" : 289214265007681536,
  "in_reply_to_status_id" : 289209965904789505,
  "created_at" : "2013-01-10 03:37:08 +0000",
  "in_reply_to_screen_name" : "ginatrapani",
  "in_reply_to_user_id_str" : "930061",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 0, 12 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289207792835915776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6174774021, -122.3815828631 ]
  },
  "id_str" : "289209332694908929",
  "in_reply_to_user_id" : 930061,
  "text" : "@ginatrapani I felt the same way! Just don't let sleep deprivation get ya.",
  "id" : 289209332694908929,
  "in_reply_to_status_id" : 289207792835915776,
  "created_at" : "2013-01-10 03:17:32 +0000",
  "in_reply_to_screen_name" : "ginatrapani",
  "in_reply_to_user_id_str" : "930061",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/SotZ7Nly",
      "expanded_url" : "http:\/\/polarb.com\/34526",
      "display_url" : "polarb.com\/34526"
    } ]
  },
  "geo" : { },
  "id_str" : "289208968134393856",
  "text" : "Which Data Structure Do You Like Better? Please vote. http:\/\/t.co\/SotZ7Nly",
  "id" : 289208968134393856,
  "created_at" : "2013-01-10 03:16:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289181607590522880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7788202778, -122.4146545147 ]
  },
  "id_str" : "289185166566514688",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar Yay! A week from today (Wed) at Saint John's from 7:30 til midnightish.",
  "id" : 289185166566514688,
  "in_reply_to_status_id" : 289181607590522880,
  "created_at" : "2013-01-10 01:41:31 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Parrish",
      "screen_name" : "farnamstreet",
      "indices" : [ 0, 13 ],
      "id_str" : "33104659",
      "id" : 33104659
    }, {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 14, 21 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289119640121122816",
  "geo" : { },
  "id_str" : "289121824279781376",
  "in_reply_to_user_id" : 33104659,
  "text" : "@farnamstreet @berkun Interesting! Isn't coercion a subset of persuasion under that def? Use (or threat of) force appeals to fear emotions.",
  "id" : 289121824279781376,
  "in_reply_to_status_id" : 289119640121122816,
  "created_at" : "2013-01-09 21:29:49 +0000",
  "in_reply_to_screen_name" : "farnamstreet",
  "in_reply_to_user_id_str" : "33104659",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Getzel Rubashkin",
      "screen_name" : "Journeyman_Web",
      "indices" : [ 0, 15 ],
      "id_str" : "1132025496",
      "id" : 1132025496
    }, {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 16, 23 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289118397814427648",
  "geo" : { },
  "id_str" : "289119994720186368",
  "in_reply_to_user_id" : 76679049,
  "text" : "@Journeyman_Web @berkun Yeah, that seems right to me. In the universe, effectiveness IS truth. In society, the two are very different.",
  "id" : 289119994720186368,
  "in_reply_to_status_id" : 289118397814427648,
  "created_at" : "2013-01-09 21:22:32 +0000",
  "in_reply_to_screen_name" : "GetzelR",
  "in_reply_to_user_id_str" : "76679049",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Getzel Rubashkin",
      "screen_name" : "Journeyman_Web",
      "indices" : [ 0, 15 ],
      "id_str" : "1132025496",
      "id" : 1132025496
    }, {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 16, 23 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289098100981768192",
  "geo" : { },
  "id_str" : "289113536049868801",
  "in_reply_to_user_id" : 76679049,
  "text" : "@Journeyman_Web @berkun Isn't the law of natural selection basically effectiveness within circumstances over everything else?",
  "id" : 289113536049868801,
  "in_reply_to_status_id" : 289098100981768192,
  "created_at" : "2013-01-09 20:56:53 +0000",
  "in_reply_to_screen_name" : "GetzelR",
  "in_reply_to_user_id_str" : "76679049",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "MarshallHaas",
      "indices" : [ 0, 13 ],
      "id_str" : "1268491417",
      "id" : 1268491417
    }, {
      "name" : "Timehop",
      "screen_name" : "timehop",
      "indices" : [ 75, 83 ],
      "id_str" : "436143123",
      "id" : 436143123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289091259249856512",
  "geo" : { },
  "id_str" : "289093005598654466",
  "in_reply_to_user_id" : 19028099,
  "text" : "@marshallhaas Agreed! Especially once you get multiple years in there. \/cc @timehop",
  "id" : 289093005598654466,
  "in_reply_to_status_id" : 289091259249856512,
  "created_at" : "2013-01-09 19:35:18 +0000",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 3, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289083071813267456",
  "text" : "My #hackweek project is less interesting due to the fact that people are tweeting about CES all week. My filters need filters.",
  "id" : 289083071813267456,
  "created_at" : "2013-01-09 18:55:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Haider",
      "screen_name" : "pandemona",
      "indices" : [ 0, 10 ],
      "id_str" : "18337283",
      "id" : 18337283
    }, {
      "name" : "Josh Elman",
      "screen_name" : "joshelman",
      "indices" : [ 11, 21 ],
      "id_str" : "1979921",
      "id" : 1979921
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 22, 29 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 30, 38 ],
      "id_str" : "291",
      "id" : 291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289075268889485312",
  "geo" : { },
  "id_str" : "289081265024532480",
  "in_reply_to_user_id" : 18337283,
  "text" : "@pandemona @joshelman @isaach @goldman I agree. They should flaunt a number that proves that that use case is growing.",
  "id" : 289081265024532480,
  "in_reply_to_status_id" : 289075268889485312,
  "created_at" : "2013-01-09 18:48:39 +0000",
  "in_reply_to_screen_name" : "pandemona",
  "in_reply_to_user_id_str" : "18337283",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess",
      "screen_name" : "mibi",
      "indices" : [ 0, 5 ],
      "id_str" : "14965636",
      "id" : 14965636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289080502269378560",
  "geo" : { },
  "id_str" : "289080982395555840",
  "in_reply_to_user_id" : 14965636,
  "text" : "@mibi About 4 months ago.",
  "id" : 289080982395555840,
  "in_reply_to_status_id" : 289080502269378560,
  "created_at" : "2013-01-09 18:47:31 +0000",
  "in_reply_to_screen_name" : "mibi",
  "in_reply_to_user_id_str" : "14965636",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Elman",
      "screen_name" : "joshelman",
      "indices" : [ 0, 10 ],
      "id_str" : "1979921",
      "id" : 1979921
    }, {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 11, 19 ],
      "id_str" : "291",
      "id" : 291
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 20, 27 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289071464991309824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7777979818, -122.4150594489 ]
  },
  "id_str" : "289072728852557824",
  "in_reply_to_user_id" : 1979921,
  "text" : "@joshelman @goldman @isaach Point is: they should share a meaningful number. If it can't \"fall flat\" when value ends, it's not meaningful.",
  "id" : 289072728852557824,
  "in_reply_to_status_id" : 289071464991309824,
  "created_at" : "2013-01-09 18:14:43 +0000",
  "in_reply_to_screen_name" : "joshelman",
  "in_reply_to_user_id_str" : "1979921",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kottke.org",
      "screen_name" : "kottke",
      "indices" : [ 3, 10 ],
      "id_str" : "14120215",
      "id" : 14120215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/FJpQ5yKP",
      "expanded_url" : "http:\/\/kottke.org\/13\/01\/the-extraordinary-is-the-new-ordinary",
      "display_url" : "kottke.org\/13\/01\/the-extr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289067928672948224",
  "text" : "RT @kottke: On today's internet, the extraordinary is the new ordinary http:\/\/t.co\/FJpQ5yKP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/kottke.org\" rel=\"nofollow\"\u003Ekottke tweeter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/FJpQ5yKP",
        "expanded_url" : "http:\/\/kottke.org\/13\/01\/the-extraordinary-is-the-new-ordinary",
        "display_url" : "kottke.org\/13\/01\/the-extr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "289066764015374336",
    "text" : "On today's internet, the extraordinary is the new ordinary http:\/\/t.co\/FJpQ5yKP",
    "id" : 289066764015374336,
    "created_at" : "2013-01-09 17:51:01 +0000",
    "user" : {
      "name" : "kottke.org",
      "screen_name" : "kottke",
      "protected" : false,
      "id_str" : "14120215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421227828\/apple-touch-icon_normal.png",
      "id" : 14120215,
      "verified" : false
    }
  },
  "id" : 289067928672948224,
  "created_at" : "2013-01-09 17:55:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/timehop.com\/\" rel=\"nofollow\"\u003ETimehop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/fgd4yVDM",
      "expanded_url" : "http:\/\/t.imehop.com\/ULmFR5",
      "display_url" : "t.imehop.com\/ULmFR5"
    } ]
  },
  "geo" : { },
  "id_str" : "289066507659522048",
  "text" : "I want Niko to re-create this photo when he's 50.  http:\/\/t.co\/fgd4yVDM",
  "id" : 289066507659522048,
  "created_at" : "2013-01-09 17:50:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gigaom",
      "screen_name" : "gigaom",
      "indices" : [ 3, 10 ],
      "id_str" : "2893971",
      "id" : 2893971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/j3f8IYdI",
      "expanded_url" : "http:\/\/dlvr.it\/2mWCR0",
      "display_url" : "dlvr.it\/2mWCR0"
    } ]
  },
  "geo" : { },
  "id_str" : "289065882834055168",
  "text" : "RT @gigaom: Twitter\u2019s human-powered search is the present and future of AI http:\/\/t.co\/j3f8IYdI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/j3f8IYdI",
        "expanded_url" : "http:\/\/dlvr.it\/2mWCR0",
        "display_url" : "dlvr.it\/2mWCR0"
      } ]
    },
    "geo" : { },
    "id_str" : "289064876280782848",
    "text" : "Twitter\u2019s human-powered search is the present and future of AI http:\/\/t.co\/j3f8IYdI",
    "id" : 289064876280782848,
    "created_at" : "2013-01-09 17:43:31 +0000",
    "user" : {
      "name" : "Gigaom",
      "screen_name" : "gigaom",
      "protected" : false,
      "id_str" : "2893971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458702422479613952\/3I1T5T51_normal.png",
      "id" : 2893971,
      "verified" : true
    }
  },
  "id" : 289065882834055168,
  "created_at" : "2013-01-09 17:47:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289064471345889280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7779541314, -122.4150971514 ]
  },
  "id_str" : "289064928369852417",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun I think the universe's bias for effectiveness over accuracy may be its greatest flaw.",
  "id" : 289064928369852417,
  "in_reply_to_status_id" : 289064471345889280,
  "created_at" : "2013-01-09 17:43:44 +0000",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289058364724477952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7781478033, -122.4150911741 ]
  },
  "id_str" : "289063037946712065",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun And yet using persuasion tactics, while often effective at convincing someone, have nothing to do with actually being right.",
  "id" : 289063037946712065,
  "in_reply_to_status_id" : 289058364724477952,
  "created_at" : "2013-01-09 17:36:13 +0000",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Elman",
      "screen_name" : "joshelman",
      "indices" : [ 0, 10 ],
      "id_str" : "1979921",
      "id" : 1979921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289057331654840320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7772864088, -122.4154069806 ]
  },
  "id_str" : "289062093695627265",
  "in_reply_to_user_id" : 1979921,
  "text" : "@joshelman How do you think inactive accounts support their business?",
  "id" : 289062093695627265,
  "in_reply_to_status_id" : 289057331654840320,
  "created_at" : "2013-01-09 17:32:28 +0000",
  "in_reply_to_screen_name" : "joshelman",
  "in_reply_to_user_id_str" : "1979921",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avi Bryant",
      "screen_name" : "avibryant",
      "indices" : [ 0, 10 ],
      "id_str" : "13192",
      "id" : 13192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289055998172356610",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7781872893, -122.414947525 ]
  },
  "id_str" : "289061432681713664",
  "in_reply_to_user_id" : 13192,
  "text" : "@avibryant I see people trusting non-statistically significant data all the time. Stat. sig. data is hard to find even in giant data sets.",
  "id" : 289061432681713664,
  "in_reply_to_status_id" : 289055998172356610,
  "created_at" : "2013-01-09 17:29:50 +0000",
  "in_reply_to_screen_name" : "avibryant",
  "in_reply_to_user_id_str" : "13192",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/Mh42TEID",
      "expanded_url" : "http:\/\/blog.linkedin.com\/2013\/01\/09\/linkedin-200-million\/",
      "display_url" : "blog.linkedin.com\/2013\/01\/09\/lin\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7776232802, -122.4152351444 ]
  },
  "id_str" : "289056450821648384",
  "text" : "Yeah but does anyone have guesses on LinkedIn's monthly active users? http:\/\/t.co\/Mh42TEID",
  "id" : 289056450821648384,
  "created_at" : "2013-01-09 17:10:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/RS7ilN5I",
      "expanded_url" : "http:\/\/www.nytimes.com\/2012\/02\/14\/science\/novelty-seeking-neophilia-can-be-a-predictor-of-well-being.html?_r=2&buffer_share=28b82&utm_source=buffer&",
      "display_url" : "nytimes.com\/2012\/02\/14\/sci\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778224892, -122.4152108744 ]
  },
  "id_str" : "289055667342434305",
  "text" : "Neophilia, grit, and flow. 3 personality traits that self-correct each other and make life more fulfilling  http:\/\/t.co\/RS7ilN5I",
  "id" : 289055667342434305,
  "created_at" : "2013-01-09 17:06:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Babauta",
      "screen_name" : "zen_habits",
      "indices" : [ 3, 14 ],
      "id_str" : "15859268",
      "id" : 15859268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/kVYtidJp",
      "expanded_url" : "http:\/\/zenhabits.net\/primal\/",
      "display_url" : "zenhabits.net\/primal\/"
    } ]
  },
  "geo" : { },
  "id_str" : "289052230890422272",
  "text" : "RT @zen_habits: What We Lack in a Hyperconnected World http:\/\/t.co\/kVYtidJp",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/kVYtidJp",
        "expanded_url" : "http:\/\/zenhabits.net\/primal\/",
        "display_url" : "zenhabits.net\/primal\/"
      } ]
    },
    "geo" : { },
    "id_str" : "289049667516391425",
    "text" : "What We Lack in a Hyperconnected World http:\/\/t.co\/kVYtidJp",
    "id" : 289049667516391425,
    "created_at" : "2013-01-09 16:43:05 +0000",
    "user" : {
      "name" : "Leo Babauta",
      "screen_name" : "zen_habits",
      "protected" : false,
      "id_str" : "15859268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000335306551\/a74fde4f2030a71689a5f2d480d4f73c_normal.jpeg",
      "id" : 15859268,
      "verified" : true
    }
  },
  "id" : 289052230890422272,
  "created_at" : "2013-01-09 16:53:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    }, {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 12, 28 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288898149685284864",
  "geo" : { },
  "id_str" : "288899074042761216",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler @cjlikearockstar Oh yeah, that's what I meant.  Saturday is BOOK OF MORMON WOOOO!",
  "id" : 288899074042761216,
  "in_reply_to_status_id" : 288898149685284864,
  "created_at" : "2013-01-09 06:44:41 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288894161262895105",
  "geo" : { },
  "id_str" : "288897423273758720",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar It'll be alright. Hey whatcha doing Saturday night? Come to our going away party at Saint Johns!",
  "id" : 288897423273758720,
  "in_reply_to_status_id" : 288894161262895105,
  "created_at" : "2013-01-09 06:38:07 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "indices" : [ 0, 5 ],
      "id_str" : "10221",
      "id" : 10221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thanks",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288890428328116226",
  "geo" : { },
  "id_str" : "288891272863813632",
  "in_reply_to_user_id" : 10221,
  "text" : "@drew Yeah, something I was hoping for just fell through. It's not a big thing, life will go on. #thanks",
  "id" : 288891272863813632,
  "in_reply_to_status_id" : 288890428328116226,
  "created_at" : "2013-01-09 06:13:41 +0000",
  "in_reply_to_screen_name" : "drew",
  "in_reply_to_user_id_str" : "10221",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whensideprojectsdie",
      "indices" : [ 74, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288889291227148289",
  "text" : "Don't worry, nothing too serious\u2026 family, friends, and work are all fine. #whensideprojectsdie",
  "id" : 288889291227148289,
  "created_at" : "2013-01-09 06:05:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288888218873655297",
  "text" : "Got some bummer news.",
  "id" : 288888218873655297,
  "created_at" : "2013-01-09 06:01:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Teso",
      "screen_name" : "ChrisTeso",
      "indices" : [ 0, 10 ],
      "id_str" : "19081905",
      "id" : 19081905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/PdkmtIeW",
      "expanded_url" : "http:\/\/bit.ly\/LnamDG",
      "display_url" : "bit.ly\/LnamDG"
    } ]
  },
  "in_reply_to_status_id_str" : "288876661615755264",
  "geo" : { },
  "id_str" : "288887726583975936",
  "in_reply_to_user_id" : 19081905,
  "text" : "@ChrisTeso It's always 8:36pm http:\/\/t.co\/PdkmtIeW",
  "id" : 288887726583975936,
  "in_reply_to_status_id" : 288876661615755264,
  "created_at" : "2013-01-09 05:59:35 +0000",
  "in_reply_to_screen_name" : "ChrisTeso",
  "in_reply_to_user_id_str" : "19081905",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288870347036585984",
  "geo" : { },
  "id_str" : "288871047565045760",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc Probably less so when trying to implement superhuman AI.",
  "id" : 288871047565045760,
  "in_reply_to_status_id" : 288870347036585984,
  "created_at" : "2013-01-09 04:53:19 +0000",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288869948489596929",
  "geo" : { },
  "id_str" : "288870119332016129",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc Looks like he's going to try now that he's at Google and has \"unlimited resources\" at his disposal.",
  "id" : 288870119332016129,
  "in_reply_to_status_id" : 288869948489596929,
  "created_at" : "2013-01-09 04:49:38 +0000",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288869421915717632",
  "geo" : { },
  "id_str" : "288869774191104001",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc True, I read some reviews that make it seem like he's rehashing old ideas. But it's still interesting.",
  "id" : 288869774191104001,
  "in_reply_to_status_id" : 288869421915717632,
  "created_at" : "2013-01-09 04:48:15 +0000",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/LiilytPH",
      "expanded_url" : "http:\/\/instagr.am\/p\/UP_i0go0IO\/",
      "display_url" : "instagr.am\/p\/UP_i0go0IO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "288867822724067328",
  "text" : "8:36pm Reading about Kurzweil's new theory of the mind, all revolving around simple pattern matching http:\/\/t.co\/LiilytPH",
  "id" : 288867822724067328,
  "created_at" : "2013-01-09 04:40:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288865825824321536",
  "geo" : { },
  "id_str" : "288866871481073664",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach That's after removing the \"non-coding DNA\" (800MB). You can compress the remaining DNA another 90% without losing data. So 3-10MB.",
  "id" : 288866871481073664,
  "in_reply_to_status_id" : 288865825824321536,
  "created_at" : "2013-01-09 04:36:43 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288865332561575936",
  "geo" : { },
  "id_str" : "288865626116747264",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates The world is our S3 and EC2.",
  "id" : 288865626116747264,
  "in_reply_to_status_id" : 288865332561575936,
  "created_at" : "2013-01-09 04:31:46 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288864440567361537",
  "text" : "But when that data is expressed into, amongst other things, a brain, it can then eventually store between 1-14 petabytes (1-14,000,000 GB).",
  "id" : 288864440567361537,
  "created_at" : "2013-01-09 04:27:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288863644685586432",
  "text" : "The current estimate for the amount of non-compressed data stored in DNA is 30-100 MB.",
  "id" : 288863644685586432,
  "created_at" : "2013-01-09 04:23:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288841620663726081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7749209164, -122.4229361863 ]
  },
  "id_str" : "288850186749476864",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold I think it has already reached there too.",
  "id" : 288850186749476864,
  "in_reply_to_status_id" : 288841620663726081,
  "created_at" : "2013-01-09 03:30:25 +0000",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Graham",
      "screen_name" : "paulg",
      "indices" : [ 3, 9 ],
      "id_str" : "183749519",
      "id" : 183749519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/oK8aj5Kx",
      "expanded_url" : "http:\/\/bit.ly\/UGFXaa",
      "display_url" : "bit.ly\/UGFXaa"
    } ]
  },
  "geo" : { },
  "id_str" : "288843940600373248",
  "text" : "RT @paulg: Survey data says says rumors of Facebook demise exaggerated, but Snapchat and Instagram real. http:\/\/t.co\/oK8aj5Kx",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/oK8aj5Kx",
        "expanded_url" : "http:\/\/bit.ly\/UGFXaa",
        "display_url" : "bit.ly\/UGFXaa"
      } ]
    },
    "geo" : { },
    "id_str" : "288731982328909824",
    "text" : "Survey data says says rumors of Facebook demise exaggerated, but Snapchat and Instagram real. http:\/\/t.co\/oK8aj5Kx",
    "id" : 288731982328909824,
    "created_at" : "2013-01-08 19:40:43 +0000",
    "user" : {
      "name" : "Paul Graham",
      "screen_name" : "paulg",
      "protected" : false,
      "id_str" : "183749519",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1824002576\/pg-railsconf_normal.jpg",
      "id" : 183749519,
      "verified" : true
    }
  },
  "id" : 288843940600373248,
  "created_at" : "2013-01-09 03:05:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/vewQsNRq",
      "expanded_url" : "http:\/\/www.thisiscolossal.com\/2012\/12\/new-trampled-snow-art-from-simon-beck\/",
      "display_url" : "thisiscolossal.com\/2012\/12\/new-tr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288842315659882497",
  "text" : "RT @isaach: stunning art trampled into snow over hours and days: http:\/\/t.co\/vewQsNRq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/vewQsNRq",
        "expanded_url" : "http:\/\/www.thisiscolossal.com\/2012\/12\/new-trampled-snow-art-from-simon-beck\/",
        "display_url" : "thisiscolossal.com\/2012\/12\/new-tr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "288837001870991360",
    "text" : "stunning art trampled into snow over hours and days: http:\/\/t.co\/vewQsNRq",
    "id" : 288837001870991360,
    "created_at" : "2013-01-09 02:38:02 +0000",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430605387117494272\/lmplHwca_normal.png",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 288842315659882497,
  "created_at" : "2013-01-09 02:59:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Malthe Sigurdsson",
      "screen_name" : "malthe",
      "indices" : [ 10, 17 ],
      "id_str" : "496223",
      "id" : 496223
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 19, 27 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 28, 35 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/288820877972344833\/photo\/1",
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/gT7cJ2XR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAIZDuuCEAAKvFe.jpg",
      "id_str" : "288820877976539136",
      "id" : 288820877976539136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAIZDuuCEAAKvFe.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gT7cJ2XR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288820248969367552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7768772259, -122.4172509192 ]
  },
  "id_str" : "288820877972344833",
  "in_reply_to_user_id" : 496223,
  "text" : "@anildash @malthe  @djacobs @isaach Yeah, cohort retention graphs looks something like this: http:\/\/t.co\/gT7cJ2XR",
  "id" : 288820877972344833,
  "in_reply_to_status_id" : 288820248969367552,
  "created_at" : "2013-01-09 01:33:58 +0000",
  "in_reply_to_screen_name" : "malthe",
  "in_reply_to_user_id_str" : "496223",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288811555150241793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769211474, -122.4172114847 ]
  },
  "id_str" : "288812991837794304",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Okay, yeah, so feeds work well in ThinkUp + social media, but not for all cases of web-based dashboard analytics.",
  "id" : 288812991837794304,
  "in_reply_to_status_id" : 288811555150241793,
  "created_at" : "2013-01-09 01:02:37 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288810187798745089",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769516398, -122.4171978842 ]
  },
  "id_str" : "288811299587117057",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash True but if you wanna make data-based decisions, you gotta be at least a bit advanced. It's really easy to reach bad conclusions.",
  "id" : 288811299587117057,
  "in_reply_to_status_id" : 288810187798745089,
  "created_at" : "2013-01-09 00:55:54 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288809935117094912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769965435, -122.4172156979 ]
  },
  "id_str" : "288810471417597953",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach I'll dig something up or draw a picture.",
  "id" : 288810471417597953,
  "in_reply_to_status_id" : 288809935117094912,
  "created_at" : "2013-01-09 00:52:36 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/iMFYGO9n",
      "expanded_url" : "http:\/\/bit.ly\/TJK7M2",
      "display_url" : "bit.ly\/TJK7M2"
    } ]
  },
  "in_reply_to_status_id_str" : "288792168326381568",
  "geo" : { },
  "id_str" : "288808362378948608",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash My response got a bit long, so I blogged it: http:\/\/t.co\/iMFYGO9n",
  "id" : 288808362378948608,
  "in_reply_to_status_id" : 288792168326381568,
  "created_at" : "2013-01-09 00:44:14 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u25B5 Jenna Wortham \u25B5",
      "screen_name" : "jennydeluxe",
      "indices" : [ 3, 15 ],
      "id_str" : "10454572",
      "id" : 10454572
    }, {
      "name" : "Mathew Ingram",
      "screen_name" : "mathewi",
      "indices" : [ 43, 51 ],
      "id_str" : "824157",
      "id" : 824157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/n5KfQvrh",
      "expanded_url" : "http:\/\/engineering.twitter.com\/2013\/01\/improving-twitter-search-with-real-time.html",
      "display_url" : "engineering.twitter.com\/2013\/01\/improv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288759303370850304",
  "text" : "RT @jennydeluxe: Singularity starts now RT @mathewi Twitter uses Mechanical Turk workers to help it understand trending topics http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mathew Ingram",
        "screen_name" : "mathewi",
        "indices" : [ 26, 34 ],
        "id_str" : "824157",
        "id" : 824157
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/n5KfQvrh",
        "expanded_url" : "http:\/\/engineering.twitter.com\/2013\/01\/improving-twitter-search-with-real-time.html",
        "display_url" : "engineering.twitter.com\/2013\/01\/improv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "288756144086872067",
    "text" : "Singularity starts now RT @mathewi Twitter uses Mechanical Turk workers to help it understand trending topics http:\/\/t.co\/n5KfQvrh \u2026",
    "id" : 288756144086872067,
    "created_at" : "2013-01-08 21:16:44 +0000",
    "user" : {
      "name" : "\u25B5 Jenna Wortham \u25B5",
      "screen_name" : "jennydeluxe",
      "protected" : false,
      "id_str" : "10454572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1541555730\/qbEleAiJKZJRKqceqLRo_normal.gif",
      "id" : 10454572,
      "verified" : true
    }
  },
  "id" : 288759303370850304,
  "created_at" : "2013-01-08 21:29:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "indices" : [ 55, 67 ],
      "id_str" : "1532061",
      "id" : 1532061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/dSgf3PJ4",
      "expanded_url" : "http:\/\/fnd.gs\/13gF7Bo",
      "display_url" : "fnd.gs\/13gF7Bo"
    } ]
  },
  "geo" : { },
  "id_str" : "288752540307296257",
  "text" : "The Post-Productivity Economy http:\/\/t.co\/dSgf3PJ4 \/by @kevin2kelly",
  "id" : 288752540307296257,
  "created_at" : "2013-01-08 21:02:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 3, 18 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/zkrX9Onj",
      "expanded_url" : "http:\/\/www.businessinsider.com\/why-the-mint-the-coin-debate-could-be-the-most-important-fiscal-policy-debate-youll-ever-see-in-your-life-2013-1",
      "display_url" : "businessinsider.com\/why-the-mint-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288710935235936257",
  "text" : "RT @mikeindustries: Finally caught up on the trillion dollar coin debate. Excellent reading here: http:\/\/t.co\/zkrX9Onj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/zkrX9Onj",
        "expanded_url" : "http:\/\/www.businessinsider.com\/why-the-mint-the-coin-debate-could-be-the-most-important-fiscal-policy-debate-youll-ever-see-in-your-life-2013-1",
        "display_url" : "businessinsider.com\/why-the-mint-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "288709961092042753",
    "text" : "Finally caught up on the trillion dollar coin debate. Excellent reading here: http:\/\/t.co\/zkrX9Onj",
    "id" : 288709961092042753,
    "created_at" : "2013-01-08 18:13:13 +0000",
    "user" : {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "protected" : false,
      "id_str" : "74523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430955581830995968\/sSqK3_b9_normal.jpeg",
      "id" : 74523,
      "verified" : false
    }
  },
  "id" : 288710935235936257,
  "created_at" : "2013-01-08 18:17:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 0, 8 ],
      "id_str" : "9395832",
      "id" : 9395832
    }, {
      "name" : "Svbtle Feed",
      "screen_name" : "SvbtleFeed",
      "indices" : [ 83, 94 ],
      "id_str" : "1352847072",
      "id" : 1352847072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/EEMPWiv6",
      "expanded_url" : "http:\/\/blog.svbtle.com\/svbtle-funding",
      "display_url" : "blog.svbtle.com\/svbtle-funding"
    } ]
  },
  "geo" : { },
  "id_str" : "288706482768314368",
  "in_reply_to_user_id" : 9395832,
  "text" : "@dcurtis Congrats on funding! PS - the link here + on the homepage doesn't work RT @SvbtleFeed: Svbtle funding http:\/\/t.co\/EEMPWiv6",
  "id" : 288706482768314368,
  "created_at" : "2013-01-08 17:59:24 +0000",
  "in_reply_to_screen_name" : "dcurtis",
  "in_reply_to_user_id_str" : "9395832",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/QCXl9u1Z",
      "expanded_url" : "http:\/\/flic.kr\/p\/dJHGyn",
      "display_url" : "flic.kr\/p\/dJHGyn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7735, -122.422167 ]
  },
  "id_str" : "288531954553458688",
  "text" : "8:36pm I like my coworkers, they are smrt http:\/\/t.co\/QCXl9u1Z",
  "id" : 288531954553458688,
  "created_at" : "2013-01-08 06:25:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan Donohoe",
      "screen_name" : "bdonohoe",
      "indices" : [ 12, 21 ],
      "id_str" : "1193421",
      "id" : 1193421
    }, {
      "name" : "Reeve S. Thompson ",
      "screen_name" : "Reeve",
      "indices" : [ 22, 28 ],
      "id_str" : "9317922",
      "id" : 9317922
    }, {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 29, 40 ],
      "id_str" : "26123649",
      "id" : 26123649
    }, {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 41, 48 ],
      "id_str" : "23640904",
      "id" : 23640904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/zkBkmm1h",
      "expanded_url" : "http:\/\/4sq.com\/TZbIaJ",
      "display_url" : "4sq.com\/TZbIaJ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.773536, -122.42211 ]
  },
  "id_str" : "288462580840792065",
  "text" : "Drinks with @bdonohoe @reeve @brianellin @emoore (@ Hotel Biron w\/ 2 others) http:\/\/t.co\/zkBkmm1h",
  "id" : 288462580840792065,
  "created_at" : "2013-01-08 01:50:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/MpwUgJO2",
      "expanded_url" : "http:\/\/bit.ly\/WERGRi",
      "display_url" : "bit.ly\/WERGRi"
    } ]
  },
  "geo" : { },
  "id_str" : "288384490286485504",
  "text" : "Interesting take on why people don't seem to like 48 frames per second in the new Hobbit: http:\/\/t.co\/MpwUgJO2",
  "id" : 288384490286485504,
  "created_at" : "2013-01-07 20:39:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/288369671370051585\/photo\/1",
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/ikuv09Xh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAB-sDJCEAAdmt2.png",
      "id_str" : "288369671374245888",
      "id" : 288369671374245888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAB-sDJCEAAdmt2.png",
      "sizes" : [ {
        "h" : 580,
        "resize" : "fit",
        "w" : 516
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 516
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 516
      } ],
      "display_url" : "pic.twitter.com\/ikuv09Xh"
    } ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "hackweek",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288369671370051585",
  "text" : "#hackweek is trending in my #hackweek project. http:\/\/t.co\/ikuv09Xh",
  "id" : 288369671370051585,
  "created_at" : "2013-01-07 19:41:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 14, 29 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288361270766350336",
  "text" : "It should! MT @mikeindustries: Does a service exist which takes my Instapaper backlog &amp; mails me a nice bound periodical every month?",
  "id" : 288361270766350336,
  "created_at" : "2013-01-07 19:07:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 0, 13 ],
      "id_str" : "14471007",
      "id" : 14471007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/ONyzEjjz",
      "expanded_url" : "http:\/\/bit.ly\/WEr9nt",
      "display_url" : "bit.ly\/WEr9nt"
    } ]
  },
  "in_reply_to_status_id_str" : "288347320234430464",
  "geo" : { },
  "id_str" : "288358075818184704",
  "in_reply_to_user_id" : 14471007,
  "text" : "@dianakimball RE 750: yeah, we're deprecating it. You can still use it here: http:\/\/t.co\/ONyzEjjz but should create a password pronto. :)",
  "id" : 288358075818184704,
  "in_reply_to_status_id" : 288347320234430464,
  "created_at" : "2013-01-07 18:54:57 +0000",
  "in_reply_to_screen_name" : "dianakimball",
  "in_reply_to_user_id_str" : "14471007",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deacon 87",
      "screen_name" : "Deacon87",
      "indices" : [ 0, 9 ],
      "id_str" : "17628107",
      "id" : 17628107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288203794624421888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778292617, -122.4151700953 ]
  },
  "id_str" : "288211618888830976",
  "in_reply_to_user_id" : 17628107,
  "text" : "@Deacon87 is it MS?",
  "id" : 288211618888830976,
  "in_reply_to_status_id" : 288203794624421888,
  "created_at" : "2013-01-07 09:12:59 +0000",
  "in_reply_to_screen_name" : "Deacon87",
  "in_reply_to_user_id_str" : "17628107",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288188131990175744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778151088, -122.4151272669 ]
  },
  "id_str" : "288192379847077888",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel A bunch of Chinese iBankers have a bad day so go fishing and carb-loading til the sun goes down. And then drunk walkie-talkie.",
  "id" : 288192379847077888,
  "in_reply_to_status_id" : 288188131990175744,
  "created_at" : "2013-01-07 07:56:32 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 16, 22 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 23, 31 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288189157925343233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7779155909, -122.4150865939 ]
  },
  "id_str" : "288189795639906304",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries @couch @djacobs Hm you are probably correct. But I like your RTs.",
  "id" : 288189795639906304,
  "in_reply_to_status_id" : 288189157925343233,
  "created_at" : "2013-01-07 07:46:16 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288181310973947904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778030644, -122.4151969055 ]
  },
  "id_str" : "288189483709526016",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Wanna hop on to World of Warcraft and befriend some orcs?",
  "id" : 288189483709526016,
  "in_reply_to_status_id" : 288181310973947904,
  "created_at" : "2013-01-07 07:45:01 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 16, 22 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 23, 31 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288187882450063360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7777209796, -122.4153082718 ]
  },
  "id_str" : "288188869243965441",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries @couch @djacobs Accept my vote for making this a more integrated experience. #hackweek",
  "id" : 288188869243965441,
  "in_reply_to_status_id" : 288187882450063360,
  "created_at" : "2013-01-07 07:42:35 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 0, 6 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 7, 15 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 16, 31 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Buster's Stellar.io",
      "screen_name" : "buster_stellar",
      "indices" : [ 68, 83 ],
      "id_str" : "1023497148",
      "id" : 1023497148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288185298138066944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7780115604, -122.4153253304 ]
  },
  "id_str" : "288187415192014848",
  "in_reply_to_user_id" : 631823,
  "text" : "@couch @djacobs @mikeindustries That said, the short time of seeing @buster_stellar's retweets in my timeline has been an enjoyable thing.",
  "id" : 288187415192014848,
  "in_reply_to_status_id" : 288185298138066944,
  "created_at" : "2013-01-07 07:36:48 +0000",
  "in_reply_to_screen_name" : "couch",
  "in_reply_to_user_id_str" : "631823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 0, 6 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 7, 15 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 16, 31 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "wadpaw",
      "screen_name" : "wadpaw",
      "indices" : [ 54, 61 ],
      "id_str" : "789838819",
      "id" : 789838819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288185298138066944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7780259327, -122.415247239 ]
  },
  "id_str" : "288186845412610048",
  "in_reply_to_user_id" : 631823,
  "text" : "@couch @djacobs @mikeindustries I didn't even realize @wadpaw was one of \"them\".",
  "id" : 288186845412610048,
  "in_reply_to_status_id" : 288185298138066944,
  "created_at" : "2013-01-07 07:34:32 +0000",
  "in_reply_to_screen_name" : "couch",
  "in_reply_to_user_id_str" : "631823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rands",
      "screen_name" : "rands",
      "indices" : [ 0, 6 ],
      "id_str" : "30923",
      "id" : 30923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288054630892580864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778178237, -122.4152064856 ]
  },
  "id_str" : "288186020573360128",
  "in_reply_to_user_id" : 30923,
  "text" : "@rands Or rather that monkeys are in charge.",
  "id" : 288186020573360128,
  "in_reply_to_status_id" : 288054630892580864,
  "created_at" : "2013-01-07 07:31:16 +0000",
  "in_reply_to_screen_name" : "rands",
  "in_reply_to_user_id_str" : "30923",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deacon 87",
      "screen_name" : "Deacon87",
      "indices" : [ 0, 9 ],
      "id_str" : "17628107",
      "id" : 17628107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288183503131144193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7811563273, -122.4119288175 ]
  },
  "id_str" : "288183886016573440",
  "in_reply_to_user_id" : 17628107,
  "text" : "@Deacon87 Me too. He's a curious mix of genius and grandpa.",
  "id" : 288183886016573440,
  "in_reply_to_status_id" : 288183503131144193,
  "created_at" : "2013-01-07 07:22:47 +0000",
  "in_reply_to_screen_name" : "Deacon87",
  "in_reply_to_user_id_str" : "17628107",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Morrill",
      "screen_name" : "DanielleMorrill",
      "indices" : [ 0, 16 ],
      "id_str" : "7017692",
      "id" : 7017692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288182363484200961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7835215082, -122.4074847041 ]
  },
  "id_str" : "288182766045106176",
  "in_reply_to_user_id" : 7017692,
  "text" : "@DanielleMorrill Sometimes you gotta trust your gut. Long term impact is the real metric anyway. Good luck!",
  "id" : 288182766045106176,
  "in_reply_to_status_id" : 288182363484200961,
  "created_at" : "2013-01-07 07:18:20 +0000",
  "in_reply_to_screen_name" : "DanielleMorrill",
  "in_reply_to_user_id_str" : "7017692",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Morrill",
      "screen_name" : "DanielleMorrill",
      "indices" : [ 0, 16 ],
      "id_str" : "7017692",
      "id" : 7017692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288181175829278720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822381957, -122.4060124533 ]
  },
  "id_str" : "288181692877910016",
  "in_reply_to_user_id" : 7017692,
  "text" : "@DanielleMorrill Yup. And at Amazon. 90% of A\/B tests have no statistical significance. Real meaning is difficult to find.",
  "id" : 288181692877910016,
  "in_reply_to_status_id" : 288181175829278720,
  "created_at" : "2013-01-07 07:14:04 +0000",
  "in_reply_to_screen_name" : "DanielleMorrill",
  "in_reply_to_user_id_str" : "7017692",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7820598217, -122.4042901233 ]
  },
  "id_str" : "288178991494463488",
  "text" : "What's the least used emoji. Is it \uD83D\uDCEF?",
  "id" : 288178991494463488,
  "created_at" : "2013-01-07 07:03:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 0, 13 ],
      "id_str" : "1784841",
      "id" : 1784841
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "believe",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288177499089805312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7820666998, -122.4043067075 ]
  },
  "id_str" : "288177966368829440",
  "in_reply_to_user_id" : 1784841,
  "text" : "@sawickipedia The singularity is coooool. Except for the robot revolution part. #believe",
  "id" : 288177966368829440,
  "in_reply_to_status_id" : 288177499089805312,
  "created_at" : "2013-01-07 06:59:15 +0000",
  "in_reply_to_screen_name" : "sawickipedia",
  "in_reply_to_user_id_str" : "1784841",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurt Revis",
      "screen_name" : "kurtrevis",
      "indices" : [ 0, 10 ],
      "id_str" : "56244113",
      "id" : 56244113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288176856472113152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7820263224, -122.4043423068 ]
  },
  "id_str" : "288177651473055746",
  "in_reply_to_user_id" : 56244113,
  "text" : "@kurtrevis Actual Kindles have a wonky work around. iOS apps have to do a font size dance.",
  "id" : 288177651473055746,
  "in_reply_to_status_id" : 288176856472113152,
  "created_at" : "2013-01-07 06:58:00 +0000",
  "in_reply_to_screen_name" : "kurtrevis",
  "in_reply_to_user_id_str" : "56244113",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 0, 13 ],
      "id_str" : "1784841",
      "id" : 1784841
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "winsallbets",
      "indices" : [ 53, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288177048122454016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7820530413, -122.4042974493 ]
  },
  "id_str" : "288177397445050368",
  "in_reply_to_user_id" : 1784841,
  "text" : "@sawickipedia I've got one foot in and one foot out. #winsallbets",
  "id" : 288177397445050368,
  "in_reply_to_status_id" : 288177048122454016,
  "created_at" : "2013-01-07 06:57:00 +0000",
  "in_reply_to_screen_name" : "sawickipedia",
  "in_reply_to_user_id_str" : "1784841",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Morrill",
      "screen_name" : "DanielleMorrill",
      "indices" : [ 0, 16 ],
      "id_str" : "7017692",
      "id" : 7017692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288174752659566592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7821218191, -122.4042086634 ]
  },
  "id_str" : "288176451310714880",
  "in_reply_to_user_id" : 7017692,
  "text" : "@DanielleMorrill Even most late A\/B test results are the same.",
  "id" : 288176451310714880,
  "in_reply_to_status_id" : 288174752659566592,
  "created_at" : "2013-01-07 06:53:14 +0000",
  "in_reply_to_screen_name" : "DanielleMorrill",
  "in_reply_to_user_id_str" : "7017692",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deacon 87",
      "screen_name" : "Deacon87",
      "indices" : [ 0, 9 ],
      "id_str" : "17628107",
      "id" : 17628107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288175530749091840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7821183909, -122.4042091831 ]
  },
  "id_str" : "288175931841990656",
  "in_reply_to_user_id" : 17628107,
  "text" : "@Deacon87 Are you a Kurzweil fan?",
  "id" : 288175931841990656,
  "in_reply_to_status_id" : 288175530749091840,
  "created_at" : "2013-01-07 06:51:10 +0000",
  "in_reply_to_screen_name" : "Deacon87",
  "in_reply_to_user_id_str" : "17628107",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822350392, -122.4040367784 ]
  },
  "id_str" : "288174249917685760",
  "text" : "Ray Kurzweil is a lucid dreamer.",
  "id" : 288174249917685760,
  "created_at" : "2013-01-07 06:44:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Broome",
      "screen_name" : "rosical",
      "indices" : [ 0, 8 ],
      "id_str" : "140145169",
      "id" : 140145169
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "subtweet",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288171403776237569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822537228, -122.4040072663 ]
  },
  "id_str" : "288173655354138624",
  "in_reply_to_user_id" : 140145169,
  "text" : "@rosical #subtweet",
  "id" : 288173655354138624,
  "in_reply_to_status_id" : 288171403776237569,
  "created_at" : "2013-01-07 06:42:08 +0000",
  "in_reply_to_screen_name" : "rosical",
  "in_reply_to_user_id_str" : "140145169",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DeadWriter",
      "screen_name" : "DeadWriter",
      "indices" : [ 0, 11 ],
      "id_str" : "17660964",
      "id" : 17660964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288169959287308288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822687581, -122.4039940229 ]
  },
  "id_str" : "288171097915019265",
  "in_reply_to_user_id" : 17660964,
  "text" : "@DeadWriter How does he find them? I wanna do that.",
  "id" : 288171097915019265,
  "in_reply_to_status_id" : 288169959287308288,
  "created_at" : "2013-01-07 06:31:58 +0000",
  "in_reply_to_screen_name" : "DeadWriter",
  "in_reply_to_user_id_str" : "17660964",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain Carle",
      "screen_name" : "froginthevalley",
      "indices" : [ 0, 16 ],
      "id_str" : "657693",
      "id" : 657693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288170489606729729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822696058, -122.4039830246 ]
  },
  "id_str" : "288170892272484354",
  "in_reply_to_user_id" : 657693,
  "text" : "@froginthevalley Yeah I filed an erroneous bug last week about this. iPhone-only.",
  "id" : 288170892272484354,
  "in_reply_to_status_id" : 288170489606729729,
  "created_at" : "2013-01-07 06:31:09 +0000",
  "in_reply_to_screen_name" : "froginthevalley",
  "in_reply_to_user_id_str" : "657693",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain Carle",
      "screen_name" : "froginthevalley",
      "indices" : [ 0, 16 ],
      "id_str" : "657693",
      "id" : 657693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288169547956117504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822754586, -122.4039603553 ]
  },
  "id_str" : "288170103667834880",
  "in_reply_to_user_id" : 657693,
  "text" : "@froginthevalley compact and cropped all wonky. :)",
  "id" : 288170103667834880,
  "in_reply_to_status_id" : 288169547956117504,
  "created_at" : "2013-01-07 06:28:01 +0000",
  "in_reply_to_screen_name" : "froginthevalley",
  "in_reply_to_user_id_str" : "657693",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hadacoupleglassestoo",
      "indices" : [ 43, 64 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288168873524596736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822362312, -122.4040268736 ]
  },
  "id_str" : "288169561524690945",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Watch out for that lamppost! #hadacoupleglassestoo",
  "id" : 288169561524690945,
  "in_reply_to_status_id" : 288168873524596736,
  "created_at" : "2013-01-07 06:25:52 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain Carle",
      "screen_name" : "froginthevalley",
      "indices" : [ 0, 16 ],
      "id_str" : "657693",
      "id" : 657693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288168088824860673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78228036, -122.4039583359 ]
  },
  "id_str" : "288169056035536896",
  "in_reply_to_user_id" : 657693,
  "text" : "@froginthevalley Does twitpic use ol' type.js? Card image is wonky. PS why are you using twitpic??",
  "id" : 288169056035536896,
  "in_reply_to_status_id" : 288168088824860673,
  "created_at" : "2013-01-07 06:23:51 +0000",
  "in_reply_to_screen_name" : "froginthevalley",
  "in_reply_to_user_id_str" : "657693",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 73, 80 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288166719275536384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822516103, -122.40401725 ]
  },
  "id_str" : "288167158490464256",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc That *would* be awesome. If I were an author my book would be on @github and people would submit pull requests for my typos.",
  "id" : 288167158490464256,
  "in_reply_to_status_id" : 288166719275536384,
  "created_at" : "2013-01-07 06:16:19 +0000",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288111291338465281",
  "geo" : { },
  "id_str" : "288166370229772288",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm What are you gonna do?",
  "id" : 288166370229772288,
  "in_reply_to_status_id" : 288111291338465281,
  "created_at" : "2013-01-07 06:13:11 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Sposato",
      "screen_name" : "jonathansposato",
      "indices" : [ 0, 16 ],
      "id_str" : "37036797",
      "id" : 37036797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288162096988958720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822578502, -122.4040155688 ]
  },
  "id_str" : "288162458227593216",
  "in_reply_to_user_id" : 37036797,
  "text" : "@jonathansposato In that case you better get on SnapChat pronto.",
  "id" : 288162458227593216,
  "in_reply_to_status_id" : 288162096988958720,
  "created_at" : "2013-01-07 05:57:38 +0000",
  "in_reply_to_screen_name" : "jonathansposato",
  "in_reply_to_user_id_str" : "37036797",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822636864, -122.4040017293 ]
  },
  "id_str" : "288161676979732481",
  "text" : "Do you highlight and note typos in Kindle books in case the author asks you to edit the next edition?",
  "id" : 288161676979732481,
  "created_at" : "2013-01-07 05:54:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Sposato",
      "screen_name" : "jonathansposato",
      "indices" : [ 0, 16 ],
      "id_str" : "37036797",
      "id" : 37036797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288157880723587072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7820693353, -122.4042994269 ]
  },
  "id_str" : "288158849658130432",
  "in_reply_to_user_id" : 37036797,
  "text" : "@jonathansposato I'm surprised. You should have at least 100x that number. Start live-blogging Downton Abbey perhaps? :)",
  "id" : 288158849658130432,
  "in_reply_to_status_id" : 288157880723587072,
  "created_at" : "2013-01-07 05:43:18 +0000",
  "in_reply_to_screen_name" : "jonathansposato",
  "in_reply_to_user_id_str" : "37036797",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Allen",
      "screen_name" : "moustache",
      "indices" : [ 0, 10 ],
      "id_str" : "19783",
      "id" : 19783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288158086596788224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.782269236, -122.4039934104 ]
  },
  "id_str" : "288158563975716864",
  "in_reply_to_user_id" : 19783,
  "text" : "@moustache Hmm. Not on iPhone.",
  "id" : 288158563975716864,
  "in_reply_to_status_id" : 288158086596788224,
  "created_at" : "2013-01-07 05:42:10 +0000",
  "in_reply_to_screen_name" : "moustache",
  "in_reply_to_user_id_str" : "19783",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288157754516967424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822823794, -122.4039510002 ]
  },
  "id_str" : "288158000395460609",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves You should look his talks up on YouTube. He's a bit of a fanatic.",
  "id" : 288158000395460609,
  "in_reply_to_status_id" : 288157754516967424,
  "created_at" : "2013-01-07 05:39:55 +0000",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288155966900424705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822605087, -122.4039845444 ]
  },
  "id_str" : "288156644494434304",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves Not much yet. David Lynch's TM talks give me the creeps a bit. Not you?",
  "id" : 288156644494434304,
  "in_reply_to_status_id" : 288155966900424705,
  "created_at" : "2013-01-07 05:34:32 +0000",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288155817734193153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822676186, -122.4039800233 ]
  },
  "id_str" : "288156454437937152",
  "in_reply_to_user_id" : 43157011,
  "text" : "@BrettRWilkes I'm on the Kindle iPhone app. Good to know that actual Kindles have a better solution though!",
  "id" : 288156454437937152,
  "in_reply_to_status_id" : 288155817734193153,
  "created_at" : "2013-01-07 05:33:47 +0000",
  "in_reply_to_screen_name" : "brettruu",
  "in_reply_to_user_id_str" : "43157011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Garcia",
      "screen_name" : "motherinternet",
      "indices" : [ 0, 15 ],
      "id_str" : "68347135",
      "id" : 68347135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288154226645934081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822398409, -122.4040315076 ]
  },
  "id_str" : "288156005710311424",
  "in_reply_to_user_id" : 6280322,
  "text" : "@motherinternet A curmudgeony review. Enjoining it so far myself. Have you read it?",
  "id" : 288156005710311424,
  "in_reply_to_status_id" : 288154226645934081,
  "created_at" : "2013-01-07 05:32:00 +0000",
  "in_reply_to_screen_name" : "uglymrbetty",
  "in_reply_to_user_id_str" : "6280322",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7820931142, -122.4042556907 ]
  },
  "id_str" : "288153300317122561",
  "text" : "What's your strategy for highlighting a Kindle passage that spans pages? Mine is to shrink the text to micro-sizes.",
  "id" : 288153300317122561,
  "created_at" : "2013-01-07 05:21:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gav",
      "screen_name" : "ukgav",
      "indices" : [ 0, 6 ],
      "id_str" : "232329387",
      "id" : 232329387
    }, {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 7, 13 ],
      "id_str" : "42559115",
      "id" : 42559115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288145410776768512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7821591152, -122.4041645832 ]
  },
  "id_str" : "288151694070652929",
  "in_reply_to_user_id" : 232329387,
  "text" : "@ukgav @joshm Exactly. That's the whole point of this exploration. :)",
  "id" : 288151694070652929,
  "in_reply_to_status_id" : 288145410776768512,
  "created_at" : "2013-01-07 05:14:52 +0000",
  "in_reply_to_screen_name" : "ukgav",
  "in_reply_to_user_id_str" : "232329387",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingsilearnedfromraykurzweil",
      "indices" : [ 79, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7821204509, -122.4042334313 ]
  },
  "id_str" : "288150294318161920",
  "text" : "Hierarchical parallel pattern recognition of a hierarchically-organized world. #thingsilearnedfromraykurzweil",
  "id" : 288150294318161920,
  "created_at" : "2013-01-07 05:09:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7821385835, -122.4041971585 ]
  },
  "id_str" : "288146958504308736",
  "text" : "I'm surprised to learn that Ray Kurzweil practices Transcendental Meditation.",
  "id" : 288146958504308736,
  "created_at" : "2013-01-07 04:56:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 0, 6 ],
      "id_str" : "42559115",
      "id" : 42559115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288143788243841024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7821018551, -122.4042270655 ]
  },
  "id_str" : "288144565112815616",
  "in_reply_to_user_id" : 42559115,
  "text" : "@joshm Interesting point. I'll think about that. And also... trends often span multiple URLs and large trends will appear multiple times.",
  "id" : 288144565112815616,
  "in_reply_to_status_id" : 288143788243841024,
  "created_at" : "2013-01-07 04:46:32 +0000",
  "in_reply_to_screen_name" : "joshm",
  "in_reply_to_user_id_str" : "42559115",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/EXF0xdFV",
      "expanded_url" : "http:\/\/flic.kr\/p\/dJttz1",
      "display_url" : "flic.kr\/p\/dJttz1"
    } ]
  },
  "geo" : { },
  "id_str" : "288142793849843712",
  "text" : "8:36pm My \"personal trends\" data is starting to look more relevant #hackweek http:\/\/t.co\/EXF0xdFV",
  "id" : 288142793849843712,
  "created_at" : "2013-01-07 04:39:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288141476150538240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822010646, -122.4040803545 ]
  },
  "id_str" : "288141616932347905",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Haha oops.",
  "id" : 288141616932347905,
  "in_reply_to_status_id" : 288141476150538240,
  "created_at" : "2013-01-07 04:34:49 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "feels roulette",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/zmKwhTPK",
      "expanded_url" : "http:\/\/dealbook.nytimes.com\/2012\/12\/10\/hsbc-said-to-near-1-9-billion-settlement-over-money-laundering\/",
      "display_url" : "dealbook.nytimes.com\/2012\/12\/10\/hsb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288140611918364672",
  "text" : "RT @steveklabnik: Please read the first sentence of this story. It's too long to tweet, but holy shit. http:\/\/t.co\/zmKwhTPK",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/zmKwhTPK",
        "expanded_url" : "http:\/\/dealbook.nytimes.com\/2012\/12\/10\/hsbc-said-to-near-1-9-billion-settlement-over-money-laundering\/",
        "display_url" : "dealbook.nytimes.com\/2012\/12\/10\/hsb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "287316230648524800",
    "text" : "Please read the first sentence of this story. It's too long to tweet, but holy shit. http:\/\/t.co\/zmKwhTPK",
    "id" : 287316230648524800,
    "created_at" : "2013-01-04 21:55:02 +0000",
    "user" : {
      "name" : "feels roulette",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/437278932123934720\/V_FfX3x7_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 288140611918364672,
  "created_at" : "2013-01-07 04:30:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 12, 26 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/FIEZ9sxV",
      "expanded_url" : "http:\/\/flic.kr\/s\/aHsjDwf641",
      "display_url" : "flic.kr\/s\/aHsjDwf641"
    } ]
  },
  "geo" : { },
  "id_str" : "288135174359760896",
  "text" : "Inspired by @carinnatarvin's Best of 2013 Flickr set, I made one too. Made lovingly in Flickr's iPhone app. Try http:\/\/t.co\/FIEZ9sxV",
  "id" : 288135174359760896,
  "created_at" : "2013-01-07 04:09:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288121300814266368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7820442645, -122.4043252242 ]
  },
  "id_str" : "288127088056225793",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin That was fun to look through! I wanna make one now too.",
  "id" : 288127088056225793,
  "in_reply_to_status_id" : 288121300814266368,
  "created_at" : "2013-01-07 03:37:05 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/hjdl40NN",
      "expanded_url" : "http:\/\/wayoftheduck.com\/fitbit-zip",
      "display_url" : "wayoftheduck.com\/fitbit-zip"
    } ]
  },
  "in_reply_to_status_id_str" : "288109492246302720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7777232282, -122.4152124834 ]
  },
  "id_str" : "288111491415166977",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver That said, my current fave: http:\/\/t.co\/hjdl40NN",
  "id" : 288111491415166977,
  "in_reply_to_status_id" : 288109492246302720,
  "created_at" : "2013-01-07 02:35:07 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288109492246302720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778131733, -122.4153273181 ]
  },
  "id_str" : "288111204994514944",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver Not really. I've used them all. It's like the days when I tried 5x to like Palm Pilots. Never stuck. Then the iPhone comes out.",
  "id" : 288111204994514944,
  "in_reply_to_status_id" : 288109492246302720,
  "created_at" : "2013-01-07 02:33:58 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notbadatall",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7777795203, -122.4151922562 ]
  },
  "id_str" : "288110777066463233",
  "text" : "Solo dinner at restaurant with Kindle wins again! #notbadatall",
  "id" : 288110777066463233,
  "created_at" : "2013-01-07 02:32:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288107212335902720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778500028, -122.4152098256 ]
  },
  "id_str" : "288107968975732737",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger Let's try again end of month? I'll be here permanently at that point!",
  "id" : 288107968975732737,
  "in_reply_to_status_id" : 288107212335902720,
  "created_at" : "2013-01-07 02:21:07 +0000",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288106669471326210",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778579103, -122.4150373578 ]
  },
  "id_str" : "288106958454657024",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger Tonight? :)",
  "id" : 288106958454657024,
  "in_reply_to_status_id" : 288106669471326210,
  "created_at" : "2013-01-07 02:17:06 +0000",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778296992, -122.4152323736 ]
  },
  "id_str" : "288106014656581632",
  "text" : "Who's out and about in SF tonight?",
  "id" : 288106014656581632,
  "created_at" : "2013-01-07 02:13:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 0, 6 ],
      "id_str" : "42559115",
      "id" : 42559115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288080069157584896",
  "geo" : { },
  "id_str" : "288083634043359233",
  "in_reply_to_user_id" : 42559115,
  "text" : "@joshm Send me your ideas and maybe I can be your proxy hackweeker! :)",
  "id" : 288083634043359233,
  "in_reply_to_status_id" : 288080069157584896,
  "created_at" : "2013-01-07 00:44:25 +0000",
  "in_reply_to_screen_name" : "joshm",
  "in_reply_to_user_id_str" : "42559115",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 8, 16 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Mike D. Stellar Feed",
      "screen_name" : "mike_stellar",
      "indices" : [ 108, 121 ],
      "id_str" : "474428523",
      "id" : 474428523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288074083910959107",
  "geo" : { },
  "id_str" : "288076765908332544",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez @djacobs I must not be paying very close attention. So they're just retweeting the same things that @mike_stellar does? Not good.",
  "id" : 288076765908332544,
  "in_reply_to_status_id" : 288074083910959107,
  "created_at" : "2013-01-07 00:17:07 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Mike D. Stellar Feed",
      "screen_name" : "mike_stellar",
      "indices" : [ 13, 26 ],
      "id_str" : "474428523",
      "id" : 474428523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288070867567648768",
  "geo" : { },
  "id_str" : "288073190184468480",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs Oh, @mike_stellar is the only stellar bot I have run across\u2026 do you see multiple stellar bots with overlapping friend networks?",
  "id" : 288073190184468480,
  "in_reply_to_status_id" : 288070867567648768,
  "created_at" : "2013-01-07 00:02:55 +0000",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288069423007404033",
  "geo" : { },
  "id_str" : "288070114371321858",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs I do understand the interactions clutter, but it's a signal of its own in a way. Solve a problem = create new problems.",
  "id" : 288070114371321858,
  "in_reply_to_status_id" : 288069423007404033,
  "created_at" : "2013-01-06 23:50:42 +0000",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "indices" : [ 0, 5 ],
      "id_str" : "10221",
      "id" : 10221
    }, {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 6, 20 ],
      "id_str" : "18749271",
      "id" : 18749271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288068602899333120",
  "geo" : { },
  "id_str" : "288069014142476292",
  "in_reply_to_user_id" : 10221,
  "text" : "@drew @libbybrittain Create a twitter account that you want to RT from and email me buster@twitter.com. Also, you need a stellar.io account.",
  "id" : 288069014142476292,
  "in_reply_to_status_id" : 288068602899333120,
  "created_at" : "2013-01-06 23:46:19 +0000",
  "in_reply_to_screen_name" : "drew",
  "in_reply_to_user_id_str" : "10221",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 0, 6 ],
      "id_str" : "42559115",
      "id" : 42559115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288068070705074177",
  "geo" : { },
  "id_str" : "288068370883018752",
  "in_reply_to_user_id" : 42559115,
  "text" : "@joshm Ok! Create a @josh_stellar (or something) twitter account, and email me at buster@twitter.com and I'll send you more instructions.",
  "id" : 288068370883018752,
  "in_reply_to_status_id" : 288068070705074177,
  "created_at" : "2013-01-06 23:43:46 +0000",
  "in_reply_to_screen_name" : "joshm",
  "in_reply_to_user_id_str" : "42559115",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288067300605693952",
  "geo" : { },
  "id_str" : "288067698074738688",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs They do use stellar.io\u2026 just the RSS feed instead of the website. I'm trying it to see if it's good or not. An experiment.",
  "id" : 288067698074738688,
  "in_reply_to_status_id" : 288067300605693952,
  "created_at" : "2013-01-06 23:41:05 +0000",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288067059198357504",
  "geo" : { },
  "id_str" : "288067264434016256",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm Check your work email.",
  "id" : 288067264434016256,
  "in_reply_to_status_id" : 288067059198357504,
  "created_at" : "2013-01-06 23:39:22 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288065561043279872",
  "geo" : { },
  "id_str" : "288066768633737216",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm It is! The workaround here requires a stellar.io account, do you have one yet? If not I can send you an invite.",
  "id" : 288066768633737216,
  "in_reply_to_status_id" : 288065561043279872,
  "created_at" : "2013-01-06 23:37:24 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 12, 27 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Mike D. Stellar Feed",
      "screen_name" : "mike_stellar",
      "indices" : [ 36, 49 ],
      "id_str" : "474428523",
      "id" : 474428523
    }, {
      "name" : "Buster's Stellar.io",
      "screen_name" : "buster_stellar",
      "indices" : [ 80, 95 ],
      "id_str" : "1023497148",
      "id" : 1023497148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288064867741622272",
  "text" : "Inspired by @mikeindustries and his @mike_stellar bot, I've created one for me: @buster_stellar. Who else wants one?",
  "id" : 288064867741622272,
  "created_at" : "2013-01-06 23:29:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288062086016299008",
  "geo" : { },
  "id_str" : "288064420632989696",
  "in_reply_to_user_id" : 352927399,
  "text" : "@JohnMBower By calibrating. For example, scoring an RT on a tweet by someone with 100 followers the same as 100 RTs by someone with 10,000.",
  "id" : 288064420632989696,
  "in_reply_to_status_id" : 288062086016299008,
  "created_at" : "2013-01-06 23:28:04 +0000",
  "in_reply_to_screen_name" : "JohnMABower",
  "in_reply_to_user_id_str" : "352927399",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 0, 8 ],
      "id_str" : "291",
      "id" : 291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288061051063382017",
  "geo" : { },
  "id_str" : "288064108044099586",
  "in_reply_to_user_id" : 291,
  "text" : "@goldman Agreed. And the Discover tab is inching in that direction, but I like the idea of it still using a subtle variety of \"follow\".",
  "id" : 288064108044099586,
  "in_reply_to_status_id" : 288061051063382017,
  "created_at" : "2013-01-06 23:26:49 +0000",
  "in_reply_to_screen_name" : "goldman",
  "in_reply_to_user_id_str" : "291",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cheri Roberts",
      "screen_name" : "CheriSpeak",
      "indices" : [ 0, 11 ],
      "id_str" : "558885462",
      "id" : 558885462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288054773326938112",
  "geo" : { },
  "id_str" : "288056914946949121",
  "in_reply_to_user_id" : 558885462,
  "text" : "@CheriSpeak How so?",
  "id" : 288056914946949121,
  "in_reply_to_status_id" : 288054773326938112,
  "created_at" : "2013-01-06 22:58:15 +0000",
  "in_reply_to_screen_name" : "CheriSpeak",
  "in_reply_to_user_id_str" : "558885462",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288054281477689345",
  "geo" : { },
  "id_str" : "288056807778304000",
  "in_reply_to_user_id" : 352927399,
  "text" : "@JohnMBower The difference would be that this is opt-in. You choose who you want to fuzzy follow. It wouldn't be very many people.",
  "id" : 288056807778304000,
  "in_reply_to_status_id" : 288054281477689345,
  "created_at" : "2013-01-06 22:57:49 +0000",
  "in_reply_to_screen_name" : "JohnMABower",
  "in_reply_to_user_id_str" : "352927399",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 37, 46 ]
    }, {
      "text" : "hackweek",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288053790618296320",
  "text" : "Taking a short break from my primary #hackweek project to work on a small side #hackweek project.",
  "id" : 288053790618296320,
  "created_at" : "2013-01-06 22:45:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Cox",
      "screen_name" : "acox",
      "indices" : [ 0, 5 ],
      "id_str" : "8756332",
      "id" : 8756332
    }, {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 6, 14 ],
      "id_str" : "353195232",
      "id" : 353195232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288047850171019264",
  "geo" : { },
  "id_str" : "288048001044320256",
  "in_reply_to_user_id" : 8756332,
  "text" : "@acox @liftapp is pretty great. I assume you've tried them?",
  "id" : 288048001044320256,
  "in_reply_to_status_id" : 288047850171019264,
  "created_at" : "2013-01-06 22:22:49 +0000",
  "in_reply_to_screen_name" : "acox",
  "in_reply_to_user_id_str" : "8756332",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Cox",
      "screen_name" : "acox",
      "indices" : [ 0, 5 ],
      "id_str" : "8756332",
      "id" : 8756332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288041804174073857",
  "geo" : { },
  "id_str" : "288046769999323136",
  "in_reply_to_user_id" : 8756332,
  "text" : "@acox Woah that was years ago. I think I did, and then the domain expired. What are you looking for?",
  "id" : 288046769999323136,
  "in_reply_to_status_id" : 288041804174073857,
  "created_at" : "2013-01-06 22:17:56 +0000",
  "in_reply_to_screen_name" : "acox",
  "in_reply_to_user_id_str" : "8756332",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288022644085907457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763013165, -122.418093327 ]
  },
  "id_str" : "288027778085953536",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm Thanks!",
  "id" : 288027778085953536,
  "in_reply_to_status_id" : 288022644085907457,
  "created_at" : "2013-01-06 21:02:28 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sunday",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "timeshifted",
      "indices" : [ 8, 20 ]
    }, {
      "text" : "hackweek",
      "indices" : [ 21, 30 ]
    }, {
      "text" : "canaryinatimeline",
      "indices" : [ 31, 49 ]
    }, {
      "text" : "inbed",
      "indices" : [ 50, 56 ]
    }, {
      "text" : "pajamas",
      "indices" : [ 57, 65 ]
    }, {
      "text" : "hotel",
      "indices" : [ 66, 72 ]
    }, {
      "text" : "hungry",
      "indices" : [ 73, 80 ]
    }, {
      "text" : "needfood",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288019354711371777",
  "text" : "#sunday #timeshifted #hackweek #canaryinatimeline #inbed #pajamas #hotel #hungry #needfood",
  "id" : 288019354711371777,
  "created_at" : "2013-01-06 20:28:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yaqui n\u00FA\u00F1ez",
      "screen_name" : "yaqui",
      "indices" : [ 0, 6 ],
      "id_str" : "638283",
      "id" : 638283
    }, {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 40, 47 ],
      "id_str" : "494518813",
      "id" : 494518813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288017636690907136",
  "geo" : { },
  "id_str" : "288018006100029440",
  "in_reply_to_user_id" : 638283,
  "text" : "@yaqui Awesome. Yes, I need IDEAS. More @branch-ing.",
  "id" : 288018006100029440,
  "in_reply_to_status_id" : 288017636690907136,
  "created_at" : "2013-01-06 20:23:38 +0000",
  "in_reply_to_screen_name" : "yaqui",
  "in_reply_to_user_id_str" : "638283",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yaqui n\u00FA\u00F1ez",
      "screen_name" : "yaqui",
      "indices" : [ 0, 6 ],
      "id_str" : "638283",
      "id" : 638283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288017159567859712",
  "geo" : { },
  "id_str" : "288017455866060800",
  "in_reply_to_user_id" : 638283,
  "text" : "@yaqui In a couple days, yeah. Still taking it down quite often.",
  "id" : 288017455866060800,
  "in_reply_to_status_id" : 288017159567859712,
  "created_at" : "2013-01-06 20:21:27 +0000",
  "in_reply_to_screen_name" : "yaqui",
  "in_reply_to_user_id_str" : "638283",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logan Bowers",
      "screen_name" : "loganb",
      "indices" : [ 0, 7 ],
      "id_str" : "6072622",
      "id" : 6072622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "longlivegooglereader",
      "indices" : [ 71, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288016196589215744",
  "geo" : { },
  "id_str" : "288017277717204992",
  "in_reply_to_user_id" : 6072622,
  "text" : "@loganb Wasn't \"share\" the same as RT? I do remember liking it though. #longlivegooglereader",
  "id" : 288017277717204992,
  "in_reply_to_status_id" : 288016196589215744,
  "created_at" : "2013-01-06 20:20:44 +0000",
  "in_reply_to_screen_name" : "loganb",
  "in_reply_to_user_id_str" : "6072622",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288014094731202560",
  "geo" : { },
  "id_str" : "288014506343399424",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman They definitely could. But then again, if the food has a label, it's probably not *that* healthy.",
  "id" : 288014506343399424,
  "in_reply_to_status_id" : 288014094731202560,
  "created_at" : "2013-01-06 20:09:44 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/288013478466306048\/photo\/1",
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/8NagowaO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_86u5MCQAEuRSK.png",
      "id_str" : "288013478474694657",
      "id" : 288013478474694657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_86u5MCQAEuRSK.png",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/8NagowaO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288013478466306048",
  "text" : "Here's a screenshot of some preliminary \"personal trends\" data based on 3 timelines I'm following. http:\/\/t.co\/8NagowaO",
  "id" : 288013478466306048,
  "created_at" : "2013-01-06 20:05:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288007410449252353",
  "geo" : { },
  "id_str" : "288008959850328064",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman Versus the real things we should be measuring: nutrient density, glycemic load (how steeply glucose spikes), and fiber density.",
  "id" : 288008959850328064,
  "in_reply_to_status_id" : 288007410449252353,
  "created_at" : "2013-01-06 19:47:41 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288007410449252353",
  "geo" : { },
  "id_str" : "288007725445689344",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman It's over-precise, in my opinion. A classic case of measuring the wrong thing because it is easily measured.",
  "id" : 288007725445689344,
  "in_reply_to_status_id" : 288007410449252353,
  "created_at" : "2013-01-06 19:42:47 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 0, 11 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288004359642562562",
  "geo" : { },
  "id_str" : "288005176869130241",
  "in_reply_to_user_id" : 26123649,
  "text" : "@brianellin Me too. But what if I could hand-pick a few people who I know follow a unique &amp; smart set of people, and see their best tweets?",
  "id" : 288005176869130241,
  "in_reply_to_status_id" : 288004359642562562,
  "created_at" : "2013-01-06 19:32:39 +0000",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh MacLeod",
      "screen_name" : "gapingvoid",
      "indices" : [ 58, 69 ],
      "id_str" : "50193",
      "id" : 50193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/unzI6dQj",
      "expanded_url" : "http:\/\/gapingvoid.com\/2013\/01\/06\/starting-points\/",
      "display_url" : "gapingvoid.com\/2013\/01\/06\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7781037691, -122.4150982932 ]
  },
  "id_str" : "288001102979420160",
  "text" : "\"All points are starting points\" http:\/\/t.co\/unzI6dQj \/by @gapingvoid",
  "id" : 288001102979420160,
  "created_at" : "2013-01-06 19:16:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/RVEMaLr8",
      "expanded_url" : "http:\/\/on.branch.com\/136N8cN#BD0DA4WIC4s",
      "display_url" : "on.branch.com\/136N8cN#BD0DA4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288000591039430657",
  "text" : "What if we could \"fuzzy follow\" people... getting the best tweets that they *read* instead of the tweets they wrote? http:\/\/t.co\/RVEMaLr8",
  "id" : 288000591039430657,
  "created_at" : "2013-01-06 19:14:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287985188330426371",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7781897232, -122.414946628 ]
  },
  "id_str" : "287985880935854080",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap So it's gonna be controversial? Good!",
  "id" : 287985880935854080,
  "in_reply_to_status_id" : 287985188330426371,
  "created_at" : "2013-01-06 18:15:59 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287984360894906368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778941791, -122.4151985377 ]
  },
  "id_str" : "287984879633846272",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap Nice, let's see it!",
  "id" : 287984879633846272,
  "in_reply_to_status_id" : 287984360894906368,
  "created_at" : "2013-01-06 18:12:00 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287982477342027776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778936813, -122.4151733513 ]
  },
  "id_str" : "287984437738762241",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman I saw something about a skin sensor that could estimate calories in and out. I doubt it will be mass market for a while though.",
  "id" : 287984437738762241,
  "in_reply_to_status_id" : 287982477342027776,
  "created_at" : "2013-01-06 18:10:15 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sung Hu Kim",
      "screen_name" : "sunghu",
      "indices" : [ 3, 10 ],
      "id_str" : "11407672",
      "id" : 11407672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/ekf8yezH",
      "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/culture\/2013\/01\/video-the-art-of-pickpocketing.html",
      "display_url" : "newyorker.com\/online\/blogs\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "287979786452754433",
  "text" : "RT @sunghu: Amazing video of the world's greatest pickpocket showing his tricks and techniques: http:\/\/t.co\/ekf8yezH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/ekf8yezH",
        "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/culture\/2013\/01\/video-the-art-of-pickpocketing.html",
        "display_url" : "newyorker.com\/online\/blogs\/c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "287962847382740992",
    "text" : "Amazing video of the world's greatest pickpocket showing his tricks and techniques: http:\/\/t.co\/ekf8yezH",
    "id" : 287962847382740992,
    "created_at" : "2013-01-06 16:44:27 +0000",
    "user" : {
      "name" : "Sung Hu Kim",
      "screen_name" : "sunghu",
      "protected" : false,
      "id_str" : "11407672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/865738636\/Sung_Hu_Kim_HQ_normal.jpg",
      "id" : 11407672,
      "verified" : false
    }
  },
  "id" : 287979786452754433,
  "created_at" : "2013-01-06 17:51:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sangiorgio",
      "screen_name" : "mariosangiorgio",
      "indices" : [ 0, 16 ],
      "id_str" : "244515103",
      "id" : 244515103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287870430189088768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7777759501, -122.4151250826 ]
  },
  "id_str" : "287972406574870528",
  "in_reply_to_user_id" : 244515103,
  "text" : "@mariosangiorgio Yup exactly.",
  "id" : 287972406574870528,
  "in_reply_to_status_id" : 287870430189088768,
  "created_at" : "2013-01-06 17:22:26 +0000",
  "in_reply_to_screen_name" : "mariosangiorgio",
  "in_reply_to_user_id_str" : "244515103",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/1dYjky4o",
      "expanded_url" : "http:\/\/flic.kr\/p\/dJ15fa",
      "display_url" : "flic.kr\/p\/dJ15fa"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.777, -122.417167 ]
  },
  "id_str" : "287785395192737792",
  "text" : "8:36pm Got pretty far on my #hackweek project, code name Canary in a Timeline http:\/\/t.co\/1dYjky4o",
  "id" : 287785395192737792,
  "created_at" : "2013-01-06 04:59:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "indices" : [ 3, 16 ],
      "id_str" : "1186",
      "id" : 1186
    }, {
      "name" : "Sam Bates",
      "screen_name" : "samb8s",
      "indices" : [ 18, 25 ],
      "id_str" : "39796783",
      "id" : 39796783
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 26, 33 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FiscalCliff",
      "indices" : [ 34, 46 ]
    }, {
      "text" : "GANGNAMSTYLE",
      "indices" : [ 51, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287717886385061888",
  "text" : "RT @chrismessina: @samb8s @buster #FiscalCliff and #GANGNAMSTYLE are hashtags, so by the process of transitive elimination, hashtags had ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Bates",
        "screen_name" : "samb8s",
        "indices" : [ 0, 7 ],
        "id_str" : "39796783",
        "id" : 39796783
      }, {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 8, 15 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FiscalCliff",
        "indices" : [ 16, 28 ]
      }, {
        "text" : "GANGNAMSTYLE",
        "indices" : [ 33, 46 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "287717037239828481",
    "geo" : { },
    "id_str" : "287717742755319808",
    "in_reply_to_user_id" : 39796783,
    "text" : "@samb8s @buster #FiscalCliff and #GANGNAMSTYLE are hashtags, so by the process of transitive elimination, hashtags had to win.",
    "id" : 287717742755319808,
    "in_reply_to_status_id" : 287717037239828481,
    "created_at" : "2013-01-06 00:30:30 +0000",
    "in_reply_to_screen_name" : "samb8s",
    "in_reply_to_user_id_str" : "39796783",
    "user" : {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "protected" : false,
      "id_str" : "1186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447092175256305664\/YXDvxb_9_normal.jpeg",
      "id" : 1186,
      "verified" : false
    }
  },
  "id" : 287717886385061888,
  "created_at" : "2013-01-06 00:31:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "indices" : [ 116, 129 ],
      "id_str" : "1186",
      "id" : 1186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/3wxDjjIr",
      "expanded_url" : "http:\/\/www.theverge.com\/2013\/1\/5\/3840210\/hashtag-word-of-the-year-american-dialect-society",
      "display_url" : "theverge.com\/2013\/1\/5\/38402\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "287715513403068417",
  "text" : "'Hashtag' named word of the year, beating out \"YOLO,\" \"Fiscal cliff,\" and \"Gangnam style.\" http:\/\/t.co\/3wxDjjIr \/cc @chrismessina",
  "id" : 287715513403068417,
  "created_at" : "2013-01-06 00:21:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287682913217155072",
  "geo" : { },
  "id_str" : "287684392145530880",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler Thanks! I've prototyped it before but it'll be fun to take it a couple steps further.",
  "id" : 287684392145530880,
  "in_reply_to_status_id" : 287682913217155072,
  "created_at" : "2013-01-05 22:17:58 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287681438562799616",
  "geo" : { },
  "id_str" : "287684303385669635",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc I'm gonna try and pull personal trends from your home timeline (see last few tweets).",
  "id" : 287684303385669635,
  "in_reply_to_status_id" : 287681438562799616,
  "created_at" : "2013-01-05 22:17:37 +0000",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287624102854926336",
  "geo" : { },
  "id_str" : "287680415072923648",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc What are you going to do this time?",
  "id" : 287680415072923648,
  "in_reply_to_status_id" : 287624102854926336,
  "created_at" : "2013-01-05 22:02:10 +0000",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.branch.com\" rel=\"nofollow\"\u003EBranch Inc\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 0, 12 ],
      "id_str" : "930061",
      "id" : 930061
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 13, 22 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/W8DStq3q",
      "expanded_url" : "http:\/\/branch.com\/b\/how-would-you-design-a-twitter-personal-trends-service?showsignin=true&inviter=Buster%20Benson",
      "display_url" : "branch.com\/b\/how-would-yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "287660788871725056",
  "in_reply_to_user_id" : 930061,
  "text" : "@ginatrapani @anildash I just added you to my branch about \u201CHow would you design a Twitter \"personal trends\" service?\u201D http:\/\/t.co\/W8DStq3q",
  "id" : 287660788871725056,
  "created_at" : "2013-01-05 20:44:11 +0000",
  "in_reply_to_screen_name" : "ginatrapani",
  "in_reply_to_user_id_str" : "930061",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 10, 22 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287659879483707392",
  "geo" : { },
  "id_str" : "287660069703790592",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @ginatrapani That's partially why I want to do this, so that I can give you better feedback on how to build this into ThinkUp!",
  "id" : 287660069703790592,
  "in_reply_to_status_id" : 287659879483707392,
  "created_at" : "2013-01-05 20:41:19 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sangiorgio",
      "screen_name" : "mariosangiorgio",
      "indices" : [ 0, 16 ],
      "id_str" : "244515103",
      "id" : 244515103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287653909865041920",
  "geo" : { },
  "id_str" : "287656857479307264",
  "in_reply_to_user_id" : 244515103,
  "text" : "@mariosangiorgio Not sure yet. Something attention-worthy, or at least more so than the average.",
  "id" : 287656857479307264,
  "in_reply_to_status_id" : 287653909865041920,
  "created_at" : "2013-01-05 20:28:33 +0000",
  "in_reply_to_screen_name" : "mariosangiorgio",
  "in_reply_to_user_id_str" : "244515103",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Shapiro",
      "screen_name" : "ZackShapiro",
      "indices" : [ 0, 12 ],
      "id_str" : "15999465",
      "id" : 15999465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287656174164250624",
  "geo" : { },
  "id_str" : "287656556949032961",
  "in_reply_to_user_id" : 15999465,
  "text" : "@ZackShapiro I actually used them when I prototyped this a few months ago. Very cool API.",
  "id" : 287656556949032961,
  "in_reply_to_status_id" : 287656174164250624,
  "created_at" : "2013-01-05 20:27:22 +0000",
  "in_reply_to_screen_name" : "ZackShapiro",
  "in_reply_to_user_id_str" : "15999465",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 82, 91 ]
    }, {
      "text" : "personaltrends",
      "indices" : [ 92, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287653455311540225",
  "text" : "If anyone knows of existing implementations of this idea, send 'em my way please! #hackweek #personaltrends",
  "id" : 287653455311540225,
  "created_at" : "2013-01-05 20:15:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287652732364533760",
  "text" : "It should ping me when something important is happening in my timeline, maybe even before I see it myself. #hackweek",
  "id" : 287652732364533760,
  "created_at" : "2013-01-05 20:12:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 3, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287652177848188928",
  "text" : "My #hackweek project (which I hope only takes a couple days) is to try to pull out personal trends from your home timeline.",
  "id" : 287652177848188928,
  "created_at" : "2013-01-05 20:09:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 12, 20 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287651228626866176",
  "text" : "Starting my @twitter #hackweek project a couple days early.",
  "id" : 287651228626866176,
  "created_at" : "2013-01-05 20:06:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Bryce Roberts",
      "screen_name" : "bryce",
      "indices" : [ 10, 16 ],
      "id_str" : "6160742",
      "id" : 6160742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287626443087835137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7766674458, -122.418074945 ]
  },
  "id_str" : "287632715916914688",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert @bryce Whenever Niko uses the toilet a Kermit the Frog pez dispenser flies down from the shelf to Darth Vader's theme song.",
  "id" : 287632715916914688,
  "in_reply_to_status_id" : 287626443087835137,
  "created_at" : "2013-01-05 18:52:38 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 82, 90 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/TmnfuLZp",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/ryanhatesthis\/the-54-best-animated-gifs-of-2012",
      "display_url" : "buzzfeed.com\/ryanhatesthis\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7777052285, -122.4152490145 ]
  },
  "id_str" : "287531707454857216",
  "text" : "54 best animated gifs of 2012, brought to you by the late night Twitter insomnia, @rsarver's question, and #6 http:\/\/t.co\/TmnfuLZp",
  "id" : 287531707454857216,
  "created_at" : "2013-01-05 12:11:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Strick v L",
      "screen_name" : "strickvl",
      "indices" : [ 0, 9 ],
      "id_str" : "14439930",
      "id" : 14439930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/EBjDeEMZ",
      "expanded_url" : "http:\/\/750words.com\/help\/request_help",
      "display_url" : "750words.com\/help\/request_h\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "287525935681507328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778878687, -122.4151006542 ]
  },
  "id_str" : "287526577305182209",
  "in_reply_to_user_id" : 14439930,
  "text" : "@strickvl Have you submitted a request for help to http:\/\/t.co\/EBjDeEMZ? If not can you do that?",
  "id" : 287526577305182209,
  "in_reply_to_status_id" : 287525935681507328,
  "created_at" : "2013-01-05 11:50:52 +0000",
  "in_reply_to_screen_name" : "strickvl",
  "in_reply_to_user_id_str" : "14439930",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Strick v L",
      "screen_name" : "strickvl",
      "indices" : [ 0, 9 ],
      "id_str" : "14439930",
      "id" : 14439930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287480151271436288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778653821, -122.415246546 ]
  },
  "id_str" : "287525394205274114",
  "in_reply_to_user_id" : 14439930,
  "text" : "@strickvl We try our best but don't have full time support. What's the problem?",
  "id" : 287525394205274114,
  "in_reply_to_status_id" : 287480151271436288,
  "created_at" : "2013-01-05 11:46:10 +0000",
  "in_reply_to_screen_name" : "strickvl",
  "in_reply_to_user_id_str" : "14439930",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/kZCVG9tm",
      "expanded_url" : "http:\/\/flic.kr\/p\/dHJfrB",
      "display_url" : "flic.kr\/p\/dHJfrB"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.771333, -122.424 ]
  },
  "id_str" : "287525090076278784",
  "text" : "8:36pm Dinner and good conversation http:\/\/t.co\/kZCVG9tm",
  "id" : 287525090076278784,
  "created_at" : "2013-01-05 11:44:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Robertson",
      "screen_name" : "Loobylu",
      "indices" : [ 0, 8 ],
      "id_str" : "653333",
      "id" : 653333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287302799899914242",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7766314799, -122.4168716603 ]
  },
  "id_str" : "287308300360499200",
  "in_reply_to_user_id" : 653333,
  "text" : "@Loobylu Ooh cool! Can you tweet the ones that make it to the blog too?",
  "id" : 287308300360499200,
  "in_reply_to_status_id" : 287302799899914242,
  "created_at" : "2013-01-04 21:23:31 +0000",
  "in_reply_to_screen_name" : "Loobylu",
  "in_reply_to_user_id_str" : "653333",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K. Thor Jensen",
      "screen_name" : "kthorjensen",
      "indices" : [ 0, 12 ],
      "id_str" : "25319959",
      "id" : 25319959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287276447184343040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769858416, -122.4171476535 ]
  },
  "id_str" : "287276781864624128",
  "in_reply_to_user_id" : 25319959,
  "text" : "@kthorjensen I think it might be n\/2 cups.",
  "id" : 287276781864624128,
  "in_reply_to_status_id" : 287276447184343040,
  "created_at" : "2013-01-04 19:18:16 +0000",
  "in_reply_to_screen_name" : "kthorjensen",
  "in_reply_to_user_id_str" : "25319959",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287263888477659136",
  "geo" : { },
  "id_str" : "287264538234073088",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc It's still very buggy\/unfinished\u2026 if you're not using the current one sure, or you might want to wait til it's a bit more stable.",
  "id" : 287264538234073088,
  "in_reply_to_status_id" : 287263888477659136,
  "created_at" : "2013-01-04 18:29:37 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287257059542589440",
  "geo" : { },
  "id_str" : "287264348378902528",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc And every iPhone thief should be charged the same as a kidney stealer.",
  "id" : 287264348378902528,
  "in_reply_to_status_id" : 287257059542589440,
  "created_at" : "2013-01-04 18:28:52 +0000",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vivek Wadhwa",
      "screen_name" : "wadhwa",
      "indices" : [ 58, 65 ],
      "id_str" : "32718488",
      "id" : 32718488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/unfrsbHm",
      "expanded_url" : "http:\/\/m.washingtonpost.com\/national\/on-innovations\/ethics-in-the-age-of-acceleration\/2012\/07\/13\/gJQAzVDUiW_story.html",
      "display_url" : "m.washingtonpost.com\/national\/on-in\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7777840441, -122.4153050752 ]
  },
  "id_str" : "287255187842793472",
  "text" : "Ethics in an age of acceleration http:\/\/t.co\/unfrsbHm \/by @wadhwa",
  "id" : 287255187842793472,
  "created_at" : "2013-01-04 17:52:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/jj4Z6HjT",
      "expanded_url" : "http:\/\/wayoftheduck.com\/starter-kit",
      "display_url" : "wayoftheduck.com\/starter-kit"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7777702882, -122.4151975001 ]
  },
  "id_str" : "287245473532768256",
  "text" : "Starter kit for a solar-powered 3D printer that can make enough $$ to buy parts, pick 'em up, and print its children. http:\/\/t.co\/jj4Z6HjT",
  "id" : 287245473532768256,
  "created_at" : "2013-01-04 17:13:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778379335, -122.4152301527 ]
  },
  "id_str" : "287142142105759744",
  "text" : "I'm convinced the new Kurzweil book was written for me. Recursion, pattern matching, identity, free will, robots, the future, and the brain!",
  "id" : 287142142105759744,
  "created_at" : "2013-01-04 10:23:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7780513833, -122.4151720722 ]
  },
  "id_str" : "287135732072583168",
  "text" : "Recursive replication is DNA. Recursive thinking is intelligence.",
  "id" : 287135732072583168,
  "created_at" : "2013-01-04 09:57:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Galef",
      "screen_name" : "juliagalef",
      "indices" : [ 13, 24 ],
      "id_str" : "18691746",
      "id" : 18691746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287119275209146368",
  "text" : "@arjanharing @juliagalef Thanks, Arjan, looking at it now. I wish I could just read the glossary and immediately be cured of cognitive bias.",
  "id" : 287119275209146368,
  "created_at" : "2013-01-04 08:52:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Galef",
      "screen_name" : "juliagalef",
      "indices" : [ 0, 11 ],
      "id_str" : "18691746",
      "id" : 18691746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/1h1q58Ju",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/List_of_cognitive_biases",
      "display_url" : "en.wikipedia.org\/wiki\/List_of_c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "287117284164653056",
  "in_reply_to_user_id" : 18691746,
  "text" : "@juliagalef What's your favorite go-to list of cognitive biases and strategies to thwart them? Something simpler than http:\/\/t.co\/1h1q58Ju",
  "id" : 287117284164653056,
  "created_at" : "2013-01-04 08:44:29 +0000",
  "in_reply_to_screen_name" : "juliagalef",
  "in_reply_to_user_id_str" : "18691746",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287099598575661056",
  "geo" : { },
  "id_str" : "287104117292294144",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Totally. Stoked for the ability to upload my entire Twitter archive too. So fun.",
  "id" : 287104117292294144,
  "in_reply_to_status_id" : 287099598575661056,
  "created_at" : "2013-01-04 07:52:10 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThinkUp",
      "screen_name" : "thinkup",
      "indices" : [ 7, 15 ],
      "id_str" : "100127476",
      "id" : 100127476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/oiKAuYFg",
      "expanded_url" : "http:\/\/bit.ly\/TMzHtz",
      "display_url" : "bit.ly\/TMzHtz"
    }, {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/hIvr4kzc",
      "expanded_url" : "http:\/\/bit.ly\/TMzF5d",
      "display_url" : "bit.ly\/TMzF5d"
    } ]
  },
  "geo" : { },
  "id_str" : "287099302277419009",
  "text" : "Got my @thinkup 2.0 beta running: http:\/\/t.co\/oiKAuYFg and it has a TON of cool improvements over 1.1.1. Get it here! http:\/\/t.co\/hIvr4kzc",
  "id" : 287099302277419009,
  "created_at" : "2013-01-04 07:33:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287098062470537216",
  "geo" : { },
  "id_str" : "287098327735074817",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Yay! Ran the CLI again and it just finished up. Last output: \"Completed insight generation for Buster Benson on facebook\".",
  "id" : 287098327735074817,
  "in_reply_to_status_id" : 287098062470537216,
  "created_at" : "2013-01-04 07:29:10 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287096859594481664",
  "geo" : { },
  "id_str" : "287097158363148288",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Not frustrated... just wanted to let you know. Thanks for continuing to make this more awesome.",
  "id" : 287097158363148288,
  "in_reply_to_status_id" : 287096859594481664,
  "created_at" : "2013-01-04 07:24:31 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/287096554442088451\/photo\/1",
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/qFwzU5WN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_v4y5ACYAA5sB1.png",
      "id_str" : "287096554446282752",
      "id" : 287096554446282752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_v4y5ACYAA5sB1.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 794
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 794
      } ],
      "display_url" : "pic.twitter.com\/qFwzU5WN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287096222152536064",
  "geo" : { },
  "id_str" : "287096554442088451",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Yup, I have. Still no dash. http:\/\/t.co\/qFwzU5WN",
  "id" : 287096554442088451,
  "in_reply_to_status_id" : 287096222152536064,
  "created_at" : "2013-01-04 07:22:07 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287095250416189440",
  "geo" : { },
  "id_str" : "287095970485919744",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Hm, it just finished with \"Completed insight generation for buster on twitter\" and still no dashboard...",
  "id" : 287095970485919744,
  "in_reply_to_status_id" : 287095250416189440,
  "created_at" : "2013-01-04 07:19:48 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287095250416189440",
  "geo" : { },
  "id_str" : "287095634085965824",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Suspected that might be the case. The web crawler didn't do the trick but the CLI crawler seems to be doing a bunch of stuff now.",
  "id" : 287095634085965824,
  "in_reply_to_status_id" : 287095250416189440,
  "created_at" : "2013-01-04 07:18:27 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/ueRnYoyG",
      "expanded_url" : "http:\/\/bit.ly\/ULSOGj",
      "display_url" : "bit.ly\/ULSOGj"
    } ]
  },
  "geo" : { },
  "id_str" : "287094271088148480",
  "text" : "Just bought Ray Kurzweil's new book \"How to Create a Mind\" after watching his talk at Singularity Summit: http:\/\/t.co\/ueRnYoyG",
  "id" : 287094271088148480,
  "created_at" : "2013-01-04 07:13:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vivek Wadhwa",
      "screen_name" : "wadhwa",
      "indices" : [ 3, 10 ],
      "id_str" : "32718488",
      "id" : 32718488
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoogleScale",
      "indices" : [ 126, 140 ]
    }, {
      "text" : "SingularityU",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287094006121381889",
  "text" : "RT @wadhwa: Kurzweil says that at Google, he will be working on advanced implementations of AI--will have unlimited resources #GoogleSca ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GoogleScale",
        "indices" : [ 114, 126 ]
      }, {
        "text" : "SingularityU",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "286893821944557568",
    "text" : "Kurzweil says that at Google, he will be working on advanced implementations of AI--will have unlimited resources #GoogleScale #SingularityU",
    "id" : 286893821944557568,
    "created_at" : "2013-01-03 17:56:32 +0000",
    "user" : {
      "name" : "Vivek Wadhwa",
      "screen_name" : "wadhwa",
      "protected" : false,
      "id_str" : "32718488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3755159314\/f5c832f044b2cf7ff45a73fa13503dcf_normal.jpeg",
      "id" : 32718488,
      "verified" : false
    }
  },
  "id" : 287094006121381889,
  "created_at" : "2013-01-04 07:11:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Malin",
      "screen_name" : "mmalin",
      "indices" : [ 0, 7 ],
      "id_str" : "606727563",
      "id" : 606727563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287091194360655872",
  "geo" : { },
  "id_str" : "287091663531286529",
  "in_reply_to_user_id" : 606727563,
  "text" : "@mmalin Easiest revolution ever.",
  "id" : 287091663531286529,
  "in_reply_to_status_id" : 287091194360655872,
  "created_at" : "2013-01-04 07:02:41 +0000",
  "in_reply_to_screen_name" : "mmalin",
  "in_reply_to_user_id_str" : "606727563",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Malin",
      "screen_name" : "mmalin",
      "indices" : [ 0, 7 ],
      "id_str" : "606727563",
      "id" : 606727563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287090667363115008",
  "geo" : { },
  "id_str" : "287090756508864512",
  "in_reply_to_user_id" : 606727563,
  "text" : "@mmalin What if that just teaches them how to be misleading? :)",
  "id" : 287090756508864512,
  "in_reply_to_status_id" : 287090667363115008,
  "created_at" : "2013-01-04 06:59:04 +0000",
  "in_reply_to_screen_name" : "mmalin",
  "in_reply_to_user_id_str" : "606727563",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThinkUp",
      "screen_name" : "thinkup",
      "indices" : [ 0, 8 ],
      "id_str" : "100127476",
      "id" : 100127476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/xnD8gV9t",
      "expanded_url" : "http:\/\/busterbenson.com\/thinkup\/",
      "display_url" : "busterbenson.com\/thinkup\/"
    } ]
  },
  "in_reply_to_status_id_str" : "286585099900817408",
  "geo" : { },
  "id_str" : "287090633783508992",
  "in_reply_to_user_id" : 100127476,
  "text" : "@thinkup I upgraded, connected accounts, &amp; ran the cron but still see a \"get started\" page instead of the dash: http:\/\/t.co\/xnD8gV9t Ideas?",
  "id" : 287090633783508992,
  "in_reply_to_status_id" : 286585099900817408,
  "created_at" : "2013-01-04 06:58:35 +0000",
  "in_reply_to_screen_name" : "thinkup",
  "in_reply_to_user_id_str" : "100127476",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287080050807934976",
  "text" : "There are 4.1M articles in Wikipedia, more than we'll ever be able to read, much less remember. Watson can read &amp; memorize it in 3 seconds.",
  "id" : 287080050807934976,
  "created_at" : "2013-01-04 06:16:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287079179562930176",
  "text" : "Wikipedia isn't a free encyclopedia for humans, it's the \"ABC 123\" book for future baby computer brains.",
  "id" : 287079179562930176,
  "created_at" : "2013-01-04 06:13:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/y9N5J7YY",
      "expanded_url" : "http:\/\/flic.kr\/p\/dHkq7P",
      "display_url" : "flic.kr\/p\/dHkq7P"
    } ]
  },
  "geo" : { },
  "id_str" : "287066677521309696",
  "text" : "8:36pm Fiddling with work ideas in my hotel room http:\/\/t.co\/y9N5J7YY",
  "id" : 287066677521309696,
  "created_at" : "2013-01-04 05:23:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/XZNlOTu6",
      "expanded_url" : "http:\/\/cinemagr.am\/show\/93114844",
      "display_url" : "cinemagr.am\/show\/93114844"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7729876862, -122.4153850376 ]
  },
  "id_str" : "287052976374308864",
  "text" : "Ambient conversations at Una http:\/\/t.co\/XZNlOTu6",
  "id" : 287052976374308864,
  "created_at" : "2013-01-04 04:28:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287050943575502848",
  "text" : "If the Tesla Model S is the iPhone of cars, what's the 4th gen Android? Actually, how about the Sidekick.",
  "id" : 287050943575502848,
  "created_at" : "2013-01-04 04:20:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Walter Adamson",
      "screen_name" : "adamson",
      "indices" : [ 3, 11 ],
      "id_str" : "9616512",
      "id" : 9616512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/KettLbyM",
      "expanded_url" : "http:\/\/tech.fortune.cnn.com\/2013\/01\/03\/google-larry-page",
      "display_url" : "tech.fortune.cnn.com\/2013\/01\/03\/goo\u2026"
    }, {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/h13c75EC",
      "expanded_url" : "http:\/\/tweetedtimes.com\/ThePersuader\/brains-like-planets",
      "display_url" : "tweetedtimes.com\/ThePersuader\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "287049727898431488",
  "text" : "RT @adamson: Top story: The future according to Google's Larry Page - Fortune Tech http:\/\/t.co\/KettLbyM, see more http:\/\/t.co\/h13c75EC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetedtimes.com\" rel=\"nofollow\"\u003EThe Tweeted Times Mobile\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/KettLbyM",
        "expanded_url" : "http:\/\/tech.fortune.cnn.com\/2013\/01\/03\/google-larry-page",
        "display_url" : "tech.fortune.cnn.com\/2013\/01\/03\/goo\u2026"
      }, {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/h13c75EC",
        "expanded_url" : "http:\/\/tweetedtimes.com\/ThePersuader\/brains-like-planets",
        "display_url" : "tweetedtimes.com\/ThePersuader\/b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "287040457446404097",
    "text" : "Top story: The future according to Google's Larry Page - Fortune Tech http:\/\/t.co\/KettLbyM, see more http:\/\/t.co\/h13c75EC",
    "id" : 287040457446404097,
    "created_at" : "2013-01-04 03:39:12 +0000",
    "user" : {
      "name" : "Walter Adamson",
      "screen_name" : "adamson",
      "protected" : false,
      "id_str" : "9616512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/90654394\/Adamson-184X184_normal.JPG",
      "id" : 9616512,
      "verified" : false
    }
  },
  "id" : 287049727898431488,
  "created_at" : "2013-01-04 04:16:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 33, 42 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/WjhTkBbj",
      "expanded_url" : "http:\/\/www.wired.co.uk\/news\/archive\/2012-11\/19\/elon-musk-on-hyperloop",
      "display_url" : "wired.co.uk\/news\/archive\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "287039152292233216",
  "text" : "I really want to know more about @elonmusk\u2019s Hyperloop idea http:\/\/t.co\/WjhTkBbj",
  "id" : 287039152292233216,
  "created_at" : "2013-01-04 03:34:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Kathleen Peck",
      "screen_name" : "sarahkpeck",
      "indices" : [ 0, 11 ],
      "id_str" : "196745496",
      "id" : 196745496
    }, {
      "name" : "sha",
      "screen_name" : "shashashasha",
      "indices" : [ 12, 25 ],
      "id_str" : "3176751",
      "id" : 3176751
    }, {
      "name" : "Andi Hansen",
      "screen_name" : "vis_sys",
      "indices" : [ 26, 34 ],
      "id_str" : "845914094",
      "id" : 845914094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286993889724887040",
  "geo" : { },
  "id_str" : "287037802795921408",
  "in_reply_to_user_id" : 196745496,
  "text" : "@sarahkpeck @shashashasha @vis_sys That\u2019s pretty neat. Is the list of micro-life pluses and minuses available anywhere?",
  "id" : 287037802795921408,
  "in_reply_to_status_id" : 286993889724887040,
  "created_at" : "2013-01-04 03:28:39 +0000",
  "in_reply_to_screen_name" : "sarahkpeck",
  "in_reply_to_user_id_str" : "196745496",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annalee Newitz",
      "screen_name" : "Annaleen",
      "indices" : [ 3, 12 ],
      "id_str" : "756475",
      "id" : 756475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/3ZhLGZfu",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/future_tense\/2013\/01\/03\/mark_lynas_environmentalist_who_opposed_gmos_admits_he_was_wrong.html",
      "display_url" : "slate.com\/blogs\/future_t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "287035898598674432",
  "text" : "RT @Annaleen: This is a huge step forward for environmentalism. GMOs are not the enemy. http:\/\/t.co\/3ZhLGZfu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/3ZhLGZfu",
        "expanded_url" : "http:\/\/www.slate.com\/blogs\/future_tense\/2013\/01\/03\/mark_lynas_environmentalist_who_opposed_gmos_admits_he_was_wrong.html",
        "display_url" : "slate.com\/blogs\/future_t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "287004441687773184",
    "text" : "This is a huge step forward for environmentalism. GMOs are not the enemy. http:\/\/t.co\/3ZhLGZfu",
    "id" : 287004441687773184,
    "created_at" : "2013-01-04 01:16:05 +0000",
    "user" : {
      "name" : "Annalee Newitz",
      "screen_name" : "Annaleen",
      "protected" : false,
      "id_str" : "756475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2381216127\/7lycf0juxowmrx88i90m_normal.jpeg",
      "id" : 756475,
      "verified" : false
    }
  },
  "id" : 287035898598674432,
  "created_at" : "2013-01-04 03:21:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 0, 11 ],
      "id_str" : "26123649",
      "id" : 26123649
    }, {
      "name" : "Kate Taylor",
      "screen_name" : "purekate",
      "indices" : [ 12, 21 ],
      "id_str" : "15214830",
      "id" : 15214830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287031208062377985",
  "geo" : { },
  "id_str" : "287034757404061696",
  "in_reply_to_user_id" : 26123649,
  "text" : "@brianellin @purekate I\u2019m here til Wed afternoon. Pick a day!",
  "id" : 287034757404061696,
  "in_reply_to_status_id" : 287031208062377985,
  "created_at" : "2013-01-04 03:16:33 +0000",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Higgins",
      "screen_name" : "chrishiggins",
      "indices" : [ 42, 55 ],
      "id_str" : "12096622",
      "id" : 12096622
    }, {
      "name" : "The Magazine",
      "screen_name" : "TheMagazineApp",
      "indices" : [ 59, 74 ],
      "id_str" : "748478131",
      "id" : 748478131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/V5ChlT4f",
      "expanded_url" : "http:\/\/the-magazine.org\/7\/playing-to-lose",
      "display_url" : "the-magazine.org\/7\/playing-to-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "287033621301297152",
  "text" : "Competitive Tetris! \"Playing to Lose\" \/by @chrishiggins in @TheMagazineApp http:\/\/t.co\/V5ChlT4f",
  "id" : 287033621301297152,
  "created_at" : "2013-01-04 03:12:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Olson LaFave",
      "screen_name" : "emilyolson",
      "indices" : [ 0, 11 ],
      "id_str" : "2375802074",
      "id" : 2375802074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287027666639548417",
  "geo" : { },
  "id_str" : "287029127695974400",
  "in_reply_to_user_id" : 14097091,
  "text" : "@emilyolson Ooh that sounds good. I\u2019ll look it up.",
  "id" : 287029127695974400,
  "in_reply_to_status_id" : 287027666639548417,
  "created_at" : "2013-01-04 02:54:11 +0000",
  "in_reply_to_screen_name" : "emilylafave",
  "in_reply_to_user_id_str" : "14097091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Taylor",
      "screen_name" : "purekate",
      "indices" : [ 0, 9 ],
      "id_str" : "15214830",
      "id" : 15214830
    }, {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 70, 81 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287027975461945344",
  "geo" : { },
  "id_str" : "287028913991974912",
  "in_reply_to_user_id" : 15214830,
  "text" : "@purekate In my opinion, yes. I like the whole feel of the place too. @brianellin tipped me off on it.",
  "id" : 287028913991974912,
  "in_reply_to_status_id" : 287027975461945344,
  "created_at" : "2013-01-04 02:53:20 +0000",
  "in_reply_to_screen_name" : "purekate",
  "in_reply_to_user_id_str" : "15214830",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/f8vHRCXy",
      "expanded_url" : "http:\/\/4sq.com\/UkqJaP",
      "display_url" : "4sq.com\/UkqJaP"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.772918, -122.415449 ]
  },
  "id_str" : "287027276762206208",
  "text" : "First thing I want to eat when I return to SF. What should I do next? (@ Una Pizza Napoletana) http:\/\/t.co\/f8vHRCXy",
  "id" : 287027276762206208,
  "created_at" : "2013-01-04 02:46:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286977794234269696",
  "geo" : { },
  "id_str" : "286982844016885760",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel I've heard Niko start doing the same.",
  "id" : 286982844016885760,
  "in_reply_to_status_id" : 286977794234269696,
  "created_at" : "2013-01-03 23:50:16 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hadfield",
      "screen_name" : "Cmdr_Hadfield",
      "indices" : [ 7, 21 ],
      "id_str" : "186154646",
      "id" : 186154646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286965969748893696",
  "text" : "Follow @Cmdr_Hadfield right now -- he's tweeting pictures of Earth from space as he orbits.",
  "id" : 286965969748893696,
  "created_at" : "2013-01-03 22:43:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Shatner",
      "screen_name" : "WilliamShatner",
      "indices" : [ 23, 38 ],
      "id_str" : "15227791",
      "id" : 15227791
    }, {
      "name" : "Chris Hadfield",
      "screen_name" : "Cmdr_Hadfield",
      "indices" : [ 43, 57 ],
      "id_str" : "186154646",
      "id" : 186154646
    }, {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 112, 118 ],
      "id_str" : "8285392",
      "id" : 8285392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "omg",
      "indices" : [ 102, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/moqtvBs9",
      "expanded_url" : "http:\/\/bit.ly\/RvoL4Y",
      "display_url" : "bit.ly\/RvoL4Y"
    } ]
  },
  "geo" : { },
  "id_str" : "286965303152357376",
  "text" : "Tweet exchange between @WilliamShatner and @Cmdr_Hadfield as he orbits in space! http:\/\/t.co\/moqtvBs9 #omg \/via @raffi",
  "id" : 286965303152357376,
  "created_at" : "2013-01-03 22:40:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    }, {
      "name" : "Pasquale D'Silva",
      "screen_name" : "pasql",
      "indices" : [ 13, 19 ],
      "id_str" : "187793",
      "id" : 187793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286911397902815232",
  "geo" : { },
  "id_str" : "286913531696250880",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger @pasql Oooh, I think I just \"got\" Sets. Exciiiiting.",
  "id" : 286913531696250880,
  "in_reply_to_status_id" : 286911397902815232,
  "created_at" : "2013-01-03 19:14:51 +0000",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Swizec",
      "screen_name" : "Swizec",
      "indices" : [ 0, 7 ],
      "id_str" : "15353121",
      "id" : 15353121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286768942708568064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778383638, -122.4151709485 ]
  },
  "id_str" : "286769896325525504",
  "in_reply_to_user_id" : 15353121,
  "text" : "@Swizec No, it's gotta be deliberate.",
  "id" : 286769896325525504,
  "in_reply_to_status_id" : 286768942708568064,
  "created_at" : "2013-01-03 09:44:05 +0000",
  "in_reply_to_screen_name" : "Swizec",
  "in_reply_to_user_id_str" : "15353121",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 139 ],
      "url" : "https:\/\/t.co\/UKLW7hVo",
      "expanded_url" : "https:\/\/github.com\/busterbenson\/public\/blob\/master\/Beliefs.md",
      "display_url" : "github.com\/busterbenson\/p\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7777776232, -122.4152205912 ]
  },
  "id_str" : "286768149595049987",
  "text" : "One of the most rewarding things with tracking beliefs is having a tangible reference to go back to when things shift https:\/\/t.co\/UKLW7hVo",
  "id" : 286768149595049987,
  "created_at" : "2013-01-03 09:37:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286766782612639744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7777137896, -122.4152650844 ]
  },
  "id_str" : "286767612787036160",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner Same here (though you've probably read more). I loved his free will book too. Gonna let it sink in and see where beliefs end up.",
  "id" : 286767612787036160,
  "in_reply_to_status_id" : 286766782612639744,
  "created_at" : "2013-01-03 09:35:01 +0000",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286749063527927808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7777787607, -122.4151991245 ]
  },
  "id_str" : "286765994096091136",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner Yeah Sam Harris is pretty rad. Thanks for the link. My mind is changing about a few things.",
  "id" : 286765994096091136,
  "in_reply_to_status_id" : 286749063527927808,
  "created_at" : "2013-01-03 09:28:35 +0000",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Harris",
      "screen_name" : "SamHarrisOrg",
      "indices" : [ 31, 44 ],
      "id_str" : "116994659",
      "id" : 116994659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/bXB1tH6v",
      "expanded_url" : "http:\/\/bit.ly\/12ZwHzc",
      "display_url" : "bit.ly\/12ZwHzc"
    } ]
  },
  "in_reply_to_status_id_str" : "286641445560020992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778648308, -122.4151267445 ]
  },
  "id_str" : "286765373653676032",
  "in_reply_to_user_id" : 116994659,
  "text" : "Long, but pretty damn smart RT @SamHarrisOrg: My thoughts on guns in the aftermath of Newtown: \"The Riddle of the Gun\" http:\/\/t.co\/bXB1tH6v",
  "id" : 286765373653676032,
  "in_reply_to_status_id" : 286641445560020992,
  "created_at" : "2013-01-03 09:26:07 +0000",
  "in_reply_to_screen_name" : "SamHarrisOrg",
  "in_reply_to_user_id_str" : "116994659",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7777852525, -122.4152327561 ]
  },
  "id_str" : "286757644109217792",
  "text" : "Whoever's in charge of my brain right now is easily annoyed apparently.",
  "id" : 286757644109217792,
  "created_at" : "2013-01-03 08:55:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/McteUKJD",
      "expanded_url" : "http:\/\/www.elephantjournal.com\/2013\/01\/the-yinside-of-new-years-resolutions-bernie-clark\/?utm_source=All&utm_campaign=Daily+Moment+of+Awake+in+the+Inbox+of+Your+Mind&utm_medium=email",
      "display_url" : "elephantjournal.com\/2013\/01\/the-yi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286657982010363905",
  "text" : "\"This year, why not resolve to accept something about yourself that you will no longer try to change or improve?\" http:\/\/t.co\/McteUKJD",
  "id" : 286657982010363905,
  "created_at" : "2013-01-03 02:19:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/pkqr97Rf",
      "expanded_url" : "http:\/\/flic.kr\/p\/dGWtVi",
      "display_url" : "flic.kr\/p\/dGWtVi"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.641333, -84.439167 ]
  },
  "id_str" : "286651200097640449",
  "text" : "8:36pm Connecting in Atlanta. Walking by a life-size touchscreen video game (ad?) http:\/\/t.co\/pkqr97Rf",
  "id" : 286651200097640449,
  "created_at" : "2013-01-03 01:52:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286629319042822146",
  "geo" : { },
  "id_str" : "286632074385952769",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm Delaware doesn't have cheesesteak, will scapple do?",
  "id" : 286632074385952769,
  "in_reply_to_status_id" : 286629319042822146,
  "created_at" : "2013-01-03 00:36:26 +0000",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buddy Bump",
      "screen_name" : "bebumpersticker",
      "indices" : [ 0, 16 ],
      "id_str" : "438711168",
      "id" : 438711168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286607466836422656",
  "geo" : { },
  "id_str" : "286622165925781505",
  "in_reply_to_user_id" : 438711168,
  "text" : "@bebumpersticker Awesome to hear it. Let me know how it goes and if I can help with anything.",
  "id" : 286622165925781505,
  "in_reply_to_status_id" : 286607466836422656,
  "created_at" : "2013-01-02 23:57:04 +0000",
  "in_reply_to_screen_name" : "bebumpersticker",
  "in_reply_to_user_id_str" : "438711168",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286611022305964034",
  "geo" : { },
  "id_str" : "286622040973262848",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm My wife grew up in Wilmington DE, which sort of counts as Philly, right? Did you head back for the holidays this year?",
  "id" : 286622040973262848,
  "in_reply_to_status_id" : 286611022305964034,
  "created_at" : "2013-01-02 23:56:34 +0000",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/wo5rKbVR",
      "expanded_url" : "http:\/\/4sq.com\/XjVpd3",
      "display_url" : "4sq.com\/XjVpd3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.8770074528, -75.2424430847 ]
  },
  "id_str" : "286610362256748544",
  "text" : "Sad to be leaving family for a week. Excited to be going back to work. (@ Philadelphia International Airport (PHL)) http:\/\/t.co\/wo5rKbVR",
  "id" : 286610362256748544,
  "created_at" : "2013-01-02 23:10:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buddy Bump",
      "screen_name" : "bebumpersticker",
      "indices" : [ 0, 16 ],
      "id_str" : "438711168",
      "id" : 438711168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286601250567487488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.875744269, -75.2408721515 ]
  },
  "id_str" : "286606259749257217",
  "in_reply_to_user_id" : 438711168,
  "text" : "@bebumpersticker Cool! What inspired you?",
  "id" : 286606259749257217,
  "in_reply_to_status_id" : 286601250567487488,
  "created_at" : "2013-01-02 22:53:51 +0000",
  "in_reply_to_screen_name" : "bebumpersticker",
  "in_reply_to_user_id_str" : "438711168",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/hshXd3T5",
      "expanded_url" : "http:\/\/instagr.am\/p\/T_nLaZI0Jm\/",
      "display_url" : "instagr.am\/p\/T_nLaZI0Jm\/"
    } ]
  },
  "geo" : { },
  "id_str" : "286562494330306560",
  "text" : "Xmas Castle continues development http:\/\/t.co\/hshXd3T5",
  "id" : 286562494330306560,
  "created_at" : "2013-01-02 19:59:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rabbitrabbit",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/pSnxdXnA",
      "expanded_url" : "http:\/\/wayoftheduck.com\/rabbit-rabbit",
      "display_url" : "wayoftheduck.com\/rabbit-rabbit"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7619325518, -75.508218267 ]
  },
  "id_str" : "286544221274521601",
  "text" : "Want me to remind you of your resolution on the 1st of every month this year? Join us here: http:\/\/t.co\/pSnxdXnA #rabbitrabbit",
  "id" : 286544221274521601,
  "created_at" : "2013-01-02 18:47:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286541714146086912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7619139479, -75.5082168362 ]
  },
  "id_str" : "286542832662114305",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Hmm, good question. I think you should talk about at least one other thing to be safe.",
  "id" : 286542832662114305,
  "in_reply_to_status_id" : 286541714146086912,
  "created_at" : "2013-01-02 18:41:49 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286541518653763585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.76198019, -75.5085936562 ]
  },
  "id_str" : "286541886934622209",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Awesome, run with it! It's been enlightening to think about it as I watch tv in Delaware. Happy new year!",
  "id" : 286541886934622209,
  "in_reply_to_status_id" : 286541518653763585,
  "created_at" : "2013-01-02 18:38:04 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/c3XHLohb",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Bechdel_test",
      "display_url" : "en.m.wikipedia.org\/wiki\/Bechdel_t\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7619828823, -75.5083442082 ]
  },
  "id_str" : "286525398848782336",
  "text" : "A work passes the Bechdel test if it features at least 2 women who talk to each other about something other than a man http:\/\/t.co\/c3XHLohb",
  "id" : 286525398848782336,
  "created_at" : "2013-01-02 17:32:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "benward",
      "indices" : [ 0, 8 ],
      "id_str" : "12249",
      "id" : 12249
    }, {
      "name" : "Alex Duloz",
      "screen_name" : "alexduloz",
      "indices" : [ 9, 19 ],
      "id_str" : "380189226",
      "id" : 380189226
    }, {
      "name" : "Katy Watkins",
      "screen_name" : "_KatyWatkins",
      "indices" : [ 20, 33 ],
      "id_str" : "238824495",
      "id" : 238824495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286522602007187458",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7624419209, -75.5083182315 ]
  },
  "id_str" : "286523857697923073",
  "in_reply_to_user_id" : 12249,
  "text" : "@BenWard @alexduloz @_katywatkins A google group would be enough to bootstrap I think.",
  "id" : 286523857697923073,
  "in_reply_to_status_id" : 286522602007187458,
  "created_at" : "2013-01-02 17:26:25 +0000",
  "in_reply_to_screen_name" : "benward",
  "in_reply_to_user_id_str" : "12249",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "benward",
      "indices" : [ 0, 8 ],
      "id_str" : "12249",
      "id" : 12249
    }, {
      "name" : "Alex Duloz",
      "screen_name" : "alexduloz",
      "indices" : [ 9, 19 ],
      "id_str" : "380189226",
      "id" : 380189226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286515080605073409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7619212026, -75.5082723053 ]
  },
  "id_str" : "286519524000407552",
  "in_reply_to_user_id" : 12249,
  "text" : "@BenWard @alexduloz I would be so into that.",
  "id" : 286519524000407552,
  "in_reply_to_status_id" : 286515080605073409,
  "created_at" : "2013-01-02 17:09:12 +0000",
  "in_reply_to_screen_name" : "benward",
  "in_reply_to_user_id_str" : "12249",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Duloz",
      "screen_name" : "alexduloz",
      "indices" : [ 0, 10 ],
      "id_str" : "380189226",
      "id" : 380189226
    }, {
      "name" : "Ben Ward",
      "screen_name" : "benward",
      "indices" : [ 11, 19 ],
      "id_str" : "12249",
      "id" : 12249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286366604730699778",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7619147578, -75.5082179281 ]
  },
  "id_str" : "286480244137918465",
  "in_reply_to_user_id" : 380189226,
  "text" : "@alexduloz @benward Exciting!",
  "id" : 286480244137918465,
  "in_reply_to_status_id" : 286366604730699778,
  "created_at" : "2013-01-02 14:33:07 +0000",
  "in_reply_to_screen_name" : "alexduloz",
  "in_reply_to_user_id_str" : "380189226",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286364856674836480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7621197906, -75.508219488 ]
  },
  "id_str" : "286480151729020929",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman I ran into the owner of this handle on my first day there and it wasn't his primary account... got lucky!",
  "id" : 286480151729020929,
  "in_reply_to_status_id" : 286364856674836480,
  "created_at" : "2013-01-02 14:32:45 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    }, {
      "name" : "Jason Preston",
      "screen_name" : "jasonp",
      "indices" : [ 12, 19 ],
      "id_str" : "4131861",
      "id" : 4131861
    }, {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "indices" : [ 61, 73 ],
      "id_str" : "1532061",
      "id" : 1532061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286364636238970881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.762120503, -75.508207921 ]
  },
  "id_str" : "286479917326143488",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman @jasonp Yes, it's from What Technology Wants, by @kevin2kelly and it's a great book.",
  "id" : 286479917326143488,
  "in_reply_to_status_id" : 286364636238970881,
  "created_at" : "2013-01-02 14:31:49 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Arrington",
      "screen_name" : "arrington",
      "indices" : [ 3, 13 ],
      "id_str" : "37570179",
      "id" : 37570179
    }, {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 87, 98 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/pMsstmHd",
      "expanded_url" : "http:\/\/techcrunch.com\/2013\/01\/01\/the-income-rich-take-one-for-the-team-thanks\/",
      "display_url" : "techcrunch.com\/2013\/01\/01\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286359615065706496",
  "text" : "RT @arrington: The Income Rich Take One For The Team. Thanks! http:\/\/t.co\/pMsstmHd via @techcrunch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TechCrunch",
        "screen_name" : "TechCrunch",
        "indices" : [ 72, 83 ],
        "id_str" : "816653",
        "id" : 816653
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/pMsstmHd",
        "expanded_url" : "http:\/\/techcrunch.com\/2013\/01\/01\/the-income-rich-take-one-for-the-team-thanks\/",
        "display_url" : "techcrunch.com\/2013\/01\/01\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "286357560431366144",
    "text" : "The Income Rich Take One For The Team. Thanks! http:\/\/t.co\/pMsstmHd via @techcrunch",
    "id" : 286357560431366144,
    "created_at" : "2013-01-02 06:25:37 +0000",
    "user" : {
      "name" : "Michael Arrington",
      "screen_name" : "arrington",
      "protected" : false,
      "id_str" : "37570179",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000654181704\/52e1a4162ad05f167fca1432630dac1c_normal.jpeg",
      "id" : 37570179,
      "verified" : true
    }
  },
  "id" : 286359615065706496,
  "created_at" : "2013-01-02 06:33:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 3, 14 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/qinYyXOk",
      "expanded_url" : "http:\/\/bit.ly\/Ul3o56",
      "display_url" : "bit.ly\/Ul3o56"
    } ]
  },
  "geo" : { },
  "id_str" : "286358406816735234",
  "text" : "RT @moniguzman: Why is there no good synonym for technology? http:\/\/t.co\/qinYyXOk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/qinYyXOk",
        "expanded_url" : "http:\/\/bit.ly\/Ul3o56",
        "display_url" : "bit.ly\/Ul3o56"
      } ]
    },
    "geo" : { },
    "id_str" : "286356363557359616",
    "text" : "Why is there no good synonym for technology? http:\/\/t.co\/qinYyXOk",
    "id" : 286356363557359616,
    "created_at" : "2013-01-02 06:20:51 +0000",
    "user" : {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "protected" : false,
      "id_str" : "3452941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454510513251037184\/83aM56tP_normal.jpeg",
      "id" : 3452941,
      "verified" : false
    }
  },
  "id" : 286358406816735234,
  "created_at" : "2013-01-02 06:28:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286356363557359616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7625376084, -75.5081046253 ]
  },
  "id_str" : "286358394812628992",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman I like the anthropomorphicization (???) of technology: the Technium.",
  "id" : 286358394812628992,
  "in_reply_to_status_id" : 286356363557359616,
  "created_at" : "2013-01-02 06:28:56 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Levie",
      "screen_name" : "levie",
      "indices" : [ 3, 9 ],
      "id_str" : "914061",
      "id" : 914061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286330758380007426",
  "text" : "RT @levie: The US government's core competency at this point is averting self-created crises.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "286329299714334720",
    "text" : "The US government's core competency at this point is averting self-created crises.",
    "id" : 286329299714334720,
    "created_at" : "2013-01-02 04:33:19 +0000",
    "user" : {
      "name" : "Aaron Levie",
      "screen_name" : "levie",
      "protected" : false,
      "id_str" : "914061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1626898956\/twitter_normal.png",
      "id" : 914061,
      "verified" : false
    }
  },
  "id" : 286330758380007426,
  "created_at" : "2013-01-02 04:39:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 3, 9 ],
      "id_str" : "8285392",
      "id" : 8285392
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 57, 65 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/raffi\/status\/286320673440276482\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/6iAg9yqx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_k3IrDCIAEMXqO.png",
      "id_str" : "286320673448665089",
      "id" : 286320673448665089,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_k3IrDCIAEMXqO.png",
      "sizes" : [ {
        "h" : 794,
        "resize" : "fit",
        "w" : 793
      }, {
        "h" : 794,
        "resize" : "fit",
        "w" : 793
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6iAg9yqx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/FSu0ckfC",
      "expanded_url" : "http:\/\/blog.twitter.com\/2013\/01\/celebrating-2013-in-global-town-square.html",
      "display_url" : "blog.twitter.com\/2013\/01\/celebr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286325844870320128",
  "text" : "RT @raffi: users sent almost 34k tweets \/ second through @twitter when tokyo hit midnight on new year's eve \u2192 http:\/\/t.co\/FSu0ckfC http: ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 46, 54 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/raffi\/status\/286320673440276482\/photo\/1",
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/6iAg9yqx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A_k3IrDCIAEMXqO.png",
        "id_str" : "286320673448665089",
        "id" : 286320673448665089,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_k3IrDCIAEMXqO.png",
        "sizes" : [ {
          "h" : 794,
          "resize" : "fit",
          "w" : 793
        }, {
          "h" : 794,
          "resize" : "fit",
          "w" : 793
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/6iAg9yqx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/FSu0ckfC",
        "expanded_url" : "http:\/\/blog.twitter.com\/2013\/01\/celebrating-2013-in-global-town-square.html",
        "display_url" : "blog.twitter.com\/2013\/01\/celebr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "286320673440276482",
    "text" : "users sent almost 34k tweets \/ second through @twitter when tokyo hit midnight on new year's eve \u2192 http:\/\/t.co\/FSu0ckfC http:\/\/t.co\/6iAg9yqx",
    "id" : 286320673440276482,
    "created_at" : "2013-01-02 03:59:03 +0000",
    "user" : {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "protected" : false,
      "id_str" : "8285392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1270234259\/raffi-headshot-casual_normal.png",
      "id" : 8285392,
      "verified" : false
    }
  },
  "id" : 286325844870320128,
  "created_at" : "2013-01-02 04:19:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Harran",
      "screen_name" : "edwardharran",
      "indices" : [ 0, 13 ],
      "id_str" : "1297298624",
      "id" : 1297298624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286322033099407360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7624113551, -75.5083872937 ]
  },
  "id_str" : "286325292367224832",
  "in_reply_to_user_id" : 9013032,
  "text" : "@edwardharran So true!",
  "id" : 286325292367224832,
  "in_reply_to_status_id" : 286322033099407360,
  "created_at" : "2013-01-02 04:17:24 +0000",
  "in_reply_to_screen_name" : "eddieharran",
  "in_reply_to_user_id_str" : "9013032",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/BFN0qrTQ",
      "expanded_url" : "http:\/\/flic.kr\/p\/dGDThw",
      "display_url" : "flic.kr\/p\/dGDThw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.762166, -75.5085 ]
  },
  "id_str" : "286289351896358912",
  "text" : "8:36pm Knows all the words to all the books http:\/\/t.co\/BFN0qrTQ",
  "id" : 286289351896358912,
  "created_at" : "2013-01-02 01:54:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everett",
      "screen_name" : "Mr_Scribbles",
      "indices" : [ 28, 41 ],
      "id_str" : "13106032",
      "id" : 13106032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/6fcBx2dI",
      "expanded_url" : "http:\/\/www.wired.com\/design\/2012\/12\/365-superheroes\/?pid=1756&viewall=true",
      "display_url" : "wired.com\/design\/2012\/12\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7621709189, -75.5085211662 ]
  },
  "id_str" : "286277655567929344",
  "text" : "A superhero a day, drawn by @mr_scribbles: http:\/\/t.co\/6fcBx2dI",
  "id" : 286277655567929344,
  "created_at" : "2013-01-02 01:08:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "benward",
      "indices" : [ 0, 8 ],
      "id_str" : "12249",
      "id" : 12249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286270693002326016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7618932376, -75.508263676 ]
  },
  "id_str" : "286272931535917059",
  "in_reply_to_user_id" : 12249,
  "text" : "@BenWard Maybe you should fork it and find 30 new people to do the challenge? I'd love to participate in something like that.",
  "id" : 286272931535917059,
  "in_reply_to_status_id" : 286270693002326016,
  "created_at" : "2013-01-02 00:49:20 +0000",
  "in_reply_to_screen_name" : "benward",
  "in_reply_to_user_id_str" : "12249",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 3, 10 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/zosoJOxE",
      "expanded_url" : "http:\/\/bit.ly\/Ujfji9",
      "display_url" : "bit.ly\/Ujfji9"
    } ]
  },
  "geo" : { },
  "id_str" : "286257785954512898",
  "text" : "RT @berkun: List of unsolved problems in philosophy http:\/\/t.co\/zosoJOxE - Ironically doesn't include the problem of assuming every prob ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/zosoJOxE",
        "expanded_url" : "http:\/\/bit.ly\/Ujfji9",
        "display_url" : "bit.ly\/Ujfji9"
      } ]
    },
    "geo" : { },
    "id_str" : "286255881782427648",
    "text" : "List of unsolved problems in philosophy http:\/\/t.co\/zosoJOxE - Ironically doesn't include the problem of assuming every problem is solvable",
    "id" : 286255881782427648,
    "created_at" : "2013-01-01 23:41:35 +0000",
    "user" : {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "protected" : false,
      "id_str" : "30495974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000825792839\/f028b7a5a19718e0e4bcad31b1db6ddf_normal.jpeg",
      "id" : 30495974,
      "verified" : false
    }
  },
  "id" : 286257785954512898,
  "created_at" : "2013-01-01 23:49:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/pzcmqmZs",
      "expanded_url" : "http:\/\/flic.kr\/p\/dGy1d5",
      "display_url" : "flic.kr\/p\/dGy1d5"
    } ]
  },
  "geo" : { },
  "id_str" : "286212312942120961",
  "text" : "Hidden View back yard http:\/\/t.co\/pzcmqmZs",
  "id" : 286212312942120961,
  "created_at" : "2013-01-01 20:48:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/wTVjoqge",
      "expanded_url" : "http:\/\/instagr.am\/p\/T89uBfo0EP\/",
      "display_url" : "instagr.am\/p\/T89uBfo0EP\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.9790270467, -76.6098354244 ]
  },
  "id_str" : "286189846811250689",
  "text" : "Hidden View dining room @ Hidden View Farm http:\/\/t.co\/wTVjoqge",
  "id" : 286189846811250689,
  "created_at" : "2013-01-01 19:19:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]