Grailbird.data.tweets_2013_02 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307394246439215104",
  "geo" : { },
  "id_str" : "307394442430664704",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm What was your game?",
  "id" : 307394442430664704,
  "in_reply_to_status_id" : 307394246439215104,
  "created_at" : "2013-03-01 07:38:40 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307393644309147648",
  "geo" : { },
  "id_str" : "307393827361128448",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm I have to make a Twitter game out of pretty much anything I want to get done in a day. :)",
  "id" : 307393827361128448,
  "in_reply_to_status_id" : 307393644309147648,
  "created_at" : "2013-03-01 07:36:14 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/sHNQptqg7S",
      "expanded_url" : "http:\/\/bit.ly\/Yad1FN",
      "display_url" : "bit.ly\/Yad1FN"
    } ]
  },
  "geo" : { },
  "id_str" : "307393106385465344",
  "text" : "993. Did my first weigh-in on http:\/\/t.co\/sHNQptqg7S which worked for me last time. If you want to lose weight, join us!",
  "id" : 307393106385465344,
  "created_at" : "2013-03-01 07:33:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 0, 14 ],
      "id_str" : "820661",
      "id" : 820661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307386597828079616",
  "geo" : { },
  "id_str" : "307386961532944384",
  "in_reply_to_user_id" : 820661,
  "text" : "@daveschappell True. Unfortunately my brain only likes the aesthetic of running. And this is more about mental challenge than physical.",
  "id" : 307386961532944384,
  "in_reply_to_status_id" : 307386597828079616,
  "created_at" : "2013-03-01 07:08:57 +0000",
  "in_reply_to_screen_name" : "daveschappell",
  "in_reply_to_user_id_str" : "820661",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 0, 14 ],
      "id_str" : "820661",
      "id" : 820661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307384822781865984",
  "geo" : { },
  "id_str" : "307385154932969472",
  "in_reply_to_user_id" : 820661,
  "text" : "@daveschappell Somewhere in Santa Monica perhaps?",
  "id" : 307385154932969472,
  "in_reply_to_status_id" : 307384822781865984,
  "created_at" : "2013-03-01 07:01:46 +0000",
  "in_reply_to_screen_name" : "daveschappell",
  "in_reply_to_user_id_str" : "820661",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307382386163859456",
  "geo" : { },
  "id_str" : "307382949358227456",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates What if everywhere he went was still in the woods?",
  "id" : 307382949358227456,
  "in_reply_to_status_id" : 307382386163859456,
  "created_at" : "2013-03-01 06:53:00 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307381841034354689",
  "geo" : { },
  "id_str" : "307382048170053632",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates The real question: what would Dr Who do?",
  "id" : 307382048170053632,
  "in_reply_to_status_id" : 307381841034354689,
  "created_at" : "2013-03-01 06:49:25 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307381169945714688",
  "geo" : { },
  "id_str" : "307381514256134144",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Now who's the weird one.",
  "id" : 307381514256134144,
  "in_reply_to_status_id" : 307381169945714688,
  "created_at" : "2013-03-01 06:47:18 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hyped up aka popular",
      "screen_name" : "iano",
      "indices" : [ 0, 5 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307381202531266560",
  "geo" : { },
  "id_str" : "307381279865847809",
  "in_reply_to_user_id" : 14409856,
  "text" : "@iano depends on your carrier.",
  "id" : 307381279865847809,
  "in_reply_to_status_id" : 307381202531266560,
  "created_at" : "2013-03-01 06:46:22 +0000",
  "in_reply_to_screen_name" : "iano",
  "in_reply_to_user_id_str" : "14409856",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Morrill",
      "screen_name" : "DanielleMorrill",
      "indices" : [ 3, 19 ],
      "id_str" : "7017692",
      "id" : 7017692
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 21, 28 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307380942316646400",
  "text" : "RT @DanielleMorrill: @buster I'd try to stay in the woods forever",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "307379827596480512",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.78918377, -122.3899887459 ]
    },
    "id_str" : "307380556079960064",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster I'd try to stay in the woods forever",
    "id" : 307380556079960064,
    "in_reply_to_status_id" : 307379827596480512,
    "created_at" : "2013-03-01 06:43:30 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Danielle Morrill",
      "screen_name" : "DanielleMorrill",
      "protected" : false,
      "id_str" : "7017692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464640302108536832\/IcWYsMUy_normal.jpeg",
      "id" : 7017692,
      "verified" : false
    }
  },
  "id" : 307380942316646400,
  "created_at" : "2013-03-01 06:45:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 3, 13 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 15, 22 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307380923664564224",
  "text" : "RT @tomcoates: @buster Fuckin' weird bunch of woods, is what I'm thinking.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "307380590833983489",
    "geo" : { },
    "id_str" : "307380756311834624",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster Fuckin' weird bunch of woods, is what I'm thinking.",
    "id" : 307380756311834624,
    "in_reply_to_status_id" : 307380590833983489,
    "created_at" : "2013-03-01 06:44:17 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "protected" : false,
      "id_str" : "12514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459820658327683072\/I_qV0WKP_normal.png",
      "id" : 12514,
      "verified" : false
    }
  },
  "id" : 307380923664564224,
  "created_at" : "2013-03-01 06:44:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307380176751312896",
  "geo" : { },
  "id_str" : "307380590833983489",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates The woods are meaningless, complex, unfair, and unpredictable, but also responsive.",
  "id" : 307380590833983489,
  "in_reply_to_status_id" : 307380176751312896,
  "created_at" : "2013-03-01 06:43:38 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307379827596480512",
  "text" : "You're in the woods. When you leave the woods, life is over. Do you run through? Look for short cuts? Stop? Sink your teeth into the woods.",
  "id" : 307379827596480512,
  "created_at" : "2013-03-01 06:40:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307375854944665601",
  "text" : "Outliers is to the self-improvement\/success industry what Fooled By Randomness is to the stock market\/day-trading industry.",
  "id" : 307375854944665601,
  "created_at" : "2013-03-01 06:24:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RunKeeper",
      "screen_name" : "RunKeeper",
      "indices" : [ 19, 29 ],
      "id_str" : "15445811",
      "id" : 15445811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/tUO80GrU4u",
      "expanded_url" : "http:\/\/bit.ly\/WkPMeU",
      "display_url" : "bit.ly\/WkPMeU"
    } ]
  },
  "geo" : { },
  "id_str" : "307369333695340544",
  "text" : "994. Dusted off my @runkeeper profile too. Friend me there if you're running much between now and Sep 29th. http:\/\/t.co\/tUO80GrU4u",
  "id" : 307369333695340544,
  "created_at" : "2013-03-01 05:58:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Stamatiou",
      "screen_name" : "Stammy",
      "indices" : [ 0, 7 ],
      "id_str" : "624683",
      "id" : 624683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307046132326989825",
  "geo" : { },
  "id_str" : "307368032848728064",
  "in_reply_to_user_id" : 624683,
  "text" : "@Stammy Definitely say hi next time! Just joined tweetfeet@ too so I might see you there\u2026 do you run on specific days?",
  "id" : 307368032848728064,
  "in_reply_to_status_id" : 307046132326989825,
  "created_at" : "2013-03-01 05:53:44 +0000",
  "in_reply_to_screen_name" : "Stammy",
  "in_reply_to_user_id_str" : "624683",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Stamatiou",
      "screen_name" : "Stammy",
      "indices" : [ 0, 7 ],
      "id_str" : "624683",
      "id" : 624683
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 12, 20 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307045513193201665",
  "geo" : { },
  "id_str" : "307367095568592896",
  "in_reply_to_user_id" : 624683,
  "text" : "@Stammy The @mybasis watch is sort of magical and awesome. It still needs: an iPhone app, an API, and Bluetooth sync. But I have high hopes.",
  "id" : 307367095568592896,
  "in_reply_to_status_id" : 307045513193201665,
  "created_at" : "2013-03-01 05:50:00 +0000",
  "in_reply_to_screen_name" : "Stammy",
  "in_reply_to_user_id_str" : "624683",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 85, 96 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/pfqKs33jHx",
      "expanded_url" : "http:\/\/bit.ly\/WkP69h",
      "display_url" : "bit.ly\/WkP69h"
    } ]
  },
  "geo" : { },
  "id_str" : "307366507917217792",
  "text" : "995. Totally just registered for the Lake Tahoe Marathon on Sep 29! Thx for the tip, @TheCulprit! Anyone else? http:\/\/t.co\/pfqKs33jHx",
  "id" : 307366507917217792,
  "created_at" : "2013-03-01 05:47:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307361523884490752",
  "text" : "996. Decided against my regular evening adult beverage tonight. Definitely counts as a small thing at this stage of the game.",
  "id" : 307361523884490752,
  "created_at" : "2013-03-01 05:27:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/YthP9XL3DG",
      "expanded_url" : "http:\/\/flic.kr\/p\/dYBvvv",
      "display_url" : "flic.kr\/p\/dYBvvv"
    } ]
  },
  "geo" : { },
  "id_str" : "307359631141916672",
  "text" : "8:36pm Just had a long conversation about what giants do when they find you. http:\/\/t.co\/YthP9XL3DG",
  "id" : 307359631141916672,
  "created_at" : "2013-03-01 05:20:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 3, 14 ],
      "id_str" : "3452941",
      "id" : 3452941
    }, {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "indices" : [ 93, 102 ],
      "id_str" : "255784266",
      "id" : 255784266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/ccJTgA2Wy2",
      "expanded_url" : "http:\/\/www.geekwire.com\/2013\/twitter\/",
      "display_url" : "geekwire.com\/2013\/twitter\/"
    } ]
  },
  "geo" : { },
  "id_str" : "307351127987466240",
  "text" : "RT @moniguzman: Fun with your Twitter archive: What I learned from 18,000 tweets - latest on @geekwire http:\/\/t.co\/ccJTgA2Wy2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GeekWire",
        "screen_name" : "geekwire",
        "indices" : [ 77, 86 ],
        "id_str" : "255784266",
        "id" : 255784266
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/ccJTgA2Wy2",
        "expanded_url" : "http:\/\/www.geekwire.com\/2013\/twitter\/",
        "display_url" : "geekwire.com\/2013\/twitter\/"
      } ]
    },
    "geo" : { },
    "id_str" : "307342077530865668",
    "text" : "Fun with your Twitter archive: What I learned from 18,000 tweets - latest on @geekwire http:\/\/t.co\/ccJTgA2Wy2",
    "id" : 307342077530865668,
    "created_at" : "2013-03-01 04:10:36 +0000",
    "user" : {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "protected" : false,
      "id_str" : "3452941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454510513251037184\/83aM56tP_normal.jpeg",
      "id" : 3452941,
      "verified" : false
    }
  },
  "id" : 307351127987466240,
  "created_at" : "2013-03-01 04:46:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 0, 12 ],
      "id_str" : "195863654",
      "id" : 195863654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307303334761607168",
  "geo" : { },
  "id_str" : "307303735816753153",
  "in_reply_to_user_id" : 195863654,
  "text" : "@marihuertas Cool, let me know what you decide. One last rec: have you checked out the Moves app? No wearable tech required.",
  "id" : 307303735816753153,
  "in_reply_to_status_id" : 307303334761607168,
  "created_at" : "2013-03-01 01:38:14 +0000",
  "in_reply_to_screen_name" : "marihuertas",
  "in_reply_to_user_id_str" : "195863654",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 0, 12 ],
      "id_str" : "195863654",
      "id" : 195863654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307301239744516096",
  "geo" : { },
  "id_str" : "307302386991517696",
  "in_reply_to_user_id" : 195863654,
  "text" : "@marihuertas Downside is that there's no app yet, and no API yet, and doesn't sync over bluetooth yet. All those things are coming though.",
  "id" : 307302386991517696,
  "in_reply_to_status_id" : 307301239744516096,
  "created_at" : "2013-03-01 01:32:53 +0000",
  "in_reply_to_screen_name" : "marihuertas",
  "in_reply_to_user_id_str" : "195863654",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 0, 12 ],
      "id_str" : "195863654",
      "id" : 195863654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307301239744516096",
  "geo" : { },
  "id_str" : "307302206397358080",
  "in_reply_to_user_id" : 195863654,
  "text" : "@marihuertas For example, it is much better at detecting when you wake up, and when you fall asleep. Also, seeing heartbeat data is magic.",
  "id" : 307302206397358080,
  "in_reply_to_status_id" : 307301239744516096,
  "created_at" : "2013-03-01 01:32:10 +0000",
  "in_reply_to_screen_name" : "marihuertas",
  "in_reply_to_user_id_str" : "195863654",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 0, 12 ],
      "id_str" : "195863654",
      "id" : 195863654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307301239744516096",
  "geo" : { },
  "id_str" : "307301982564139008",
  "in_reply_to_user_id" : 195863654,
  "text" : "@marihuertas It is bulkier than the bands. But heartbeat + perspiration + skin temp + + good data vis = way better data.",
  "id" : 307301982564139008,
  "in_reply_to_status_id" : 307301239744516096,
  "created_at" : "2013-03-01 01:31:16 +0000",
  "in_reply_to_screen_name" : "marihuertas",
  "in_reply_to_user_id_str" : "195863654",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 0, 12 ],
      "id_str" : "195863654",
      "id" : 195863654
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 42, 50 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307300450301005825",
  "geo" : { },
  "id_str" : "307300879860645888",
  "in_reply_to_user_id" : 195863654,
  "text" : "@marihuertas Yeah, that does win. But the @mybasis watch should also a top contender. I've had one for a couple weeks - it's awesome.",
  "id" : 307300879860645888,
  "in_reply_to_status_id" : 307300450301005825,
  "created_at" : "2013-03-01 01:26:53 +0000",
  "in_reply_to_screen_name" : "marihuertas",
  "in_reply_to_user_id_str" : "195863654",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Jacobs",
      "screen_name" : "evanjacobs",
      "indices" : [ 0, 11 ],
      "id_str" : "14803483",
      "id" : 14803483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307286147615322113",
  "geo" : { },
  "id_str" : "307286516235902976",
  "in_reply_to_user_id" : 14803483,
  "text" : "@evanjacobs Jealous. So do you know where we are? 1355 Market St. Your name will be on the list, come to 9th floor, text me. 206-355-9718",
  "id" : 307286516235902976,
  "in_reply_to_status_id" : 307286147615322113,
  "created_at" : "2013-03-01 00:29:49 +0000",
  "in_reply_to_screen_name" : "evanjacobs",
  "in_reply_to_user_id_str" : "14803483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Jacobs",
      "screen_name" : "evanjacobs",
      "indices" : [ 0, 11 ],
      "id_str" : "14803483",
      "id" : 14803483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307285300877590530",
  "geo" : { },
  "id_str" : "307285550145085446",
  "in_reply_to_user_id" : 14803483,
  "text" : "@evanjacobs 10am tomorrow could work. How's the conference?",
  "id" : 307285550145085446,
  "in_reply_to_status_id" : 307285300877590530,
  "created_at" : "2013-03-01 00:25:58 +0000",
  "in_reply_to_screen_name" : "evanjacobs",
  "in_reply_to_user_id_str" : "14803483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avi Bryant",
      "screen_name" : "avibryant",
      "indices" : [ 3, 13 ],
      "id_str" : "13192",
      "id" : 13192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/Lt1xBi5BEU",
      "expanded_url" : "http:\/\/allthingsd.com\/20130228\/groupon-dumps-andrew-mason-as-ceo\/",
      "display_url" : "allthingsd.com\/20130228\/group\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307247090436804608",
  "text" : "RT @avibryant: Say what you will about Andrew Mason and Groupon, he knows how to write a memo. http:\/\/t.co\/Lt1xBi5BEU",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/Lt1xBi5BEU",
        "expanded_url" : "http:\/\/allthingsd.com\/20130228\/groupon-dumps-andrew-mason-as-ceo\/",
        "display_url" : "allthingsd.com\/20130228\/group\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "307245052961378304",
    "text" : "Say what you will about Andrew Mason and Groupon, he knows how to write a memo. http:\/\/t.co\/Lt1xBi5BEU",
    "id" : 307245052961378304,
    "created_at" : "2013-02-28 21:45:03 +0000",
    "user" : {
      "name" : "Avi Bryant",
      "screen_name" : "avibryant",
      "protected" : false,
      "id_str" : "13192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/452471447047254016\/f1QJrHB0_normal.png",
      "id" : 13192,
      "verified" : false
    }
  },
  "id" : 307247090436804608,
  "created_at" : "2013-02-28 21:53:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307235537071247362",
  "geo" : { },
  "id_str" : "307242536269934592",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit Ooh, both of those look like great options. Are you going to either? And which one is flatter? :)",
  "id" : 307242536269934592,
  "in_reply_to_status_id" : 307235537071247362,
  "created_at" : "2013-02-28 21:35:03 +0000",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matilda444",
      "screen_name" : "Matilda444",
      "indices" : [ 0, 11 ],
      "id_str" : "4250751",
      "id" : 4250751
    }, {
      "name" : "Hal Higdon",
      "screen_name" : "higdonmarathon",
      "indices" : [ 44, 59 ],
      "id_str" : "180516047",
      "id" : 180516047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307233125384200193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762083112, -122.417303069 ]
  },
  "id_str" : "307234282324234240",
  "in_reply_to_user_id" : 4250751,
  "text" : "@Matilda444 Nope, but I am now! Thanks. \/cc @higdonmarathon",
  "id" : 307234282324234240,
  "in_reply_to_status_id" : 307233125384200193,
  "created_at" : "2013-02-28 21:02:15 +0000",
  "in_reply_to_screen_name" : "Matilda444",
  "in_reply_to_user_id_str" : "4250751",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307232956949352449",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762510344, -122.417407902 ]
  },
  "id_str" : "307233470248280065",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit I am attempting to! Not sure which race though. Any good ones in Sept?",
  "id" : 307233470248280065,
  "in_reply_to_status_id" : 307232956949352449,
  "created_at" : "2013-02-28 20:59:02 +0000",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Runner's World",
      "screen_name" : "runnersworld",
      "indices" : [ 11, 24 ],
      "id_str" : "14882900",
      "id" : 14882900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307230006835281920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762898465, -122.4172858873 ]
  },
  "id_str" : "307230992870014976",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame @runnersworld Followed! And turned on notifications even. :)",
  "id" : 307230992870014976,
  "in_reply_to_status_id" : 307230006835281920,
  "created_at" : "2013-02-28 20:49:11 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/307228815581646848\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/h54y5RbcmE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEN--uHCEAEAU9k.jpg",
      "id_str" : "307228815585841153",
      "id" : 307228815585841153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEN--uHCEAEAU9k.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/h54y5RbcmE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7761927778, -122.417558312 ]
  },
  "id_str" : "307228815581646848",
  "text" : "997. What do aspiring marathoners eat for lunch? My best guess. http:\/\/t.co\/h54y5RbcmE",
  "id" : 307228815581646848,
  "created_at" : "2013-02-28 20:40:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764470159, -122.4167399725 ]
  },
  "id_str" : "307182188166778882",
  "text" : "998. Listening to Outliers audiobook on BART. Chinese proverb \"No one who rises before dawn 360 days a year fails to make his family rich.\"",
  "id" : 307182188166778882,
  "created_at" : "2013-02-28 17:35:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JT Kane",
      "screen_name" : "jt_w_lightning",
      "indices" : [ 0, 15 ],
      "id_str" : "27724967",
      "id" : 27724967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307179135460065280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764647992, -122.4167246714 ]
  },
  "id_str" : "307181422794395649",
  "in_reply_to_user_id" : 27724967,
  "text" : "@jt_w_lightning Not yet. One in Sept or Oct most likely. Know any good candidates?",
  "id" : 307181422794395649,
  "in_reply_to_status_id" : 307179135460065280,
  "created_at" : "2013-02-28 17:32:13 +0000",
  "in_reply_to_screen_name" : "jt_w_lightning",
  "in_reply_to_user_id_str" : "27724967",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Jacobs",
      "screen_name" : "evanjacobs",
      "indices" : [ 0, 11 ],
      "id_str" : "14803483",
      "id" : 14803483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307178814289625088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776458123, -122.4167158136 ]
  },
  "id_str" : "307181213825777664",
  "in_reply_to_user_id" : 14803483,
  "text" : "@evanjacobs I'm not, but would love to show you Twitter HQ if you have time to drop by.",
  "id" : 307181213825777664,
  "in_reply_to_status_id" : 307178814289625088,
  "created_at" : "2013-02-28 17:31:23 +0000",
  "in_reply_to_screen_name" : "evanjacobs",
  "in_reply_to_user_id_str" : "14803483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Bez",
      "screen_name" : "lejoe",
      "indices" : [ 0, 6 ],
      "id_str" : "2129311",
      "id" : 2129311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307175875097546753",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7844963843, -122.4078909642 ]
  },
  "id_str" : "307177191068811264",
  "in_reply_to_user_id" : 2129311,
  "text" : "@lejoe Thank you!",
  "id" : 307177191068811264,
  "in_reply_to_status_id" : 307175875097546753,
  "created_at" : "2013-02-28 17:15:24 +0000",
  "in_reply_to_screen_name" : "lejoe",
  "in_reply_to_user_id_str" : "2129311",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307173803224625152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.784459161, -122.4079411743 ]
  },
  "id_str" : "307177147603251201",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver It starts to hurt around 3 miles too. Hoping that stretching and lunges will continue to help.",
  "id" : 307177147603251201,
  "in_reply_to_status_id" : 307173803224625152,
  "created_at" : "2013-02-28 17:15:13 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8046377255, -122.2950800517 ]
  },
  "id_str" : "307172375043125249",
  "text" : "999. First morning run around the neighborhood.",
  "id" : 307172375043125249,
  "created_at" : "2013-02-28 16:56:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/kO4I77Bqss",
      "expanded_url" : "http:\/\/wayoftheduck.com\/1000-small-things",
      "display_url" : "wayoftheduck.com\/1000-small-thi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8284904594, -122.2673544009 ]
  },
  "id_str" : "307170533303275520",
  "text" : "1000. Declaring a start. http:\/\/t.co\/kO4I77Bqss",
  "id" : 307170533303275520,
  "created_at" : "2013-02-28 16:48:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Stamatiou",
      "screen_name" : "Stammy",
      "indices" : [ 0, 7 ],
      "id_str" : "624683",
      "id" : 624683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307043532588318720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595833954, -122.2753829492 ]
  },
  "id_str" : "307044487664910336",
  "in_reply_to_user_id" : 624683,
  "text" : "@Stammy Ooh good idea! And wow, 1000 miles is a lot!",
  "id" : 307044487664910336,
  "in_reply_to_status_id" : 307043532588318720,
  "created_at" : "2013-02-28 08:28:05 +0000",
  "in_reply_to_screen_name" : "Stammy",
  "in_reply_to_user_id_str" : "624683",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/xNLM3pz3KH",
      "expanded_url" : "http:\/\/flic.kr\/p\/dYtpL9",
      "display_url" : "flic.kr\/p\/dYtpL9"
    } ]
  },
  "geo" : { },
  "id_str" : "307006562352914432",
  "text" : "8:36pm Just daydreaming about work ideas in the kitchen http:\/\/t.co\/xNLM3pz3KH",
  "id" : 307006562352914432,
  "created_at" : "2013-02-28 05:57:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hall",
      "screen_name" : "JamesHallPhoto",
      "indices" : [ 0, 15 ],
      "id_str" : "63792306",
      "id" : 63792306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306970701070483456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596342471, -122.2754403357 ]
  },
  "id_str" : "306982280742719488",
  "in_reply_to_user_id" : 63792306,
  "text" : "@JamesHallPhoto Ha, I can't remember where it's from either! Was it from that crazy podcast that you and Kharis ambushed me with perhaps?",
  "id" : 306982280742719488,
  "in_reply_to_status_id" : 306970701070483456,
  "created_at" : "2013-02-28 04:20:53 +0000",
  "in_reply_to_screen_name" : "JamesHallPhoto",
  "in_reply_to_user_id_str" : "63792306",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Ewing",
      "screen_name" : "hoverbird",
      "indices" : [ 0, 10 ],
      "id_str" : "792690",
      "id" : 792690
    }, {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 11, 13 ],
      "id_str" : "11222",
      "id" : 11222
    }, {
      "name" : "Kevin Weil",
      "screen_name" : "kevinweil",
      "indices" : [ 14, 24 ],
      "id_str" : "3452911",
      "id" : 3452911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306956565989183488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595984262, -122.2755733599 ]
  },
  "id_str" : "306967003783131136",
  "in_reply_to_user_id" : 792690,
  "text" : "@hoverbird @k @kevinweil We still don't show impressions though.",
  "id" : 306967003783131136,
  "in_reply_to_status_id" : 306956565989183488,
  "created_at" : "2013-02-28 03:20:11 +0000",
  "in_reply_to_screen_name" : "hoverbird",
  "in_reply_to_user_id_str" : "792690",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hall",
      "screen_name" : "JamesHallPhoto",
      "indices" : [ 0, 15 ],
      "id_str" : "63792306",
      "id" : 63792306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306961527292977153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596302747, -122.2752839449 ]
  },
  "id_str" : "306964457127542786",
  "in_reply_to_user_id" : 63792306,
  "text" : "@JamesHallPhoto They should research the list... unfortunately I don't know them well enough to know who does what best.",
  "id" : 306964457127542786,
  "in_reply_to_status_id" : 306961527292977153,
  "created_at" : "2013-02-28 03:10:04 +0000",
  "in_reply_to_screen_name" : "JamesHallPhoto",
  "in_reply_to_user_id_str" : "63792306",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hall",
      "screen_name" : "JamesHallPhoto",
      "indices" : [ 0, 15 ],
      "id_str" : "63792306",
      "id" : 63792306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306942260589772800",
  "geo" : { },
  "id_str" : "306943162004414464",
  "in_reply_to_user_id" : 63792306,
  "text" : "@JamesHallPhoto Some companies can approximate reach, but right now Twitter doesn't share that info.",
  "id" : 306943162004414464,
  "in_reply_to_status_id" : 306942260589772800,
  "created_at" : "2013-02-28 01:45:27 +0000",
  "in_reply_to_screen_name" : "JamesHallPhoto",
  "in_reply_to_user_id_str" : "63792306",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hall",
      "screen_name" : "JamesHallPhoto",
      "indices" : [ 0, 15 ],
      "id_str" : "63792306",
      "id" : 63792306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/PMqHzSjqFP",
      "expanded_url" : "http:\/\/bit.ly\/XbVZZ0",
      "display_url" : "bit.ly\/XbVZZ0"
    } ]
  },
  "in_reply_to_status_id_str" : "306937905618755585",
  "geo" : { },
  "id_str" : "306939132763066368",
  "in_reply_to_user_id" : 63792306,
  "text" : "@JamesHallPhoto What do they want to track? Not much is really available yet, but these companies do some: http:\/\/t.co\/PMqHzSjqFP",
  "id" : 306939132763066368,
  "in_reply_to_status_id" : 306937905618755585,
  "created_at" : "2013-02-28 01:29:26 +0000",
  "in_reply_to_screen_name" : "JamesHallPhoto",
  "in_reply_to_user_id_str" : "63792306",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hall",
      "screen_name" : "JamesHallPhoto",
      "indices" : [ 0, 15 ],
      "id_str" : "63792306",
      "id" : 63792306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/eC3UqZUjX8",
      "expanded_url" : "http:\/\/Twitter.com",
      "display_url" : "Twitter.com"
    } ]
  },
  "in_reply_to_status_id_str" : "306840580124708864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769069463, -122.4172399332 ]
  },
  "id_str" : "306850101316448256",
  "in_reply_to_user_id" : 63792306,
  "text" : "@JamesHallPhoto Yeah me too. :) http:\/\/t.co\/eC3UqZUjX8 and TweetDeck are about equally slow.",
  "id" : 306850101316448256,
  "in_reply_to_status_id" : 306840580124708864,
  "created_at" : "2013-02-27 19:35:39 +0000",
  "in_reply_to_screen_name" : "JamesHallPhoto",
  "in_reply_to_user_id_str" : "63792306",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596379469, -122.2754659877 ]
  },
  "id_str" : "306649353509011456",
  "text" : "Levitas, the opposite of gravitas.",
  "id" : 306649353509011456,
  "created_at" : "2013-02-27 06:17:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306644073081610240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595990091, -122.2753127672 ]
  },
  "id_str" : "306644722628300800",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg People should change their identities every day. We should mourn and celebrate every change. Identity schmidentity.",
  "id" : 306644722628300800,
  "in_reply_to_status_id" : 306644073081610240,
  "created_at" : "2013-02-27 05:59:33 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/vqjgYMHDmo",
      "expanded_url" : "http:\/\/flic.kr\/p\/dYdfqh",
      "display_url" : "flic.kr\/p\/dYdfqh"
    } ]
  },
  "geo" : { },
  "id_str" : "306624772152885249",
  "text" : "8:36pm Talking about hot air bikes http:\/\/t.co\/vqjgYMHDmo",
  "id" : 306624772152885249,
  "created_at" : "2013-02-27 04:40:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/P2r0FyupJG",
      "expanded_url" : "http:\/\/vine.co\/v\/bgL26PqWQHb",
      "display_url" : "vine.co\/v\/bgL26PqWQHb"
    } ]
  },
  "geo" : { },
  "id_str" : "306601890567819265",
  "text" : "Time to relax http:\/\/t.co\/P2r0FyupJG",
  "id" : 306601890567819265,
  "created_at" : "2013-02-27 03:09:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306571144004247552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769397687, -122.4172860699 ]
  },
  "id_str" : "306572766163902464",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten I'm about to start that too. Sounds awesome.",
  "id" : 306572766163902464,
  "in_reply_to_status_id" : 306571144004247552,
  "created_at" : "2013-02-27 01:13:37 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reeve S. Thompson ",
      "screen_name" : "Reeve",
      "indices" : [ 3, 9 ],
      "id_str" : "9317922",
      "id" : 9317922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CODE",
      "indices" : [ 102, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/pUho9FZmaJ",
      "expanded_url" : "http:\/\/code.org",
      "display_url" : "code.org"
    } ]
  },
  "geo" : { },
  "id_str" : "306570354430734336",
  "text" : "RT @Reeve: A true 21st century skill, all kids should get the chance to code - http:\/\/t.co\/pUho9FZmaJ #CODE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CODE",
        "indices" : [ 91, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/pUho9FZmaJ",
        "expanded_url" : "http:\/\/code.org",
        "display_url" : "code.org"
      } ]
    },
    "geo" : { },
    "id_str" : "306560092977909760",
    "text" : "A true 21st century skill, all kids should get the chance to code - http:\/\/t.co\/pUho9FZmaJ #CODE",
    "id" : 306560092977909760,
    "created_at" : "2013-02-27 00:23:16 +0000",
    "user" : {
      "name" : "Reeve S. Thompson ",
      "screen_name" : "Reeve",
      "protected" : false,
      "id_str" : "9317922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000770789536\/f4b1befc193bde9183ac2b1b722c1f4a_normal.png",
      "id" : 9317922,
      "verified" : false
    }
  },
  "id" : 306570354430734336,
  "created_at" : "2013-02-27 01:04:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 3, 12 ],
      "id_str" : "14986129",
      "id" : 14986129
    }, {
      "name" : "Bram Cohen",
      "screen_name" : "bramcohen",
      "indices" : [ 29, 39 ],
      "id_str" : "17201709",
      "id" : 17201709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/nesKICyE0W",
      "expanded_url" : "http:\/\/qr.ae\/TntmO",
      "display_url" : "qr.ae\/TntmO"
    } ]
  },
  "geo" : { },
  "id_str" : "306569846303375361",
  "text" : "RT @irondavy: Neat answer by @bramcohen to \"What are some strategies for winning 'rock, paper, scissors'\"? http:\/\/t.co\/nesKICyE0W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.quora.com\/\" rel=\"nofollow\"\u003EQuora\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bram Cohen",
        "screen_name" : "bramcohen",
        "indices" : [ 15, 25 ],
        "id_str" : "17201709",
        "id" : 17201709
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/nesKICyE0W",
        "expanded_url" : "http:\/\/qr.ae\/TntmO",
        "display_url" : "qr.ae\/TntmO"
      } ]
    },
    "geo" : { },
    "id_str" : "306558291457236992",
    "text" : "Neat answer by @bramcohen to \"What are some strategies for winning 'rock, paper, scissors'\"? http:\/\/t.co\/nesKICyE0W",
    "id" : 306558291457236992,
    "created_at" : "2013-02-27 00:16:06 +0000",
    "user" : {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "protected" : false,
      "id_str" : "14986129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460097018266779648\/sDfnmwhH_normal.jpeg",
      "id" : 14986129,
      "verified" : false
    }
  },
  "id" : 306569846303375361,
  "created_at" : "2013-02-27 01:02:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/xtvynxwdDy",
      "expanded_url" : "http:\/\/bit.ly\/YAkr6c",
      "display_url" : "bit.ly\/YAkr6c"
    } ]
  },
  "geo" : { },
  "id_str" : "306463967222591488",
  "text" : "'To a normal English speaker, \"Hi, I\u2019m Mxyztplk\" is basically indistinguishable from \"Hi, I\u2019m Mxzkqklt\"' - xkcd http:\/\/t.co\/xtvynxwdDy",
  "id" : 306463967222591488,
  "created_at" : "2013-02-26 18:01:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 3, 18 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306292857562611712",
  "text" : "RT @mikeindustries: People dissing Google Glass shouldn't forget that it's simply an iteration towards retinal implants. Ignore it at yo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306292784552357888",
    "text" : "People dissing Google Glass shouldn't forget that it's simply an iteration towards retinal implants. Ignore it at your peril (or pleasure).",
    "id" : 306292784552357888,
    "created_at" : "2013-02-26 06:41:05 +0000",
    "user" : {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "protected" : false,
      "id_str" : "74523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430955581830995968\/sSqK3_b9_normal.jpeg",
      "id" : 74523,
      "verified" : false
    }
  },
  "id" : 306292857562611712,
  "created_at" : "2013-02-26 06:41:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hall",
      "screen_name" : "JamesHallPhoto",
      "indices" : [ 0, 15 ],
      "id_str" : "63792306",
      "id" : 63792306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306263573024346112",
  "geo" : { },
  "id_str" : "306281989890248706",
  "in_reply_to_user_id" : 63792306,
  "text" : "@JamesHallPhoto I *do* like that. Though I wonder if it's on sales, since MP3s and Napster were a big influence on change pre-2004.",
  "id" : 306281989890248706,
  "in_reply_to_status_id" : 306263573024346112,
  "created_at" : "2013-02-26 05:58:11 +0000",
  "in_reply_to_screen_name" : "JamesHallPhoto",
  "in_reply_to_user_id_str" : "63792306",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iman Abdulmajid",
      "screen_name" : "The_Real_IMAN",
      "indices" : [ 3, 17 ],
      "id_str" : "182972598",
      "id" : 182972598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/55LcNEeuZp",
      "expanded_url" : "http:\/\/bit.ly\/YuooY5",
      "display_url" : "bit.ly\/YuooY5"
    } ]
  },
  "geo" : { },
  "id_str" : "306276055260471297",
  "text" : "RT @The_Real_IMAN: BOWIE NEW SINGLE! IT'S BEYOND!!!\nhttp:\/\/t.co\/55LcNEeuZp",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/55LcNEeuZp",
        "expanded_url" : "http:\/\/bit.ly\/YuooY5",
        "display_url" : "bit.ly\/YuooY5"
      } ]
    },
    "geo" : { },
    "id_str" : "306260177429090304",
    "text" : "BOWIE NEW SINGLE! IT'S BEYOND!!!\nhttp:\/\/t.co\/55LcNEeuZp",
    "id" : 306260177429090304,
    "created_at" : "2013-02-26 04:31:30 +0000",
    "user" : {
      "name" : "Iman Abdulmajid",
      "screen_name" : "The_Real_IMAN",
      "protected" : false,
      "id_str" : "182972598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3439757193\/f2087b95b5fe3f884412d44f19fb3981_normal.jpeg",
      "id" : 182972598,
      "verified" : true
    }
  },
  "id" : 306276055260471297,
  "created_at" : "2013-02-26 05:34:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "indices" : [ 3, 16 ],
      "id_str" : "16906137",
      "id" : 16906137
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FiveWordTEDTalks",
      "indices" : [ 59, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306272101835354112",
  "text" : "RT @pourmecoffee: My oversimplification seems like wisdom. #FiveWordTEDTalks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FiveWordTEDTalks",
        "indices" : [ 41, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "174310449066680322",
    "text" : "My oversimplification seems like wisdom. #FiveWordTEDTalks",
    "id" : 174310449066680322,
    "created_at" : "2012-02-28 01:50:24 +0000",
    "user" : {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "protected" : false,
      "id_str" : "16906137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421566216\/coffee1242220886_normal.jpg",
      "id" : 16906137,
      "verified" : true
    }
  },
  "id" : 306272101835354112,
  "created_at" : "2013-02-26 05:18:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/ZlU1YTdj6I",
      "expanded_url" : "http:\/\/flic.kr\/p\/dXRTDa",
      "display_url" : "flic.kr\/p\/dXRTDa"
    } ]
  },
  "geo" : { },
  "id_str" : "306270272183492608",
  "text" : "8:36pm Little burrito http:\/\/t.co\/ZlU1YTdj6I",
  "id" : 306270272183492608,
  "created_at" : "2013-02-26 05:11:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/ZM531GijXm",
      "expanded_url" : "http:\/\/vine.co\/v\/bgP2x1mxZQp",
      "display_url" : "vine.co\/v\/bgP2x1mxZQp"
    } ]
  },
  "geo" : { },
  "id_str" : "306269763674439683",
  "text" : "Reading bedtime stories to himself http:\/\/t.co\/ZM531GijXm",
  "id" : 306269763674439683,
  "created_at" : "2013-02-26 05:09:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Nathan Kontny",
      "screen_name" : "natekontny",
      "indices" : [ 88, 99 ],
      "id_str" : "17386551",
      "id" : 17386551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/n90u2MZGFr",
      "expanded_url" : "http:\/\/draftin.com",
      "display_url" : "draftin.com"
    }, {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/jnJaXzKSML",
      "expanded_url" : "http:\/\/ninjasandrobots.com\/draft-preview-uber-for-writing",
      "display_url" : "ninjasandrobots.com\/draft-preview-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "306235312873549826",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597700808, -122.2753484992 ]
  },
  "id_str" : "306258517612982273",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver http:\/\/t.co\/n90u2MZGFr is new but pretty promising. http:\/\/t.co\/jnJaXzKSML \/cc @natekontny",
  "id" : 306258517612982273,
  "in_reply_to_status_id" : 306235312873549826,
  "created_at" : "2013-02-26 04:24:55 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/MJjwd9I1Dt",
      "expanded_url" : "http:\/\/vine.co\/v\/bgPJtx96HqK",
      "display_url" : "vine.co\/v\/bgPJtx96HqK"
    } ]
  },
  "geo" : { },
  "id_str" : "306254793167474688",
  "text" : "The little engine that could take the stairs http:\/\/t.co\/MJjwd9I1Dt",
  "id" : 306254793167474688,
  "created_at" : "2013-02-26 04:10:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/08G0m5dYSA",
      "expanded_url" : "http:\/\/bit.ly\/W9oiJh",
      "display_url" : "bit.ly\/W9oiJh"
    } ]
  },
  "in_reply_to_status_id_str" : "306173094563823616",
  "geo" : { },
  "id_str" : "306173681728647169",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman What do you want to understand about it? Uploading it to http:\/\/t.co\/08G0m5dYSA has been the most rewarding use of it so far.",
  "id" : 306173681728647169,
  "in_reply_to_status_id" : 306173094563823616,
  "created_at" : "2013-02-25 22:47:48 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nofilter",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/wsR1zuMH7N",
      "expanded_url" : "http:\/\/wayoftheduck.com\/filters",
      "display_url" : "wayoftheduck.com\/filters"
    } ]
  },
  "geo" : { },
  "id_str" : "306105752886587393",
  "text" : "There's no such thing as #nofilter http:\/\/t.co\/wsR1zuMH7N",
  "id" : 306105752886587393,
  "created_at" : "2013-02-25 18:17:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306073222489714688",
  "geo" : { },
  "id_str" : "306077752086392832",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Which book?",
  "id" : 306077752086392832,
  "in_reply_to_status_id" : 306073222489714688,
  "created_at" : "2013-02-25 16:26:37 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gigaom",
      "screen_name" : "gigaom",
      "indices" : [ 3, 10 ],
      "id_str" : "2893971",
      "id" : 2893971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/JruicWVhsB",
      "expanded_url" : "http:\/\/dlvr.it\/30PQ1s",
      "display_url" : "dlvr.it\/30PQ1s"
    } ]
  },
  "geo" : { },
  "id_str" : "305952621448003584",
  "text" : "RT @gigaom: Why Firefox OS may bring balance back to the smartphone industry http:\/\/t.co\/JruicWVhsB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/JruicWVhsB",
        "expanded_url" : "http:\/\/dlvr.it\/30PQ1s",
        "display_url" : "dlvr.it\/30PQ1s"
      } ]
    },
    "geo" : { },
    "id_str" : "305950329399308289",
    "text" : "Why Firefox OS may bring balance back to the smartphone industry http:\/\/t.co\/JruicWVhsB",
    "id" : 305950329399308289,
    "created_at" : "2013-02-25 08:00:17 +0000",
    "user" : {
      "name" : "Gigaom",
      "screen_name" : "gigaom",
      "protected" : false,
      "id_str" : "2893971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458702422479613952\/3I1T5T51_normal.png",
      "id" : 2893971,
      "verified" : true
    }
  },
  "id" : 305952621448003584,
  "created_at" : "2013-02-25 08:09:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Franklin",
      "screen_name" : "AaronSeattle",
      "indices" : [ 0, 13 ],
      "id_str" : "15358390",
      "id" : 15358390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305907635675336704",
  "geo" : { },
  "id_str" : "305917212089266176",
  "in_reply_to_user_id" : 15358390,
  "text" : "@AaronSeattle Just about a month ago. Working at Twitter now. :)",
  "id" : 305917212089266176,
  "in_reply_to_status_id" : 305907635675336704,
  "created_at" : "2013-02-25 05:48:41 +0000",
  "in_reply_to_screen_name" : "AaronSeattle",
  "in_reply_to_user_id_str" : "15358390",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 30, 41 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/mFiuNlxFpf",
      "expanded_url" : "http:\/\/flic.kr\/p\/dXFwNY",
      "display_url" : "flic.kr\/p\/dXFwNY"
    } ]
  },
  "geo" : { },
  "id_str" : "305902862913912833",
  "text" : "8:36pm Portrait of a mama, by @nikobenson http:\/\/t.co\/mFiuNlxFpf",
  "id" : 305902862913912833,
  "created_at" : "2013-02-25 04:51:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Crawford",
      "screen_name" : "britt",
      "indices" : [ 0, 6 ],
      "id_str" : "5362",
      "id" : 5362
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 105, 113 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305883778553880578",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8401195538, -122.269643834 ]
  },
  "id_str" : "305892805912432640",
  "in_reply_to_user_id" : 5362,
  "text" : "@britt Yeah so far it's pretty great data. An iPhone app, Bluetooth, and an API would be a home run. \/cc @mybasis",
  "id" : 305892805912432640,
  "in_reply_to_status_id" : 305883778553880578,
  "created_at" : "2013-02-25 04:11:42 +0000",
  "in_reply_to_screen_name" : "britt",
  "in_reply_to_user_id_str" : "5362",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 8, 12 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/qdLWuokbFT",
      "expanded_url" : "http:\/\/vine.co\/v\/bgXQMqpiUI7",
      "display_url" : "vine.co\/v\/bgXQMqpiUI7"
    } ]
  },
  "geo" : { },
  "id_str" : "305869941909884931",
  "text" : "Testing @ian's Google Glass in the bathroom http:\/\/t.co\/qdLWuokbFT",
  "id" : 305869941909884931,
  "created_at" : "2013-02-25 02:40:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/bbrzNyE1nh",
      "expanded_url" : "http:\/\/vine.co\/v\/bgX52atzUhn",
      "display_url" : "vine.co\/v\/bgX52atzUhn"
    } ]
  },
  "geo" : { },
  "id_str" : "305854989685882881",
  "text" : "The long goose chase http:\/\/t.co\/bbrzNyE1nh",
  "id" : 305854989685882881,
  "created_at" : "2013-02-25 01:41:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/E0URNnIaCA",
      "expanded_url" : "http:\/\/tmblr.co\/ZQJvayexEdv2",
      "display_url" : "tmblr.co\/ZQJvayexEdv2"
    } ]
  },
  "geo" : { },
  "id_str" : "305848602733981697",
  "text" : "Panorama: Low tide in Alameda http:\/\/t.co\/E0URNnIaCA",
  "id" : 305848602733981697,
  "created_at" : "2013-02-25 01:16:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/kYXf1EDrZA",
      "expanded_url" : "http:\/\/vine.co\/v\/bggdTj7r91l",
      "display_url" : "vine.co\/v\/bggdTj7r91l"
    } ]
  },
  "geo" : { },
  "id_str" : "305829531082698752",
  "text" : "That was easy(tm) http:\/\/t.co\/kYXf1EDrZA",
  "id" : 305829531082698752,
  "created_at" : "2013-02-25 00:00:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/Jj2Prggmbl",
      "expanded_url" : "http:\/\/flic.kr\/p\/dXts3T",
      "display_url" : "flic.kr\/p\/dXts3T"
    } ]
  },
  "geo" : { },
  "id_str" : "305786806824218627",
  "text" : "Cruisin' in Alameda http:\/\/t.co\/Jj2Prggmbl",
  "id" : 305786806824218627,
  "created_at" : "2013-02-24 21:10:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Emberton",
      "screen_name" : "oliveremberton",
      "indices" : [ 3, 18 ],
      "id_str" : "16004473",
      "id" : 16004473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/bgjKeKJy4M",
      "expanded_url" : "http:\/\/bit.ly\/YKnGpC",
      "display_url" : "bit.ly\/YKnGpC"
    } ]
  },
  "geo" : { },
  "id_str" : "305743112062513152",
  "text" : "RT @oliveremberton: The next frontier isn't to get more efficient, it's to get more brave http:\/\/t.co\/bgjKeKJy4M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/bgjKeKJy4M",
        "expanded_url" : "http:\/\/bit.ly\/YKnGpC",
        "display_url" : "bit.ly\/YKnGpC"
      } ]
    },
    "geo" : { },
    "id_str" : "305741269475397632",
    "text" : "The next frontier isn't to get more efficient, it's to get more brave http:\/\/t.co\/bgjKeKJy4M",
    "id" : 305741269475397632,
    "created_at" : "2013-02-24 18:09:33 +0000",
    "user" : {
      "name" : "Oliver Emberton",
      "screen_name" : "oliveremberton",
      "protected" : false,
      "id_str" : "16004473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499421599\/Oliver-Twitter_normal.jpg",
      "id" : 16004473,
      "verified" : false
    }
  },
  "id" : 305743112062513152,
  "created_at" : "2013-02-24 18:16:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 3, 18 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ZGzTXGg9Yz",
      "expanded_url" : "http:\/\/vimeo.com\/51873011",
      "display_url" : "vimeo.com\/51873011"
    } ]
  },
  "geo" : { },
  "id_str" : "305740991535669248",
  "text" : "RT @mikeindustries: An excellent 3 minute film about a technology that may eventually charge your electric car in one minute: http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/ZGzTXGg9Yz",
        "expanded_url" : "http:\/\/vimeo.com\/51873011",
        "display_url" : "vimeo.com\/51873011"
      } ]
    },
    "geo" : { },
    "id_str" : "305738763802386433",
    "text" : "An excellent 3 minute film about a technology that may eventually charge your electric car in one minute: http:\/\/t.co\/ZGzTXGg9Yz",
    "id" : 305738763802386433,
    "created_at" : "2013-02-24 17:59:36 +0000",
    "user" : {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "protected" : false,
      "id_str" : "74523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430955581830995968\/sSqK3_b9_normal.jpeg",
      "id" : 74523,
      "verified" : false
    }
  },
  "id" : 305740991535669248,
  "created_at" : "2013-02-24 18:08:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Buckhouse",
      "screen_name" : "buckhouse",
      "indices" : [ 104, 114 ],
      "id_str" : "16896060",
      "id" : 16896060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/xG2Bq3uzpP",
      "expanded_url" : "https:\/\/medium.com\/design-story\/44bf7444cc4d",
      "display_url" : "medium.com\/design-story\/4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305738246355296256",
  "text" : "\"Stories operate as tiny machines inside our minds to change how we think.\" https:\/\/t.co\/xG2Bq3uzpP \/by @buckhouse",
  "id" : 305738246355296256,
  "created_at" : "2013-02-24 17:57:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omid Ashtari",
      "screen_name" : "omid",
      "indices" : [ 0, 5 ],
      "id_str" : "114971521",
      "id" : 114971521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305732271141441536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596584403, -122.2755585754 ]
  },
  "id_str" : "305736430246825985",
  "in_reply_to_user_id" : 114971521,
  "text" : "@omid I'll probably try that too.",
  "id" : 305736430246825985,
  "in_reply_to_status_id" : 305732271141441536,
  "created_at" : "2013-02-24 17:50:19 +0000",
  "in_reply_to_screen_name" : "omid",
  "in_reply_to_user_id_str" : "114971521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/0lGxSpfc0l",
      "expanded_url" : "http:\/\/flic.kr\/p\/dXq3hM",
      "display_url" : "flic.kr\/p\/dXq3hM"
    } ]
  },
  "geo" : { },
  "id_str" : "305735913948999680",
  "text" : "Successful branding of my child http:\/\/t.co\/0lGxSpfc0l",
  "id" : 305735913948999680,
  "created_at" : "2013-02-24 17:48:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omid Ashtari",
      "screen_name" : "omid",
      "indices" : [ 0, 5 ],
      "id_str" : "114971521",
      "id" : 114971521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305729446055383041",
  "geo" : { },
  "id_str" : "305731972779606016",
  "in_reply_to_user_id" : 114971521,
  "text" : "@omid A watch is better than a bunch of sensors that you had to wear before this came out. But if you are okay with that\u2026 there are options.",
  "id" : 305731972779606016,
  "in_reply_to_status_id" : 305729446055383041,
  "created_at" : "2013-02-24 17:32:37 +0000",
  "in_reply_to_screen_name" : "omid",
  "in_reply_to_user_id_str" : "114971521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omid Ashtari",
      "screen_name" : "omid",
      "indices" : [ 0, 5 ],
      "id_str" : "114971521",
      "id" : 114971521
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 31, 39 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305723771283714049",
  "geo" : { },
  "id_str" : "305727414397440001",
  "in_reply_to_user_id" : 114971521,
  "text" : "@omid You need the awesome new @mybasis watch. Order quick because there's a long wait.",
  "id" : 305727414397440001,
  "in_reply_to_status_id" : 305723771283714049,
  "created_at" : "2013-02-24 17:14:30 +0000",
  "in_reply_to_screen_name" : "omid",
  "in_reply_to_user_id_str" : "114971521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/305722936214581248\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/ZASeX8Bcw3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BD4lZAVCcAEHaUj.png",
      "id_str" : "305722936222969857",
      "id" : 305722936222969857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD4lZAVCcAEHaUj.png",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 195,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZASeX8Bcw3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305722936214581248",
  "text" : "Also, I wonder if increased perspiration is linked with any particular phase of sleep. What is 2:35am - 6:25am? http:\/\/t.co\/ZASeX8Bcw3",
  "id" : 305722936214581248,
  "created_at" : "2013-02-24 16:56:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 35, 43 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/305721752112209921\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/LMLbL8uYBl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BD4kUFNCIAET3_l.png",
      "id_str" : "305721752120598529",
      "id" : 305721752120598529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD4kUFNCIAET3_l.png",
      "sizes" : [ {
        "h" : 539,
        "resize" : "fit",
        "w" : 942
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 195,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 539,
        "resize" : "fit",
        "w" : 942
      } ],
      "display_url" : "pic.twitter.com\/LMLbL8uYBl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305721752112209921",
  "text" : "Trying to reverse engineer how the @mybasis watch knows when I fall asleep and wake up. Heart rate drops and jumps? http:\/\/t.co\/LMLbL8uYBl",
  "id" : 305721752112209921,
  "created_at" : "2013-02-24 16:52:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    }, {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 10, 25 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Nozlee S-H",
      "screen_name" : "nzle",
      "indices" : [ 26, 31 ],
      "id_str" : "823207",
      "id" : 823207
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 32, 40 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Stellar",
      "screen_name" : "yo_stellar",
      "indices" : [ 41, 52 ],
      "id_str" : "180817904",
      "id" : 180817904
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 53, 62 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Stellar",
      "screen_name" : "yo_stellar",
      "indices" : [ 121, 132 ],
      "id_str" : "180817904",
      "id" : 180817904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305709884261945344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859658404, -122.2753202092 ]
  },
  "id_str" : "305710549138800640",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie @mikeindustries @nzle @djacobs @yo_stellar @anildash It was high value to me bc it was constrained to users of @yo_stellar.",
  "id" : 305710549138800640,
  "in_reply_to_status_id" : 305709884261945344,
  "created_at" : "2013-02-24 16:07:29 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    }, {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 10, 25 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Nozlee S-H",
      "screen_name" : "nzle",
      "indices" : [ 26, 31 ],
      "id_str" : "823207",
      "id" : 823207
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 32, 40 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Stellar",
      "screen_name" : "yo_stellar",
      "indices" : [ 41, 52 ],
      "id_str" : "180817904",
      "id" : 180817904
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 53, 62 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305708769806008321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595269094, -122.2753964712 ]
  },
  "id_str" : "305709089298718720",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie @mikeindustries @nzle @djacobs @yo_stellar @anildash I'm going to turn mine off. It's nice for me but clearly not for everyone.",
  "id" : 305709089298718720,
  "in_reply_to_status_id" : 305708769806008321,
  "created_at" : "2013-02-24 16:01:41 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Spiers",
      "screen_name" : "espiers",
      "indices" : [ 3, 11 ],
      "id_str" : "14801863",
      "id" : 14801863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/G3yzAtYb1W",
      "expanded_url" : "https:\/\/medium.com\/architecting-a-life\/cff4161f551c",
      "display_url" : "medium.com\/architecting-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305705301099823104",
  "text" : "RT @espiers: Letter to a 20something Workaholic: Why Developing Relationships in Your 20s Matters: https:\/\/t.co\/G3yzAtYb1W",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/G3yzAtYb1W",
        "expanded_url" : "https:\/\/medium.com\/architecting-a-life\/cff4161f551c",
        "display_url" : "medium.com\/architecting-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "305701004836470784",
    "text" : "Letter to a 20something Workaholic: Why Developing Relationships in Your 20s Matters: https:\/\/t.co\/G3yzAtYb1W",
    "id" : 305701004836470784,
    "created_at" : "2013-02-24 15:29:33 +0000",
    "user" : {
      "name" : "Elizabeth Spiers",
      "screen_name" : "espiers",
      "protected" : false,
      "id_str" : "14801863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459052665125617665\/7QGVatRq_normal.jpeg",
      "id" : 14801863,
      "verified" : false
    }
  },
  "id" : 305705301099823104,
  "created_at" : "2013-02-24 15:46:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305556219978985472",
  "geo" : { },
  "id_str" : "305558432101068801",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover Thank you! A\/B Fit is one of my favorite ideas to think about, too. How did you find me?",
  "id" : 305558432101068801,
  "in_reply_to_status_id" : 305556219978985472,
  "created_at" : "2013-02-24 06:03:01 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305548978295042049",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595792598, -122.2754419642 ]
  },
  "id_str" : "305555461636247552",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun Only if by everyone you mean assholes.",
  "id" : 305555461636247552,
  "in_reply_to_status_id" : 305548978295042049,
  "created_at" : "2013-02-24 05:51:13 +0000",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/UgUB1hIvT6",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/jeffbercovici\/2013\/02\/22\/heres-how-you-buy-your-way-onto-the-new-york-times-bestsellers-list\/",
      "display_url" : "forbes.com\/sites\/jeffberc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305544173015138304",
  "text" : "How to buy your way onto the NYT Bestsellers List and prove that you suck http:\/\/t.co\/UgUB1hIvT6",
  "id" : 305544173015138304,
  "created_at" : "2013-02-24 05:06:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/7pRnUSWqnu",
      "expanded_url" : "http:\/\/flic.kr\/p\/dXmNqY",
      "display_url" : "flic.kr\/p\/dXmNqY"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.2755 ]
  },
  "id_str" : "305538507101847553",
  "text" : "8:36pm Thinking about putting on smurf pajamas. http:\/\/t.co\/7pRnUSWqnu",
  "id" : 305538507101847553,
  "created_at" : "2013-02-24 04:43:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Williams",
      "screen_name" : "jw",
      "indices" : [ 3, 6 ],
      "id_str" : "12528",
      "id" : 12528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/uMZsrERK9k",
      "expanded_url" : "https:\/\/medium.com\/work-education\/6152adc41de9",
      "display_url" : "medium.com\/work-education\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305534973627207680",
  "text" : "RT @jw: We thought foursquare was crap, and believed the design nerds flocking to Gowalla validated our attitude: https:\/\/t.co\/uMZsrERK9k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/uMZsrERK9k",
        "expanded_url" : "https:\/\/medium.com\/work-education\/6152adc41de9",
        "display_url" : "medium.com\/work-education\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "305501842924765184",
    "text" : "We thought foursquare was crap, and believed the design nerds flocking to Gowalla validated our attitude: https:\/\/t.co\/uMZsrERK9k",
    "id" : 305501842924765184,
    "created_at" : "2013-02-24 02:18:09 +0000",
    "user" : {
      "name" : "Josh Williams",
      "screen_name" : "jw",
      "protected" : false,
      "id_str" : "12528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453726574966083584\/WvWsZixz_normal.png",
      "id" : 12528,
      "verified" : false
    }
  },
  "id" : 305534973627207680,
  "created_at" : "2013-02-24 04:29:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dami Dina",
      "screen_name" : "DamiDina",
      "indices" : [ 0, 9 ],
      "id_str" : "99204810",
      "id" : 99204810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305493839232241664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596469694, -122.2758300154 ]
  },
  "id_str" : "305495105127731200",
  "in_reply_to_user_id" : 99204810,
  "text" : "@DamiDina Thank you!",
  "id" : 305495105127731200,
  "in_reply_to_status_id" : 305493839232241664,
  "created_at" : "2013-02-24 01:51:23 +0000",
  "in_reply_to_screen_name" : "DamiDina",
  "in_reply_to_user_id_str" : "99204810",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/5aO3A7Cvif",
      "expanded_url" : "http:\/\/bit.ly\/Zr5Skn",
      "display_url" : "bit.ly\/Zr5Skn"
    } ]
  },
  "geo" : { },
  "id_str" : "305491127765716992",
  "text" : "\"On filters\" (both photo &amp; brain filters) - Way of the Duck http:\/\/t.co\/5aO3A7Cvif",
  "id" : 305491127765716992,
  "created_at" : "2013-02-24 01:35:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/305452535878135808\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/NzfLZUwy3y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BD0vdokCMAAd-bt.jpg",
      "id_str" : "305452535882330112",
      "id" : 305452535882330112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD0vdokCMAAd-bt.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/NzfLZUwy3y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305450689977544705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85982545, -122.2754555104 ]
  },
  "id_str" : "305452535878135808",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries Ha, true. I do think it's possible to get away with. Might not earn me any fashion points though. http:\/\/t.co\/NzfLZUwy3y",
  "id" : 305452535878135808,
  "in_reply_to_status_id" : 305450689977544705,
  "created_at" : "2013-02-23 23:02:14 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "onepairofshoesproblems",
      "indices" : [ 96, 119 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305449273452032000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8613585839, -122.2761570757 ]
  },
  "id_str" : "305450356010283008",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries I'll try them when I get through these. Could I wear Mizunos to the office too? #onepairofshoesproblems",
  "id" : 305450356010283008,
  "in_reply_to_status_id" : 305449273452032000,
  "created_at" : "2013-02-23 22:53:34 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305447700428640258",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8617365659, -122.2782958859 ]
  },
  "id_str" : "305448999287128064",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries Nike runners, they've generally done me well over the years. I think the real problem is the quality of the bread down here.",
  "id" : 305448999287128064,
  "in_reply_to_status_id" : 305447700428640258,
  "created_at" : "2013-02-23 22:48:11 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305447060512075776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8615631862, -122.280868292 ]
  },
  "id_str" : "305447524427243521",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries Not running for 2 years then going on a long hilly run. Think it's just stubborn runner's knee.",
  "id" : 305447524427243521,
  "in_reply_to_status_id" : 305447060512075776,
  "created_at" : "2013-02-23 22:42:19 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305446126864175105",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8616816086, -122.2809779828 ]
  },
  "id_str" : "305446988365844481",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries Mostly because my knee is still whack. Very much looking forward to regular runs. Planning to run a marathon this year.",
  "id" : 305446988365844481,
  "in_reply_to_status_id" : 305446126864175105,
  "created_at" : "2013-02-23 22:40:11 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/runkeeper.com\" rel=\"nofollow\"\u003ERunKeeper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RunKeeper",
      "indices" : [ 76, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/215kebYSyO",
      "expanded_url" : "http:\/\/rnkpr.com\/a2iapnk",
      "display_url" : "rnkpr.com\/a2iapnk"
    } ]
  },
  "geo" : { },
  "id_str" : "305445294911397889",
  "text" : "Just posted a 3.55 mi run - Knee still feels funny.  http:\/\/t.co\/215kebYSyO #RunKeeper",
  "id" : 305445294911397889,
  "created_at" : "2013-02-23 22:33:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 1, 11 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/9xGxCdzMMC",
      "expanded_url" : "http:\/\/bit.ly\/XSNDRK",
      "display_url" : "bit.ly\/XSNDRK"
    } ]
  },
  "geo" : { },
  "id_str" : "305378160801898497",
  "text" : ".@kellianne and I are doing a Diet Bet in March where we put money down on trying to lose weight. Join us: http:\/\/t.co\/9xGxCdzMMC",
  "id" : 305378160801898497,
  "created_at" : "2013-02-23 18:06:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/XKsxmW2gt3",
      "expanded_url" : "http:\/\/flic.kr\/p\/dX1SzB",
      "display_url" : "flic.kr\/p\/dX1SzB"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.2755 ]
  },
  "id_str" : "305204137753210881",
  "text" : "8:36pm It's a smurf pajamas kinda night http:\/\/t.co\/XKsxmW2gt3",
  "id" : 305204137753210881,
  "created_at" : "2013-02-23 06:35:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 40, 55 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Planes on Trains",
      "screen_name" : "isthereplane",
      "indices" : [ 87, 100 ],
      "id_str" : "612694334",
      "id" : 612694334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/H13GY2jGjs",
      "expanded_url" : "http:\/\/bit.ly\/ZyD79a",
      "display_url" : "bit.ly\/ZyD79a"
    } ]
  },
  "geo" : { },
  "id_str" : "305169079331872768",
  "text" : "I've got one: http:\/\/t.co\/H13GY2jGjs RT @mikeindustries: New favorite Twitter account: @isthereplane. Planes on Trains.",
  "id" : 305169079331872768,
  "created_at" : "2013-02-23 04:15:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Very Short Story",
      "screen_name" : "VeryShortStory",
      "indices" : [ 39, 54 ],
      "id_str" : "31986700",
      "id" : 31986700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 55, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8286909545, -122.2670549994 ]
  },
  "id_str" : "305144477591429120",
  "text" : "I'm late to this but you should follow @VeryShortStory #ff",
  "id" : 305144477591429120,
  "created_at" : "2013-02-23 02:38:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Graham",
      "screen_name" : "paulg",
      "indices" : [ 45, 51 ],
      "id_str" : "183749519",
      "id" : 183749519
    }, {
      "name" : "Jason Costa",
      "screen_name" : "jasoncosta",
      "indices" : [ 87, 98 ],
      "id_str" : "14927800",
      "id" : 14927800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/CJiFjuXWVJ",
      "expanded_url" : "http:\/\/www.fastcompany.com\/node\/3006142",
      "display_url" : "fastcompany.com\/node\/3006142"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7792435892, -122.4142426216 ]
  },
  "id_str" : "305139260477042688",
  "text" : "My new segment: schleppin' and sloggin' with @paulg and me http:\/\/t.co\/CJiFjuXWVJ \/via @jasoncosta",
  "id" : 305139260477042688,
  "created_at" : "2013-02-23 02:17:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Costa",
      "screen_name" : "jasoncosta",
      "indices" : [ 0, 11 ],
      "id_str" : "14927800",
      "id" : 14927800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305079438004080640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7792434608, -122.4142426748 ]
  },
  "id_str" : "305138302699319296",
  "in_reply_to_user_id" : 14927800,
  "text" : "@jasoncosta Woah didn't realize this until you linked to it! Thanks. :)",
  "id" : 305138302699319296,
  "in_reply_to_status_id" : 305079438004080640,
  "created_at" : "2013-02-23 02:13:35 +0000",
  "in_reply_to_screen_name" : "jasoncosta",
  "in_reply_to_user_id_str" : "14927800",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/P7t4K4m2LR",
      "expanded_url" : "http:\/\/bit.ly\/VC5lw3",
      "display_url" : "bit.ly\/VC5lw3"
    } ]
  },
  "in_reply_to_status_id_str" : "305089205657272320",
  "geo" : { },
  "id_str" : "305121852555161600",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote I don't think so. http:\/\/t.co\/P7t4K4m2LR is no longer up.",
  "id" : 305121852555161600,
  "in_reply_to_status_id" : 305089205657272320,
  "created_at" : "2013-02-23 01:08:13 +0000",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 0, 7 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 8, 22 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 23, 33 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305061271986909184",
  "geo" : { },
  "id_str" : "305066712477339648",
  "in_reply_to_user_id" : 15727738,
  "text" : "@cwhogg @aarondcoleman @e_ramirez I'd rather just hang out with you guys. :)",
  "id" : 305066712477339648,
  "in_reply_to_status_id" : 305061271986909184,
  "created_at" : "2013-02-22 21:29:06 +0000",
  "in_reply_to_screen_name" : "cwhogg",
  "in_reply_to_user_id_str" : "15727738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audra Williams",
      "screen_name" : "audrawilliams",
      "indices" : [ 0, 14 ],
      "id_str" : "16299301",
      "id" : 16299301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305038080052695041",
  "geo" : { },
  "id_str" : "305043691435876353",
  "in_reply_to_user_id" : 16299301,
  "text" : "@audrawilliams Totally understand. I'm doing my best. If it's not enough, no hard feelings if you want to go somewhere with full-time staff.",
  "id" : 305043691435876353,
  "in_reply_to_status_id" : 305038080052695041,
  "created_at" : "2013-02-22 19:57:38 +0000",
  "in_reply_to_screen_name" : "audrawilliams",
  "in_reply_to_user_id_str" : "16299301",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audra Williams",
      "screen_name" : "audrawilliams",
      "indices" : [ 0, 14 ],
      "id_str" : "16299301",
      "id" : 16299301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/ilBDZPRrxj",
      "expanded_url" : "http:\/\/750words.tumblr.com",
      "display_url" : "750words.tumblr.com"
    } ]
  },
  "in_reply_to_status_id_str" : "305030877400940544",
  "geo" : { },
  "id_str" : "305036552906629121",
  "in_reply_to_user_id" : 16299301,
  "text" : "@audrawilliams Times and circumstances change. Sorry to disappoint. See http:\/\/t.co\/ilBDZPRrxj (last 4 posts) for full context.",
  "id" : 305036552906629121,
  "in_reply_to_status_id" : 305030877400940544,
  "created_at" : "2013-02-22 19:29:16 +0000",
  "in_reply_to_screen_name" : "audrawilliams",
  "in_reply_to_user_id_str" : "16299301",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Hunter Walk",
      "screen_name" : "hunterwalk",
      "indices" : [ 9, 20 ],
      "id_str" : "46063",
      "id" : 46063
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "clickbaitcoldwar",
      "indices" : [ 117, 134 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305006539725475840",
  "geo" : { },
  "id_str" : "305006977635999744",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver @hunterwalk Definitely an illusion. Eventually brains catch on and click bait headlines will adapt further. #clickbaitcoldwar",
  "id" : 305006977635999744,
  "in_reply_to_status_id" : 305006539725475840,
  "created_at" : "2013-02-22 17:31:44 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Hunter Walk",
      "screen_name" : "hunterwalk",
      "indices" : [ 9, 20 ],
      "id_str" : "46063",
      "id" : 46063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305004306623508480",
  "geo" : { },
  "id_str" : "305006363698950144",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver @hunterwalk I think it's more about the illusion that a short list will of crucial info will save us time somehow.",
  "id" : 305006363698950144,
  "in_reply_to_status_id" : 305004306623508480,
  "created_at" : "2013-02-22 17:29:18 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "indices" : [ 3, 14 ],
      "id_str" : "419710142",
      "id" : 419710142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/ZZZ5nrp8UK",
      "expanded_url" : "http:\/\/pandodaily.com\/2013\/02\/22\/no-google-glass-is-not-a-segway-for-your-face\/",
      "display_url" : "pandodaily.com\/2013\/02\/22\/no-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304988572233125889",
  "text" : "RT @PandoDaily: No, Google Glass is not a Segway for your face http:\/\/t.co\/ZZZ5nrp8UK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pandodaily.com\/\" rel=\"nofollow\"\u003EPandoDaily\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/ZZZ5nrp8UK",
        "expanded_url" : "http:\/\/pandodaily.com\/2013\/02\/22\/no-google-glass-is-not-a-segway-for-your-face\/",
        "display_url" : "pandodaily.com\/2013\/02\/22\/no-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304985760111656960",
    "text" : "No, Google Glass is not a Segway for your face http:\/\/t.co\/ZZZ5nrp8UK",
    "id" : 304985760111656960,
    "created_at" : "2013-02-22 16:07:26 +0000",
    "user" : {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "protected" : false,
      "id_str" : "419710142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1764819620\/Pando_Twitter_Logo_normal.jpg",
      "id" : 419710142,
      "verified" : false
    }
  },
  "id" : 304988572233125889,
  "created_at" : "2013-02-22 16:18:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/xE8WW7BdnV",
      "expanded_url" : "http:\/\/flic.kr\/p\/dWMvQk",
      "display_url" : "flic.kr\/p\/dWMvQk"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8465, -122.252 ]
  },
  "id_str" : "304839603976806400",
  "text" : "8:36pm Was just leaving a gourmet burger place http:\/\/t.co\/xE8WW7BdnV",
  "id" : 304839603976806400,
  "created_at" : "2013-02-22 06:26:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 43, 53 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/QNs9AMyw4z",
      "expanded_url" : "http:\/\/4sq.com\/Yqtrqi",
      "display_url" : "4sq.com\/Yqtrqi"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8707932813, -122.2930202201 ]
  },
  "id_str" : "304839050945236992",
  "text" : "Cool neighborhood bar! (@ Albatross Pub w\/ @kellianne) http:\/\/t.co\/QNs9AMyw4z",
  "id" : 304839050945236992,
  "created_at" : "2013-02-22 06:24:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 0, 8 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jealous",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304736561923244032",
  "geo" : { },
  "id_str" : "304748449268654080",
  "in_reply_to_user_id" : 22891211,
  "text" : "@chanian You're going??? You better vine every bite. #jealous",
  "id" : 304748449268654080,
  "in_reply_to_status_id" : 304736561923244032,
  "created_at" : "2013-02-22 00:24:26 +0000",
  "in_reply_to_screen_name" : "chanian",
  "in_reply_to_user_id_str" : "22891211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 51, 63 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/dvvW4SOwwf",
      "expanded_url" : "http:\/\/www.slideshare.net\/joinsessions\/what-to-know-before-you-build-your-health-app",
      "display_url" : "slideshare.net\/joinsessions\/w\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "304731548027060225",
  "geo" : { },
  "id_str" : "304747226100535296",
  "in_reply_to_user_id" : 30801469,
  "text" : "Listen to Nick, he speaks the opposite of lies! RT @nickcrocker: What you need to know before you build a health app: http:\/\/t.co\/dvvW4SOwwf",
  "id" : 304747226100535296,
  "in_reply_to_status_id" : 304731548027060225,
  "created_at" : "2013-02-22 00:19:35 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 0, 4 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304734851674800131",
  "geo" : { },
  "id_str" : "304735272988446720",
  "in_reply_to_user_id" : 259,
  "text" : "@ian Nah, just include fave, retweet, reply icons under the tweet. :)",
  "id" : 304735272988446720,
  "in_reply_to_status_id" : 304734851674800131,
  "created_at" : "2013-02-21 23:32:05 +0000",
  "in_reply_to_screen_name" : "ian",
  "in_reply_to_user_id_str" : "259",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304731710128549889",
  "geo" : { },
  "id_str" : "304735103400165376",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker Woah man. That's YOUR BEST WORK YET. So good. I'll blog it a bit later. Well done. Are you presenting this somewhere?",
  "id" : 304735103400165376,
  "in_reply_to_status_id" : 304731710128549889,
  "created_at" : "2013-02-21 23:31:25 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304728423862001665",
  "text" : "New revenue idea for Twitter: option to promote your tweet as a plane banner to be flown over a location at a time of your choosing.",
  "id" : 304728423862001665,
  "created_at" : "2013-02-21 23:04:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heidi Stabb",
      "screen_name" : "heidi_reads",
      "indices" : [ 0, 12 ],
      "id_str" : "274404727",
      "id" : 274404727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/hw0Zu9fOl6",
      "expanded_url" : "http:\/\/750words.com\/auth?method=unsupported",
      "display_url" : "750words.com\/auth?method=un\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "304708382210789377",
  "geo" : { },
  "id_str" : "304708690597007360",
  "in_reply_to_user_id" : 274404727,
  "text" : "@heidi_reads try http:\/\/t.co\/hw0Zu9fOl6 and be sure to add an email and password to your account for next time!",
  "id" : 304708690597007360,
  "in_reply_to_status_id" : 304708382210789377,
  "created_at" : "2013-02-21 21:46:27 +0000",
  "in_reply_to_screen_name" : "heidi_reads",
  "in_reply_to_user_id_str" : "274404727",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304497894352904193",
  "geo" : { },
  "id_str" : "304498872124841984",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april All you Glass is half-empty folks.",
  "id" : 304498872124841984,
  "in_reply_to_status_id" : 304497894352904193,
  "created_at" : "2013-02-21 07:52:43 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 34, 41 ],
      "id_str" : "494518813",
      "id" : 494518813
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 121, 129 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/jcfZxbDIbK",
      "expanded_url" : "http:\/\/branch.com\/b\/my-basis-watch",
      "display_url" : "branch.com\/b\/my-basis-wat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304497692208406528",
  "text" : "Talking about \u201CMy Basis Watch\u201D on @branch. If you have one, ask to join and I'll approve you! http:\/\/t.co\/jcfZxbDIbK \/cc @mybasis",
  "id" : 304497692208406528,
  "created_at" : "2013-02-21 07:48:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Javid",
      "screen_name" : "pauljavid",
      "indices" : [ 0, 10 ],
      "id_str" : "23734792",
      "id" : 23734792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304478398204481539",
  "geo" : { },
  "id_str" : "304478720721293312",
  "in_reply_to_user_id" : 23734792,
  "text" : "@pauljavid Setup was a pain (didn't work on my MacBook Pro and ordered a replacement before trying it on iMac where it worked). More soon.",
  "id" : 304478720721293312,
  "in_reply_to_status_id" : 304478398204481539,
  "created_at" : "2013-02-21 06:32:38 +0000",
  "in_reply_to_screen_name" : "pauljavid",
  "in_reply_to_user_id_str" : "23734792",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judi",
      "screen_name" : "judidec",
      "indices" : [ 0, 8 ],
      "id_str" : "29344406",
      "id" : 29344406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304478361407860737",
  "geo" : { },
  "id_str" : "304478580077887489",
  "in_reply_to_user_id" : 29344406,
  "text" : "@judidec I had some trouble setting it up, but will have a full report of actual usage soon!",
  "id" : 304478580077887489,
  "in_reply_to_status_id" : 304478361407860737,
  "created_at" : "2013-02-21 06:32:05 +0000",
  "in_reply_to_screen_name" : "judidec",
  "in_reply_to_user_id_str" : "29344406",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 10, 20 ],
      "id_str" : "2854761",
      "id" : 2854761
    }, {
      "name" : "Daryn Nakhuda",
      "screen_name" : "daryn",
      "indices" : [ 21, 27 ],
      "id_str" : "804808",
      "id" : 804808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/yOGUtBrc9B",
      "expanded_url" : "http:\/\/bit.ly\/XqNaXU",
      "display_url" : "bit.ly\/XqNaXU"
    } ]
  },
  "in_reply_to_status_id_str" : "304471304617197569",
  "geo" : { },
  "id_str" : "304477352652595200",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @galenward @daryn *shakes hand and commits to Github* http:\/\/t.co\/yOGUtBrc9B (Does it look good to you?)",
  "id" : 304477352652595200,
  "in_reply_to_status_id" : 304471304617197569,
  "created_at" : "2013-02-21 06:27:12 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 0, 14 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 15, 25 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 26, 33 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reunion",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304472502313308160",
  "geo" : { },
  "id_str" : "304472607544209408",
  "in_reply_to_user_id" : 9609062,
  "text" : "@aarondcoleman @e_ramirez @cwhogg #reunion!",
  "id" : 304472607544209408,
  "in_reply_to_status_id" : 304472502313308160,
  "created_at" : "2013-02-21 06:08:21 +0000",
  "in_reply_to_screen_name" : "aaronc",
  "in_reply_to_user_id_str" : "9609062",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/KIN4ZvcrxF",
      "expanded_url" : "http:\/\/flic.kr\/p\/dWxg6n",
      "display_url" : "flic.kr\/p\/dWxg6n"
    } ]
  },
  "geo" : { },
  "id_str" : "304472143377354752",
  "text" : "Yup, got one.  http:\/\/t.co\/KIN4ZvcrxF",
  "id" : 304472143377354752,
  "created_at" : "2013-02-21 06:06:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304469538001547265",
  "geo" : { },
  "id_str" : "304471377140916224",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Ha, thanks! When are you in SF next?",
  "id" : 304471377140916224,
  "in_reply_to_status_id" : 304469538001547265,
  "created_at" : "2013-02-21 06:03:27 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 11, 20 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304467474282328065",
  "geo" : { },
  "id_str" : "304471261931794433",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward @RickWebb The same wild that had iPhones in 2006. Or cell phones in the 90s. Or cars in the 1920s.",
  "id" : 304471261931794433,
  "in_reply_to_status_id" : 304467474282328065,
  "created_at" : "2013-02-21 06:03:00 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 11, 20 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304467474282328065",
  "geo" : { },
  "id_str" : "304468125259276288",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward @RickWebb In the same wild that we currently see Fitbits, NikeFuel bands, retina MacBook Pros, etc.",
  "id" : 304468125259276288,
  "in_reply_to_status_id" : 304467474282328065,
  "created_at" : "2013-02-21 05:50:32 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304467389368655872",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Or rather, descendants! :)",
  "id" : 304467389368655872,
  "created_at" : "2013-02-21 05:47:37 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304467017560379392",
  "geo" : { },
  "id_str" : "304467162809118721",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean Ha. Yes. Oops.",
  "id" : 304467162809118721,
  "in_reply_to_status_id" : 304467017560379392,
  "created_at" : "2013-02-21 05:46:42 +0000",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304465416254812161",
  "geo" : { },
  "id_str" : "304466237029748736",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Let's wager! I wager that by 3\/1\/2016 ancestors of Google Glass (not necessarily by Google) will be regularly spotted in the wild.",
  "id" : 304466237029748736,
  "in_reply_to_status_id" : 304465416254812161,
  "created_at" : "2013-02-21 05:43:02 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304463798847283201",
  "geo" : { },
  "id_str" : "304463919609675776",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb 3 years.",
  "id" : 304463919609675776,
  "in_reply_to_status_id" : 304463798847283201,
  "created_at" : "2013-02-21 05:33:49 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teamglass",
      "indices" : [ 7, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304462985861165057",
  "text" : "I'm on #teamglass.",
  "id" : 304462985861165057,
  "created_at" : "2013-02-21 05:30:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304454637375868928",
  "geo" : { },
  "id_str" : "304454924647923714",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc You bet. In fact, his mind was blown when he saw a cable car going down Market St in SF the other day -- it didn't even need a track!",
  "id" : 304454924647923714,
  "in_reply_to_status_id" : 304454637375868928,
  "created_at" : "2013-02-21 04:58:05 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/0PqagyTc3r",
      "expanded_url" : "http:\/\/flic.kr\/p\/dWCftu",
      "display_url" : "flic.kr\/p\/dWCftu"
    } ]
  },
  "geo" : { },
  "id_str" : "304452551414280192",
  "text" : "8:36pm Good night cable car http:\/\/t.co\/0PqagyTc3r",
  "id" : 304452551414280192,
  "created_at" : "2013-02-21 04:48:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 3, 6 ],
      "id_str" : "19853",
      "id" : 19853
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 8, 15 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304436188352225282",
  "text" : "RT @rk: @buster Top 10 Things That Would Make Your Life Better That You Will Never Do [PICS] [VIDEO]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "304424011469819904",
    "geo" : { },
    "id_str" : "304433370631401472",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster Top 10 Things That Would Make Your Life Better That You Will Never Do [PICS] [VIDEO]",
    "id" : 304433370631401472,
    "in_reply_to_status_id" : 304424011469819904,
    "created_at" : "2013-02-21 03:32:26 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "protected" : false,
      "id_str" : "19853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1202040731\/70847_7101903_1567328_n_normal.jpg",
      "id" : 19853,
      "verified" : false
    }
  },
  "id" : 304436188352225282,
  "created_at" : "2013-02-21 03:43:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greenlies",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304424011469819904",
  "text" : "Top 5 Fluffy Lies You Like To Hear And I Will Tell You (Again) So That You Click This Link And PS I Make A Little Money Too Weeee #greenlies",
  "id" : 304424011469819904,
  "created_at" : "2013-02-21 02:55:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ifIhadGlass",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "ohifonly",
      "indices" : [ 13, 22 ]
    }, {
      "text" : "IhadGlass",
      "indices" : [ 23, 33 ]
    }, {
      "text" : "prettyplease",
      "indices" : [ 34, 47 ]
    }, {
      "text" : "didIwin",
      "indices" : [ 48, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/sE3fneR0",
      "expanded_url" : "http:\/\/bit.ly\/UIwFtt",
      "display_url" : "bit.ly\/UIwFtt"
    } ]
  },
  "geo" : { },
  "id_str" : "304293782101295105",
  "text" : "#ifIhadGlass #ohifonly #IhadGlass #prettyplease #didIwin? http:\/\/t.co\/sE3fneR0",
  "id" : 304293782101295105,
  "created_at" : "2013-02-20 18:17:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304284762204413953",
  "geo" : { },
  "id_str" : "304286955112382464",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Skip the 90's and just get Glass already.",
  "id" : 304286955112382464,
  "in_reply_to_status_id" : 304284762204413953,
  "created_at" : "2013-02-20 17:50:38 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304283903613616129",
  "geo" : { },
  "id_str" : "304286803379249152",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun I'm pretty sure all biases run in parallel, like applying every photo filter at once and then forgetting about it due to bias bias.",
  "id" : 304286803379249152,
  "in_reply_to_status_id" : 304283903613616129,
  "created_at" : "2013-02-20 17:50:01 +0000",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304285547277479936",
  "text" : "U",
  "id" : 304285547277479936,
  "created_at" : "2013-02-20 17:45:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304283616328957953",
  "geo" : { },
  "id_str" : "304284178306965508",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Have you forgotten the invention of cell phones and how conspicuous\/awkward it was to see people talking to themselves?",
  "id" : 304284178306965508,
  "in_reply_to_status_id" : 304283616328957953,
  "created_at" : "2013-02-20 17:39:36 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304282130958151680",
  "geo" : { },
  "id_str" : "304283531654344704",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun That is, unless you have overestimation bias.",
  "id" : 304283531654344704,
  "in_reply_to_status_id" : 304282130958151680,
  "created_at" : "2013-02-20 17:37:01 +0000",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kelly oxford",
      "screen_name" : "kellyoxford",
      "indices" : [ 3, 15 ],
      "id_str" : "22872643",
      "id" : 22872643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304277600363245568",
  "text" : "RT @kellyoxford: One thing Kurt Cobain would have loved is trending on Twitter on his birthday.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "304273358906880001",
    "text" : "One thing Kurt Cobain would have loved is trending on Twitter on his birthday.",
    "id" : 304273358906880001,
    "created_at" : "2013-02-20 16:56:36 +0000",
    "user" : {
      "name" : "kelly oxford",
      "screen_name" : "kellyoxford",
      "protected" : false,
      "id_str" : "22872643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461951982891466752\/Vs80t_kr_normal.jpeg",
      "id" : 22872643,
      "verified" : true
    }
  },
  "id" : 304277600363245568,
  "created_at" : "2013-02-20 17:13:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/QA40ASaS",
      "expanded_url" : "http:\/\/wayoftheduck.com\/long-slog",
      "display_url" : "wayoftheduck.com\/long-slog"
    } ]
  },
  "geo" : { },
  "id_str" : "304276633852997632",
  "text" : "\"The long slog, the thing that feels like way too much painful effort in the beginning becomes the only reward.\" http:\/\/t.co\/QA40ASaS",
  "id" : 304276633852997632,
  "created_at" : "2013-02-20 17:09:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed News",
      "screen_name" : "BuzzFeedNews",
      "indices" : [ 47, 60 ],
      "id_str" : "1020058453",
      "id" : 1020058453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/uHdPRMG3",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/federal-eye\/wp\/2013\/02\/19\/postal-service-to-launch-new-clothing-line-in-2014",
      "display_url" : "washingtonpost.com\/blogs\/federal-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "304137658840522752",
  "geo" : { },
  "id_str" : "304142270620393472",
  "in_reply_to_user_id" : 1020058453,
  "text" : "New schwag for live shows? I'm so confused. RT @BuzzFeedNews: U.S. Postal Service to launch new clothing line in 2014 http:\/\/t.co\/uHdPRMG3",
  "id" : 304142270620393472,
  "in_reply_to_status_id" : 304137658840522752,
  "created_at" : "2013-02-20 08:15:42 +0000",
  "in_reply_to_screen_name" : "BuzzFeedNews",
  "in_reply_to_user_id_str" : "1020058453",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 86, 97 ],
      "id_str" : "26123649",
      "id" : 26123649
    }, {
      "name" : "Ben Ward",
      "screen_name" : "benward",
      "indices" : [ 98, 106 ],
      "id_str" : "12249",
      "id" : 12249
    }, {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 107, 113 ],
      "id_str" : "15310552",
      "id" : 15310552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/bWInrY4a",
      "expanded_url" : "http:\/\/bit.ly\/XM2s8C",
      "display_url" : "bit.ly\/XM2s8C"
    } ]
  },
  "geo" : { },
  "id_str" : "304127165845368833",
  "text" : "Stoked to discover that Svbtle is now allowing tweet embeds: http:\/\/t.co\/bWInrY4a \/cc @brianellin @benward @singy",
  "id" : 304127165845368833,
  "created_at" : "2013-02-20 07:15:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/O0pKMkVZ",
      "expanded_url" : "http:\/\/bit.ly\/XM2cXh",
      "display_url" : "bit.ly\/XM2cXh"
    } ]
  },
  "geo" : { },
  "id_str" : "304126252351119360",
  "text" : "\"The long slog\" - Way of the Duck http:\/\/t.co\/O0pKMkVZ",
  "id" : 304126252351119360,
  "created_at" : "2013-02-20 07:12:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304118427289808896",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman Take that theory and turn it into a true\/false statement. Then, tracking becomes a way to prove\/disprove your theory.",
  "id" : 304118427289808896,
  "created_at" : "2013-02-20 06:40:57 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304108778213765120",
  "geo" : { },
  "id_str" : "304116075379949568",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman What's your current best theory on how length of time is related to quality of writing? X words\/hour? Y # of breaks? Total time?",
  "id" : 304116075379949568,
  "in_reply_to_status_id" : 304108778213765120,
  "created_at" : "2013-02-20 06:31:37 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/zRPAiJKA",
      "expanded_url" : "http:\/\/bit.ly\/QsfclQ",
      "display_url" : "bit.ly\/QsfclQ"
    } ]
  },
  "geo" : { },
  "id_str" : "304111540506853377",
  "text" : "Getting back into my http:\/\/t.co\/zRPAiJKA after a while away.",
  "id" : 304111540506853377,
  "created_at" : "2013-02-20 06:13:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304092189779173376",
  "geo" : { },
  "id_str" : "304093281854296067",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman That's why it's such a great candidate for self-tracking. Good luck and please write about it. :)",
  "id" : 304093281854296067,
  "in_reply_to_status_id" : 304092189779173376,
  "created_at" : "2013-02-20 05:01:02 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304091163818864640",
  "geo" : { },
  "id_str" : "304092856979693568",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean Uh oh, word's getting out about your awesomeness. Soon it won't be cool to like you anymore.",
  "id" : 304092856979693568,
  "in_reply_to_status_id" : 304091163818864640,
  "created_at" : "2013-02-20 04:59:21 +0000",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304091894395318272",
  "geo" : { },
  "id_str" : "304092091871551488",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim I do remember her to be a fan of the marshmallow.",
  "id" : 304092091871551488,
  "in_reply_to_status_id" : 304091894395318272,
  "created_at" : "2013-02-20 04:56:19 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/8nLMkLbK",
      "expanded_url" : "http:\/\/flic.kr\/p\/dWgJZv",
      "display_url" : "flic.kr\/p\/dWgJZv"
    } ]
  },
  "geo" : { },
  "id_str" : "304091697242058752",
  "text" : "8:36pm Niko's picture titled Still Life With Unstable Train Car http:\/\/t.co\/8nLMkLbK",
  "id" : 304091697242058752,
  "created_at" : "2013-02-20 04:54:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Dave Gamache",
      "screen_name" : "dhg",
      "indices" : [ 16, 20 ],
      "id_str" : "17346623",
      "id" : 17346623
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futureofinterrogation",
      "indices" : [ 109, 131 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304087023449427969",
  "geo" : { },
  "id_str" : "304087941242830848",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries @dhg I like that one! And I've since come up with more bathroom-related interview questions. #futureofinterrogation",
  "id" : 304087941242830848,
  "in_reply_to_status_id" : 304087023449427969,
  "created_at" : "2013-02-20 04:39:49 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304085935967064064",
  "geo" : { },
  "id_str" : "304087259609694210",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman That's a perfect trigger. Track right after that. Also, try to reduce your \"tracking\" to T\/F answers to 2-3 smart questions.",
  "id" : 304087259609694210,
  "in_reply_to_status_id" : 304085935967064064,
  "created_at" : "2013-02-20 04:37:07 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304085682647879680",
  "geo" : { },
  "id_str" : "304086008381726722",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel We haven't really used it yet! Do you have ideas?",
  "id" : 304086008381726722,
  "in_reply_to_status_id" : 304085682647879680,
  "created_at" : "2013-02-20 04:32:08 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304084323387187200",
  "geo" : { },
  "id_str" : "304085421699244032",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman Ooh that's a great idea. Lots to learn. Is there something you consistently do at the end of column-writing?",
  "id" : 304085421699244032,
  "in_reply_to_status_id" : 304084323387187200,
  "created_at" : "2013-02-20 04:29:48 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304083999788244995",
  "geo" : { },
  "id_str" : "304084854419632128",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman Yeah that's a tricky one. Maybe set a reminder alarm early morning to track?",
  "id" : 304084854419632128,
  "in_reply_to_status_id" : 304083999788244995,
  "created_at" : "2013-02-20 04:27:33 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304082511867297792",
  "geo" : { },
  "id_str" : "304083426254921730",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman What's the tracking project?",
  "id" : 304083426254921730,
  "in_reply_to_status_id" : 304082511867297792,
  "created_at" : "2013-02-20 04:21:53 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304082618855591936",
  "geo" : { },
  "id_str" : "304083222378192897",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman Just use hash marks on a wall for every day you do the thing you want to track. That's as useful as most fancy analytics.",
  "id" : 304083222378192897,
  "in_reply_to_status_id" : 304082618855591936,
  "created_at" : "2013-02-20 04:21:04 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304081706913251329",
  "geo" : { },
  "id_str" : "304082094185922560",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman Nah. First time I opened the app in months. :) How are you liking the QS meetup?",
  "id" : 304082094185922560,
  "in_reply_to_status_id" : 304081706913251329,
  "created_at" : "2013-02-20 04:16:35 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D. Keith Robinson",
      "screen_name" : "dkr",
      "indices" : [ 0, 4 ],
      "id_str" : "10877",
      "id" : 10877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304080729153880065",
  "geo" : { },
  "id_str" : "304081728996261888",
  "in_reply_to_user_id" : 10877,
  "text" : "@dkr I'm watching Curious George and drinking a glass of wine. Let's see the fish!",
  "id" : 304081728996261888,
  "in_reply_to_status_id" : 304080729153880065,
  "created_at" : "2013-02-20 04:15:08 +0000",
  "in_reply_to_screen_name" : "dkr",
  "in_reply_to_user_id_str" : "10877",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304080343928041474",
  "text" : "Hi. Whatcha doing?",
  "id" : 304080343928041474,
  "created_at" : "2013-02-20 04:09:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robi Ganguly",
      "screen_name" : "rganguly",
      "indices" : [ 0, 9 ],
      "id_str" : "622663",
      "id" : 622663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304058179816402944",
  "geo" : { },
  "id_str" : "304059860453056514",
  "in_reply_to_user_id" : 622663,
  "text" : "@rganguly Definitely. I might be an outlier but I find all of those things to be fun.",
  "id" : 304059860453056514,
  "in_reply_to_status_id" : 304058179816402944,
  "created_at" : "2013-02-20 02:48:14 +0000",
  "in_reply_to_screen_name" : "rganguly",
  "in_reply_to_user_id_str" : "622663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 92, 99 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QuantifiedSelf",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/x0ONsNHT",
      "expanded_url" : "http:\/\/quantifiedself.com\/2013\/02\/how-to-download-fitbit-data-using-google-spreadsheets\/",
      "display_url" : "quantifiedself.com\/2013\/02\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304057934315388929",
  "text" : "RT @e_ramirez: I\u2019ve updated the instructions for using Google spreadsheets to download your @fitbit data. Have fun!  http:\/\/t.co\/x0ONsNH ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fitbit",
        "screen_name" : "fitbit",
        "indices" : [ 77, 84 ],
        "id_str" : "17424053",
        "id" : 17424053
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "QuantifiedSelf",
        "indices" : [ 123, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/x0ONsNHT",
        "expanded_url" : "http:\/\/quantifiedself.com\/2013\/02\/how-to-download-fitbit-data-using-google-spreadsheets\/",
        "display_url" : "quantifiedself.com\/2013\/02\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304031715528146944",
    "text" : "I\u2019ve updated the instructions for using Google spreadsheets to download your @fitbit data. Have fun!  http:\/\/t.co\/x0ONsNHT #QuantifiedSelf",
    "id" : 304031715528146944,
    "created_at" : "2013-02-20 00:56:24 +0000",
    "user" : {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "protected" : false,
      "id_str" : "21135674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1777379809\/391870_10100894712944981_10004982_63155096_635581352_n_normal.jpg",
      "id" : 21135674,
      "verified" : false
    }
  },
  "id" : 304057934315388929,
  "created_at" : "2013-02-20 02:40:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304057054308466689",
  "text" : "Do all of these in parallel: Find yourself, explore the universe, make goals, devise strategies, experiment with tactics, find a fit, slog.",
  "id" : 304057054308466689,
  "created_at" : "2013-02-20 02:37:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/r4kKZ71k",
      "expanded_url" : "http:\/\/www.livescience.com\/26866-largest-prime-number-discovered.html",
      "display_url" : "livescience.com\/26866-largest-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303963513536253952",
  "text" : "New largest prime number found. 2^57,885,161-1 is also only 48th Mersenne Prime.  http:\/\/t.co\/r4kKZ71k",
  "id" : 303963513536253952,
  "created_at" : "2013-02-19 20:25:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303932688568553473",
  "geo" : { },
  "id_str" : "303939965082017792",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc dun dun DUN.",
  "id" : 303939965082017792,
  "in_reply_to_status_id" : 303932688568553473,
  "created_at" : "2013-02-19 18:51:49 +0000",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/A9yHBozX",
      "expanded_url" : "http:\/\/tcrn.ch\/XmWX0R",
      "display_url" : "tcrn.ch\/XmWX0R"
    }, {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/1T0bJxT6",
      "expanded_url" : "http:\/\/amzn.to\/12IiCHW",
      "display_url" : "amzn.to\/12IiCHW"
    } ]
  },
  "geo" : { },
  "id_str" : "303930595929649152",
  "text" : "In the future, robots will have all the jobs and we will retire. http:\/\/t.co\/A9yHBozX Also relevant: http:\/\/t.co\/1T0bJxT6",
  "id" : 303930595929649152,
  "created_at" : "2013-02-19 18:14:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/5t0CtXjY",
      "expanded_url" : "http:\/\/flic.kr\/p\/dVZPqD",
      "display_url" : "flic.kr\/p\/dVZPqD"
    } ]
  },
  "geo" : { },
  "id_str" : "303732414994317312",
  "text" : "8:36pm \"The trains aren't tired\" as an argument against bedtime http:\/\/t.co\/5t0CtXjY",
  "id" : 303732414994317312,
  "created_at" : "2013-02-19 05:07:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 11, 22 ],
      "id_str" : "14372143",
      "id" : 14372143
    }, {
      "name" : "Andrej Gregov",
      "screen_name" : "agregov",
      "indices" : [ 50, 58 ],
      "id_str" : "752413",
      "id" : 752413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/GtqSDpCE",
      "expanded_url" : "http:\/\/37signals.com\/svn\/posts\/3434-a-loose-rant-on-maximization",
      "display_url" : "37signals.com\/svn\/posts\/3434\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303724628235411456",
  "text" : "Well said, @jasonfried  http:\/\/t.co\/GtqSDpCE \/via @agregov",
  "id" : 303724628235411456,
  "created_at" : "2013-02-19 04:36:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/No8KKwRM",
      "expanded_url" : "http:\/\/vine.co\/v\/b6AupV5glAX",
      "display_url" : "vine.co\/v\/b6AupV5glAX"
    } ]
  },
  "geo" : { },
  "id_str" : "303684259913269248",
  "text" : "Let's play trains! http:\/\/t.co\/No8KKwRM",
  "id" : 303684259913269248,
  "created_at" : "2013-02-19 01:55:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Giulia Forsythe",
      "screen_name" : "giuliaforsythe",
      "indices" : [ 0, 15 ],
      "id_str" : "17620729",
      "id" : 17620729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303562635117490176",
  "geo" : { },
  "id_str" : "303575297159200769",
  "in_reply_to_user_id" : 17620729,
  "text" : "@giuliaforsythe No reason other than that it would take time and energy to make it open source ready. Might happen in future.",
  "id" : 303575297159200769,
  "in_reply_to_status_id" : 303562635117490176,
  "created_at" : "2013-02-18 18:42:45 +0000",
  "in_reply_to_screen_name" : "giuliaforsythe",
  "in_reply_to_user_id_str" : "17620729",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mitch Kapor",
      "screen_name" : "mkapor",
      "indices" : [ 3, 10 ],
      "id_str" : "2730791",
      "id" : 2730791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/ni1u2Yds",
      "expanded_url" : "http:\/\/nyti.ms\/VxHBeZ",
      "display_url" : "nyti.ms\/VxHBeZ"
    } ]
  },
  "geo" : { },
  "id_str" : "303537820226699265",
  "text" : "RT @mkapor: Human brainome project? http:\/\/t.co\/ni1u2Yds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 44 ],
        "url" : "http:\/\/t.co\/ni1u2Yds",
        "expanded_url" : "http:\/\/nyti.ms\/VxHBeZ",
        "display_url" : "nyti.ms\/VxHBeZ"
      } ]
    },
    "geo" : { },
    "id_str" : "303537082683514880",
    "text" : "Human brainome project? http:\/\/t.co\/ni1u2Yds",
    "id" : 303537082683514880,
    "created_at" : "2013-02-18 16:10:54 +0000",
    "user" : {
      "name" : "Mitch Kapor",
      "screen_name" : "mkapor",
      "protected" : false,
      "id_str" : "2730791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2980368237\/711ec3a016b6aaf3d6ec98e14ec145aa_normal.jpeg",
      "id" : 2730791,
      "verified" : true
    }
  },
  "id" : 303537820226699265,
  "created_at" : "2013-02-18 16:13:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samir mezrahi",
      "screen_name" : "samir",
      "indices" : [ 3, 9 ],
      "id_str" : "115396965",
      "id" : 115396965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303531337258774529",
  "text" : "RT @samir: A Twitter App that knows when you haven't watched something on DVR and filters out all tweets about that episode.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303529696358957057",
    "text" : "A Twitter App that knows when you haven't watched something on DVR and filters out all tweets about that episode.",
    "id" : 303529696358957057,
    "created_at" : "2013-02-18 15:41:33 +0000",
    "user" : {
      "name" : "samir mezrahi",
      "screen_name" : "samir",
      "protected" : false,
      "id_str" : "115396965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465647540927344640\/cpSfJSi-_normal.jpeg",
      "id" : 115396965,
      "verified" : true
    }
  },
  "id" : 303531337258774529,
  "created_at" : "2013-02-18 15:48:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 3, 15 ],
      "id_str" : "195863654",
      "id" : 195863654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "health",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/Ujwqn7W2",
      "expanded_url" : "http:\/\/is.gd\/38oGD9",
      "display_url" : "is.gd\/38oGD9"
    } ]
  },
  "geo" : { },
  "id_str" : "303529264496644098",
  "text" : "RT @marihuertas: \"We've made dying a piece of cake.\" http:\/\/t.co\/Ujwqn7W2 #health",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "health",
        "indices" : [ 57, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/Ujwqn7W2",
        "expanded_url" : "http:\/\/is.gd\/38oGD9",
        "display_url" : "is.gd\/38oGD9"
      } ]
    },
    "geo" : { },
    "id_str" : "303520283892011009",
    "text" : "\"We've made dying a piece of cake.\" http:\/\/t.co\/Ujwqn7W2 #health",
    "id" : 303520283892011009,
    "created_at" : "2013-02-18 15:04:09 +0000",
    "user" : {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "protected" : false,
      "id_str" : "195863654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000420864707\/b827233ecd1cd9452628cff95555c284_normal.jpeg",
      "id" : 195863654,
      "verified" : false
    }
  },
  "id" : 303529264496644098,
  "created_at" : "2013-02-18 15:39:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303411980537065472",
  "geo" : { },
  "id_str" : "303412551495065600",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler Yeah, even after 4 years I still need an alarm on my phone.",
  "id" : 303412551495065600,
  "in_reply_to_status_id" : 303411980537065472,
  "created_at" : "2013-02-18 07:56:04 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303395179447083008",
  "geo" : { },
  "id_str" : "303411591280484354",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler You should! The whole point is to allow yourself to be a little boring. Still interesting to see how things change over years.",
  "id" : 303411591280484354,
  "in_reply_to_status_id" : 303395179447083008,
  "created_at" : "2013-02-18 07:52:15 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/PdkmtIeW",
      "expanded_url" : "http:\/\/bit.ly\/LnamDG",
      "display_url" : "bit.ly\/LnamDG"
    } ]
  },
  "in_reply_to_status_id_str" : "303377600246603777",
  "geo" : { },
  "id_str" : "303388365926047744",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler Not really, other than it is a specific time. Full story written up here on the 4-year anniversary: http:\/\/t.co\/PdkmtIeW",
  "id" : 303388365926047744,
  "in_reply_to_status_id" : 303377600246603777,
  "created_at" : "2013-02-18 06:19:57 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 20, 30 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/Q8XcgCUc",
      "expanded_url" : "http:\/\/flic.kr\/p\/dVGap2",
      "display_url" : "flic.kr\/p\/dVGap2"
    } ]
  },
  "geo" : { },
  "id_str" : "303373958076567552",
  "text" : "8:36pm Thankful for @helenjane and James for letting us crash their lovely St Helena lifestyle. Niko wants to go... http:\/\/t.co\/Q8XcgCUc",
  "id" : 303373958076567552,
  "created_at" : "2013-02-18 05:22:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rands",
      "screen_name" : "rands",
      "indices" : [ 3, 9 ],
      "id_str" : "30923",
      "id" : 30923
    }, {
      "name" : "the reddit alien",
      "screen_name" : "reddit",
      "indices" : [ 62, 69 ],
      "id_str" : "811377",
      "id" : 811377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/ZfCNoSMW",
      "expanded_url" : "http:\/\/imgur.com\/a\/w9nHF",
      "display_url" : "imgur.com\/a\/w9nHF"
    } ]
  },
  "geo" : { },
  "id_str" : "303360712879788033",
  "text" : "RT @rands: What 200 calories looks like: http:\/\/t.co\/ZfCNoSMW @reddit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "the reddit alien",
        "screen_name" : "reddit",
        "indices" : [ 51, 58 ],
        "id_str" : "811377",
        "id" : 811377
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/ZfCNoSMW",
        "expanded_url" : "http:\/\/imgur.com\/a\/w9nHF",
        "display_url" : "imgur.com\/a\/w9nHF"
      } ]
    },
    "geo" : { },
    "id_str" : "303213862281412608",
    "text" : "What 200 calories looks like: http:\/\/t.co\/ZfCNoSMW @reddit",
    "id" : 303213862281412608,
    "created_at" : "2013-02-17 18:46:32 +0000",
    "user" : {
      "name" : "rands",
      "screen_name" : "rands",
      "protected" : false,
      "id_str" : "30923",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458982455932760064\/40qsmGPF_normal.png",
      "id" : 30923,
      "verified" : false
    }
  },
  "id" : 303360712879788033,
  "created_at" : "2013-02-18 04:30:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/XfVibCQE",
      "expanded_url" : "http:\/\/flic.kr\/p\/dVDZum",
      "display_url" : "flic.kr\/p\/dVDZum"
    } ]
  },
  "geo" : { },
  "id_str" : "303233955514175489",
  "text" : "Current status http:\/\/t.co\/XfVibCQE",
  "id" : 303233955514175489,
  "created_at" : "2013-02-17 20:06:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/IJuMK8xU",
      "expanded_url" : "http:\/\/vine.co\/v\/brV1ug9Bhil",
      "display_url" : "vine.co\/v\/brV1ug9Bhil"
    } ]
  },
  "geo" : { },
  "id_str" : "303230814030811136",
  "text" : "Mustard fields http:\/\/t.co\/IJuMK8xU",
  "id" : 303230814030811136,
  "created_at" : "2013-02-17 19:53:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Gordon",
      "screen_name" : "JeremySF",
      "indices" : [ 0, 9 ],
      "id_str" : "19872718",
      "id" : 19872718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303216165734469632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.5047929681, -122.470689564 ]
  },
  "id_str" : "303226438910369792",
  "in_reply_to_user_id" : 19872718,
  "text" : "@JeremySF Ha! Awesome!",
  "id" : 303226438910369792,
  "in_reply_to_status_id" : 303216165734469632,
  "created_at" : "2013-02-17 19:36:31 +0000",
  "in_reply_to_screen_name" : "JeremySF",
  "in_reply_to_user_id_str" : "19872718",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samir mezrahi",
      "screen_name" : "samir",
      "indices" : [ 3, 9 ],
      "id_str" : "115396965",
      "id" : 115396965
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/samir\/status\/303187046007181312\/photo\/1",
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/yHGQwKn9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDUjAxICEAA04DL.jpg",
      "id_str" : "303187046011375616",
      "id" : 303187046011375616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDUjAxICEAA04DL.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yHGQwKn9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303203159290040320",
  "text" : "RT @samir: Is this the iPhone 5S? http:\/\/t.co\/yHGQwKn9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/samir\/status\/303187046007181312\/photo\/1",
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/yHGQwKn9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BDUjAxICEAA04DL.jpg",
        "id_str" : "303187046011375616",
        "id" : 303187046011375616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDUjAxICEAA04DL.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/yHGQwKn9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303187046007181312",
    "text" : "Is this the iPhone 5S? http:\/\/t.co\/yHGQwKn9",
    "id" : 303187046007181312,
    "created_at" : "2013-02-17 16:59:59 +0000",
    "user" : {
      "name" : "samir mezrahi",
      "screen_name" : "samir",
      "protected" : false,
      "id_str" : "115396965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465647540927344640\/cpSfJSi-_normal.jpeg",
      "id" : 115396965,
      "verified" : true
    }
  },
  "id" : 303203159290040320,
  "created_at" : "2013-02-17 18:04:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/Ce5lvTOH",
      "expanded_url" : "http:\/\/flic.kr\/p\/dVB737",
      "display_url" : "flic.kr\/p\/dVB737"
    } ]
  },
  "geo" : { },
  "id_str" : "303188976695652353",
  "text" : "Pedi-cabbin' http:\/\/t.co\/Ce5lvTOH",
  "id" : 303188976695652353,
  "created_at" : "2013-02-17 17:07:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/e1K05p8S",
      "expanded_url" : "http:\/\/flic.kr\/p\/dVsDv7",
      "display_url" : "flic.kr\/p\/dVsDv7"
    } ]
  },
  "geo" : { },
  "id_str" : "303004483561078785",
  "text" : "8:36pm Niko, Nora, and Dottie watch a cartoon before bed http:\/\/t.co\/e1K05p8S",
  "id" : 303004483561078785,
  "created_at" : "2013-02-17 04:54:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/iO1t16sG",
      "expanded_url" : "http:\/\/vine.co\/v\/brU10jeTT0x",
      "display_url" : "vine.co\/v\/brU10jeTT0x"
    } ]
  },
  "geo" : { },
  "id_str" : "302965505713659906",
  "text" : "Are you guys muppets? http:\/\/t.co\/iO1t16sG",
  "id" : 302965505713659906,
  "created_at" : "2013-02-17 02:19:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 38, 48 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/0XeMxUtM",
      "expanded_url" : "http:\/\/instagr.am\/p\/Vz24VGo0FO\/",
      "display_url" : "instagr.am\/p\/Vz24VGo0FO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "302922696222724096",
  "text" : "How they do nap time in St Helena \/cc @helenjane http:\/\/t.co\/0XeMxUtM",
  "id" : 302922696222724096,
  "created_at" : "2013-02-16 23:29:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Gordon",
      "screen_name" : "JeremySF",
      "indices" : [ 0, 9 ],
      "id_str" : "19872718",
      "id" : 19872718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302896451686653952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.5071633943, -122.466730876 ]
  },
  "id_str" : "302921737396428800",
  "in_reply_to_user_id" : 19872718,
  "text" : "@JeremySF Uh oh. Double or nothing? PS I have poor risk management.",
  "id" : 302921737396428800,
  "in_reply_to_status_id" : 302896451686653952,
  "created_at" : "2013-02-16 23:25:44 +0000",
  "in_reply_to_screen_name" : "JeremySF",
  "in_reply_to_user_id_str" : "19872718",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 16, 27 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Andy Rachleff",
      "screen_name" : "arachleff",
      "indices" : [ 81, 91 ],
      "id_str" : "14875576",
      "id" : 14875576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/U6FD99P5",
      "expanded_url" : "http:\/\/tcrn.ch\/Z5ItVh",
      "display_url" : "tcrn.ch\/Z5ItVh"
    } ]
  },
  "in_reply_to_status_id_str" : "302855033530249217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.108132165, -122.2295565439 ]
  },
  "id_str" : "302865482938195969",
  "in_reply_to_user_id" : 816653,
  "text" : "A refresher. RT @TechCrunch: What \"Disrupt\" Really Means http:\/\/t.co\/U6FD99P5 by @arachleff",
  "id" : 302865482938195969,
  "in_reply_to_status_id" : 302855033530249217,
  "created_at" : "2013-02-16 19:42:12 +0000",
  "in_reply_to_screen_name" : "TechCrunch",
  "in_reply_to_user_id_str" : "816653",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/jspQXZaR",
      "expanded_url" : "http:\/\/vine.co\/v\/brIu5wXz910",
      "display_url" : "vine.co\/v\/brIu5wXz910"
    } ]
  },
  "geo" : { },
  "id_str" : "302820032755400704",
  "text" : "Morning concert http:\/\/t.co\/jspQXZaR",
  "id" : 302820032755400704,
  "created_at" : "2013-02-16 16:41:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/VokqNzmn",
      "expanded_url" : "http:\/\/www.newscientist.com\/mobile\/article\/mg21729045.400-the-computer-that-never-crashes.html",
      "display_url" : "newscientist.com\/mobile\/article\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859734213, -122.2754928936 ]
  },
  "id_str" : "302691048612847616",
  "text" : "A new computer based on the apparent chaos of nature can reprogram itself if it finds a fault http:\/\/t.co\/VokqNzmn",
  "id" : 302691048612847616,
  "created_at" : "2013-02-16 08:09:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nullsleep",
      "screen_name" : "Nullsleep",
      "indices" : [ 3, 13 ],
      "id_str" : "15483321",
      "id" : 15483321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302676074519728128",
  "text" : "RT @Nullsleep: \u2736              *            .     `\n         \u2727  .        \u2736         *    .\n\n                           \u2604\n\n\u2587\u2585\u2587\u2583\u2584\u2587\u2581\u2585\u2587\u2587\u2585\u2587",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "302461851529273344",
    "text" : "\u2736              *            .     `\n         \u2727  .        \u2736         *    .\n\n                           \u2604\n\n\u2587\u2585\u2587\u2583\u2584\u2587\u2581\u2585\u2587\u2587\u2585\u2587",
    "id" : 302461851529273344,
    "created_at" : "2013-02-15 16:58:19 +0000",
    "user" : {
      "name" : "Nullsleep",
      "screen_name" : "Nullsleep",
      "protected" : false,
      "id_str" : "15483321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427850848111038464\/UXCFOI4o_normal.png",
      "id" : 15483321,
      "verified" : false
    }
  },
  "id" : 302676074519728128,
  "created_at" : "2013-02-16 07:09:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/ANAENNFa",
      "expanded_url" : "http:\/\/flic.kr\/p\/dVbUZC",
      "display_url" : "flic.kr\/p\/dVbUZC"
    } ]
  },
  "geo" : { },
  "id_str" : "302639946659950592",
  "text" : "8:36pm Brusha brush http:\/\/t.co\/ANAENNFa",
  "id" : 302639946659950592,
  "created_at" : "2013-02-16 04:46:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katy Watkins",
      "screen_name" : "_KatyWatkins",
      "indices" : [ 0, 13 ],
      "id_str" : "238824495",
      "id" : 238824495
    }, {
      "name" : "Ben Ward",
      "screen_name" : "benward",
      "indices" : [ 14, 22 ],
      "id_str" : "12249",
      "id" : 12249
    }, {
      "name" : "Editorially",
      "screen_name" : "GetEditorially",
      "indices" : [ 85, 100 ],
      "id_str" : "368540976",
      "id" : 368540976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302471441713082368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764227055, -122.4165485894 ]
  },
  "id_str" : "302475383507394560",
  "in_reply_to_user_id" : 238824495,
  "text" : "@_KatyWatkins @benward Me too! Though after reading about it I still don't know what @geteditorially actually is.",
  "id" : 302475383507394560,
  "in_reply_to_status_id" : 302471441713082368,
  "created_at" : "2013-02-15 17:52:05 +0000",
  "in_reply_to_screen_name" : "_KatyWatkins",
  "in_reply_to_user_id_str" : "238824495",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farhad Manjoo",
      "screen_name" : "fmanjoo",
      "indices" : [ 3, 11 ],
      "id_str" : "2195241",
      "id" : 2195241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302471562098012160",
  "text" : "RT @fmanjoo: \"Having trouble viewing this email\" is a great email filter.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "302469027102601217",
    "text" : "\"Having trouble viewing this email\" is a great email filter.",
    "id" : 302469027102601217,
    "created_at" : "2013-02-15 17:26:50 +0000",
    "user" : {
      "name" : "Farhad Manjoo",
      "screen_name" : "fmanjoo",
      "protected" : false,
      "id_str" : "2195241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/424235863250173952\/0xeLHVmD_normal.jpeg",
      "id" : 2195241,
      "verified" : true
    }
  },
  "id" : 302471562098012160,
  "created_at" : "2013-02-15 17:36:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8057725534, -122.2971922762 ]
  },
  "id_str" : "302471175374770176",
  "text" : "It's cool that current tech is disrupting publishing and advertising, but when will we start disrupting bigger things like space and time?",
  "id" : 302471175374770176,
  "created_at" : "2013-02-15 17:35:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302468775687626752",
  "text" : "RT @adamochoa: a horse walks into a bar. an elephant walks into a library. a lion walks into a hospital. it\u2019s been five years since the  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "288025387714375682",
    "text" : "a horse walks into a bar. an elephant walks into a library. a lion walks into a hospital. it\u2019s been five years since the last human vanished",
    "id" : 288025387714375682,
    "created_at" : "2013-01-06 20:52:58 +0000",
    "user" : {
      "name" : "adam",
      "screen_name" : "burgerkrang",
      "protected" : false,
      "id_str" : "143197926",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/429864835833032705\/-3p4Lxr3_normal.jpeg",
      "id" : 143197926,
      "verified" : false
    }
  },
  "id" : 302468775687626752,
  "created_at" : "2013-02-15 17:25:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David J Bland",
      "screen_name" : "davidjbland",
      "indices" : [ 3, 15 ],
      "id_str" : "14409265",
      "id" : 14409265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302465165041999874",
  "text" : "RT @davidjbland: Requirements are actually Hypotheses and your Projects are really just Experiments. Realizing this should be liberating.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "302138756813684736",
    "text" : "Requirements are actually Hypotheses and your Projects are really just Experiments. Realizing this should be liberating.",
    "id" : 302138756813684736,
    "created_at" : "2013-02-14 19:34:27 +0000",
    "user" : {
      "name" : "David J Bland",
      "screen_name" : "davidjbland",
      "protected" : false,
      "id_str" : "14409265",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2204894501\/5l70tbn29zjp4ksukidm_normal.png",
      "id" : 14409265,
      "verified" : false
    }
  },
  "id" : 302465165041999874,
  "created_at" : "2013-02-15 17:11:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Brewer",
      "screen_name" : "jbrewer",
      "indices" : [ 0, 8 ],
      "id_str" : "12555",
      "id" : 12555
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hatefollowing",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302458148822863872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596428343, -122.2752825533 ]
  },
  "id_str" : "302459741119078400",
  "in_reply_to_user_id" : 12555,
  "text" : "@jbrewer I would but I subscribe to the philosophy that if you don't like what people tweet you should unfollow. But I can't. #hatefollowing",
  "id" : 302459741119078400,
  "in_reply_to_status_id" : 302458148822863872,
  "created_at" : "2013-02-15 16:49:56 +0000",
  "in_reply_to_screen_name" : "jbrewer",
  "in_reply_to_user_id_str" : "12555",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859620149, -122.2754258695 ]
  },
  "id_str" : "302455322705027073",
  "text" : "I often reply to feel good habit\/behavior change advice on Twitter in my head. The reply is always \"LIES!\"",
  "id" : 302455322705027073,
  "created_at" : "2013-02-15 16:32:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302446662083833858",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859664266, -122.2755093222 ]
  },
  "id_str" : "302449072319655936",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim Send me a screenshot if you can. I'll file it internally.",
  "id" : 302449072319655936,
  "in_reply_to_status_id" : 302446662083833858,
  "created_at" : "2013-02-15 16:07:32 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302425113998008320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596305087, -122.2754405341 ]
  },
  "id_str" : "302444138022961153",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim What's the bug? Should I call the twambulance?",
  "id" : 302444138022961153,
  "in_reply_to_status_id" : 302425113998008320,
  "created_at" : "2013-02-15 15:47:56 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/X1hERuZr",
      "expanded_url" : "http:\/\/flic.kr\/p\/dUXfD3",
      "display_url" : "flic.kr\/p\/dUXfD3"
    } ]
  },
  "geo" : { },
  "id_str" : "302277592269062144",
  "text" : "8:36pm Cheers to my lovely valentine! http:\/\/t.co\/X1hERuZr",
  "id" : 302277592269062144,
  "created_at" : "2013-02-15 04:46:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 57, 67 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/ddbqeYZq",
      "expanded_url" : "http:\/\/4sq.com\/Zejsez",
      "display_url" : "4sq.com\/Zejsez"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8511071594, -122.2523188591 ]
  },
  "id_str" : "302263543791775744",
  "text" : "Checking out Rockridge. Where should we go? (@ Mitama w\/ @kellianne) http:\/\/t.co\/ddbqeYZq",
  "id" : 302263543791775744,
  "created_at" : "2013-02-15 03:50:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reeve S. Thompson ",
      "screen_name" : "Reeve",
      "indices" : [ 0, 6 ],
      "id_str" : "9317922",
      "id" : 9317922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301955173612392448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596250806, -122.2756197118 ]
  },
  "id_str" : "301956117943156736",
  "in_reply_to_user_id" : 9317922,
  "text" : "@Reeve It really is! Also let's you see which sitters have had repeats, whether they've been hired by friends, and pay by credit card!",
  "id" : 301956117943156736,
  "in_reply_to_status_id" : 301955173612392448,
  "created_at" : "2013-02-14 07:28:43 +0000",
  "in_reply_to_screen_name" : "Reeve",
  "in_reply_to_user_id_str" : "9317922",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301951452883058688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597092331, -122.2756105312 ]
  },
  "id_str" : "301952695948939264",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling OMG that is a *great* idea!",
  "id" : 301952695948939264,
  "in_reply_to_status_id" : 301951452883058688,
  "created_at" : "2013-02-14 07:15:07 +0000",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reeve S. Thompson ",
      "screen_name" : "Reeve",
      "indices" : [ 0, 6 ],
      "id_str" : "9317922",
      "id" : 9317922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301952023551684608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597822413, -122.2756552511 ]
  },
  "id_str" : "301952564730142720",
  "in_reply_to_user_id" : 9317922,
  "text" : "@Reeve I got a babysitter for Valentine's Day at 10:30pm the night before. But will have better info to report after tomorrow...",
  "id" : 301952564730142720,
  "in_reply_to_status_id" : 301952023551684608,
  "created_at" : "2013-02-14 07:14:36 +0000",
  "in_reply_to_screen_name" : "Reeve",
  "in_reply_to_user_id_str" : "9317922",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/o6QuN7Bb",
      "expanded_url" : "http:\/\/bit.ly\/Y9Z2fN",
      "display_url" : "bit.ly\/Y9Z2fN"
    } ]
  },
  "geo" : { },
  "id_str" : "301947862344933376",
  "text" : "Woah, http:\/\/t.co\/o6QuN7Bb is sort of magical.",
  "id" : 301947862344933376,
  "created_at" : "2013-02-14 06:55:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/t9o69LPW",
      "expanded_url" : "http:\/\/flic.kr\/p\/dUCwJ6",
      "display_url" : "flic.kr\/p\/dUCwJ6"
    } ]
  },
  "geo" : { },
  "id_str" : "301922323974471680",
  "text" : "8:36pm Niko now recognizes my 8:36 alarm and insists on taking the pictures himself. http:\/\/t.co\/t9o69LPW",
  "id" : 301922323974471680,
  "created_at" : "2013-02-14 05:14:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8565087309, -122.2714995035 ]
  },
  "id_str" : "301884781539520512",
  "text" : "If I start a band I'm gonna call it \"Vague tweets about work that nobody will get are the new screaming into pillows\".",
  "id" : 301884781539520512,
  "created_at" : "2013-02-14 02:45:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 3, 14 ],
      "id_str" : "3452941",
      "id" : 3452941
    }, {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "indices" : [ 90, 99 ],
      "id_str" : "255784266",
      "id" : 255784266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/KWuHUECC",
      "expanded_url" : "http:\/\/www.geekwire.com\/2013\/world-supposed-vine\/",
      "display_url" : "geekwire.com\/2013\/world-sup\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301846128712892416",
  "text" : "RT @moniguzman: Embedding YouTube videos into a post is one thing. Embedding Vines? Whoa. @geekwire http:\/\/t.co\/KWuHUECC",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GeekWire",
        "screen_name" : "geekwire",
        "indices" : [ 74, 83 ],
        "id_str" : "255784266",
        "id" : 255784266
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/KWuHUECC",
        "expanded_url" : "http:\/\/www.geekwire.com\/2013\/world-supposed-vine\/",
        "display_url" : "geekwire.com\/2013\/world-sup\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301845090287120385",
    "text" : "Embedding YouTube videos into a post is one thing. Embedding Vines? Whoa. @geekwire http:\/\/t.co\/KWuHUECC",
    "id" : 301845090287120385,
    "created_at" : "2013-02-14 00:07:32 +0000",
    "user" : {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "protected" : false,
      "id_str" : "3452941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454510513251037184\/83aM56tP_normal.jpeg",
      "id" : 3452941,
      "verified" : false
    }
  },
  "id" : 301846128712892416,
  "created_at" : "2013-02-14 00:11:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hall",
      "screen_name" : "JamesHallPhoto",
      "indices" : [ 3, 18 ],
      "id_str" : "63792306",
      "id" : 63792306
    }, {
      "name" : "Casey Neistat",
      "screen_name" : "CaseyNeistat",
      "indices" : [ 60, 73 ],
      "id_str" : "154221292",
      "id" : 154221292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/8hwrjZA1",
      "expanded_url" : "http:\/\/nyti.ms\/WHJFPY",
      "display_url" : "nyti.ms\/WHJFPY"
    } ]
  },
  "geo" : { },
  "id_str" : "301790588632707073",
  "text" : "RT @JamesHallPhoto: Fun video expos\u00E9 reveals calorie truths @CaseyNeistat: most calorie listings on food labels are lies. New York Times ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Casey Neistat",
        "screen_name" : "CaseyNeistat",
        "indices" : [ 40, 53 ],
        "id_str" : "154221292",
        "id" : 154221292
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/8hwrjZA1",
        "expanded_url" : "http:\/\/nyti.ms\/WHJFPY",
        "display_url" : "nyti.ms\/WHJFPY"
      } ]
    },
    "in_reply_to_status_id_str" : "301699644168208384",
    "geo" : { },
    "id_str" : "301783615304499201",
    "in_reply_to_user_id" : 154221292,
    "text" : "Fun video expos\u00E9 reveals calorie truths @CaseyNeistat: most calorie listings on food labels are lies. New York Times http:\/\/t.co\/8hwrjZA1",
    "id" : 301783615304499201,
    "in_reply_to_status_id" : 301699644168208384,
    "created_at" : "2013-02-13 20:03:15 +0000",
    "in_reply_to_screen_name" : "CaseyNeistat",
    "in_reply_to_user_id_str" : "154221292",
    "user" : {
      "name" : "James Hall",
      "screen_name" : "JamesHallPhoto",
      "protected" : false,
      "id_str" : "63792306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459007305212641280\/RGACC9iy_normal.jpeg",
      "id" : 63792306,
      "verified" : false
    }
  },
  "id" : 301790588632707073,
  "created_at" : "2013-02-13 20:30:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smart",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301587427586355200",
  "text" : "In order to start a new PG&amp;E (gas and electricity here in the Bay Area) account online, you need an account number. #smart",
  "id" : 301587427586355200,
  "created_at" : "2013-02-13 07:03:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/Dpf0kGjc",
      "expanded_url" : "http:\/\/bit.ly\/15bcZBm",
      "display_url" : "bit.ly\/15bcZBm"
    } ]
  },
  "geo" : { },
  "id_str" : "301583538715783168",
  "text" : "Sad to be selling my couch. Make me an offer! http:\/\/t.co\/Dpf0kGjc",
  "id" : 301583538715783168,
  "created_at" : "2013-02-13 06:48:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mitch Monsen",
      "screen_name" : "mitchmonsen",
      "indices" : [ 3, 15 ],
      "id_str" : "158941275",
      "id" : 158941275
    }, {
      "name" : "Quora",
      "screen_name" : "Quora",
      "indices" : [ 81, 87 ],
      "id_str" : "33696409",
      "id" : 33696409
    }, {
      "name" : "Oliver Emberton",
      "screen_name" : "oliveremberton",
      "indices" : [ 92, 107 ],
      "id_str" : "16004473",
      "id" : 16004473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/zdbTQVLG",
      "expanded_url" : "http:\/\/bit.ly\/11EWRt4",
      "display_url" : "bit.ly\/11EWRt4"
    } ]
  },
  "geo" : { },
  "id_str" : "301564347648462848",
  "text" : "RT @mitchmonsen: How to Master Your Life: Play the Sims http:\/\/t.co\/zdbTQVLG via @quora and @oliveremberton. Great stuff!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quora",
        "screen_name" : "Quora",
        "indices" : [ 64, 70 ],
        "id_str" : "33696409",
        "id" : 33696409
      }, {
        "name" : "Oliver Emberton",
        "screen_name" : "oliveremberton",
        "indices" : [ 75, 90 ],
        "id_str" : "16004473",
        "id" : 16004473
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/zdbTQVLG",
        "expanded_url" : "http:\/\/bit.ly\/11EWRt4",
        "display_url" : "bit.ly\/11EWRt4"
      } ]
    },
    "geo" : { },
    "id_str" : "301489781119008769",
    "text" : "How to Master Your Life: Play the Sims http:\/\/t.co\/zdbTQVLG via @quora and @oliveremberton. Great stuff!",
    "id" : 301489781119008769,
    "created_at" : "2013-02-13 00:35:39 +0000",
    "user" : {
      "name" : "Mitch Monsen",
      "screen_name" : "mitchmonsen",
      "protected" : false,
      "id_str" : "158941275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1409243938\/Mugshot1Pro_normal.jpg",
      "id" : 158941275,
      "verified" : false
    }
  },
  "id" : 301564347648462848,
  "created_at" : "2013-02-13 05:31:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/ZFzeWrKs",
      "expanded_url" : "http:\/\/flic.kr\/p\/dUupUN",
      "display_url" : "flic.kr\/p\/dUupUN"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.275334 ]
  },
  "id_str" : "301558230813913088",
  "text" : "8:36pm Trying to convince this guy that there are monsters in his closet but he's not buying it http:\/\/t.co\/ZFzeWrKs",
  "id" : 301558230813913088,
  "created_at" : "2013-02-13 05:07:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7788779549, -122.4145688437 ]
  },
  "id_str" : "301516042721697792",
  "text" : "What did you just say?",
  "id" : 301516042721697792,
  "created_at" : "2013-02-13 02:20:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 111, 120 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/7lPfHlfn",
      "expanded_url" : "http:\/\/amyjokim.com\/2012\/09\/19\/social-engagement-whos-playing-how-do-they-like-to-engage\/",
      "display_url" : "amyjokim.com\/2012\/09\/19\/soc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7932316921, -122.3966581576 ]
  },
  "id_str" : "301380539573739521",
  "text" : "Compete, collaborate, express, &amp; explore: 4 verbs you need to know to understand #gamification. Well said, @amyjokim http:\/\/t.co\/7lPfHlfn",
  "id" : 301380539573739521,
  "created_at" : "2013-02-12 17:21:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/kjkfvpSV",
      "expanded_url" : "http:\/\/flic.kr\/p\/dUa7Jc",
      "display_url" : "flic.kr\/p\/dUa7Jc"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595, -122.2755 ]
  },
  "id_str" : "301218931903967232",
  "text" : "8:36pm Niko *was* holding a stuffed penguin with his chin but let it go right before I could take a picture http:\/\/t.co\/kjkfvpSV",
  "id" : 301218931903967232,
  "created_at" : "2013-02-12 06:39:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cadell Last",
      "screen_name" : "cadelllast",
      "indices" : [ 60, 71 ],
      "id_str" : "269588540",
      "id" : 269588540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/vtLFNIvb",
      "expanded_url" : "http:\/\/theratchet.ca\/the-next-evolution",
      "display_url" : "theratchet.ca\/the-next-evolu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301215613379043328",
  "text" : "RT @SvbtleFeed: The Next Evolution\n\nhttp:\/\/t.co\/vtLFNIvb by @cadelllast",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/svbtle.com\" rel=\"nofollow\"\u003ESvbtle Feed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cadell Last",
        "screen_name" : "cadelllast",
        "indices" : [ 44, 55 ],
        "id_str" : "269588540",
        "id" : 269588540
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 40 ],
        "url" : "http:\/\/t.co\/vtLFNIvb",
        "expanded_url" : "http:\/\/theratchet.ca\/the-next-evolution",
        "display_url" : "theratchet.ca\/the-next-evolu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301154308907479041",
    "text" : "The Next Evolution\n\nhttp:\/\/t.co\/vtLFNIvb by @cadelllast",
    "id" : 301154308907479041,
    "created_at" : "2013-02-12 02:22:37 +0000",
    "user" : {
      "name" : "Svbtle",
      "screen_name" : "Svbtle",
      "protected" : false,
      "id_str" : "776098190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3628360840\/42e89e02ef6e7a798d74e8bdf7ed4364_normal.png",
      "id" : 776098190,
      "verified" : false
    }
  },
  "id" : 301215613379043328,
  "created_at" : "2013-02-12 06:26:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/301166335503781888\/photo\/1",
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/DK2r9k5v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC31L76CUAAzyAf.jpg",
      "id_str" : "301166335512170496",
      "id" : 301166335512170496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC31L76CUAAzyAf.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      } ],
      "display_url" : "pic.twitter.com\/DK2r9k5v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301166335503781888",
  "text" : "1) The moon is a Cheshire Cat tonight. 2) Why do pictures of the moon always make it look so puny? http:\/\/t.co\/DK2r9k5v",
  "id" : 301166335503781888,
  "created_at" : "2013-02-12 03:10:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/read-it-later-pro\/id309601447?mt=8&uo=4\" rel=\"nofollow\"\u003EPocket for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Graham",
      "screen_name" : "paulg",
      "indices" : [ 56, 62 ],
      "id_str" : "183749519",
      "id" : 183749519
    }, {
      "name" : "Pocket",
      "screen_name" : "Pocket",
      "indices" : [ 95, 102 ],
      "id_str" : "27530178",
      "id" : 27530178
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "longreads",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/qmyiPMDB",
      "expanded_url" : "http:\/\/pocket.co\/swk4R",
      "display_url" : "pocket.co\/swk4R"
    } ]
  },
  "geo" : { },
  "id_str" : "301164613817466880",
  "text" : "Best read in a while, even if you don't have kids. From @paulg in 2008: Lies We Tell Kids (via @Pocket) #longreads http:\/\/t.co\/qmyiPMDB",
  "id" : 301164613817466880,
  "created_at" : "2013-02-12 03:03:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simply Measured",
      "screen_name" : "simplymeasured",
      "indices" : [ 3, 18 ],
      "id_str" : "92162698",
      "id" : 92162698
    }, {
      "name" : "Vine",
      "screen_name" : "vineapp",
      "indices" : [ 30, 38 ],
      "id_str" : "586671909",
      "id" : 586671909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/1JbNLQnB",
      "expanded_url" : "http:\/\/bit.ly\/14O6FPf",
      "display_url" : "bit.ly\/14O6FPf"
    } ]
  },
  "geo" : { },
  "id_str" : "301078968721870848",
  "text" : "RT @simplymeasured: Over 110k @vineapp videos were posted to Twitter this weekend. We analyzed all of them: http:\/\/t.co\/1JbNLQnB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vine",
        "screen_name" : "vineapp",
        "indices" : [ 10, 18 ],
        "id_str" : "586671909",
        "id" : 586671909
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/1JbNLQnB",
        "expanded_url" : "http:\/\/bit.ly\/14O6FPf",
        "display_url" : "bit.ly\/14O6FPf"
      } ]
    },
    "geo" : { },
    "id_str" : "301067437221232641",
    "text" : "Over 110k @vineapp videos were posted to Twitter this weekend. We analyzed all of them: http:\/\/t.co\/1JbNLQnB",
    "id" : 301067437221232641,
    "created_at" : "2013-02-11 20:37:25 +0000",
    "user" : {
      "name" : "Simply Measured",
      "screen_name" : "simplymeasured",
      "protected" : false,
      "id_str" : "92162698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000125372008\/7583819d9e230e8af55fe1b96141b05a_normal.jpeg",
      "id" : 92162698,
      "verified" : true
    }
  },
  "id" : 301078968721870848,
  "created_at" : "2013-02-11 21:23:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lowell",
      "screen_name" : "jthomas",
      "indices" : [ 0, 8 ],
      "id_str" : "760181",
      "id" : 760181
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 9, 17 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301026935629312001",
  "geo" : { },
  "id_str" : "301027722438770688",
  "in_reply_to_user_id" : 760181,
  "text" : "@jthomas @mybasis Hm, I'm on a MacBook Pro. My iMac is still in storage (just moved). I've been in correspondence with Kristin S in support.",
  "id" : 301027722438770688,
  "in_reply_to_status_id" : 301026935629312001,
  "created_at" : "2013-02-11 17:59:36 +0000",
  "in_reply_to_screen_name" : "jthomas",
  "in_reply_to_user_id_str" : "760181",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    }, {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 14, 20 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300998493965799425",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597626277, -122.2753964179 ]
  },
  "id_str" : "300999883639377921",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten @joshc I actually unfollowed him yesterday.",
  "id" : 300999883639377921,
  "in_reply_to_status_id" : 300998493965799425,
  "created_at" : "2013-02-11 16:08:59 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lawblob",
      "screen_name" : "lawblob",
      "indices" : [ 3, 11 ],
      "id_str" : "41875694",
      "id" : 41875694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300989572941221888",
  "text" : "RT @lawblob: the Pope is quitting because he feels he can be a bigger influence as a pundit on Fox News",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "300985425768611840",
    "text" : "the Pope is quitting because he feels he can be a bigger influence as a pundit on Fox News",
    "id" : 300985425768611840,
    "created_at" : "2013-02-11 15:11:32 +0000",
    "user" : {
      "name" : "lawblob",
      "screen_name" : "lawblob",
      "protected" : false,
      "id_str" : "41875694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000712022277\/fee5add6cc078b6f557bcfd3a85821c2_normal.jpeg",
      "id" : 41875694,
      "verified" : false
    }
  },
  "id" : 300989572941221888,
  "created_at" : "2013-02-11 15:28:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 0, 14 ],
      "id_str" : "820661",
      "id" : 820661
    }, {
      "name" : "Mailbox",
      "screen_name" : "mailbox",
      "indices" : [ 35, 43 ],
      "id_str" : "624947324",
      "id" : 624947324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300844485431132160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8593440309, -122.2759565779 ]
  },
  "id_str" : "300847680177991680",
  "in_reply_to_user_id" : 820661,
  "text" : "@daveschappell Ha. Have you gotten @mailbox yet? Solves that by hitting snooze on entire task list. I sorta like it.",
  "id" : 300847680177991680,
  "in_reply_to_status_id" : 300844485431132160,
  "created_at" : "2013-02-11 06:04:11 +0000",
  "in_reply_to_screen_name" : "daveschappell",
  "in_reply_to_user_id_str" : "820661",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Robertson",
      "screen_name" : "Loobylu",
      "indices" : [ 0, 8 ],
      "id_str" : "653333",
      "id" : 653333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300835007533031424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859577589, -122.2753522209 ]
  },
  "id_str" : "300836103420792832",
  "in_reply_to_user_id" : 653333,
  "text" : "@Loobylu No, it's just that everyone else got so young!",
  "id" : 300836103420792832,
  "in_reply_to_status_id" : 300835007533031424,
  "created_at" : "2013-02-11 05:18:10 +0000",
  "in_reply_to_screen_name" : "Loobylu",
  "in_reply_to_user_id_str" : "653333",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Shellen",
      "screen_name" : "shellen",
      "indices" : [ 52, 60 ],
      "id_str" : "422",
      "id" : 422
    }, {
      "name" : "Blogger",
      "screen_name" : "Blogger",
      "indices" : [ 99, 107 ],
      "id_str" : "18780567",
      "id" : 18780567
    }, {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 120, 127 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300693220235542528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597910358, -122.2759878593 ]
  },
  "id_str" : "300833448749322240",
  "in_reply_to_user_id" : 422,
  "text" : "I remember exactly where I was when I found out. RT @shellen: On this day 10 years ago, our little @Blogger team joined @Google. Good times.",
  "id" : 300833448749322240,
  "in_reply_to_status_id" : 300693220235542528,
  "created_at" : "2013-02-11 05:07:38 +0000",
  "in_reply_to_screen_name" : "shellen",
  "in_reply_to_user_id_str" : "422",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/BKRpaPzK",
      "expanded_url" : "http:\/\/flic.kr\/p\/dTS2Qn",
      "display_url" : "flic.kr\/p\/dTS2Qn"
    } ]
  },
  "geo" : { },
  "id_str" : "300829155468124160",
  "text" : "8:36pm Our place is still a mess but it's a happy mess http:\/\/t.co\/BKRpaPzK",
  "id" : 300829155468124160,
  "created_at" : "2013-02-11 04:50:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 47, 58 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 135 ],
      "url" : "https:\/\/t.co\/KWOKBZfj",
      "expanded_url" : "https:\/\/foursquare.com\/buster\/badge\/51186104e4b05931ead7cc92?ref=tw",
      "display_url" : "foursquare.com\/buster\/badge\/5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "300803830986203137",
  "text" : "I just reached Level 4 of the \"Bento\" badge on @foursquare. I\u2019ve checked in at 15 different Japanese Restaurants! https:\/\/t.co\/KWOKBZfj",
  "id" : 300803830986203137,
  "created_at" : "2013-02-11 03:09:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robi Ganguly",
      "screen_name" : "rganguly",
      "indices" : [ 0, 9 ],
      "id_str" : "622663",
      "id" : 622663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300765607874400257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597188703, -122.2751461593 ]
  },
  "id_str" : "300766636317749248",
  "in_reply_to_user_id" : 622663,
  "text" : "@rganguly Had lunch at Berkeley Bowl just today. Will check out Zachary's! Thanks! Send any other recs you've got.",
  "id" : 300766636317749248,
  "in_reply_to_status_id" : 300765607874400257,
  "created_at" : "2013-02-11 00:42:08 +0000",
  "in_reply_to_screen_name" : "rganguly",
  "in_reply_to_user_id_str" : "622663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robi Ganguly",
      "screen_name" : "rganguly",
      "indices" : [ 0, 9 ],
      "id_str" : "622663",
      "id" : 622663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300764956352196608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596446219, -122.2753109938 ]
  },
  "id_str" : "300765427993305088",
  "in_reply_to_user_id" : 622663,
  "text" : "@rganguly South Berkeley, just north of the Ashby Bart stop.",
  "id" : 300765427993305088,
  "in_reply_to_status_id" : 300764956352196608,
  "created_at" : "2013-02-11 00:37:20 +0000",
  "in_reply_to_screen_name" : "rganguly",
  "in_reply_to_user_id_str" : "622663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597144792, -122.2754796676 ]
  },
  "id_str" : "300764117256523776",
  "text" : "Took a long sunny circuitous walk, checked out the local coffee shops, joined the downtown YMCA. Totally loving my new neighborhood.",
  "id" : 300764117256523776,
  "created_at" : "2013-02-11 00:32:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300761551764336641",
  "geo" : { },
  "id_str" : "300762991421452290",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Rent forever! Buy stock or something instead!",
  "id" : 300762991421452290,
  "in_reply_to_status_id" : 300761551764336641,
  "created_at" : "2013-02-11 00:27:39 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300762713687203840",
  "text" : "Our neighbors\/landlords (65 &amp; 80 years old respectively) are going on a month-long skiing trip in Vermont. I am lazy.",
  "id" : 300762713687203840,
  "created_at" : "2013-02-11 00:26:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaurav Gupta",
      "screen_name" : "unsymmetric",
      "indices" : [ 0, 12 ],
      "id_str" : "16554166",
      "id" : 16554166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300661682508804097",
  "geo" : { },
  "id_str" : "300668889572974592",
  "in_reply_to_user_id" : 16554166,
  "text" : "@unsymmetric Thank you!",
  "id" : 300668889572974592,
  "in_reply_to_status_id" : 300661682508804097,
  "created_at" : "2013-02-10 18:13:44 +0000",
  "in_reply_to_screen_name" : "unsymmetric",
  "in_reply_to_user_id_str" : "16554166",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 0, 11 ],
      "id_str" : "26123649",
      "id" : 26123649
    }, {
      "name" : "Randall Dietel",
      "screen_name" : "R27D",
      "indices" : [ 12, 17 ],
      "id_str" : "171937887",
      "id" : 171937887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300658945448620035",
  "geo" : { },
  "id_str" : "300660746465988608",
  "in_reply_to_user_id" : 26123649,
  "text" : "@brianellin @R27D You're probably right. Thanks for the tips on local bike shops to check out. Any good ones in Berkeley that you know of?",
  "id" : 300660746465988608,
  "in_reply_to_status_id" : 300658945448620035,
  "created_at" : "2013-02-10 17:41:22 +0000",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaurav Gupta",
      "screen_name" : "unsymmetric",
      "indices" : [ 0, 12 ],
      "id_str" : "16554166",
      "id" : 16554166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300657176974852096",
  "geo" : { },
  "id_str" : "300657932574543873",
  "in_reply_to_user_id" : 16554166,
  "text" : "@unsymmetric Riding around SF\/Berkeley, occasionally taking it on BART, and might be taking it to the country for biking wine tours.",
  "id" : 300657932574543873,
  "in_reply_to_status_id" : 300657176974852096,
  "created_at" : "2013-02-10 17:30:11 +0000",
  "in_reply_to_screen_name" : "unsymmetric",
  "in_reply_to_user_id_str" : "16554166",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/I5jU2WuP",
      "expanded_url" : "http:\/\/bit.ly\/14LLHk8",
      "display_url" : "bit.ly\/14LLHk8"
    } ]
  },
  "geo" : { },
  "id_str" : "300656275178528768",
  "text" : "Which bike should I get? http:\/\/t.co\/I5jU2WuP",
  "id" : 300656275178528768,
  "created_at" : "2013-02-10 17:23:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300502827644633089",
  "geo" : { },
  "id_str" : "300505173321715712",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Toss it in the mail when you're done!",
  "id" : 300505173321715712,
  "in_reply_to_status_id" : 300502827644633089,
  "created_at" : "2013-02-10 07:23:11 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300438714537086976",
  "geo" : { },
  "id_str" : "300495070946279425",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin The other sounds were cut of \"cheese!\"es.",
  "id" : 300495070946279425,
  "in_reply_to_status_id" : 300438714537086976,
  "created_at" : "2013-02-10 06:43:02 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300479012902408192",
  "geo" : { },
  "id_str" : "300494915807346689",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel I am IN! I assume it's on Netflix or Hulu or some such?",
  "id" : 300494915807346689,
  "in_reply_to_status_id" : 300479012902408192,
  "created_at" : "2013-02-10 06:42:25 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brennan Novak",
      "screen_name" : "brennannovak",
      "indices" : [ 0, 13 ],
      "id_str" : "17958179",
      "id" : 17958179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300467845857411072",
  "geo" : { },
  "id_str" : "300469169898541056",
  "in_reply_to_user_id" : 17958179,
  "text" : "@brennannovak Fear of being left out.",
  "id" : 300469169898541056,
  "in_reply_to_status_id" : 300467845857411072,
  "created_at" : "2013-02-10 05:00:07 +0000",
  "in_reply_to_screen_name" : "brennannovak",
  "in_reply_to_user_id_str" : "17958179",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 34, 45 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/icAgpkL4",
      "expanded_url" : "http:\/\/instagram.com\/p\/Vh_D74I0Jn\/",
      "display_url" : "instagram.com\/p\/Vh_D74I0Jn\/"
    }, {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/B7nu9kN2",
      "expanded_url" : "http:\/\/vine.co\/v\/bvKrWQImMQd",
      "display_url" : "vine.co\/v\/bvKrWQImMQd"
    } ]
  },
  "geo" : { },
  "id_str" : "300419402854191104",
  "text" : "Exhibit A and B in the battle for @nikobenson's cute moments:\n\nA) http:\/\/t.co\/icAgpkL4\nB) http:\/\/t.co\/B7nu9kN2 \n\nWho wins?",
  "id" : 300419402854191104,
  "created_at" : "2013-02-10 01:42:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/B7nu9kN2",
      "expanded_url" : "http:\/\/vine.co\/v\/bvKrWQImMQd",
      "display_url" : "vine.co\/v\/bvKrWQImMQd"
    } ]
  },
  "geo" : { },
  "id_str" : "300407842123415552",
  "text" : "Giddyup! http:\/\/t.co\/B7nu9kN2",
  "id" : 300407842123415552,
  "created_at" : "2013-02-10 00:56:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300316492006834176",
  "geo" : { },
  "id_str" : "300366961332854784",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Niko needs that book!",
  "id" : 300366961332854784,
  "in_reply_to_status_id" : 300316492006834176,
  "created_at" : "2013-02-09 22:13:58 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 0, 8 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/300347150066384896\/photo\/1",
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/WcIdJOLE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCsMJEVCAAAw49l.png",
      "id_str" : "300347150070579200",
      "id" : 300347150070579200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCsMJEVCAAAw49l.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 1006
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 1006
      } ],
      "display_url" : "pic.twitter.com\/WcIdJOLE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300347150066384896",
  "in_reply_to_user_id" : 216453702,
  "text" : "@mybasis No, I'm trying to activate my Basis watch for the first time. Can't get past this page: http:\/\/t.co\/WcIdJOLE",
  "id" : 300347150066384896,
  "created_at" : "2013-02-09 20:55:15 +0000",
  "in_reply_to_screen_name" : "mybasis",
  "in_reply_to_user_id_str" : "216453702",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 0, 8 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300344644389175296",
  "geo" : { },
  "id_str" : "300344868830576640",
  "in_reply_to_user_id" : 216453702,
  "text" : "@mybasis Nothing. I hit \"continue\" on the connect page and eventually the continue button turns blue again. No errors.",
  "id" : 300344868830576640,
  "in_reply_to_status_id" : 300344644389175296,
  "created_at" : "2013-02-09 20:46:11 +0000",
  "in_reply_to_screen_name" : "mybasis",
  "in_reply_to_user_id_str" : "216453702",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 51, 62 ],
      "id_str" : "14120151",
      "id" : 14120151
    }, {
      "name" : "HISTORY",
      "screen_name" : "HISTORY",
      "indices" : [ 97, 105 ],
      "id_str" : "22692199",
      "id" : 22692199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/h5WSRcLm",
      "expanded_url" : "http:\/\/4sq.com\/VLGDX1",
      "display_url" : "4sq.com\/VLGDX1"
    } ]
  },
  "geo" : { },
  "id_str" : "300310733323911168",
  "text" : "I just reached Level 2 of the \"Historian\" badge on @foursquare. I found 4 historic tips from the @History Channel http:\/\/t.co\/h5WSRcLm",
  "id" : 300310733323911168,
  "created_at" : "2013-02-09 18:30:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claudecf",
      "screen_name" : "claudecf",
      "indices" : [ 0, 9 ],
      "id_str" : "607743",
      "id" : 607743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300276876453232640",
  "geo" : { },
  "id_str" : "300279226697928704",
  "in_reply_to_user_id" : 607743,
  "text" : "@claudecf That's totally fine. Penzu is a great service.",
  "id" : 300279226697928704,
  "in_reply_to_status_id" : 300276876453232640,
  "created_at" : "2013-02-09 16:25:21 +0000",
  "in_reply_to_screen_name" : "claudecf",
  "in_reply_to_user_id_str" : "607743",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lawblob",
      "screen_name" : "lawblob",
      "indices" : [ 3, 11 ],
      "id_str" : "41875694",
      "id" : 41875694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300256211088056320",
  "text" : "RT @lawblob: RT = rat tail, MT = Mexican trucker, DM = dragon math, FF = Fat Feet, TL = Tuba Lyfe, OH = Ohio \n\nNow you know.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "300252337161773058",
    "text" : "RT = rat tail, MT = Mexican trucker, DM = dragon math, FF = Fat Feet, TL = Tuba Lyfe, OH = Ohio \n\nNow you know.",
    "id" : 300252337161773058,
    "created_at" : "2013-02-09 14:38:30 +0000",
    "user" : {
      "name" : "lawblob",
      "screen_name" : "lawblob",
      "protected" : false,
      "id_str" : "41875694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000712022277\/fee5add6cc078b6f557bcfd3a85821c2_normal.jpeg",
      "id" : 41875694,
      "verified" : false
    }
  },
  "id" : 300256211088056320,
  "created_at" : "2013-02-09 14:53:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Maberly",
      "screen_name" : "CMaberly",
      "indices" : [ 0, 9 ],
      "id_str" : "128375612",
      "id" : 128375612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300190695464005632",
  "geo" : { },
  "id_str" : "300255030257278976",
  "in_reply_to_user_id" : 128375612,
  "text" : "@CMaberly Not all connections built (online + offline) translate into reality. We do our best to connect with others and some small % last.",
  "id" : 300255030257278976,
  "in_reply_to_status_id" : 300190695464005632,
  "created_at" : "2013-02-09 14:49:12 +0000",
  "in_reply_to_screen_name" : "CMaberly",
  "in_reply_to_user_id_str" : "128375612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claudecf",
      "screen_name" : "claudecf",
      "indices" : [ 0, 9 ],
      "id_str" : "607743",
      "id" : 607743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300153940979367937",
  "geo" : { },
  "id_str" : "300254477557067776",
  "in_reply_to_user_id" : 607743,
  "text" : "@claudecf I'm thinking about it. Times have changed since I first created the site 3 years ago.",
  "id" : 300254477557067776,
  "in_reply_to_status_id" : 300153940979367937,
  "created_at" : "2013-02-09 14:47:00 +0000",
  "in_reply_to_screen_name" : "claudecf",
  "in_reply_to_user_id_str" : "607743",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tired",
      "indices" : [ 60, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/MyZPBIK6",
      "expanded_url" : "http:\/\/flic.kr\/p\/dTpUEC",
      "display_url" : "flic.kr\/p\/dTpUEC"
    } ]
  },
  "geo" : { },
  "id_str" : "300140404181983233",
  "text" : "8:36pm Too tired to eat. Too tired to watch The Daily Show. #tired http:\/\/t.co\/MyZPBIK6",
  "id" : 300140404181983233,
  "created_at" : "2013-02-09 07:13:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 3, 14 ],
      "id_str" : "1586501",
      "id" : 1586501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300136379378171904",
  "text" : "RT @nickbilton: The revolution will be tweeted. The sunset, Instagrammed. The relationship, Facebooked. The storm, Vined.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "300022857486966784",
    "text" : "The revolution will be tweeted. The sunset, Instagrammed. The relationship, Facebooked. The storm, Vined.",
    "id" : 300022857486966784,
    "created_at" : "2013-02-08 23:26:38 +0000",
    "user" : {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "protected" : false,
      "id_str" : "1586501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453750282770341888\/SEwjZ2AI_normal.png",
      "id" : 1586501,
      "verified" : true
    }
  },
  "id" : 300136379378171904,
  "created_at" : "2013-02-09 06:57:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 8, 16 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300088147897888768",
  "text" : "I got a @mybasis watch but it won't connect to my account. Anybody else have this problem?",
  "id" : 300088147897888768,
  "created_at" : "2013-02-09 03:46:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dick costolo",
      "screen_name" : "dickc",
      "indices" : [ 22, 28 ],
      "id_str" : "6385432",
      "id" : 6385432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300056668593606656",
  "text" : "\"Don't hate. Love.\" - @dickc",
  "id" : 300056668593606656,
  "created_at" : "2013-02-09 01:40:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claudecf",
      "screen_name" : "claudecf",
      "indices" : [ 0, 9 ],
      "id_str" : "607743",
      "id" : 607743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/QW8w6pDR",
      "expanded_url" : "http:\/\/750words.tumblr.com\/post\/40322046809\/the-future-of-750-words-please-read-and-reply",
      "display_url" : "750words.tumblr.com\/post\/403220468\u2026"
    }, {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/KWcXs05h",
      "expanded_url" : "http:\/\/750words.tumblr.com\/post\/42338373655\/the-plan-for-750-words",
      "display_url" : "750words.tumblr.com\/post\/423383736\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "299970531090890752",
  "geo" : { },
  "id_str" : "300006463861039105",
  "in_reply_to_user_id" : 607743,
  "text" : "@claudecf Details for the changes are here: http:\/\/t.co\/QW8w6pDR and a plan is here: http:\/\/t.co\/KWcXs05h",
  "id" : 300006463861039105,
  "in_reply_to_status_id" : 299970531090890752,
  "created_at" : "2013-02-08 22:21:29 +0000",
  "in_reply_to_screen_name" : "claudecf",
  "in_reply_to_user_id_str" : "607743",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Maberly",
      "screen_name" : "CMaberly",
      "indices" : [ 0, 9 ],
      "id_str" : "128375612",
      "id" : 128375612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299875174352822273",
  "geo" : { },
  "id_str" : "299958385535762432",
  "in_reply_to_user_id" : 128375612,
  "text" : "@CMaberly It increases the ability to do both, but in my opinion has a net gain on building. What do you think?",
  "id" : 299958385535762432,
  "in_reply_to_status_id" : 299875174352822273,
  "created_at" : "2013-02-08 19:10:26 +0000",
  "in_reply_to_screen_name" : "CMaberly",
  "in_reply_to_user_id_str" : "128375612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Zuckerberg",
      "screen_name" : "finkd",
      "indices" : [ 3, 9 ],
      "id_str" : "20749410",
      "id" : 20749410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299826219749355521",
  "text" : "RT @finkd: This is neat.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetdeck.com\/\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1260709608",
    "text" : "This is neat.",
    "id" : 1260709608,
    "created_at" : "2009-02-28 02:11:54 +0000",
    "user" : {
      "name" : "Mark Zuckerberg",
      "screen_name" : "finkd",
      "protected" : false,
      "id_str" : "20749410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/77846223\/profile_normal.jpg",
      "id" : 20749410,
      "verified" : false
    }
  },
  "id" : 299826219749355521,
  "created_at" : "2013-02-08 10:25:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Case",
      "screen_name" : "Case",
      "indices" : [ 0, 5 ],
      "id_str" : "409",
      "id" : 409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299733605993820161",
  "geo" : { },
  "id_str" : "299824057241698304",
  "in_reply_to_user_id" : 409,
  "text" : "@Case How are you? I haven't seen you in forever. Let's hang out!",
  "id" : 299824057241698304,
  "in_reply_to_status_id" : 299733605993820161,
  "created_at" : "2013-02-08 10:16:40 +0000",
  "in_reply_to_screen_name" : "Case",
  "in_reply_to_user_id_str" : "409",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299822118777024512",
  "in_reply_to_user_id" : 761628,
  "text" : "@rickwebb is pretty damn awesome, right?",
  "id" : 299822118777024512,
  "created_at" : "2013-02-08 10:08:58 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/FzDV3Zuw",
      "expanded_url" : "http:\/\/vine.co\/v\/bnxMB0jemIB",
      "display_url" : "vine.co\/v\/bnxMB0jemIB"
    } ]
  },
  "geo" : { },
  "id_str" : "299770510475141120",
  "text" : "Thieves! Assholes! http:\/\/t.co\/FzDV3Zuw",
  "id" : 299770510475141120,
  "created_at" : "2013-02-08 06:43:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 19, 26 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 27, 31 ],
      "id_str" : "259",
      "id" : 259
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 32, 42 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 43, 52 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Katie P",
      "screen_name" : "capitol_trouble",
      "indices" : [ 53, 69 ],
      "id_str" : "16063333",
      "id" : 16063333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/PvifJqYc",
      "expanded_url" : "http:\/\/flic.kr\/p\/dT57Dz",
      "display_url" : "flic.kr\/p\/dT57Dz"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.768166, -122.424501 ]
  },
  "id_str" : "299739428195299328",
  "text" : "8:36pm Dinner with @sharon @ian @kellianne @rickwebb @capitol_trouble at Mission Beach Cafe http:\/\/t.co\/PvifJqYc",
  "id" : 299739428195299328,
  "created_at" : "2013-02-08 04:40:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mailbox",
      "screen_name" : "mailbox",
      "indices" : [ 0, 8 ],
      "id_str" : "624947324",
      "id" : 624947324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299711890697904128",
  "geo" : { },
  "id_str" : "299712330919473153",
  "in_reply_to_user_id" : 624947324,
  "text" : "@mailbox The Verge's intro video claimed otherwise! Please say that was an error. :)",
  "id" : 299712330919473153,
  "in_reply_to_status_id" : 299711890697904128,
  "created_at" : "2013-02-08 02:52:42 +0000",
  "in_reply_to_screen_name" : "mailbox",
  "in_reply_to_user_id_str" : "624947324",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mailbox",
      "screen_name" : "mailbox",
      "indices" : [ 25, 33 ],
      "id_str" : "624947324",
      "id" : 624947324
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/299711384055324672\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/chXLtlMw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCjJ6nZCIAAOFu3.jpg",
      "id_str" : "299711384063713280",
      "id" : 299711384063713280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCjJ6nZCIAAOFu3.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com\/chXLtlMw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299711384055324672",
  "text" : "Excited to get access to @mailbox soon but worried that the lack of bulk archive might be a deal breaker for me. http:\/\/t.co\/chXLtlMw",
  "id" : 299711384055324672,
  "created_at" : "2013-02-08 02:48:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Kirkpatrick",
      "screen_name" : "marshallk",
      "indices" : [ 3, 13 ],
      "id_str" : "818340",
      "id" : 818340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 108 ],
      "url" : "https:\/\/t.co\/nRubOKTN",
      "expanded_url" : "https:\/\/twitter.com\/search?q=twttr%20until%3A2006-04-01&src=typd",
      "display_url" : "twitter.com\/search?q=twttr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299686145363689474",
  "text" : "RT @marshallk: Here's a fun search query in the new Twitter historical search function https:\/\/t.co\/nRubOKTN",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 93 ],
        "url" : "https:\/\/t.co\/nRubOKTN",
        "expanded_url" : "https:\/\/twitter.com\/search?q=twttr%20until%3A2006-04-01&src=typd",
        "display_url" : "twitter.com\/search?q=twttr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "299679273000787968",
    "text" : "Here's a fun search query in the new Twitter historical search function https:\/\/t.co\/nRubOKTN",
    "id" : 299679273000787968,
    "created_at" : "2013-02-08 00:41:21 +0000",
    "user" : {
      "name" : "Marshall Kirkpatrick",
      "screen_name" : "marshallk",
      "protected" : false,
      "id_str" : "818340",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459130034192515072\/BG5-NO9z_normal.png",
      "id" : 818340,
      "verified" : true
    }
  },
  "id" : 299686145363689474,
  "created_at" : "2013-02-08 01:08:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/ysjX5x1L",
      "expanded_url" : "http:\/\/bit.ly\/TRq8MA",
      "display_url" : "bit.ly\/TRq8MA"
    } ]
  },
  "geo" : { },
  "id_str" : "299685525495889921",
  "text" : "If you were ever annoyed that Twitter's search only showed the last week or so of tweets, things are getting better: http:\/\/t.co\/ysjX5x1L",
  "id" : 299685525495889921,
  "created_at" : "2013-02-08 01:06:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jairus Khan",
      "screen_name" : "JairusKhan",
      "indices" : [ 0, 11 ],
      "id_str" : "12337352",
      "id" : 12337352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299574976342786049",
  "geo" : { },
  "id_str" : "299581724663377921",
  "in_reply_to_user_id" : 12337352,
  "text" : "@JairusKhan I am considering something\u2026 not sure what form it will take yet.",
  "id" : 299581724663377921,
  "in_reply_to_status_id" : 299574976342786049,
  "created_at" : "2013-02-07 18:13:43 +0000",
  "in_reply_to_screen_name" : "JairusKhan",
  "in_reply_to_user_id_str" : "12337352",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrej Gregov",
      "screen_name" : "agregov",
      "indices" : [ 99, 107 ],
      "id_str" : "752413",
      "id" : 752413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/bIi0Izoy",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/andygreenberg\/2013\/02\/05\/inside-evasi0n-the-most-elaborate-jailbreak-to-ever-hack-your-iphone\/",
      "display_url" : "forbes.com\/sites\/andygree\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299559527022473218",
  "text" : "Want to know how the latest iPhone jailbreak works? It's a work of art.  http:\/\/t.co\/bIi0Izoy \/via @agregov",
  "id" : 299559527022473218,
  "created_at" : "2013-02-07 16:45:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299421227292966912",
  "geo" : { },
  "id_str" : "299424812177178624",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach Hey I might've turned up in that one.",
  "id" : 299424812177178624,
  "in_reply_to_status_id" : 299421227292966912,
  "created_at" : "2013-02-07 07:50:12 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299415123762741248",
  "geo" : { },
  "id_str" : "299419781642199040",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach Whatcha gonna graph search for?",
  "id" : 299419781642199040,
  "in_reply_to_status_id" : 299415123762741248,
  "created_at" : "2013-02-07 07:30:13 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/delectable-wine\/id512106648?mt=8&uo=4\" rel=\"nofollow\"\u003EDelectable Wine on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/wpJ0Akte",
      "expanded_url" : "http:\/\/del.ec\/xDg",
      "display_url" : "del.ec\/xDg"
    } ]
  },
  "geo" : { },
  "id_str" : "299398502860070912",
  "text" : "Celebrating our first overnight in the new house with this bottle we picked up in Tuscany yum http:\/\/t.co\/wpJ0Akte",
  "id" : 299398502860070912,
  "created_at" : "2013-02-07 06:05:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/wWMgs4t2",
      "expanded_url" : "http:\/\/vine.co\/v\/bnH9Qbxube0",
      "display_url" : "vine.co\/v\/bnH9Qbxube0"
    } ]
  },
  "geo" : { },
  "id_str" : "299392593333219328",
  "text" : "Our heater http:\/\/t.co\/wWMgs4t2",
  "id" : 299392593333219328,
  "created_at" : "2013-02-07 05:42:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    }, {
      "name" : "michele banko",
      "screen_name" : "mbanko",
      "indices" : [ 12, 19 ],
      "id_str" : "86397270",
      "id" : 86397270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299377591897423872",
  "geo" : { },
  "id_str" : "299384287642386432",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold @mbanko Yup! We go way back! And mates = mantra, I don't even think that was autocorrect's fault.",
  "id" : 299384287642386432,
  "in_reply_to_status_id" : 299377591897423872,
  "created_at" : "2013-02-07 05:09:11 +0000",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299376693607530496",
  "geo" : { },
  "id_str" : "299377136261808128",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling Happy birthday, Megan! We miss you!",
  "id" : 299377136261808128,
  "in_reply_to_status_id" : 299376693607530496,
  "created_at" : "2013-02-07 04:40:46 +0000",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/k9wp2vBv",
      "expanded_url" : "http:\/\/flic.kr\/p\/dSWiFG",
      "display_url" : "flic.kr\/p\/dSWiFG"
    } ]
  },
  "geo" : { },
  "id_str" : "299376638603452416",
  "text" : "8:36pm First overnight in our new place! Our cool new dresser from Alameda Flea Market also arrived. http:\/\/t.co\/k9wp2vBv",
  "id" : 299376638603452416,
  "created_at" : "2013-02-07 04:38:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michele banko",
      "screen_name" : "mbanko",
      "indices" : [ 0, 7 ],
      "id_str" : "86397270",
      "id" : 86397270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299367723186679808",
  "geo" : { },
  "id_str" : "299374722204983297",
  "in_reply_to_user_id" : 86397270,
  "text" : "@mbanko Ha, little did I know how effective the mates would be. How are you?????",
  "id" : 299374722204983297,
  "in_reply_to_status_id" : 299367723186679808,
  "created_at" : "2013-02-07 04:31:10 +0000",
  "in_reply_to_screen_name" : "mbanko",
  "in_reply_to_user_id_str" : "86397270",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/sPXnGRN3",
      "expanded_url" : "http:\/\/vine.co\/v\/bnHmD1iB7zg",
      "display_url" : "vine.co\/v\/bnHmD1iB7zg"
    } ]
  },
  "geo" : { },
  "id_str" : "299368054905782273",
  "text" : "One-legged Flinstone stridering http:\/\/t.co\/sPXnGRN3",
  "id" : 299368054905782273,
  "created_at" : "2013-02-07 04:04:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Morga",
      "screen_name" : "AliciaMorga",
      "indices" : [ 0, 12 ],
      "id_str" : "19053875",
      "id" : 19053875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299262472676835328",
  "geo" : { },
  "id_str" : "299302555551408128",
  "in_reply_to_user_id" : 19053875,
  "text" : "@AliciaMorga I love sheep\/wolf thought too! How have you been? Would love to catch up with you again\u2026 I'm officially moved down here now.",
  "id" : 299302555551408128,
  "in_reply_to_status_id" : 299262472676835328,
  "created_at" : "2013-02-06 23:44:24 +0000",
  "in_reply_to_screen_name" : "AliciaMorga",
  "in_reply_to_user_id_str" : "19053875",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "indices" : [ 14, 27 ],
      "id_str" : "1186",
      "id" : 1186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/6G7nKgIy",
      "expanded_url" : "http:\/\/flic.kr\/p\/5bdL8r",
      "display_url" : "flic.kr\/p\/5bdL8r"
    } ]
  },
  "in_reply_to_status_id_str" : "299185830747058178",
  "geo" : { },
  "id_str" : "299190888083640321",
  "in_reply_to_user_id" : 1186,
  "text" : "Good times RT @chrismessina: \"How hashtags are born\" infographic from a year after I proposed them: http:\/\/t.co\/6G7nKgIy",
  "id" : 299190888083640321,
  "in_reply_to_status_id" : 299185830747058178,
  "created_at" : "2013-02-06 16:20:41 +0000",
  "in_reply_to_screen_name" : "chrismessina",
  "in_reply_to_user_id_str" : "1186",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. T",
      "screen_name" : "MrT",
      "indices" : [ 3, 7 ],
      "id_str" : "472872558",
      "id" : 472872558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299189584259055616",
  "text" : "RT @MrT: Tweet your mother right!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299176814981558272",
    "text" : "Tweet your mother right!",
    "id" : 299176814981558272,
    "created_at" : "2013-02-06 15:24:45 +0000",
    "user" : {
      "name" : "Mr. T",
      "screen_name" : "MrT",
      "protected" : false,
      "id_str" : "472872558",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3160816489\/a0bbfcd09d9b7dbc56b76a07130972cf_normal.png",
      "id" : 472872558,
      "verified" : true
    }
  },
  "id" : 299189584259055616,
  "created_at" : "2013-02-06 16:15:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mina",
      "screen_name" : "minarad",
      "indices" : [ 0, 8 ],
      "id_str" : "14296102",
      "id" : 14296102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299019979599265794",
  "geo" : { },
  "id_str" : "299027314048651264",
  "in_reply_to_user_id" : 14296102,
  "text" : "@minarad We were inside. Was there a doppelg\u00E4nger? :)",
  "id" : 299027314048651264,
  "in_reply_to_status_id" : 299019979599265794,
  "created_at" : "2013-02-06 05:30:41 +0000",
  "in_reply_to_screen_name" : "minarad",
  "in_reply_to_user_id_str" : "14296102",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bar Agricole",
      "screen_name" : "baragricole",
      "indices" : [ 9, 21 ],
      "id_str" : "116125324",
      "id" : 116125324
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 25, 35 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/pAZpqrry",
      "expanded_url" : "http:\/\/4sq.com\/VCPcnb",
      "display_url" : "4sq.com\/VCPcnb"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.771362, -122.412966 ]
  },
  "id_str" : "299016662097747968",
  "text" : "Yum. (at @baragricole w\/ @kellianne) http:\/\/t.co\/pAZpqrry",
  "id" : 299016662097747968,
  "created_at" : "2013-02-06 04:48:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/aQ5iZuxh",
      "expanded_url" : "http:\/\/flic.kr\/p\/dSFZVh",
      "display_url" : "flic.kr\/p\/dSFZVh"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.771499, -122.413001 ]
  },
  "id_str" : "299014285022068736",
  "text" : "8:36pm Dinner with new+old friends at Bar Agricole http:\/\/t.co\/aQ5iZuxh",
  "id" : 299014285022068736,
  "created_at" : "2013-02-06 04:38:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Lacy",
      "screen_name" : "sarahcuda",
      "indices" : [ 29, 39 ],
      "id_str" : "5668942",
      "id" : 5668942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/kJDRYKSe",
      "expanded_url" : "http:\/\/pandodaily.com\/2013\/02\/05\/how-snapchat-took-over-yale\/",
      "display_url" : "pandodaily.com\/2013\/02\/05\/how\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "298960771692511232",
  "geo" : { },
  "id_str" : "298990018687545344",
  "in_reply_to_user_id" : 5668942,
  "text" : "Relevant to my interests! RT @sarahcuda: How Snapchat took over Yale http:\/\/t.co\/kJDRYKSe",
  "id" : 298990018687545344,
  "in_reply_to_status_id" : 298960771692511232,
  "created_at" : "2013-02-06 03:02:30 +0000",
  "in_reply_to_screen_name" : "sarahcuda",
  "in_reply_to_user_id_str" : "5668942",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 3, 11 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Deb Roy",
      "screen_name" : "dkroy",
      "indices" : [ 14, 20 ],
      "id_str" : "30569817",
      "id" : 30569817
    }, {
      "name" : "Bluefin Labs",
      "screen_name" : "bluefinlabs",
      "indices" : [ 29, 41 ],
      "id_str" : "176646124",
      "id" : 176646124
    }, {
      "name" : "TED Talks",
      "screen_name" : "TEDTalks",
      "indices" : [ 72, 81 ],
      "id_str" : "15492359",
      "id" : 15492359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/JxhPxG2O",
      "expanded_url" : "http:\/\/www.ted.com\/talks\/deb_roy_the_birth_of_a_word.html",
      "display_url" : "ted.com\/talks\/deb_roy_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298989199313498112",
  "text" : "RT @rsarver: .@dkroy, CEO of @bluefinlabs, also gave one of my favorite @TEDTalks ever about how his son learned how to speak http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Deb Roy",
        "screen_name" : "dkroy",
        "indices" : [ 1, 7 ],
        "id_str" : "30569817",
        "id" : 30569817
      }, {
        "name" : "Bluefin Labs",
        "screen_name" : "bluefinlabs",
        "indices" : [ 16, 28 ],
        "id_str" : "176646124",
        "id" : 176646124
      }, {
        "name" : "TED Talks",
        "screen_name" : "TEDTalks",
        "indices" : [ 59, 68 ],
        "id_str" : "15492359",
        "id" : 15492359
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/JxhPxG2O",
        "expanded_url" : "http:\/\/www.ted.com\/talks\/deb_roy_the_birth_of_a_word.html",
        "display_url" : "ted.com\/talks\/deb_roy_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "298959436964302850",
    "text" : ".@dkroy, CEO of @bluefinlabs, also gave one of my favorite @TEDTalks ever about how his son learned how to speak http:\/\/t.co\/JxhPxG2O",
    "id" : 298959436964302850,
    "created_at" : "2013-02-06 01:00:58 +0000",
    "user" : {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "protected" : false,
      "id_str" : "795649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3015419114\/3dc096c48ef6167d1b26fd0d6b01814d_normal.jpeg",
      "id" : 795649,
      "verified" : false
    }
  },
  "id" : 298989199313498112,
  "created_at" : "2013-02-06 02:59:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Deb Roy",
      "screen_name" : "dkroy",
      "indices" : [ 58, 64 ],
      "id_str" : "30569817",
      "id" : 30569817
    }, {
      "name" : "Bluefin Labs",
      "screen_name" : "bluefinlabs",
      "indices" : [ 77, 89 ],
      "id_str" : "176646124",
      "id" : 176646124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298959436964302850",
  "geo" : { },
  "id_str" : "298986396218187777",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver Woah that's one of my favorites too! Had no idea @dkroy was part of @bluefinlabs... that's awesome!",
  "id" : 298986396218187777,
  "in_reply_to_status_id" : 298959436964302850,
  "created_at" : "2013-02-06 02:48:06 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gallagher",
      "screen_name" : "necolas",
      "indices" : [ 0, 8 ],
      "id_str" : "24974216",
      "id" : 24974216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298941058404974592",
  "geo" : { },
  "id_str" : "298978157162295296",
  "in_reply_to_user_id" : 24974216,
  "text" : "@necolas Ouch.",
  "id" : 298978157162295296,
  "in_reply_to_status_id" : 298941058404974592,
  "created_at" : "2013-02-06 02:15:22 +0000",
  "in_reply_to_screen_name" : "necolas",
  "in_reply_to_user_id_str" : "24974216",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Aza Raskin",
      "screen_name" : "aza",
      "indices" : [ 11, 15 ],
      "id_str" : "13370272",
      "id" : 13370272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298873781068386305",
  "geo" : { },
  "id_str" : "298873943002066944",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates @aza Yeah, it should all be background, but after a few days I noticed my phone dying significantly earlier than usual.",
  "id" : 298873943002066944,
  "in_reply_to_status_id" : 298873781068386305,
  "created_at" : "2013-02-05 19:21:15 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Aza Raskin",
      "screen_name" : "aza",
      "indices" : [ 11, 15 ],
      "id_str" : "13370272",
      "id" : 13370272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298873221866999808",
  "geo" : { },
  "id_str" : "298873657948770305",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates @aza I love it too but unfortunately the battery drain is pretty severe.",
  "id" : 298873657948770305,
  "in_reply_to_status_id" : 298873221866999808,
  "created_at" : "2013-02-05 19:20:07 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298863054626648064",
  "text" : "@MikeSkyler Email me at buster@twitter.com and I'll explain how to go about it.",
  "id" : 298863054626648064,
  "created_at" : "2013-02-05 18:37:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298859534204690432",
  "text" : "@MikeSkyler Sure, what's the problem?",
  "id" : 298859534204690432,
  "created_at" : "2013-02-05 18:24:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrei Pop",
      "screen_name" : "andreimpop",
      "indices" : [ 0, 11 ],
      "id_str" : "82801305",
      "id" : 82801305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298662280101502976",
  "geo" : { },
  "id_str" : "298845732293718017",
  "in_reply_to_user_id" : 82801305,
  "text" : "@andreimpop I live in SF now! Are you ever near the Twitter office (Civic Center Bart stop) around coffee time? :)",
  "id" : 298845732293718017,
  "in_reply_to_status_id" : 298662280101502976,
  "created_at" : "2013-02-05 17:29:09 +0000",
  "in_reply_to_screen_name" : "andreimpop",
  "in_reply_to_user_id_str" : "82801305",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/iWDeg4yD",
      "expanded_url" : "http:\/\/flic.kr\/p\/dSm1Xn",
      "display_url" : "flic.kr\/p\/dSm1Xn"
    } ]
  },
  "geo" : { },
  "id_str" : "298660453670862848",
  "text" : "8:36pm Listening to Niko narrate a story about ducks who got lost on the way home http:\/\/t.co\/iWDeg4yD",
  "id" : 298660453670862848,
  "created_at" : "2013-02-05 05:12:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Anderson",
      "screen_name" : "chr1sa",
      "indices" : [ 3, 10 ],
      "id_str" : "17595439",
      "id" : 17595439
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 87, 96 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/eHZmMIrt",
      "expanded_url" : "http:\/\/dashes.com\/anil\/2013\/02\/the-world-is-getting-better-quickly.html",
      "display_url" : "dashes.com\/anil\/2013\/02\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298561906577403904",
  "text" : "RT @chr1sa: The World is Getting Better. Quickly. - Anil Dash http:\/\/t.co\/eHZmMIrt via @anildash",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anil Dash",
        "screen_name" : "anildash",
        "indices" : [ 75, 84 ],
        "id_str" : "36823",
        "id" : 36823
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/eHZmMIrt",
        "expanded_url" : "http:\/\/dashes.com\/anil\/2013\/02\/the-world-is-getting-better-quickly.html",
        "display_url" : "dashes.com\/anil\/2013\/02\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "298555557663608832",
    "text" : "The World is Getting Better. Quickly. - Anil Dash http:\/\/t.co\/eHZmMIrt via @anildash",
    "id" : 298555557663608832,
    "created_at" : "2013-02-04 22:16:06 +0000",
    "user" : {
      "name" : "Chris Anderson",
      "screen_name" : "chr1sa",
      "protected" : false,
      "id_str" : "17595439",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000034395983\/18ce4b3eb08868f444a2596942dcb7af_normal.jpeg",
      "id" : 17595439,
      "verified" : true
    }
  },
  "id" : 298561906577403904,
  "created_at" : "2013-02-04 22:41:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298529764392710145",
  "geo" : { },
  "id_str" : "298529949919363076",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell Awesome, I started on the week of my 6th anniversary too!",
  "id" : 298529949919363076,
  "in_reply_to_status_id" : 298529764392710145,
  "created_at" : "2013-02-04 20:34:21 +0000",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "indices" : [ 62, 73 ],
      "id_str" : "419710142",
      "id" : 419710142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 139 ],
      "url" : "https:\/\/t.co\/AydSxrbF",
      "expanded_url" : "https:\/\/pandodaily.wordpress.com\/2013\/02\/04\/how-twitter-is-changing-news-as-we-know-it\/",
      "display_url" : "pandodaily.wordpress.com\/2013\/02\/04\/how\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "298443710948069377",
  "geo" : { },
  "id_str" : "298475582608510976",
  "in_reply_to_user_id" : 419710142,
  "text" : "News outlets can shift focus to fact-checking the firehose RT @PandoDaily: How Twitter is changing news as we know it https:\/\/t.co\/AydSxrbF",
  "id" : 298475582608510976,
  "in_reply_to_status_id" : 298443710948069377,
  "created_at" : "2013-02-04 16:58:18 +0000",
  "in_reply_to_screen_name" : "PandoDaily",
  "in_reply_to_user_id_str" : "419710142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/E24FriU0",
      "expanded_url" : "http:\/\/tomtunguz.com\/feynman-and-fomo",
      "display_url" : "tomtunguz.com\/feynman-and-fo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298466746648653825",
  "text" : "Num dishes to try at a restaurant before setting on a favorite = \u221A2(Meals remaining at restaurant + 1) - 1 \n\nhttp:\/\/t.co\/E24FriU0",
  "id" : 298466746648653825,
  "created_at" : "2013-02-04 16:23:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Watson",
      "screen_name" : "paulmwatson",
      "indices" : [ 0, 12 ],
      "id_str" : "11214",
      "id" : 11214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298339774756945920",
  "geo" : { },
  "id_str" : "298343545469820929",
  "in_reply_to_user_id" : 11214,
  "text" : "@paulmwatson Anything with creative merit\/world-improving vision? I just wish advertising was more pitch-like vs dumb entertainment.",
  "id" : 298343545469820929,
  "in_reply_to_status_id" : 298339774756945920,
  "created_at" : "2013-02-04 08:13:38 +0000",
  "in_reply_to_screen_name" : "paulmwatson",
  "in_reply_to_user_id_str" : "11214",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298327640111198208",
  "text" : "The best advertising minds of my generation are thinking about how to make people... buy cars?",
  "id" : 298327640111198208,
  "created_at" : "2013-02-04 07:10:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/VN7eLTvS",
      "expanded_url" : "http:\/\/vine.co\/v\/b12VLZT53Jm",
      "display_url" : "vine.co\/v\/b12VLZT53Jm"
    } ]
  },
  "geo" : { },
  "id_str" : "298230035259719681",
  "text" : "Sunny bowl party http:\/\/t.co\/VN7eLTvS",
  "id" : 298230035259719681,
  "created_at" : "2013-02-04 00:42:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 36, 47 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/wYJalbvj",
      "expanded_url" : "http:\/\/vine.co\/v\/b1xw7vP5H1n",
      "display_url" : "vine.co\/v\/b1xw7vP5H1n"
    } ]
  },
  "geo" : { },
  "id_str" : "298151655684337665",
  "text" : "In case you were wondering how tall @nikobenson is http:\/\/t.co\/wYJalbvj",
  "id" : 298151655684337665,
  "created_at" : "2013-02-03 19:31:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Knauss",
      "screen_name" : "gknauss",
      "indices" : [ 3, 11 ],
      "id_str" : "3163591",
      "id" : 3163591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298133088305807361",
  "text" : "RT @gknauss: Live by the gun, die by the gun.\n\nGo to work, die by the gun. Attend school, die by the gun. See a movie, die by the gun.\n\nEtc.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298125885188497409",
    "text" : "Live by the gun, die by the gun.\n\nGo to work, die by the gun. Attend school, die by the gun. See a movie, die by the gun.\n\nEtc.",
    "id" : 298125885188497409,
    "created_at" : "2013-02-03 17:48:44 +0000",
    "user" : {
      "name" : "Greg Knauss",
      "screen_name" : "gknauss",
      "protected" : false,
      "id_str" : "3163591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/38137892\/greg-icon-128_normal.gif",
      "id" : 3163591,
      "verified" : false
    }
  },
  "id" : 298133088305807361,
  "created_at" : "2013-02-03 18:17:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xeni Jardin",
      "screen_name" : "xeni",
      "indices" : [ 3, 8 ],
      "id_str" : "767",
      "id" : 767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298082381431201793",
  "text" : "RT @xeni: \u2728\uD83C\uDF1CSuperb Owl \uD83C\uDF1B\u2728",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298079150160367616",
    "text" : "\u2728\uD83C\uDF1CSuperb Owl \uD83C\uDF1B\u2728",
    "id" : 298079150160367616,
    "created_at" : "2013-02-03 14:43:02 +0000",
    "user" : {
      "name" : "Xeni Jardin",
      "screen_name" : "xeni",
      "protected" : false,
      "id_str" : "767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461599487866044416\/b-84ZSil_normal.jpeg",
      "id" : 767,
      "verified" : true
    }
  },
  "id" : 298082381431201793,
  "created_at" : "2013-02-03 14:55:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Wallin",
      "screen_name" : "joewallin",
      "indices" : [ 3, 13 ],
      "id_str" : "14857106",
      "id" : 14857106
    }, {
      "name" : "HackerNode App",
      "screen_name" : "hackernodeapp",
      "indices" : [ 75, 89 ],
      "id_str" : "504039372",
      "id" : 504039372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/2EVC9YLt",
      "expanded_url" : "http:\/\/www.giantfreakinrobot.com\/sci\/neil-degrasse-tyson-suggests-books-intelligent-person-read.html",
      "display_url" : "giantfreakinrobot.com\/sci\/neil-degra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297982702513160192",
  "text" : "RT @joewallin: Neil DeGrasse Tyson\u2019s Eight Books Everyone Should Read (via @hackernodeapp) http:\/\/t.co\/2EVC9YLt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/hackernode\/id473882597?mt=8&uo=4\" rel=\"nofollow\"\u003EHackerNode on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HackerNode App",
        "screen_name" : "hackernodeapp",
        "indices" : [ 60, 74 ],
        "id_str" : "504039372",
        "id" : 504039372
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/2EVC9YLt",
        "expanded_url" : "http:\/\/www.giantfreakinrobot.com\/sci\/neil-degrasse-tyson-suggests-books-intelligent-person-read.html",
        "display_url" : "giantfreakinrobot.com\/sci\/neil-degra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "297968867928600576",
    "text" : "Neil DeGrasse Tyson\u2019s Eight Books Everyone Should Read (via @hackernodeapp) http:\/\/t.co\/2EVC9YLt",
    "id" : 297968867928600576,
    "created_at" : "2013-02-03 07:24:48 +0000",
    "user" : {
      "name" : "Joe Wallin",
      "screen_name" : "joewallin",
      "protected" : false,
      "id_str" : "14857106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1455439273\/JoeWallin_blogphoto_72_normal.jpg",
      "id" : 14857106,
      "verified" : false
    }
  },
  "id" : 297982702513160192,
  "created_at" : "2013-02-03 08:19:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297940037046243328",
  "text" : "Is anyone trying to get rid of a simple, well-made wardrobe. It doesn't need to be very large, I don't have much clothes.",
  "id" : 297940037046243328,
  "created_at" : "2013-02-03 05:30:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/a08GkpWw",
      "expanded_url" : "http:\/\/flic.kr\/p\/dRKYDp",
      "display_url" : "flic.kr\/p\/dRKYDp"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.787833, -122.391834 ]
  },
  "id_str" : "297938682726453248",
  "text" : "8:36pm Spending the day in IKEA-land makes me extra uninterested in IKEA things. http:\/\/t.co\/a08GkpWw",
  "id" : 297938682726453248,
  "created_at" : "2013-02-03 05:24:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IKEA_Emeryville",
      "screen_name" : "IKEA_Emeryville",
      "indices" : [ 27, 43 ],
      "id_str" : "300403333",
      "id" : 300403333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/xwPejlAJ",
      "expanded_url" : "http:\/\/4sq.com\/TrO8FZ",
      "display_url" : "4sq.com\/TrO8FZ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8310056091, -122.2923803329 ]
  },
  "id_str" : "297834038016741376",
  "text" : "Now this is happening. (at @ikea_emeryville w\/ 13 others) http:\/\/t.co\/xwPejlAJ",
  "id" : 297834038016741376,
  "created_at" : "2013-02-02 22:29:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 0, 4 ],
      "id_str" : "259",
      "id" : 259
    }, {
      "name" : "Dane Jasper",
      "screen_name" : "dane",
      "indices" : [ 5, 10 ],
      "id_str" : "7575072",
      "id" : 7575072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297821607789993985",
  "geo" : { },
  "id_str" : "297822756655992832",
  "in_reply_to_user_id" : 259,
  "text" : "@ian @dane Just signed up!",
  "id" : 297822756655992832,
  "in_reply_to_status_id" : 297821607789993985,
  "created_at" : "2013-02-02 21:44:13 +0000",
  "in_reply_to_screen_name" : "ian",
  "in_reply_to_user_id_str" : "259",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 0, 4 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297818620258574337",
  "geo" : { },
  "id_str" : "297819812086812672",
  "in_reply_to_user_id" : 259,
  "text" : "@ian Awesome. Just the rec I needed! Do they require a land line?",
  "id" : 297819812086812672,
  "in_reply_to_status_id" : 297818620258574337,
  "created_at" : "2013-02-02 21:32:31 +0000",
  "in_reply_to_screen_name" : "ian",
  "in_reply_to_user_id_str" : "259",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297814604417990659",
  "text" : "What's the best Internet provider for residences in Berkeley?",
  "id" : 297814604417990659,
  "created_at" : "2013-02-02 21:11:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297807331268374528",
  "geo" : { },
  "id_str" : "297811619638042624",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Definitely takes some adjustment. Berkeley feels like a big Ballard.",
  "id" : 297811619638042624,
  "in_reply_to_status_id" : 297807331268374528,
  "created_at" : "2013-02-02 20:59:57 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297806349297938432",
  "geo" : { },
  "id_str" : "297806706677792768",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel they crack me up.",
  "id" : 297806706677792768,
  "in_reply_to_status_id" : 297806349297938432,
  "created_at" : "2013-02-02 20:40:26 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pentametron",
      "screen_name" : "pentametron",
      "indices" : [ 75, 87 ],
      "id_str" : "516047986",
      "id" : 516047986
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/297804922706079744\/photo\/1",
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/cDLSOyz1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCID_9bCMAA-LYQ.jpg",
      "id_str" : "297804922714468352",
      "id" : 297804922714468352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCID_9bCMAA-LYQ.jpg",
      "sizes" : [ {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/cDLSOyz1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297804922706079744",
  "text" : "\"I'm gonna turn into a pizza roll \/ How many hours til the Puppy Bowl?!\" - @pentametron http:\/\/t.co\/cDLSOyz1",
  "id" : 297804922706079744,
  "created_at" : "2013-02-02 20:33:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "berkeleybowlproblems",
      "indices" : [ 52, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297799305807425536",
  "text" : "OH \"Carrot chips? Are they dried or what the hell?\" #berkeleybowlproblems",
  "id" : 297799305807425536,
  "created_at" : "2013-02-02 20:11:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/0jW5qOVx",
      "expanded_url" : "http:\/\/4sq.com\/YLjeev",
      "display_url" : "4sq.com\/YLjeev"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.857178, -122.267337 ]
  },
  "id_str" : "297795501510758400",
  "text" : "Apparently it's a whole scene. (@ Berkeley Bowl) http:\/\/t.co\/0jW5qOVx",
  "id" : 297795501510758400,
  "created_at" : "2013-02-02 19:55:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297792263944278017",
  "text" : "3-way Berkeley Bowl parking lot battle. Just happened.",
  "id" : 297792263944278017,
  "created_at" : "2013-02-02 19:43:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/runkeeper.com\" rel=\"nofollow\"\u003ERunKeeper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gettingbetter",
      "indices" : [ 58, 72 ]
    }, {
      "text" : "RunKeeper",
      "indices" : [ 95, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/UfmAsUkg",
      "expanded_url" : "http:\/\/rnkpr.com\/a2f4ef9",
      "display_url" : "rnkpr.com\/a2f4ef9"
    } ]
  },
  "geo" : { },
  "id_str" : "297779696748339200",
  "text" : "Just posted a 3.50 mi run - Felt knee but wasn't painful. #gettingbetter. http:\/\/t.co\/UfmAsUkg #RunKeeper",
  "id" : 297779696748339200,
  "created_at" : "2013-02-02 18:53:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Campbell",
      "screen_name" : "coryjcampbell",
      "indices" : [ 0, 14 ],
      "id_str" : "54029411",
      "id" : 54029411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297756953915043840",
  "geo" : { },
  "id_str" : "297757313165586433",
  "in_reply_to_user_id" : 54029411,
  "text" : "@coryjcampbell It currently only goes back something like 7 days. A known terrible experience.",
  "id" : 297757313165586433,
  "in_reply_to_status_id" : 297756953915043840,
  "created_at" : "2013-02-02 17:24:10 +0000",
  "in_reply_to_screen_name" : "coryjcampbell",
  "in_reply_to_user_id_str" : "54029411",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297746277251301378",
  "geo" : { },
  "id_str" : "297746400442212352",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Yes!!!",
  "id" : 297746400442212352,
  "in_reply_to_status_id" : 297746277251301378,
  "created_at" : "2013-02-02 16:40:48 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "indices" : [ 0, 8 ],
      "id_str" : "6825792",
      "id" : 6825792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297745140376801281",
  "geo" : { },
  "id_str" : "297745989815631872",
  "in_reply_to_user_id" : 6825792,
  "text" : "@ibogost They are a repeat, and unapologetic, offender. Pretty lame.",
  "id" : 297745989815631872,
  "in_reply_to_status_id" : 297745140376801281,
  "created_at" : "2013-02-02 16:39:10 +0000",
  "in_reply_to_screen_name" : "ibogost",
  "in_reply_to_user_id_str" : "6825792",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chrizito",
      "screen_name" : "chrizito",
      "indices" : [ 0, 9 ],
      "id_str" : "16954777",
      "id" : 16954777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297740402671382531",
  "geo" : { },
  "id_str" : "297741461196263425",
  "in_reply_to_user_id" : 16954777,
  "text" : "@chrizito Q",
  "id" : 297741461196263425,
  "in_reply_to_status_id" : 297740402671382531,
  "created_at" : "2013-02-02 16:21:10 +0000",
  "in_reply_to_screen_name" : "chrizito",
  "in_reply_to_user_id_str" : "16954777",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Foxman",
      "screen_name" : "ArielFoxman",
      "indices" : [ 3, 15 ],
      "id_str" : "53152678",
      "id" : 53152678
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297740064249761792",
  "text" : "RT @arielfoxman: I saw my shadow today. And it said hit the gym before spring.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297729963321327617",
    "text" : "I saw my shadow today. And it said hit the gym before spring.",
    "id" : 297729963321327617,
    "created_at" : "2013-02-02 15:35:29 +0000",
    "user" : {
      "name" : "Ariel Foxman",
      "screen_name" : "ArielFoxman",
      "protected" : false,
      "id_str" : "53152678",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3317415196\/8bd82012a74d8c47623ac85859515f2f_normal.jpeg",
      "id" : 53152678,
      "verified" : true
    }
  },
  "id" : 297740064249761792,
  "created_at" : "2013-02-02 16:15:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 57, 64 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "indices" : [ 111, 114 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 136 ],
      "url" : "https:\/\/t.co\/o7Sf7Dvd",
      "expanded_url" : "https:\/\/medium.com\/frontpage-picks\/a28e7282916b",
      "display_url" : "medium.com\/frontpage-pick\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "297726183083212801",
  "geo" : { },
  "id_str" : "297739833575624704",
  "in_reply_to_user_id" : 571202103,
  "text" : "Naming products\/companies is the perfect creative act RT @Medium: \"Nomgoose: The Product that Named Itself\" by @ev https:\/\/t.co\/o7Sf7Dvd",
  "id" : 297739833575624704,
  "in_reply_to_status_id" : 297726183083212801,
  "created_at" : "2013-02-02 16:14:42 +0000",
  "in_reply_to_screen_name" : "Medium",
  "in_reply_to_user_id_str" : "571202103",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297705400772468740",
  "geo" : { },
  "id_str" : "297733692464455681",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Slowly over the next week or so since we have our temp place til the 20th.",
  "id" : 297733692464455681,
  "in_reply_to_status_id" : 297705400772468740,
  "created_at" : "2013-02-02 15:50:18 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/JxL5s4CS",
      "expanded_url" : "http:\/\/flic.kr\/p\/dRB5df",
      "display_url" : "flic.kr\/p\/dRB5df"
    } ]
  },
  "geo" : { },
  "id_str" : "297598637096189952",
  "text" : "8:36pm Making lists of things we need to buy, sell, and trash for our new place. http:\/\/t.co\/JxL5s4CS",
  "id" : 297598637096189952,
  "created_at" : "2013-02-02 06:53:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/5X977goP",
      "expanded_url" : "http:\/\/vine.co\/v\/b11EbWE32b9",
      "display_url" : "vine.co\/v\/b11EbWE32b9"
    } ]
  },
  "geo" : { },
  "id_str" : "297530307786207232",
  "text" : "McGee and Stuart http:\/\/t.co\/5X977goP",
  "id" : 297530307786207232,
  "created_at" : "2013-02-02 02:22:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kay Vreeland",
      "screen_name" : "cay_anchor",
      "indices" : [ 0, 11 ],
      "id_str" : "16275525",
      "id" : 16275525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297412598897459200",
  "geo" : { },
  "id_str" : "297415971692482560",
  "in_reply_to_user_id" : 16275525,
  "text" : "@cay_anchor Coming soon\u2026. dun dun dun! (but the short answer is we'll be moving to a pay-only site with a free trial period).",
  "id" : 297415971692482560,
  "in_reply_to_status_id" : 297412598897459200,
  "created_at" : "2013-02-01 18:47:48 +0000",
  "in_reply_to_screen_name" : "cay_anchor",
  "in_reply_to_user_id_str" : "16275525",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 0, 6 ],
      "id_str" : "15310552",
      "id" : 15310552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297175594897117184",
  "geo" : { },
  "id_str" : "297404327977447424",
  "in_reply_to_user_id" : 15310552,
  "text" : "@singy Woah, awesome!",
  "id" : 297404327977447424,
  "in_reply_to_status_id" : 297175594897117184,
  "created_at" : "2013-02-01 18:01:31 +0000",
  "in_reply_to_screen_name" : "singy",
  "in_reply_to_user_id_str" : "15310552",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/cBnMP6ZE",
      "expanded_url" : "http:\/\/bit.ly\/XNBTQ6",
      "display_url" : "bit.ly\/XNBTQ6"
    } ]
  },
  "geo" : { },
  "id_str" : "297380613009326082",
  "text" : "Rabbit, rabbit! http:\/\/t.co\/cBnMP6ZE",
  "id" : 297380613009326082,
  "created_at" : "2013-02-01 16:27:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/lift.do\" rel=\"nofollow\"\u003EL I F T\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 40, 48 ],
      "id_str" : "353195232",
      "id" : 353195232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/nqtERf0s",
      "expanded_url" : "http:\/\/lift.do\/c\/3118425",
      "display_url" : "lift.do\/c\/3118425"
    } ]
  },
  "geo" : { },
  "id_str" : "297378100113723392",
  "text" : "I just checked in to morning routine on @liftapp: \"Changed the name of my goal to be something more people are o... http:\/\/t.co\/nqtERf0s",
  "id" : 297378100113723392,
  "created_at" : "2013-02-01 16:17:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]