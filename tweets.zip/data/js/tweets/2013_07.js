Grailbird.data.tweets_2013_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 0, 10 ],
      "id_str" : "125733",
      "id" : 125733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362792018038108162",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859645867, -122.2754925875 ]
  },
  "id_str" : "362798321397530624",
  "in_reply_to_user_id" : 125733,
  "text" : "@JohnWrede LOVE it.",
  "id" : 362798321397530624,
  "in_reply_to_status_id" : 362792018038108162,
  "created_at" : "2013-08-01 04:53:54 +0000",
  "in_reply_to_screen_name" : "JohnWrede",
  "in_reply_to_user_id_str" : "125733",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/pmJ3OjLZEz",
      "expanded_url" : "http:\/\/flic.kr\/p\/fkCzZZ",
      "display_url" : "flic.kr\/p\/fkCzZZ"
    } ]
  },
  "geo" : { },
  "id_str" : "362785104382267393",
  "text" : "8:36pm Exhausted. Ready for some Orange Is the New Black. http:\/\/t.co\/pmJ3OjLZEz",
  "id" : 362785104382267393,
  "created_at" : "2013-08-01 04:01:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriemTeam",
      "screen_name" : "TriemTeam",
      "indices" : [ 0, 10 ],
      "id_str" : "24792603",
      "id" : 24792603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362746431448170499",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8287252148, -122.2659002171 ]
  },
  "id_str" : "362748466394443777",
  "in_reply_to_user_id" : 24792603,
  "text" : "@TriemTeam True. I used that a lot but often only after trying to guess... which is the slowest of all possible worlds.",
  "id" : 362748466394443777,
  "in_reply_to_status_id" : 362746431448170499,
  "created_at" : "2013-08-01 01:35:48 +0000",
  "in_reply_to_screen_name" : "TriemTeam",
  "in_reply_to_user_id_str" : "24792603",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362747664229597185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8181326416, -122.269463295 ]
  },
  "id_str" : "362748426401751040",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Do you have any folders at all? Seems like an impossible task to organize by icon in an easily scannable way.",
  "id" : 362748426401751040,
  "in_reply_to_status_id" : 362747664229597185,
  "created_at" : "2013-08-01 01:35:39 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mitali Pattnaik",
      "screen_name" : "mitali",
      "indices" : [ 0, 7 ],
      "id_str" : "2913411",
      "id" : 2913411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362745728650588161",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8049977714, -122.2947522196 ]
  },
  "id_str" : "362746327395864577",
  "in_reply_to_user_id" : 2913411,
  "text" : "@mitali There's probably just as much serendipity in the letter-based folders.",
  "id" : 362746327395864577,
  "in_reply_to_status_id" : 362745728650588161,
  "created_at" : "2013-08-01 01:27:18 +0000",
  "in_reply_to_screen_name" : "mitali",
  "in_reply_to_user_id_str" : "2913411",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Galligan",
      "screen_name" : "mg",
      "indices" : [ 0, 3 ],
      "id_str" : "607",
      "id" : 607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362745298046566401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8087203849, -122.3143460528 ]
  },
  "id_str" : "362745650468749312",
  "in_reply_to_user_id" : 607,
  "text" : "@mg Lemme know if you need any beta testers. :)",
  "id" : 362745650468749312,
  "in_reply_to_status_id" : 362745298046566401,
  "created_at" : "2013-08-01 01:24:37 +0000",
  "in_reply_to_screen_name" : "mg",
  "in_reply_to_user_id_str" : "607",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 0, 6 ],
      "id_str" : "5469512",
      "id" : 5469512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362744648797659136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7788876822, -122.4145098655 ]
  },
  "id_str" : "362745515923869696",
  "in_reply_to_user_id" : 5469512,
  "text" : "@micah Ha! I might actually avoid apps with new letters that push it past a single screen.",
  "id" : 362745515923869696,
  "in_reply_to_status_id" : 362744648797659136,
  "created_at" : "2013-08-01 01:24:05 +0000",
  "in_reply_to_screen_name" : "micah",
  "in_reply_to_user_id_str" : "5469512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Galligan",
      "screen_name" : "mg",
      "indices" : [ 0, 3 ],
      "id_str" : "607",
      "id" : 607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362744240406659072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7788876822, -122.4145098655 ]
  },
  "id_str" : "362745033486630913",
  "in_reply_to_user_id" : 607,
  "text" : "@mg You're close! Being able to follow a keyword might push it over to screen 1. Basically need more push notifications.",
  "id" : 362745033486630913,
  "in_reply_to_status_id" : 362744240406659072,
  "created_at" : "2013-08-01 01:22:10 +0000",
  "in_reply_to_screen_name" : "mg",
  "in_reply_to_user_id_str" : "607",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/362743958037729280\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/stzAKWj5l2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQi5tTuCEAIGLTe.jpg",
      "id_str" : "362743958041923586",
      "id" : 362743958041923586,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQi5tTuCEAIGLTe.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/stzAKWj5l2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7788876822, -122.4145098655 ]
  },
  "id_str" : "362743958037729280",
  "text" : "Organizing my 2nd tier apps alphabetically is working surprisingly well. WAY faster to find than by theme. http:\/\/t.co\/stzAKWj5l2",
  "id" : 362743958037729280,
  "created_at" : "2013-08-01 01:17:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arsenio Santos",
      "screen_name" : "arsenio",
      "indices" : [ 0, 8 ],
      "id_str" : "15428642",
      "id" : 15428642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362736161875165184",
  "geo" : { },
  "id_str" : "362736271291990016",
  "in_reply_to_user_id" : 15428642,
  "text" : "@arsenio Excellent. :)",
  "id" : 362736271291990016,
  "in_reply_to_status_id" : 362736161875165184,
  "created_at" : "2013-08-01 00:47:21 +0000",
  "in_reply_to_screen_name" : "arsenio",
  "in_reply_to_user_id_str" : "15428642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arsenio Santos",
      "screen_name" : "arsenio",
      "indices" : [ 0, 8 ],
      "id_str" : "15428642",
      "id" : 15428642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362735086627602432",
  "geo" : { },
  "id_str" : "362735352034770944",
  "in_reply_to_user_id" : 15428642,
  "text" : "@arsenio Click that \"request approval\" button. I'll make sure it gets approved quickly.",
  "id" : 362735352034770944,
  "in_reply_to_status_id" : 362735086627602432,
  "created_at" : "2013-08-01 00:43:41 +0000",
  "in_reply_to_screen_name" : "arsenio",
  "in_reply_to_user_id_str" : "15428642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arsenio Santos",
      "screen_name" : "arsenio",
      "indices" : [ 0, 8 ],
      "id_str" : "15428642",
      "id" : 15428642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/IQpvI3ltZW",
      "expanded_url" : "https:\/\/dev.twitter.com\/docs\/cards\/validation\/validator",
      "display_url" : "dev.twitter.com\/docs\/cards\/val\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "362734313235693568",
  "geo" : { },
  "id_str" : "362734532245458946",
  "in_reply_to_user_id" : 15428642,
  "text" : "@arsenio Yes. Go here: https:\/\/t.co\/IQpvI3ltZW and it should let you through automatically. If not, let me know.",
  "id" : 362734532245458946,
  "in_reply_to_status_id" : 362734313235693568,
  "created_at" : "2013-08-01 00:40:26 +0000",
  "in_reply_to_screen_name" : "arsenio",
  "in_reply_to_user_id_str" : "15428642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arsenio Santos",
      "screen_name" : "arsenio",
      "indices" : [ 0, 8 ],
      "id_str" : "15428642",
      "id" : 15428642
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 9, 12 ],
      "id_str" : "19853",
      "id" : 19853
    }, {
      "name" : "Matt Galligan",
      "screen_name" : "mg",
      "indices" : [ 13, 16 ],
      "id_str" : "607",
      "id" : 607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362712411079319552",
  "geo" : { },
  "id_str" : "362725798609817600",
  "in_reply_to_user_id" : 15428642,
  "text" : "@arsenio @rk @mg That was quick! Hopefully you'll start to see better clickthru. Let me know if you have any Cards questions in the future!",
  "id" : 362725798609817600,
  "in_reply_to_status_id" : 362712411079319552,
  "created_at" : "2013-08-01 00:05:44 +0000",
  "in_reply_to_screen_name" : "arsenio",
  "in_reply_to_user_id_str" : "15428642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mira Crisp",
      "screen_name" : "misscrisp",
      "indices" : [ 0, 10 ],
      "id_str" : "16228258",
      "id" : 16228258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362719166492442624",
  "geo" : { },
  "id_str" : "362725374423072768",
  "in_reply_to_user_id" : 16228258,
  "text" : "@misscrisp Awww\u2026 now who's gonna DJ our dinner and evening hang out times? We'll miss you. Come stay with us again any time!",
  "id" : 362725374423072768,
  "in_reply_to_status_id" : 362719166492442624,
  "created_at" : "2013-08-01 00:04:03 +0000",
  "in_reply_to_screen_name" : "misscrisp",
  "in_reply_to_user_id_str" : "16228258",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Circa",
      "screen_name" : "Circa",
      "indices" : [ 0, 6 ],
      "id_str" : "441389311",
      "id" : 441389311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362623602983583745",
  "geo" : { },
  "id_str" : "362628972930015232",
  "in_reply_to_user_id" : 441389311,
  "text" : "@Circa Cool. Just be sure to use the new \"summary_large_image\" card (not photo) to get the best click through rates.",
  "id" : 362628972930015232,
  "in_reply_to_status_id" : 362623602983583745,
  "created_at" : "2013-07-31 17:40:59 +0000",
  "in_reply_to_screen_name" : "Circa",
  "in_reply_to_user_id_str" : "441389311",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    }, {
      "name" : "Circa",
      "screen_name" : "Circa",
      "indices" : [ 4, 10 ],
      "id_str" : "441389311",
      "id" : 441389311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362587250921451520",
  "geo" : { },
  "id_str" : "362592498276773890",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk @Circa Hm, yeah, I think the pic.twitter is overriding. I recommend switching to the summary with large image card.",
  "id" : 362592498276773890,
  "in_reply_to_status_id" : 362587250921451520,
  "created_at" : "2013-07-31 15:16:02 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Circa",
      "screen_name" : "Circa",
      "indices" : [ 0, 6 ],
      "id_str" : "441389311",
      "id" : 441389311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362572277411377152",
  "geo" : { },
  "id_str" : "362576157209673729",
  "in_reply_to_user_id" : 441389311,
  "text" : "@Circa I have 2 feature requests: subscribe to all stories that match a keyword, and add Twitter Cards so I can open stories in app.",
  "id" : 362576157209673729,
  "in_reply_to_status_id" : 362572277411377152,
  "created_at" : "2013-07-31 14:11:06 +0000",
  "in_reply_to_screen_name" : "Circa",
  "in_reply_to_user_id_str" : "441389311",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "lux",
      "screen_name" : "thebeean",
      "indices" : [ 58, 67 ],
      "id_str" : "166892253",
      "id" : 166892253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362459020390436864",
  "geo" : { },
  "id_str" : "362478291350863873",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach Woah, that was an intense story.  Happy birthday, @thebeean! She and Niko should meet!",
  "id" : 362478291350863873,
  "in_reply_to_status_id" : 362459020390436864,
  "created_at" : "2013-07-31 07:42:13 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 7, 16 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/lstSoRkHAU",
      "expanded_url" : "http:\/\/flic.kr\/p\/fjZGcT",
      "display_url" : "flic.kr\/p\/fjZGcT"
    } ]
  },
  "geo" : { },
  "id_str" : "362418574956052480",
  "text" : "8:36pm @rickwebb is Niko's newest train track repairman.  http:\/\/t.co\/lstSoRkHAU",
  "id" : 362418574956052480,
  "created_at" : "2013-07-31 03:44:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rahul Ganjoo",
      "screen_name" : "elegantlywasted",
      "indices" : [ 3, 19 ],
      "id_str" : "12893512",
      "id" : 12893512
    }, {
      "name" : "JOSH RANDALL",
      "screen_name" : "joshrandall",
      "indices" : [ 27, 39 ],
      "id_str" : "19759026",
      "id" : 19759026
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/joshrandall\/status\/362241816378109953\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/UzgBYjAPfU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQbxA0SCcAACjef.jpg",
      "id_str" : "362241816386498560",
      "id" : 362241816386498560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQbxA0SCcAACjef.jpg",
      "sizes" : [ {
        "h" : 349,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 636
      } ],
      "display_url" : "pic.twitter.com\/UzgBYjAPfU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362248659406036992",
  "text" : "RT @elegantlywasted: Hah! \u201C@joshrandall: Guy removes graffiti only to find image of himself sprayed onto same wall hours later :) http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JOSH RANDALL",
        "screen_name" : "joshrandall",
        "indices" : [ 6, 18 ],
        "id_str" : "19759026",
        "id" : 19759026
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/joshrandall\/status\/362241816378109953\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/UzgBYjAPfU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQbxA0SCcAACjef.jpg",
        "id_str" : "362241816386498560",
        "id" : 362241816386498560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQbxA0SCcAACjef.jpg",
        "sizes" : [ {
          "h" : 349,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 636
        } ],
        "display_url" : "pic.twitter.com\/UzgBYjAPfU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "362241816378109953",
    "geo" : { },
    "id_str" : "362247593494974464",
    "in_reply_to_user_id" : 19759026,
    "text" : "Hah! \u201C@joshrandall: Guy removes graffiti only to find image of himself sprayed onto same wall hours later :) http:\/\/t.co\/UzgBYjAPfU\u201D",
    "id" : 362247593494974464,
    "in_reply_to_status_id" : 362241816378109953,
    "created_at" : "2013-07-30 16:25:31 +0000",
    "in_reply_to_screen_name" : "joshrandall",
    "in_reply_to_user_id_str" : "19759026",
    "user" : {
      "name" : "Rahul Ganjoo",
      "screen_name" : "elegantlywasted",
      "protected" : false,
      "id_str" : "12893512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448298707608301568\/F2IJgWdf_normal.jpeg",
      "id" : 12893512,
      "verified" : false
    }
  },
  "id" : 362248659406036992,
  "created_at" : "2013-07-30 16:29:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffery Bennett",
      "screen_name" : "meandmybadself",
      "indices" : [ 0, 15 ],
      "id_str" : "1797691",
      "id" : 1797691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362202606774386688",
  "geo" : { },
  "id_str" : "362225150952869888",
  "in_reply_to_user_id" : 1797691,
  "text" : "@meandmybadself Thanks! It's such a rewarding project, but I have a near 0% success rate at convincing others it's worth doing.",
  "id" : 362225150952869888,
  "in_reply_to_status_id" : 362202606774386688,
  "created_at" : "2013-07-30 14:56:20 +0000",
  "in_reply_to_screen_name" : "meandmybadself",
  "in_reply_to_user_id_str" : "1797691",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/lC0tvSSOOs",
      "expanded_url" : "http:\/\/flic.kr\/p\/fjyNaE",
      "display_url" : "flic.kr\/p\/fjyNaE"
    } ]
  },
  "geo" : { },
  "id_str" : "362055916721410048",
  "text" : "8:36pm Eating chocolate in the bathtub http:\/\/t.co\/lC0tvSSOOs",
  "id" : 362055916721410048,
  "created_at" : "2013-07-30 03:43:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "indices" : [ 0, 9 ],
      "id_str" : "22483",
      "id" : 22483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361942599013105664",
  "geo" : { },
  "id_str" : "361944027144273920",
  "in_reply_to_user_id" : 22483,
  "text" : "@pinwheel Don't do it.",
  "id" : 361944027144273920,
  "in_reply_to_status_id" : 361942599013105664,
  "created_at" : "2013-07-29 20:19:15 +0000",
  "in_reply_to_screen_name" : "pinwheel",
  "in_reply_to_user_id_str" : "22483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 3, 14 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/G8ROrGsDTp",
      "expanded_url" : "http:\/\/bit.ly\/17Ppq6c",
      "display_url" : "bit.ly\/17Ppq6c"
    } ]
  },
  "geo" : { },
  "id_str" : "361931401953681408",
  "text" : "RT @seanbonner: New Blog Post: Rule 34 for Creatives http:\/\/t.co\/G8ROrGsDTp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/G8ROrGsDTp",
        "expanded_url" : "http:\/\/bit.ly\/17Ppq6c",
        "display_url" : "bit.ly\/17Ppq6c"
      } ]
    },
    "geo" : { },
    "id_str" : "361930750272086016",
    "text" : "New Blog Post: Rule 34 for Creatives http:\/\/t.co\/G8ROrGsDTp",
    "id" : 361930750272086016,
    "created_at" : "2013-07-29 19:26:29 +0000",
    "user" : {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "protected" : false,
      "id_str" : "765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416764038962348032\/rQuyO9H-_normal.png",
      "id" : 765,
      "verified" : false
    }
  },
  "id" : 361931401953681408,
  "created_at" : "2013-07-29 19:29:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/WgZhsevEum",
      "expanded_url" : "http:\/\/instagram.com\/p\/cVpbi5o0DQ\/",
      "display_url" : "instagram.com\/p\/cVpbi5o0DQ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "361721239619895297",
  "text" : "8:36pm I seriously just drew my Goddess card. They're trying to tell me I'm not a sorceress. http:\/\/t.co\/WgZhsevEum",
  "id" : 361721239619895297,
  "created_at" : "2013-07-29 05:33:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361554309227347969",
  "geo" : { },
  "id_str" : "361605855143149570",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler Oh, reverted to iOS 6 (was testing 7) with no backup, so am installing apps as I need them. ~15 so far. Previously I was in 100s.",
  "id" : 361605855143149570,
  "in_reply_to_status_id" : 361554309227347969,
  "created_at" : "2013-07-28 21:55:28 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "underrepresentedmoviegenres",
      "indices" : [ 12, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361592215870517251",
  "text" : "Kids horror #underrepresentedmoviegenres",
  "id" : 361592215870517251,
  "created_at" : "2013-07-28 21:01:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sina Khanifar",
      "screen_name" : "sinak",
      "indices" : [ 3, 9 ],
      "id_str" : "3573701",
      "id" : 3573701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 142, 143 ],
      "url" : "http:\/\/t.co\/oJfpJsONIY",
      "expanded_url" : "http:\/\/j.mp\/13f2YmZ",
      "display_url" : "j.mp\/13f2YmZ"
    } ]
  },
  "geo" : { },
  "id_str" : "361573222430412801",
  "text" : "RT @sinak: Prism: a new app that visualizes your SMS \"metadata\" and shows you data that the NSA has had access to for years -&gt; http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/oJfpJsONIY",
        "expanded_url" : "http:\/\/j.mp\/13f2YmZ",
        "display_url" : "j.mp\/13f2YmZ"
      } ]
    },
    "geo" : { },
    "id_str" : "361572341760794624",
    "text" : "Prism: a new app that visualizes your SMS \"metadata\" and shows you data that the NSA has had access to for years -&gt; http:\/\/t.co\/oJfpJsONIY",
    "id" : 361572341760794624,
    "created_at" : "2013-07-28 19:42:18 +0000",
    "user" : {
      "name" : "Sina Khanifar",
      "screen_name" : "sinak",
      "protected" : false,
      "id_str" : "3573701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/452131355078320128\/Mj-3p9TC_normal.jpeg",
      "id" : 3573701,
      "verified" : false
    }
  },
  "id" : 361573222430412801,
  "created_at" : "2013-07-28 19:45:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/RlhF6lqtUf",
      "expanded_url" : "https:\/\/vine.co\/v\/hAFtJLZAvaD",
      "display_url" : "vine.co\/v\/hAFtJLZAvaD"
    } ]
  },
  "geo" : { },
  "id_str" : "361565025363693571",
  "text" : "Niko's new song \"Sometimes it happens\" https:\/\/t.co\/RlhF6lqtUf",
  "id" : 361565025363693571,
  "created_at" : "2013-07-28 19:13:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Simon",
      "screen_name" : "nprscottsimon",
      "indices" : [ 3, 17 ],
      "id_str" : "20245775",
      "id" : 20245775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361563399492075520",
  "text" : "RT @nprscottsimon: And: listen to people in their 80's. They have looked across the street at death for a decade. They know what's vital.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "361547310217433088",
    "text" : "And: listen to people in their 80's. They have looked across the street at death for a decade. They know what's vital.",
    "id" : 361547310217433088,
    "created_at" : "2013-07-28 18:02:50 +0000",
    "user" : {
      "name" : "Scott Simon",
      "screen_name" : "nprscottsimon",
      "protected" : false,
      "id_str" : "20245775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/77669155\/scottsimon_normal.jpg",
      "id" : 20245775,
      "verified" : true
    }
  },
  "id" : 361563399492075520,
  "created_at" : "2013-07-28 19:06:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361553323796598784",
  "geo" : { },
  "id_str" : "361554196782252032",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler I did, about 20 times. But I'm sort of enjoying my bare minimum apps phone now.",
  "id" : 361554196782252032,
  "in_reply_to_status_id" : 361553323796598784,
  "created_at" : "2013-07-28 18:30:12 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 0, 3 ],
      "id_str" : "15504330",
      "id" : 15504330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361518595383111682",
  "geo" : { },
  "id_str" : "361527132142313473",
  "in_reply_to_user_id" : 15504330,
  "text" : "@wm I sort of almost would maybe even consider it.",
  "id" : 361527132142313473,
  "in_reply_to_status_id" : 361518595383111682,
  "created_at" : "2013-07-28 16:42:39 +0000",
  "in_reply_to_screen_name" : "wm",
  "in_reply_to_user_id_str" : "15504330",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361372298055389185",
  "geo" : { },
  "id_str" : "361518706410532864",
  "in_reply_to_user_id" : 149464163,
  "text" : "@andrewkonoff Tried that but didn't work to restore to iOS 7. Back on 6 now...",
  "id" : 361518706410532864,
  "in_reply_to_status_id" : 361372298055389185,
  "created_at" : "2013-07-28 16:09:10 +0000",
  "in_reply_to_screen_name" : "andknf",
  "in_reply_to_user_id_str" : "149464163",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "appzero",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361518284107038720",
  "text" : "Restored my phone to iOS 6, with no backup. Gonna build my app empire up from scratch. #appzero",
  "id" : 361518284107038720,
  "created_at" : "2013-07-28 16:07:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361477287352336384",
  "geo" : { },
  "id_str" : "361518021208055810",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert After beta3 I lost push notifications. Only fix was to restore, and then got into a broken loop.",
  "id" : 361518021208055810,
  "in_reply_to_status_id" : 361477287352336384,
  "created_at" : "2013-07-28 16:06:27 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lame",
      "indices" : [ 69, 74 ]
    }, {
      "text" : "dude",
      "indices" : [ 75, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361371409978638336",
  "text" : "iOS 7 broke my stupid phone. Won't even restore to factory settings. #lame #dude",
  "id" : 361371409978638336,
  "created_at" : "2013-07-28 06:23:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Morga",
      "screen_name" : "AliciaMorga",
      "indices" : [ 25, 37 ],
      "id_str" : "19053875",
      "id" : 19053875
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Philanthropy",
      "indices" : [ 68, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/zAUydznLXv",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/07\/27\/opinion\/the-charitable-industrial-complex.html",
      "display_url" : "nytimes.com\/2013\/07\/27\/opi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "361199212286840832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595937623, -122.275725325 ]
  },
  "id_str" : "361218596254388224",
  "in_reply_to_user_id" : 19053875,
  "text" : "Interesting thoughts! RT @AliciaMorga: Yep:  http:\/\/t.co\/zAUydznLXv #Philanthropy",
  "id" : 361218596254388224,
  "in_reply_to_status_id" : 361199212286840832,
  "created_at" : "2013-07-27 20:16:39 +0000",
  "in_reply_to_screen_name" : "AliciaMorga",
  "in_reply_to_user_id_str" : "19053875",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/j4bZLKvAaE",
      "expanded_url" : "http:\/\/flic.kr\/p\/fhhPJR",
      "display_url" : "flic.kr\/p\/fhhPJR"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.616116, -122.391617 ]
  },
  "id_str" : "360999968108064769",
  "text" : "8:36pm Just returned from NYC. Just a long Bart ride left. http:\/\/t.co\/j4bZLKvAaE",
  "id" : 360999968108064769,
  "created_at" : "2013-07-27 05:47:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "indices" : [ 0, 5 ],
      "id_str" : "10221",
      "id" : 10221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360971373717360640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6169572188, -122.3835024675 ]
  },
  "id_str" : "360995773804064768",
  "in_reply_to_user_id" : 10221,
  "text" : "@drew Yeah I have no idea how they got in. Was using 1Password even. Maybe an oauthed app got hacked?",
  "id" : 360995773804064768,
  "in_reply_to_status_id" : 360971373717360640,
  "created_at" : "2013-07-27 05:31:14 +0000",
  "in_reply_to_screen_name" : "drew",
  "in_reply_to_user_id_str" : "10221",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360969803172814849",
  "geo" : { },
  "id_str" : "360971206951833602",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg Thanks. Changed my password. Looking into auth'd accounts to try to figure out if there are still vulnerabilities.",
  "id" : 360971206951833602,
  "in_reply_to_status_id" : 360969803172814849,
  "created_at" : "2013-07-27 03:53:36 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Loretz",
      "screen_name" : "colinloretz",
      "indices" : [ 0, 12 ],
      "id_str" : "2803511",
      "id" : 2803511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360967435207192576",
  "geo" : { },
  "id_str" : "360970753425948672",
  "in_reply_to_user_id" : 2803511,
  "text" : "@colinloretz Crap. Thanks for the heads up.",
  "id" : 360970753425948672,
  "in_reply_to_status_id" : 360967435207192576,
  "created_at" : "2013-07-27 03:51:48 +0000",
  "in_reply_to_screen_name" : "colinloretz",
  "in_reply_to_user_id_str" : "2803511",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Fisher",
      "screen_name" : "jeremyhfisher",
      "indices" : [ 0, 14 ],
      "id_str" : "68862738",
      "id" : 68862738
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 15, 24 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 25, 39 ],
      "id_str" : "18749271",
      "id" : 18749271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360925113127927809",
  "geo" : { },
  "id_str" : "360959194179964928",
  "in_reply_to_user_id" : 68862738,
  "text" : "@jeremyhfisher @RickWebb @libbybrittain That would be awesome. Let me know how it goes.",
  "id" : 360959194179964928,
  "in_reply_to_status_id" : 360925113127927809,
  "created_at" : "2013-07-27 03:05:52 +0000",
  "in_reply_to_screen_name" : "jeremyhfisher",
  "in_reply_to_user_id_str" : "68862738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/zdyXsQTXma",
      "expanded_url" : "https:\/\/medium.com\/ladybits-on-medium\/b3b502925697",
      "display_url" : "medium.com\/ladybits-on-me\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360924347315138560",
  "text" : "\"Do you like the taste of beer?\" is the best predictor of a person\u2019s answer to \"Would you have sex on the 1st date?\" https:\/\/t.co\/zdyXsQTXma",
  "id" : 360924347315138560,
  "created_at" : "2013-07-27 00:47:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7249880607, -73.8504024314 ]
  },
  "id_str" : "360875806244872194",
  "text" : "Startup idea: kickstarter to harness the energy from the worry of being in a taxi stuck in traffic on the way to the airport.",
  "id" : 360875806244872194,
  "created_at" : "2013-07-26 21:34:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 0, 6 ],
      "id_str" : "5469512",
      "id" : 5469512
    }, {
      "name" : "Jana Trantow",
      "screen_name" : "janatrantow",
      "indices" : [ 7, 19 ],
      "id_str" : "116872150",
      "id" : 116872150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360811767368130564",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.736746369, -73.8779786323 ]
  },
  "id_str" : "360874393972383744",
  "in_reply_to_user_id" : 5469512,
  "text" : "@micah @janatrantow Dang! I probably saw you but didn't realize it! High fives *will* happen!",
  "id" : 360874393972383744,
  "in_reply_to_status_id" : 360811767368130564,
  "created_at" : "2013-07-26 21:28:54 +0000",
  "in_reply_to_screen_name" : "micah",
  "in_reply_to_user_id_str" : "5469512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 11, 18 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/2MwEy20ntn",
      "expanded_url" : "http:\/\/www.emojitracker.com\/",
      "display_url" : "emojitracker.com"
    } ]
  },
  "in_reply_to_status_id_str" : "360865234874941440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7611231695, -73.9692057587 ]
  },
  "id_str" : "360868407723294720",
  "in_reply_to_user_id" : 99723,
  "text" : "\uD83D\uDC4D\u2764\uFE0F\uD83D\uDC8F\uD83D\uDCA5\uD83D\uDC12\uD83D\uDE82 RT @dacort: Something I wish I had built: http:\/\/t.co\/2MwEy20ntn",
  "id" : 360868407723294720,
  "in_reply_to_status_id" : 360865234874941440,
  "created_at" : "2013-07-26 21:05:07 +0000",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 32, 40 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/uf7vebKvaC",
      "expanded_url" : "http:\/\/4sq.com\/17J19P9",
      "display_url" : "4sq.com\/17J19P9"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7595293001, -73.9803564548 ]
  },
  "id_str" : "360858745833660416",
  "text" : "We're in the tv! (@ NBC News w\/ @chanian) http:\/\/t.co\/uf7vebKvaC",
  "id" : 360858745833660416,
  "created_at" : "2013-07-26 20:26:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 38, 46 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/u1kZkMav4M",
      "expanded_url" : "http:\/\/4sq.com\/1br5b4n",
      "display_url" : "4sq.com\/1br5b4n"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7241284245, -73.9972651005 ]
  },
  "id_str" : "360803828943179776",
  "text" : "Hello Foursquare! (@ Foursquare HQ w\/ @chanian) http:\/\/t.co\/u1kZkMav4M",
  "id" : 360803828943179776,
  "created_at" : "2013-07-26 16:48:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 35, 43 ],
      "id_str" : "22891211",
      "id" : 22891211
    }, {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 44, 50 ],
      "id_str" : "15310552",
      "id" : 15310552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/dX6AE1nERl",
      "expanded_url" : "http:\/\/4sq.com\/12QyUdU",
      "display_url" : "4sq.com\/12QyUdU"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7538404188, -73.9787954092 ]
  },
  "id_str" : "360787948108656642",
  "text" : "Sup Twitter NYC. (@ Twitter NYC w\/ @chanian @singy) http:\/\/t.co\/dX6AE1nERl",
  "id" : 360787948108656642,
  "created_at" : "2013-07-26 15:45:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nein.",
      "screen_name" : "NeinQuarterly",
      "indices" : [ 3, 17 ],
      "id_str" : "458966079",
      "id" : 458966079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360787517445910530",
  "text" : "RT @NeinQuarterly: Maybe you could try being the change that I want to see in the world.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360729983016108032",
    "text" : "Maybe you could try being the change that I want to see in the world.",
    "id" : 360729983016108032,
    "created_at" : "2013-07-26 11:55:04 +0000",
    "user" : {
      "name" : "Nein.",
      "screen_name" : "NeinQuarterly",
      "protected" : false,
      "id_str" : "458966079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000829092209\/ed4c25faaa25fbba40b11fabe8241a59_normal.jpeg",
      "id" : 458966079,
      "verified" : true
    }
  },
  "id" : 360787517445910530,
  "created_at" : "2013-07-26 15:43:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jana Trantow",
      "screen_name" : "janatrantow",
      "indices" : [ 0, 12 ],
      "id_str" : "116872150",
      "id" : 116872150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360759159676874753",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7535521999, -73.978996652 ]
  },
  "id_str" : "360766617904353283",
  "in_reply_to_user_id" : 116872150,
  "text" : "@janatrantow Oh man! I have meetings all day then have to fly back. Coming back in Aug though... would love to visit!",
  "id" : 360766617904353283,
  "in_reply_to_status_id" : 360759159676874753,
  "created_at" : "2013-07-26 14:20:39 +0000",
  "in_reply_to_screen_name" : "janatrantow",
  "in_reply_to_user_id_str" : "116872150",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Newman",
      "screen_name" : "dannynewman",
      "indices" : [ 0, 12 ],
      "id_str" : "8273",
      "id" : 8273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360665074173624320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7535564856, -73.9791478331 ]
  },
  "id_str" : "360766399561469953",
  "in_reply_to_user_id" : 8273,
  "text" : "@dannynewman Yes but just for a couple hours. Hi!",
  "id" : 360766399561469953,
  "in_reply_to_status_id" : 360665074173624320,
  "created_at" : "2013-07-26 14:19:47 +0000",
  "in_reply_to_screen_name" : "dannynewman",
  "in_reply_to_user_id_str" : "8273",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Sharples",
      "screen_name" : "fredsharples",
      "indices" : [ 0, 13 ],
      "id_str" : "18338254",
      "id" : 18338254
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 45, 53 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360636680564248576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7458568764, -73.9882138396 ]
  },
  "id_str" : "360641685849522176",
  "in_reply_to_user_id" : 18338254,
  "text" : "@fredsharples Hmm... that's a tough one. The @mybasis is my current fave probably. Low end Fitbit Zip is probably just as good as others.",
  "id" : 360641685849522176,
  "in_reply_to_status_id" : 360636680564248576,
  "created_at" : "2013-07-26 06:04:13 +0000",
  "in_reply_to_screen_name" : "fredsharples",
  "in_reply_to_user_id_str" : "18338254",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Newman",
      "screen_name" : "dannynewman",
      "indices" : [ 0, 12 ],
      "id_str" : "8273",
      "id" : 8273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7458647022, -73.9883060338 ]
  },
  "id_str" : "360626242954858498",
  "in_reply_to_user_id" : 8273,
  "text" : "@dannynewman Are you at the Ace too?",
  "id" : 360626242954858498,
  "created_at" : "2013-07-26 05:02:51 +0000",
  "in_reply_to_screen_name" : "dannynewman",
  "in_reply_to_user_id_str" : "8273",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ace Hotel",
      "screen_name" : "acehotel",
      "indices" : [ 30, 39 ],
      "id_str" : "42436219",
      "id" : 42436219
    }, {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 52, 60 ],
      "id_str" : "22891211",
      "id" : 22891211
    }, {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 61, 67 ],
      "id_str" : "15310552",
      "id" : 15310552
    }, {
      "name" : "Danny Newman",
      "screen_name" : "dannynewman",
      "indices" : [ 68, 80 ],
      "id_str" : "8273",
      "id" : 8273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/e3B9eaObhA",
      "expanded_url" : "http:\/\/4sq.com\/12odeel",
      "display_url" : "4sq.com\/12odeel"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7458775134, -73.9881422709 ]
  },
  "id_str" : "360618847943917570",
  "text" : "Buster needs food, badly. (at @AceHotel New York w\/ @chanian @singy @dannynewman) [pic]: http:\/\/t.co\/e3B9eaObhA",
  "id" : 360618847943917570,
  "created_at" : "2013-07-26 04:33:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 0, 6 ],
      "id_str" : "15310552",
      "id" : 15310552
    }, {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 25, 33 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360601806302220288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.64333863, -73.7770124153 ]
  },
  "id_str" : "360602521712078850",
  "in_reply_to_user_id" : 15310552,
  "text" : "@singy I'm starving. \/cc @chanian",
  "id" : 360602521712078850,
  "in_reply_to_status_id" : 360601806302220288,
  "created_at" : "2013-07-26 03:28:35 +0000",
  "in_reply_to_screen_name" : "singy",
  "in_reply_to_user_id_str" : "15310552",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360586542353350657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.644778376, -73.7731126716 ]
  },
  "id_str" : "360594212443533312",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim Change is change! Sometimes negatives can create space for positives and vice versa.",
  "id" : 360594212443533312,
  "in_reply_to_status_id" : 360586542353350657,
  "created_at" : "2013-07-26 02:55:34 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Loftesness",
      "screen_name" : "dloft",
      "indices" : [ 0, 6 ],
      "id_str" : "13839772",
      "id" : 13839772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360583977653895168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.644778376, -73.7731126716 ]
  },
  "id_str" : "360593907056259072",
  "in_reply_to_user_id" : 13839772,
  "text" : "@dloft I'm only a 2. There are studies linked to being more prone to illness if you have a high score.",
  "id" : 360593907056259072,
  "in_reply_to_status_id" : 360583977653895168,
  "created_at" : "2013-07-26 02:54:21 +0000",
  "in_reply_to_screen_name" : "dloft",
  "in_reply_to_user_id_str" : "13839772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Belle",
      "screen_name" : "bellebethcooper",
      "indices" : [ 0, 16 ],
      "id_str" : "2282884573",
      "id" : 2282884573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360577637921460224",
  "geo" : { },
  "id_str" : "360577875377782784",
  "in_reply_to_user_id" : 369261529,
  "text" : "@BelleBethCooper I'm a 2.",
  "id" : 360577875377782784,
  "in_reply_to_status_id" : 360577637921460224,
  "created_at" : "2013-07-26 01:50:39 +0000",
  "in_reply_to_screen_name" : "BelleBCooper",
  "in_reply_to_user_id_str" : "369261529",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Belle",
      "screen_name" : "bellebethcooper",
      "indices" : [ 0, 16 ],
      "id_str" : "2282884573",
      "id" : 2282884573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360576922771668993",
  "geo" : { },
  "id_str" : "360577363848867840",
  "in_reply_to_user_id" : 369261529,
  "text" : "@BelleBethCooper You're right, I'll add \"Started a new serious relationship.\"",
  "id" : 360577363848867840,
  "in_reply_to_status_id" : 360576922771668993,
  "created_at" : "2013-07-26 01:48:37 +0000",
  "in_reply_to_screen_name" : "BelleBCooper",
  "in_reply_to_user_id_str" : "369261529",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360575428592795648",
  "geo" : { },
  "id_str" : "360576177305436160",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Lost job and changed job?",
  "id" : 360576177305436160,
  "in_reply_to_status_id" : 360575428592795648,
  "created_at" : "2013-07-26 01:43:54 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/K5hGqnevYT",
      "expanded_url" : "http:\/\/wayoftheduck.com\/life-change-score",
      "display_url" : "wayoftheduck.com\/life-change-sc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360574731658862596",
  "text" : "What's your life change score? http:\/\/t.co\/K5hGqnevYT",
  "id" : 360574731658862596,
  "created_at" : "2013-07-26 01:38:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360569110351978496",
  "geo" : { },
  "id_str" : "360569761215680514",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie For those of us who drink fairly regularly, cutting only that out will usually do the trick.",
  "id" : 360569761215680514,
  "in_reply_to_status_id" : 360569110351978496,
  "created_at" : "2013-07-26 01:18:24 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virgin America",
      "screen_name" : "VirginAmerica",
      "indices" : [ 28, 42 ],
      "id_str" : "12101862",
      "id" : 12101862
    }, {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 46, 54 ],
      "id_str" : "22891211",
      "id" : 22891211
    }, {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 55, 61 ],
      "id_str" : "15310552",
      "id" : 15310552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/NkgHIzsAIy",
      "expanded_url" : "http:\/\/4sq.com\/11h4LXn",
      "display_url" : "4sq.com\/11h4LXn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6173928719, -122.3820734024 ]
  },
  "id_str" : "360489865864937472",
  "text" : "SF -&gt; NYC for a day. (at @VirginAmerica w\/ @chanian @singy) http:\/\/t.co\/NkgHIzsAIy",
  "id" : 360489865864937472,
  "created_at" : "2013-07-25 20:00:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Lockwood",
      "screen_name" : "TriciaLockwood",
      "indices" : [ 3, 18 ],
      "id_str" : "299820130",
      "id" : 299820130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/xZ9sUDG0R5",
      "expanded_url" : "http:\/\/www.theawl.com\/2013\/07\/rape-joke-patricia-lockwood",
      "display_url" : "theawl.com\/2013\/07\/rape-j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360460543405998080",
  "text" : "RT @TriciaLockwood: I have a poem called \"Rape Joke\" up at The Awl today. It is a serious poem: http:\/\/t.co\/xZ9sUDG0R5",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/xZ9sUDG0R5",
        "expanded_url" : "http:\/\/www.theawl.com\/2013\/07\/rape-joke-patricia-lockwood",
        "display_url" : "theawl.com\/2013\/07\/rape-j\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "360456818293620736",
    "text" : "I have a poem called \"Rape Joke\" up at The Awl today. It is a serious poem: http:\/\/t.co\/xZ9sUDG0R5",
    "id" : 360456818293620736,
    "created_at" : "2013-07-25 17:49:37 +0000",
    "user" : {
      "name" : "Patricia Lockwood",
      "screen_name" : "TriciaLockwood",
      "protected" : false,
      "id_str" : "299820130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1430045704\/tweeter_normal.jpg",
      "id" : 299820130,
      "verified" : false
    }
  },
  "id" : 360460543405998080,
  "created_at" : "2013-07-25 18:04:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/BBWPwc2GY2",
      "expanded_url" : "http:\/\/flic.kr\/p\/fgdr24",
      "display_url" : "flic.kr\/p\/fgdr24"
    } ]
  },
  "geo" : { },
  "id_str" : "360259382304452608",
  "text" : "8:36pm Steak and Goldbergs http:\/\/t.co\/BBWPwc2GY2",
  "id" : 360259382304452608,
  "created_at" : "2013-07-25 04:45:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7934384967, -122.3962833438 ]
  },
  "id_str" : "360210782581030913",
  "text" : "I'm excited about dinner.",
  "id" : 360210782581030913,
  "created_at" : "2013-07-25 01:31:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crossingfingers",
      "indices" : [ 71, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7844757236, -122.4078553088 ]
  },
  "id_str" : "360209972988088320",
  "text" : "I've got a couple awesome people in the Twitter job referral pipeline. #crossingfingers",
  "id" : 360209972988088320,
  "created_at" : "2013-07-25 01:28:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Daniels",
      "screen_name" : "maxdaniels",
      "indices" : [ 0, 11 ],
      "id_str" : "17490227",
      "id" : 17490227
    }, {
      "name" : "Budge",
      "screen_name" : "budge",
      "indices" : [ 12, 18 ],
      "id_str" : "286384512",
      "id" : 286384512
    }, {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 52, 68 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360151767176069121",
  "geo" : { },
  "id_str" : "360165641233248256",
  "in_reply_to_user_id" : 17490227,
  "text" : "@maxdaniels @budge Yeah, thanks, it really was! \/cc @ameliagreenhall",
  "id" : 360165641233248256,
  "in_reply_to_status_id" : 360151767176069121,
  "created_at" : "2013-07-24 22:32:35 +0000",
  "in_reply_to_screen_name" : "maxdaniels",
  "in_reply_to_user_id_str" : "17490227",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan McMinn",
      "screen_name" : "ryanmcminn",
      "indices" : [ 0, 11 ],
      "id_str" : "12061042",
      "id" : 12061042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360088719446913027",
  "geo" : { },
  "id_str" : "360089226127212544",
  "in_reply_to_user_id" : 12061042,
  "text" : "@ryanmcminn Ha! Even easier than astrology.",
  "id" : 360089226127212544,
  "in_reply_to_status_id" : 360088719446913027,
  "created_at" : "2013-07-24 17:28:56 +0000",
  "in_reply_to_screen_name" : "ryanmcminn",
  "in_reply_to_user_id_str" : "12061042",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764910089, -122.4167559516 ]
  },
  "id_str" : "360075416750391296",
  "text" : "A service that reads your Twitter, Facebook, Instagram streams and tells you how you come off. Even better, give it as a gift.",
  "id" : 360075416750391296,
  "created_at" : "2013-07-24 16:34:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Wilson",
      "screen_name" : "fredwilson",
      "indices" : [ 3, 14 ],
      "id_str" : "1000591",
      "id" : 1000591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/MnmcnYt2bw",
      "expanded_url" : "http:\/\/www.avc.com\/a_vc\/2013\/07\/growth-is-a-bitch.html",
      "display_url" : "avc.com\/a_vc\/2013\/07\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360071995976724480",
  "text" : "RT @fredwilson: Growth Is A Bitch http:\/\/t.co\/MnmcnYt2bw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/MnmcnYt2bw",
        "expanded_url" : "http:\/\/www.avc.com\/a_vc\/2013\/07\/growth-is-a-bitch.html",
        "display_url" : "avc.com\/a_vc\/2013\/07\/g\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "360065670232285184",
    "text" : "Growth Is A Bitch http:\/\/t.co\/MnmcnYt2bw",
    "id" : 360065670232285184,
    "created_at" : "2013-07-24 15:55:20 +0000",
    "user" : {
      "name" : "Fred Wilson",
      "screen_name" : "fredwilson",
      "protected" : false,
      "id_str" : "1000591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3580641456\/82c873940343750638b7caa04b4652fe_normal.jpeg",
      "id" : 1000591,
      "verified" : true
    }
  },
  "id" : 360071995976724480,
  "created_at" : "2013-07-24 16:20:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Nobbs",
      "screen_name" : "michaelnobbs",
      "indices" : [ 3, 16 ],
      "id_str" : "6996832",
      "id" : 6996832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/LZRMvohNuE",
      "expanded_url" : "http:\/\/buff.ly\/15OTMX3",
      "display_url" : "buff.ly\/15OTMX3"
    } ]
  },
  "geo" : { },
  "id_str" : "360038248891953153",
  "text" : "RT @michaelnobbs: Twihaiku? Micropoetry? The rise of Twitter poetry http:\/\/t.co\/LZRMvohNuE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/LZRMvohNuE",
        "expanded_url" : "http:\/\/buff.ly\/15OTMX3",
        "display_url" : "buff.ly\/15OTMX3"
      } ]
    },
    "geo" : { },
    "id_str" : "359886967711858689",
    "text" : "Twihaiku? Micropoetry? The rise of Twitter poetry http:\/\/t.co\/LZRMvohNuE",
    "id" : 359886967711858689,
    "created_at" : "2013-07-24 04:05:14 +0000",
    "user" : {
      "name" : "Michael Nobbs",
      "screen_name" : "michaelnobbs",
      "protected" : false,
      "id_str" : "6996832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1145178262\/twitter.avatar_normal.jpg",
      "id" : 6996832,
      "verified" : false
    }
  },
  "id" : 360038248891953153,
  "created_at" : "2013-07-24 14:06:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/MMR9OsPCSq",
      "expanded_url" : "http:\/\/flic.kr\/p\/ffB9uv",
      "display_url" : "flic.kr\/p\/ffB9uv"
    } ]
  },
  "geo" : { },
  "id_str" : "359902267081625600",
  "text" : "Double story time with the Goldbergs http:\/\/t.co\/MMR9OsPCSq",
  "id" : 359902267081625600,
  "created_at" : "2013-07-24 05:06:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/PIcFK82lRN",
      "expanded_url" : "http:\/\/flic.kr\/p\/ffPMUW",
      "display_url" : "flic.kr\/p\/ffPMUW"
    } ]
  },
  "geo" : { },
  "id_str" : "359883202699075584",
  "text" : "8:36pm Niko and Lillia reunited! http:\/\/t.co\/PIcFK82lRN",
  "id" : 359883202699075584,
  "created_at" : "2013-07-24 03:50:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daisy barringer",
      "screen_name" : "daisy",
      "indices" : [ 0, 6 ],
      "id_str" : "7390862",
      "id" : 7390862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359772263333109760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763887126, -122.4173115179 ]
  },
  "id_str" : "359773193512300548",
  "in_reply_to_user_id" : 7390862,
  "text" : "@daisy The protected account curse in a nutshell. Follow them if you think they're interesting as a person?",
  "id" : 359773193512300548,
  "in_reply_to_status_id" : 359772263333109760,
  "created_at" : "2013-07-23 20:33:08 +0000",
  "in_reply_to_screen_name" : "daisy",
  "in_reply_to_user_id_str" : "7390862",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 0, 11 ],
      "id_str" : "1586501",
      "id" : 1586501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359754931193909248",
  "geo" : { },
  "id_str" : "359772615721746432",
  "in_reply_to_user_id" : 1586501,
  "text" : "@nickbilton Pre-ordered! Will there be an audiobook?",
  "id" : 359772615721746432,
  "in_reply_to_status_id" : 359754931193909248,
  "created_at" : "2013-07-23 20:30:50 +0000",
  "in_reply_to_screen_name" : "nickbilton",
  "in_reply_to_user_id_str" : "1586501",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daisy barringer",
      "screen_name" : "daisy",
      "indices" : [ 0, 6 ],
      "id_str" : "7390862",
      "id" : 7390862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359769889717760000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764238659, -122.4170624324 ]
  },
  "id_str" : "359772071632445441",
  "in_reply_to_user_id" : 7390862,
  "text" : "@daisy Seems fair to me but if they want to share they can just approve the follow, right? I fear being ignored more than being read.",
  "id" : 359772071632445441,
  "in_reply_to_status_id" : 359769889717760000,
  "created_at" : "2013-07-23 20:28:40 +0000",
  "in_reply_to_screen_name" : "daisy",
  "in_reply_to_user_id_str" : "7390862",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kid President",
      "screen_name" : "iamkidpresident",
      "indices" : [ 3, 19 ],
      "id_str" : "627799297",
      "id" : 627799297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359768391755636742",
  "text" : "RT @iamkidpresident: Treat everybody like they are royal babies.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359688082867490818",
    "text" : "Treat everybody like they are royal babies.",
    "id" : 359688082867490818,
    "created_at" : "2013-07-23 14:54:56 +0000",
    "user" : {
      "name" : "Kid President",
      "screen_name" : "iamkidpresident",
      "protected" : false,
      "id_str" : "627799297",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2373000215\/qkp8f7490xr28uznmnkq_normal.jpeg",
      "id" : 627799297,
      "verified" : false
    }
  },
  "id" : 359768391755636742,
  "created_at" : "2013-07-23 20:14:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daisy barringer",
      "screen_name" : "daisy",
      "indices" : [ 0, 6 ],
      "id_str" : "7390862",
      "id" : 7390862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359767144449327106",
  "geo" : { },
  "id_str" : "359768353960759297",
  "in_reply_to_user_id" : 7390862,
  "text" : "@daisy If your account was protected  would you want that? Seems not. Then again, I don't understand protected accounts.",
  "id" : 359768353960759297,
  "in_reply_to_status_id" : 359767144449327106,
  "created_at" : "2013-07-23 20:13:54 +0000",
  "in_reply_to_screen_name" : "daisy",
  "in_reply_to_user_id_str" : "7390862",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Hische",
      "screen_name" : "jessicahische",
      "indices" : [ 0, 14 ],
      "id_str" : "18638800",
      "id" : 18638800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/sPVrNlPLQB",
      "expanded_url" : "http:\/\/tweetdeck.com",
      "display_url" : "tweetdeck.com"
    } ]
  },
  "in_reply_to_status_id_str" : "359702052894556162",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762438688, -122.4169191112 ]
  },
  "id_str" : "359715394996543488",
  "in_reply_to_user_id" : 18638800,
  "text" : "@jessicahische Have you already tried http:\/\/t.co\/sPVrNlPLQB? It's much more single-column friendly these days.",
  "id" : 359715394996543488,
  "in_reply_to_status_id" : 359702052894556162,
  "created_at" : "2013-07-23 16:43:28 +0000",
  "in_reply_to_screen_name" : "jessicahische",
  "in_reply_to_user_id_str" : "18638800",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 8, 16 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/bdbQ1fGqQr",
      "expanded_url" : "http:\/\/ow.ly\/neVIp",
      "display_url" : "ow.ly\/neVIp"
    }, {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/ZUvzd0EZW3",
      "expanded_url" : "http:\/\/ow.ly\/neVRC",
      "display_url" : "ow.ly\/neVRC"
    } ]
  },
  "in_reply_to_status_id_str" : "359699547414462465",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8531866438, -122.270364347 ]
  },
  "id_str" : "359702613345828864",
  "in_reply_to_user_id" : 216453702,
  "text" : "Yay! RT @mybasis: Our Basis Sync App for iPhone is now available: http:\/\/t.co\/bdbQ1fGqQr Read more about it: http:\/\/t.co\/ZUvzd0EZW3",
  "id" : 359702613345828864,
  "in_reply_to_status_id" : 359699547414462465,
  "created_at" : "2013-07-23 15:52:40 +0000",
  "in_reply_to_screen_name" : "mybasis",
  "in_reply_to_user_id_str" : "216453702",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 57, 64 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/LFQey4ExN8",
      "expanded_url" : "http:\/\/blog.isaach.com\/2013\/07\/twitter-hackweek-july-2013.html",
      "display_url" : "blog.isaach.com\/2013\/07\/twitte\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "359534860458655745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859739751, -122.2755478427 ]
  },
  "id_str" : "359553118679207936",
  "in_reply_to_user_id" : 7852612,
  "text" : "Instructions on how to visualize giant social graphs: RT @isaach: what i did for twitter hackweek and how i did it http:\/\/t.co\/LFQey4ExN8",
  "id" : 359553118679207936,
  "in_reply_to_status_id" : 359534860458655745,
  "created_at" : "2013-07-23 05:58:38 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/tpq1KZlFMo",
      "expanded_url" : "http:\/\/flic.kr\/p\/feVRK8",
      "display_url" : "flic.kr\/p\/feVRK8"
    } ]
  },
  "geo" : { },
  "id_str" : "359528755695329280",
  "text" : "8:36pm Before and after Niko realized we were taking pictures of his angry writhing  http:\/\/t.co\/tpq1KZlFMo",
  "id" : 359528755695329280,
  "created_at" : "2013-07-23 04:21:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA Kennedy \/ KSC",
      "screen_name" : "NASAKennedy",
      "indices" : [ 3, 15 ],
      "id_str" : "16580226",
      "id" : 16580226
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NASAKennedy\/status\/359326972368789505\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/NkE9yW9ljg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPyV-kKCIAAMigP.jpg",
      "id_str" : "359326972372983808",
      "id" : 359326972372983808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPyV-kKCIAAMigP.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 1632
      } ],
      "display_url" : "pic.twitter.com\/NkE9yW9ljg"
    } ],
    "hashtags" : [ {
      "text" : "NASA",
      "indices" : [ 50, 55 ]
    }, {
      "text" : "space",
      "indices" : [ 56, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359511899806769153",
  "text" : "RT @NASAKennedy: We can't wait to use this again. #NASA #space http:\/\/t.co\/NkE9yW9ljg",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASAKennedy\/status\/359326972368789505\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/NkE9yW9ljg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BPyV-kKCIAAMigP.jpg",
        "id_str" : "359326972372983808",
        "id" : 359326972372983808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPyV-kKCIAAMigP.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1224,
          "resize" : "fit",
          "w" : 1632
        } ],
        "display_url" : "pic.twitter.com\/NkE9yW9ljg"
      } ],
      "hashtags" : [ {
        "text" : "NASA",
        "indices" : [ 33, 38 ]
      }, {
        "text" : "space",
        "indices" : [ 39, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359326972368789505",
    "text" : "We can't wait to use this again. #NASA #space http:\/\/t.co\/NkE9yW9ljg",
    "id" : 359326972368789505,
    "created_at" : "2013-07-22 15:00:01 +0000",
    "user" : {
      "name" : "NASA Kennedy \/ KSC",
      "screen_name" : "NASAKennedy",
      "protected" : false,
      "id_str" : "16580226",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456408200464433153\/X9YbZm5q_normal.jpeg",
      "id" : 16580226,
      "verified" : true
    }
  },
  "id" : 359511899806769153,
  "created_at" : "2013-07-23 03:14:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 0, 14 ],
      "id_str" : "820661",
      "id" : 820661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359495619687100417",
  "geo" : { },
  "id_str" : "359497054805958656",
  "in_reply_to_user_id" : 820661,
  "text" : "@daveschappell Seriously though, I fave to high-5 the author and RT to share with others. I often find myself doing both.",
  "id" : 359497054805958656,
  "in_reply_to_status_id" : 359495619687100417,
  "created_at" : "2013-07-23 02:15:51 +0000",
  "in_reply_to_screen_name" : "daveschappell",
  "in_reply_to_user_id_str" : "820661",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 0, 14 ],
      "id_str" : "820661",
      "id" : 820661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359419884028956672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7771013993, -122.4160935831 ]
  },
  "id_str" : "359433922389610496",
  "in_reply_to_user_id" : 820661,
  "text" : "@daveschappell If you do the trifecta (fave, retweet, and reply) you unlock a special tweet hole to another tweeterverse.",
  "id" : 359433922389610496,
  "in_reply_to_status_id" : 359419884028956672,
  "created_at" : "2013-07-22 22:04:59 +0000",
  "in_reply_to_screen_name" : "daveschappell",
  "in_reply_to_user_id_str" : "820661",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "a. spaceman",
      "screen_name" : "adamrensch",
      "indices" : [ 3, 14 ],
      "id_str" : "146576344",
      "id" : 146576344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359173334564487168",
  "text" : "RT @adamrensch: next time you thoughtlessly sit under a tree take a moment to consider that it EATS LIGHT",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "348631300640489472",
    "text" : "next time you thoughtlessly sit under a tree take a moment to consider that it EATS LIGHT",
    "id" : 348631300640489472,
    "created_at" : "2013-06-23 02:39:13 +0000",
    "user" : {
      "name" : "a. spaceman",
      "screen_name" : "adamrensch",
      "protected" : false,
      "id_str" : "146576344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460925895197224960\/KLqNEV6U_normal.jpeg",
      "id" : 146576344,
      "verified" : false
    }
  },
  "id" : 359173334564487168,
  "created_at" : "2013-07-22 04:49:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/92NZpJRT4h",
      "expanded_url" : "http:\/\/flic.kr\/p\/fecyEi",
      "display_url" : "flic.kr\/p\/fecyEi"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859711, -122.275489 ]
  },
  "id_str" : "359156698449055746",
  "text" : "8:36pm Orange Is the New Sunday Evening Binge Watch In Bed Marathon http:\/\/t.co\/92NZpJRT4h",
  "id" : 359156698449055746,
  "created_at" : "2013-07-22 03:43:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whedonesque",
      "screen_name" : "whedonesque",
      "indices" : [ 4, 16 ],
      "id_str" : "13007812",
      "id" : 13007812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597299432, -122.2756039349 ]
  },
  "id_str" : "359107757338673152",
  "text" : "The @whedonesque family is throwing a party in our front yard. What are your Buffy questions?",
  "id" : 359107757338673152,
  "created_at" : "2013-07-22 00:28:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lawblob",
      "screen_name" : "lawblob",
      "indices" : [ 3, 11 ],
      "id_str" : "41875694",
      "id" : 41875694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359106674788810753",
  "text" : "RT @lawblob: if you love something set it free. except Shamu.. we all love Shamu but he must be imprisoned forever",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269103001325670401",
    "text" : "if you love something set it free. except Shamu.. we all love Shamu but he must be imprisoned forever",
    "id" : 269103001325670401,
    "created_at" : "2012-11-15 15:42:09 +0000",
    "user" : {
      "name" : "lawblob",
      "screen_name" : "lawblob",
      "protected" : false,
      "id_str" : "41875694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000712022277\/fee5add6cc078b6f557bcfd3a85821c2_normal.jpeg",
      "id" : 41875694,
      "verified" : false
    }
  },
  "id" : 359106674788810753,
  "created_at" : "2013-07-22 00:24:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shepphard",
      "screen_name" : "getdownshep",
      "indices" : [ 0, 12 ],
      "id_str" : "19645612",
      "id" : 19645612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/vMcjnwapEl",
      "expanded_url" : "http:\/\/bit.ly\/M92VRg",
      "display_url" : "bit.ly\/M92VRg"
    } ]
  },
  "in_reply_to_status_id_str" : "359068104262811648",
  "geo" : { },
  "id_str" : "359079252173398017",
  "in_reply_to_user_id" : 19645612,
  "text" : "@getdownshep It would be way too boring to make public. Tracking it through peabrain.co and posting updates on http:\/\/t.co\/vMcjnwapEl",
  "id" : 359079252173398017,
  "in_reply_to_status_id" : 359068104262811648,
  "created_at" : "2013-07-21 22:35:39 +0000",
  "in_reply_to_screen_name" : "getdownshep",
  "in_reply_to_user_id_str" : "19645612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8644683007, -122.277905471 ]
  },
  "id_str" : "359070264224522240",
  "text" : "\"Everyone should choose their own path. Here's how you do that.\" - every self help book",
  "id" : 359070264224522240,
  "created_at" : "2013-07-21 21:59:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/runkeeper.com\" rel=\"nofollow\"\u003ERunKeeper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RunKeeper",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/IrgrDhG2XP",
      "expanded_url" : "http:\/\/rnkpr.com\/a3iilu4",
      "display_url" : "rnkpr.com\/a3iilu4"
    } ]
  },
  "geo" : { },
  "id_str" : "359067465835229186",
  "text" : "Just completed a 2.49 mi run - 1st run. Stopped as knee started acting up.  http:\/\/t.co\/IrgrDhG2XP #RunKeeper",
  "id" : 359067465835229186,
  "created_at" : "2013-07-21 21:48:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359030977743437825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859732076, -122.2757438784 ]
  },
  "id_str" : "359051913888665600",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april No reason. Just because it's normal to do so in this town.",
  "id" : 359051913888665600,
  "in_reply_to_status_id" : 359030977743437825,
  "created_at" : "2013-07-21 20:47:01 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/358995131438886912\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/L0fVZtz6BU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPtoK4YCcAASAl-.jpg",
      "id_str" : "358995131447275520",
      "id" : 358995131447275520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPtoK4YCcAASAl-.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/L0fVZtz6BU"
    } ],
    "hashtags" : [ {
      "text" : "berkeley",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8572763875, -122.2674004176 ]
  },
  "id_str" : "358995131438886912",
  "text" : "There are 50+ people waiting with shopping carts at the ready to get into Berkeley Bowl when it opens. #berkeley http:\/\/t.co\/L0fVZtz6BU",
  "id" : 358995131438886912,
  "created_at" : "2013-07-21 17:01:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Mod",
      "screen_name" : "craigmod",
      "indices" : [ 0, 9 ],
      "id_str" : "1835951",
      "id" : 1835951
    }, {
      "name" : "elle luna",
      "screen_name" : "elleluna",
      "indices" : [ 10, 19 ],
      "id_str" : "21107053",
      "id" : 21107053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358982942158098432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597591765, -122.2755384406 ]
  },
  "id_str" : "358989596933103617",
  "in_reply_to_user_id" : 1835951,
  "text" : "@craigmod @elleluna It should work on URLs that are tweeted for the first time. Let me know if you experience otherwise.",
  "id" : 358989596933103617,
  "in_reply_to_status_id" : 358982942158098432,
  "created_at" : "2013-07-21 16:39:24 +0000",
  "in_reply_to_screen_name" : "craigmod",
  "in_reply_to_user_id_str" : "1835951",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "emma jane webb",
      "screen_name" : "emmarocks",
      "indices" : [ 10, 20 ],
      "id_str" : "766566",
      "id" : 766566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358486456261550080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595923759, -122.2754447428 ]
  },
  "id_str" : "358487126196752384",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @emmarocks And apparently you never sleep.",
  "id" : 358487126196752384,
  "in_reply_to_status_id" : 358486456261550080,
  "created_at" : "2013-07-20 07:22:45 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "indices" : [ 0, 5 ],
      "id_str" : "10221",
      "id" : 10221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358482728989106179",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859685822, -122.2756320993 ]
  },
  "id_str" : "358486493116907520",
  "in_reply_to_user_id" : 10221,
  "text" : "@drew When I had a life coach I spent most of our time encouraging her to dive into her life coaching business.",
  "id" : 358486493116907520,
  "in_reply_to_status_id" : 358482728989106179,
  "created_at" : "2013-07-20 07:20:14 +0000",
  "in_reply_to_screen_name" : "drew",
  "in_reply_to_user_id_str" : "10221",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "emma jane webb",
      "screen_name" : "emmarocks",
      "indices" : [ 10, 20 ],
      "id_str" : "766566",
      "id" : 766566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596498492, -122.2754729447 ]
  },
  "id_str" : "358485599239405568",
  "in_reply_to_user_id" : 761628,
  "text" : "@rickwebb @emmarocks Love the Johnny Cash stamp.",
  "id" : 358485599239405568,
  "created_at" : "2013-07-20 07:16:41 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/T85biKEw0T",
      "expanded_url" : "http:\/\/instagram.com\/p\/b-oMJnI0A3\/",
      "display_url" : "instagram.com\/p\/b-oMJnI0A3\/"
    } ]
  },
  "geo" : { },
  "id_str" : "358481281656438784",
  "text" : "Peeking in on sleeping Niko is infinitely fun http:\/\/t.co\/T85biKEw0T",
  "id" : 358481281656438784,
  "created_at" : "2013-07-20 06:59:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Victor",
      "screen_name" : "joeyvictor24",
      "indices" : [ 0, 13 ],
      "id_str" : "503779036",
      "id" : 503779036
    }, {
      "name" : "Lynn Kuhlmann",
      "screen_name" : "LynnKuhlmann",
      "indices" : [ 14, 27 ],
      "id_str" : "482299240",
      "id" : 482299240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358469609034219520",
  "geo" : { },
  "id_str" : "358477389958885376",
  "in_reply_to_user_id" : 503779036,
  "text" : "@joeyvictor24 @LynnKuhlmann woof!",
  "id" : 358477389958885376,
  "in_reply_to_status_id" : 358469609034219520,
  "created_at" : "2013-07-20 06:44:04 +0000",
  "in_reply_to_screen_name" : "joeyvictor24",
  "in_reply_to_user_id_str" : "503779036",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/lZiUu3I5zx",
      "expanded_url" : "http:\/\/flic.kr\/p\/fcRW1c",
      "display_url" : "flic.kr\/p\/fcRW1c"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.809563, -122.272789 ]
  },
  "id_str" : "358440791665934337",
  "text" : "8:36pm Talking about serious topic at our favorite date night restaurant http:\/\/t.co\/lZiUu3I5zx",
  "id" : 358440791665934337,
  "created_at" : "2013-07-20 04:18:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769884735, -122.4172639878 ]
  },
  "id_str" : "358390005565104128",
  "text" : "If cheesy self-help books don't make you want to puke, I recommend checking out The Tools.",
  "id" : 358390005565104128,
  "created_at" : "2013-07-20 00:56:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Tools",
      "screen_name" : "TheToolsBook",
      "indices" : [ 113, 126 ],
      "id_str" : "500138754",
      "id" : 500138754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7766266774, -122.4168629385 ]
  },
  "id_str" : "358389534641242112",
  "text" : "\"When a man knows he is to be hanged in a fortnight, it concentrates his mind wonderfully.\" - Samuel Johnson via @TheToolsBook",
  "id" : 358389534641242112,
  "created_at" : "2013-07-20 00:54:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 129, 140 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/pn7teIYMW9",
      "expanded_url" : "http:\/\/techcrunch.com\/2013\/07\/19\/poppy-games\/",
      "display_url" : "techcrunch.com\/2013\/07\/19\/pop\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "358384033136263169",
  "text" : "Could be awesome: \"Poppy Is Courting Developers To Build 3-D Augmented Reality Games For Your iPhone\" http:\/\/t.co\/pn7teIYMW9 via @techcrunch",
  "id" : 358384033136263169,
  "created_at" : "2013-07-20 00:33:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358374589476245507",
  "geo" : { },
  "id_str" : "358377610444673025",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin The best part is seeing how proud\/nervous\/excited they are. Definitely tear-worthy.",
  "id" : 358377610444673025,
  "in_reply_to_status_id" : 358374589476245507,
  "created_at" : "2013-07-20 00:07:35 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Heitzeberg",
      "screen_name" : "jheitzeb",
      "indices" : [ 54, 63 ],
      "id_str" : "6629572",
      "id" : 6629572
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 102, 114 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/8CsiBlgDNu",
      "expanded_url" : "http:\/\/kck.st\/12pALEG",
      "display_url" : "kck.st\/12pALEG"
    } ]
  },
  "geo" : { },
  "id_str" : "358375686257393664",
  "text" : "Backed Poppy! Meant to do this a while ago. Nice work @jheitzeb! Turn Your iPhone into a 3D Camera on @Kickstarter http:\/\/t.co\/8CsiBlgDNu",
  "id" : 358375686257393664,
  "created_at" : "2013-07-19 23:59:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Frey",
      "screen_name" : "erinfrey",
      "indices" : [ 0, 9 ],
      "id_str" : "20031223",
      "id" : 20031223
    }, {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 10, 25 ],
      "id_str" : "6727082",
      "id" : 6727082
    }, {
      "name" : "Mark Jaquith",
      "screen_name" : "markjaquith",
      "indices" : [ 26, 38 ],
      "id_str" : "821042",
      "id" : 821042
    }, {
      "name" : "Josh Roman",
      "screen_name" : "joshroman",
      "indices" : [ 39, 49 ],
      "id_str" : "15006958",
      "id" : 15006958
    }, {
      "name" : "Lauren Bacon",
      "screen_name" : "laurenbacon",
      "indices" : [ 50, 62 ],
      "id_str" : "16296154",
      "id" : 16296154
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358352705879687168",
  "geo" : { },
  "id_str" : "358359673742696448",
  "in_reply_to_user_id" : 20031223,
  "text" : "@erinfrey @tehgeekmeister @markjaquith @joshroman @laurenbacon I'll let you know when I build a habit.",
  "id" : 358359673742696448,
  "in_reply_to_status_id" : 358352705879687168,
  "created_at" : "2013-07-19 22:56:18 +0000",
  "in_reply_to_screen_name" : "erinfrey",
  "in_reply_to_user_id_str" : "20031223",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358278424336416768",
  "geo" : { },
  "id_str" : "358328238717681665",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Niko choked on his lines. It was super cute.",
  "id" : 358328238717681665,
  "in_reply_to_status_id" : 358278424336416768,
  "created_at" : "2013-07-19 20:51:24 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 7, 17 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358305788202205184",
  "geo" : { },
  "id_str" : "358327623425867777",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc @ingopixel Turns out, as big as Niko's train obsession is, it's nowhere near some of the kitty and princess obsessions we witnessed.",
  "id" : 358327623425867777,
  "in_reply_to_status_id" : 358305788202205184,
  "created_at" : "2013-07-19 20:48:57 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriemTeam",
      "screen_name" : "TriemTeam",
      "indices" : [ 0, 10 ],
      "id_str" : "24792603",
      "id" : 24792603
    }, {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 11, 21 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358291928304988160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598330791, -122.2837781864 ]
  },
  "id_str" : "358295451021230080",
  "in_reply_to_user_id" : 24792603,
  "text" : "@TriemTeam @ingopixel The normal names of our youth are the new weird names.",
  "id" : 358295451021230080,
  "in_reply_to_status_id" : 358291928304988160,
  "created_at" : "2013-07-19 18:41:06 +0000",
  "in_reply_to_screen_name" : "TriemTeam",
  "in_reply_to_user_id_str" : "24792603",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/pyXuThYtPm",
      "expanded_url" : "http:\/\/flic.kr\/p\/fcBgKH",
      "display_url" : "flic.kr\/p\/fcBgKH"
    } ]
  },
  "geo" : { },
  "id_str" : "358283160900997120",
  "text" : "What Do You See? the musical http:\/\/t.co\/pyXuThYtPm",
  "id" : 358283160900997120,
  "created_at" : "2013-07-19 17:52:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/HlbL3T6EgW",
      "expanded_url" : "http:\/\/flic.kr\/p\/fcAMF8",
      "display_url" : "flic.kr\/p\/fcAMF8"
    } ]
  },
  "geo" : { },
  "id_str" : "358278699252060161",
  "text" : "The cast list for Niko's first play http:\/\/t.co\/HlbL3T6EgW",
  "id" : 358278699252060161,
  "created_at" : "2013-07-19 17:34:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/ym8IYbidBM",
      "expanded_url" : "http:\/\/flic.kr\/p\/fcAH4B",
      "display_url" : "flic.kr\/p\/fcAH4B"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85963, -122.283631 ]
  },
  "id_str" : "358277668208254976",
  "text" : "Niko's last day of preschool, school play starting soon http:\/\/t.co\/ym8IYbidBM",
  "id" : 358277668208254976,
  "created_at" : "2013-07-19 17:30:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mohit Jaswal",
      "screen_name" : "MohitJaswal",
      "indices" : [ 0, 12 ],
      "id_str" : "51660042",
      "id" : 51660042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358259614594252800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597494262, -122.2754294426 ]
  },
  "id_str" : "358263949940101121",
  "in_reply_to_user_id" : 51660042,
  "text" : "@MohitJaswal Yes, it does.",
  "id" : 358263949940101121,
  "in_reply_to_status_id" : 358259614594252800,
  "created_at" : "2013-07-19 16:35:56 +0000",
  "in_reply_to_screen_name" : "MohitJaswal",
  "in_reply_to_user_id_str" : "51660042",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 0, 14 ],
      "id_str" : "18749271",
      "id" : 18749271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358251027968958466",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597380283, -122.275767553 ]
  },
  "id_str" : "358253170281025537",
  "in_reply_to_user_id" : 18749271,
  "text" : "@libbybrittain What problem are you trying to solve?",
  "id" : 358253170281025537,
  "in_reply_to_status_id" : 358251027968958466,
  "created_at" : "2013-07-19 15:53:06 +0000",
  "in_reply_to_screen_name" : "libbybrittain",
  "in_reply_to_user_id_str" : "18749271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mat honan",
      "screen_name" : "mat",
      "indices" : [ 3, 7 ],
      "id_str" : "11113",
      "id" : 11113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/UC1aRy1ybW",
      "expanded_url" : "http:\/\/www.emptyage.com\/post\/55852918660\/the-objectively-best-things-that-have-ever-been-on-the",
      "display_url" : "emptyage.com\/post\/558529186\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "358245988588195840",
  "text" : "RT @mat: So, I am pretty much an expert at this shit and these are the best things that have ever been on the web http:\/\/t.co\/UC1aRy1ybW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/UC1aRy1ybW",
        "expanded_url" : "http:\/\/www.emptyage.com\/post\/55852918660\/the-objectively-best-things-that-have-ever-been-on-the",
        "display_url" : "emptyage.com\/post\/558529186\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "358115306612330498",
    "text" : "So, I am pretty much an expert at this shit and these are the best things that have ever been on the web http:\/\/t.co\/UC1aRy1ybW",
    "id" : 358115306612330498,
    "created_at" : "2013-07-19 06:45:17 +0000",
    "user" : {
      "name" : "mat honan",
      "screen_name" : "mat",
      "protected" : false,
      "id_str" : "11113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432654572876619776\/oF1EKBOV_normal.jpeg",
      "id" : 11113,
      "verified" : true
    }
  },
  "id" : 358245988588195840,
  "created_at" : "2013-07-19 15:24:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pratik",
      "screen_name" : "pratiktandel",
      "indices" : [ 0, 13 ],
      "id_str" : "259246576",
      "id" : 259246576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358080860517445632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8708131193, -122.2927412578 ]
  },
  "id_str" : "358081414446587905",
  "in_reply_to_user_id" : 259246576,
  "text" : "@pratiktandel Would you rather pay to follow my non-sensationalist account?",
  "id" : 358081414446587905,
  "in_reply_to_status_id" : 358080860517445632,
  "created_at" : "2013-07-19 04:30:36 +0000",
  "in_reply_to_screen_name" : "pratiktandel",
  "in_reply_to_user_id_str" : "259246576",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pratik",
      "screen_name" : "pratiktandel",
      "indices" : [ 0, 13 ],
      "id_str" : "259246576",
      "id" : 259246576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358075162823897088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8707803541, -122.2927814808 ]
  },
  "id_str" : "358080282315853824",
  "in_reply_to_user_id" : 259246576,
  "text" : "@pratiktandel Plus I pay myself on tweet expands.",
  "id" : 358080282315853824,
  "in_reply_to_status_id" : 358075162823897088,
  "created_at" : "2013-07-19 04:26:06 +0000",
  "in_reply_to_screen_name" : "pratiktandel",
  "in_reply_to_user_id_str" : "259246576",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pratik",
      "screen_name" : "pratiktandel",
      "indices" : [ 0, 13 ],
      "id_str" : "259246576",
      "id" : 259246576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358075162823897088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8707966069, -122.2929178645 ]
  },
  "id_str" : "358079822532059136",
  "in_reply_to_user_id" : 259246576,
  "text" : "@pratiktandel Just live tweeting from the front lines of my living room.",
  "id" : 358079822532059136,
  "in_reply_to_status_id" : 358075162823897088,
  "created_at" : "2013-07-19 04:24:17 +0000",
  "in_reply_to_screen_name" : "pratiktandel",
  "in_reply_to_user_id_str" : "259246576",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/hNYGkOohwm",
      "expanded_url" : "http:\/\/flic.kr\/p\/fchwqr",
      "display_url" : "flic.kr\/p\/fchwqr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597, -122.275489 ]
  },
  "id_str" : "358074795558043650",
  "text" : "8:36pm Aerial shot of a bridge collapse http:\/\/t.co\/hNYGkOohwm",
  "id" : 358074795558043650,
  "created_at" : "2013-07-19 04:04:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 10, 17 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 18, 27 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Patrick Ewing",
      "screen_name" : "hoverbird",
      "indices" : [ 59, 69 ],
      "id_str" : "792690",
      "id" : 792690
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 74, 80 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twittermysteries",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358052803471613952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595375237, -122.2752749276 ]
  },
  "id_str" : "358061566400270338",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert @harryh @anildash What I can't understand is why @hoverbird and @couch get it even though they're not verified. #twittermysteries",
  "id" : 358061566400270338,
  "in_reply_to_status_id" : 358052803471613952,
  "created_at" : "2013-07-19 03:11:44 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Haggerty",
      "screen_name" : "bhaggs",
      "indices" : [ 0, 7 ],
      "id_str" : "1692881",
      "id" : 1692881
    }, {
      "name" : "Mike Bodge",
      "screen_name" : "mikebodge",
      "indices" : [ 59, 69 ],
      "id_str" : "19344531",
      "id" : 19344531
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "3Dclub",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358028126527295488",
  "geo" : { },
  "id_str" : "358028388889403392",
  "in_reply_to_user_id" : 1692881,
  "text" : "@bhaggs We're both seeing in 3D these days. #3Dclub PS. Hi @mikebodge!",
  "id" : 358028388889403392,
  "in_reply_to_status_id" : 358028126527295488,
  "created_at" : "2013-07-19 00:59:54 +0000",
  "in_reply_to_screen_name" : "bhaggs",
  "in_reply_to_user_id_str" : "1692881",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357930172340637696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764521679, -122.4165167381 ]
  },
  "id_str" : "357939685781278720",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun You should do a tweet survey like I did yesterday. Super interesting results.",
  "id" : 357939685781278720,
  "in_reply_to_status_id" : 357930172340637696,
  "created_at" : "2013-07-18 19:07:25 +0000",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Stump",
      "screen_name" : "joestump",
      "indices" : [ 0, 9 ],
      "id_str" : "4234581",
      "id" : 4234581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357913776881803267",
  "geo" : { },
  "id_str" : "357915168900005888",
  "in_reply_to_user_id" : 4234581,
  "text" : "@joestump I agree! I've been a snob about avoiding them for decades, but my mind has changed after this recent experience.",
  "id" : 357915168900005888,
  "in_reply_to_status_id" : 357913776881803267,
  "created_at" : "2013-07-18 17:30:00 +0000",
  "in_reply_to_screen_name" : "joestump",
  "in_reply_to_user_id_str" : "4234581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "excited",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764513297, -122.4163423945 ]
  },
  "id_str" : "357913472124059648",
  "text" : "My chiropractor and physical therapist healed my knee in 2 months! Ready to run again!!!!!! #excited",
  "id" : 357913472124059648,
  "created_at" : "2013-07-18 17:23:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephdub",
      "screen_name" : "stephdub",
      "indices" : [ 0, 9 ],
      "id_str" : "14936359",
      "id" : 14936359
    }, {
      "name" : "Helena Price",
      "screen_name" : "helena",
      "indices" : [ 10, 17 ],
      "id_str" : "19699682",
      "id" : 19699682
    }, {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "indices" : [ 18, 27 ],
      "id_str" : "22483",
      "id" : 22483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357911536494329856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7765596658, -122.4165299815 ]
  },
  "id_str" : "357912353666371585",
  "in_reply_to_user_id" : 14936359,
  "text" : "@stephdub @helena @pinwheel Ah it wasn't working when I tried it yesterday. In now!",
  "id" : 357912353666371585,
  "in_reply_to_status_id" : 357911536494329856,
  "created_at" : "2013-07-18 17:18:49 +0000",
  "in_reply_to_screen_name" : "stephdub",
  "in_reply_to_user_id_str" : "14936359",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena Price",
      "screen_name" : "helena",
      "indices" : [ 0, 7 ],
      "id_str" : "19699682",
      "id" : 19699682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357895146781683712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7875709047, -122.3956751892 ]
  },
  "id_str" : "357906061811912705",
  "in_reply_to_user_id" : 19699682,
  "text" : "@helena Curious to hear if it works for what you wanted to do. And if you have invites, invite me!",
  "id" : 357906061811912705,
  "in_reply_to_status_id" : 357895146781683712,
  "created_at" : "2013-07-18 16:53:49 +0000",
  "in_reply_to_screen_name" : "helena",
  "in_reply_to_user_id_str" : "19699682",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena Price",
      "screen_name" : "helena",
      "indices" : [ 0, 7 ],
      "id_str" : "19699682",
      "id" : 19699682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357893975392272389",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7875009443, -122.3957300109 ]
  },
  "id_str" : "357894891910606850",
  "in_reply_to_user_id" : 19699682,
  "text" : "@helena I almost sent that to you when I saw it!",
  "id" : 357894891910606850,
  "in_reply_to_status_id" : 357893975392272389,
  "created_at" : "2013-07-18 16:09:26 +0000",
  "in_reply_to_screen_name" : "helena",
  "in_reply_to_user_id_str" : "19699682",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/57GnE3t8K5",
      "expanded_url" : "http:\/\/flic.kr\/p\/fbFoz8",
      "display_url" : "flic.kr\/p\/fbFoz8"
    } ]
  },
  "geo" : { },
  "id_str" : "357706944099782656",
  "text" : "8:36pm Playing trains http:\/\/t.co\/57GnE3t8K5",
  "id" : 357706944099782656,
  "created_at" : "2013-07-18 03:42:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/ck4WitSwbc",
      "expanded_url" : "http:\/\/flic.kr\/p\/fbUeWy",
      "display_url" : "flic.kr\/p\/fbUeWy"
    } ]
  },
  "geo" : { },
  "id_str" : "357690458396295168",
  "text" : "And the unicorn said \"hee-haw!\" http:\/\/t.co\/ck4WitSwbc",
  "id" : 357690458396295168,
  "created_at" : "2013-07-18 02:37:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357670879905320960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7891550518, -122.4018093808 ]
  },
  "id_str" : "357674992504274946",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall 11!",
  "id" : 357674992504274946,
  "in_reply_to_status_id" : 357670879905320960,
  "created_at" : "2013-07-18 01:35:38 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7774107643, -122.4164460787 ]
  },
  "id_str" : "357673664268865536",
  "text" : "A service that mildly electrocutes you when you tweet something that has already been tweeted by someone else, character-for-character.",
  "id" : 357673664268865536,
  "created_at" : "2013-07-18 01:30:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7790901406, -122.4143816369 ]
  },
  "id_str" : "357672884044435456",
  "text" : "just reading my twttr",
  "id" : 357672884044435456,
  "created_at" : "2013-07-18 01:27:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Cooney",
      "screen_name" : "DeanCooney",
      "indices" : [ 0, 11 ],
      "id_str" : "547064680",
      "id" : 547064680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357669869988225026",
  "in_reply_to_user_id" : 547064680,
  "text" : "@DeanCooney Changed my icon on a whim\u2026 I was getting tired of the illustration.",
  "id" : 357669869988225026,
  "created_at" : "2013-07-18 01:15:16 +0000",
  "in_reply_to_screen_name" : "DeanCooney",
  "in_reply_to_user_id_str" : "547064680",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/gLPyw54OlB",
      "expanded_url" : "http:\/\/bit.ly\/buster-ratings",
      "display_url" : "bit.ly\/buster-ratings"
    }, {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ymBGP7vtOs",
      "expanded_url" : "http:\/\/bit.ly\/rate-buster",
      "display_url" : "bit.ly\/rate-buster"
    } ]
  },
  "geo" : { },
  "id_str" : "357667929485094912",
  "text" : "76% of people who follow me would recommend following me, and more fun stats: http:\/\/t.co\/gLPyw54OlB Take my survey! http:\/\/t.co\/ymBGP7vtOs",
  "id" : 357667929485094912,
  "created_at" : "2013-07-18 01:07:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357649861258133504",
  "geo" : { },
  "id_str" : "357656952064581632",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb You'll see them soon!",
  "id" : 357656952064581632,
  "in_reply_to_status_id" : 357649861258133504,
  "created_at" : "2013-07-18 00:23:56 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Newman",
      "screen_name" : "dannynewman",
      "indices" : [ 3, 15 ],
      "id_str" : "8273",
      "id" : 8273
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 19, 26 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/YSILPCz2DU",
      "expanded_url" : "https:\/\/twitter.com\/intent\/tweet?text=follow%20dannynewman",
      "display_url" : "twitter.com\/intent\/tweet?t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "357656604289671168",
  "text" : "RT @dannynewman: . @buster how many people can i get to do this: https:\/\/t.co\/YSILPCz2DU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 2, 9 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/YSILPCz2DU",
        "expanded_url" : "https:\/\/twitter.com\/intent\/tweet?text=follow%20dannynewman",
        "display_url" : "twitter.com\/intent\/tweet?t\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "357651026620317697",
    "geo" : { },
    "id_str" : "357651191204823040",
    "in_reply_to_user_id" : 2185,
    "text" : ". @buster how many people can i get to do this: https:\/\/t.co\/YSILPCz2DU",
    "id" : 357651191204823040,
    "in_reply_to_status_id" : 357651026620317697,
    "created_at" : "2013-07-18 00:01:03 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Danny Newman",
      "screen_name" : "dannynewman",
      "protected" : false,
      "id_str" : "8273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2992738535\/c5a92b4d7809bafbcfb6afe8333fe805_normal.jpeg",
      "id" : 8273,
      "verified" : false
    }
  },
  "id" : 357656604289671168,
  "created_at" : "2013-07-18 00:22:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "benward",
      "indices" : [ 0, 8 ],
      "id_str" : "12249",
      "id" : 12249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357651104328192000",
  "geo" : { },
  "id_str" : "357651312713801728",
  "in_reply_to_user_id" : 12249,
  "text" : "@benward Ah man, I tried intent\/dm and intent\/directmessage in futility before resorting to tweet. Thanks!",
  "id" : 357651312713801728,
  "in_reply_to_status_id" : 357651104328192000,
  "created_at" : "2013-07-18 00:01:32 +0000",
  "in_reply_to_screen_name" : "benward",
  "in_reply_to_user_id_str" : "12249",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Newman",
      "screen_name" : "dannynewman",
      "indices" : [ 0, 12 ],
      "id_str" : "8273",
      "id" : 8273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357650221502701569",
  "geo" : { },
  "id_str" : "357651026620317697",
  "in_reply_to_user_id" : 8273,
  "text" : "@dannynewman I think so!",
  "id" : 357651026620317697,
  "in_reply_to_status_id" : 357650221502701569,
  "created_at" : "2013-07-18 00:00:24 +0000",
  "in_reply_to_screen_name" : "dannynewman",
  "in_reply_to_user_id_str" : "8273",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357649378405650432",
  "geo" : { },
  "id_str" : "357650064723812352",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake Hah. At first I tried to tweet \"DM me\" and of course that didn't work quite right.",
  "id" : 357650064723812352,
  "in_reply_to_status_id" : 357649378405650432,
  "created_at" : "2013-07-17 23:56:34 +0000",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Newman",
      "screen_name" : "dannynewman",
      "indices" : [ 0, 12 ],
      "id_str" : "8273",
      "id" : 8273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357649482306953217",
  "geo" : { },
  "id_str" : "357649775077769219",
  "in_reply_to_user_id" : 8273,
  "text" : "@dannynewman Both work.",
  "id" : 357649775077769219,
  "in_reply_to_status_id" : 357649482306953217,
  "created_at" : "2013-07-17 23:55:25 +0000",
  "in_reply_to_screen_name" : "dannynewman",
  "in_reply_to_user_id_str" : "8273",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357649466364411904",
  "geo" : { },
  "id_str" : "357649743444324352",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Busted searching for buster boobs.",
  "id" : 357649743444324352,
  "in_reply_to_status_id" : 357649466364411904,
  "created_at" : "2013-07-17 23:55:18 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bianca L. St.Louis",
      "screen_name" : "beLaurie",
      "indices" : [ 0, 9 ],
      "id_str" : "92143477",
      "id" : 92143477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357647326816382976",
  "geo" : { },
  "id_str" : "357647492185198592",
  "in_reply_to_user_id" : 92143477,
  "text" : "@beLaurie Curiosity!",
  "id" : 357647492185198592,
  "in_reply_to_status_id" : 357647326816382976,
  "created_at" : "2013-07-17 23:46:21 +0000",
  "in_reply_to_screen_name" : "beLaurie",
  "in_reply_to_user_id_str" : "92143477",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/MbY8Qwy6Ha",
      "expanded_url" : "https:\/\/twitter.com\/intent\/tweet?text=dm%20buster%20",
      "display_url" : "twitter.com\/intent\/tweet?t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "357647065217646593",
  "text" : "I dare you to DM me. https:\/\/t.co\/MbY8Qwy6Ha",
  "id" : 357647065217646593,
  "created_at" : "2013-07-17 23:44:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 12, 21 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Patrick Keane",
      "screen_name" : "phkeane",
      "indices" : [ 31, 39 ],
      "id_str" : "3661961",
      "id" : 3661961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/RpPimCT8SS",
      "expanded_url" : "https:\/\/support.google.com\/googleplay\/answer\/134336?hl=en",
      "display_url" : "support.google.com\/googleplay\/ans\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "357636860211765248",
  "text" : "Yes pls! RT @arainert Like. RT @phkeane Google Play's 15 minute app return policy is very smart. Apple better copy. https:\/\/t.co\/RpPimCT8SS",
  "id" : 357636860211765248,
  "created_at" : "2013-07-17 23:04:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetaversary",
      "indices" : [ 10, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/iKB2bVVhhO",
      "expanded_url" : "https:\/\/bitly.com\/rate-buster",
      "display_url" : "bitly.com\/rate-buster"
    } ]
  },
  "geo" : { },
  "id_str" : "357603772349943808",
  "text" : "On my 7yr #tweetaversary, here's a survey so you can chime in on how you like my tweets: https:\/\/t.co\/iKB2bVVhhO (results will be posted)",
  "id" : 357603772349943808,
  "created_at" : "2013-07-17 20:52:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magic Recs",
      "screen_name" : "MagicRecs",
      "indices" : [ 51, 61 ],
      "id_str" : "1270746139",
      "id" : 1270746139
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 91, 98 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/60UJKCq4bK",
      "expanded_url" : "http:\/\/bit.ly\/1dFqb36",
      "display_url" : "bit.ly\/1dFqb36"
    } ]
  },
  "geo" : { },
  "id_str" : "357600734965022720",
  "text" : "How to scoop any organization, with our little pal @magicrecs: http:\/\/t.co\/60UJKCq4bK \/via @isaach",
  "id" : 357600734965022720,
  "created_at" : "2013-07-17 20:40:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Calabresi",
      "screen_name" : "calabresi",
      "indices" : [ 0, 10 ],
      "id_str" : "31049555",
      "id" : 31049555
    }, {
      "name" : "Todd Gehman",
      "screen_name" : "pugetive",
      "indices" : [ 83, 92 ],
      "id_str" : "16355060",
      "id" : 16355060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357580076226854913",
  "geo" : { },
  "id_str" : "357586018817425409",
  "in_reply_to_user_id" : 31049555,
  "text" : "@calabresi I think I did, but they were a little too country for my tastes. :) \/cc @pugetive",
  "id" : 357586018817425409,
  "in_reply_to_status_id" : 357580076226854913,
  "created_at" : "2013-07-17 19:42:05 +0000",
  "in_reply_to_screen_name" : "calabresi",
  "in_reply_to_user_id_str" : "31049555",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Gehman",
      "screen_name" : "pugetive",
      "indices" : [ 126, 135 ],
      "id_str" : "16355060",
      "id" : 16355060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/T7rMGqz3Dn",
      "expanded_url" : "http:\/\/bit.ly\/13jzgwA",
      "display_url" : "bit.ly\/13jzgwA"
    } ]
  },
  "geo" : { },
  "id_str" : "357572664979755008",
  "text" : "My 1st tweet was 7 years ago today: \"Thinking about heading out to Rendezvous to see Todd's band.\" http:\/\/t.co\/T7rMGqz3Dn \/cc @pugetive\u00A0",
  "id" : 357572664979755008,
  "created_at" : "2013-07-17 18:49:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pickle and Jam",
      "screen_name" : "pickleandjam",
      "indices" : [ 0, 13 ],
      "id_str" : "599601895",
      "id" : 599601895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357561041456087040",
  "geo" : { },
  "id_str" : "357567357431988224",
  "in_reply_to_user_id" : 599601895,
  "text" : "@pickleandjam Yay!",
  "id" : 357567357431988224,
  "in_reply_to_status_id" : 357561041456087040,
  "created_at" : "2013-07-17 18:27:55 +0000",
  "in_reply_to_screen_name" : "pickleandjam",
  "in_reply_to_user_id_str" : "599601895",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Capecelatro",
      "screen_name" : "jcap49",
      "indices" : [ 0, 7 ],
      "id_str" : "78733683",
      "id" : 78733683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357521377751859203",
  "geo" : { },
  "id_str" : "357523308973002752",
  "in_reply_to_user_id" : 78733683,
  "text" : "@jcap49 Thanks!",
  "id" : 357523308973002752,
  "in_reply_to_status_id" : 357521377751859203,
  "created_at" : "2013-07-17 15:32:53 +0000",
  "in_reply_to_screen_name" : "jcap49",
  "in_reply_to_user_id_str" : "78733683",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Potluck",
      "screen_name" : "potluck",
      "indices" : [ 11, 19 ],
      "id_str" : "1395445934",
      "id" : 1395445934
    }, {
      "name" : "Potluck",
      "screen_name" : "potluck",
      "indices" : [ 43, 51 ],
      "id_str" : "1395445934",
      "id" : 1395445934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/iJGUq80ge6",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/potluck\/id669745934",
      "display_url" : "itunes.apple.com\/us\/app\/potluck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "357520710907863042",
  "text" : "Get it! RT @potluck: It's here folks! Meet @potluck for iOS: https:\/\/t.co\/iJGUq80ge6",
  "id" : 357520710907863042,
  "created_at" : "2013-07-17 15:22:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mikedariano",
      "screen_name" : "mikedariano",
      "indices" : [ 34, 46 ],
      "id_str" : "14890398",
      "id" : 14890398
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 87, 94 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/ODeggIzGIa",
      "expanded_url" : "http:\/\/wp.me\/pJMhC-BN",
      "display_url" : "wp.me\/pJMhC-BN"
    } ]
  },
  "in_reply_to_status_id_str" : "357469861288493059",
  "geo" : { },
  "id_str" : "357516775950258176",
  "in_reply_to_user_id" : 14890398,
  "text" : "Said better than when I tried: RT @mikedariano: Death Bed Point Challenge! inspired by @buster http:\/\/t.co\/ODeggIzGIa",
  "id" : 357516775950258176,
  "in_reply_to_status_id" : 357469861288493059,
  "created_at" : "2013-07-17 15:06:56 +0000",
  "in_reply_to_screen_name" : "mikedariano",
  "in_reply_to_user_id_str" : "14890398",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mikedariano",
      "screen_name" : "mikedariano",
      "indices" : [ 0, 12 ],
      "id_str" : "14890398",
      "id" : 14890398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357469861288493059",
  "geo" : { },
  "id_str" : "357516549654974465",
  "in_reply_to_user_id" : 14890398,
  "text" : "@mikedariano Nicely said! You definitely captured the spirit of what I was trying to say.",
  "id" : 357516549654974465,
  "in_reply_to_status_id" : 357469861288493059,
  "created_at" : "2013-07-17 15:06:02 +0000",
  "in_reply_to_screen_name" : "mikedariano",
  "in_reply_to_user_id_str" : "14890398",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ifihadglass",
      "indices" : [ 52, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357380286578827265",
  "text" : "Turn-by-turn directions for finding life's meaning. #ifihadglass",
  "id" : 357380286578827265,
  "created_at" : "2013-07-17 06:04:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dreams",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357369065653796864",
  "text" : "Some day I want to kickstarter an open source choose your own adventure self help book, or something. #dreams",
  "id" : 357369065653796864,
  "created_at" : "2013-07-17 05:19:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "putabirdonit",
      "indices" : [ 35, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357360664571940864",
  "geo" : { },
  "id_str" : "357362934839652353",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey THREEBIRDEE to be precise. #putabirdonit",
  "id" : 357362934839652353,
  "in_reply_to_status_id" : 357360664571940864,
  "created_at" : "2013-07-17 04:55:37 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/iM1KFL96Sj",
      "expanded_url" : "http:\/\/flic.kr\/p\/fbmuuN",
      "display_url" : "flic.kr\/p\/fbmuuN"
    } ]
  },
  "geo" : { },
  "id_str" : "357359995374936065",
  "text" : "8:36pm Working on a new professional avatar for myself http:\/\/t.co\/iM1KFL96Sj",
  "id" : 357359995374936065,
  "created_at" : "2013-07-17 04:43:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 26, 33 ],
      "id_str" : "47",
      "id" : 47
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Xt4fXEXAt8",
      "expanded_url" : "http:\/\/laughingmeme.org\/2013\/07\/16\/surviving-being-senior-management\/",
      "display_url" : "laughingmeme.org\/2013\/07\/16\/sur\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "357320263030947841",
  "geo" : { },
  "id_str" : "357327201655472129",
  "in_reply_to_user_id" : 47,
  "text" : "I love this post -&gt; RT @kellan: New blog post: \"Surviving being senior (tech) management\" http:\/\/t.co\/Xt4fXEXAt8",
  "id" : 357327201655472129,
  "in_reply_to_status_id" : 357320263030947841,
  "created_at" : "2013-07-17 02:33:38 +0000",
  "in_reply_to_screen_name" : "kellan",
  "in_reply_to_user_id_str" : "47",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 0, 7 ],
      "id_str" : "47",
      "id" : 47
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357320263030947841",
  "geo" : { },
  "id_str" : "357326941994483712",
  "in_reply_to_user_id" : 47,
  "text" : "@kellan Yer smrt.",
  "id" : 357326941994483712,
  "in_reply_to_status_id" : 357320263030947841,
  "created_at" : "2013-07-17 02:32:36 +0000",
  "in_reply_to_screen_name" : "kellan",
  "in_reply_to_user_id_str" : "47",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 93, 100 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/xs6I58R5QD",
      "expanded_url" : "http:\/\/www.theonion.com\/articles\/mans-idea-for-tweet-just-pops-into-his-mind-almost,33132\/",
      "display_url" : "theonion.com\/articles\/mans-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "357312507838337024",
  "text" : "Man\u2019s Idea For Tweet Just Pops Into His Mind Almost Fully Formed http:\/\/t.co\/xs6I58R5QD \/via @eismcc",
  "id" : 357312507838337024,
  "created_at" : "2013-07-17 01:35:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Takei",
      "screen_name" : "GeorgeTakei",
      "indices" : [ 3, 15 ],
      "id_str" : "237845487",
      "id" : 237845487
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GeorgeTakei\/status\/357229677640814594\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/Jjh1igJTOq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPUif8dCEAEHI6t.jpg",
      "id_str" : "357229677645008897",
      "id" : 357229677645008897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPUif8dCEAEHI6t.jpg",
      "sizes" : [ {
        "h" : 460,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 246,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 434,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Jjh1igJTOq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357309127254487042",
  "text" : "RT @GeorgeTakei: A prescription for a culture war. http:\/\/t.co\/Jjh1igJTOq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GeorgeTakei\/status\/357229677640814594\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/Jjh1igJTOq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BPUif8dCEAEHI6t.jpg",
        "id_str" : "357229677645008897",
        "id" : 357229677645008897,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPUif8dCEAEHI6t.jpg",
        "sizes" : [ {
          "h" : 460,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 246,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 460,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Jjh1igJTOq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357229677640814594",
    "text" : "A prescription for a culture war. http:\/\/t.co\/Jjh1igJTOq",
    "id" : 357229677640814594,
    "created_at" : "2013-07-16 20:06:06 +0000",
    "user" : {
      "name" : "George Takei",
      "screen_name" : "GeorgeTakei",
      "protected" : false,
      "id_str" : "237845487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/414913325667852288\/eIwHqqiF_normal.png",
      "id" : 237845487,
      "verified" : true
    }
  },
  "id" : 357309127254487042,
  "created_at" : "2013-07-17 01:21:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357198116069445633",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries Awesome awesome stuff.",
  "id" : 357198116069445633,
  "created_at" : "2013-07-16 18:00:41 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alex choi \u2744\uFE0F\u2615\uFE0F",
      "screen_name" : "xc",
      "indices" : [ 0, 3 ],
      "id_str" : "26233",
      "id" : 26233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357010673957478402",
  "geo" : { },
  "id_str" : "357014871897935874",
  "in_reply_to_user_id" : 26233,
  "text" : "@xc Won't they all drive into tightly packed self-valeting lots somewhere to charge\/wash\/get new tabs?",
  "id" : 357014871897935874,
  "in_reply_to_status_id" : 357010673957478402,
  "created_at" : "2013-07-16 05:52:33 +0000",
  "in_reply_to_screen_name" : "xc",
  "in_reply_to_user_id_str" : "26233",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/uhz3gjK4Jb",
      "expanded_url" : "http:\/\/flic.kr\/p\/fathEt",
      "display_url" : "flic.kr\/p\/fathEt"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859694, -122.275498 ]
  },
  "id_str" : "357006630031855616",
  "text" : "8:36pm Niko was showing me how he puts rings on by shaking them down http:\/\/t.co\/uhz3gjK4Jb",
  "id" : 357006630031855616,
  "created_at" : "2013-07-16 05:19:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    }, {
      "name" : "Om Malik",
      "screen_name" : "om",
      "indices" : [ 11, 14 ],
      "id_str" : "989",
      "id" : 989
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 15, 23 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356863170939322369",
  "geo" : { },
  "id_str" : "356863473847771136",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler @om @twitter Yeah! I'd like to call it \"Twitter's Believe It or Not\" and have a wax museum side show.",
  "id" : 356863473847771136,
  "in_reply_to_status_id" : 356863170939322369,
  "created_at" : "2013-07-15 19:50:57 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Om Malik",
      "screen_name" : "om",
      "indices" : [ 92, 95 ],
      "id_str" : "989",
      "id" : 989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/B6220kTUIe",
      "expanded_url" : "http:\/\/Twitter.com",
      "display_url" : "Twitter.com"
    }, {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/Ksw4OgggwL",
      "expanded_url" : "http:\/\/gigaom.com\/2006\/07\/15\/valleys-all-twttr\/",
      "display_url" : "gigaom.com\/2006\/07\/15\/val\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "356853667279802368",
  "text" : "Happy 7th birthday, http:\/\/t.co\/B6220kTUIe! Here's the first blog post about the launch, by @om: http:\/\/t.co\/Ksw4OgggwL",
  "id" : 356853667279802368,
  "created_at" : "2013-07-15 19:11:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 0, 12 ],
      "id_str" : "195863654",
      "id" : 195863654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356465092746940416",
  "geo" : { },
  "id_str" : "356817492204724226",
  "in_reply_to_user_id" : 195863654,
  "text" : "@marihuertas Exactly. Every channel needs to be cleaned out every once in a while.",
  "id" : 356817492204724226,
  "in_reply_to_status_id" : 356465092746940416,
  "created_at" : "2013-07-15 16:48:14 +0000",
  "in_reply_to_screen_name" : "marihuertas",
  "in_reply_to_user_id_str" : "195863654",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356465043677777920",
  "geo" : { },
  "id_str" : "356817262663053312",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Yeah, this could be a fun side project. Thinking about it...",
  "id" : 356817262663053312,
  "in_reply_to_status_id" : 356465043677777920,
  "created_at" : "2013-07-15 16:47:19 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    }, {
      "name" : "Ryan Block",
      "screen_name" : "ryan",
      "indices" : [ 5, 10 ],
      "id_str" : "862681",
      "id" : 862681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356464749476708353",
  "geo" : { },
  "id_str" : "356817124892749826",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap @ryan There's an inflection point at a certain following number that forces you to let go of seeing every tweet. I probably see 1%.",
  "id" : 356817124892749826,
  "in_reply_to_status_id" : 356464749476708353,
  "created_at" : "2013-07-15 16:46:46 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356787015615905793",
  "text" : "RT @elonmusk: Will publish Hyperloop alpha design by Aug 12. Critical feedback for improvements would be much appreciated.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "356776740409974785",
    "text" : "Will publish Hyperloop alpha design by Aug 12. Critical feedback for improvements would be much appreciated.",
    "id" : 356776740409974785,
    "created_at" : "2013-07-15 14:06:18 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/420314816444502016\/xj5TnUsx_normal.jpeg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 356787015615905793,
  "created_at" : "2013-07-15 14:47:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356657562764054528",
  "geo" : { },
  "id_str" : "356659825146474497",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates There's something pleasant about morbidity.",
  "id" : 356659825146474497,
  "in_reply_to_status_id" : 356657562764054528,
  "created_at" : "2013-07-15 06:21:43 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356658208275836930",
  "geo" : { },
  "id_str" : "356659417678221312",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean Minus the crawling out of the television bit.",
  "id" : 356659417678221312,
  "in_reply_to_status_id" : 356658208275836930,
  "created_at" : "2013-07-15 06:20:06 +0000",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dollars",
      "screen_name" : "theDoug",
      "indices" : [ 0, 8 ],
      "id_str" : "36043",
      "id" : 36043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356658817280389121",
  "geo" : { },
  "id_str" : "356659297213620224",
  "in_reply_to_user_id" : 36043,
  "text" : "@theDoug Looks like it is dead... I would've signed up.",
  "id" : 356659297213620224,
  "in_reply_to_status_id" : 356658817280389121,
  "created_at" : "2013-07-15 06:19:37 +0000",
  "in_reply_to_screen_name" : "theDoug",
  "in_reply_to_user_id_str" : "36043",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356657469663092736",
  "text" : "A weekly email of obituaries about people who died at your age.",
  "id" : 356657469663092736,
  "created_at" : "2013-07-15 06:12:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356640049258983424",
  "geo" : { },
  "id_str" : "356649503127900160",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach So rad. But what does it *mean*?",
  "id" : 356649503127900160,
  "in_reply_to_status_id" : 356640049258983424,
  "created_at" : "2013-07-15 05:40:42 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/DzW2ooCt1M",
      "expanded_url" : "http:\/\/flic.kr\/p\/f9M1zV",
      "display_url" : "flic.kr\/p\/f9M1zV"
    } ]
  },
  "geo" : { },
  "id_str" : "356648657568808960",
  "text" : "8:36pm Mini Benson family reunion: sis, niece, cousin, mom.  http:\/\/t.co\/DzW2ooCt1M",
  "id" : 356648657568808960,
  "created_at" : "2013-07-15 05:37:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "newhat",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/ee35qqCjjk",
      "expanded_url" : "http:\/\/flic.kr\/p\/f9AYoe",
      "display_url" : "flic.kr\/p\/f9AYoe"
    } ]
  },
  "geo" : { },
  "id_str" : "356559170528481281",
  "text" : "Niko's day is made #newhat http:\/\/t.co\/ee35qqCjjk",
  "id" : 356559170528481281,
  "created_at" : "2013-07-14 23:41:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Block",
      "screen_name" : "ryan",
      "indices" : [ 27, 32 ],
      "id_str" : "862681",
      "id" : 862681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356464170054582272",
  "text" : "Ooh I might do this too RT @ryan: It's been 6+ years, I'm finally going to reboot everyone I'm following on Twitter. It's not you, it's me!",
  "id" : 356464170054582272,
  "created_at" : "2013-07-14 17:24:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356299952147800064",
  "text" : "If truth, the whole truth, and nothing but the truth isn't available, that doesn't mean you should trust 2nd place.",
  "id" : 356299952147800064,
  "created_at" : "2013-07-14 06:31:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Od0WVqKplG",
      "expanded_url" : "http:\/\/flic.kr\/p\/f9dku9",
      "display_url" : "flic.kr\/p\/f9dku9"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.813816, -122.246239 ]
  },
  "id_str" : "356256374394585088",
  "text" : "8:36pm Delicious dinner and drawing session at Boot and Shoe with Mom, Kristy, Ryan, and Adelyn http:\/\/t.co\/Od0WVqKplG",
  "id" : 356256374394585088,
  "created_at" : "2013-07-14 03:38:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hunter Walk",
      "screen_name" : "hunterwalk",
      "indices" : [ 3, 14 ],
      "id_str" : "46063",
      "id" : 46063
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hunterwalk\/status\/356084561433726976\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/yJCQZlOwTa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPERBaKCEAAdx7G.jpg",
      "id_str" : "356084561437921280",
      "id" : 356084561437921280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPERBaKCEAAdx7G.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 804,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      } ],
      "display_url" : "pic.twitter.com\/yJCQZlOwTa"
    } ],
    "hashtags" : [ {
      "text" : "YxYY",
      "indices" : [ 77, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356089160408383491",
  "text" : "RT @hunterwalk: Twitter Fail Whale artist Yiying Liu created \"Win Whale\" for #YxYY making this my best event t-shirt evah! http:\/\/t.co\/yJCQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/hunterwalk\/status\/356084561433726976\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/yJCQZlOwTa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BPERBaKCEAAdx7G.jpg",
        "id_str" : "356084561437921280",
        "id" : 356084561437921280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPERBaKCEAAdx7G.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 764
        }, {
          "h" : 804,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 764
        } ],
        "display_url" : "pic.twitter.com\/yJCQZlOwTa"
      } ],
      "hashtags" : [ {
        "text" : "YxYY",
        "indices" : [ 61, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "356084561433726976",
    "text" : "Twitter Fail Whale artist Yiying Liu created \"Win Whale\" for #YxYY making this my best event t-shirt evah! http:\/\/t.co\/yJCQZlOwTa",
    "id" : 356084561433726976,
    "created_at" : "2013-07-13 16:15:49 +0000",
    "user" : {
      "name" : "Hunter Walk",
      "screen_name" : "hunterwalk",
      "protected" : false,
      "id_str" : "46063",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3530636661\/448f950491b7c174df124e6ce8d7ba79_normal.png",
      "id" : 46063,
      "verified" : false
    }
  },
  "id" : 356089160408383491,
  "created_at" : "2013-07-13 16:34:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/N0hK5axBCu",
      "expanded_url" : "http:\/\/www.quora.com\/Neuroscience-1\/Where-is-our-consciousness-Is-our-consciousness-a-thing-that-has-mass-matter",
      "display_url" : "quora.com\/Neuroscience-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "356081778760482818",
  "text" : "\"A hurricane is a metaphor for consciousness, both being dynamic systems operating on top of a physical substrate.\" http:\/\/t.co\/N0hK5axBCu",
  "id" : 356081778760482818,
  "created_at" : "2013-07-13 16:04:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/upebNj9lQ6",
      "expanded_url" : "http:\/\/flic.kr\/p\/f8zA7U",
      "display_url" : "flic.kr\/p\/f8zA7U"
    } ]
  },
  "geo" : { },
  "id_str" : "355910288580681729",
  "text" : "8:36pm Adelyn and Niko here take a pillow fight break http:\/\/t.co\/upebNj9lQ6",
  "id" : 355910288580681729,
  "created_at" : "2013-07-13 04:43:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 0, 10 ],
      "id_str" : "1771141",
      "id" : 1771141
    }, {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 11, 17 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 18, 27 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355770968645439488",
  "geo" : { },
  "id_str" : "355789379685453824",
  "in_reply_to_user_id" : 1771141,
  "text" : "@samantham @joshc @RickWebb YAY!!!!!",
  "id" : 355789379685453824,
  "in_reply_to_status_id" : 355770968645439488,
  "created_at" : "2013-07-12 20:42:53 +0000",
  "in_reply_to_screen_name" : "samantham",
  "in_reply_to_user_id_str" : "1771141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355749000340709376",
  "geo" : { },
  "id_str" : "355749187368919042",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler Yes! Pick a day any day.",
  "id" : 355749187368919042,
  "in_reply_to_status_id" : 355749000340709376,
  "created_at" : "2013-07-12 18:03:10 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/7bNHUC0QcY",
      "expanded_url" : "https:\/\/twitter.com\/buster\/status\/355516073434546177",
      "display_url" : "twitter.com\/buster\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "355748256640274436",
  "geo" : { },
  "id_str" : "355748453437030401",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler Yup! https:\/\/t.co\/7bNHUC0QcY",
  "id" : 355748453437030401,
  "in_reply_to_status_id" : 355748256640274436,
  "created_at" : "2013-07-12 18:00:15 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    }, {
      "name" : "Emily Badger",
      "screen_name" : "emilymbadger",
      "indices" : [ 17, 30 ],
      "id_str" : "253152109",
      "id" : 253152109
    }, {
      "name" : "Jake Kastrenakes",
      "screen_name" : "jake_k",
      "indices" : [ 31, 38 ],
      "id_str" : "8009142",
      "id" : 8009142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355703012368449537",
  "geo" : { },
  "id_str" : "355707008235741188",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall @emilymbadger @jake_k Just finished the book \"Connectome\" which explains how this works! Really cool stuff.",
  "id" : 355707008235741188,
  "in_reply_to_status_id" : 355703012368449537,
  "created_at" : "2013-07-12 15:15:34 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Kontny",
      "screen_name" : "natekontny",
      "indices" : [ 124, 135 ],
      "id_str" : "17386551",
      "id" : 17386551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/35mhzVHr7p",
      "expanded_url" : "http:\/\/www.quora.com\/Investing\/I-have-5-What-is-the-best-way-to-invest-and-grow-my-money\/answer\/Visakan-Veerasamy?srid=tPl&share=1",
      "display_url" : "quora.com\/Investing\/I-ha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "355706361977380866",
  "text" : "High school kids answer: \"What would you do to earn money if all you had was $5 and two hours?\" http:\/\/t.co\/35mhzVHr7p \/via @natekontny",
  "id" : 355706361977380866,
  "created_at" : "2013-07-12 15:13:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The iOS Feed",
      "screen_name" : "iOSFeed",
      "indices" : [ 3, 11 ],
      "id_str" : "1583751571",
      "id" : 1583751571
    }, {
      "name" : "betaworks",
      "screen_name" : "betaworks",
      "indices" : [ 56, 66 ],
      "id_str" : "14445325",
      "id" : 14445325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/y5dzsihj9W",
      "expanded_url" : "http:\/\/www.wired.com\/design\/2013\/07\/can-quit-playing-dots-heres-why\/",
      "display_url" : "wired.com\/design\/2013\/07\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "355689206699397120",
  "text" : "RT @iOSFeed: 4 design secrets behind the game Dots from @betaworks : http:\/\/t.co\/y5dzsihj9W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "betaworks",
        "screen_name" : "betaworks",
        "indices" : [ 43, 53 ],
        "id_str" : "14445325",
        "id" : 14445325
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/y5dzsihj9W",
        "expanded_url" : "http:\/\/www.wired.com\/design\/2013\/07\/can-quit-playing-dots-heres-why\/",
        "display_url" : "wired.com\/design\/2013\/07\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "355672446717792256",
    "text" : "4 design secrets behind the game Dots from @betaworks : http:\/\/t.co\/y5dzsihj9W",
    "id" : 355672446717792256,
    "created_at" : "2013-07-12 12:58:14 +0000",
    "user" : {
      "name" : "The iOS Feed",
      "screen_name" : "iOSFeed",
      "protected" : false,
      "id_str" : "1583751571",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000116477406\/17aef16f5c173a4b37d6c8f66ef98d66_normal.png",
      "id" : 1583751571,
      "verified" : false
    }
  },
  "id" : 355689206699397120,
  "created_at" : "2013-07-12 14:04:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daedelus",
      "screen_name" : "daedelus_music",
      "indices" : [ 3, 18 ],
      "id_str" : "17229626",
      "id" : 17229626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355666853147844608",
  "text" : "RT @daedelus_music: Most rapper's names are weak nowadays. Mozart's baptized name was Johannes Chrysostomus Wolfgangus Theophilus Mozart. s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "355227572809904130",
    "text" : "Most rapper's names are weak nowadays. Mozart's baptized name was Johannes Chrysostomus Wolfgangus Theophilus Mozart. seriously.",
    "id" : 355227572809904130,
    "created_at" : "2013-07-11 07:30:27 +0000",
    "user" : {
      "name" : "Daedelus",
      "screen_name" : "daedelus_music",
      "protected" : false,
      "id_str" : "17229626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453717706152226816\/_JnuS654_normal.jpeg",
      "id" : 17229626,
      "verified" : true
    }
  },
  "id" : 355666853147844608,
  "created_at" : "2013-07-12 12:36:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Newman",
      "screen_name" : "dannynewman",
      "indices" : [ 0, 12 ],
      "id_str" : "8273",
      "id" : 8273
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sharknado",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355547201126137856",
  "geo" : { },
  "id_str" : "355550461715165186",
  "in_reply_to_user_id" : 8273,
  "text" : "@dannynewman Are you telling me #sharknado on a plane isn't a thing yet?",
  "id" : 355550461715165186,
  "in_reply_to_status_id" : 355547201126137856,
  "created_at" : "2013-07-12 04:53:30 +0000",
  "in_reply_to_screen_name" : "dannynewman",
  "in_reply_to_user_id_str" : "8273",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/qYytBQSVD4",
      "expanded_url" : "http:\/\/flic.kr\/p\/f7G6Fc",
      "display_url" : "flic.kr\/p\/f7G6Fc"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859602, -122.275489 ]
  },
  "id_str" : "355531593617641473",
  "text" : "8:36pm Kellianne wanted some alone time so it's dude dinner http:\/\/t.co\/qYytBQSVD4",
  "id" : 355531593617641473,
  "created_at" : "2013-07-12 03:38:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355525186814087169",
  "text" : "Really hungry for some foodnado.",
  "id" : 355525186814087169,
  "created_at" : "2013-07-12 03:13:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 11, 22 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sharknado",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/EXPsEwAiOs",
      "expanded_url" : "http:\/\/flic.kr\/p\/f7UJXq",
      "display_url" : "flic.kr\/p\/f7UJXq"
    } ]
  },
  "geo" : { },
  "id_str" : "355516073434546177",
  "text" : "Looks like @nikobenson and I go to the same stylist #sharknado http:\/\/t.co\/EXPsEwAiOs",
  "id" : 355516073434546177,
  "created_at" : "2013-07-12 02:36:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dom Sagolla",
      "screen_name" : "dom",
      "indices" : [ 25, 29 ],
      "id_str" : "21",
      "id" : 21
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/AZsc0Aaq7U",
      "expanded_url" : "http:\/\/www.140characters.com\/2009\/01\/30\/how-twitter-was-born\/",
      "display_url" : "140characters.com\/2009\/01\/30\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "355487220297240576",
  "text" : "How Twitter Was Born, by @dom. Nice back story: http:\/\/t.co\/AZsc0Aaq7U #hackweek",
  "id" : 355487220297240576,
  "created_at" : "2013-07-12 00:42:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena Price",
      "screen_name" : "helena",
      "indices" : [ 0, 7 ],
      "id_str" : "19699682",
      "id" : 19699682
    }, {
      "name" : "Aaron Durand",
      "screen_name" : "everydaydude",
      "indices" : [ 8, 21 ],
      "id_str" : "14715999",
      "id" : 14715999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355458271999565825",
  "geo" : { },
  "id_str" : "355480260374048768",
  "in_reply_to_user_id" : 19699682,
  "text" : "@helena @everydaydude Mission accepted. Shall we get lunch in the Commons sometime next week, Aaron? My treat.",
  "id" : 355480260374048768,
  "in_reply_to_status_id" : 355458271999565825,
  "created_at" : "2013-07-12 00:14:33 +0000",
  "in_reply_to_screen_name" : "helena",
  "in_reply_to_user_id_str" : "19699682",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena Price",
      "screen_name" : "helena",
      "indices" : [ 24, 31 ],
      "id_str" : "19699682",
      "id" : 19699682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/05Nt1k6yCy",
      "expanded_url" : "http:\/\/flic.kr\/p\/f7yt7F",
      "display_url" : "flic.kr\/p\/f7yt7F"
    } ]
  },
  "geo" : { },
  "id_str" : "355453030684037120",
  "text" : "Finally met the amazing @helena! http:\/\/t.co\/05Nt1k6yCy",
  "id" : 355453030684037120,
  "created_at" : "2013-07-11 22:26:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/U4nZCC45pS",
      "expanded_url" : "https:\/\/twitter.com\/jack\/status\/20",
      "display_url" : "twitter.com\/jack\/status\/20"
    } ]
  },
  "in_reply_to_status_id_str" : "355450693559140354",
  "geo" : { },
  "id_str" : "355451831364751361",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april The first one that wasn't a deleted test message is https:\/\/t.co\/U4nZCC45pS",
  "id" : 355451831364751361,
  "in_reply_to_status_id" : 355450693559140354,
  "created_at" : "2013-07-11 22:21:35 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dom Sagolla",
      "screen_name" : "dom",
      "indices" : [ 53, 57 ],
      "id_str" : "21",
      "id" : 21
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/cFSr7VwiE9",
      "expanded_url" : "https:\/\/twitter.com\/dom\/statuses\/38",
      "display_url" : "twitter.com\/dom\/statuses\/38"
    } ]
  },
  "geo" : { },
  "id_str" : "355435664780689408",
  "text" : "The 38th tweet ever sent: https:\/\/t.co\/cFSr7VwiE9 by @dom",
  "id" : 355435664780689408,
  "created_at" : "2013-07-11 21:17:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355404890132066306",
  "geo" : { },
  "id_str" : "355404985044975616",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner Just being on the list, in this case.",
  "id" : 355404985044975616,
  "in_reply_to_status_id" : 355404890132066306,
  "created_at" : "2013-07-11 19:15:26 +0000",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355404261053571075",
  "geo" : { },
  "id_str" : "355404380591243264",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner Can you write a short toast for each of the famous first 140?",
  "id" : 355404380591243264,
  "in_reply_to_status_id" : 355404261053571075,
  "created_at" : "2013-07-11 19:13:02 +0000",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 14, 25 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/uu2UiEpXgO",
      "expanded_url" : "https:\/\/medium.com\/geek-empire-1\/75cd70a8259c",
      "display_url" : "medium.com\/geek-empire-1\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "355396081380634626",
  "geo" : { },
  "id_str" : "355401947571945473",
  "in_reply_to_user_id" : 765,
  "text" : "Neat -&gt; RT @seanbonner: I just published \u201CThe First 140 \u201D https:\/\/t.co\/uu2UiEpXgO",
  "id" : 355401947571945473,
  "in_reply_to_status_id" : 355396081380634626,
  "created_at" : "2013-07-11 19:03:22 +0000",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 3, 12 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Rex Sorgatz",
      "screen_name" : "fimoculous",
      "indices" : [ 99, 110 ],
      "id_str" : "41713",
      "id" : 41713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/w9yEL3GaxV",
      "expanded_url" : "http:\/\/2.dashes.com\/15fiptq",
      "display_url" : "2.dashes.com\/15fiptq"
    } ]
  },
  "geo" : { },
  "id_str" : "355391777617883138",
  "text" : "RT @anildash: Two decades after it took over pop music, the loop has taken over all of mass media. @fimoculous at his best: http:\/\/t.co\/w9y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rex Sorgatz",
        "screen_name" : "fimoculous",
        "indices" : [ 85, 96 ],
        "id_str" : "41713",
        "id" : 41713
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/w9yEL3GaxV",
        "expanded_url" : "http:\/\/2.dashes.com\/15fiptq",
        "display_url" : "2.dashes.com\/15fiptq"
      } ]
    },
    "geo" : { },
    "id_str" : "354999906638905346",
    "text" : "Two decades after it took over pop music, the loop has taken over all of mass media. @fimoculous at his best: http:\/\/t.co\/w9yEL3GaxV",
    "id" : 354999906638905346,
    "created_at" : "2013-07-10 16:25:47 +0000",
    "user" : {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "protected" : false,
      "id_str" : "36823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450813957461524480\/iNanfzj4_normal.jpeg",
      "id" : 36823,
      "verified" : true
    }
  },
  "id" : 355391777617883138,
  "created_at" : "2013-07-11 18:22:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 42, 52 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355377547711746048",
  "geo" : { },
  "id_str" : "355379502748147712",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm My head is an prototype framework for @kellianne's haircut ideas.",
  "id" : 355379502748147712,
  "in_reply_to_status_id" : 355377547711746048,
  "created_at" : "2013-07-11 17:34:10 +0000",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Biz Stone",
      "screen_name" : "biz",
      "indices" : [ 13, 17 ],
      "id_str" : "13",
      "id" : 13
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 46, 62 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/EX1aNV1753",
      "expanded_url" : "http:\/\/youtu.be\/EGnMThF_2Lo",
      "display_url" : "youtu.be\/EGnMThF_2Lo"
    } ]
  },
  "geo" : { },
  "id_str" : "355206558382174209",
  "text" : "TWTTR 101 by @biz  http:\/\/t.co\/EX1aNV1753 via @tonystubblebine is still applicable even today.",
  "id" : 355206558382174209,
  "created_at" : "2013-07-11 06:06:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 0, 8 ],
      "id_str" : "291",
      "id" : 291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355151677826928642",
  "geo" : { },
  "id_str" : "355201670889750528",
  "in_reply_to_user_id" : 291,
  "text" : "@goldman Do you know the date for the 160-&gt;140 change? Had to be between March and June of 2006 right?",
  "id" : 355201670889750528,
  "in_reply_to_status_id" : 355151677826928642,
  "created_at" : "2013-07-11 05:47:32 +0000",
  "in_reply_to_screen_name" : "goldman",
  "in_reply_to_user_id_str" : "291",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355186919975567360",
  "geo" : { },
  "id_str" : "355187930970591232",
  "in_reply_to_user_id" : 438953167,
  "text" : "@MobileAdGal It's been a bit neglected, yeah. But just this week some improvements have been made. What's your top gripe about DMs?",
  "id" : 355187930970591232,
  "in_reply_to_status_id" : 355186919975567360,
  "created_at" : "2013-07-11 04:52:56 +0000",
  "in_reply_to_screen_name" : "BitaShahian",
  "in_reply_to_user_id_str" : "438953167",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "indices" : [ 0, 5 ],
      "id_str" : "949521",
      "id" : 949521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355176305538502657",
  "geo" : { },
  "id_str" : "355176700293824512",
  "in_reply_to_user_id" : 949521,
  "text" : "@stop That's awesome. How are we doing on the eventual 9 digits?",
  "id" : 355176700293824512,
  "in_reply_to_status_id" : 355176305538502657,
  "created_at" : "2013-07-11 04:08:18 +0000",
  "in_reply_to_screen_name" : "stop",
  "in_reply_to_user_id_str" : "949521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "indices" : [ 3, 8 ],
      "id_str" : "949521",
      "id" : 949521
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 10, 17 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "ashton kutcher",
      "screen_name" : "aplusk",
      "indices" : [ 69, 76 ],
      "id_str" : "19058681",
      "id" : 19058681
    }, {
      "name" : "CNN Breaking News",
      "screen_name" : "cnnbrk",
      "indices" : [ 88, 95 ],
      "id_str" : "428333",
      "id" : 428333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355176469678395394",
  "text" : "RT @stop: @buster In 2009, we had to redesign the sidebar stats when @aplusk was racing @cnnbrk to a 1M followers, because seven digits wou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      }, {
        "name" : "ashton kutcher",
        "screen_name" : "aplusk",
        "indices" : [ 59, 66 ],
        "id_str" : "19058681",
        "id" : 19058681
      }, {
        "name" : "CNN Breaking News",
        "screen_name" : "cnnbrk",
        "indices" : [ 78, 85 ],
        "id_str" : "428333",
        "id" : 428333
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "355121456184705024",
    "geo" : { },
    "id_str" : "355176305538502657",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster In 2009, we had to redesign the sidebar stats when @aplusk was racing @cnnbrk to a 1M followers, because seven digits wouldn't fit.",
    "id" : 355176305538502657,
    "in_reply_to_status_id" : 355121456184705024,
    "created_at" : "2013-07-11 04:06:44 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "protected" : false,
      "id_str" : "949521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441691596375863296\/H7LzEpDT_normal.jpeg",
      "id" : 949521,
      "verified" : false
    }
  },
  "id" : 355176469678395394,
  "created_at" : "2013-07-11 04:07:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/IahWYRBAQ9",
      "expanded_url" : "http:\/\/flic.kr\/p\/f74vAv",
      "display_url" : "flic.kr\/p\/f74vAv"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859752, -122.275475 ]
  },
  "id_str" : "355169720095358976",
  "text" : "8:36pm Dinner with owls http:\/\/t.co\/IahWYRBAQ9",
  "id" : 355169720095358976,
  "created_at" : "2013-07-11 03:40:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 0, 14 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355163520712716289",
  "geo" : { },
  "id_str" : "355164395229286401",
  "in_reply_to_user_id" : 226976689,
  "text" : "@marcprecipice I still consider SMS followers my only true followers.",
  "id" : 355164395229286401,
  "in_reply_to_status_id" : 355163520712716289,
  "created_at" : "2013-07-11 03:19:25 +0000",
  "in_reply_to_screen_name" : "marcprecipice",
  "in_reply_to_user_id_str" : "226976689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 0, 14 ],
      "id_str" : "226976689",
      "id" : 226976689
    }, {
      "name" : "Coda Hale",
      "screen_name" : "coda",
      "indices" : [ 15, 20 ],
      "id_str" : "637533",
      "id" : 637533
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 32, 42 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355163338868658176",
  "geo" : { },
  "id_str" : "355164155721940995",
  "in_reply_to_user_id" : 226976689,
  "text" : "@marcprecipice @coda When I got @kellianne to join she called it \"the Eraserhead of the Internet\".",
  "id" : 355164155721940995,
  "in_reply_to_status_id" : 355163338868658176,
  "created_at" : "2013-07-11 03:18:28 +0000",
  "in_reply_to_screen_name" : "marcprecipice",
  "in_reply_to_user_id_str" : "226976689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Selvitelle",
      "screen_name" : "bs",
      "indices" : [ 0, 3 ],
      "id_str" : "309073",
      "id" : 309073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355146618275774464",
  "geo" : { },
  "id_str" : "355147823806812160",
  "in_reply_to_user_id" : 309073,
  "text" : "@bs Gimme some drama! :)",
  "id" : 355147823806812160,
  "in_reply_to_status_id" : 355146618275774464,
  "created_at" : "2013-07-11 02:13:34 +0000",
  "in_reply_to_screen_name" : "bs",
  "in_reply_to_user_id_str" : "309073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 3, 9 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 11, 18 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355137476165251072",
  "text" : "RT @couch: @buster I love this. In 2006 only, you could turn on \u201CNudge Me On New Years\u201D that would text you to update your status on NYE.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "355121456184705024",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7764033575, -122.4173885648 ]
    },
    "id_str" : "355135934108405762",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster I love this. In 2006 only, you could turn on \u201CNudge Me On New Years\u201D that would text you to update your status on NYE.",
    "id" : 355135934108405762,
    "in_reply_to_status_id" : 355121456184705024,
    "created_at" : "2013-07-11 01:26:19 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "protected" : false,
      "id_str" : "631823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428249544136994817\/fYWQCTd__normal.jpeg",
      "id" : 631823,
      "verified" : false
    }
  },
  "id" : 355137476165251072,
  "created_at" : "2013-07-11 01:32:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355134723829415936",
  "geo" : { },
  "id_str" : "355135084128518145",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley Shall I add you to the Google Doc as honorary historian?",
  "id" : 355135084128518145,
  "in_reply_to_status_id" : 355134723829415936,
  "created_at" : "2013-07-11 01:22:56 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 3, 8 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 10, 17 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355134029831487492",
  "text" : "RT @buzz: @buster Another amusing period thing I remember was the little Flash widget you could use to put your Twitter updates on your MyS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "355130822292029440",
    "geo" : { },
    "id_str" : "355132210086543360",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster Another amusing period thing I remember was the little Flash widget you could use to put your Twitter updates on your MySpace page.",
    "id" : 355132210086543360,
    "in_reply_to_status_id" : 355130822292029440,
    "created_at" : "2013-07-11 01:11:31 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "protected" : false,
      "id_str" : "528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000380729495\/f67b4c4cc29328c5fca63ef57936bcdb_normal.jpeg",
      "id" : 528,
      "verified" : false
    }
  },
  "id" : 355134029831487492,
  "created_at" : "2013-07-11 01:18:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 3, 10 ],
      "id_str" : "1530531",
      "id" : 1530531
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 12, 19 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/K0nWgrrOjN",
      "expanded_url" : "https:\/\/support.twitter.com\/articles\/20170024",
      "display_url" : "support.twitter.com\/articles\/20170\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "355133930757828608",
  "text" : "RT @miradu: @buster 7 years later you can still tweet by texting 40404 - on more then 250 operators in more then 100 countries: https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/K0nWgrrOjN",
        "expanded_url" : "https:\/\/support.twitter.com\/articles\/20170024",
        "display_url" : "support.twitter.com\/articles\/20170\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "355130822292029440",
    "geo" : { },
    "id_str" : "355132224624017408",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster 7 years later you can still tweet by texting 40404 - on more then 250 operators in more then 100 countries: https:\/\/t.co\/K0nWgrrOjN",
    "id" : 355132224624017408,
    "in_reply_to_status_id" : 355130822292029440,
    "created_at" : "2013-07-11 01:11:35 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "protected" : false,
      "id_str" : "1530531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455935284769599488\/RM_aphCO_normal.jpeg",
      "id" : 1530531,
      "verified" : false
    }
  },
  "id" : 355133930757828608,
  "created_at" : "2013-07-11 01:18:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/JVfepsjnNk",
      "expanded_url" : "http:\/\/web.archive.org\/web\/20120724003502\/http:\/\/listorious.com\/top\/longest?page=1",
      "display_url" : "web.archive.org\/web\/2012072400\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "355133790655496192",
  "text" : "The first 140 twitter users: http:\/\/t.co\/JVfepsjnNk #hackweek",
  "id" : 355133790655496192,
  "created_at" : "2013-07-11 01:17:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Pusateri",
      "screen_name" : "Cruftbox",
      "indices" : [ 1, 10 ],
      "id_str" : "792738",
      "id" : 792738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355131704157024257",
  "geo" : { },
  "id_str" : "355133198646251520",
  "in_reply_to_user_id" : 792738,
  "text" : ".@Cruftbox During SXSW 2007 it went from 20,000 tweets per day to 60,000\u2026 about 10 seconds worth at today's rate.",
  "id" : 355133198646251520,
  "in_reply_to_status_id" : 355131704157024257,
  "created_at" : "2013-07-11 01:15:27 +0000",
  "in_reply_to_screen_name" : "Cruftbox",
  "in_reply_to_user_id_str" : "792738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/355130822292029440\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/dCgdaJWDi4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BO2tmfGCQAIdoTd.jpg",
      "id_str" : "355130822325583874",
      "id" : 355130822325583874,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BO2tmfGCQAIdoTd.jpg",
      "sizes" : [ {
        "h" : 279,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/dCgdaJWDi4"
    } ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355130822292029440",
  "text" : "Remember how Twttr looked when it first launched? #hackweek http:\/\/t.co\/dCgdaJWDi4",
  "id" : 355130822292029440,
  "created_at" : "2013-07-11 01:06:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Ewing",
      "screen_name" : "hoverbird",
      "indices" : [ 0, 10 ],
      "id_str" : "792690",
      "id" : 792690
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 11, 18 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355126854316859392",
  "geo" : { },
  "id_str" : "355128496328159233",
  "in_reply_to_user_id" : 792690,
  "text" : "@hoverbird @isaach Yeah, that's the plan. These are the bones, and it needs to be turned into a narrative.",
  "id" : 355128496328159233,
  "in_reply_to_status_id" : 355126854316859392,
  "created_at" : "2013-07-11 00:56:46 +0000",
  "in_reply_to_screen_name" : "hoverbird",
  "in_reply_to_user_id_str" : "792690",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Ewing",
      "screen_name" : "hoverbird",
      "indices" : [ 0, 10 ],
      "id_str" : "792690",
      "id" : 792690
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 11, 18 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deduping",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355125745279959041",
  "geo" : { },
  "id_str" : "355126392322658304",
  "in_reply_to_user_id" : 792690,
  "text" : "@hoverbird @isaach I do as of about 10 mins ago. I am focusing on the history of the product (not business or social impact). #deduping",
  "id" : 355126392322658304,
  "in_reply_to_status_id" : 355125745279959041,
  "created_at" : "2013-07-11 00:48:24 +0000",
  "in_reply_to_screen_name" : "hoverbird",
  "in_reply_to_user_id_str" : "792690",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 0, 11 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355125257104932865",
  "geo" : { },
  "id_str" : "355126003368083459",
  "in_reply_to_user_id" : 13919072,
  "text" : "@robinsloan Thanks! Have any favorite stories or anecdotes you'd like to make sure get in there?",
  "id" : 355126003368083459,
  "in_reply_to_status_id" : 355125257104932865,
  "created_at" : "2013-07-11 00:46:51 +0000",
  "in_reply_to_screen_name" : "robinsloan",
  "in_reply_to_user_id_str" : "13919072",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew E Plotkin",
      "screen_name" : "andreweplotkin",
      "indices" : [ 0, 15 ],
      "id_str" : "90545097",
      "id" : 90545097
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 16, 23 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355124980377329666",
  "geo" : { },
  "id_str" : "355125838418673668",
  "in_reply_to_user_id" : 90545097,
  "text" : "@andreweplotkin @isaach I'll add you both to the doc in a bit.",
  "id" : 355125838418673668,
  "in_reply_to_status_id" : 355124980377329666,
  "created_at" : "2013-07-11 00:46:12 +0000",
  "in_reply_to_screen_name" : "andreweplotkin",
  "in_reply_to_user_id_str" : "90545097",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Barnard",
      "screen_name" : "toddbarnard",
      "indices" : [ 0, 12 ],
      "id_str" : "13621",
      "id" : 13621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355124821228666882",
  "geo" : { },
  "id_str" : "355125751470755840",
  "in_reply_to_user_id" : 13621,
  "text" : "@toddbarnard Do you mean the ability to view someone else's timeline?",
  "id" : 355125751470755840,
  "in_reply_to_status_id" : 355124821228666882,
  "created_at" : "2013-07-11 00:45:51 +0000",
  "in_reply_to_screen_name" : "toddbarnard",
  "in_reply_to_user_id_str" : "13621",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee LeFever",
      "screen_name" : "leelefever",
      "indices" : [ 0, 11 ],
      "id_str" : "12279",
      "id" : 12279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355124595734487043",
  "geo" : { },
  "id_str" : "355124744590344192",
  "in_reply_to_user_id" : 12279,
  "text" : "@leelefever I remember that!",
  "id" : 355124744590344192,
  "in_reply_to_status_id" : 355124595734487043,
  "created_at" : "2013-07-11 00:41:51 +0000",
  "in_reply_to_screen_name" : "leelefever",
  "in_reply_to_user_id_str" : "12279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee LeFever",
      "screen_name" : "leelefever",
      "indices" : [ 3, 14 ],
      "id_str" : "12279",
      "id" : 12279
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 16, 23 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Common Craft",
      "screen_name" : "CommonCraft",
      "indices" : [ 70, 82 ],
      "id_str" : "14977120",
      "id" : 14977120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/PObhmO1gl8",
      "expanded_url" : "http:\/\/www.commoncraft.com\/twittercom-now-less-common-craft",
      "display_url" : "commoncraft.com\/twittercom-now\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "355124647798378496",
  "text" : "RT @leelefever: @buster Not a \"product\" thing, and I'm biased, but an @CommonCraft video graced the front page for over a year. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      }, {
        "name" : "Common Craft",
        "screen_name" : "CommonCraft",
        "indices" : [ 54, 66 ],
        "id_str" : "14977120",
        "id" : 14977120
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/PObhmO1gl8",
        "expanded_url" : "http:\/\/www.commoncraft.com\/twittercom-now-less-common-craft",
        "display_url" : "commoncraft.com\/twittercom-now\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "355123202156007424",
    "geo" : { },
    "id_str" : "355124595734487043",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster Not a \"product\" thing, and I'm biased, but an @CommonCraft video graced the front page for over a year. http:\/\/t.co\/PObhmO1gl8",
    "id" : 355124595734487043,
    "in_reply_to_status_id" : 355123202156007424,
    "created_at" : "2013-07-11 00:41:16 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Lee LeFever",
      "screen_name" : "leelefever",
      "protected" : false,
      "id_str" : "12279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3249299655\/4fcc204542a282eae806ba6df7184463_normal.jpeg",
      "id" : 12279,
      "verified" : false
    }
  },
  "id" : 355124647798378496,
  "created_at" : "2013-07-11 00:41:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 1, 6 ],
      "id_str" : "528",
      "id" : 528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/j0vlvJcBDz",
      "expanded_url" : "https:\/\/blog.twitter.com\/2008\/twitter-and-xmpp-drinking-fire-hose",
      "display_url" : "blog.twitter.com\/2008\/twitter-a\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "355123571665805314",
  "geo" : { },
  "id_str" : "355124374438809600",
  "in_reply_to_user_id" : 528,
  "text" : ".@buzz The firehose\/streaming API was originally built for Technorati. https:\/\/t.co\/j0vlvJcBDz",
  "id" : 355124374438809600,
  "in_reply_to_status_id" : 355123571665805314,
  "created_at" : "2013-07-11 00:40:23 +0000",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew E Plotkin",
      "screen_name" : "andreweplotkin",
      "indices" : [ 0, 15 ],
      "id_str" : "90545097",
      "id" : 90545097
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 16, 23 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355123171847974912",
  "geo" : { },
  "id_str" : "355124088013991937",
  "in_reply_to_user_id" : 90545097,
  "text" : "@andreweplotkin @isaach Hmm\u2026 yeah, that would be good to include. Any idea if any of it is already collected somewhere?",
  "id" : 355124088013991937,
  "in_reply_to_status_id" : 355123171847974912,
  "created_at" : "2013-07-11 00:39:15 +0000",
  "in_reply_to_screen_name" : "andreweplotkin",
  "in_reply_to_user_id_str" : "90545097",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355122799385387008",
  "geo" : { },
  "id_str" : "355123716029558784",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz I remember that too. But I also remember appreciating the brilliance of Dodgeball status updates as a standalone site.",
  "id" : 355123716029558784,
  "in_reply_to_status_id" : 355122799385387008,
  "created_at" : "2013-07-11 00:37:46 +0000",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355122790556381185",
  "geo" : { },
  "id_str" : "355123349522882561",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner You would be King of Twitter if you worked here. I'm the 3rd oldest Twitter user I believe...",
  "id" : 355123349522882561,
  "in_reply_to_status_id" : 355122790556381185,
  "created_at" : "2013-07-11 00:36:19 +0000",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kia K.",
      "screen_name" : "imkialikethecar",
      "indices" : [ 1, 17 ],
      "id_str" : "245697392",
      "id" : 245697392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/wjtl7pFFKg",
      "expanded_url" : "https:\/\/blog.twitter.com\/2009\/whats-happening",
      "display_url" : "blog.twitter.com\/2009\/whats-hap\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "355122563623559170",
  "geo" : { },
  "id_str" : "355123202156007424",
  "in_reply_to_user_id" : 245697392,
  "text" : ".@imkialikethecar On Nov 19th, 2009 the prompt changed from \"What are you doing?\" to \"What's happening?\" https:\/\/t.co\/wjtl7pFFKg",
  "id" : 355123202156007424,
  "in_reply_to_status_id" : 355122563623559170,
  "created_at" : "2013-07-11 00:35:43 +0000",
  "in_reply_to_screen_name" : "imkialikethecar",
  "in_reply_to_user_id_str" : "245697392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355122155010273280",
  "geo" : { },
  "id_str" : "355122833459920897",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I'm purposely leaving out social impact and world events because they would be so difficult to track down. Maybe next #hackweek?",
  "id" : 355122833459920897,
  "in_reply_to_status_id" : 355122155010273280,
  "created_at" : "2013-07-11 00:34:16 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 0, 7 ],
      "id_str" : "1530531",
      "id" : 1530531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355122026186420224",
  "geo" : { },
  "id_str" : "355122654711263232",
  "in_reply_to_user_id" : 1530531,
  "text" : "@miradu Go back and read the first comments on the post if you haven't already.",
  "id" : 355122654711263232,
  "in_reply_to_status_id" : 355122026186420224,
  "created_at" : "2013-07-11 00:33:33 +0000",
  "in_reply_to_screen_name" : "miradu",
  "in_reply_to_user_id_str" : "1530531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355122005617557504",
  "geo" : { },
  "id_str" : "355122541448265728",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner That's awesome. I'm 2,185\u2026 ancient compared to you. I'll add a slide with your face on it.",
  "id" : 355122541448265728,
  "in_reply_to_status_id" : 355122005617557504,
  "created_at" : "2013-07-11 00:33:06 +0000",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 31, 42 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/SbN8oYZ9ob",
      "expanded_url" : "http:\/\/techcrunch.com\/2006\/07\/15\/is-twttr-interesting\/",
      "display_url" : "techcrunch.com\/2006\/07\/15\/is-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "355121618164518913",
  "text" : "To get you started, here's the @techcrunch post announcing the launch of Twttr on July 15th, 2006: http:\/\/t.co\/SbN8oYZ9ob",
  "id" : 355121618164518913,
  "created_at" : "2013-07-11 00:29:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355121456184705024",
  "text" : "I'm writing a history of Twitter the product for #hackweek. What do you think I'm missing? Ask me anything, or suggest an addition.",
  "id" : 355121456184705024,
  "created_at" : "2013-07-11 00:28:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354841355081621506",
  "geo" : { },
  "id_str" : "354854519261237252",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk I'd bet that most\/enough of it is.",
  "id" : 354854519261237252,
  "in_reply_to_status_id" : 354841355081621506,
  "created_at" : "2013-07-10 06:48:04 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/354833812582187008\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/mSNc9kJMMI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOyfePmCQAMBeDn.png",
      "id_str" : "354833812586381315",
      "id" : 354833812586381315,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOyfePmCQAMBeDn.png",
      "sizes" : [ {
        "h" : 1154,
        "resize" : "fit",
        "w" : 2334
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 297,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 168,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mSNc9kJMMI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/sq3CmEJT53",
      "expanded_url" : "http:\/\/bit.ly\/13nMKJd",
      "display_url" : "bit.ly\/13nMKJd"
    } ]
  },
  "geo" : { },
  "id_str" : "354833812582187008",
  "text" : "Only 900 out of 1,000 slogs left towards my kiloslog (context: http:\/\/t.co\/sq3CmEJT53). Est. completion by Jan 2017. http:\/\/t.co\/mSNc9kJMMI",
  "id" : 354833812582187008,
  "created_at" : "2013-07-10 05:25:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 3, 13 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354831309052448769",
  "text" : "RT @galenward: Will there be any reason to own a car when cars are self-driving? I think there will be a huge shift to the convenience of s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354677861824724992",
    "text" : "Will there be any reason to own a car when cars are self-driving? I think there will be a huge shift to the convenience of services.",
    "id" : 354677861824724992,
    "created_at" : "2013-07-09 19:06:06 +0000",
    "user" : {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "protected" : false,
      "id_str" : "2854761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1795457065\/Galen_Ward_-_its_okay_to_have_a_crush_normal.jpg",
      "id" : 2854761,
      "verified" : false
    }
  },
  "id" : 354831309052448769,
  "created_at" : "2013-07-10 05:15:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badparent",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/TGwSlQPQ1e",
      "expanded_url" : "http:\/\/flic.kr\/p\/f6J9Fo",
      "display_url" : "flic.kr\/p\/f6J9Fo"
    } ]
  },
  "geo" : { },
  "id_str" : "354810183395971075",
  "text" : "8:36pm Niko resting on the floor of a restaurant because I'm a #badparent http:\/\/t.co\/TGwSlQPQ1e",
  "id" : 354810183395971075,
  "created_at" : "2013-07-10 03:51:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sina Khanifar",
      "screen_name" : "sinak",
      "indices" : [ 1, 7 ],
      "id_str" : "3573701",
      "id" : 3573701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354798258725466112",
  "geo" : { },
  "id_str" : "354805707163435008",
  "in_reply_to_user_id" : 3573701,
  "text" : ".@sinak I think a dead head is just fine. It's betting on the idea that the brain contains our memories\/thoughts even when turned off.",
  "id" : 354805707163435008,
  "in_reply_to_status_id" : 354798258725466112,
  "created_at" : "2013-07-10 03:34:07 +0000",
  "in_reply_to_screen_name" : "sinak",
  "in_reply_to_user_id_str" : "3573701",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354797440601296897",
  "text" : "I might be willing to pay $80k to freeze my head upon death. I guess it depends on if I have it.",
  "id" : 354797440601296897,
  "created_at" : "2013-07-10 03:01:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Cheng",
      "screen_name" : "jackcheng",
      "indices" : [ 12, 22 ],
      "id_str" : "146703",
      "id" : 146703
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/354685929031614464\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/qGMBjQOK2w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOwY-ScCQAIiDgX.jpg",
      "id_str" : "354685929035808770",
      "id" : 354685929035808770,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOwY-ScCQAIiDgX.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qGMBjQOK2w"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7765121646, -122.4167212083 ]
  },
  "id_str" : "354685929031614464",
  "text" : "The amazing @jackcheng is at Twitter to talk about his writing process. I've been wanting to meet him for years! http:\/\/t.co\/qGMBjQOK2w",
  "id" : 354685929031614464,
  "created_at" : "2013-07-09 19:38:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 0, 11 ],
      "id_str" : "784078",
      "id" : 784078
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 12, 19 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354607585871138816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597231873, -122.2756228514 ]
  },
  "id_str" : "354610807990005760",
  "in_reply_to_user_id" : 784078,
  "text" : "@alicetiara @harryh I use that same logic\/strategy.",
  "id" : 354610807990005760,
  "in_reply_to_status_id" : 354607585871138816,
  "created_at" : "2013-07-09 14:39:39 +0000",
  "in_reply_to_screen_name" : "alicetiara",
  "in_reply_to_user_id_str" : "784078",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ANAGRAMATRON",
      "screen_name" : "anagramatron",
      "indices" : [ 8, 21 ],
      "id_str" : "1170208442",
      "id" : 1170208442
    }, {
      "name" : "Fazirul Syamil \u00ABSE\u00BB",
      "screen_name" : "FazirulSyamil",
      "indices" : [ 25, 39 ],
      "id_str" : "866279342",
      "id" : 866279342
    }, {
      "name" : "Megga Avitta",
      "screen_name" : "MegaDevitasari",
      "indices" : [ 70, 85 ],
      "id_str" : "1479278011",
      "id" : 1479278011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/rTYQLlq0np",
      "expanded_url" : "http:\/\/bit.ly\/14FdVNW",
      "display_url" : "bit.ly\/14FdVNW"
    } ]
  },
  "geo" : { },
  "id_str" : "354470053015592960",
  "text" : "A great @Anagramatron: \n\n@FazirulSyamil \"You are the of my life\" and \n@MegaDevitasari \"I hate my feel for you\"\n\nhttp:\/\/t.co\/rTYQLlq0np",
  "id" : 354470053015592960,
  "created_at" : "2013-07-09 05:20:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 0, 3 ],
      "id_str" : "15504330",
      "id" : 15504330
    }, {
      "name" : "rothmana",
      "screen_name" : "rothmana",
      "indices" : [ 4, 13 ],
      "id_str" : "17392577",
      "id" : 17392577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354458649378291713",
  "geo" : { },
  "id_str" : "354459216083296258",
  "in_reply_to_user_id" : 15504330,
  "text" : "@wm @rothmana Ooh, fun. Niko's already most interested in the \"scariest\" story in the book, where Toad imagines Frog eaten by a wolf.",
  "id" : 354459216083296258,
  "in_reply_to_status_id" : 354458649378291713,
  "created_at" : "2013-07-09 04:37:17 +0000",
  "in_reply_to_screen_name" : "wm",
  "in_reply_to_user_id_str" : "15504330",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rothmana",
      "screen_name" : "rothmana",
      "indices" : [ 0, 9 ],
      "id_str" : "17392577",
      "id" : 17392577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354457284711165952",
  "geo" : { },
  "id_str" : "354457775985795072",
  "in_reply_to_user_id" : 17392577,
  "text" : "@rothmana We've just started dipping our toes in Frog &amp; Toad. Haven't run across the cookies one yet--will look for it next bookstore visit!",
  "id" : 354457775985795072,
  "in_reply_to_status_id" : 354457284711165952,
  "created_at" : "2013-07-09 04:31:33 +0000",
  "in_reply_to_screen_name" : "rothmana",
  "in_reply_to_user_id_str" : "17392577",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/mWKiQBHT8L",
      "expanded_url" : "http:\/\/flic.kr\/p\/f5NCfF",
      "display_url" : "flic.kr\/p\/f5NCfF"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859694, -122.275528 ]
  },
  "id_str" : "354456348693504002",
  "text" : "8:36pm Reading 8 stories for bedtime since Niko didn't fight during bath time. http:\/\/t.co\/mWKiQBHT8L",
  "id" : 354456348693504002,
  "created_at" : "2013-07-09 04:25:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 9, 16 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/isaach\/status\/354443464001351680\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/8pAaRXP5Xi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOs8c91CcAAg1dG.png",
      "id_str" : "354443464009740288",
      "id" : 354443464009740288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOs8c91CcAAg1dG.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/8pAaRXP5Xi"
    } ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354443464001351680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597330197, -122.2756265325 ]
  },
  "id_str" : "354452169602244608",
  "in_reply_to_user_id" : 7852612,
  "text" : "Woah. RT @isaach: 1st render of the largest component of the graph of mutual follows amongst verified users #hackweek http:\/\/t.co\/8pAaRXP5Xi",
  "id" : 354452169602244608,
  "in_reply_to_status_id" : 354443464001351680,
  "created_at" : "2013-07-09 04:09:17 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "indices" : [ 3, 8 ],
      "id_str" : "949521",
      "id" : 949521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/krxYGmiFAd",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998",
      "display_url" : "itunes.apple.com\/us\/app\/twitter\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "354440814677602304",
  "text" : "RT @stop: So happy to see Twitter for Mac get the full Connect experience with faves, retweets, follows. Plus DM syncing. https:\/\/t.co\/krxY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/krxYGmiFAd",
        "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998",
        "display_url" : "itunes.apple.com\/us\/app\/twitter\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "354377787878031360",
    "text" : "So happy to see Twitter for Mac get the full Connect experience with faves, retweets, follows. Plus DM syncing. https:\/\/t.co\/krxYGmiFAd",
    "id" : 354377787878031360,
    "created_at" : "2013-07-08 23:13:43 +0000",
    "user" : {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "protected" : false,
      "id_str" : "949521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441691596375863296\/H7LzEpDT_normal.jpeg",
      "id" : 949521,
      "verified" : false
    }
  },
  "id" : 354440814677602304,
  "created_at" : "2013-07-09 03:24:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard MacManus",
      "screen_name" : "ricmac",
      "indices" : [ 0, 7 ],
      "id_str" : "105895323",
      "id" : 105895323
    }, {
      "name" : "Pentametron",
      "screen_name" : "pentametron",
      "indices" : [ 52, 64 ],
      "id_str" : "516047986",
      "id" : 516047986
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354383151931461633",
  "geo" : { },
  "id_str" : "354383824026746881",
  "in_reply_to_user_id" : 105895323,
  "text" : "@ricmac I agree! Which rate limit did you run into, @pentametron? Feel free to email me at buster@twitter.com\u2026 I'd love to help route.",
  "id" : 354383824026746881,
  "in_reply_to_status_id" : 354383151931461633,
  "created_at" : "2013-07-08 23:37:42 +0000",
  "in_reply_to_screen_name" : "ricmac",
  "in_reply_to_user_id_str" : "105895323",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354348896144723968",
  "geo" : { },
  "id_str" : "354361598002987012",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs Ooh, much better! I like.",
  "id" : 354361598002987012,
  "in_reply_to_status_id" : 354348896144723968,
  "created_at" : "2013-07-08 22:09:23 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 0, 12 ],
      "id_str" : "15019184",
      "id" : 15019184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354307335151296512",
  "geo" : { },
  "id_str" : "354307437970460672",
  "in_reply_to_user_id" : 15019184,
  "text" : "@heyamberrae It works for me.",
  "id" : 354307437970460672,
  "in_reply_to_status_id" : 354307335151296512,
  "created_at" : "2013-07-08 18:34:10 +0000",
  "in_reply_to_screen_name" : "heyamberrae",
  "in_reply_to_user_id_str" : "15019184",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 3, 9 ],
      "id_str" : "8285392",
      "id" : 8285392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/X8k1NGXxMe",
      "expanded_url" : "https:\/\/blog.twitter.com\/2013\/direct-message-sync-mobile-search-improvements-and-more",
      "display_url" : "blog.twitter.com\/2013\/direct-me\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "354298982794661891",
  "text" : "RT @raffi: we've solved the hardest problem in CS! \"Direct messages now sync across all your devices.\" https:\/\/t.co\/X8k1NGXxMe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/X8k1NGXxMe",
        "expanded_url" : "https:\/\/blog.twitter.com\/2013\/direct-message-sync-mobile-search-improvements-and-more",
        "display_url" : "blog.twitter.com\/2013\/direct-me\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "354298742683336704",
    "text" : "we've solved the hardest problem in CS! \"Direct messages now sync across all your devices.\" https:\/\/t.co\/X8k1NGXxMe",
    "id" : 354298742683336704,
    "created_at" : "2013-07-08 17:59:37 +0000",
    "user" : {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "protected" : false,
      "id_str" : "8285392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1270234259\/raffi-headshot-casual_normal.png",
      "id" : 8285392,
      "verified" : false
    }
  },
  "id" : 354298982794661891,
  "created_at" : "2013-07-08 18:00:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daisy barringer",
      "screen_name" : "daisy",
      "indices" : [ 3, 9 ],
      "id_str" : "7390862",
      "id" : 7390862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/r9G8VShTu8",
      "expanded_url" : "http:\/\/billanddavescocktailhour.com\/the-day-the-internet-died-july-23-2018\/",
      "display_url" : "billanddavescocktailhour.com\/the-day-the-in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "354296639722233857",
  "text" : "RT @daisy: Great cartoon from David Gessner - \"The Day the Internet Died\" - http:\/\/t.co\/r9G8VShTu8",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/r9G8VShTu8",
        "expanded_url" : "http:\/\/billanddavescocktailhour.com\/the-day-the-internet-died-july-23-2018\/",
        "display_url" : "billanddavescocktailhour.com\/the-day-the-in\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "354295392801787906",
    "text" : "Great cartoon from David Gessner - \"The Day the Internet Died\" - http:\/\/t.co\/r9G8VShTu8",
    "id" : 354295392801787906,
    "created_at" : "2013-07-08 17:46:18 +0000",
    "user" : {
      "name" : "daisy barringer",
      "screen_name" : "daisy",
      "protected" : false,
      "id_str" : "7390862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459021588898144257\/m3bEkMeq_normal.jpeg",
      "id" : 7390862,
      "verified" : false
    }
  },
  "id" : 354296639722233857,
  "created_at" : "2013-07-08 17:51:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 16, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354287343571714049",
  "text" : "Opened up a new #hackweek column in TweetDeck... now I just have to figure out what I'm gonna do.",
  "id" : 354287343571714049,
  "created_at" : "2013-07-08 17:14:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354273829285142529",
  "geo" : { },
  "id_str" : "354279946761416704",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler Cool! What did you use them for?",
  "id" : 354279946761416704,
  "in_reply_to_status_id" : 354273829285142529,
  "created_at" : "2013-07-08 16:44:56 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rand Fishkin",
      "screen_name" : "randfish",
      "indices" : [ 3, 12 ],
      "id_str" : "6527972",
      "id" : 6527972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/MDK16UiRXN",
      "expanded_url" : "http:\/\/moz.com\/blog\/seo-satisfaction",
      "display_url" : "moz.com\/blog\/seo-satis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "354255432560291844",
  "text" : "RT @randfish: One of the most important and ignored ranking factors in SEO: http:\/\/t.co\/MDK16UiRXN",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/MDK16UiRXN",
        "expanded_url" : "http:\/\/moz.com\/blog\/seo-satisfaction",
        "display_url" : "moz.com\/blog\/seo-satis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "354245614030163970",
    "text" : "One of the most important and ignored ranking factors in SEO: http:\/\/t.co\/MDK16UiRXN",
    "id" : 354245614030163970,
    "created_at" : "2013-07-08 14:28:30 +0000",
    "user" : {
      "name" : "Rand Fishkin",
      "screen_name" : "randfish",
      "protected" : false,
      "id_str" : "6527972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454052786749988865\/mIzsM7-e_normal.jpeg",
      "id" : 6527972,
      "verified" : true
    }
  },
  "id" : 354255432560291844,
  "created_at" : "2013-07-08 15:07:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Mod",
      "screen_name" : "craigmod",
      "indices" : [ 3, 12 ],
      "id_str" : "1835951",
      "id" : 1835951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/QQsn7gj2R3",
      "expanded_url" : "http:\/\/cmod.me\/1aOlhUa",
      "display_url" : "cmod.me\/1aOlhUa"
    } ]
  },
  "geo" : { },
  "id_str" : "354253397970522113",
  "text" : "RT @craigmod: Wow. What an incredible product story\u00A0\u2014 Sugru:   http:\/\/t.co\/QQsn7gj2R3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/QQsn7gj2R3",
        "expanded_url" : "http:\/\/cmod.me\/1aOlhUa",
        "display_url" : "cmod.me\/1aOlhUa"
      } ]
    },
    "geo" : { },
    "id_str" : "354248052070039552",
    "text" : "Wow. What an incredible product story\u00A0\u2014 Sugru:   http:\/\/t.co\/QQsn7gj2R3",
    "id" : 354248052070039552,
    "created_at" : "2013-07-08 14:38:11 +0000",
    "user" : {
      "name" : "Craig Mod",
      "screen_name" : "craigmod",
      "protected" : false,
      "id_str" : "1835951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2644801549\/787bf94df02d213d1359133d48d673b6_normal.png",
      "id" : 1835951,
      "verified" : false
    }
  },
  "id" : 354253397970522113,
  "created_at" : "2013-07-08 14:59:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/getprismatic.com\" rel=\"nofollow\"\u003Egetprismatic.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prismatic",
      "screen_name" : "Prismatic",
      "indices" : [ 83, 93 ],
      "id_str" : "229709694",
      "id" : 229709694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/IhRydX463P",
      "expanded_url" : "http:\/\/prsm.tc\/RG1gm9",
      "display_url" : "prsm.tc\/RG1gm9"
    } ]
  },
  "geo" : { },
  "id_str" : "354224834533789697",
  "text" : "Background on the possible discovery of the Higgs Boson http:\/\/t.co\/IhRydX463P via @prismatic",
  "id" : 354224834533789697,
  "created_at" : "2013-07-08 13:05:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lewis",
      "screen_name" : "plewis67",
      "indices" : [ 12, 21 ],
      "id_str" : "251583860",
      "id" : 251583860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/jpbWKgGLox",
      "expanded_url" : "http:\/\/bit.ly\/12SuCWb",
      "display_url" : "bit.ly\/12SuCWb"
    } ]
  },
  "in_reply_to_status_id_str" : "354215634810310658",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596947656, -122.275546329 ]
  },
  "id_str" : "354222414256799745",
  "in_reply_to_user_id" : 251583860,
  "text" : "Awesome: RT @plewis67: Seth Roberts has posted the meditation experiment I presented at the QS conference: http:\/\/t.co\/jpbWKgGLox",
  "id" : 354222414256799745,
  "in_reply_to_status_id" : 354215634810310658,
  "created_at" : "2013-07-08 12:56:19 +0000",
  "in_reply_to_screen_name" : "plewis67",
  "in_reply_to_user_id_str" : "251583860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zentweet",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354115561048903680",
  "text" : "The obstacle is the path. #zentweet",
  "id" : 354115561048903680,
  "created_at" : "2013-07-08 05:51:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Sacks",
      "screen_name" : "OliverSacks",
      "indices" : [ 57, 69 ],
      "id_str" : "52488565",
      "id" : 52488565
    }, {
      "name" : "Deb Roy",
      "screen_name" : "dkroy",
      "indices" : [ 98, 104 ],
      "id_str" : "30569817",
      "id" : 30569817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/SP4sCdQ92R",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/07\/07\/opinion\/sunday\/the-joy-of-old-age-no-kidding.html?src=me&ref=general",
      "display_url" : "nytimes.com\/2013\/07\/07\/opi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597691656, -122.2756213044 ]
  },
  "id_str" : "354115145343045632",
  "text" : "So good: \"The Joy of Old Age\"  http:\/\/t.co\/SP4sCdQ92R by @OliverSacks who is turning 80 soon \/via @dkroy",
  "id" : 354115145343045632,
  "created_at" : "2013-07-08 05:50:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 46, 53 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 58, 62 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/eCJpFBnFMd",
      "expanded_url" : "http:\/\/flic.kr\/p\/f5gEHf",
      "display_url" : "flic.kr\/p\/f5gEHf"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859705, -122.275484 ]
  },
  "id_str" : "354082286142099458",
  "text" : "8:36pm Watching the Muppet Movie (again) with @sharon and @ian http:\/\/t.co\/eCJpFBnFMd",
  "id" : 354082286142099458,
  "created_at" : "2013-07-08 03:39:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Fishburne",
      "screen_name" : "tomfishburne",
      "indices" : [ 3, 16 ],
      "id_str" : "43407384",
      "id" : 43407384
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tomfishburne\/status\/354066366258626560\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/EU7lZH3i8F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOnle_RCQAEXypR.jpg",
      "id_str" : "354066366267015169",
      "id" : 354066366267015169,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOnle_RCQAEXypR.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EU7lZH3i8F"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/tAnX9LR5xX",
      "expanded_url" : "http:\/\/ow.ly\/mJKP6",
      "display_url" : "ow.ly\/mJKP6"
    } ]
  },
  "geo" : { },
  "id_str" : "354069484337766402",
  "text" : "RT @tomfishburne: \"Ad Retargeting\" - new cartoon and post on ads that stalk you http:\/\/t.co\/tAnX9LR5xX http:\/\/t.co\/EU7lZH3i8F",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tomfishburne\/status\/354066366258626560\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/EU7lZH3i8F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BOnle_RCQAEXypR.jpg",
        "id_str" : "354066366267015169",
        "id" : 354066366267015169,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOnle_RCQAEXypR.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/EU7lZH3i8F"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/tAnX9LR5xX",
        "expanded_url" : "http:\/\/ow.ly\/mJKP6",
        "display_url" : "ow.ly\/mJKP6"
      } ]
    },
    "geo" : { },
    "id_str" : "354066366258626560",
    "text" : "\"Ad Retargeting\" - new cartoon and post on ads that stalk you http:\/\/t.co\/tAnX9LR5xX http:\/\/t.co\/EU7lZH3i8F",
    "id" : 354066366258626560,
    "created_at" : "2013-07-08 02:36:14 +0000",
    "user" : {
      "name" : "Tom Fishburne",
      "screen_name" : "tomfishburne",
      "protected" : false,
      "id_str" : "43407384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1577292457\/twitter_headshot_normal.jpg",
      "id" : 43407384,
      "verified" : false
    }
  },
  "id" : 354069484337766402,
  "created_at" : "2013-07-08 02:48:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/XVbIzgYdSh",
      "expanded_url" : "https:\/\/vine.co\/v\/h7aD9J9iHLY",
      "display_url" : "vine.co\/v\/h7aD9J9iHLY"
    } ]
  },
  "geo" : { },
  "id_str" : "353985544335794177",
  "text" : "Pony ride! https:\/\/t.co\/XVbIzgYdSh",
  "id" : 353985544335794177,
  "created_at" : "2013-07-07 21:15:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 19, 23 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/5MMt1Qgj45",
      "expanded_url" : "https:\/\/vine.co\/v\/h7aX3Eug9mI",
      "display_url" : "vine.co\/v\/h7aX3Eug9mI"
    } ]
  },
  "geo" : { },
  "id_str" : "353982203576856577",
  "text" : "Bobble Lagoon: 20, @ian: 0.5? https:\/\/t.co\/5MMt1Qgj45",
  "id" : 353982203576856577,
  "created_at" : "2013-07-07 21:01:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 18, 22 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/vZwGhXOMUZ",
      "expanded_url" : "https:\/\/vine.co\/v\/h7aX1Pv5DQB",
      "display_url" : "vine.co\/v\/h7aX1Pv5DQB"
    } ]
  },
  "geo" : { },
  "id_str" : "353981827310030850",
  "text" : "Bobble Lagoon: 1, @ian: 0 https:\/\/t.co\/vZwGhXOMUZ",
  "id" : 353981827310030850,
  "created_at" : "2013-07-07 21:00:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/N3sGP0Qk8a",
      "expanded_url" : "https:\/\/vine.co\/v\/h7amPwFuiqQ",
      "display_url" : "vine.co\/v\/h7amPwFuiqQ"
    } ]
  },
  "geo" : { },
  "id_str" : "353969872771887106",
  "text" : "Cars https:\/\/t.co\/N3sGP0Qk8a",
  "id" : 353969872771887106,
  "created_at" : "2013-07-07 20:12:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mariusz Nowostawski",
      "screen_name" : "Praeteritio",
      "indices" : [ 0, 12 ],
      "id_str" : "32199673",
      "id" : 32199673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353954258745438208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6590047025, -121.8862454941 ]
  },
  "id_str" : "353957404930609153",
  "in_reply_to_user_id" : 32199673,
  "text" : "@Praeteritio It was entertaining. Definitely gonna watch the other episodes now.",
  "id" : 353957404930609153,
  "in_reply_to_status_id" : 353954258745438208,
  "created_at" : "2013-07-07 19:23:16 +0000",
  "in_reply_to_screen_name" : "Praeteritio",
  "in_reply_to_user_id_str" : "32199673",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 41, 48 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 49, 59 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/nnPFgg6zIG",
      "expanded_url" : "http:\/\/4sq.com\/13uwTdi",
      "display_url" : "4sq.com\/13uwTdi"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6597536102, -121.8863368034 ]
  },
  "id_str" : "353938867361021952",
  "text" : "Fairin' (@ Alameda County Fairgrounds w\/ @sharon @kellianne) [pic]: http:\/\/t.co\/nnPFgg6zIG",
  "id" : 353938867361021952,
  "created_at" : "2013-07-07 18:09:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Slavin(public)",
      "screen_name" : "slavin_fpo",
      "indices" : [ 84, 95 ],
      "id_str" : "17561826",
      "id" : 17561826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/r1vdLJaCe7",
      "expanded_url" : "http:\/\/vimeo.com\/69181785",
      "display_url" : "vimeo.com\/69181785"
    } ]
  },
  "geo" : { },
  "id_str" : "353903210886475776",
  "text" : "How cat people are created: http:\/\/t.co\/r1vdLJaCe7 (by the always thought-provoking @slavin_fpo)",
  "id" : 353903210886475776,
  "created_at" : "2013-07-07 15:47:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596583568, -122.2755058018 ]
  },
  "id_str" : "353741266590244864",
  "text" : "Watching Black Mirror episode one.",
  "id" : 353741266590244864,
  "created_at" : "2013-07-07 05:04:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353725303929057280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597978736, -122.2754446977 ]
  },
  "id_str" : "353735154562379776",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler Yeah that was super interesting.",
  "id" : 353735154562379776,
  "in_reply_to_status_id" : 353725303929057280,
  "created_at" : "2013-07-07 04:40:07 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seth Webster \u24CB",
      "screen_name" : "sethwebster",
      "indices" : [ 0, 12 ],
      "id_str" : "14573883",
      "id" : 14573883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353698652298018818",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596567223, -122.275634464 ]
  },
  "id_str" : "353732462729363457",
  "in_reply_to_user_id" : 14573883,
  "text" : "@sethwebster Nah, it's been around.",
  "id" : 353732462729363457,
  "in_reply_to_status_id" : 353698652298018818,
  "created_at" : "2013-07-07 04:29:25 +0000",
  "in_reply_to_screen_name" : "sethwebster",
  "in_reply_to_user_id_str" : "14573883",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/WLh4iGvPQ2",
      "expanded_url" : "http:\/\/flic.kr\/p\/f4vG55",
      "display_url" : "flic.kr\/p\/f4vG55"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859702, -122.275445 ]
  },
  "id_str" : "353731871147962369",
  "text" : "8:36pm We were fighting during bath time but we made up during story time http:\/\/t.co\/WLh4iGvPQ2",
  "id" : 353731871147962369,
  "created_at" : "2013-07-07 04:27:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8637046274, -122.275862691 ]
  },
  "id_str" : "353694175310520321",
  "text" : "I'm morbidly infobese.",
  "id" : 353694175310520321,
  "created_at" : "2013-07-07 01:57:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/rv0A3gXwlX",
      "expanded_url" : "http:\/\/flic.kr\/p\/f4cnrc",
      "display_url" : "flic.kr\/p\/f4cnrc"
    } ]
  },
  "geo" : { },
  "id_str" : "353692175348932608",
  "text" : "It's snacks in a park o'clock http:\/\/t.co\/rv0A3gXwlX",
  "id" : 353692175348932608,
  "created_at" : "2013-07-07 01:49:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Deschamps",
      "screen_name" : "manuel",
      "indices" : [ 0, 7 ],
      "id_str" : "104071721",
      "id" : 104071721
    }, {
      "name" : "Bryan Haggerty",
      "screen_name" : "bhaggs",
      "indices" : [ 8, 15 ],
      "id_str" : "1692881",
      "id" : 1692881
    }, {
      "name" : "Reeve S. Thompson ",
      "screen_name" : "Reeve",
      "indices" : [ 20, 26 ],
      "id_str" : "9317922",
      "id" : 9317922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353686009797558272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8634564986, -122.2760876511 ]
  },
  "id_str" : "353689899813179393",
  "in_reply_to_user_id" : 104071721,
  "text" : "@manuel @bhaggs \/cc @reeve",
  "id" : 353689899813179393,
  "in_reply_to_status_id" : 353686009797558272,
  "created_at" : "2013-07-07 01:40:18 +0000",
  "in_reply_to_screen_name" : "manuel",
  "in_reply_to_user_id_str" : "104071721",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "susan wu",
      "screen_name" : "sw",
      "indices" : [ 0, 3 ],
      "id_str" : "893211",
      "id" : 893211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353653279504343041",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85977004, -122.2753800884 ]
  },
  "id_str" : "353672192975831040",
  "in_reply_to_user_id" : 893211,
  "text" : "@sw True. And they couldn't have planned a cuter destruction of a habitat.",
  "id" : 353672192975831040,
  "in_reply_to_status_id" : 353653279504343041,
  "created_at" : "2013-07-07 00:29:56 +0000",
  "in_reply_to_screen_name" : "sw",
  "in_reply_to_user_id_str" : "893211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Reich",
      "screen_name" : "ohheygreat",
      "indices" : [ 0, 11 ],
      "id_str" : "9670142",
      "id" : 9670142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353660300618240001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597712264, -122.2755800508 ]
  },
  "id_str" : "353662089639895040",
  "in_reply_to_user_id" : 9670142,
  "text" : "@ohheygreat And you'll keep them as long as you keep talking only about said tragedy.",
  "id" : 353662089639895040,
  "in_reply_to_status_id" : 353660300618240001,
  "created_at" : "2013-07-06 23:49:47 +0000",
  "in_reply_to_screen_name" : "ohheygreat",
  "in_reply_to_user_id_str" : "9670142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Powazek",
      "screen_name" : "fraying",
      "indices" : [ 3, 11 ],
      "id_str" : "4999",
      "id" : 4999
    }, {
      "name" : "THE Lance Arthur",
      "screen_name" : "thelancearthur",
      "indices" : [ 26, 41 ],
      "id_str" : "143569237",
      "id" : 143569237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/KxVEThqDik",
      "expanded_url" : "http:\/\/sfy.co\/iNc4",
      "display_url" : "sfy.co\/iNc4"
    } ]
  },
  "geo" : { },
  "id_str" : "353644178145689600",
  "text" : "RT @fraying: Last Sunday, @thelancearthur posted a string of tweets too great to be missed, so:\nThe State of the Same-Sex Union: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "THE Lance Arthur",
        "screen_name" : "thelancearthur",
        "indices" : [ 13, 28 ],
        "id_str" : "143569237",
        "id" : 143569237
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/KxVEThqDik",
        "expanded_url" : "http:\/\/sfy.co\/iNc4",
        "display_url" : "sfy.co\/iNc4"
      } ]
    },
    "geo" : { },
    "id_str" : "353639773287628800",
    "text" : "Last Sunday, @thelancearthur posted a string of tweets too great to be missed, so:\nThe State of the Same-Sex Union: http:\/\/t.co\/KxVEThqDik",
    "id" : 353639773287628800,
    "created_at" : "2013-07-06 22:21:06 +0000",
    "user" : {
      "name" : "Derek Powazek",
      "screen_name" : "fraying",
      "protected" : false,
      "id_str" : "4999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460906468703600641\/cTszEMo6_normal.jpeg",
      "id" : 4999,
      "verified" : false
    }
  },
  "id" : 353644178145689600,
  "created_at" : "2013-07-06 22:38:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 49, 57 ],
      "id_str" : "14097392",
      "id" : 14097392
    }, {
      "name" : "Dan Shipper",
      "screen_name" : "danshipper",
      "indices" : [ 103, 114 ],
      "id_str" : "19829693",
      "id" : 19829693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/bnrUyGLwY1",
      "expanded_url" : "http:\/\/buff.ly\/17Nel69",
      "display_url" : "buff.ly\/17Nel69"
    } ]
  },
  "in_reply_to_status_id_str" : "353626429348519937",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8259742121, -122.3011643999 ]
  },
  "id_str" : "353641854446731265",
  "in_reply_to_user_id" : 14097392,
  "text" : "Good summary of System 1 vs System 2 thinking RT @nireyal: \"So that\u2019s what they were talking about\" by @danshipper http:\/\/t.co\/bnrUyGLwY1",
  "id" : 353641854446731265,
  "in_reply_to_status_id" : 353626429348519937,
  "created_at" : "2013-07-06 22:29:23 +0000",
  "in_reply_to_screen_name" : "nireyal",
  "in_reply_to_user_id_str" : "14097392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8067030013, -122.4104612322 ]
  },
  "id_str" : "353631606516350977",
  "text" : "The new otters at the SF Aquarium are tearing out all the plants and building a leaf fort, and the terrarium designers stand by shrugging.",
  "id" : 353631606516350977,
  "created_at" : "2013-07-06 21:48:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "movingsidewalkftw",
      "indices" : [ 120, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353614567328333824",
  "text" : "Me: \"What was your favorite thing at the aquarium? The jellyfish? The otters?\" Niko: \"I saw a sidewalk that went away.\" #movingsidewalkftw",
  "id" : 353614567328333824,
  "created_at" : "2013-07-06 20:40:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Eun",
      "screen_name" : "Eunner",
      "indices" : [ 3, 10 ],
      "id_str" : "22503430",
      "id" : 22503430
    }, {
      "name" : "flySFO",
      "screen_name" : "flySFO",
      "indices" : [ 106, 113 ],
      "id_str" : "16408759",
      "id" : 16408759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/E6Ur1XEfa4",
      "expanded_url" : "https:\/\/path.com\/p\/1lwrZb",
      "display_url" : "path.com\/p\/1lwrZb"
    } ]
  },
  "geo" : { },
  "id_str" : "353612629484380160",
  "text" : "RT @Eunner: I just crash landed at SFO. Tail ripped off. Most everyone seems fine. I'm ok. Surreal... (at @flySFO) [pic] \u2014 https:\/\/t.co\/E6U\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/path.com\/\" rel=\"nofollow\"\u003EPath\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "flySFO",
        "screen_name" : "flySFO",
        "indices" : [ 94, 101 ],
        "id_str" : "16408759",
        "id" : 16408759
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/E6Ur1XEfa4",
        "expanded_url" : "https:\/\/path.com\/p\/1lwrZb",
        "display_url" : "path.com\/p\/1lwrZb"
      } ]
    },
    "geo" : { },
    "id_str" : "353592664526028801",
    "text" : "I just crash landed at SFO. Tail ripped off. Most everyone seems fine. I'm ok. Surreal... (at @flySFO) [pic] \u2014 https:\/\/t.co\/E6Ur1XEfa4",
    "id" : 353592664526028801,
    "created_at" : "2013-07-06 19:13:55 +0000",
    "user" : {
      "name" : "David Eun",
      "screen_name" : "Eunner",
      "protected" : false,
      "id_str" : "22503430",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1271657174\/SuperCompressed_Headshot0506_normal.jpg",
      "id" : 22503430,
      "verified" : false
    }
  },
  "id" : 353612629484380160,
  "created_at" : "2013-07-06 20:33:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/MmwwBrnr8J",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Heuristics",
      "display_url" : "en.wikipedia.org\/wiki\/Heuristics"
    } ]
  },
  "in_reply_to_status_id_str" : "353559193103515649",
  "geo" : { },
  "id_str" : "353560442490208258",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc and here are our search algorithms: http:\/\/t.co\/MmwwBrnr8J",
  "id" : 353560442490208258,
  "in_reply_to_status_id" : 353559193103515649,
  "created_at" : "2013-07-06 17:05:52 +0000",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Waters",
      "screen_name" : "oliverwaters",
      "indices" : [ 44, 57 ],
      "id_str" : "14257869",
      "id" : 14257869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/rhBP8xTDxJ",
      "expanded_url" : "http:\/\/youtu.be\/eGimzB5QM1M",
      "display_url" : "youtu.be\/eGimzB5QM1M"
    } ]
  },
  "in_reply_to_status_id_str" : "353405777169489920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596697187, -122.2755238372 ]
  },
  "id_str" : "353411341677101057",
  "in_reply_to_user_id" : 14257869,
  "text" : "Woah, this rocket can take off AND LAND! RT @oliverwaters: SpaceX Grasshopper 325m Test from Hexacopter http:\/\/t.co\/rhBP8xTDxJ",
  "id" : 353411341677101057,
  "in_reply_to_status_id" : 353405777169489920,
  "created_at" : "2013-07-06 07:13:24 +0000",
  "in_reply_to_screen_name" : "oliverwaters",
  "in_reply_to_user_id_str" : "14257869",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353330337650184192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8686972257, -122.2683704344 ]
  },
  "id_str" : "353366322953994242",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Looking forward to taking him to the *next* Muppet movie!",
  "id" : 353366322953994242,
  "in_reply_to_status_id" : 353330337650184192,
  "created_at" : "2013-07-06 04:14:31 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Regales",
      "screen_name" : "bmorerican",
      "indices" : [ 0, 11 ],
      "id_str" : "23912695",
      "id" : 23912695
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 12, 22 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353336290021883905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8686881838, -122.2681917022 ]
  },
  "id_str" : "353366048579403778",
  "in_reply_to_user_id" : 23912695,
  "text" : "@bmorerican @kellianne He did great! Some parts seemed loud to me too but it didn't seem to bother him much.",
  "id" : 353366048579403778,
  "in_reply_to_status_id" : 353336290021883905,
  "created_at" : "2013-07-06 04:13:25 +0000",
  "in_reply_to_screen_name" : "bmorerican",
  "in_reply_to_user_id_str" : "23912695",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/woVFtozIqp",
      "expanded_url" : "http:\/\/flic.kr\/p\/f3Bjxn",
      "display_url" : "flic.kr\/p\/f3Bjxn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.868466, -122.26877 ]
  },
  "id_str" : "353365980312907776",
  "text" : "8:36pm Niko's review: \"Not too scary. Just a little bit.\" http:\/\/t.co\/woVFtozIqp",
  "id" : 353365980312907776,
  "created_at" : "2013-07-06 04:13:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/qQMZbMDMBg",
      "expanded_url" : "http:\/\/4sq.com\/17TWj2e",
      "display_url" : "4sq.com\/17TWj2e"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8688021549, -122.2680151463 ]
  },
  "id_str" : "353333478504415232",
  "text" : "Niko's first movie theater movie (@ Shattuck Cinemas for Monsters University) http:\/\/t.co\/qQMZbMDMBg",
  "id" : 353333478504415232,
  "created_at" : "2013-07-06 02:04:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 6, 17 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596952257, -122.2756212094 ]
  },
  "id_str" : "353311174198165504",
  "text" : "Asked @nikobenson if he wanted to go see a movie ON THE BIG SCREEN for the 1st time. He proceeded to summarize the plot of Monsters U to us.",
  "id" : 353311174198165504,
  "created_at" : "2013-07-06 00:35:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marissalorette",
      "screen_name" : "marissalorette",
      "indices" : [ 0, 15 ],
      "id_str" : "1490561570",
      "id" : 1490561570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596983385, -122.275483003 ]
  },
  "id_str" : "353044528250355713",
  "in_reply_to_user_id" : 1490561570,
  "text" : "@marissalorette Found you! Bummed I missed out on the indiegogo fun... I'll get it next time. Great seeing you all today!",
  "id" : 353044528250355713,
  "created_at" : "2013-07-05 06:55:49 +0000",
  "in_reply_to_screen_name" : "marissalorette",
  "in_reply_to_user_id_str" : "1490561570",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353029003738755073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597562787, -122.2754648529 ]
  },
  "id_str" : "353029704040710144",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc What did you hear?",
  "id" : 353029704040710144,
  "in_reply_to_status_id" : 353029003738755073,
  "created_at" : "2013-07-05 05:56:55 +0000",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/ArKzsighBB",
      "expanded_url" : "https:\/\/vine.co\/v\/hWrLztTlP5I",
      "display_url" : "vine.co\/v\/hWrLztTlP5I"
    } ]
  },
  "geo" : { },
  "id_str" : "352999523477504001",
  "text" : "Are you ready for fireworks??? https:\/\/t.co\/ArKzsighBB",
  "id" : 352999523477504001,
  "created_at" : "2013-07-05 03:56:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/oNIWBCSLSJ",
      "expanded_url" : "http:\/\/flic.kr\/p\/f3d3fW",
      "display_url" : "flic.kr\/p\/f3d3fW"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859722, -122.275581 ]
  },
  "id_str" : "352995379123458049",
  "text" : "8:36pm Nora Lee left her patriotic ears at the party http:\/\/t.co\/oNIWBCSLSJ",
  "id" : 352995379123458049,
  "created_at" : "2013-07-05 03:40:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vinefail",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/dlYnYhelBd",
      "expanded_url" : "http:\/\/flickr.com\/gp\/erikbenson\/1818XY\/photos\/erikbenson\/9210992179\/",
      "display_url" : "flickr.com\/gp\/erikbenson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352984742729232386",
  "text" : "Kids of Summer 6-sec documentary #vinefail http:\/\/t.co\/dlYnYhelBd",
  "id" : 352984742729232386,
  "created_at" : "2013-07-05 02:58:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/ZrZg1cVaCH",
      "expanded_url" : "https:\/\/vine.co\/v\/hWvVw1Ljhwd",
      "display_url" : "vine.co\/v\/hWvVw1Ljhwd"
    } ]
  },
  "geo" : { },
  "id_str" : "352964601589137409",
  "text" : "Kids entering bubble world https:\/\/t.co\/ZrZg1cVaCH",
  "id" : 352964601589137409,
  "created_at" : "2013-07-05 01:38:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352914426636148736",
  "text" : "RT if you're drunk already.",
  "id" : 352914426636148736,
  "created_at" : "2013-07-04 22:18:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Kesterson",
      "screen_name" : "kylekesterson",
      "indices" : [ 0, 14 ],
      "id_str" : "20256785",
      "id" : 20256785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/KYG01QzZPt",
      "expanded_url" : "https:\/\/twitter.com\/jack\/status\/352641990908850176",
      "display_url" : "twitter.com\/jack\/status\/35\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "352909111643475970",
  "geo" : { },
  "id_str" : "352909961984098304",
  "in_reply_to_user_id" : 20256785,
  "text" : "@kylekesterson https:\/\/t.co\/KYG01QzZPt",
  "id" : 352909961984098304,
  "in_reply_to_status_id" : 352909111643475970,
  "created_at" : "2013-07-04 22:01:06 +0000",
  "in_reply_to_screen_name" : "kylekesterson",
  "in_reply_to_user_id_str" : "20256785",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352908691567157249",
  "text" : "Vines of Fireworks Per Second (VFPS)",
  "id" : 352908691567157249,
  "created_at" : "2013-07-04 21:56:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ouch",
      "indices" : [ 41, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352901492879028224",
  "geo" : { },
  "id_str" : "352902832959139841",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver Nothing another beer can't fix. #ouch",
  "id" : 352902832959139841,
  "in_reply_to_status_id" : 352901492879028224,
  "created_at" : "2013-07-04 21:32:46 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.rdio.com\" rel=\"nofollow\"\u003ERdio\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rdio",
      "screen_name" : "Rdio",
      "indices" : [ 74, 79 ],
      "id_str" : "54205414",
      "id" : 54205414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/jMA76fQgW3",
      "expanded_url" : "http:\/\/rd.io\/x\/QFvDL0IKCg\/",
      "display_url" : "rd.io\/x\/QFvDL0IKCg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "352899248414666753",
  "text" : "This one looks pretty good: \"Top 424 HAPPY 4th OF JULY!\" by Dave Novak on @Rdio: http:\/\/t.co\/jMA76fQgW3",
  "id" : 352899248414666753,
  "created_at" : "2013-07-04 21:18:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rdio",
      "screen_name" : "Rdio",
      "indices" : [ 48, 53 ],
      "id_str" : "54205414",
      "id" : 54205414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352898530186235904",
  "text" : "Who made the best 4th of July party playlist on @rdio?",
  "id" : 352898530186235904,
  "created_at" : "2013-07-04 21:15:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352875828310310913",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597193294, -122.2756434374 ]
  },
  "id_str" : "352879771195158529",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel It'd be even better if we had some Pixels around!",
  "id" : 352879771195158529,
  "in_reply_to_status_id" : 352875828310310913,
  "created_at" : "2013-07-04 20:01:08 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/WJEHNMST2c",
      "expanded_url" : "http:\/\/flic.kr\/p\/f2YNSY",
      "display_url" : "flic.kr\/p\/f2YNSY"
    } ]
  },
  "geo" : { },
  "id_str" : "352871423326425088",
  "text" : "4th of July Man can fly if he concentrates http:\/\/t.co\/WJEHNMST2c",
  "id" : 352871423326425088,
  "created_at" : "2013-07-04 19:27:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/8lkS73iSs1",
      "expanded_url" : "https:\/\/vine.co\/v\/hW1WbKt3X2v",
      "display_url" : "vine.co\/v\/hW1WbKt3X2v"
    } ]
  },
  "geo" : { },
  "id_str" : "352870777500090372",
  "text" : "4th of July Man just ran past me https:\/\/t.co\/8lkS73iSs1",
  "id" : 352870777500090372,
  "created_at" : "2013-07-04 19:25:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352827285222592513",
  "text" : "Who are the entrepreneurs today who are founding countries instead of companies?",
  "id" : 352827285222592513,
  "created_at" : "2013-07-04 16:32:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352816587306315777",
  "text" : "RT @neiltyson: A thought to disturb slumber: The letters that spell \"eleven plus two\" also spell \"twelve plus one\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352482213658509312",
    "text" : "A thought to disturb slumber: The letters that spell \"eleven plus two\" also spell \"twelve plus one\"",
    "id" : 352482213658509312,
    "created_at" : "2013-07-03 17:41:23 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 352816587306315777,
  "created_at" : "2013-07-04 15:50:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 0, 8 ],
      "id_str" : "5699",
      "id" : 5699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352679773190881280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859749062, -122.2754766324 ]
  },
  "id_str" : "352683504972206081",
  "in_reply_to_user_id" : 5699,
  "text" : "@stewart Ooh la la. Signed all up with a bow on it!",
  "id" : 352683504972206081,
  "in_reply_to_status_id" : 352679773190881280,
  "created_at" : "2013-07-04 07:01:14 +0000",
  "in_reply_to_screen_name" : "stewart",
  "in_reply_to_user_id_str" : "5699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 0, 8 ],
      "id_str" : "5699",
      "id" : 5699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352651575757516800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597700893, -122.2755891738 ]
  },
  "id_str" : "352651933162553344",
  "in_reply_to_user_id" : 5699,
  "text" : "@stewart How do I sign up for the beta??",
  "id" : 352651933162553344,
  "in_reply_to_status_id" : 352651575757516800,
  "created_at" : "2013-07-04 04:55:47 +0000",
  "in_reply_to_screen_name" : "stewart",
  "in_reply_to_user_id_str" : "5699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/308hJ9q1Rc",
      "expanded_url" : "http:\/\/flic.kr\/p\/f2hVbr",
      "display_url" : "flic.kr\/p\/f2hVbr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85975, -122.275467 ]
  },
  "id_str" : "352633124418617344",
  "text" : "8:36pm Watching the Muppets (again) http:\/\/t.co\/308hJ9q1Rc",
  "id" : 352633124418617344,
  "created_at" : "2013-07-04 03:41:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Moberg",
      "screen_name" : "patrickmoberg",
      "indices" : [ 0, 14 ],
      "id_str" : "4102571",
      "id" : 4102571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597675004, -122.275386212 ]
  },
  "id_str" : "352628818013458433",
  "in_reply_to_user_id" : 4102571,
  "text" : "@patrickmoberg Could you draw a 5-winged duck?",
  "id" : 352628818013458433,
  "created_at" : "2013-07-04 03:23:56 +0000",
  "in_reply_to_screen_name" : "patrickmoberg",
  "in_reply_to_user_id_str" : "4102571",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 0, 9 ],
      "id_str" : "14986129",
      "id" : 14986129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597286137, -122.2754950576 ]
  },
  "id_str" : "352628339749568512",
  "in_reply_to_user_id" : 14986129,
  "text" : "@irondavy Could you draw a 5-winged duck?",
  "id" : 352628339749568512,
  "created_at" : "2013-07-04 03:22:02 +0000",
  "in_reply_to_screen_name" : "irondavy",
  "in_reply_to_user_id_str" : "14986129",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 0, 10 ],
      "id_str" : "13349",
      "id" : 13349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352576339699712000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776951285, -122.4172938443 ]
  },
  "id_str" : "352577501312188417",
  "in_reply_to_user_id" : 13349,
  "text" : "@ryanchris Uber's new beta test.",
  "id" : 352577501312188417,
  "in_reply_to_status_id" : 352576339699712000,
  "created_at" : "2013-07-04 00:00:01 +0000",
  "in_reply_to_screen_name" : "ryanchris",
  "in_reply_to_user_id_str" : "13349",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 0, 4 ],
      "id_str" : "12720772",
      "id" : 12720772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352572914035458049",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7770393859, -122.4171805824 ]
  },
  "id_str" : "352577217269743616",
  "in_reply_to_user_id" : 12720772,
  "text" : "@gwb You just outted yourself as one of the enlightened.",
  "id" : 352577217269743616,
  "in_reply_to_status_id" : 352572914035458049,
  "created_at" : "2013-07-03 23:58:53 +0000",
  "in_reply_to_screen_name" : "gwb",
  "in_reply_to_user_id_str" : "12720772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352572509415145472",
  "text" : "RT if you've reached enlightenment.",
  "id" : 352572509415145472,
  "created_at" : "2013-07-03 23:40:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allison kudla",
      "screen_name" : "allisonx",
      "indices" : [ 0, 9 ],
      "id_str" : "14047537",
      "id" : 14047537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352558217429131264",
  "geo" : { },
  "id_str" : "352564827538984962",
  "in_reply_to_user_id" : 14047537,
  "text" : "@allisonx Oh man that guy is awesome!!",
  "id" : 352564827538984962,
  "in_reply_to_status_id" : 352558217429131264,
  "created_at" : "2013-07-03 23:09:39 +0000",
  "in_reply_to_screen_name" : "allisonx",
  "in_reply_to_user_id_str" : "14047537",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allison kudla",
      "screen_name" : "allisonx",
      "indices" : [ 121, 130 ],
      "id_str" : "14047537",
      "id" : 14047537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/4RpxmCOfPn",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/ashleyperez\/this-teacher-wore-the-same-exact-outfit-in-his-yearbook-phot",
      "display_url" : "buzzfeed.com\/ashleyperez\/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352564767774355457",
  "text" : "Rad: \"This Teacher Wore The Same Exact Outfit In His Yearbook Photo Every Year For 40 Years\" http:\/\/t.co\/4RpxmCOfPn \/via @allisonx",
  "id" : 352564767774355457,
  "created_at" : "2013-07-03 23:09:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Chipps",
      "screen_name" : "SaraJChipps",
      "indices" : [ 3, 15 ],
      "id_str" : "15524875",
      "id" : 15524875
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SaraJChipps\/status\/352543729518796800\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/CpV83pblZY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOR8p3YCYAAvERD.jpg",
      "id_str" : "352543729522991104",
      "id" : 352543729522991104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOR8p3YCYAAvERD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/CpV83pblZY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352547654145810432",
  "text" : "RT @SaraJChipps: They weren't kidding. http:\/\/t.co\/CpV83pblZY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SaraJChipps\/status\/352543729518796800\/photo\/1",
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/CpV83pblZY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BOR8p3YCYAAvERD.jpg",
        "id_str" : "352543729522991104",
        "id" : 352543729522991104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOR8p3YCYAAvERD.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/CpV83pblZY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352543729518796800",
    "text" : "They weren't kidding. http:\/\/t.co\/CpV83pblZY",
    "id" : 352543729518796800,
    "created_at" : "2013-07-03 21:45:49 +0000",
    "user" : {
      "name" : "Sara Chipps",
      "screen_name" : "SaraJChipps",
      "protected" : false,
      "id_str" : "15524875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453283149967937536\/GxvTKRk1_normal.png",
      "id" : 15524875,
      "verified" : false
    }
  },
  "id" : 352547654145810432,
  "created_at" : "2013-07-03 22:01:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Bogan",
      "screen_name" : "waferbaby",
      "indices" : [ 0, 10 ],
      "id_str" : "821753",
      "id" : 821753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352521802121097216",
  "geo" : { },
  "id_str" : "352522111895601154",
  "in_reply_to_user_id" : 821753,
  "text" : "@waferbaby sorry for tweet-faving that. what's wrong?",
  "id" : 352522111895601154,
  "in_reply_to_status_id" : 352521802121097216,
  "created_at" : "2013-07-03 20:19:55 +0000",
  "in_reply_to_screen_name" : "waferbaby",
  "in_reply_to_user_id_str" : "821753",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Bogan",
      "screen_name" : "waferbaby",
      "indices" : [ 0, 10 ],
      "id_str" : "821753",
      "id" : 821753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352518941890973697",
  "geo" : { },
  "id_str" : "352521684743495680",
  "in_reply_to_user_id" : 821753,
  "text" : "@waferbaby just follow-vined you.",
  "id" : 352521684743495680,
  "in_reply_to_status_id" : 352518941890973697,
  "created_at" : "2013-07-03 20:18:13 +0000",
  "in_reply_to_screen_name" : "waferbaby",
  "in_reply_to_user_id_str" : "821753",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352511984241086467",
  "text" : "You can now re-vine things. That's awesome!",
  "id" : 352511984241086467,
  "created_at" : "2013-07-03 19:39:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dom Hofmann",
      "screen_name" : "dhof",
      "indices" : [ 3, 8 ],
      "id_str" : "13258512",
      "id" : 13258512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/j3dODq2NEP",
      "expanded_url" : "http:\/\/vine.co\/blog\/discover-share",
      "display_url" : "vine.co\/blog\/discover-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352511422682509314",
  "text" : "RT @dhof: We put out a big Vine update today, if you're into that sort of thing. http:\/\/t.co\/j3dODq2NEP",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/j3dODq2NEP",
        "expanded_url" : "http:\/\/vine.co\/blog\/discover-share",
        "display_url" : "vine.co\/blog\/discover-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "352510546165248001",
    "text" : "We put out a big Vine update today, if you're into that sort of thing. http:\/\/t.co\/j3dODq2NEP",
    "id" : 352510546165248001,
    "created_at" : "2013-07-03 19:33:58 +0000",
    "user" : {
      "name" : "Dom Hofmann",
      "screen_name" : "dhof",
      "protected" : false,
      "id_str" : "13258512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465999349227737088\/H3Xl8anY_normal.jpeg",
      "id" : 13258512,
      "verified" : false
    }
  },
  "id" : 352511422682509314,
  "created_at" : "2013-07-03 19:37:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Lynch",
      "screen_name" : "DAVID_LYNCH",
      "indices" : [ 3, 15 ],
      "id_str" : "15962096",
      "id" : 15962096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352470578726318081",
  "text" : "RT @DAVID_LYNCH: Dear Twitter Friends, the happy squirrels are running fast and free.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352458991806324737",
    "text" : "Dear Twitter Friends, the happy squirrels are running fast and free.",
    "id" : 352458991806324737,
    "created_at" : "2013-07-03 16:09:06 +0000",
    "user" : {
      "name" : "David Lynch",
      "screen_name" : "DAVID_LYNCH",
      "protected" : false,
      "id_str" : "15962096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/63730229\/DL_normal.jpg",
      "id" : 15962096,
      "verified" : true
    }
  },
  "id" : 352470578726318081,
  "created_at" : "2013-07-03 16:55:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352469679010361346",
  "geo" : { },
  "id_str" : "352470280662286336",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash But wait, some guy told me there was a lockdown going on.",
  "id" : 352470280662286336,
  "in_reply_to_status_id" : 352469679010361346,
  "created_at" : "2013-07-03 16:53:58 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 15, 25 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352347347512074240",
  "geo" : { },
  "id_str" : "352434575521234946",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin @kellianne That's very close to us! We'll definitely go and see if she's there.",
  "id" : 352434575521234946,
  "in_reply_to_status_id" : 352347347512074240,
  "created_at" : "2013-07-03 14:32:05 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan D. Gantz, CPK",
      "screen_name" : "sixfoot6",
      "indices" : [ 0, 9 ],
      "id_str" : "822030",
      "id" : 822030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352303406532132865",
  "geo" : { },
  "id_str" : "352307042771402754",
  "in_reply_to_user_id" : 822030,
  "text" : "@sixfoot6 I think there are times of quick scaffolding and times of slower iterative change. We're all of the photo sensors before the eye.",
  "id" : 352307042771402754,
  "in_reply_to_status_id" : 352303406532132865,
  "created_at" : "2013-07-03 06:05:19 +0000",
  "in_reply_to_screen_name" : "sixfoot6",
  "in_reply_to_user_id_str" : "822030",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352302846546415617",
  "text" : "The premonition that everything happening with tech\/web between 1990-2050 will be summarized as throw away scaffolding \/ transition years.",
  "id" : 352302846546415617,
  "created_at" : "2013-07-03 05:48:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352298899022680064",
  "geo" : { },
  "id_str" : "352299592043331584",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake The anger seems to come bc some of us came to believe we'd defeated Goliath, when it's really still round one on the Internet.",
  "id" : 352299592043331584,
  "in_reply_to_status_id" : 352298899022680064,
  "created_at" : "2013-07-03 05:35:42 +0000",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352294662490439682",
  "geo" : { },
  "id_str" : "352298240160448513",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake I bet the total number of people who know about\/use RSS has actually increased since the golden years. Just not as fast...",
  "id" : 352298240160448513,
  "in_reply_to_status_id" : 352294662490439682,
  "created_at" : "2013-07-03 05:30:20 +0000",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Sharples",
      "screen_name" : "fredsharples",
      "indices" : [ 0, 13 ],
      "id_str" : "18338254",
      "id" : 18338254
    }, {
      "name" : "Bookboard",
      "screen_name" : "bookboard",
      "indices" : [ 14, 24 ],
      "id_str" : "216248980",
      "id" : 216248980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352290852938330112",
  "geo" : { },
  "id_str" : "352292936756637698",
  "in_reply_to_user_id" : 18338254,
  "text" : "@fredsharples @bookboard I haven't! Looks awesome though, I'll take a look!",
  "id" : 352292936756637698,
  "in_reply_to_status_id" : 352290852938330112,
  "created_at" : "2013-07-03 05:09:16 +0000",
  "in_reply_to_screen_name" : "fredsharples",
  "in_reply_to_user_id_str" : "18338254",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/iJlEuz9g5V",
      "expanded_url" : "http:\/\/flic.kr\/p\/f1ScMh",
      "display_url" : "flic.kr\/p\/f1ScMh"
    } ]
  },
  "geo" : { },
  "id_str" : "352287179361361920",
  "text" : "8:36pm Reading Niko all the books he can carry is getting more daunting lately.  http:\/\/t.co\/iJlEuz9g5V",
  "id" : 352287179361361920,
  "created_at" : "2013-07-03 04:46:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352261834230865920",
  "geo" : { },
  "id_str" : "352268635349336065",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler I had a sandwich for lunch.",
  "id" : 352268635349336065,
  "in_reply_to_status_id" : 352261834230865920,
  "created_at" : "2013-07-03 03:32:42 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 0, 4 ],
      "id_str" : "12720772",
      "id" : 12720772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/M8cPpqDMmg",
      "expanded_url" : "https:\/\/readtapestry.com\/s\/RVwPvalHq\/",
      "display_url" : "readtapestry.com\/s\/RVwPvalHq\/"
    } ]
  },
  "in_reply_to_status_id_str" : "352242085899935746",
  "geo" : { },
  "id_str" : "352242698419310593",
  "in_reply_to_user_id" : 12720772,
  "text" : "@gwb I agree: https:\/\/t.co\/M8cPpqDMmg",
  "id" : 352242698419310593,
  "in_reply_to_status_id" : 352242085899935746,
  "created_at" : "2013-07-03 01:49:38 +0000",
  "in_reply_to_screen_name" : "gwb",
  "in_reply_to_user_id_str" : "12720772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 0, 4 ],
      "id_str" : "12720772",
      "id" : 12720772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352240478630055936",
  "geo" : { },
  "id_str" : "352242126265925632",
  "in_reply_to_user_id" : 12720772,
  "text" : "@gwb PS I have no idea how old you are. Could be 23. Could be 53.",
  "id" : 352242126265925632,
  "in_reply_to_status_id" : 352240478630055936,
  "created_at" : "2013-07-03 01:47:21 +0000",
  "in_reply_to_screen_name" : "gwb",
  "in_reply_to_user_id_str" : "12720772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 0, 4 ],
      "id_str" : "12720772",
      "id" : 12720772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352240478630055936",
  "geo" : { },
  "id_str" : "352241430602850306",
  "in_reply_to_user_id" : 12720772,
  "text" : "@gwb Like the fact that we're gonna die soon?",
  "id" : 352241430602850306,
  "in_reply_to_status_id" : 352240478630055936,
  "created_at" : "2013-07-03 01:44:36 +0000",
  "in_reply_to_screen_name" : "gwb",
  "in_reply_to_user_id_str" : "12720772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352241228718415872",
  "text" : "RT if you suck at following your own rules.",
  "id" : 352241228718415872,
  "created_at" : "2013-07-03 01:43:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352235163649982464",
  "geo" : { },
  "id_str" : "352240088324911106",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Seems reasonable to me. I'd probably lower it to 10% given our proven slothiness.",
  "id" : 352240088324911106,
  "in_reply_to_status_id" : 352235163649982464,
  "created_at" : "2013-07-03 01:39:16 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony LoConte",
      "screen_name" : "ToneLoOnTheGo",
      "indices" : [ 3, 17 ],
      "id_str" : "231617609",
      "id" : 231617609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352239612464336896",
  "text" : "RT @ToneLoOnTheGo: Is corn the only thing that's delicious after it explodes?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/favstar.fm\" rel=\"nofollow\"\u003EFavstar.FM\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "202565336489398272",
    "text" : "Is corn the only thing that's delicious after it explodes?",
    "id" : 202565336489398272,
    "created_at" : "2012-05-16 01:05:14 +0000",
    "user" : {
      "name" : "Tony LoConte",
      "screen_name" : "ToneLoOnTheGo",
      "protected" : false,
      "id_str" : "231617609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410791168\/79d35a8b5dd575c56ae2494277b2ccb6_normal.jpeg",
      "id" : 231617609,
      "verified" : false
    }
  },
  "id" : 352239612464336896,
  "created_at" : "2013-07-03 01:37:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352236541088776192",
  "text" : "It just struck me that I'm 14 years older than 23 year olds.",
  "id" : 352236541088776192,
  "created_at" : "2013-07-03 01:25:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    }, {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 12, 22 ],
      "id_str" : "14110325",
      "id" : 14110325
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 23, 31 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352235062290415616",
  "geo" : { },
  "id_str" : "352235251331903489",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold @jayholler @mybasis You win.",
  "id" : 352235251331903489,
  "in_reply_to_status_id" : 352235062290415616,
  "created_at" : "2013-07-03 01:20:02 +0000",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    }, {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 12, 22 ],
      "id_str" : "14110325",
      "id" : 14110325
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 35, 43 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352233681647181824",
  "geo" : { },
  "id_str" : "352234764490649603",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold @jayholler Why not the @mybasis? Real question is: what will you use this data for?",
  "id" : 352234764490649603,
  "in_reply_to_status_id" : 352233681647181824,
  "created_at" : "2013-07-03 01:18:06 +0000",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352230717134082049",
  "geo" : { },
  "id_str" : "352231390944825344",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler It's true, they have the best data but not enough tools to find the real signal. Can't wait for their API.",
  "id" : 352231390944825344,
  "in_reply_to_status_id" : 352230717134082049,
  "created_at" : "2013-07-03 01:04:42 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "megan hunt",
      "screen_name" : "lasertron",
      "indices" : [ 0, 10 ],
      "id_str" : "17915737",
      "id" : 17915737
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 11, 20 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 68, 79 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352230067167961089",
  "geo" : { },
  "id_str" : "352231085469483008",
  "in_reply_to_user_id" : 17915737,
  "text" : "@lasertron @anildash That's awesome. I need to get back on tweeting @nikobenson's best quotes. Clearly the world needs more 3yo humor.",
  "id" : 352231085469483008,
  "in_reply_to_status_id" : 352230067167961089,
  "created_at" : "2013-07-03 01:03:29 +0000",
  "in_reply_to_screen_name" : "lasertron",
  "in_reply_to_user_id_str" : "17915737",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352229441155502081",
  "geo" : { },
  "id_str" : "352230000436580352",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler I do. It is pretty amazing but will be better when they have an iphone app and an API. (Android app is already out)",
  "id" : 352230000436580352,
  "in_reply_to_status_id" : 352229441155502081,
  "created_at" : "2013-07-03 00:59:10 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Rogers",
      "screen_name" : "smfrogers",
      "indices" : [ 18, 28 ],
      "id_str" : "14420872",
      "id" : 14420872
    }, {
      "name" : "Twitter Data",
      "screen_name" : "TwitterData",
      "indices" : [ 42, 54 ],
      "id_str" : "1526228120",
      "id" : 1526228120
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "followtuesday",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352192272361721856",
  "text" : "#followtuesday RT @smfrogers: Introducing @TwitterData. It will become the place for great Twitter dataviz and analysis",
  "id" : 352192272361721856,
  "created_at" : "2013-07-02 22:29:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 3, 12 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BuzzFeed\/status\/347427770558726144\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/BNbxC7qbHt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNJPt3GCQAAaw-U.jpg",
      "id_str" : "347427770562920448",
      "id" : 347427770562920448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNJPt3GCQAAaw-U.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/BNbxC7qbHt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/KqOQ3jr0NM",
      "expanded_url" : "http:\/\/bzfd.it\/1atOYbC",
      "display_url" : "bzfd.it\/1atOYbC"
    } ]
  },
  "geo" : { },
  "id_str" : "352188243288137728",
  "text" : "RT @BuzzFeed: RIP Society http:\/\/t.co\/KqOQ3jr0NM http:\/\/t.co\/BNbxC7qbHt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BuzzFeed\/status\/347427770558726144\/photo\/1",
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/BNbxC7qbHt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BNJPt3GCQAAaw-U.jpg",
        "id_str" : "347427770562920448",
        "id" : 347427770562920448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNJPt3GCQAAaw-U.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        } ],
        "display_url" : "pic.twitter.com\/BNbxC7qbHt"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/KqOQ3jr0NM",
        "expanded_url" : "http:\/\/bzfd.it\/1atOYbC",
        "display_url" : "bzfd.it\/1atOYbC"
      } ]
    },
    "geo" : { },
    "id_str" : "347562927768866816",
    "text" : "RIP Society http:\/\/t.co\/KqOQ3jr0NM http:\/\/t.co\/BNbxC7qbHt",
    "id" : 347562927768866816,
    "created_at" : "2013-06-20 03:53:54 +0000",
    "user" : {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "protected" : false,
      "id_str" : "5695632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2852410605\/6e6da28a06cfd7aea20a3cc393ef1182_normal.png",
      "id" : 5695632,
      "verified" : true
    }
  },
  "id" : 352188243288137728,
  "created_at" : "2013-07-02 22:13:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Heitzeberg",
      "screen_name" : "jheitzeb",
      "indices" : [ 3, 12 ],
      "id_str" : "6629572",
      "id" : 6629572
    }, {
      "name" : "Marc Barros",
      "screen_name" : "marcbarros",
      "indices" : [ 139, 140 ],
      "id_str" : "822774",
      "id" : 822774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/WKtJ0fNOJL",
      "expanded_url" : "http:\/\/marcbarros.com\/why-startups-dont-know-anything-about-craftsmanship",
      "display_url" : "marcbarros.com\/why-startups-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352182513474609152",
  "text" : "RT @jheitzeb: \"[lean startup] is like telling an artist to smear colors on the wall until people buy the painting\" http:\/\/t.co\/WKtJ0fNOJL v\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marc Barros",
        "screen_name" : "marcbarros",
        "indices" : [ 128, 139 ],
        "id_str" : "822774",
        "id" : 822774
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/WKtJ0fNOJL",
        "expanded_url" : "http:\/\/marcbarros.com\/why-startups-dont-know-anything-about-craftsmanship",
        "display_url" : "marcbarros.com\/why-startups-d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "352178327387254785",
    "text" : "\"[lean startup] is like telling an artist to smear colors on the wall until people buy the painting\" http:\/\/t.co\/WKtJ0fNOJL via @marcbarros",
    "id" : 352178327387254785,
    "created_at" : "2013-07-02 21:33:51 +0000",
    "user" : {
      "name" : "Joe Heitzeberg",
      "screen_name" : "jheitzeb",
      "protected" : false,
      "id_str" : "6629572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465359564594876416\/AV-hzn2q_normal.jpeg",
      "id" : 6629572,
      "verified" : false
    }
  },
  "id" : 352182513474609152,
  "created_at" : "2013-07-02 21:50:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 115, 126 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/52XIz1URQp",
      "expanded_url" : "http:\/\/techcrunch.com\/2013\/07\/01\/glasstesla-lets-google-glass-owners-control-their-teslas-like-futuristic-robo-wizards-might\/",
      "display_url" : "techcrunch.com\/2013\/07\/01\/gla\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352164289102098433",
  "text" : "lol \"New App Lets Google Glass Owners Control Their Teslas Like Rich-Ass Robo-Wizards\" http:\/\/t.co\/52XIz1URQp \/via @techcrunch",
  "id" : 352164289102098433,
  "created_at" : "2013-07-02 20:38:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/8lSnT4U3He",
      "expanded_url" : "http:\/\/bit.ly\/10xTbqA",
      "display_url" : "bit.ly\/10xTbqA"
    } ]
  },
  "geo" : { },
  "id_str" : "352158870354935809",
  "text" : "Best comment: \"Regrettably, I think you\u2019re on a dangerous track. It\u2019s the quickest way I know towards perdition.\" http:\/\/t.co\/8lSnT4U3He",
  "id" : 352158870354935809,
  "created_at" : "2013-07-02 20:16:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352134315313868800",
  "geo" : { },
  "id_str" : "352134623070920705",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs Awesome. And yeah, please add me to all the betas! :)",
  "id" : 352134623070920705,
  "in_reply_to_status_id" : 352134315313868800,
  "created_at" : "2013-07-02 18:40:11 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352128819810930688",
  "geo" : { },
  "id_str" : "352129569827987456",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez \"My suggestions for improvement are less cussing and more usage of the future tense.\"",
  "id" : 352129569827987456,
  "in_reply_to_status_id" : 352128819810930688,
  "created_at" : "2013-07-02 18:20:06 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352128663602470914",
  "text" : "TIme to review my peers. How much should I grade them on the quality of their tweets?",
  "id" : 352128663602470914,
  "created_at" : "2013-07-02 18:16:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Menotti Minutillo",
      "screen_name" : "44",
      "indices" : [ 0, 3 ],
      "id_str" : "15067515",
      "id" : 15067515
    }, {
      "name" : "Michael Shafrir",
      "screen_name" : "mcs",
      "indices" : [ 4, 8 ],
      "id_str" : "4612141",
      "id" : 4612141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352120796174495747",
  "geo" : { },
  "id_str" : "352123951117377536",
  "in_reply_to_user_id" : 15067515,
  "text" : "@44 @mcs Yup, all good for now. Thanks.",
  "id" : 352123951117377536,
  "in_reply_to_status_id" : 352120796174495747,
  "created_at" : "2013-07-02 17:57:46 +0000",
  "in_reply_to_screen_name" : "44",
  "in_reply_to_user_id_str" : "15067515",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Menotti Minutillo",
      "screen_name" : "44",
      "indices" : [ 0, 3 ],
      "id_str" : "15067515",
      "id" : 15067515
    }, {
      "name" : "Michael Shafrir",
      "screen_name" : "mcs",
      "indices" : [ 20, 24 ],
      "id_str" : "4612141",
      "id" : 4612141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352119391099428866",
  "geo" : { },
  "id_str" : "352120368447750145",
  "in_reply_to_user_id" : 15067515,
  "text" : "@44 I think so, but @mcs was able to email it to me as an attachment. If anyone else needs it, let me know and I can forward it on.",
  "id" : 352120368447750145,
  "in_reply_to_status_id" : 352119391099428866,
  "created_at" : "2013-07-02 17:43:32 +0000",
  "in_reply_to_screen_name" : "44",
  "in_reply_to_user_id_str" : "15067515",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Shafrir",
      "screen_name" : "mcs",
      "indices" : [ 0, 4 ],
      "id_str" : "4612141",
      "id" : 4612141
    }, {
      "name" : "Menotti Minutillo",
      "screen_name" : "44",
      "indices" : [ 5, 8 ],
      "id_str" : "15067515",
      "id" : 15067515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352111569926225921",
  "geo" : { },
  "id_str" : "352112914649460736",
  "in_reply_to_user_id" : 4612141,
  "text" : "@mcs @44 Okay, I closed Network Connect and Safari and went through those steps again and it worked. Not moving for 8 hrs.",
  "id" : 352112914649460736,
  "in_reply_to_status_id" : 352111569926225921,
  "created_at" : "2013-07-02 17:13:55 +0000",
  "in_reply_to_screen_name" : "mcs",
  "in_reply_to_user_id_str" : "4612141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Shafrir",
      "screen_name" : "mcs",
      "indices" : [ 0, 4 ],
      "id_str" : "4612141",
      "id" : 4612141
    }, {
      "name" : "Menotti Minutillo",
      "screen_name" : "44",
      "indices" : [ 5, 8 ],
      "id_str" : "15067515",
      "id" : 15067515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352111569926225921",
  "geo" : { },
  "id_str" : "352112119438770176",
  "in_reply_to_user_id" : 4612141,
  "text" : "@mcs @44 Oh yeah, forgot about that. Unfortunately, looks like I need to be on the network already to see anything in there. :\/",
  "id" : 352112119438770176,
  "in_reply_to_status_id" : 352111569926225921,
  "created_at" : "2013-07-02 17:10:45 +0000",
  "in_reply_to_screen_name" : "mcs",
  "in_reply_to_user_id_str" : "4612141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Shafrir",
      "screen_name" : "mcs",
      "indices" : [ 0, 4 ],
      "id_str" : "4612141",
      "id" : 4612141
    }, {
      "name" : "Menotti Minutillo",
      "screen_name" : "44",
      "indices" : [ 5, 8 ],
      "id_str" : "15067515",
      "id" : 15067515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352110843112067072",
  "geo" : { },
  "id_str" : "352111386102476800",
  "in_reply_to_user_id" : 4612141,
  "text" : "@mcs @44 I'm not trying to be dumb (it comes naturally) but where do I launch Self Service from?",
  "id" : 352111386102476800,
  "in_reply_to_status_id" : 352110843112067072,
  "created_at" : "2013-07-02 17:07:51 +0000",
  "in_reply_to_screen_name" : "mcs",
  "in_reply_to_user_id_str" : "4612141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Shafrir",
      "screen_name" : "mcs",
      "indices" : [ 0, 4 ],
      "id_str" : "4612141",
      "id" : 4612141
    }, {
      "name" : "Menotti Minutillo",
      "screen_name" : "44",
      "indices" : [ 5, 8 ],
      "id_str" : "15067515",
      "id" : 15067515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351430433411575809",
  "geo" : { },
  "id_str" : "352110602975592448",
  "in_reply_to_user_id" : 4612141,
  "text" : "@mcs @44 I got Network Connect to work once yesterday by updating Java, but now it's not working again. What's this Junos Pulse client?",
  "id" : 352110602975592448,
  "in_reply_to_status_id" : 351430433411575809,
  "created_at" : "2013-07-02 17:04:44 +0000",
  "in_reply_to_screen_name" : "mcs",
  "in_reply_to_user_id_str" : "4612141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Dirac",
      "screen_name" : "leopd",
      "indices" : [ 0, 6 ],
      "id_str" : "5500632",
      "id" : 5500632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352102233996926978",
  "geo" : { },
  "id_str" : "352105440609443845",
  "in_reply_to_user_id" : 5500632,
  "text" : "@leopd The link was so awesome it couldn't even fit in my tweet.",
  "id" : 352105440609443845,
  "in_reply_to_status_id" : 352102233996926978,
  "created_at" : "2013-07-02 16:44:13 +0000",
  "in_reply_to_screen_name" : "leopd",
  "in_reply_to_user_id_str" : "5500632",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Local 123",
      "screen_name" : "local123cafe",
      "indices" : [ 37, 50 ],
      "id_str" : "42094062",
      "id" : 42094062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "workingfromcafe",
      "indices" : [ 4, 20 ]
    }, {
      "text" : "bartstrike",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/O2Y7LQSVuq",
      "expanded_url" : "http:\/\/4sq.com\/13jrOoe",
      "display_url" : "4sq.com\/13jrOoe"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.868468, -122.291749 ]
  },
  "id_str" : "352104530344808449",
  "text" : "WFC #workingfromcafe #bartstrike (at @Local123Cafe) http:\/\/t.co\/O2Y7LQSVuq",
  "id" : 352104530344808449,
  "created_at" : "2013-07-02 16:40:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Feld",
      "screen_name" : "bfeld",
      "indices" : [ 3, 9 ],
      "id_str" : "3754891",
      "id" : 3754891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/fEk5Ne2itM",
      "expanded_url" : "http:\/\/goo.gl\/fb\/qMRJH",
      "display_url" : "goo.gl\/fb\/qMRJH"
    } ]
  },
  "geo" : { },
  "id_str" : "352086724878401536",
  "text" : "RT @bfeld: Feld Thoughts:  Problem Solving Versus Empathy http:\/\/t.co\/fEk5Ne2itM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/fEk5Ne2itM",
        "expanded_url" : "http:\/\/goo.gl\/fb\/qMRJH",
        "display_url" : "goo.gl\/fb\/qMRJH"
      } ]
    },
    "geo" : { },
    "id_str" : "352084876377329664",
    "text" : "Feld Thoughts:  Problem Solving Versus Empathy http:\/\/t.co\/fEk5Ne2itM",
    "id" : 352084876377329664,
    "created_at" : "2013-07-02 15:22:30 +0000",
    "user" : {
      "name" : "Brad Feld",
      "screen_name" : "bfeld",
      "protected" : false,
      "id_str" : "3754891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441605100440547328\/vJhIbf6j_normal.png",
      "id" : 3754891,
      "verified" : true
    }
  },
  "id" : 352086724878401536,
  "created_at" : "2013-07-02 15:29:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352083026194337792",
  "text" : "A 5-minute guide to living a healthy life that you can forget in even less time.",
  "id" : 352083026194337792,
  "created_at" : "2013-07-02 15:15:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 3, 14 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Andrew Mason",
      "screen_name" : "andrewmason",
      "indices" : [ 27, 39 ],
      "id_str" : "898371",
      "id" : 898371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Phys5sAtYj",
      "expanded_url" : "http:\/\/smandrew.com\/blog\/2013\/7\/1\/hardly-workin-now-available-on-itunes",
      "display_url" : "smandrew.com\/blog\/2013\/7\/1\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "351940837757820929",
  "text" : "RT @waxpancake: Why I love @andrewmason: Hardly Workin\u2019, his promised post-Groupon album of motivational work songs, is real. http:\/\/t.co\/P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Mason",
        "screen_name" : "andrewmason",
        "indices" : [ 11, 23 ],
        "id_str" : "898371",
        "id" : 898371
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/Phys5sAtYj",
        "expanded_url" : "http:\/\/smandrew.com\/blog\/2013\/7\/1\/hardly-workin-now-available-on-itunes",
        "display_url" : "smandrew.com\/blog\/2013\/7\/1\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "351932998813360128",
    "text" : "Why I love @andrewmason: Hardly Workin\u2019, his promised post-Groupon album of motivational work songs, is real. http:\/\/t.co\/Phys5sAtYj",
    "id" : 351932998813360128,
    "created_at" : "2013-07-02 05:19:00 +0000",
    "user" : {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "protected" : false,
      "id_str" : "13461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416642320574844928\/Gz7V2B6r_normal.jpeg",
      "id" : 13461,
      "verified" : false
    }
  },
  "id" : 351940837757820929,
  "created_at" : "2013-07-02 05:50:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Florenzano",
      "screen_name" : "ericflo",
      "indices" : [ 3, 11 ],
      "id_str" : "14087951",
      "id" : 14087951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/jNhwEp8C2T",
      "expanded_url" : "http:\/\/eflorenzano.com\/blog\/2013\/07\/01\/fix-it\/",
      "display_url" : "eflorenzano.com\/blog\/2013\/07\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "351939360758841348",
  "text" : "RT @ericflo: Blogged for the first time since forever. \u201CSo fix it!\u201D http:\/\/t.co\/jNhwEp8C2T (Wow, blogging gets harder if you don\u2019t do it of\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/jNhwEp8C2T",
        "expanded_url" : "http:\/\/eflorenzano.com\/blog\/2013\/07\/01\/fix-it\/",
        "display_url" : "eflorenzano.com\/blog\/2013\/07\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "351933867919278081",
    "text" : "Blogged for the first time since forever. \u201CSo fix it!\u201D http:\/\/t.co\/jNhwEp8C2T (Wow, blogging gets harder if you don\u2019t do it often.)",
    "id" : 351933867919278081,
    "created_at" : "2013-07-02 05:22:27 +0000",
    "user" : {
      "name" : "Eric Florenzano",
      "screen_name" : "ericflo",
      "protected" : false,
      "id_str" : "14087951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2657553689\/da8d3d8b3a5ba262d5cb28b0fcc49313_normal.jpeg",
      "id" : 14087951,
      "verified" : false
    }
  },
  "id" : 351939360758841348,
  "created_at" : "2013-07-02 05:44:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Gordon",
      "screen_name" : "JeremySF",
      "indices" : [ 0, 9 ],
      "id_str" : "19872718",
      "id" : 19872718
    }, {
      "name" : "Jeff Seibert",
      "screen_name" : "jeffseibert",
      "indices" : [ 10, 22 ],
      "id_str" : "8798682",
      "id" : 8798682
    }, {
      "name" : "Jessica Verrilli",
      "screen_name" : "jess",
      "indices" : [ 23, 28 ],
      "id_str" : "6331462",
      "id" : 6331462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "seatbelts",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351907094389198848",
  "geo" : { },
  "id_str" : "351917588881743874",
  "in_reply_to_user_id" : 19872718,
  "text" : "@JeremySF @jeffseibert @jess They let that crazy kid named data drive. #seatbelts",
  "id" : 351917588881743874,
  "in_reply_to_status_id" : 351907094389198848,
  "created_at" : "2013-07-02 04:17:46 +0000",
  "in_reply_to_screen_name" : "JeremySF",
  "in_reply_to_user_id_str" : "19872718",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain Carle",
      "screen_name" : "froginthevalley",
      "indices" : [ 0, 16 ],
      "id_str" : "657693",
      "id" : 657693
    }, {
      "name" : "Ben Ward",
      "screen_name" : "benward",
      "indices" : [ 17, 25 ],
      "id_str" : "12249",
      "id" : 12249
    }, {
      "name" : "Eric Florenzano",
      "screen_name" : "ericflo",
      "indices" : [ 26, 34 ],
      "id_str" : "14087951",
      "id" : 14087951
    }, {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 35, 39 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351915195788046337",
  "geo" : { },
  "id_str" : "351916528666554370",
  "in_reply_to_user_id" : 657693,
  "text" : "@froginthevalley @benward @ericflo @cap Each platform markets itself (and the writing on it) to different people, so I write differently.",
  "id" : 351916528666554370,
  "in_reply_to_status_id" : 351915195788046337,
  "created_at" : "2013-07-02 04:13:33 +0000",
  "in_reply_to_screen_name" : "froginthevalley",
  "in_reply_to_user_id_str" : "657693",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/PDFp3AKhIQ",
      "expanded_url" : "http:\/\/flic.kr\/p\/f18KzL",
      "display_url" : "flic.kr\/p\/f18KzL"
    } ]
  },
  "geo" : { },
  "id_str" : "351914712465813504",
  "text" : "8:36pm \"Look what we found in the park. In the dark. We will take him home. We will call him Clark.\" http:\/\/t.co\/PDFp3AKhIQ",
  "id" : 351914712465813504,
  "created_at" : "2013-07-02 04:06:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "benward",
      "indices" : [ 0, 8 ],
      "id_str" : "12249",
      "id" : 12249
    }, {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 9, 13 ],
      "id_str" : "2182141",
      "id" : 2182141
    }, {
      "name" : "Eric Florenzano",
      "screen_name" : "ericflo",
      "indices" : [ 14, 22 ],
      "id_str" : "14087951",
      "id" : 14087951
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "usealltheblogs",
      "indices" : [ 51, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351907501849055232",
  "geo" : { },
  "id_str" : "351908384137682945",
  "in_reply_to_user_id" : 12249,
  "text" : "@benward @cap @ericflo I use both for some reason. #usealltheblogs",
  "id" : 351908384137682945,
  "in_reply_to_status_id" : 351907501849055232,
  "created_at" : "2013-07-02 03:41:11 +0000",
  "in_reply_to_screen_name" : "benward",
  "in_reply_to_user_id_str" : "12249",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351877340307001346",
  "geo" : { },
  "id_str" : "351879019362402304",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake Ouch.",
  "id" : 351879019362402304,
  "in_reply_to_status_id" : 351877340307001346,
  "created_at" : "2013-07-02 01:44:30 +0000",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 4, 14 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351867416424366081",
  "geo" : { },
  "id_str" : "351868140898095105",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm @kellianne My #hackweek project will be to out all the spouses of Twitter employees that have unfollowed them.",
  "id" : 351868140898095105,
  "in_reply_to_status_id" : 351867416424366081,
  "created_at" : "2013-07-02 01:01:16 +0000",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 11, 21 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351866934616264704",
  "text" : "Apparently @kellianne wasn't following me. I think she blocked me because I was posting too many baby photos.",
  "id" : 351866934616264704,
  "created_at" : "2013-07-02 00:56:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mat honan",
      "screen_name" : "mat",
      "indices" : [ 3, 7 ],
      "id_str" : "11113",
      "id" : 11113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351791130196713474",
  "text" : "RT @mat: BART announces you are going to need to walk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "351791016463958017",
    "text" : "BART announces you are going to need to walk",
    "id" : 351791016463958017,
    "created_at" : "2013-07-01 19:54:48 +0000",
    "user" : {
      "name" : "mat honan",
      "screen_name" : "mat",
      "protected" : false,
      "id_str" : "11113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432654572876619776\/oF1EKBOV_normal.jpeg",
      "id" : 11113,
      "verified" : true
    }
  },
  "id" : 351791130196713474,
  "created_at" : "2013-07-01 19:55:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nicolas krismer",
      "screen_name" : "krismer",
      "indices" : [ 0, 8 ],
      "id_str" : "1971883274",
      "id" : 1971883274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351758161503465474",
  "geo" : { },
  "id_str" : "351759051480236032",
  "in_reply_to_user_id" : 2664761,
  "text" : "@krismer This is a great time to be part of Twitter. There are tons of ways to learn on the job\u2026 classes all the time, etc.",
  "id" : 351759051480236032,
  "in_reply_to_status_id" : 351758161503465474,
  "created_at" : "2013-07-01 17:47:47 +0000",
  "in_reply_to_screen_name" : "krismerrill",
  "in_reply_to_user_id_str" : "2664761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nicolas krismer",
      "screen_name" : "krismer",
      "indices" : [ 0, 8 ],
      "id_str" : "1971883274",
      "id" : 1971883274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351757525193990144",
  "geo" : { },
  "id_str" : "351757729444012034",
  "in_reply_to_user_id" : 2664761,
  "text" : "@krismer Yes! Good luck on the interview!",
  "id" : 351757729444012034,
  "in_reply_to_status_id" : 351757525193990144,
  "created_at" : "2013-07-01 17:42:32 +0000",
  "in_reply_to_screen_name" : "krismerrill",
  "in_reply_to_user_id_str" : "2664761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Blome",
      "screen_name" : "Greg_Blome",
      "indices" : [ 0, 11 ],
      "id_str" : "38095093",
      "id" : 38095093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351755664076455939",
  "geo" : { },
  "id_str" : "351755753184444416",
  "in_reply_to_user_id" : 38095093,
  "text" : "@Greg_Blome Thanks!",
  "id" : 351755753184444416,
  "in_reply_to_status_id" : 351755664076455939,
  "created_at" : "2013-07-01 17:34:41 +0000",
  "in_reply_to_screen_name" : "Greg_Blome",
  "in_reply_to_user_id_str" : "38095093",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/nbbzPAvZeh",
      "expanded_url" : "https:\/\/medium.com\/better-humans\/20cc8d9c7494",
      "display_url" : "medium.com\/better-humans\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "351746104695595009",
  "text" : "\"The Death Bed Game: He\/she who dies with the most death bed points, wins.\" - Way of the Duck https:\/\/t.co\/nbbzPAvZeh",
  "id" : 351746104695595009,
  "created_at" : "2013-07-01 16:56:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351718991712100352",
  "text" : "Rabbit rabbit!",
  "id" : 351718991712100352,
  "created_at" : "2013-07-01 15:08:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]