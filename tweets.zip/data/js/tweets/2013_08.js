Grailbird.data.tweets_2013_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/3PZ4srUW05",
      "expanded_url" : "http:\/\/flic.kr\/p\/fG75sf",
      "display_url" : "flic.kr\/p\/fG75sf"
    } ]
  },
  "geo" : { },
  "id_str" : "374018989199859713",
  "text" : "8:36pm Rosie always gets really busy around bed time http:\/\/t.co\/3PZ4srUW05",
  "id" : 374018989199859713,
  "created_at" : "2013-09-01 04:00:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason W",
      "screen_name" : "J2XL",
      "indices" : [ 0, 5 ],
      "id_str" : "1593141",
      "id" : 1593141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374007621839122432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8342964361, -122.2919772473 ]
  },
  "id_str" : "374009318074359809",
  "in_reply_to_user_id" : 1593141,
  "text" : "@J2XL I think that's a better plan anyway.",
  "id" : 374009318074359809,
  "in_reply_to_status_id" : 374007621839122432,
  "created_at" : "2013-09-01 03:22:24 +0000",
  "in_reply_to_screen_name" : "J2XL",
  "in_reply_to_user_id_str" : "1593141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason W",
      "screen_name" : "J2XL",
      "indices" : [ 0, 5 ],
      "id_str" : "1593141",
      "id" : 1593141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373984200707153921",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8342964361, -122.2919772473 ]
  },
  "id_str" : "374007445783191552",
  "in_reply_to_user_id" : 1593141,
  "text" : "@J2XL Ha, true. Can't you clone just a single file in a repo? Either way it's probably better to start from scratch with your own repo.",
  "id" : 374007445783191552,
  "in_reply_to_status_id" : 373984200707153921,
  "created_at" : "2013-09-01 03:14:58 +0000",
  "in_reply_to_screen_name" : "J2XL",
  "in_reply_to_user_id_str" : "1593141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Gordon",
      "screen_name" : "JeremySF",
      "indices" : [ 38, 47 ],
      "id_str" : "19872718",
      "id" : 19872718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/9crHHp0e3Z",
      "expanded_url" : "http:\/\/busymockingbird.wordpress.com\/2013\/08\/27\/collaborating-with-a-4-year-old\/",
      "display_url" : "busymockingbird.wordpress.com\/2013\/08\/27\/col\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "373955305236746240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597855903, -122.275530881 ]
  },
  "id_str" : "373959602980655104",
  "in_reply_to_user_id" : 19872718,
  "text" : "I gotta start working on my faces. RT @JeremySF: So good. http:\/\/t.co\/9crHHp0e3Z",
  "id" : 373959602980655104,
  "in_reply_to_status_id" : 373955305236746240,
  "created_at" : "2013-09-01 00:04:51 +0000",
  "in_reply_to_screen_name" : "JeremySF",
  "in_reply_to_user_id_str" : "19872718",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iamyourguy",
      "screen_name" : "iamyourguy",
      "indices" : [ 3, 14 ],
      "id_str" : "323310903",
      "id" : 323310903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373900093377609728",
  "text" : "RT @iamyourguy: Not yet\nNot yet\nNot yet\nNot yet\nNot yet\nEAT ME NOW\nToo late \n\n- avocados",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "369616541509099520",
    "text" : "Not yet\nNot yet\nNot yet\nNot yet\nNot yet\nEAT ME NOW\nToo late \n\n- avocados",
    "id" : 369616541509099520,
    "created_at" : "2013-08-20 00:27:05 +0000",
    "user" : {
      "name" : "iamyourguy",
      "screen_name" : "iamyourguy",
      "protected" : false,
      "id_str" : "323310903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1727912295\/JustMe_normal.jpg",
      "id" : 323310903,
      "verified" : false
    }
  },
  "id" : 373900093377609728,
  "created_at" : "2013-08-31 20:08:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "3yearoldproblems",
      "indices" : [ 54, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/qzJTKoSSrx",
      "expanded_url" : "http:\/\/flic.kr\/p\/fF6GEB",
      "display_url" : "flic.kr\/p\/fF6GEB"
    } ]
  },
  "geo" : { },
  "id_str" : "373652807099764736",
  "text" : "8:36pm To brush your teeth or not to brush your teeth #3yearoldproblems http:\/\/t.co\/qzJTKoSSrx",
  "id" : 373652807099764736,
  "created_at" : "2013-08-31 03:45:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik D. Kennedy",
      "screen_name" : "erikdkennedy",
      "indices" : [ 3, 16 ],
      "id_str" : "15192767",
      "id" : 15192767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373519394330009600",
  "text" : "RT @erikdkennedy: The world makes a lot more sense when you always translate \"I'm just joking\" to \"I'm just telling it exactly how it is\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373519145520091136",
    "text" : "The world makes a lot more sense when you always translate \"I'm just joking\" to \"I'm just telling it exactly how it is\".",
    "id" : 373519145520091136,
    "created_at" : "2013-08-30 18:54:38 +0000",
    "user" : {
      "name" : "Erik D. Kennedy",
      "screen_name" : "erikdkennedy",
      "protected" : false,
      "id_str" : "15192767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438080658905120768\/lt3d0hN1_normal.png",
      "id" : 15192767,
      "verified" : false
    }
  },
  "id" : 373519394330009600,
  "created_at" : "2013-08-30 18:55:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Stamatiou",
      "screen_name" : "Stammy",
      "indices" : [ 0, 7 ],
      "id_str" : "624683",
      "id" : 624683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373517583137259520",
  "geo" : { },
  "id_str" : "373518245942145024",
  "in_reply_to_user_id" : 624683,
  "text" : "@Stammy I like being able to easy check all and delete after a quick scan of the other tabs.",
  "id" : 373518245942145024,
  "in_reply_to_status_id" : 373517583137259520,
  "created_at" : "2013-08-30 18:51:04 +0000",
  "in_reply_to_screen_name" : "Stammy",
  "in_reply_to_user_id_str" : "624683",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Stamatiou",
      "screen_name" : "Stammy",
      "indices" : [ 0, 7 ],
      "id_str" : "624683",
      "id" : 624683
    }, {
      "name" : "Dan Loewenherz \u26A1",
      "screen_name" : "dwlz",
      "indices" : [ 8, 13 ],
      "id_str" : "17824785",
      "id" : 17824785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373517077870436352",
  "geo" : { },
  "id_str" : "373517436617621504",
  "in_reply_to_user_id" : 624683,
  "text" : "@Stammy @dwlz But how often do you actually follow those instructions?",
  "id" : 373517436617621504,
  "in_reply_to_status_id" : 373517077870436352,
  "created_at" : "2013-08-30 18:47:51 +0000",
  "in_reply_to_screen_name" : "Stammy",
  "in_reply_to_user_id_str" : "624683",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bodge",
      "screen_name" : "mikebodge",
      "indices" : [ 0, 10 ],
      "id_str" : "19344531",
      "id" : 19344531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/v4jab0FmUE",
      "expanded_url" : "http:\/\/asana.com",
      "display_url" : "asana.com"
    } ]
  },
  "in_reply_to_status_id_str" : "373511280487067648",
  "geo" : { },
  "id_str" : "373512704167649280",
  "in_reply_to_user_id" : 19344531,
  "text" : "@mikebodge I use http:\/\/t.co\/v4jab0FmUE for those.",
  "id" : 373512704167649280,
  "in_reply_to_status_id" : 373511280487067648,
  "created_at" : "2013-08-30 18:29:02 +0000",
  "in_reply_to_screen_name" : "mikebodge",
  "in_reply_to_user_id_str" : "19344531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/8kuJzXCAFG",
      "expanded_url" : "https:\/\/www.google.com\/search?q=ferret",
      "display_url" : "google.com\/search?q=ferret"
    } ]
  },
  "in_reply_to_status_id_str" : "373511569474211841",
  "geo" : { },
  "id_str" : "373512498516721664",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver Looks like a ferret to me: https:\/\/t.co\/8kuJzXCAFG",
  "id" : 373512498516721664,
  "in_reply_to_status_id" : 373511569474211841,
  "created_at" : "2013-08-30 18:28:13 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "indices" : [ 3, 15 ],
      "id_str" : "289534689",
      "id" : 289534689
    }, {
      "name" : "Christina Wodtke",
      "screen_name" : "cwodtke",
      "indices" : [ 17, 25 ],
      "id_str" : "1763261",
      "id" : 1763261
    }, {
      "name" : "Raph Koster",
      "screen_name" : "raphkoster",
      "indices" : [ 26, 37 ],
      "id_str" : "20119483",
      "id" : 20119483
    }, {
      "name" : "Mattie Brice",
      "screen_name" : "xMattieBrice",
      "indices" : [ 38, 51 ],
      "id_str" : "276322412",
      "id" : 276322412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373504486032961536",
  "text" : "RT @seriouspony: @cwodtke @raphkoster @xMattieBrice most gamification is still operant conditioning. Gamifiers use Skinner, game devs use C\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christina Wodtke",
        "screen_name" : "cwodtke",
        "indices" : [ 0, 8 ],
        "id_str" : "1763261",
        "id" : 1763261
      }, {
        "name" : "Raph Koster",
        "screen_name" : "raphkoster",
        "indices" : [ 9, 20 ],
        "id_str" : "20119483",
        "id" : 20119483
      }, {
        "name" : "Mattie Brice",
        "screen_name" : "xMattieBrice",
        "indices" : [ 21, 34 ],
        "id_str" : "276322412",
        "id" : 276322412
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "373475834935259136",
    "geo" : { },
    "id_str" : "373477137174392833",
    "in_reply_to_user_id" : 289534689,
    "text" : "@cwodtke @raphkoster @xMattieBrice most gamification is still operant conditioning. Gamifiers use Skinner, game devs use Cs\u00EDkszentmih\u00E1lyi",
    "id" : 373477137174392833,
    "in_reply_to_status_id" : 373475834935259136,
    "created_at" : "2013-08-30 16:07:43 +0000",
    "in_reply_to_screen_name" : "seriouspony",
    "in_reply_to_user_id_str" : "289534689",
    "user" : {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "protected" : false,
      "id_str" : "289534689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000125491934\/4759dbdd7f9745522eeb9cdf5315efa2_normal.jpeg",
      "id" : 289534689,
      "verified" : false
    }
  },
  "id" : 373504486032961536,
  "created_at" : "2013-08-30 17:56:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logan Bowers",
      "screen_name" : "loganb",
      "indices" : [ 0, 7 ],
      "id_str" : "6072622",
      "id" : 6072622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373494031986081792",
  "geo" : { },
  "id_str" : "373494581561548800",
  "in_reply_to_user_id" : 6072622,
  "text" : "@loganb I think this applies more to the whole system than its parts. Parts can be fragile as long as the system doesn't break when they do.",
  "id" : 373494581561548800,
  "in_reply_to_status_id" : 373494031986081792,
  "created_at" : "2013-08-30 17:17:02 +0000",
  "in_reply_to_screen_name" : "loganb",
  "in_reply_to_user_id_str" : "6072622",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373493446276698114",
  "geo" : { },
  "id_str" : "373493651017457664",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk Me too. I think this is the primary reason why successful companies become easier to disrupt over time.",
  "id" : 373493651017457664,
  "in_reply_to_status_id" : 373493446276698114,
  "created_at" : "2013-08-30 17:13:20 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373493050258894848",
  "geo" : { },
  "id_str" : "373493302458212352",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk That's better than nothing, but it's still an attempt to remove randomness the rest of the time.",
  "id" : 373493302458212352,
  "in_reply_to_status_id" : 373493050258894848,
  "created_at" : "2013-08-30 17:11:57 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373492570313084928",
  "geo" : { },
  "id_str" : "373492852610703360",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk Totally. As products develop, teams often try to increase predictability. It's clear to me now that this is a terrible idea.",
  "id" : 373492852610703360,
  "in_reply_to_status_id" : 373492570313084928,
  "created_at" : "2013-08-30 17:10:09 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8282556823, -122.2676009379 ]
  },
  "id_str" : "373479865179074560",
  "text" : "Removing randomness, variability, unpredictability from a system (business, government, society) makes it more fragile and is a disservice.",
  "id" : 373479865179074560,
  "created_at" : "2013-08-30 16:18:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bianca L. St.Louis",
      "screen_name" : "beLaurie",
      "indices" : [ 0, 9 ],
      "id_str" : "92143477",
      "id" : 92143477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373301109307088896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596547526, -122.2756808159 ]
  },
  "id_str" : "373302916028694528",
  "in_reply_to_user_id" : 92143477,
  "text" : "@beLaurie Thanks!",
  "id" : 373302916028694528,
  "in_reply_to_status_id" : 373301109307088896,
  "created_at" : "2013-08-30 04:35:25 +0000",
  "in_reply_to_screen_name" : "beLaurie",
  "in_reply_to_user_id_str" : "92143477",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/373294250160451584\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/dxovhfCwif",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BS41JIPCYAIeUd8.jpg",
      "id_str" : "373294250063978498",
      "id" : 373294250063978498,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS41JIPCYAIeUd8.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/dxovhfCwif"
    } ],
    "hashtags" : [ {
      "text" : "ohyeah",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "mediumbrag",
      "indices" : [ 8, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597668505, -122.2754923863 ]
  },
  "id_str" : "373294250160451584",
  "text" : "#ohyeah #mediumbrag http:\/\/t.co\/dxovhfCwif",
  "id" : 373294250160451584,
  "created_at" : "2013-08-30 04:00:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 11, 21 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373290683651473410",
  "geo" : { },
  "id_str" : "373290937482371072",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april @kellianne Totally.",
  "id" : 373290937482371072,
  "in_reply_to_status_id" : 373290683651473410,
  "created_at" : "2013-08-30 03:47:49 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373289462098178048",
  "geo" : { },
  "id_str" : "373289723864682497",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane Whatcha doin' this weekend? And\/or other weekends? Come hang in the bathroom with us!",
  "id" : 373289723864682497,
  "in_reply_to_status_id" : 373289462098178048,
  "created_at" : "2013-08-30 03:43:00 +0000",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/gwXCd56hHk",
      "expanded_url" : "http:\/\/flic.kr\/p\/fEKt8C",
      "display_url" : "flic.kr\/p\/fEKt8C"
    } ]
  },
  "geo" : { },
  "id_str" : "373288904863920129",
  "text" : "8:36pm Niko make the biggest smile you've ever made http:\/\/t.co\/gwXCd56hHk",
  "id" : 373288904863920129,
  "created_at" : "2013-08-30 03:39:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Cheng",
      "screen_name" : "jackcheng",
      "indices" : [ 0, 10 ],
      "id_str" : "146703",
      "id" : 146703
    }, {
      "name" : "Bored Elon Musk",
      "screen_name" : "BoredElonMusk",
      "indices" : [ 11, 25 ],
      "id_str" : "1666038950",
      "id" : 1666038950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373263492947914752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8599167709, -122.275264403 ]
  },
  "id_str" : "373285411822391297",
  "in_reply_to_user_id" : 146703,
  "text" : "@jackcheng @BoredElonMusk Ha. Sadly not. More like @boredrandomexentrepreneur.",
  "id" : 373285411822391297,
  "in_reply_to_status_id" : 373263492947914752,
  "created_at" : "2013-08-30 03:25:52 +0000",
  "in_reply_to_screen_name" : "jackcheng",
  "in_reply_to_user_id_str" : "146703",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte",
      "screen_name" : "monstergirlee",
      "indices" : [ 0, 14 ],
      "id_str" : "23658986",
      "id" : 23658986
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/FtR27QabCe",
      "expanded_url" : "http:\/\/twitter.com",
      "display_url" : "twitter.com"
    } ]
  },
  "in_reply_to_status_id_str" : "373275131709116417",
  "geo" : { },
  "id_str" : "373279706264522753",
  "in_reply_to_user_id" : 23658986,
  "text" : "@monstergirlee I think that will most likely be fixed. Are you using http:\/\/t.co\/FtR27QabCe or the app?",
  "id" : 373279706264522753,
  "in_reply_to_status_id" : 373275131709116417,
  "created_at" : "2013-08-30 03:03:11 +0000",
  "in_reply_to_screen_name" : "monstergirlee",
  "in_reply_to_user_id_str" : "23658986",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/poEO1cmrIE",
      "expanded_url" : "https:\/\/vine.co\/v\/hiV3dOQ95Yi",
      "display_url" : "vine.co\/v\/hiV3dOQ95Yi"
    } ]
  },
  "geo" : { },
  "id_str" : "373271285104926720",
  "text" : "Niko: \"I will give you the biggest kiss ever!\" https:\/\/t.co\/poEO1cmrIE",
  "id" : 373271285104926720,
  "created_at" : "2013-08-30 02:29:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8568322995, -122.2726627116 ]
  },
  "id_str" : "373262146764668928",
  "text" : "A walking app uses proximity sensors and sends you push notifications when you're about to walk into something. Because you're app-walking.",
  "id" : 373262146764668928,
  "created_at" : "2013-08-30 01:53:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373260848199770112",
  "geo" : { },
  "id_str" : "373261407157891072",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame I actually imagined it falling so hard that it smashed Bart too. Could happen right? :0",
  "id" : 373261407157891072,
  "in_reply_to_status_id" : 373260848199770112,
  "created_at" : "2013-08-30 01:50:28 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Rheingold",
      "screen_name" : "tedr",
      "indices" : [ 0, 5 ],
      "id_str" : "997",
      "id" : 997
    }, {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 6, 17 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373254977944170496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8542731503, -122.2712219049 ]
  },
  "id_str" : "373260658202013697",
  "in_reply_to_user_id" : 997,
  "text" : "@tedr @waxpancake I bet you they launch with Gap's new logo that they didn't end up using.",
  "id" : 373260658202013697,
  "in_reply_to_status_id" : 373254977944170496,
  "created_at" : "2013-08-30 01:47:30 +0000",
  "in_reply_to_screen_name" : "tedr",
  "in_reply_to_user_id_str" : "997",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    }, {
      "name" : "Suyash Sonwalkar",
      "screen_name" : "suyash",
      "indices" : [ 5, 12 ],
      "id_str" : "18040828",
      "id" : 18040828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373233610402189312",
  "geo" : { },
  "id_str" : "373246754117783553",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm @suyash I'd like to see more sources confirming\/denying this story, but yeah, it doesn't sound good at all.",
  "id" : 373246754117783553,
  "in_reply_to_status_id" : 373233610402189312,
  "created_at" : "2013-08-30 00:52:15 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/of0CN0sApp",
      "expanded_url" : "http:\/\/bit.ly\/1dv8o3T",
      "display_url" : "bit.ly\/1dv8o3T"
    } ]
  },
  "geo" : { },
  "id_str" : "373232373426823168",
  "text" : "\"All the evidence that Caltrans has indicates this new bridge will collapse when the Hayward Fault\u00A0ruptures.\" http:\/\/t.co\/of0CN0sApp",
  "id" : 373232373426823168,
  "created_at" : "2013-08-29 23:55:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373190656241332224",
  "geo" : { },
  "id_str" : "373191070143631360",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Ha. I can help you here. Email me at buster@twitter.com with a request and I'll set it up.",
  "id" : 373191070143631360,
  "in_reply_to_status_id" : 373190656241332224,
  "created_at" : "2013-08-29 21:10:59 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greatminds",
      "indices" : [ 75, 86 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373189864381886464",
  "geo" : { },
  "id_str" : "373190529787244544",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel If I didn't know better I'd say I basically stole your post. #greatminds",
  "id" : 373190529787244544,
  "in_reply_to_status_id" : 373189864381886464,
  "created_at" : "2013-08-29 21:08:50 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373182258296803328",
  "geo" : { },
  "id_str" : "373188921342951424",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Thanks! So much rage on the internets...",
  "id" : 373188921342951424,
  "in_reply_to_status_id" : 373182258296803328,
  "created_at" : "2013-08-29 21:02:27 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373182080035069952",
  "geo" : { },
  "id_str" : "373182182505734144",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert I know I know\u2026 :) Great work.",
  "id" : 373182182505734144,
  "in_reply_to_status_id" : 373182080035069952,
  "created_at" : "2013-08-29 20:35:40 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Davidson",
      "screen_name" : "tdavidson",
      "indices" : [ 0, 10 ],
      "id_str" : "8466962",
      "id" : 8466962
    }, {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 11, 18 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373181910702632960",
  "geo" : { },
  "id_str" : "373182053388275712",
  "in_reply_to_user_id" : 8466962,
  "text" : "@tdavidson @ftrain Me too. It is so dead on.",
  "id" : 373182053388275712,
  "in_reply_to_status_id" : 373181910702632960,
  "created_at" : "2013-08-29 20:35:09 +0000",
  "in_reply_to_screen_name" : "tdavidson",
  "in_reply_to_user_id_str" : "8466962",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373181329690853376",
  "geo" : { },
  "id_str" : "373181572955922432",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert SUPER excited about this. Wish it was coming to iPhone sooner!",
  "id" : 373181572955922432,
  "in_reply_to_status_id" : 373181329690853376,
  "created_at" : "2013-08-29 20:33:15 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 101, 108 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/MS8X0TqCYH",
      "expanded_url" : "http:\/\/bit.ly\/15nHS2b",
      "display_url" : "bit.ly\/15nHS2b"
    } ]
  },
  "geo" : { },
  "id_str" : "373180046380261376",
  "text" : "Friendly reminder about how the internet works: \"Why Wasn't I Consulted?\" http:\/\/t.co\/MS8X0TqCYH (an @ftrain classic)",
  "id" : 373180046380261376,
  "created_at" : "2013-08-29 20:27:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "NosajJake",
      "indices" : [ 0, 10 ],
      "id_str" : "421368926",
      "id" : 421368926
    }, {
      "name" : "Faisal Misle",
      "screen_name" : "fmisle",
      "indices" : [ 11, 18 ],
      "id_str" : "28609326",
      "id" : 28609326
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 63, 71 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373168691690897408",
  "geo" : { },
  "id_str" : "373168824985460736",
  "in_reply_to_user_id" : 421368926,
  "text" : "@NosajJake @fmisle I can't fix that but a quick note to support@twitter.com should resolve it.",
  "id" : 373168824985460736,
  "in_reply_to_status_id" : 373168691690897408,
  "created_at" : "2013-08-29 19:42:35 +0000",
  "in_reply_to_screen_name" : "NosajJake",
  "in_reply_to_user_id_str" : "421368926",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "NosajJake",
      "indices" : [ 0, 10 ],
      "id_str" : "421368926",
      "id" : 421368926
    }, {
      "name" : "Faisal Misle",
      "screen_name" : "fmisle",
      "indices" : [ 11, 18 ],
      "id_str" : "28609326",
      "id" : 28609326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373168137447149569",
  "geo" : { },
  "id_str" : "373168325871669248",
  "in_reply_to_user_id" : 421368926,
  "text" : "@NosajJake @fmisle Maybe! What's the problem?",
  "id" : 373168325871669248,
  "in_reply_to_status_id" : 373168137447149569,
  "created_at" : "2013-08-29 19:40:36 +0000",
  "in_reply_to_screen_name" : "NosajJake",
  "in_reply_to_user_id_str" : "421368926",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Plans",
      "screen_name" : "davidplans",
      "indices" : [ 0, 11 ],
      "id_str" : "18679482",
      "id" : 18679482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373163300067872768",
  "geo" : { },
  "id_str" : "373164983783141376",
  "in_reply_to_user_id" : 18679482,
  "text" : "@davidplans Thanks, David.",
  "id" : 373164983783141376,
  "in_reply_to_status_id" : 373163300067872768,
  "created_at" : "2013-08-29 19:27:19 +0000",
  "in_reply_to_screen_name" : "davidplans",
  "in_reply_to_user_id_str" : "18679482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Amber Costley",
      "screen_name" : "amberdawn",
      "indices" : [ 10, 20 ],
      "id_str" : "6634652",
      "id" : 6634652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373148540136353792",
  "geo" : { },
  "id_str" : "373148812765696000",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @amberdawn Do it! I'm super curious to see how it plays out.",
  "id" : 373148812765696000,
  "in_reply_to_status_id" : 373148540136353792,
  "created_at" : "2013-08-29 18:23:04 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Amber Costley",
      "screen_name" : "amberdawn",
      "indices" : [ 10, 20 ],
      "id_str" : "6634652",
      "id" : 6634652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373146663827046400",
  "geo" : { },
  "id_str" : "373146946011025408",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @amberdawn That would be cray.",
  "id" : 373146946011025408,
  "in_reply_to_status_id" : 373146663827046400,
  "created_at" : "2013-08-29 18:15:39 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Costley",
      "screen_name" : "amberdawn",
      "indices" : [ 0, 10 ],
      "id_str" : "6634652",
      "id" : 6634652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373145617872084993",
  "geo" : { },
  "id_str" : "373145930330959873",
  "in_reply_to_user_id" : 6634652,
  "text" : "@amberdawn Thanks! It's one of my most useful things\u2026 but difficult to articulate the value without actually doing it. Try it!",
  "id" : 373145930330959873,
  "in_reply_to_status_id" : 373145617872084993,
  "created_at" : "2013-08-29 18:11:37 +0000",
  "in_reply_to_screen_name" : "amberdawn",
  "in_reply_to_user_id_str" : "6634652",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Payne",
      "screen_name" : "al3x",
      "indices" : [ 0, 5 ],
      "id_str" : "18713",
      "id" : 18713
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 6, 15 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373142176990896129",
  "geo" : { },
  "id_str" : "373143830771400704",
  "in_reply_to_user_id" : 18713,
  "text" : "@al3x @anildash Just don't look at any cute animals cause that crash is gonna be a doozy.",
  "id" : 373143830771400704,
  "in_reply_to_status_id" : 373142176990896129,
  "created_at" : "2013-08-29 18:03:16 +0000",
  "in_reply_to_screen_name" : "al3x",
  "in_reply_to_user_id_str" : "18713",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Maureen",
      "screen_name" : "DocMaureen",
      "indices" : [ 0, 11 ],
      "id_str" : "59111239",
      "id" : 59111239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373141205565313024",
  "geo" : { },
  "id_str" : "373141372703752192",
  "in_reply_to_user_id" : 59111239,
  "text" : "@DocMaureen I'm just listening. I didn't work on it but am interested in hearing how people are reacting.",
  "id" : 373141372703752192,
  "in_reply_to_status_id" : 373141205565313024,
  "created_at" : "2013-08-29 17:53:30 +0000",
  "in_reply_to_screen_name" : "DocMaureen",
  "in_reply_to_user_id_str" : "59111239",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline wolven",
      "screen_name" : "jackiewolven",
      "indices" : [ 0, 13 ],
      "id_str" : "7413172",
      "id" : 7413172
    }, {
      "name" : "HSofia",
      "screen_name" : "hsofia",
      "indices" : [ 14, 21 ],
      "id_str" : "14372614",
      "id" : 14372614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373113943322923011",
  "geo" : { },
  "id_str" : "373115011427618817",
  "in_reply_to_user_id" : 7413172,
  "text" : "@jackiewolven @hsofia Give it a couple days to see how things work after getting a bit used to them. Then check back in.",
  "id" : 373115011427618817,
  "in_reply_to_status_id" : 373113943322923011,
  "created_at" : "2013-08-29 16:08:45 +0000",
  "in_reply_to_screen_name" : "jackiewolven",
  "in_reply_to_user_id_str" : "7413172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline wolven",
      "screen_name" : "jackiewolven",
      "indices" : [ 0, 13 ],
      "id_str" : "7413172",
      "id" : 7413172
    }, {
      "name" : "HSofia",
      "screen_name" : "hsofia",
      "indices" : [ 14, 21 ],
      "id_str" : "14372614",
      "id" : 14372614
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 22, 30 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373107492785360897",
  "geo" : { },
  "id_str" : "373113683720691712",
  "in_reply_to_user_id" : 7413172,
  "text" : "@jackiewolven @hsofia @twitter Yeah we're definitely all listening. What's up?",
  "id" : 373113683720691712,
  "in_reply_to_status_id" : 373107492785360897,
  "created_at" : "2013-08-29 16:03:28 +0000",
  "in_reply_to_screen_name" : "jackiewolven",
  "in_reply_to_user_id_str" : "7413172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 131, 138 ],
      "id_str" : "23640904",
      "id" : 23640904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/VJp6dKWjZs",
      "expanded_url" : "http:\/\/bit.ly\/1dS5rYI",
      "display_url" : "bit.ly\/1dS5rYI"
    } ]
  },
  "geo" : { },
  "id_str" : "373110569236443136",
  "text" : "On recognizing and fighting bias: \"But the bottom line is this: we\u2014as a society\u2014don't see each other.\" http:\/\/t.co\/VJp6dKWjZs \/via @emoore",
  "id" : 373110569236443136,
  "created_at" : "2013-08-29 15:51:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martha Rotter",
      "screen_name" : "martharotter",
      "indices" : [ 0, 13 ],
      "id_str" : "9448512",
      "id" : 9448512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373104222809505794",
  "geo" : { },
  "id_str" : "373105729139257346",
  "in_reply_to_user_id" : 9448512,
  "text" : "@martharotter Thanks, Martha!",
  "id" : 373105729139257346,
  "in_reply_to_status_id" : 373104222809505794,
  "created_at" : "2013-08-29 15:31:52 +0000",
  "in_reply_to_screen_name" : "martharotter",
  "in_reply_to_user_id_str" : "9448512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Guillebeau",
      "screen_name" : "chrisguillebeau",
      "indices" : [ 0, 16 ],
      "id_str" : "10373972",
      "id" : 10373972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/ZmSs7rD9Go",
      "expanded_url" : "https:\/\/medium.com\/better-humans\/c02337782a89",
      "display_url" : "medium.com\/better-humans\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "373100598754672641",
  "geo" : { },
  "id_str" : "373105165508694016",
  "in_reply_to_user_id" : 10373972,
  "text" : "@chrisguillebeau I'd be curious on your take on this: https:\/\/t.co\/ZmSs7rD9Go (big and small goals can both be fragile)",
  "id" : 373105165508694016,
  "in_reply_to_status_id" : 373100598754672641,
  "created_at" : "2013-08-29 15:29:38 +0000",
  "in_reply_to_screen_name" : "chrisguillebeau",
  "in_reply_to_user_id_str" : "10373972",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/Vrt60MMUfR",
      "expanded_url" : "https:\/\/medium.com\/lessons-learned\/1b16c7a2c0e7",
      "display_url" : "medium.com\/lessons-learne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373103800984141824",
  "text" : "Thoughts on getting mad on the internet: https:\/\/t.co\/Vrt60MMUfR",
  "id" : 373103800984141824,
  "created_at" : "2013-08-29 15:24:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenn Van Grove",
      "screen_name" : "jbruin",
      "indices" : [ 3, 10 ],
      "id_str" : "6193182",
      "id" : 6193182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/knWvhdpVNt",
      "expanded_url" : "http:\/\/news.cnet.com\/8301-1023_3-57600542-93\/heading-someplace-new-foursquare-wants-to-give-you-the-lowdown\/",
      "display_url" : "news.cnet.com\/8301-1023_3-57\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373101991448158208",
  "text" : "RT @jbruin: With passive location, Foursquare looks to add magic to everyday moments http:\/\/t.co\/knWvhdpVNt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/knWvhdpVNt",
        "expanded_url" : "http:\/\/news.cnet.com\/8301-1023_3-57600542-93\/heading-someplace-new-foursquare-wants-to-give-you-the-lowdown\/",
        "display_url" : "news.cnet.com\/8301-1023_3-57\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "373098325097979905",
    "text" : "With passive location, Foursquare looks to add magic to everyday moments http:\/\/t.co\/knWvhdpVNt",
    "id" : 373098325097979905,
    "created_at" : "2013-08-29 15:02:27 +0000",
    "user" : {
      "name" : "Jenn Van Grove",
      "screen_name" : "jbruin",
      "protected" : false,
      "id_str" : "6193182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443626110656344065\/D87I0ELg_normal.jpeg",
      "id" : 6193182,
      "verified" : true
    }
  },
  "id" : 373101991448158208,
  "created_at" : "2013-08-29 15:17:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robi Ganguly",
      "screen_name" : "rganguly",
      "indices" : [ 0, 9 ],
      "id_str" : "622663",
      "id" : 622663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373090298085531648",
  "geo" : { },
  "id_str" : "373093860382998528",
  "in_reply_to_user_id" : 622663,
  "text" : "@rganguly Thanks, Robi!",
  "id" : 373093860382998528,
  "in_reply_to_status_id" : 373090298085531648,
  "created_at" : "2013-08-29 14:44:42 +0000",
  "in_reply_to_screen_name" : "rganguly",
  "in_reply_to_user_id_str" : "622663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/Vrt60MMUfR",
      "expanded_url" : "https:\/\/medium.com\/lessons-learned\/1b16c7a2c0e7",
      "display_url" : "medium.com\/lessons-learne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372986446837067776",
  "text" : "I just published \u201CManaging My Internet Rage\u201D https:\/\/t.co\/Vrt60MMUfR",
  "id" : 372986446837067776,
  "created_at" : "2013-08-29 07:37:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372976660762468352",
  "geo" : { },
  "id_str" : "372977488042795008",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey I've hugged him. Great hugger.",
  "id" : 372977488042795008,
  "in_reply_to_status_id" : 372976660762468352,
  "created_at" : "2013-08-29 07:02:17 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 0, 7 ],
      "id_str" : "23640904",
      "id" : 23640904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372967511181901824",
  "geo" : { },
  "id_str" : "372969737812066304",
  "in_reply_to_user_id" : 23640904,
  "text" : "@emoore Such a great post. Thanks.",
  "id" : 372969737812066304,
  "in_reply_to_status_id" : 372967511181901824,
  "created_at" : "2013-08-29 06:31:29 +0000",
  "in_reply_to_screen_name" : "emoore",
  "in_reply_to_user_id_str" : "23640904",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sand Farnia",
      "screen_name" : "sandfarnia",
      "indices" : [ 74, 85 ],
      "id_str" : "20836022",
      "id" : 20836022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/xpgAGocLyQ",
      "expanded_url" : "https:\/\/medium.com\/better-humans\/e8982968f5a0",
      "display_url" : "medium.com\/better-humans\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372961560844460032",
  "text" : "Counterpoint to today. \u201CLife is fragile, and death is swift and coming.\u201D \u2014@sandfarnia https:\/\/t.co\/xpgAGocLyQ",
  "id" : 372961560844460032,
  "created_at" : "2013-08-29 05:59:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Giese",
      "screen_name" : "greeblemonkey",
      "indices" : [ 0, 14 ],
      "id_str" : "2337300114",
      "id" : 2337300114
    }, {
      "name" : "Mila Jacob Stetser",
      "screen_name" : "jstetser",
      "indices" : [ 15, 24 ],
      "id_str" : "696373",
      "id" : 696373
    }, {
      "name" : "Charlotte",
      "screen_name" : "monstergirlee",
      "indices" : [ 25, 39 ],
      "id_str" : "23658986",
      "id" : 23658986
    }, {
      "name" : "Denise DellaRocco",
      "screen_name" : "eatplaylove",
      "indices" : [ 40, 52 ],
      "id_str" : "17862307",
      "id" : 17862307
    }, {
      "name" : "Leah, agirlandaboy",
      "screen_name" : "agirlandaboy",
      "indices" : [ 53, 66 ],
      "id_str" : "80895925",
      "id" : 80895925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372938694342111232",
  "geo" : { },
  "id_str" : "372946680280129536",
  "in_reply_to_user_id" : 6752232,
  "text" : "@Greeblemonkey @jstetser @monstergirlee @eatplaylove @agirlandaboy All good feedback--thanks for sharing! I'll check back in a couple days.",
  "id" : 372946680280129536,
  "in_reply_to_status_id" : 372938694342111232,
  "created_at" : "2013-08-29 04:59:52 +0000",
  "in_reply_to_screen_name" : "Greeblehaus",
  "in_reply_to_user_id_str" : "6752232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/KfDw9QVZB8",
      "expanded_url" : "http:\/\/flic.kr\/p\/fE8rtu",
      "display_url" : "flic.kr\/p\/fE8rtu"
    } ]
  },
  "geo" : { },
  "id_str" : "372927743035326464",
  "text" : "8:36pm Mildly sick during the day, more lamely sick at night. Day 7. http:\/\/t.co\/KfDw9QVZB8",
  "id" : 372927743035326464,
  "created_at" : "2013-08-29 03:44:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 0, 8 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372910163977465857",
  "geo" : { },
  "id_str" : "372912106753888256",
  "in_reply_to_user_id" : 958581,
  "text" : "@rdicker The stuff of stars.",
  "id" : 372912106753888256,
  "in_reply_to_status_id" : 372910163977465857,
  "created_at" : "2013-08-29 02:42:29 +0000",
  "in_reply_to_screen_name" : "rdicker",
  "in_reply_to_user_id_str" : "958581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 0, 8 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372909364375330818",
  "geo" : { },
  "id_str" : "372909908225576961",
  "in_reply_to_user_id" : 958581,
  "text" : "@rdicker Who *am* I???",
  "id" : 372909908225576961,
  "in_reply_to_status_id" : 372909364375330818,
  "created_at" : "2013-08-29 02:33:45 +0000",
  "in_reply_to_screen_name" : "rdicker",
  "in_reply_to_user_id_str" : "958581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 0, 8 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372908165550993409",
  "geo" : { },
  "id_str" : "372908641419931648",
  "in_reply_to_user_id" : 958581,
  "text" : "@rdicker I am actually just scared and use anger as a defense mechanism.",
  "id" : 372908641419931648,
  "in_reply_to_status_id" : 372908165550993409,
  "created_at" : "2013-08-29 02:28:43 +0000",
  "in_reply_to_screen_name" : "rdicker",
  "in_reply_to_user_id_str" : "958581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372906170412838913",
  "geo" : { },
  "id_str" : "372907007809835008",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Orange? Get angry cause yours is the wrong color! \uD83D\uDE21",
  "id" : 372907007809835008,
  "in_reply_to_status_id" : 372906170412838913,
  "created_at" : "2013-08-29 02:22:13 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattermark",
      "screen_name" : "Mattermark",
      "indices" : [ 0, 11 ],
      "id_str" : "1434164370",
      "id" : 1434164370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodeye",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372903166267752448",
  "geo" : { },
  "id_str" : "372903857065435136",
  "in_reply_to_user_id" : 1434164370,
  "text" : "@Mattermark A magic new way of stringing tweets. #goodeye",
  "id" : 372903857065435136,
  "in_reply_to_status_id" : 372903166267752448,
  "created_at" : "2013-08-29 02:09:42 +0000",
  "in_reply_to_screen_name" : "Mattermark",
  "in_reply_to_user_id_str" : "1434164370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miley Ray Cyrus",
      "screen_name" : "MileyCyrus",
      "indices" : [ 22, 33 ],
      "id_str" : "268414482",
      "id" : 268414482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toosoon",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372901520288669696",
  "geo" : { },
  "id_str" : "372903532120526848",
  "in_reply_to_user_id" : 2185,
  "text" : "I'm still angry about @MileyCyrus. #toosoon?",
  "id" : 372903532120526848,
  "in_reply_to_status_id" : 372901520288669696,
  "created_at" : "2013-08-29 02:08:24 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim O'Neil",
      "screen_name" : "tim_oneil",
      "indices" : [ 0, 10 ],
      "id_str" : "19502698",
      "id" : 19502698
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 11, 17 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372901197163667456",
  "geo" : { },
  "id_str" : "372901791408484354",
  "in_reply_to_user_id" : 19502698,
  "text" : "@tim_oneil @couch Yeah but they changed that back, so if it's of the same magnitude I'm sure they'll do the same.",
  "id" : 372901791408484354,
  "in_reply_to_status_id" : 372901197163667456,
  "created_at" : "2013-08-29 02:01:29 +0000",
  "in_reply_to_screen_name" : "tim_oneil",
  "in_reply_to_user_id_str" : "19502698",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372894078620663808",
  "geo" : { },
  "id_str" : "372901520288669696",
  "in_reply_to_user_id" : 2185,
  "text" : "I'm still angry about the ending of Lost.",
  "id" : 372901520288669696,
  "in_reply_to_status_id" : 372894078620663808,
  "created_at" : "2013-08-29 02:00:25 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaby Pe\u00F1a",
      "screen_name" : "gpena",
      "indices" : [ 0, 6 ],
      "id_str" : "133583134",
      "id" : 133583134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372891860265467904",
  "geo" : { },
  "id_str" : "372896452407615489",
  "in_reply_to_user_id" : 133583134,
  "text" : "@gpena \uD83D\uDE16 &gt; \uD83D\uDE34 &gt; \uD83D\uDE0E",
  "id" : 372896452407615489,
  "in_reply_to_status_id" : 372891860265467904,
  "created_at" : "2013-08-29 01:40:16 +0000",
  "in_reply_to_screen_name" : "gpena",
  "in_reply_to_user_id_str" : "133583134",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte",
      "screen_name" : "monstergirlee",
      "indices" : [ 0, 14 ],
      "id_str" : "23658986",
      "id" : 23658986
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372866776217825280",
  "geo" : { },
  "id_str" : "372894892403335168",
  "in_reply_to_user_id" : 23658986,
  "text" : "@monstergirlee Give it a few days and let me know if you still hate it. Twitter definitely is listening and has reverted changes before.",
  "id" : 372894892403335168,
  "in_reply_to_status_id" : 372866776217825280,
  "created_at" : "2013-08-29 01:34:05 +0000",
  "in_reply_to_screen_name" : "monstergirlee",
  "in_reply_to_user_id_str" : "23658986",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doing My Best",
      "screen_name" : "am_doingmybest",
      "indices" : [ 0, 15 ],
      "id_str" : "292386130",
      "id" : 292386130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372868482221613058",
  "geo" : { },
  "id_str" : "372894819074322433",
  "in_reply_to_user_id" : 292386130,
  "text" : "@am_doingmybest Give it a few days and let me know if you still hate it. Twitter definitely is listening and has reverted changes before.",
  "id" : 372894819074322433,
  "in_reply_to_status_id" : 372868482221613058,
  "created_at" : "2013-08-29 01:33:47 +0000",
  "in_reply_to_screen_name" : "am_doingmybest",
  "in_reply_to_user_id_str" : "292386130",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372894078620663808",
  "text" : "I'm still angry about retweets and filtered replies. And Facebook's new profile pages. And how video killed the radio star.",
  "id" : 372894078620663808,
  "created_at" : "2013-08-29 01:30:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/TAcn0lOEoK",
      "expanded_url" : "http:\/\/appannie.com",
      "display_url" : "appannie.com"
    } ]
  },
  "in_reply_to_status_id_str" : "372875753899061249",
  "geo" : { },
  "id_str" : "372876149962964992",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward http:\/\/t.co\/TAcn0lOEoK is pretty great for tracking App Store ratings and estimating downloads from there.",
  "id" : 372876149962964992,
  "in_reply_to_status_id" : 372875753899061249,
  "created_at" : "2013-08-29 00:19:36 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farhad Manjoo",
      "screen_name" : "fmanjoo",
      "indices" : [ 0, 8 ],
      "id_str" : "2195241",
      "id" : 2195241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372824245442600960",
  "geo" : { },
  "id_str" : "372824869182144512",
  "in_reply_to_user_id" : 2195241,
  "text" : "@fmanjoo Tip: when replying to yourself you can leave off your own username too... it looks better.",
  "id" : 372824869182144512,
  "in_reply_to_status_id" : 372824245442600960,
  "created_at" : "2013-08-28 20:55:50 +0000",
  "in_reply_to_screen_name" : "fmanjoo",
  "in_reply_to_user_id_str" : "2195241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny McCarthy",
      "screen_name" : "JennyMcCarthy",
      "indices" : [ 70, 84 ],
      "id_str" : "37344334",
      "id" : 37344334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/Ts36xST33L",
      "expanded_url" : "http:\/\/www.usatoday.com\/story\/news\/nation\/2013\/08\/23\/texas-measles-outbreak\/2693945\/",
      "display_url" : "usatoday.com\/story\/news\/nat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372824143013490688",
  "text" : "\"Texas measles outbreak linked to church\" http:\/\/t.co\/Ts36xST33L \/thx @JennyMcCarthy and religion",
  "id" : 372824143013490688,
  "created_at" : "2013-08-28 20:52:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harper",
      "screen_name" : "harper",
      "indices" : [ 0, 7 ],
      "id_str" : "1497",
      "id" : 1497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/g3IkMwk6sf",
      "expanded_url" : "https:\/\/github.com\/btroia\/basis-data-export",
      "display_url" : "github.com\/btroia\/basis-d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "372807741082841088",
  "geo" : { },
  "id_str" : "372808144885256193",
  "in_reply_to_user_id" : 1497,
  "text" : "@harper Pssst: https:\/\/t.co\/g3IkMwk6sf",
  "id" : 372808144885256193,
  "in_reply_to_status_id" : 372807741082841088,
  "created_at" : "2013-08-28 19:49:22 +0000",
  "in_reply_to_screen_name" : "harper",
  "in_reply_to_user_id_str" : "1497",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/isaach\/status\/372755806313541632\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/N4UF8meWfV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSxLbkRIEAA0lWY.png",
      "id_str" : "372755806128967680",
      "id" : 372755806128967680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSxLbkRIEAA0lWY.png",
      "sizes" : [ {
        "h" : 568,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 568
      } ],
      "display_url" : "pic.twitter.com\/N4UF8meWfV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372804357797867520",
  "text" : "RT @isaach: a sample of san francisco monthly rents. this is ridiculous http:\/\/t.co\/N4UF8meWfV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/isaach\/status\/372755806313541632\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/N4UF8meWfV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSxLbkRIEAA0lWY.png",
        "id_str" : "372755806128967680",
        "id" : 372755806128967680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSxLbkRIEAA0lWY.png",
        "sizes" : [ {
          "h" : 568,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 568
        } ],
        "display_url" : "pic.twitter.com\/N4UF8meWfV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372755806313541632",
    "text" : "a sample of san francisco monthly rents. this is ridiculous http:\/\/t.co\/N4UF8meWfV",
    "id" : 372755806313541632,
    "created_at" : "2013-08-28 16:21:24 +0000",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430605387117494272\/lmplHwca_normal.png",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 372804357797867520,
  "created_at" : "2013-08-28 19:34:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah, agirlandaboy",
      "screen_name" : "agirlandaboy",
      "indices" : [ 0, 13 ],
      "id_str" : "80895925",
      "id" : 80895925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372799311915913216",
  "geo" : { },
  "id_str" : "372799689482985473",
  "in_reply_to_user_id" : 80895925,
  "text" : "@agirlandaboy Cool, keep sending feedback. I'm pretty sure it shouldn't show duplicates but there are many edge cases to consider.",
  "id" : 372799689482985473,
  "in_reply_to_status_id" : 372799311915913216,
  "created_at" : "2013-08-28 19:15:46 +0000",
  "in_reply_to_screen_name" : "agirlandaboy",
  "in_reply_to_user_id_str" : "80895925",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah, agirlandaboy",
      "screen_name" : "agirlandaboy",
      "indices" : [ 0, 13 ],
      "id_str" : "80895925",
      "id" : 80895925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372797839270612992",
  "geo" : { },
  "id_str" : "372798594362785793",
  "in_reply_to_user_id" : 80895925,
  "text" : "@agirlandaboy What do they hate?",
  "id" : 372798594362785793,
  "in_reply_to_status_id" : 372797839270612992,
  "created_at" : "2013-08-28 19:11:25 +0000",
  "in_reply_to_screen_name" : "agirlandaboy",
  "in_reply_to_user_id_str" : "80895925",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/DMpmacE9dg",
      "expanded_url" : "https:\/\/blog.twitter.com\/2013\/keep-up-with-conversations-on-twitter",
      "display_url" : "blog.twitter.com\/2013\/keep-up-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372797349946335232",
  "text" : "I'm super curious to hear what people think of the new way conversations are grouped in Twitter. Update! https:\/\/t.co\/DMpmacE9dg",
  "id" : 372797349946335232,
  "created_at" : "2013-08-28 19:06:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372775181657178112",
  "geo" : { },
  "id_str" : "372796320953561088",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Yeah, I just checked my tweet ratings and almost nobody said I tweet too much about Twitter... maybe the problem's in my head.",
  "id" : 372796320953561088,
  "in_reply_to_status_id" : 372775181657178112,
  "created_at" : "2013-08-28 19:02:23 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Morrill",
      "screen_name" : "DanielleMorrill",
      "indices" : [ 0, 16 ],
      "id_str" : "7017692",
      "id" : 7017692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372791541837725696",
  "geo" : { },
  "id_str" : "372794644813197313",
  "in_reply_to_user_id" : 7017692,
  "text" : "@DanielleMorrill I totally agree. The last iPhone release re-added simple list functionality but still lots missing.",
  "id" : 372794644813197313,
  "in_reply_to_status_id" : 372791541837725696,
  "created_at" : "2013-08-28 18:55:44 +0000",
  "in_reply_to_screen_name" : "DanielleMorrill",
  "in_reply_to_user_id_str" : "7017692",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen",
      "screen_name" : "gln",
      "indices" : [ 0, 4 ],
      "id_str" : "4366051",
      "id" : 4366051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/GUIX6bzNnQ",
      "expanded_url" : "https:\/\/twitter.com\/gln\/lists\/twitter-kids",
      "display_url" : "twitter.com\/gln\/lists\/twit\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "372775851735019521",
  "geo" : { },
  "id_str" : "372778244409266176",
  "in_reply_to_user_id" : 4366051,
  "text" : "@gln Subscribed to https:\/\/t.co\/GUIX6bzNnQ but left TPM alone :)",
  "id" : 372778244409266176,
  "in_reply_to_status_id" : 372775851735019521,
  "created_at" : "2013-08-28 17:50:34 +0000",
  "in_reply_to_screen_name" : "gln",
  "in_reply_to_user_id_str" : "4366051",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Morrill",
      "screen_name" : "DanielleMorrill",
      "indices" : [ 0, 16 ],
      "id_str" : "7017692",
      "id" : 7017692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372776462564474881",
  "geo" : { },
  "id_str" : "372776864076427264",
  "in_reply_to_user_id" : 7017692,
  "text" : "@DanielleMorrill I'm pretty sure you can\u2026 what would stop you?",
  "id" : 372776864076427264,
  "in_reply_to_status_id" : 372776462564474881,
  "created_at" : "2013-08-28 17:45:04 +0000",
  "in_reply_to_screen_name" : "DanielleMorrill",
  "in_reply_to_user_id_str" : "7017692",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372773981428137984",
  "geo" : { },
  "id_str" : "372775436939304960",
  "in_reply_to_user_id" : 2185,
  "text" : "My coworkers apparently don't like this idea and would prefer that I unfollow everyone else and add them to a list.",
  "id" : 372775436939304960,
  "in_reply_to_status_id" : 372773981428137984,
  "created_at" : "2013-08-28 17:39:24 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "TweetDeck",
      "screen_name" : "TweetDeck",
      "indices" : [ 83, 93 ],
      "id_str" : "14803701",
      "id" : 14803701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372774856258883584",
  "geo" : { },
  "id_str" : "372775126133006336",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Yeah, worth considering that option too. But it wouldn't integrate with @tweetdeck quite as easily.",
  "id" : 372775126133006336,
  "in_reply_to_status_id" : 372774856258883584,
  "created_at" : "2013-08-28 17:38:10 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0CA0_\u0CA0",
      "screen_name" : "MikeIsaac",
      "indices" : [ 0, 10 ],
      "id_str" : "19040598",
      "id" : 19040598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372774208612220928",
  "geo" : { },
  "id_str" : "372774670115688448",
  "in_reply_to_user_id" : 19040598,
  "text" : "@MikeIsaac That's the idea, at least. The echo chamber is pretty intense.",
  "id" : 372774670115688448,
  "in_reply_to_status_id" : 372774208612220928,
  "created_at" : "2013-08-28 17:36:21 +0000",
  "in_reply_to_screen_name" : "MikeIsaac",
  "in_reply_to_user_id_str" : "19040598",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Mederos",
      "screen_name" : "pvm",
      "indices" : [ 0, 4 ],
      "id_str" : "76852610",
      "id" : 76852610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372774228803608576",
  "geo" : { },
  "id_str" : "372774530009153538",
  "in_reply_to_user_id" : 76852610,
  "text" : "@pvm Yup.",
  "id" : 372774530009153538,
  "in_reply_to_status_id" : 372774228803608576,
  "created_at" : "2013-08-28 17:35:48 +0000",
  "in_reply_to_screen_name" : "pvm",
  "in_reply_to_user_id_str" : "76852610",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/poptip.com\" rel=\"nofollow\"\u003EPoptip\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372773981428137984",
  "text" : "Thinking of unfollowing all of my fellow Twitter co-workers and putting them in a list so I tweet less about meta-Twitter stuff. Yay or nay?",
  "id" : 372773981428137984,
  "created_at" : "2013-08-28 17:33:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Messinger",
      "screen_name" : "adam_messinger",
      "indices" : [ 37, 52 ],
      "id_str" : "1747381",
      "id" : 1747381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/3SA0X3JyLh",
      "expanded_url" : "http:\/\/www.nytimes.com\/books\/97\/03\/23\/lifetimes\/asi-v-fair.html",
      "display_url" : "nytimes.com\/books\/97\/03\/23\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "372741063384920064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8049178382, -122.2945396422 ]
  },
  "id_str" : "372747626032005120",
  "in_reply_to_user_id" : 1747381,
  "text" : "Enjoyed the *way off* things too. RT @adam_messinger: Asimov's vision of 2014, written in 1964. Not a bad effort... http:\/\/t.co\/3SA0X3JyLh",
  "id" : 372747626032005120,
  "in_reply_to_status_id" : 372741063384920064,
  "created_at" : "2013-08-28 15:48:54 +0000",
  "in_reply_to_screen_name" : "adam_messinger",
  "in_reply_to_user_id_str" : "1747381",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/e6bMy0qrl0",
      "expanded_url" : "http:\/\/flic.kr\/p\/fDddLn",
      "display_url" : "flic.kr\/p\/fDddLn"
    } ]
  },
  "geo" : { },
  "id_str" : "372568185477668864",
  "text" : "8:36pm Back to regular bath times http:\/\/t.co\/e6bMy0qrl0",
  "id" : 372568185477668864,
  "created_at" : "2013-08-28 03:55:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 0, 14 ],
      "id_str" : "18749271",
      "id" : 18749271
    }, {
      "name" : "Magic Recs",
      "screen_name" : "MagicRecs",
      "indices" : [ 30, 40 ],
      "id_str" : "1270746139",
      "id" : 1270746139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372364182274187264",
  "geo" : { },
  "id_str" : "372505914546208768",
  "in_reply_to_user_id" : 18749271,
  "text" : "@libbybrittain A future where @MagicRecs only recommends other magic recommendation accounts.",
  "id" : 372505914546208768,
  "in_reply_to_status_id" : 372364182274187264,
  "created_at" : "2013-08-27 23:48:25 +0000",
  "in_reply_to_screen_name" : "libbybrittain",
  "in_reply_to_user_id_str" : "18749271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarah jeong",
      "screen_name" : "sarahjeong",
      "indices" : [ 0, 11 ],
      "id_str" : "47509268",
      "id" : 47509268
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 12, 19 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 58, 65 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372455872552640512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769314071, -122.4165581634 ]
  },
  "id_str" : "372462897420447744",
  "in_reply_to_user_id" : 47509268,
  "text" : "@sarahjeong @Medium Now that you mention it, so do I! \/cc @jfuchs",
  "id" : 372462897420447744,
  "in_reply_to_status_id" : 372455872552640512,
  "created_at" : "2013-08-27 20:57:29 +0000",
  "in_reply_to_screen_name" : "sarahjeong",
  "in_reply_to_user_id_str" : "47509268",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 10, 17 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/tUBmYTBPI1",
      "expanded_url" : "http:\/\/Ted.com",
      "display_url" : "Ted.com"
    } ]
  },
  "in_reply_to_status_id_str" : "372451973226070016",
  "geo" : { },
  "id_str" : "372453110590877696",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @medium How do you think they could capture that? http:\/\/t.co\/tUBmYTBPI1 has an interesting take, but also causes new problems.",
  "id" : 372453110590877696,
  "in_reply_to_status_id" : 372451973226070016,
  "created_at" : "2013-08-27 20:18:36 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372451973226070016",
  "geo" : { },
  "id_str" : "372452762316836864",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Yeah, judging by the \"most recommended\" lists, the 2-3 minute \"inspirational\" reads seem to win out.",
  "id" : 372452762316836864,
  "in_reply_to_status_id" : 372451973226070016,
  "created_at" : "2013-08-27 20:17:13 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Fujiu",
      "screen_name" : "ryanfujiu",
      "indices" : [ 0, 10 ],
      "id_str" : "29645492",
      "id" : 29645492
    }, {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 73, 80 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372451678902968320",
  "geo" : { },
  "id_str" : "372451889050157056",
  "in_reply_to_user_id" : 29645492,
  "text" : "@ryanfujiu I don't know how they count something as a \"read\". Any hints, @jfuchs?",
  "id" : 372451889050157056,
  "in_reply_to_status_id" : 372451678902968320,
  "created_at" : "2013-08-27 20:13:44 +0000",
  "in_reply_to_screen_name" : "ryanfujiu",
  "in_reply_to_user_id_str" : "29645492",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 20, 27 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/372451090572132352\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/nFi7cM9v6F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSs2SyYCQAAYD4v.png",
      "id_str" : "372451090576326656",
      "id" : 372451090576326656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSs2SyYCQAAYD4v.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 885,
        "resize" : "fit",
        "w" : 847
      }, {
        "h" : 885,
        "resize" : "fit",
        "w" : 847
      }, {
        "h" : 627,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nFi7cM9v6F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372451090572132352",
  "text" : "My fave thing about @medium is the stats page (specifically the read ratio). http:\/\/t.co\/nFi7cM9v6F",
  "id" : 372451090572132352,
  "created_at" : "2013-08-27 20:10:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372438788489768960",
  "text" : "Looking for truth in data is uncomfortable. If you feel comfort and validation when you look at data, you're probably doing it wrong.",
  "id" : 372438788489768960,
  "created_at" : "2013-08-27 19:21:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stellar",
      "screen_name" : "yo_stellar",
      "indices" : [ 3, 14 ],
      "id_str" : "180817904",
      "id" : 180817904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/SiJP3LHjJ7",
      "expanded_url" : "https:\/\/stellar.io\/x\/manage\/membership",
      "display_url" : "stellar.io\/x\/manage\/membe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372401033919463425",
  "text" : "RT @yo_stellar: Excited to introduce the Fun Pass, a yearly membership option for Stellar: https:\/\/t.co\/SiJP3LHjJ7",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/SiJP3LHjJ7",
        "expanded_url" : "https:\/\/stellar.io\/x\/manage\/membership",
        "display_url" : "stellar.io\/x\/manage\/membe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372400968739983361",
    "text" : "Excited to introduce the Fun Pass, a yearly membership option for Stellar: https:\/\/t.co\/SiJP3LHjJ7",
    "id" : 372400968739983361,
    "created_at" : "2013-08-27 16:51:24 +0000",
    "user" : {
      "name" : "Stellar",
      "screen_name" : "yo_stellar",
      "protected" : false,
      "id_str" : "180817904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1244330927\/iOS-114_normal.png",
      "id" : 180817904,
      "verified" : false
    }
  },
  "id" : 372401033919463425,
  "created_at" : "2013-08-27 16:51:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Buckhouse",
      "screen_name" : "buckhouse",
      "indices" : [ 17, 27 ],
      "id_str" : "16896060",
      "id" : 16896060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/3QGQFt3dtK",
      "expanded_url" : "https:\/\/medium.com\/design-story\/44dba7121a1",
      "display_url" : "medium.com\/design-story\/4\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "372380726055817216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597300721, -122.2754647222 ]
  },
  "id_str" : "372393598341230592",
  "in_reply_to_user_id" : 16896060,
  "text" : "Really great: RT @buckhouse: Maybe it's time to renew our work vows? https:\/\/t.co\/3QGQFt3dtK Here's the oath I took in school.",
  "id" : 372393598341230592,
  "in_reply_to_status_id" : 372380726055817216,
  "created_at" : "2013-08-27 16:22:07 +0000",
  "in_reply_to_screen_name" : "buckhouse",
  "in_reply_to_user_id_str" : "16896060",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Harford",
      "screen_name" : "TimHarford",
      "indices" : [ 3, 14 ],
      "id_str" : "32493647",
      "id" : 32493647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/7Lc82dEdgX",
      "expanded_url" : "http:\/\/dlvr.it\/3sZrtx",
      "display_url" : "dlvr.it\/3sZrtx"
    } ]
  },
  "geo" : { },
  "id_str" : "372342625807781888",
  "text" : "RT @TimHarford: \"Signs of Life\" Absolutely beautiful xkcd \"What if\" http:\/\/t.co\/7Lc82dEdgX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/7Lc82dEdgX",
        "expanded_url" : "http:\/\/dlvr.it\/3sZrtx",
        "display_url" : "dlvr.it\/3sZrtx"
      } ]
    },
    "geo" : { },
    "id_str" : "372327537579278338",
    "text" : "\"Signs of Life\" Absolutely beautiful xkcd \"What if\" http:\/\/t.co\/7Lc82dEdgX",
    "id" : 372327537579278338,
    "created_at" : "2013-08-27 11:59:37 +0000",
    "user" : {
      "name" : "Tim Harford",
      "screen_name" : "TimHarford",
      "protected" : false,
      "id_str" : "32493647",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1338890256\/Harford_Cropped_normal.JPG",
      "id" : 32493647,
      "verified" : true
    }
  },
  "id" : 372342625807781888,
  "created_at" : "2013-08-27 12:59:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Penner",
      "screen_name" : "cpen",
      "indices" : [ 0, 5 ],
      "id_str" : "7694352",
      "id" : 7694352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/w3KZdZ51bl",
      "expanded_url" : "http:\/\/www.geekwire.com\/2012\/day-rest-life\/",
      "display_url" : "geekwire.com\/2012\/day-rest-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "372202200660856832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859686059, -122.2755236552 ]
  },
  "id_str" : "372202701896953856",
  "in_reply_to_user_id" : 7694352,
  "text" : "@cpen It's a thing I randomly started 5+ years ago and has just stuck: http:\/\/t.co\/w3KZdZ51bl",
  "id" : 372202701896953856,
  "in_reply_to_status_id" : 372202200660856832,
  "created_at" : "2013-08-27 03:43:33 +0000",
  "in_reply_to_screen_name" : "cpen",
  "in_reply_to_user_id_str" : "7694352",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/FYxHV06o2z",
      "expanded_url" : "http:\/\/flic.kr\/p\/fCPeJE",
      "display_url" : "flic.kr\/p\/fCPeJE"
    } ]
  },
  "geo" : { },
  "id_str" : "372201956833386496",
  "text" : "8:36pm Chatting on Twitter and looking at my cool shoes as I wait for Kellianne and Niko's plane to land http:\/\/t.co\/FYxHV06o2z",
  "id" : 372201956833386496,
  "created_at" : "2013-08-27 03:40:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 11, 21 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372198855351078912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596118372, -122.275473775 ]
  },
  "id_str" : "372199136277188608",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates @avantgame Wait, you're in Berkeley?",
  "id" : 372199136277188608,
  "in_reply_to_status_id" : 372198855351078912,
  "created_at" : "2013-08-27 03:29:23 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372198329234374656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596454487, -122.2754018662 ]
  },
  "id_str" : "372198675688087553",
  "in_reply_to_user_id" : 2185,
  "text" : "@avantgame Draw some lines. People will not freak out.",
  "id" : 372198675688087553,
  "in_reply_to_status_id" : 372198329234374656,
  "created_at" : "2013-08-27 03:27:34 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372197614910836736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596787852, -122.2754595132 ]
  },
  "id_str" : "372198329234374656",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame You do, for sure. Our mental model of you is super simplified and prone to flaws, it's up to you to help us train the model.",
  "id" : 372198329234374656,
  "in_reply_to_status_id" : 372197614910836736,
  "created_at" : "2013-08-27 03:26:11 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372197184914993152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596611443, -122.2755165393 ]
  },
  "id_str" : "372197476679159808",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame It's definitely a game with no expectation of good manners. Enforce your own rules!",
  "id" : 372197476679159808,
  "in_reply_to_status_id" : 372197184914993152,
  "created_at" : "2013-08-27 03:22:48 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372196302521520128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596748701, -122.2755628038 ]
  },
  "id_str" : "372196976164483075",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame I think that means you were doing too much and need a break.",
  "id" : 372196976164483075,
  "in_reply_to_status_id" : 372196302521520128,
  "created_at" : "2013-08-27 03:20:48 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372194222989770753",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596957401, -122.2754790635 ]
  },
  "id_str" : "372196074003238912",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame Too much social calculation going on, maybe? Ignore that and just say yes when you feel like it and no when you feel like it.",
  "id" : 372196074003238912,
  "in_reply_to_status_id" : 372194222989770753,
  "created_at" : "2013-08-27 03:17:13 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372192746875793409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596783057, -122.2754471285 ]
  },
  "id_str" : "372194922671001600",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame Then again if you don't have time or energy to share, say no!",
  "id" : 372194922671001600,
  "in_reply_to_status_id" : 372192746875793409,
  "created_at" : "2013-08-27 03:12:39 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372192584623345664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597300609, -122.2756786816 ]
  },
  "id_str" : "372194632135757825",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame The only game to play is the longest game.",
  "id" : 372194632135757825,
  "in_reply_to_status_id" : 372192584623345664,
  "created_at" : "2013-08-27 03:11:30 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372192584623345664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596073344, -122.2754155234 ]
  },
  "id_str" : "372194477764407296",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame When I talk to VCs (and anyone else) I like, tell them my true thoughts, and don't expect them to keep them secret or pay back.",
  "id" : 372194477764407296,
  "in_reply_to_status_id" : 372192584623345664,
  "created_at" : "2013-08-27 03:10:53 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597425521, -122.2755120814 ]
  },
  "id_str" : "372171593650147328",
  "text" : "Next time you feel kerfuffled about something that makes money by getting your attention, consider the possibility that you're being punk'd.",
  "id" : 372171593650147328,
  "created_at" : "2013-08-27 01:39:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brb",
      "indices" : [ 87, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597926768, -122.2737189477 ]
  },
  "id_str" : "372167225093795840",
  "text" : "It's true, I'm addicted to my ph-- hold a sec, just got a new tweet on the other line. #brb",
  "id" : 372167225093795840,
  "created_at" : "2013-08-27 01:22:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mira Crisp",
      "screen_name" : "misscrisp",
      "indices" : [ 0, 10 ],
      "id_str" : "16228258",
      "id" : 16228258
    }, {
      "name" : "Nassim N. Taleb",
      "screen_name" : "nntaleb",
      "indices" : [ 11, 19 ],
      "id_str" : "381289719",
      "id" : 381289719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372156731989565441",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8593574861, -122.2672682761 ]
  },
  "id_str" : "372158183801774080",
  "in_reply_to_user_id" : 16228258,
  "text" : "@misscrisp @nntaleb What happened?",
  "id" : 372158183801774080,
  "in_reply_to_status_id" : 372156731989565441,
  "created_at" : "2013-08-27 00:46:40 +0000",
  "in_reply_to_screen_name" : "misscrisp",
  "in_reply_to_user_id_str" : "16228258",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Silvia Killingsworth",
      "screen_name" : "silviakillings",
      "indices" : [ 3, 18 ],
      "id_str" : "145773567",
      "id" : 145773567
    }, {
      "name" : "\u27E1 Shani O. Hilton \u27E1",
      "screen_name" : "shani_o",
      "indices" : [ 42, 50 ],
      "id_str" : "13367172",
      "id" : 13367172
    }, {
      "name" : "Sam Faulkner Biddle",
      "screen_name" : "samfbiddle",
      "indices" : [ 78, 89 ],
      "id_str" : "44123487",
      "id" : 44123487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/GzTVyXp2LE",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/shani\/babies-the-best-thing-on-facebook",
      "display_url" : "buzzfeed.com\/shani\/babies-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372158069985128449",
  "text" : "RT @silviakillings: In Defense of Babies: @shani_o http:\/\/t.co\/GzTVyXp2LE cc: @samfbiddle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u27E1 Shani O. Hilton \u27E1",
        "screen_name" : "shani_o",
        "indices" : [ 22, 30 ],
        "id_str" : "13367172",
        "id" : 13367172
      }, {
        "name" : "Sam Faulkner Biddle",
        "screen_name" : "samfbiddle",
        "indices" : [ 58, 69 ],
        "id_str" : "44123487",
        "id" : 44123487
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/GzTVyXp2LE",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/shani\/babies-the-best-thing-on-facebook",
        "display_url" : "buzzfeed.com\/shani\/babies-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372154758569930752",
    "text" : "In Defense of Babies: @shani_o http:\/\/t.co\/GzTVyXp2LE cc: @samfbiddle",
    "id" : 372154758569930752,
    "created_at" : "2013-08-27 00:33:03 +0000",
    "user" : {
      "name" : "Silvia Killingsworth",
      "screen_name" : "silviakillings",
      "protected" : false,
      "id_str" : "145773567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443940629840936960\/HE2JghYS_normal.jpeg",
      "id" : 145773567,
      "verified" : false
    }
  },
  "id" : 372158069985128449,
  "created_at" : "2013-08-27 00:46:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Tseitlin",
      "screen_name" : "atseitlin",
      "indices" : [ 0, 10 ],
      "id_str" : "21461685",
      "id" : 21461685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372151430498377729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8592579172, -122.2672661003 ]
  },
  "id_str" : "372152007861084160",
  "in_reply_to_user_id" : 21461685,
  "text" : "@atseitlin Thanks. Do you have more simians in the making?",
  "id" : 372152007861084160,
  "in_reply_to_status_id" : 372151430498377729,
  "created_at" : "2013-08-27 00:22:07 +0000",
  "in_reply_to_screen_name" : "atseitlin",
  "in_reply_to_user_id_str" : "21461685",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Tseitlin",
      "screen_name" : "atseitlin",
      "indices" : [ 0, 10 ],
      "id_str" : "21461685",
      "id" : 21461685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372141993473744897",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.793705797, -122.3961681917 ]
  },
  "id_str" : "372145658322382848",
  "in_reply_to_user_id" : 21461685,
  "text" : "@atseitlin I think I basically subconsciously re-wrote a less-detailed paraphrase of your article for non-engineers.",
  "id" : 372145658322382848,
  "in_reply_to_status_id" : 372141993473744897,
  "created_at" : "2013-08-26 23:56:53 +0000",
  "in_reply_to_screen_name" : "atseitlin",
  "in_reply_to_user_id_str" : "21461685",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Tseitlin",
      "screen_name" : "atseitlin",
      "indices" : [ 0, 10 ],
      "id_str" : "21461685",
      "id" : 21461685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372140443258982400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7793034716, -122.4142128549 ]
  },
  "id_str" : "372141163324530689",
  "in_reply_to_user_id" : 21461685,
  "text" : "@atseitlin They're like peanut butter and chocolate together! Do you have anything to do with the monkey over there?",
  "id" : 372141163324530689,
  "in_reply_to_status_id" : 372140443258982400,
  "created_at" : "2013-08-26 23:39:02 +0000",
  "in_reply_to_screen_name" : "atseitlin",
  "in_reply_to_user_id_str" : "21461685",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rahul Ganjoo",
      "screen_name" : "elegantlywasted",
      "indices" : [ 0, 16 ],
      "id_str" : "12893512",
      "id" : 12893512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372088552953102336",
  "geo" : { },
  "id_str" : "372095994202058752",
  "in_reply_to_user_id" : 12893512,
  "text" : "@elegantlywasted Wow, thanks Rahul!",
  "id" : 372095994202058752,
  "in_reply_to_status_id" : 372088552953102336,
  "created_at" : "2013-08-26 20:39:32 +0000",
  "in_reply_to_screen_name" : "elegantlywasted",
  "in_reply_to_user_id_str" : "12893512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/mG6NXKL1Ge",
      "expanded_url" : "http:\/\/mashable.com\/2013\/08\/26\/facebook-shared-photo-albums\/",
      "display_url" : "mashable.com\/2013\/08\/26\/fac\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764462162, -122.4173666297 ]
  },
  "id_str" : "372078821656109056",
  "text" : "Smart. \"Facebook Unveils Shared Photo Albums\" http:\/\/t.co\/mG6NXKL1Ge",
  "id" : 372078821656109056,
  "created_at" : "2013-08-26 19:31:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Phelan",
      "screen_name" : "moderndaymarco",
      "indices" : [ 0, 15 ],
      "id_str" : "580128738",
      "id" : 580128738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372031114371538944",
  "geo" : { },
  "id_str" : "372069202665824256",
  "in_reply_to_user_id" : 580128738,
  "text" : "@moderndaymarco Definitely lots of parallels in startup life. Someone should write about that. You? :)",
  "id" : 372069202665824256,
  "in_reply_to_status_id" : 372031114371538944,
  "created_at" : "2013-08-26 18:53:05 +0000",
  "in_reply_to_screen_name" : "moderndaymarco",
  "in_reply_to_user_id_str" : "580128738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Kr\u00FCg",
      "screen_name" : "kk",
      "indices" : [ 0, 3 ],
      "id_str" : "13669",
      "id" : 13669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372051093758672896",
  "geo" : { },
  "id_str" : "372068929666953216",
  "in_reply_to_user_id" : 13669,
  "text" : "@kk I wanna see it! :)",
  "id" : 372068929666953216,
  "in_reply_to_status_id" : 372051093758672896,
  "created_at" : "2013-08-26 18:52:00 +0000",
  "in_reply_to_screen_name" : "kk",
  "in_reply_to_user_id_str" : "13669",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benny Wong",
      "screen_name" : "bdotdub",
      "indices" : [ 3, 11 ],
      "id_str" : "3032241",
      "id" : 3032241
    }, {
      "name" : "Lifehacker",
      "screen_name" : "lifehacker",
      "indices" : [ 42, 53 ],
      "id_str" : "7144422",
      "id" : 7144422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/Wj1WqvO62s",
      "expanded_url" : "http:\/\/lifehacker.com\/the-pros-and-cons-of-working-while-working-out-1172655393",
      "display_url" : "lifehacker.com\/the-pros-and-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372028956863516673",
  "text" : "RT @bdotdub: hahaha my cycling desk is on @lifehacker http:\/\/t.co\/Wj1WqvO62s",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lifehacker",
        "screen_name" : "lifehacker",
        "indices" : [ 29, 40 ],
        "id_str" : "7144422",
        "id" : 7144422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/Wj1WqvO62s",
        "expanded_url" : "http:\/\/lifehacker.com\/the-pros-and-cons-of-working-while-working-out-1172655393",
        "display_url" : "lifehacker.com\/the-pros-and-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372028291567214592",
    "text" : "hahaha my cycling desk is on @lifehacker http:\/\/t.co\/Wj1WqvO62s",
    "id" : 372028291567214592,
    "created_at" : "2013-08-26 16:10:31 +0000",
    "user" : {
      "name" : "Benny Wong",
      "screen_name" : "bdotdub",
      "protected" : false,
      "id_str" : "3032241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2199137970\/icon2_normal.jpg",
      "id" : 3032241,
      "verified" : false
    }
  },
  "id" : 372028956863516673,
  "created_at" : "2013-08-26 16:13:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teammiley",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8534369492, -122.2707876248 ]
  },
  "id_str" : "372028694086160384",
  "text" : "Anyone who's not on #teammiley has officially become their parents. (Which, at age 37, is probably a bit reasonable.)",
  "id" : 372028694086160384,
  "created_at" : "2013-08-26 16:12:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teammiley",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595630547, -122.2755743703 ]
  },
  "id_str" : "372016402208522240",
  "text" : "#teammiley",
  "id" : 372016402208522240,
  "created_at" : "2013-08-26 15:23:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Faulkner Biddle",
      "screen_name" : "samfbiddle",
      "indices" : [ 3, 14 ],
      "id_str" : "44123487",
      "id" : 44123487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/GrOScbbAdF",
      "expanded_url" : "http:\/\/giphy.com\/tags\/vmas-2013",
      "display_url" : "giphy.com\/tags\/vmas-2013"
    } ]
  },
  "geo" : { },
  "id_str" : "372015097272479745",
  "text" : "RT @samfbiddle: giphy is ascendant http:\/\/t.co\/GrOScbbAdF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/GrOScbbAdF",
        "expanded_url" : "http:\/\/giphy.com\/tags\/vmas-2013",
        "display_url" : "giphy.com\/tags\/vmas-2013"
      } ]
    },
    "geo" : { },
    "id_str" : "372010608834523136",
    "text" : "giphy is ascendant http:\/\/t.co\/GrOScbbAdF",
    "id" : 372010608834523136,
    "created_at" : "2013-08-26 15:00:15 +0000",
    "user" : {
      "name" : "Sam Faulkner Biddle",
      "screen_name" : "samfbiddle",
      "protected" : false,
      "id_str" : "44123487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460197159661764608\/MPtYtHu5_normal.jpeg",
      "id" : 44123487,
      "verified" : false
    }
  },
  "id" : 372015097272479745,
  "created_at" : "2013-08-26 15:18:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Oliveira",
      "screen_name" : "f",
      "indices" : [ 0, 2 ],
      "id_str" : "5511",
      "id" : 5511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372012969724764160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596200275, -122.2756739147 ]
  },
  "id_str" : "372013900373319680",
  "in_reply_to_user_id" : 5511,
  "text" : "@f Made you look! +3pts",
  "id" : 372013900373319680,
  "in_reply_to_status_id" : 372012969724764160,
  "created_at" : "2013-08-26 15:13:20 +0000",
  "in_reply_to_screen_name" : "f",
  "in_reply_to_user_id_str" : "5511",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "indices" : [ 0, 8 ],
      "id_str" : "4030",
      "id" : 4030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372006456608169984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597060158, -122.2759767887 ]
  },
  "id_str" : "372007328913956865",
  "in_reply_to_user_id" : 4030,
  "text" : "@monstro I'm in!",
  "id" : 372007328913956865,
  "in_reply_to_status_id" : 372006456608169984,
  "created_at" : "2013-08-26 14:47:13 +0000",
  "in_reply_to_screen_name" : "monstro",
  "in_reply_to_user_id_str" : "4030",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "indices" : [ 0, 8 ],
      "id_str" : "4030",
      "id" : 4030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371947441127702528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595964594, -122.2756561776 ]
  },
  "id_str" : "372006360155570178",
  "in_reply_to_user_id" : 4030,
  "text" : "@monstro Thanks, Lane! PS. Hi!",
  "id" : 372006360155570178,
  "in_reply_to_status_id" : 371947441127702528,
  "created_at" : "2013-08-26 14:43:22 +0000",
  "in_reply_to_screen_name" : "monstro",
  "in_reply_to_user_id_str" : "4030",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gustav Arng\u00E5rden",
      "screen_name" : "arngarden",
      "indices" : [ 0, 10 ],
      "id_str" : "26252299",
      "id" : 26252299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371881179755978752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596885316, -122.2755499744 ]
  },
  "id_str" : "371893169194942465",
  "in_reply_to_user_id" : 26252299,
  "text" : "@arngarden Thanks, Gustav!",
  "id" : 371893169194942465,
  "in_reply_to_status_id" : 371881179755978752,
  "created_at" : "2013-08-26 07:13:35 +0000",
  "in_reply_to_screen_name" : "arngarden",
  "in_reply_to_user_id_str" : "26252299",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Ryan B. Jackson",
      "screen_name" : "RyanBJackson1",
      "indices" : [ 0, 14 ],
      "id_str" : "416392654",
      "id" : 416392654
    }, {
      "name" : "Dr. Tim Drinkwine",
      "screen_name" : "Drizzinkwine",
      "indices" : [ 15, 28 ],
      "id_str" : "355918005",
      "id" : 355918005
    }, {
      "name" : "joe12south",
      "screen_name" : "joe12south",
      "indices" : [ 29, 40 ],
      "id_str" : "10306132",
      "id" : 10306132
    }, {
      "name" : "Ketric",
      "screen_name" : "Ketric",
      "indices" : [ 41, 48 ],
      "id_str" : "17269256",
      "id" : 17269256
    }, {
      "name" : "Leticia Elcy Skae",
      "screen_name" : "LSkae",
      "indices" : [ 49, 55 ],
      "id_str" : "450976578",
      "id" : 450976578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371848892985262080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596382632, -122.2756453642 ]
  },
  "id_str" : "371857025338077184",
  "in_reply_to_user_id" : 416392654,
  "text" : "@RyanBJackson1 @Drizzinkwine @joe12south @Ketric @LSkae Thanks for the kind words, Doc.",
  "id" : 371857025338077184,
  "in_reply_to_status_id" : 371848892985262080,
  "created_at" : "2013-08-26 04:49:58 +0000",
  "in_reply_to_screen_name" : "RyanBJackson1",
  "in_reply_to_user_id_str" : "416392654",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Wolf",
      "screen_name" : "wolfmatthewj",
      "indices" : [ 0, 13 ],
      "id_str" : "146085623",
      "id" : 146085623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371852217982017537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859728681, -122.2755327077 ]
  },
  "id_str" : "371856245814091776",
  "in_reply_to_user_id" : 146085623,
  "text" : "@wolfmatthewj Ha! I did #2 and #3 together and it led to #1.",
  "id" : 371856245814091776,
  "in_reply_to_status_id" : 371852217982017537,
  "created_at" : "2013-08-26 04:46:52 +0000",
  "in_reply_to_screen_name" : "wolfmatthewj",
  "in_reply_to_user_id_str" : "146085623",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371843802249437184",
  "geo" : { },
  "id_str" : "371844187257188353",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Oooh, that one would be perfect. Thanks!",
  "id" : 371844187257188353,
  "in_reply_to_status_id" : 371843802249437184,
  "created_at" : "2013-08-26 03:58:57 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371842164604411904",
  "geo" : { },
  "id_str" : "371842869213929472",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm I have! And read the book! And love both. Great rec.",
  "id" : 371842869213929472,
  "in_reply_to_status_id" : 371842164604411904,
  "created_at" : "2013-08-26 03:53:43 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/mexVIDz6hh",
      "expanded_url" : "http:\/\/flic.kr\/p\/fBQeLz",
      "display_url" : "flic.kr\/p\/fBQeLz"
    } ]
  },
  "geo" : { },
  "id_str" : "371841804703789056",
  "text" : "8:36pm Trying to decide if my evening is a movie (recs?) or to just go straight to bed. http:\/\/t.co\/mexVIDz6hh",
  "id" : 371841804703789056,
  "created_at" : "2013-08-26 03:49:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neven Mrgan",
      "screen_name" : "mrgan",
      "indices" : [ 35, 41 ],
      "id_str" : "35293",
      "id" : 35293
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blackbar",
      "indices" : [ 43, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597317404, -122.2755021976 ]
  },
  "id_str" : "371835199815815168",
  "text" : "Got the happy ending, I think. Thx @mrgan! #blackbar",
  "id" : 371835199815815168,
  "created_at" : "2013-08-26 03:23:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371829011795542017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859559157, -122.2756990046 ]
  },
  "id_str" : "371829833933680640",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm Seriously awesome books. Let me know what you think of them.",
  "id" : 371829833933680640,
  "in_reply_to_status_id" : 371829011795542017,
  "created_at" : "2013-08-26 03:01:55 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Kristof",
      "screen_name" : "NickKristof",
      "indices" : [ 3, 15 ],
      "id_str" : "17004618",
      "id" : 17004618
    }, {
      "name" : "Stunning Pictures",
      "screen_name" : "PicturesEarth",
      "indices" : [ 27, 41 ],
      "id_str" : "1098364164",
      "id" : 1098364164
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PicturesEarth\/status\/371769270323396608\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Vn4ei4eFjg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSjKLnKIQAAk30r.jpg",
      "id_str" : "371769270096904192",
      "id" : 371769270096904192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSjKLnKIQAAk30r.jpg",
      "sizes" : [ {
        "h" : 349,
        "resize" : "fit",
        "w" : 448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 448
      }, {
        "h" : 265,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 448
      } ],
      "display_url" : "pic.twitter.com\/Vn4ei4eFjg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371816549834711040",
  "text" : "RT @NickKristof: Awe... RT @PicturesEarth: Researcher in China wears panda costume to comfort cub who lost her mom http:\/\/t.co\/Vn4ei4eFjg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stunning Pictures",
        "screen_name" : "PicturesEarth",
        "indices" : [ 10, 24 ],
        "id_str" : "1098364164",
        "id" : 1098364164
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PicturesEarth\/status\/371769270323396608\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/Vn4ei4eFjg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSjKLnKIQAAk30r.jpg",
        "id_str" : "371769270096904192",
        "id" : 371769270096904192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSjKLnKIQAAk30r.jpg",
        "sizes" : [ {
          "h" : 349,
          "resize" : "fit",
          "w" : 448
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 448
        }, {
          "h" : 265,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 448
        } ],
        "display_url" : "pic.twitter.com\/Vn4ei4eFjg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "371770059296763904",
    "text" : "Awe... RT @PicturesEarth: Researcher in China wears panda costume to comfort cub who lost her mom http:\/\/t.co\/Vn4ei4eFjg",
    "id" : 371770059296763904,
    "created_at" : "2013-08-25 23:04:23 +0000",
    "user" : {
      "name" : "Nicholas Kristof",
      "screen_name" : "NickKristof",
      "protected" : false,
      "id_str" : "17004618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449615760168460288\/CotqSaTE_normal.jpeg",
      "id" : 17004618,
      "verified" : true
    }
  },
  "id" : 371816549834711040,
  "created_at" : "2013-08-26 02:09:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Wolf",
      "screen_name" : "wolfmatthewj",
      "indices" : [ 0, 13 ],
      "id_str" : "146085623",
      "id" : 146085623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371812058205274112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597674043, -122.2755670584 ]
  },
  "id_str" : "371813361765199872",
  "in_reply_to_user_id" : 146085623,
  "text" : "@wolfmatthewj Totally. Or start a business.",
  "id" : 371813361765199872,
  "in_reply_to_status_id" : 371812058205274112,
  "created_at" : "2013-08-26 01:56:28 +0000",
  "in_reply_to_screen_name" : "wolfmatthewj",
  "in_reply_to_user_id_str" : "146085623",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "katie dreke",
      "screen_name" : "katiedreke",
      "indices" : [ 0, 11 ],
      "id_str" : "5749372",
      "id" : 5749372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371810462574211072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597180359, -122.2755683308 ]
  },
  "id_str" : "371811971223392256",
  "in_reply_to_user_id" : 5749372,
  "text" : "@katiedreke Aww thanks.",
  "id" : 371811971223392256,
  "in_reply_to_status_id" : 371810462574211072,
  "created_at" : "2013-08-26 01:50:56 +0000",
  "in_reply_to_screen_name" : "katiedreke",
  "in_reply_to_user_id_str" : "5749372",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "indices" : [ 3, 15 ],
      "id_str" : "289534689",
      "id" : 289534689
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 127, 134 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 139, 140 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/3iJKnUd4aw",
      "expanded_url" : "https:\/\/medium.com\/better-humans\/c02337782a89",
      "display_url" : "medium.com\/better-humans\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371808410561282050",
  "text" : "RT @seriouspony: This is one of the best things I've read in a while! On making *you* antifragile.  https:\/\/t.co\/3iJKnUd4aw by @buster h\/t \u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 110, 117 ],
        "id_str" : "2185",
        "id" : 2185
      }, {
        "name" : "Tony Stubblebine",
        "screen_name" : "tonystubblebine",
        "indices" : [ 122, 138 ],
        "id_str" : "17",
        "id" : 17
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/3iJKnUd4aw",
        "expanded_url" : "https:\/\/medium.com\/better-humans\/c02337782a89",
        "display_url" : "medium.com\/better-humans\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "371767425760366592",
    "text" : "This is one of the best things I've read in a while! On making *you* antifragile.  https:\/\/t.co\/3iJKnUd4aw by @buster h\/t @tonystubblebine",
    "id" : 371767425760366592,
    "created_at" : "2013-08-25 22:53:56 +0000",
    "user" : {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "protected" : false,
      "id_str" : "289534689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000125491934\/4759dbdd7f9745522eeb9cdf5315efa2_normal.jpeg",
      "id" : 289534689,
      "verified" : false
    }
  },
  "id" : 371808410561282050,
  "created_at" : "2013-08-26 01:36:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Leto",
      "screen_name" : "laurenleto",
      "indices" : [ 0, 11 ],
      "id_str" : "15510569",
      "id" : 15510569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371799521384087553",
  "in_reply_to_user_id" : 15510569,
  "text" : "@laurenleto Do you have a script or something that mass-favorites things once an hour? How does it work? (I have my Activity tab open.)",
  "id" : 371799521384087553,
  "created_at" : "2013-08-26 01:01:28 +0000",
  "in_reply_to_screen_name" : "laurenleto",
  "in_reply_to_user_id_str" : "15510569",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30EC",
      "screen_name" : "arieare",
      "indices" : [ 76, 84 ],
      "id_str" : "77383180",
      "id" : 77383180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/UutUxOAMop",
      "expanded_url" : "https:\/\/medium.com\/i-m-h-o\/3252bbcfa36f",
      "display_url" : "medium.com\/i-m-h-o\/3252bb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371794247227146240",
  "text" : "Hearty encouragement for my growing bike obsession: \u201CWhy I Ride My Bike\u201D by @arieare https:\/\/t.co\/UutUxOAMop",
  "id" : 371794247227146240,
  "created_at" : "2013-08-26 00:40:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Newman",
      "screen_name" : "dannynewman",
      "indices" : [ 0, 12 ],
      "id_str" : "8273",
      "id" : 8273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/qmu7lWnB3c",
      "expanded_url" : "https:\/\/twitter.com\/waxpancake\/status\/371697791061331968",
      "display_url" : "twitter.com\/waxpancake\/sta\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "371778149723303936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597314443, -122.2754026574 ]
  },
  "id_str" : "371779060013088768",
  "in_reply_to_user_id" : 8273,
  "text" : "@dannynewman I solved it after this: https:\/\/t.co\/qmu7lWnB3c",
  "id" : 371779060013088768,
  "in_reply_to_status_id" : 371778149723303936,
  "created_at" : "2013-08-25 23:40:09 +0000",
  "in_reply_to_screen_name" : "dannynewman",
  "in_reply_to_user_id_str" : "8273",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 0, 6 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 7, 13 ],
      "id_str" : "15310552",
      "id" : 15310552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371778113861988352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597045424, -122.275471211 ]
  },
  "id_str" : "371778433514094592",
  "in_reply_to_user_id" : 631823,
  "text" : "@couch @singy How did you know I was a gluten free vegan cheese pizza?",
  "id" : 371778433514094592,
  "in_reply_to_status_id" : 371778113861988352,
  "created_at" : "2013-08-25 23:37:40 +0000",
  "in_reply_to_screen_name" : "couch",
  "in_reply_to_user_id_str" : "631823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/371777844537344000\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/PZMMoLMvzm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSjR-tdCQAASrsK.jpg",
      "id_str" : "371777844541538304",
      "id" : 371777844541538304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSjR-tdCQAASrsK.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/PZMMoLMvzm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371777844537344000",
  "text" : "I can go home now. http:\/\/t.co\/PZMMoLMvzm",
  "id" : 371777844537344000,
  "created_at" : "2013-08-25 23:35:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "indices" : [ 0, 12 ],
      "id_str" : "289534689",
      "id" : 289534689
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 13, 29 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371767425760366592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596297745, -122.2753765528 ]
  },
  "id_str" : "371774937825939456",
  "in_reply_to_user_id" : 289534689,
  "text" : "@seriouspony @tonystubblebine Woah, thanks! That makes my day.",
  "id" : 371774937825939456,
  "in_reply_to_status_id" : 371767425760366592,
  "created_at" : "2013-08-25 23:23:47 +0000",
  "in_reply_to_screen_name" : "seriouspony",
  "in_reply_to_user_id_str" : "289534689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/371757173912530944\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/0E8DoAne1w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSi_LhYCcAALSOg.jpg",
      "id_str" : "371757173916725248",
      "id" : 371757173916725248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSi_LhYCcAALSOg.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/0E8DoAne1w"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8616436106, -122.2794167978 ]
  },
  "id_str" : "371757173912530944",
  "text" : "http:\/\/t.co\/0E8DoAne1w",
  "id" : 371757173912530944,
  "created_at" : "2013-08-25 22:13:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    }, {
      "name" : "Nassim N. Taleb",
      "screen_name" : "nntaleb",
      "indices" : [ 28, 36 ],
      "id_str" : "381289719",
      "id" : 381289719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371729397218160640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8571638597, -122.2674158784 ]
  },
  "id_str" : "371733328518340608",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold Antifragile, by @nntaleb",
  "id" : 371733328518340608,
  "in_reply_to_status_id" : 371729397218160640,
  "created_at" : "2013-08-25 20:38:26 +0000",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371724072196919296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8572865297, -122.2668388301 ]
  },
  "id_str" : "371728318426402816",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold Do it! Read the book too.",
  "id" : 371728318426402816,
  "in_reply_to_status_id" : 371724072196919296,
  "created_at" : "2013-08-25 20:18:32 +0000",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MailChimp",
      "screen_name" : "MailChimp",
      "indices" : [ 12, 22 ],
      "id_str" : "14377870",
      "id" : 14377870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/RjqY3ulEKl",
      "expanded_url" : "http:\/\/mailchimp.com\/comic",
      "display_url" : "mailchimp.com\/comic"
    } ]
  },
  "in_reply_to_status_id_str" : "368428403306680320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598092144, -122.2760275559 ]
  },
  "id_str" : "371717590747336705",
  "in_reply_to_user_id" : 14377870,
  "text" : "Amayzing RT @MailChimp: Who purloined the Banana Serum?? http:\/\/t.co\/RjqY3ulEKl",
  "id" : 371717590747336705,
  "in_reply_to_status_id" : 368428403306680320,
  "created_at" : "2013-08-25 19:35:54 +0000",
  "in_reply_to_screen_name" : "MailChimp",
  "in_reply_to_user_id_str" : "14377870",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nein.",
      "screen_name" : "NeinQuarterly",
      "indices" : [ 3, 17 ],
      "id_str" : "458966079",
      "id" : 458966079
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NeinQuarterly\/status\/371713250997456896\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/4i01unQUv1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSiXO3xCUAA5DZO.jpg",
      "id_str" : "371713251001651200",
      "id" : 371713251001651200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSiXO3xCUAA5DZO.jpg",
      "sizes" : [ {
        "h" : 880,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 825,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 880,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/4i01unQUv1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371715694938714112",
  "text" : "RT @NeinQuarterly: THIS. http:\/\/t.co\/4i01unQUv1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NeinQuarterly\/status\/371713250997456896\/photo\/1",
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/4i01unQUv1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSiXO3xCUAA5DZO.jpg",
        "id_str" : "371713251001651200",
        "id" : 371713251001651200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSiXO3xCUAA5DZO.jpg",
        "sizes" : [ {
          "h" : 880,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 825,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 880,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/4i01unQUv1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "371713250997456896",
    "text" : "THIS. http:\/\/t.co\/4i01unQUv1",
    "id" : 371713250997456896,
    "created_at" : "2013-08-25 19:18:39 +0000",
    "user" : {
      "name" : "Nein.",
      "screen_name" : "NeinQuarterly",
      "protected" : false,
      "id_str" : "458966079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000829092209\/ed4c25faaa25fbba40b11fabe8241a59_normal.jpeg",
      "id" : 458966079,
      "verified" : true
    }
  },
  "id" : 371715694938714112,
  "created_at" : "2013-08-25 19:28:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trammell",
      "screen_name" : "trammell",
      "indices" : [ 0, 9 ],
      "id_str" : "666073",
      "id" : 666073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371696161377120257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597079777, -122.275462635 ]
  },
  "id_str" : "371698175586729985",
  "in_reply_to_user_id" : 666073,
  "text" : "@trammell I like it again now that I got the word.",
  "id" : 371698175586729985,
  "in_reply_to_status_id" : 371696161377120257,
  "created_at" : "2013-08-25 18:18:45 +0000",
  "in_reply_to_screen_name" : "trammell",
  "in_reply_to_user_id_str" : "666073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brainblock",
      "indices" : [ 28, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371697791061331968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596711852, -122.2755664122 ]
  },
  "id_str" : "371698028060479488",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake Thank you! Doi. #brainblock",
  "id" : 371698028060479488,
  "in_reply_to_status_id" : 371697791061331968,
  "created_at" : "2013-08-25 18:18:10 +0000",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371695461259689984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597117592, -122.2753477215 ]
  },
  "id_str" : "371695860398051328",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez I tried iPhone... nope. :) Something sword-like?",
  "id" : 371695860398051328,
  "in_reply_to_status_id" : 371695461259689984,
  "created_at" : "2013-08-25 18:09:33 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371694865802743808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596371624, -122.2757315044 ]
  },
  "id_str" : "371695269890363392",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez Sword seems like the obvious answer but it's one letter too short! Not dagger, not feather...",
  "id" : 371695269890363392,
  "in_reply_to_status_id" : 371694865802743808,
  "created_at" : "2013-08-25 18:07:12 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/371693993702072320\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/eylaHRgQt5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSiFt8wCIAAxWEF.jpg",
      "id_str" : "371693993706266624",
      "id" : 371693993706266624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSiFt8wCIAAxWEF.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/eylaHRgQt5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596524508, -122.2754274455 ]
  },
  "id_str" : "371693993702072320",
  "text" : "Who's playing Blackbar? I need a hint. PS I like the idea of Blackbar 2 being a redacted clue guide for Blackbar. http:\/\/t.co\/eylaHRgQt5",
  "id" : 371693993702072320,
  "created_at" : "2013-08-25 18:02:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371691540776636416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859766012, -122.2753324998 ]
  },
  "id_str" : "371692493496020994",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Yeah lost some nerd points there. Fixed.",
  "id" : 371692493496020994,
  "in_reply_to_status_id" : 371691540776636416,
  "created_at" : "2013-08-25 17:56:10 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anita Carter",
      "screen_name" : "foodfamilyandme",
      "indices" : [ 0, 16 ],
      "id_str" : "84584419",
      "id" : 84584419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371674249364123649",
  "geo" : { },
  "id_str" : "371683967847518210",
  "in_reply_to_user_id" : 84584419,
  "text" : "@foodfamilyandme The Chaos Monkey is a little less intimidating once you name him, right?",
  "id" : 371683967847518210,
  "in_reply_to_status_id" : 371674249364123649,
  "created_at" : "2013-08-25 17:22:18 +0000",
  "in_reply_to_screen_name" : "foodfamilyandme",
  "in_reply_to_user_id_str" : "84584419",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sundaypost",
      "indices" : [ 88, 99 ]
    }, {
      "text" : "longreads",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/ZmSs7rD9Go",
      "expanded_url" : "https:\/\/medium.com\/better-humans\/c02337782a89",
      "display_url" : "medium.com\/better-humans\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371683180043964416",
  "text" : "Sunday thoughts on how to get stronger when things are chaotic: https:\/\/t.co\/ZmSs7rD9Go #sundaypost #longreads",
  "id" : 371683180043964416,
  "created_at" : "2013-08-25 17:19:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alena Dorokhina",
      "screen_name" : "AlenaDorokhina",
      "indices" : [ 0, 15 ],
      "id_str" : "490571707",
      "id" : 490571707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371600886252204032",
  "geo" : { },
  "id_str" : "371640602829393920",
  "in_reply_to_user_id" : 490571707,
  "text" : "@AlenaDorokhina Unfortunately not. I've mentioned it in talks, but I really should write it up at some point.",
  "id" : 371640602829393920,
  "in_reply_to_status_id" : 371600886252204032,
  "created_at" : "2013-08-25 14:29:59 +0000",
  "in_reply_to_screen_name" : "AlenaDorokhina",
  "in_reply_to_user_id_str" : "490571707",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chandra Nerd Lodhiya",
      "screen_name" : "nerd_chandra",
      "indices" : [ 0, 13 ],
      "id_str" : "123065011",
      "id" : 123065011
    }, {
      "name" : "Arjun Balaji",
      "screen_name" : "arjunblj",
      "indices" : [ 14, 23 ],
      "id_str" : "25552514",
      "id" : 25552514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371508281719521280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597505996, -122.2755301093 ]
  },
  "id_str" : "371517932481675264",
  "in_reply_to_user_id" : 123065011,
  "text" : "@nerd_chandra @arjunblj Thanks!",
  "id" : 371517932481675264,
  "in_reply_to_status_id" : 371508281719521280,
  "created_at" : "2013-08-25 06:22:32 +0000",
  "in_reply_to_screen_name" : "nerd_chandra",
  "in_reply_to_user_id_str" : "123065011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rand Fitzpatrick",
      "screen_name" : "sixwing",
      "indices" : [ 0, 8 ],
      "id_str" : "903011",
      "id" : 903011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371492984795054081",
  "geo" : { },
  "id_str" : "371493147060088832",
  "in_reply_to_user_id" : 903011,
  "text" : "@sixwing Ha, I'll try. Have fun!",
  "id" : 371493147060088832,
  "in_reply_to_status_id" : 371492984795054081,
  "created_at" : "2013-08-25 04:44:02 +0000",
  "in_reply_to_screen_name" : "sixwing",
  "in_reply_to_user_id_str" : "903011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rand Fitzpatrick",
      "screen_name" : "sixwing",
      "indices" : [ 0, 8 ],
      "id_str" : "903011",
      "id" : 903011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371492694465314816",
  "geo" : { },
  "id_str" : "371492805085888512",
  "in_reply_to_user_id" : 903011,
  "text" : "@sixwing I'd love to hear more\u2026 write it up!",
  "id" : 371492805085888512,
  "in_reply_to_status_id" : 371492694465314816,
  "created_at" : "2013-08-25 04:42:41 +0000",
  "in_reply_to_screen_name" : "sixwing",
  "in_reply_to_user_id_str" : "903011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rand Fitzpatrick",
      "screen_name" : "sixwing",
      "indices" : [ 0, 8 ],
      "id_str" : "903011",
      "id" : 903011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371489837708103680",
  "geo" : { },
  "id_str" : "371491790085304320",
  "in_reply_to_user_id" : 903011,
  "text" : "@sixwing Yeah, I've struggled with finding the right axioms that allow iteration and improvement over time but aren't too complicated.",
  "id" : 371491790085304320,
  "in_reply_to_status_id" : 371489837708103680,
  "created_at" : "2013-08-25 04:38:39 +0000",
  "in_reply_to_screen_name" : "sixwing",
  "in_reply_to_user_id_str" : "903011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/W3AXxdhqSS",
      "expanded_url" : "http:\/\/flic.kr\/p\/fB47dv",
      "display_url" : "flic.kr\/p\/fB47dv"
    } ]
  },
  "geo" : { },
  "id_str" : "371477475429081089",
  "text" : "8:36pm Watching the awesome Daniel Kahneman talk about the tyranny of the remembering self http:\/\/t.co\/W3AXxdhqSS",
  "id" : 371477475429081089,
  "created_at" : "2013-08-25 03:41:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Dunn",
      "screen_name" : "maxdunn",
      "indices" : [ 0, 8 ],
      "id_str" : "14762746",
      "id" : 14762746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371469121739055104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597394165, -122.2755088198 ]
  },
  "id_str" : "371475639112433666",
  "in_reply_to_user_id" : 14762746,
  "text" : "@maxdunn Thank you!",
  "id" : 371475639112433666,
  "in_reply_to_status_id" : 371469121739055104,
  "created_at" : "2013-08-25 03:34:28 +0000",
  "in_reply_to_screen_name" : "maxdunn",
  "in_reply_to_user_id_str" : "14762746",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill S.",
      "screen_name" : "outseide",
      "indices" : [ 0, 9 ],
      "id_str" : "143694663",
      "id" : 143694663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371465773119995904",
  "geo" : { },
  "id_str" : "371467976160985088",
  "in_reply_to_user_id" : 143694663,
  "text" : "@outseide Yeah, it's been something I've been thinking about for a long time but never really found a way to articulate it fully\u2026 thanks.",
  "id" : 371467976160985088,
  "in_reply_to_status_id" : 371465773119995904,
  "created_at" : "2013-08-25 03:04:01 +0000",
  "in_reply_to_screen_name" : "outseide",
  "in_reply_to_user_id_str" : "143694663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 0, 4 ],
      "id_str" : "12720772",
      "id" : 12720772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371460871769190400",
  "geo" : { },
  "id_str" : "371461058625413120",
  "in_reply_to_user_id" : 12720772,
  "text" : "@gwb Thanks, my man. That DayQuil was strong, I think.",
  "id" : 371461058625413120,
  "in_reply_to_status_id" : 371460871769190400,
  "created_at" : "2013-08-25 02:36:32 +0000",
  "in_reply_to_screen_name" : "gwb",
  "in_reply_to_user_id_str" : "12720772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/QCBtfUE3X7",
      "expanded_url" : "http:\/\/bit.ly\/16vWQDz",
      "display_url" : "bit.ly\/16vWQDz"
    } ]
  },
  "geo" : { },
  "id_str" : "371457072518275072",
  "text" : "\"Live Like a Hydra.\" My attempt at integrating habits, antifragility, and the chaos monkey. http:\/\/t.co\/QCBtfUE3X7 (Would &lt;3 yr feedback!)",
  "id" : 371457072518275072,
  "created_at" : "2013-08-25 02:20:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/gtB0SZtFot",
      "expanded_url" : "http:\/\/bit.ly\/16H5ti4",
      "display_url" : "bit.ly\/16H5ti4"
    } ]
  },
  "in_reply_to_status_id_str" : "371433426382888960",
  "geo" : { },
  "id_str" : "371433541550084096",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun Thanks! Yeah: http:\/\/t.co\/gtB0SZtFot",
  "id" : 371433541550084096,
  "in_reply_to_status_id" : 371433426382888960,
  "created_at" : "2013-08-25 00:47:11 +0000",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/9aJw6lkc8R",
      "expanded_url" : "http:\/\/bit.ly\/16H5brK",
      "display_url" : "bit.ly\/16H5brK"
    }, {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/lQ606pTReQ",
      "expanded_url" : "http:\/\/bit.ly\/Rk6Ijh",
      "display_url" : "bit.ly\/Rk6Ijh"
    } ]
  },
  "geo" : { },
  "id_str" : "371432902073909248",
  "text" : "Updated my Beliefs file, specifically privacy stuff post NSA craziness. http:\/\/t.co\/9aJw6lkc8R (see all: http:\/\/t.co\/lQ606pTReQ)",
  "id" : 371432902073909248,
  "created_at" : "2013-08-25 00:44:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 124, 133 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/hzTyhlbf2K",
      "expanded_url" : "http:\/\/bit.ly\/157FMTW",
      "display_url" : "bit.ly\/157FMTW"
    } ]
  },
  "geo" : { },
  "id_str" : "371406945111912448",
  "text" : "\"Go blow people away in front of their face. I honestly believe it's that simple.\" - Dave Grohl http:\/\/t.co\/hzTyhlbf2K \/via @RickWebb",
  "id" : 371406945111912448,
  "created_at" : "2013-08-24 23:01:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Teague",
      "screen_name" : "ErinTeague",
      "indices" : [ 0, 11 ],
      "id_str" : "116299414",
      "id" : 116299414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371353457589886976",
  "geo" : { },
  "id_str" : "371372262839959552",
  "in_reply_to_user_id" : 116299414,
  "text" : "@ErinTeague Doing well! Just need a new contact at Path now\u2026 :)",
  "id" : 371372262839959552,
  "in_reply_to_status_id" : 371353457589886976,
  "created_at" : "2013-08-24 20:43:41 +0000",
  "in_reply_to_screen_name" : "ErinTeague",
  "in_reply_to_user_id_str" : "116299414",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Weinersmith",
      "screen_name" : "ZachWeiner",
      "indices" : [ 3, 14 ],
      "id_str" : "20745130",
      "id" : 20745130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/EO5NI1lqxk",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/?id=3091",
      "display_url" : "smbc-comics.com\/?id=3091"
    } ]
  },
  "geo" : { },
  "id_str" : "371332275914305536",
  "text" : "RT @ZachWeiner: Zombiecology http:\/\/t.co\/EO5NI1lqxk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/EO5NI1lqxk",
        "expanded_url" : "http:\/\/www.smbc-comics.com\/?id=3091",
        "display_url" : "smbc-comics.com\/?id=3091"
      } ]
    },
    "geo" : { },
    "id_str" : "371324264705556480",
    "text" : "Zombiecology http:\/\/t.co\/EO5NI1lqxk",
    "id" : 371324264705556480,
    "created_at" : "2013-08-24 17:32:58 +0000",
    "user" : {
      "name" : "Zach Weinersmith",
      "screen_name" : "ZachWeiner",
      "protected" : false,
      "id_str" : "20745130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2634755453\/40ffdf8a114b08a13aecc6f2a3a17320_normal.png",
      "id" : 20745130,
      "verified" : true
    }
  },
  "id" : 371332275914305536,
  "created_at" : "2013-08-24 18:04:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inhabitat",
      "screen_name" : "inhabitat",
      "indices" : [ 3, 13 ],
      "id_str" : "14150661",
      "id" : 14150661
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "design",
      "indices" : [ 106, 113 ]
    }, {
      "text" : "3dprinting",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/e7H76NInXf",
      "expanded_url" : "http:\/\/ow.ly\/oesCz",
      "display_url" : "ow.ly\/oesCz"
    } ]
  },
  "geo" : { },
  "id_str" : "371316377178488832",
  "text" : "RT @inhabitat: Meet the \"Genesis\": a 3D-printed car concept that assembles itself! http:\/\/t.co\/e7H76NInXf #design #3dprinting",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "design",
        "indices" : [ 91, 98 ]
      }, {
        "text" : "3dprinting",
        "indices" : [ 99, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/e7H76NInXf",
        "expanded_url" : "http:\/\/ow.ly\/oesCz",
        "display_url" : "ow.ly\/oesCz"
      } ]
    },
    "geo" : { },
    "id_str" : "371302845351346176",
    "text" : "Meet the \"Genesis\": a 3D-printed car concept that assembles itself! http:\/\/t.co\/e7H76NInXf #design #3dprinting",
    "id" : 371302845351346176,
    "created_at" : "2013-08-24 16:07:51 +0000",
    "user" : {
      "name" : "inhabitat",
      "screen_name" : "inhabitat",
      "protected" : false,
      "id_str" : "14150661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/51865670\/OwliMcOwl_normal.jpg",
      "id" : 14150661,
      "verified" : false
    }
  },
  "id" : 371316377178488832,
  "created_at" : "2013-08-24 17:01:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "inhabitat",
      "screen_name" : "inhabitat",
      "indices" : [ 9, 19 ],
      "id_str" : "14150661",
      "id" : 14150661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371306662033752065",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859819888, -122.2753967165 ]
  },
  "id_str" : "371313589627281409",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves @inhabitat Woah that's amazing!",
  "id" : 371313589627281409,
  "in_reply_to_status_id" : 371306662033752065,
  "created_at" : "2013-08-24 16:50:33 +0000",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/vLMP98zCXP",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/08\/24\/world\/asia\/tom-christian-descendant-of-bounty-mutineer-dies-at-77.html?pagewanted=1&smid=tw-share",
      "display_url" : "nytimes.com\/2013\/08\/24\/wor\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596555278, -122.2755930114 ]
  },
  "id_str" : "371257442912329728",
  "text" : "\"The island\u2019s cliffs bear names redolent of long-ago tragedies: 'Where Dan Fall,' 'Where Minnie Off,' 'Oh Dear.'\" http:\/\/t.co\/vLMP98zCXP",
  "id" : 371257442912329728,
  "created_at" : "2013-08-24 13:07:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596656338, -122.2756977967 ]
  },
  "id_str" : "371140179420917760",
  "text" : "I don't have much hope for the antifragility of the term \"antifragility\".",
  "id" : 371140179420917760,
  "created_at" : "2013-08-24 05:21:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371120716566904833",
  "text" : "It's helping me to blame Netflix's Chaos Monkey for the fact that I'm sick.",
  "id" : 371120716566904833,
  "created_at" : "2013-08-24 04:04:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bodge",
      "screen_name" : "mikebodge",
      "indices" : [ 0, 10 ],
      "id_str" : "19344531",
      "id" : 19344531
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 11, 20 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371118966804324352",
  "geo" : { },
  "id_str" : "371119957766983681",
  "in_reply_to_user_id" : 19344531,
  "text" : "@mikebodge @arainert Come on, put it on! Join my virtual pretend turntable.fm.",
  "id" : 371119957766983681,
  "in_reply_to_status_id" : 371118966804324352,
  "created_at" : "2013-08-24 04:01:07 +0000",
  "in_reply_to_screen_name" : "mikebodge",
  "in_reply_to_user_id_str" : "19344531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371116489086345216",
  "geo" : { },
  "id_str" : "371117332325601281",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Oh yeah. I play it cool now but I was *WAY* into them back then. I still love the album, though am rarely in the mood for it.",
  "id" : 371117332325601281,
  "in_reply_to_status_id" : 371116489086345216,
  "created_at" : "2013-08-24 03:50:41 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/z86pR0jgxz",
      "expanded_url" : "http:\/\/flic.kr\/p\/fADBNw",
      "display_url" : "flic.kr\/p\/fADBNw"
    } ]
  },
  "geo" : { },
  "id_str" : "371115164625416192",
  "text" : "8:36pm Listening to silly old stuff and journaling like it's 1996 http:\/\/t.co\/z86pR0jgxz",
  "id" : 371115164625416192,
  "created_at" : "2013-08-24 03:42:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik D. Kennedy",
      "screen_name" : "erikdkennedy",
      "indices" : [ 0, 13 ],
      "id_str" : "15192767",
      "id" : 15192767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371112129408946176",
  "geo" : { },
  "id_str" : "371113982842531840",
  "in_reply_to_user_id" : 15192767,
  "text" : "@erikdkennedy Sounds like a Miyazaki film.",
  "id" : 371113982842531840,
  "in_reply_to_status_id" : 371112129408946176,
  "created_at" : "2013-08-24 03:37:23 +0000",
  "in_reply_to_screen_name" : "erikdkennedy",
  "in_reply_to_user_id_str" : "15192767",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371085080342827009",
  "geo" : { },
  "id_str" : "371099120636661760",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne She's wrong! &lt;3 &lt;3 &lt;3",
  "id" : 371099120636661760,
  "in_reply_to_status_id" : 371085080342827009,
  "created_at" : "2013-08-24 02:38:19 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 3, 7 ],
      "id_str" : "14616067",
      "id" : 14616067
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 9, 16 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 17, 20 ],
      "id_str" : "22273667",
      "id" : 22273667
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 21, 28 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 29, 38 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ltm\/status\/371095605218508800\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/Y2Uig0Xqnz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSZlfJ8CAAAfJFs.jpg",
      "id_str" : "371095605222703104",
      "id" : 371095605222703104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSZlfJ8CAAAfJFs.jpg",
      "sizes" : [ {
        "h" : 1807,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1059,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1088
      } ],
      "display_url" : "pic.twitter.com\/Y2Uig0Xqnz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371095816192020480",
  "text" : "RT @ltm: @buster @sm @sippey @anildash ;) http:\/\/t.co\/Y2Uig0Xqnz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      }, {
        "name" : "Sara Mauskopf",
        "screen_name" : "sm",
        "indices" : [ 8, 11 ],
        "id_str" : "22273667",
        "id" : 22273667
      }, {
        "name" : "Michael Sippey",
        "screen_name" : "sippey",
        "indices" : [ 12, 19 ],
        "id_str" : "4711",
        "id" : 4711
      }, {
        "name" : "Anil Dash",
        "screen_name" : "anildash",
        "indices" : [ 20, 29 ],
        "id_str" : "36823",
        "id" : 36823
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ltm\/status\/371095605218508800\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/Y2Uig0Xqnz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSZlfJ8CAAAfJFs.jpg",
        "id_str" : "371095605222703104",
        "id" : 371095605222703104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSZlfJ8CAAAfJFs.jpg",
        "sizes" : [ {
          "h" : 1807,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1059,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1920,
          "resize" : "fit",
          "w" : 1088
        } ],
        "display_url" : "pic.twitter.com\/Y2Uig0Xqnz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "371095360162123776",
    "geo" : { },
    "id_str" : "371095605218508800",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster @sm @sippey @anildash ;) http:\/\/t.co\/Y2Uig0Xqnz",
    "id" : 371095605218508800,
    "in_reply_to_status_id" : 371095360162123776,
    "created_at" : "2013-08-24 02:24:21 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "protected" : false,
      "id_str" : "14616067",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000327820941\/98a12d185ff6963b8dc1c97e9a70b3d6_normal.jpeg",
      "id" : 14616067,
      "verified" : false
    }
  },
  "id" : 371095816192020480,
  "created_at" : "2013-08-24 02:25:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 80, 83 ],
      "id_str" : "22273667",
      "id" : 22273667
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 84, 91 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 92, 96 ],
      "id_str" : "14616067",
      "id" : 14616067
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 97, 106 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371095360162123776",
  "text" : "Weekend photo project: reenact all the emoji. PS. How many emoji are there? \/cc @sm @sippey @ltm @anildash",
  "id" : 371095360162123776,
  "created_at" : "2013-08-24 02:23:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 5, 12 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 13, 16 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/371093518548094976\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/aEgWENVsR0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSZjlsfCUAE1EDQ.jpg",
      "id_str" : "371093518552289281",
      "id" : 371093518552289281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSZjlsfCUAE1EDQ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/aEgWENVsR0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371092481053442048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596951114, -122.2755213083 ]
  },
  "id_str" : "371093518548094976",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm @sippey @sm http:\/\/t.co\/aEgWENVsR0",
  "id" : 371093518548094976,
  "in_reply_to_status_id" : 371092481053442048,
  "created_at" : "2013-08-24 02:16:04 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Teague",
      "screen_name" : "ErinTeague",
      "indices" : [ 0, 11 ],
      "id_str" : "116299414",
      "id" : 116299414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371014136940879873",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596951114, -122.2755213083 ]
  },
  "id_str" : "371092563609935872",
  "in_reply_to_user_id" : 116299414,
  "text" : "@ErinTeague Congrats!",
  "id" : 371092563609935872,
  "in_reply_to_status_id" : 371014136940879873,
  "created_at" : "2013-08-24 02:12:16 +0000",
  "in_reply_to_screen_name" : "ErinTeague",
  "in_reply_to_user_id_str" : "116299414",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 8, 11 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371091179636805632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597119689, -122.2758256196 ]
  },
  "id_str" : "371091914407161856",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey @sm Is this some kinda snapchat fail?",
  "id" : 371091914407161856,
  "in_reply_to_status_id" : 371091179636805632,
  "created_at" : "2013-08-24 02:09:41 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596997215, -122.2755203025 ]
  },
  "id_str" : "371091377754370048",
  "text" : "I'm sick and Kellianne and Niko are out of town for the weekend. Audiobooks, better be afraid.",
  "id" : 371091377754370048,
  "created_at" : "2013-08-24 02:07:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Havrilesky",
      "screen_name" : "hhavrilesky",
      "indices" : [ 3, 15 ],
      "id_str" : "48428463",
      "id" : 48428463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371081652782379009",
  "text" : "RT @hhavrilesky: 10 Proven Facts That Probably Won't Improve Your Mood On A Friday Afternoon (SPOILERS!!): 1. You're going to die eventuall\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "371057452462006272",
    "text" : "10 Proven Facts That Probably Won't Improve Your Mood On A Friday Afternoon (SPOILERS!!): 1. You're going to die eventually.",
    "id" : 371057452462006272,
    "created_at" : "2013-08-23 23:52:45 +0000",
    "user" : {
      "name" : "Heather Havrilesky",
      "screen_name" : "hhavrilesky",
      "protected" : false,
      "id_str" : "48428463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461182133218721794\/pxScLHp__normal.jpeg",
      "id" : 48428463,
      "verified" : false
    }
  },
  "id" : 371081652782379009,
  "created_at" : "2013-08-24 01:28:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 0, 9 ],
      "id_str" : "2391",
      "id" : 2391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371069960329498624",
  "geo" : { },
  "id_str" : "371081495374344193",
  "in_reply_to_user_id" : 2391,
  "text" : "@mulegirl He was so bored he apparently couldn't be bothered.",
  "id" : 371081495374344193,
  "in_reply_to_status_id" : 371069960329498624,
  "created_at" : "2013-08-24 01:28:17 +0000",
  "in_reply_to_screen_name" : "mulegirl",
  "in_reply_to_user_id_str" : "2391",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chirpify",
      "screen_name" : "Chirpify",
      "indices" : [ 0, 9 ],
      "id_str" : "526548703",
      "id" : 526548703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/LmdMGDSVxF",
      "expanded_url" : "http:\/\/wayoftheduck.com\/1-for-you",
      "display_url" : "wayoftheduck.com\/1-for-you"
    } ]
  },
  "in_reply_to_status_id_str" : "371043935612702720",
  "geo" : { },
  "id_str" : "371044131893547008",
  "in_reply_to_user_id" : 526548703,
  "text" : "@Chirpify Email: busterbenson@gmail.com. Here's my first chirpify experiment: http:\/\/t.co\/LmdMGDSVxF",
  "id" : 371044131893547008,
  "in_reply_to_status_id" : 371043935612702720,
  "created_at" : "2013-08-23 22:59:49 +0000",
  "in_reply_to_screen_name" : "Chirpify",
  "in_reply_to_user_id_str" : "526548703",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chirpify",
      "screen_name" : "Chirpify",
      "indices" : [ 0, 9 ],
      "id_str" : "526548703",
      "id" : 526548703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371038690094493696",
  "geo" : { },
  "id_str" : "371039087517388800",
  "in_reply_to_user_id" : 526548703,
  "text" : "@Chirpify I have a fun couple ideas to use Actiontags\u2026 is that something anyone can sign up for or does it cost money?",
  "id" : 371039087517388800,
  "in_reply_to_status_id" : 371038690094493696,
  "created_at" : "2013-08-23 22:39:46 +0000",
  "in_reply_to_screen_name" : "Chirpify",
  "in_reply_to_user_id_str" : "526548703",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chirpify",
      "screen_name" : "Chirpify",
      "indices" : [ 20, 29 ],
      "id_str" : "526548703",
      "id" : 526548703
    }, {
      "name" : "Stand Up To Cancer",
      "screen_name" : "SU2C",
      "indices" : [ 33, 38 ],
      "id_str" : "15245706",
      "id" : 15245706
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoGood",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371036572117786624",
  "text" : "I'm donating $1 via @chirpify to @SU2C to help fight cancer. You can too, just RT this! #DoGood",
  "id" : 371036572117786624,
  "created_at" : "2013-08-23 22:29:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle",
      "screen_name" : "FormaLiving",
      "indices" : [ 0, 12 ],
      "id_str" : "85396641",
      "id" : 85396641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371033044557127680",
  "in_reply_to_user_id" : 85396641,
  "text" : "@FormaLiving You really need to change your Twitter password. :)",
  "id" : 371033044557127680,
  "created_at" : "2013-08-23 22:15:45 +0000",
  "in_reply_to_screen_name" : "FormaLiving",
  "in_reply_to_user_id_str" : "85396641",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371020474588733440",
  "geo" : { },
  "id_str" : "371022756764057601",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves And a solar powered bitcoin miner to buy TaskRabbits to assemble babies.",
  "id" : 371022756764057601,
  "in_reply_to_status_id" : 371020474588733440,
  "created_at" : "2013-08-23 21:34:53 +0000",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371020078222802944",
  "geo" : { },
  "id_str" : "371021057177554944",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie Should I call it the Disrupter's Dilemma or Innovation 3.0?",
  "id" : 371021057177554944,
  "in_reply_to_status_id" : 371020078222802944,
  "created_at" : "2013-08-23 21:28:07 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371015281818087424",
  "text" : "Self-driving Tesla Ubers that can 3D print parts to repair themselves.",
  "id" : 371015281818087424,
  "created_at" : "2013-08-23 21:05:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.crowdbooster.com\" rel=\"nofollow\"\u003ECrowdbooster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Albritton",
      "screen_name" : "albrittongreg",
      "indices" : [ 0, 14 ],
      "id_str" : "367732797",
      "id" : 367732797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370985206393880576",
  "in_reply_to_user_id" : 367732797,
  "text" : "@albrittongreg Looks cool! I'll take a look.",
  "id" : 370985206393880576,
  "created_at" : "2013-08-23 19:05:40 +0000",
  "in_reply_to_screen_name" : "albrittongreg",
  "in_reply_to_user_id_str" : "367732797",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 66, 73 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bezoslayer",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/4MMNyGC6kS",
      "expanded_url" : "https:\/\/medium.com\/fords-sensorium\/6e9e1a7578d1",
      "display_url" : "medium.com\/fords-sensoriu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370949777891938304",
  "text" : "Pure word and thought deliciousness: \u201CHedgefox Buys Metayacht\u201D by @ftrain https:\/\/t.co\/4MMNyGC6kS #bezoslayer",
  "id" : 370949777891938304,
  "created_at" : "2013-08-23 16:44:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thinking",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370934840004059136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8016060166, -122.2841925722 ]
  },
  "id_str" : "370941158903394304",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey That makes me want to think about Pollyanna too. #thinking",
  "id" : 370941158903394304,
  "in_reply_to_status_id" : 370934840004059136,
  "created_at" : "2013-08-23 16:10:38 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Kinnish",
      "screen_name" : "neiltak",
      "indices" : [ 3, 11 ],
      "id_str" : "18799825",
      "id" : 18799825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/4s0jl3tPVY",
      "expanded_url" : "http:\/\/neilkinnish.com\/article\/introducing-pop",
      "display_url" : "neilkinnish.com\/article\/introd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370922451007315970",
  "text" : "RT @neiltak: Introducing POP http:\/\/t.co\/4s0jl3tPVY a tiny mac app",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/4s0jl3tPVY",
        "expanded_url" : "http:\/\/neilkinnish.com\/article\/introducing-pop",
        "display_url" : "neilkinnish.com\/article\/introd\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "370903478056796160",
    "text" : "Introducing POP http:\/\/t.co\/4s0jl3tPVY a tiny mac app",
    "id" : 370903478056796160,
    "created_at" : "2013-08-23 13:40:54 +0000",
    "user" : {
      "name" : "Neil Kinnish",
      "screen_name" : "neiltak",
      "protected" : false,
      "id_str" : "18799825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462865515757969408\/VkTx7hOF_normal.jpeg",
      "id" : 18799825,
      "verified" : false
    }
  },
  "id" : 370922451007315970,
  "created_at" : "2013-08-23 14:56:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Clay Johnson",
      "screen_name" : "cjoh",
      "indices" : [ 10, 15 ],
      "id_str" : "3364",
      "id" : 3364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370914379690422272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859682352, -122.275521063 ]
  },
  "id_str" : "370921830866898945",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @cjoh Okay now that's a stretch. Ballmer's cockiness that they'd already won every market was a much bigger factor than coolness.",
  "id" : 370921830866898945,
  "in_reply_to_status_id" : 370914379690422272,
  "created_at" : "2013-08-23 14:53:50 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Neves",
      "screen_name" : "TheAntonioNeves",
      "indices" : [ 0, 16 ],
      "id_str" : "20932488",
      "id" : 20932488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370764186034249728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597101329, -122.2753344038 ]
  },
  "id_str" : "370766306141687808",
  "in_reply_to_user_id" : 20932488,
  "text" : "@TheAntonioNeves Sadly the latter. :(",
  "id" : 370766306141687808,
  "in_reply_to_status_id" : 370764186034249728,
  "created_at" : "2013-08-23 04:35:50 +0000",
  "in_reply_to_screen_name" : "TheAntonioNeves",
  "in_reply_to_user_id_str" : "20932488",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sick",
      "indices" : [ 21, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596475599, -122.2754277277 ]
  },
  "id_str" : "370762962123755520",
  "text" : "Today's nap count: 3 #sick",
  "id" : 370762962123755520,
  "created_at" : "2013-08-23 04:22:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/wNYMEUe0kc",
      "expanded_url" : "http:\/\/flic.kr\/p\/fA7fQj",
      "display_url" : "flic.kr\/p\/fA7fQj"
    } ]
  },
  "geo" : { },
  "id_str" : "370751835293745152",
  "text" : "8:36pm Solo dude dinner http:\/\/t.co\/wNYMEUe0kc",
  "id" : 370751835293745152,
  "created_at" : "2013-08-23 03:38:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tomasz Tunguz",
      "screen_name" : "ttunguz",
      "indices" : [ 0, 8 ],
      "id_str" : "10069172",
      "id" : 10069172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370680068923588608",
  "geo" : { },
  "id_str" : "370680618104795136",
  "in_reply_to_user_id" : 10069172,
  "text" : "@ttunguz I totally agree, but it doesn't prove that the product won't fail.",
  "id" : 370680618104795136,
  "in_reply_to_status_id" : 370680068923588608,
  "created_at" : "2013-08-22 22:55:20 +0000",
  "in_reply_to_screen_name" : "ttunguz",
  "in_reply_to_user_id_str" : "10069172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark S. Luckie  \u261C",
      "screen_name" : "marksluckie",
      "indices" : [ 3, 15 ],
      "id_str" : "27261369",
      "id" : 27261369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/HMsRyxSctV",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Black_Twitter",
      "display_url" : "en.wikipedia.org\/wiki\/Black_Twi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370654018504097793",
  "text" : "RT @marksluckie: This \"Black Twitter\" Wikipedia page is a lot more detailed and well worth the read than I imagined it would be http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/HMsRyxSctV",
        "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Black_Twitter",
        "display_url" : "en.wikipedia.org\/wiki\/Black_Twi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "370651706683424768",
    "text" : "This \"Black Twitter\" Wikipedia page is a lot more detailed and well worth the read than I imagined it would be http:\/\/t.co\/HMsRyxSctV",
    "id" : 370651706683424768,
    "created_at" : "2013-08-22 21:00:27 +0000",
    "user" : {
      "name" : "Mark S. Luckie  \u261C",
      "screen_name" : "marksluckie",
      "protected" : false,
      "id_str" : "27261369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463694468370423808\/Ap3nH-he_normal.jpeg",
      "id" : 27261369,
      "verified" : false
    }
  },
  "id" : 370654018504097793,
  "created_at" : "2013-08-22 21:09:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370615725691387904",
  "geo" : { },
  "id_str" : "370636717125943296",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel OMG. Can't believe you didn't just wait another year to celebrate the big 2-0.",
  "id" : 370636717125943296,
  "in_reply_to_status_id" : 370615725691387904,
  "created_at" : "2013-08-22 20:00:54 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tomasz Tunguz",
      "screen_name" : "ttunguz",
      "indices" : [ 0, 8 ],
      "id_str" : "10069172",
      "id" : 10069172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370597543526141952",
  "in_reply_to_user_id" : 10069172,
  "text" : "@ttunguz How would a founder disprove a null hypothesis in 1-3 weeks without building anything? Product\/market fit needs a product.",
  "id" : 370597543526141952,
  "created_at" : "2013-08-22 17:25:14 +0000",
  "in_reply_to_screen_name" : "ttunguz",
  "in_reply_to_user_id_str" : "10069172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 14, 23 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Offbeat Bride",
      "screen_name" : "offbeatbride",
      "indices" : [ 24, 37 ],
      "id_str" : "35900211",
      "id" : 35900211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370570525149384705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596855388, -122.2754486103 ]
  },
  "id_str" : "370571654734155776",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel @RickWebb @offbeatbride Totally! Rick, can Ariel write about it???",
  "id" : 370571654734155776,
  "in_reply_to_status_id" : 370570525149384705,
  "created_at" : "2013-08-22 15:42:22 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen X. Cheng",
      "screen_name" : "karenxcheng",
      "indices" : [ 21, 33 ],
      "id_str" : "21829724",
      "id" : 21829724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/adXdTgwyCR",
      "expanded_url" : "http:\/\/danceinayear.com\/story",
      "display_url" : "danceinayear.com\/story"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596111823, -122.2754421557 ]
  },
  "id_str" : "370570982982823936",
  "text" : "Inspiring story from @karenxcheng  http:\/\/t.co\/adXdTgwyCR",
  "id" : 370570982982823936,
  "created_at" : "2013-08-22 15:39:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Anderson",
      "screen_name" : "stephenanderson",
      "indices" : [ 0, 16 ],
      "id_str" : "356663",
      "id" : 356663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370563489858736128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596990609, -122.2755793296 ]
  },
  "id_str" : "370569326647992320",
  "in_reply_to_user_id" : 356663,
  "text" : "@stephenanderson Nice work!",
  "id" : 370569326647992320,
  "in_reply_to_status_id" : 370563489858736128,
  "created_at" : "2013-08-22 15:33:06 +0000",
  "in_reply_to_screen_name" : "stephenanderson",
  "in_reply_to_user_id_str" : "356663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/oPy6VCQs2W",
      "expanded_url" : "http:\/\/flic.kr\/p\/fzhbaH",
      "display_url" : "flic.kr\/p\/fzhbaH"
    } ]
  },
  "geo" : { },
  "id_str" : "370393130945622016",
  "text" : "8:36pm BARTin' home http:\/\/t.co\/oPy6VCQs2W",
  "id" : 370393130945622016,
  "created_at" : "2013-08-22 03:52:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Aberg-Riger",
      "screen_name" : "Figure1",
      "indices" : [ 0, 8 ],
      "id_str" : "13788172",
      "id" : 13788172
    }, {
      "name" : "Tapestry",
      "screen_name" : "tapestry",
      "indices" : [ 9, 18 ],
      "id_str" : "2533401",
      "id" : 2533401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370366824220590080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7792100018, -122.4142689704 ]
  },
  "id_str" : "370388052134223872",
  "in_reply_to_user_id" : 13788172,
  "text" : "@Figure1 @tapestry Feel free to use it in the sequel.",
  "id" : 370388052134223872,
  "in_reply_to_status_id" : 370366824220590080,
  "created_at" : "2013-08-22 03:32:47 +0000",
  "in_reply_to_screen_name" : "Figure1",
  "in_reply_to_user_id_str" : "13788172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 3, 9 ],
      "id_str" : "75079616",
      "id" : 75079616
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 24, 32 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/oSa67nYurv",
      "expanded_url" : "http:\/\/updates.ifttt.com\/post\/58926583106\/twitter-triggers-are-back",
      "display_url" : "updates.ifttt.com\/post\/589265831\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370369323392442369",
  "text" : "RT @IFTTT: Welcome back @Twitter Triggers. http:\/\/t.co\/oSa67nYurv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 13, 21 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/oSa67nYurv",
        "expanded_url" : "http:\/\/updates.ifttt.com\/post\/58926583106\/twitter-triggers-are-back",
        "display_url" : "updates.ifttt.com\/post\/589265831\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "370231031716007937",
    "text" : "Welcome back @Twitter Triggers. http:\/\/t.co\/oSa67nYurv",
    "id" : 370231031716007937,
    "created_at" : "2013-08-21 17:08:51 +0000",
    "user" : {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "protected" : false,
      "id_str" : "75079616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459090900874833920\/TIT71OZq_normal.png",
      "id" : 75079616,
      "verified" : false
    }
  },
  "id" : 370369323392442369,
  "created_at" : "2013-08-22 02:18:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Aberg-Riger",
      "screen_name" : "Figure1",
      "indices" : [ 3, 11 ],
      "id_str" : "13788172",
      "id" : 13788172
    }, {
      "name" : "Tapestry",
      "screen_name" : "tapestry",
      "indices" : [ 55, 64 ],
      "id_str" : "2533401",
      "id" : 2533401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/8ua12V9MeH",
      "expanded_url" : "https:\/\/readtapestry.com\/s\/QaybGQG2K\/",
      "display_url" : "readtapestry.com\/s\/QaybGQG2K\/"
    } ]
  },
  "geo" : { },
  "id_str" : "370367134611673088",
  "text" : "RT @Figure1: WOO. THIS IS WHERE IT'S AT is featured on @tapestry. If my first tweet wasn't enough to make you read MAYBE THIS IS. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tapestry",
        "screen_name" : "tapestry",
        "indices" : [ 42, 51 ],
        "id_str" : "2533401",
        "id" : 2533401
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/8ua12V9MeH",
        "expanded_url" : "https:\/\/readtapestry.com\/s\/QaybGQG2K\/",
        "display_url" : "readtapestry.com\/s\/QaybGQG2K\/"
      } ]
    },
    "geo" : { },
    "id_str" : "370314171444772864",
    "text" : "WOO. THIS IS WHERE IT'S AT is featured on @tapestry. If my first tweet wasn't enough to make you read MAYBE THIS IS. https:\/\/t.co\/8ua12V9MeH",
    "id" : 370314171444772864,
    "created_at" : "2013-08-21 22:39:13 +0000",
    "user" : {
      "name" : "Ariel Aberg-Riger",
      "screen_name" : "Figure1",
      "protected" : false,
      "id_str" : "13788172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000056507141\/add2a1656b25a04a838509c4277e31e9_normal.jpeg",
      "id" : 13788172,
      "verified" : false
    }
  },
  "id" : 370367134611673088,
  "created_at" : "2013-08-22 02:09:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Aberg-Riger",
      "screen_name" : "Figure1",
      "indices" : [ 0, 8 ],
      "id_str" : "13788172",
      "id" : 13788172
    }, {
      "name" : "Tapestry",
      "screen_name" : "tapestry",
      "indices" : [ 9, 18 ],
      "id_str" : "2533401",
      "id" : 2533401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370314171444772864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7750554114, -122.4100169528 ]
  },
  "id_str" : "370366273298763776",
  "in_reply_to_user_id" : 13788172,
  "text" : "@Figure1 @tapestry Amazing. @ @ @",
  "id" : 370366273298763776,
  "in_reply_to_status_id" : 370314171444772864,
  "created_at" : "2013-08-22 02:06:15 +0000",
  "in_reply_to_screen_name" : "Figure1",
  "in_reply_to_user_id_str" : "13788172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THE Lance Arthur",
      "screen_name" : "thelancearthur",
      "indices" : [ 3, 18 ],
      "id_str" : "143569237",
      "id" : 143569237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/kZskmmNxwH",
      "expanded_url" : "http:\/\/www.nytimes.com\/interactive\/science\/space\/keplers-tally-of-planets.html?_r=0",
      "display_url" : "nytimes.com\/interactive\/sc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370282119043358720",
  "text" : "RT @thelancearthur: Dataviz splooge: http:\/\/t.co\/kZskmmNxwH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/kZskmmNxwH",
        "expanded_url" : "http:\/\/www.nytimes.com\/interactive\/science\/space\/keplers-tally-of-planets.html?_r=0",
        "display_url" : "nytimes.com\/interactive\/sc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "370277780342063105",
    "text" : "Dataviz splooge: http:\/\/t.co\/kZskmmNxwH",
    "id" : 370277780342063105,
    "created_at" : "2013-08-21 20:14:36 +0000",
    "user" : {
      "name" : "THE Lance Arthur",
      "screen_name" : "thelancearthur",
      "protected" : false,
      "id_str" : "143569237",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459362564976046080\/F4SMuyHK_normal.png",
      "id" : 143569237,
      "verified" : false
    }
  },
  "id" : 370282119043358720,
  "created_at" : "2013-08-21 20:31:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Stewart",
      "screen_name" : "SirPatStew",
      "indices" : [ 9, 20 ],
      "id_str" : "602317143",
      "id" : 602317143
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/370265223703564288\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/nAsfYNdJLO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSNyQlCIIAAF6Nf.jpg",
      "id_str" : "370265223519019008",
      "id" : 370265223519019008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSNyQlCIIAAF6Nf.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/nAsfYNdJLO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764223742, -122.4168414138 ]
  },
  "id_str" : "370265223703564288",
  "text" : "Hey it's @SirPatStew in our lunch room. He says he loves living in Berkeley. http:\/\/t.co\/nAsfYNdJLO",
  "id" : 370265223703564288,
  "created_at" : "2013-08-21 19:24:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370018334018138112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.828778294, -122.2666919791 ]
  },
  "id_str" : "370090487467614209",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb I faved about 3.8 thousand of them. So good!",
  "id" : 370090487467614209,
  "in_reply_to_status_id" : 370018334018138112,
  "created_at" : "2013-08-21 07:50:22 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/QKStUghSDf",
      "expanded_url" : "http:\/\/flic.kr\/p\/fySW5h",
      "display_url" : "flic.kr\/p\/fySW5h"
    } ]
  },
  "geo" : { },
  "id_str" : "370034757683269632",
  "text" : "8:36pm Drinks with Jacob, Laurie, and their friends http:\/\/t.co\/QKStUghSDf",
  "id" : 370034757683269632,
  "created_at" : "2013-08-21 04:08:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Lax",
      "screen_name" : "jlax",
      "indices" : [ 3, 8 ],
      "id_str" : "11735032",
      "id" : 11735032
    }, {
      "name" : "Potluck",
      "screen_name" : "potluck",
      "indices" : [ 15, 23 ],
      "id_str" : "1395445934",
      "id" : 1395445934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/ksmoDoux9u",
      "expanded_url" : "https:\/\/www.potluck.it\/rooms\/540928d7",
      "display_url" : "potluck.it\/rooms\/540928d7"
    } ]
  },
  "geo" : { },
  "id_str" : "369851911542812672",
  "text" : "RT @jlax: This @potluck on Webrings is the greatest thing you will read today https:\/\/t.co\/ksmoDoux9u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Potluck",
        "screen_name" : "potluck",
        "indices" : [ 5, 13 ],
        "id_str" : "1395445934",
        "id" : 1395445934
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/ksmoDoux9u",
        "expanded_url" : "https:\/\/www.potluck.it\/rooms\/540928d7",
        "display_url" : "potluck.it\/rooms\/540928d7"
      } ]
    },
    "geo" : { },
    "id_str" : "369832773835440129",
    "text" : "This @potluck on Webrings is the greatest thing you will read today https:\/\/t.co\/ksmoDoux9u",
    "id" : 369832773835440129,
    "created_at" : "2013-08-20 14:46:19 +0000",
    "user" : {
      "name" : "Jon Lax",
      "screen_name" : "jlax",
      "protected" : false,
      "id_str" : "11735032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1148796114\/Picture_3_normal.png",
      "id" : 11735032,
      "verified" : false
    }
  },
  "id" : 369851911542812672,
  "created_at" : "2013-08-20 16:02:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Doll",
      "screen_name" : "thisisjendoll",
      "indices" : [ 3, 17 ],
      "id_str" : "46442771",
      "id" : 46442771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/S4Ncvd5m2r",
      "expanded_url" : "http:\/\/www.theguardian.com\/books\/2010\/feb\/20\/ten-rules-for-writing-fiction-part-one",
      "display_url" : "theguardian.com\/books\/2010\/feb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369825994183438337",
  "text" : "RT @thisisjendoll: \"You are allowed no more than two or three [exclamation points] per 100,000 words of prose.\" \u2014 Elmore Leonard http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/S4Ncvd5m2r",
        "expanded_url" : "http:\/\/www.theguardian.com\/books\/2010\/feb\/20\/ten-rules-for-writing-fiction-part-one",
        "display_url" : "theguardian.com\/books\/2010\/feb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369823578017267712",
    "text" : "\"You are allowed no more than two or three [exclamation points] per 100,000 words of prose.\" \u2014 Elmore Leonard http:\/\/t.co\/S4Ncvd5m2r",
    "id" : 369823578017267712,
    "created_at" : "2013-08-20 14:09:46 +0000",
    "user" : {
      "name" : "Jen Doll",
      "screen_name" : "thisisjendoll",
      "protected" : false,
      "id_str" : "46442771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000261702350\/e92bbcf3eb5f76340c302162567477a6_normal.jpeg",
      "id" : 46442771,
      "verified" : false
    }
  },
  "id" : 369825994183438337,
  "created_at" : "2013-08-20 14:19:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 3, 14 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/hTXwqo3m4m",
      "expanded_url" : "http:\/\/rt.com\/news\/guardian-hard-drives-destroyed-697\/",
      "display_url" : "rt.com\/news\/guardian-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369825360470216704",
  "text" : "RT @waxpancake: Dark days for press freedom. UK govt raids the Guardian, forces destruction of their hard drives while they watch. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/hTXwqo3m4m",
        "expanded_url" : "http:\/\/rt.com\/news\/guardian-hard-drives-destroyed-697\/",
        "display_url" : "rt.com\/news\/guardian-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369823252752789505",
    "text" : "Dark days for press freedom. UK govt raids the Guardian, forces destruction of their hard drives while they watch. http:\/\/t.co\/hTXwqo3m4m",
    "id" : 369823252752789505,
    "created_at" : "2013-08-20 14:08:29 +0000",
    "user" : {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "protected" : false,
      "id_str" : "13461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416642320574844928\/Gz7V2B6r_normal.jpeg",
      "id" : 13461,
      "verified" : false
    }
  },
  "id" : 369825360470216704,
  "created_at" : "2013-08-20 14:16:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369676944075677696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6208525291, -122.3829537538 ]
  },
  "id_str" : "369683537999298560",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Ah yeah. We feel the same way! Next time!",
  "id" : 369683537999298560,
  "in_reply_to_status_id" : 369676944075677696,
  "created_at" : "2013-08-20 04:53:18 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369676944075677696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6208525291, -122.3829537538 ]
  },
  "id_str" : "369681031260954624",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc I TOLD YOU! :)",
  "id" : 369681031260954624,
  "in_reply_to_status_id" : 369676944075677696,
  "created_at" : "2013-08-20 04:43:20 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369668316497190912",
  "geo" : { },
  "id_str" : "369676602386313216",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Awesome that you went! Did you get there early and stay late?",
  "id" : 369676602386313216,
  "in_reply_to_status_id" : 369668316497190912,
  "created_at" : "2013-08-20 04:25:44 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 8, 20 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/XPfoMDh8zT",
      "expanded_url" : "https:\/\/medium.com\/health-the-future\/918b3d08f21f",
      "display_url" : "medium.com\/health-the-fut\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "369659750041927680",
  "geo" : { },
  "id_str" : "369662903953006593",
  "in_reply_to_user_id" : 30801469,
  "text" : "Yup. RT @nickcrocker: The World Is Fucking Insane: https:\/\/t.co\/XPfoMDh8zT",
  "id" : 369662903953006593,
  "in_reply_to_status_id" : 369659750041927680,
  "created_at" : "2013-08-20 03:31:18 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/hxoBBNpWLn",
      "expanded_url" : "http:\/\/flic.kr\/p\/fy8jSL",
      "display_url" : "flic.kr\/p\/fy8jSL"
    } ]
  },
  "geo" : { },
  "id_str" : "369653556279660544",
  "text" : "8:36pm Was watching a movie about terrible people. Missing my family already.  http:\/\/t.co\/hxoBBNpWLn",
  "id" : 369653556279660544,
  "created_at" : "2013-08-20 02:54:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter API",
      "screen_name" : "twitterapi",
      "indices" : [ 20, 31 ],
      "id_str" : "6253282",
      "id" : 6253282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/ZEfwoxZaaj",
      "expanded_url" : "https:\/\/dev.twitter.com\/blog\/headlines-tell-story-behind-tweet",
      "display_url" : "dev.twitter.com\/blog\/headlines\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "369507257500712960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7626642572, -75.5081135957 ]
  },
  "id_str" : "369524916162265088",
  "in_reply_to_user_id" : 6253282,
  "text" : "Rad new feature. RT @twitterapi: Introducing Twitter Headlines for Embedded Tweets: https:\/\/t.co\/ZEfwoxZaaj",
  "id" : 369524916162265088,
  "in_reply_to_status_id" : 369507257500712960,
  "created_at" : "2013-08-19 18:23:00 +0000",
  "in_reply_to_screen_name" : "twitterapi",
  "in_reply_to_user_id_str" : "6253282",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/c2v8lne1NQ",
      "expanded_url" : "http:\/\/blog.twitter.com\/2013\/new-tweets-per-second-record-and-how",
      "display_url" : "blog.twitter.com\/2013\/new-tweet\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369420054103748608",
  "text" : "\"New tweets per second (TPS) record: 143,199 TPS. Typical day: more than 500 million Tweets sent; average 5,700 TPS.\" http:\/\/t.co\/c2v8lne1NQ",
  "id" : 369420054103748608,
  "created_at" : "2013-08-19 11:26:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie Brownstein",
      "screen_name" : "Carrie_Rachel",
      "indices" : [ 3, 17 ],
      "id_str" : "56436152",
      "id" : 56436152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369419494441353216",
  "text" : "RT @Carrie_Rachel: Who hasn't, in the moment awaiting a toddler to meet your hand in a high-five, thought, 'my self-esteem depends on what \u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "368843312603480065",
    "text" : "Who hasn't, in the moment awaiting a toddler to meet your hand in a high-five, thought, 'my self-esteem depends on what happens next.'",
    "id" : 368843312603480065,
    "created_at" : "2013-08-17 21:14:33 +0000",
    "user" : {
      "name" : "Carrie Brownstein",
      "screen_name" : "Carrie_Rachel",
      "protected" : false,
      "id_str" : "56436152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466011199520243714\/-TIbugU4_normal.png",
      "id" : 56436152,
      "verified" : true
    }
  },
  "id" : 369419494441353216,
  "created_at" : "2013-08-19 11:24:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/lIiYggOvsB",
      "expanded_url" : "http:\/\/flic.kr\/p\/fx5utc",
      "display_url" : "flic.kr\/p\/fx5utc"
    } ]
  },
  "geo" : { },
  "id_str" : "369259815496724480",
  "text" : "8:36pm Happy to be back with this guy http:\/\/t.co\/lIiYggOvsB",
  "id" : 369259815496724480,
  "created_at" : "2013-08-19 00:49:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 3, 9 ],
      "id_str" : "5814",
      "id" : 5814
    }, {
      "name" : "Trevor Paglen",
      "screen_name" : "trevorpaglen",
      "indices" : [ 99, 112 ],
      "id_str" : "176906206",
      "id" : 176906206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bbingenuity",
      "indices" : [ 113, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369213633664122880",
  "text" : "RT @tempo: \"The rings of earth aren't made of dust or ice (like other planets), but of machines.\" -@trevorpaglen #bbingenuity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Trevor Paglen",
        "screen_name" : "trevorpaglen",
        "indices" : [ 88, 101 ],
        "id_str" : "176906206",
        "id" : 176906206
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bbingenuity",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "369208765746126848",
    "text" : "\"The rings of earth aren't made of dust or ice (like other planets), but of machines.\" -@trevorpaglen #bbingenuity",
    "id" : 369208765746126848,
    "created_at" : "2013-08-18 21:26:43 +0000",
    "user" : {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "protected" : false,
      "id_str" : "5814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1809986362\/265877_10150230867513403_512098402_7439693_1811499_o_normal.jpg",
      "id" : 5814,
      "verified" : false
    }
  },
  "id" : 369213633664122880,
  "created_at" : "2013-08-18 21:46:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "amanda kelso",
      "screen_name" : "mandydale",
      "indices" : [ 0, 10 ],
      "id_str" : "5526",
      "id" : 5526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369204715235450881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.2883527289, -74.5010727179 ]
  },
  "id_str" : "369206140778721280",
  "in_reply_to_user_id" : 5526,
  "text" : "@mandydale So good to see you and Cameron! Let's go to that ramen place soon!",
  "id" : 369206140778721280,
  "in_reply_to_status_id" : 369204715235450881,
  "created_at" : "2013-08-18 21:16:18 +0000",
  "in_reply_to_screen_name" : "mandydale",
  "in_reply_to_user_id_str" : "5526",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 57, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/JesW08IGRS",
      "expanded_url" : "http:\/\/flic.kr\/p\/fwXGRD",
      "display_url" : "flic.kr\/p\/fwXGRD"
    } ]
  },
  "geo" : { },
  "id_str" : "369205795977584641",
  "text" : "THAT WAS AWESOME. So great to see everyone and celebrate #webbles with you. http:\/\/t.co\/JesW08IGRS",
  "id" : 369205795977584641,
  "created_at" : "2013-08-18 21:14:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 20, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/2I1dpM2sFh",
      "expanded_url" : "https:\/\/vine.co\/v\/hOOHPOOFhMT",
      "display_url" : "vine.co\/v\/hOOHPOOFhMT"
    } ]
  },
  "geo" : { },
  "id_str" : "369004030195793920",
  "text" : "Dancing with Daleks #webbles https:\/\/t.co\/2I1dpM2sFh",
  "id" : 369004030195793920,
  "created_at" : "2013-08-18 07:53:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/pb3xHXiDbm",
      "expanded_url" : "https:\/\/vine.co\/v\/hOht5DXaQlZ",
      "display_url" : "vine.co\/v\/hOht5DXaQlZ"
    } ]
  },
  "geo" : { },
  "id_str" : "368942718065446912",
  "text" : "Rick singing #webbles https:\/\/t.co\/pb3xHXiDbm",
  "id" : 368942718065446912,
  "created_at" : "2013-08-18 03:49:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Rheingold",
      "screen_name" : "tedr",
      "indices" : [ 0, 5 ],
      "id_str" : "997",
      "id" : 997
    }, {
      "name" : "#Webbles",
      "screen_name" : "hashtagwebbles",
      "indices" : [ 6, 21 ],
      "id_str" : "1666662469",
      "id" : 1666662469
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 22, 31 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368940816737132547",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7192615348, -73.9617113563 ]
  },
  "id_str" : "368942164790628353",
  "in_reply_to_user_id" : 997,
  "text" : "@tedr @hashtagwebbles @RickWebb Hi Ted!",
  "id" : 368942164790628353,
  "in_reply_to_status_id" : 368940816737132547,
  "created_at" : "2013-08-18 03:47:21 +0000",
  "in_reply_to_screen_name" : "tedr",
  "in_reply_to_user_id_str" : "997",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/4Y6j5bZuAi",
      "expanded_url" : "https:\/\/vine.co\/v\/hOhjOdiQWPu",
      "display_url" : "vine.co\/v\/hOhjOdiQWPu"
    } ]
  },
  "geo" : { },
  "id_str" : "368940650961444864",
  "text" : "Rockets Burst From The Streetlamps Bitch https:\/\/t.co\/4Y6j5bZuAi",
  "id" : 368940650961444864,
  "created_at" : "2013-08-18 03:41:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Music Hall of WB",
      "screen_name" : "MusicHallofWB",
      "indices" : [ 50, 64 ],
      "id_str" : "20573003",
      "id" : 20573003
    }, {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 89, 94 ],
      "id_str" : "418",
      "id" : 418
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 95, 102 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 103, 107 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 9, 17 ]
    }, {
      "text" : "Webbles",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/74am8uUJ2W",
      "expanded_url" : "http:\/\/4sq.com\/17zq72K",
      "display_url" : "4sq.com\/17zq72K"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7192485474, -73.9617181343 ]
  },
  "id_str" : "368901040315195393",
  "text" : "Everyone #webbles (@ Music Hall of Williamsburg - @musichallofwb for #Webbles Wedding w\/ @dens @harryh @msg) http:\/\/t.co\/74am8uUJ2W",
  "id" : 368901040315195393,
  "created_at" : "2013-08-18 01:03:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368897530190245888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7192568994, -73.9617285971 ]
  },
  "id_str" : "368899170116964354",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler I'm on the east coast! Time is in our mind.",
  "id" : 368899170116964354,
  "in_reply_to_status_id" : 368897530190245888,
  "created_at" : "2013-08-18 00:56:30 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/Me2Aq5xnMk",
      "expanded_url" : "http:\/\/flic.kr\/p\/fwzou3",
      "display_url" : "flic.kr\/p\/fwzou3"
    } ]
  },
  "geo" : { },
  "id_str" : "368896512303960064",
  "text" : "8:36pm Feeling the love #webbles  http:\/\/t.co\/Me2Aq5xnMk",
  "id" : 368896512303960064,
  "created_at" : "2013-08-18 00:45:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 5, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/eA7UvBH6jj",
      "expanded_url" : "http:\/\/flic.kr\/p\/fwjffk",
      "display_url" : "flic.kr\/p\/fwjffk"
    } ]
  },
  "geo" : { },
  "id_str" : "368887510241255425",
  "text" : "Vows #webbles http:\/\/t.co\/eA7UvBH6jj",
  "id" : 368887510241255425,
  "created_at" : "2013-08-18 00:10:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "emma jane webb",
      "screen_name" : "emmarocks",
      "indices" : [ 11, 21 ],
      "id_str" : "766566",
      "id" : 766566
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 26, 35 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/lxmSbXvYHX",
      "expanded_url" : "http:\/\/flic.kr\/p\/fwjbmP",
      "display_url" : "flic.kr\/p\/fwjbmP"
    } ]
  },
  "geo" : { },
  "id_str" : "368886943888580608",
  "text" : "Looks like @emmarocks and @rickwebb put a ring on it #webbles  http:\/\/t.co\/lxmSbXvYHX",
  "id" : 368886943888580608,
  "created_at" : "2013-08-18 00:07:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Lafforgue",
      "screen_name" : "LaurenceLafforg",
      "indices" : [ 3, 19 ],
      "id_str" : "17636751",
      "id" : 17636751
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368877666264682496",
  "text" : "RT @LaurenceLafforg: let's make this # trend people #webbles",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "webbles",
        "indices" : [ 31, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "368876853072625664",
    "text" : "let's make this # trend people #webbles",
    "id" : 368876853072625664,
    "created_at" : "2013-08-17 23:27:49 +0000",
    "user" : {
      "name" : "Laurence Lafforgue",
      "screen_name" : "LaurenceLafforg",
      "protected" : false,
      "id_str" : "17636751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1111999306\/2010_07_31_Laurence-Profile-Picture_square__normal.png",
      "id" : 17636751,
      "verified" : false
    }
  },
  "id" : 368877666264682496,
  "created_at" : "2013-08-17 23:31:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/MNG54z0rWP",
      "expanded_url" : "https:\/\/vine.co\/v\/hOqt6OdvZJd",
      "display_url" : "vine.co\/v\/hOqt6OdvZJd"
    } ]
  },
  "geo" : { },
  "id_str" : "368876331347349504",
  "text" : "Wedding party walking to #webbles https:\/\/t.co\/MNG54z0rWP",
  "id" : 368876331347349504,
  "created_at" : "2013-08-17 23:25:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/368846704717467649\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/ROtqUTEqDA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BR5oH6uCEAEdGkZ.jpg",
      "id_str" : "368846704721661953",
      "id" : 368846704721661953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BR5oH6uCEAEdGkZ.jpg",
      "sizes" : [ {
        "h" : 291,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 171,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 97,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 291,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ROtqUTEqDA"
    } ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 12, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7205640152, -73.9612687659 ]
  },
  "id_str" : "368846704717467649",
  "text" : "On the roof #webbles http:\/\/t.co\/ROtqUTEqDA",
  "id" : 368846704717467649,
  "created_at" : "2013-08-17 21:28:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Webbles",
      "indices" : [ 3, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/rnVcovFnBu",
      "expanded_url" : "https:\/\/vine.co\/v\/hOAHTzebW1L",
      "display_url" : "vine.co\/v\/hOAHTzebW1L"
    } ]
  },
  "geo" : { },
  "id_str" : "368837807768236033",
  "text" : "Mr #Webbles is ready https:\/\/t.co\/rnVcovFnBu",
  "id" : 368837807768236033,
  "created_at" : "2013-08-17 20:52:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 18, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/CiK7DalEdp",
      "expanded_url" : "http:\/\/flic.kr\/p\/fwt8rb",
      "display_url" : "flic.kr\/p\/fwt8rb"
    } ]
  },
  "geo" : { },
  "id_str" : "368836552631132160",
  "text" : "Boutonnierring up #webbles http:\/\/t.co\/CiK7DalEdp",
  "id" : 368836552631132160,
  "created_at" : "2013-08-17 20:47:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368805175932121088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7206127821, -73.9614833104 ]
  },
  "id_str" : "368812785578168320",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel I just scared one of Rick's aunts suggesting that same idea.",
  "id" : 368812785578168320,
  "in_reply_to_status_id" : 368805175932121088,
  "created_at" : "2013-08-17 19:13:14 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7158705586, -73.9558537714 ]
  },
  "id_str" : "368803714565275648",
  "text" : "Just freaked out for 5 minutes thinking that I had lost my suit pants. I could've been the no pants groomsman. #webbles",
  "id" : 368803714565275648,
  "created_at" : "2013-08-17 18:37:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368794048850456576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7158510835, -73.9557626643 ]
  },
  "id_str" : "368795561815572482",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon Woah amazing!",
  "id" : 368795561815572482,
  "in_reply_to_status_id" : 368794048850456576,
  "created_at" : "2013-08-17 18:04:48 +0000",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368789650615201793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7157655382, -73.9557773327 ]
  },
  "id_str" : "368790719630020608",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates You must've accidentally turned on notifications for her. Go to her page, hit the gear, and turn it off.",
  "id" : 368790719630020608,
  "in_reply_to_status_id" : 368789650615201793,
  "created_at" : "2013-08-17 17:45:34 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 12, 21 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "emma jane webb",
      "screen_name" : "emmarocks",
      "indices" : [ 26, 36 ],
      "id_str" : "766566",
      "id" : 766566
    }, {
      "name" : "#Webbles",
      "screen_name" : "hashtagwebbles",
      "indices" : [ 78, 93 ],
      "id_str" : "1666662469",
      "id" : 1666662469
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7158282875, -73.9557208972 ]
  },
  "id_str" : "368734292081262592",
  "text" : "Everyone at @rickwebb and @emmarocks's #webbles wedding weekend should follow @hashtagwebbles. Spread the word!",
  "id" : 368734292081262592,
  "created_at" : "2013-08-17 14:01:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itsgonnabeawesome",
      "indices" : [ 15, 33 ]
    }, {
      "text" : "webbles",
      "indices" : [ 34, 42 ]
    }, {
      "text" : "onenightonly",
      "indices" : [ 43, 56 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368699873501011969",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7158256531, -73.9557574059 ]
  },
  "id_str" : "368726952288346112",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley Yay! #itsgonnabeawesome #webbles #onenightonly",
  "id" : 368726952288346112,
  "in_reply_to_status_id" : 368699873501011969,
  "created_at" : "2013-08-17 13:32:10 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368577619584757762",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7158220709, -73.9557812768 ]
  },
  "id_str" : "368725939896606720",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel It's true, we've been awesome wedding rich this year. I think they come in waves.",
  "id" : 368725939896606720,
  "in_reply_to_status_id" : 368577619584757762,
  "created_at" : "2013-08-17 13:28:09 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/E8uHYZLQKB",
      "expanded_url" : "http:\/\/flic.kr\/p\/fvJPx6",
      "display_url" : "flic.kr\/p\/fvJPx6"
    } ]
  },
  "geo" : { },
  "id_str" : "368558353175150592",
  "text" : "8:36pm My lovely wife at the #webbles rehearsal dinner http:\/\/t.co\/E8uHYZLQKB",
  "id" : 368558353175150592,
  "created_at" : "2013-08-17 02:22:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/1Hqo1m0MHD",
      "expanded_url" : "http:\/\/flic.kr\/p\/fvJMwP",
      "display_url" : "flic.kr\/p\/fvJMwP"
    } ]
  },
  "geo" : { },
  "id_str" : "368558275043655681",
  "text" : "Dressed up in a dirty mirror http:\/\/t.co\/1Hqo1m0MHD",
  "id" : 368558275043655681,
  "created_at" : "2013-08-17 02:21:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 49, 58 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/SHVZ8d8Ma3",
      "expanded_url" : "http:\/\/4sq.com\/1cI16ta",
      "display_url" : "4sq.com\/1cI16ta"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7200824731, -73.9555248118 ]
  },
  "id_str" : "368211283092709376",
  "text" : "#webbles attendees, come here! (@ The Bedford w\/ @rickwebb) http:\/\/t.co\/SHVZ8d8Ma3",
  "id" : 368211283092709376,
  "created_at" : "2013-08-16 03:23:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 11, 21 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368204989677580288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7207091339, -73.9951350222 ]
  },
  "id_str" : "368205518546145281",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame @kellianne Not me. :(",
  "id" : 368205518546145281,
  "in_reply_to_status_id" : 368204989677580288,
  "created_at" : "2013-08-16 03:00:11 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 0, 10 ],
      "id_str" : "1771141",
      "id" : 1771141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368205018694184960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7208112056, -73.9954767268 ]
  },
  "id_str" : "368205262429380609",
  "in_reply_to_user_id" : 1771141,
  "text" : "@samantham Come to the Bedford at Bedford and N 11th!",
  "id" : 368205262429380609,
  "in_reply_to_status_id" : 368205018694184960,
  "created_at" : "2013-08-16 02:59:10 +0000",
  "in_reply_to_screen_name" : "samantham",
  "in_reply_to_user_id_str" : "1771141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 0, 8 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368170269703012352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7505786348, -74.003384873 ]
  },
  "id_str" : "368199991950856192",
  "in_reply_to_user_id" : 22891211,
  "text" : "@chanian Got it.",
  "id" : 368199991950856192,
  "in_reply_to_status_id" : 368170269703012352,
  "created_at" : "2013-08-16 02:38:13 +0000",
  "in_reply_to_screen_name" : "chanian",
  "in_reply_to_user_id_str" : "22891211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 11, 21 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368166294333321216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7507259585, -74.0036358499 ]
  },
  "id_str" : "368199723624439808",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame @kellianne I was! Left the elevator and it closed behind me! :)",
  "id" : 368199723624439808,
  "in_reply_to_status_id" : 368166294333321216,
  "created_at" : "2013-08-16 02:37:09 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/uzb588bGBo",
      "expanded_url" : "http:\/\/flic.kr\/p\/fv6Mwt",
      "display_url" : "flic.kr\/p\/fv6Mwt"
    } ]
  },
  "geo" : { },
  "id_str" : "368169678784327681",
  "text" : "8:36pm Our tickets to Sleep No More http:\/\/t.co\/uzb588bGBo",
  "id" : 368169678784327681,
  "created_at" : "2013-08-16 00:37:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 45, 55 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/4837u5S4il",
      "expanded_url" : "http:\/\/4sq.com\/16STaQG",
      "display_url" : "4sq.com\/16STaQG"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7507630016, -74.0037689104 ]
  },
  "id_str" : "368165502793035776",
  "text" : "I'm at The McKittrick Hotel\/Sleep No More w\/ @kellianne http:\/\/t.co\/4837u5S4il",
  "id" : 368165502793035776,
  "created_at" : "2013-08-16 00:21:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 19, 29 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ftw",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368145177438715904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7506744804, -74.0040625566 ]
  },
  "id_str" : "368146166149812225",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Even @kellianne likes my hair now. It's cause I shampoo'ed in the airbnb sink. #ftw",
  "id" : 368146166149812225,
  "in_reply_to_status_id" : 368145177438715904,
  "created_at" : "2013-08-15 23:04:20 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 11, 21 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368145413754212354",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7506336246, -74.0044029734 ]
  },
  "id_str" : "368145903129227264",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel @kellianne I suck at photos, I thought the back light was the whole point! When do y'alls get here n e ways?",
  "id" : 368145903129227264,
  "in_reply_to_status_id" : 368145413754212354,
  "created_at" : "2013-08-15 23:03:17 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/368144493049962496\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/VKjWpeZzRp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRvpd0aCYAAJ0M9.jpg",
      "id_str" : "368144493054156800",
      "id" : 368144493054156800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRvpd0aCYAAJ0M9.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/VKjWpeZzRp"
    } ],
    "hashtags" : [ {
      "text" : "selfiethursday",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.750741968, -74.0041421168 ]
  },
  "id_str" : "368144493049962496",
  "text" : "#selfiethursday I'm I doing it right? http:\/\/t.co\/VKjWpeZzRp",
  "id" : 368144493049962496,
  "created_at" : "2013-08-15 22:57:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 51, 61 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/gcQGgzaCXh",
      "expanded_url" : "http:\/\/flic.kr\/p\/fv4ueX",
      "display_url" : "flic.kr\/p\/fv4ueX"
    } ]
  },
  "geo" : { },
  "id_str" : "368144070318632960",
  "text" : "I've been tasked with taking a new profile pic for @kellianne this weekend. Help me! http:\/\/t.co\/gcQGgzaCXh",
  "id" : 368144070318632960,
  "created_at" : "2013-08-15 22:56:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/4FCQ5Wztto",
      "expanded_url" : "http:\/\/4sq.com\/1dbqapZ",
      "display_url" : "4sq.com\/1dbqapZ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7507301262, -74.0041361756 ]
  },
  "id_str" : "368135662345936896",
  "text" : "Sleep No More pre-show dinner. Who has tips? (@ Gallow Green (Rooftop Garden Bar at the McKittrick Hotel)) http:\/\/t.co\/4FCQ5Wztto",
  "id" : 368135662345936896,
  "created_at" : "2013-08-15 22:22:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 51, 60 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 11, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/TIjPgrg8ek",
      "expanded_url" : "http:\/\/4sq.com\/16pjX8R",
      "display_url" : "4sq.com\/16pjX8R"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.713816, -73.961732 ]
  },
  "id_str" : "368073621488820224",
  "text" : "Found him! #webbles (@ Vanessa's Dumpling House w\/ @rickwebb) [pic]: http:\/\/t.co\/TIjPgrg8ek",
  "id" : 368073621488820224,
  "created_at" : "2013-08-15 18:16:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mihow",
      "screen_name" : "mihow",
      "indices" : [ 0, 6 ],
      "id_str" : "764757",
      "id" : 764757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368052085209980929",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7126270183, -73.9628860313 ]
  },
  "id_str" : "368065012902141952",
  "in_reply_to_user_id" : 764757,
  "text" : "@mihow Awesome! See you Saturday!",
  "id" : 368065012902141952,
  "in_reply_to_status_id" : 368052085209980929,
  "created_at" : "2013-08-15 17:41:52 +0000",
  "in_reply_to_screen_name" : "mihow",
  "in_reply_to_user_id_str" : "764757",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 10, 19 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/dFASbewsEE",
      "expanded_url" : "http:\/\/flic.kr\/p\/fuUrBP",
      "display_url" : "flic.kr\/p\/fuUrBP"
    } ]
  },
  "geo" : { },
  "id_str" : "368062633032708096",
  "text" : "Spying on @rickwebb's secret coworking space. No surprise to find a pile of Care Bears downstairs.  http:\/\/t.co\/dFASbewsEE",
  "id" : 368062633032708096,
  "created_at" : "2013-08-15 17:32:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 0, 10 ],
      "id_str" : "1771141",
      "id" : 1771141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368048380510892032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7148767647, -73.9545524316 ]
  },
  "id_str" : "368048870552772608",
  "in_reply_to_user_id" : 1771141,
  "text" : "@samantham Hurry!!!!",
  "id" : 368048870552772608,
  "in_reply_to_status_id" : 368048380510892032,
  "created_at" : "2013-08-15 16:37:43 +0000",
  "in_reply_to_screen_name" : "samantham",
  "in_reply_to_user_id_str" : "1771141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mihow",
      "screen_name" : "mihow",
      "indices" : [ 0, 6 ],
      "id_str" : "764757",
      "id" : 764757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368045960322359297",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7148047621, -73.9546078226 ]
  },
  "id_str" : "368048353558667264",
  "in_reply_to_user_id" : 764757,
  "text" : "@mihow 6th and Roebling! You?",
  "id" : 368048353558667264,
  "in_reply_to_status_id" : 368045960322359297,
  "created_at" : "2013-08-15 16:35:40 +0000",
  "in_reply_to_screen_name" : "mihow",
  "in_reply_to_user_id_str" : "764757",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 0, 10 ],
      "id_str" : "1771141",
      "id" : 1771141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "exciting",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368047638890819585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7148391959, -73.9545812367 ]
  },
  "id_str" : "368048114319781889",
  "in_reply_to_user_id" : 1771141,
  "text" : "@samantham We're at 6th and Roebling, about 5 blocks from you! When do you arrive??? #exciting",
  "id" : 368048114319781889,
  "in_reply_to_status_id" : 368047638890819585,
  "created_at" : "2013-08-15 16:34:43 +0000",
  "in_reply_to_screen_name" : "samantham",
  "in_reply_to_user_id_str" : "1771141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/MZxrC9QvGv",
      "expanded_url" : "https:\/\/vine.co\/v\/hMtn3uQlmXw",
      "display_url" : "vine.co\/v\/hMtn3uQlmXw"
    } ]
  },
  "geo" : { },
  "id_str" : "368036326954004480",
  "text" : "Our last minute airbnb in Williamsburg is actually pretty cool! #webbles https:\/\/t.co\/MZxrC9QvGv",
  "id" : 368036326954004480,
  "created_at" : "2013-08-15 15:47:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 0, 7 ],
      "id_str" : "47",
      "id" : 47
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368012592109072384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.5363305076, -74.3753123729 ]
  },
  "id_str" : "368013973750571008",
  "in_reply_to_user_id" : 47,
  "text" : "@kellan Ha! Yeah, I'm very likely (9) to recommend a net promoter card be built. People probably wouldn't use it much though. It's scary.",
  "id" : 368013973750571008,
  "in_reply_to_status_id" : 368012592109072384,
  "created_at" : "2013-08-15 14:19:03 +0000",
  "in_reply_to_screen_name" : "kellan",
  "in_reply_to_user_id_str" : "47",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fun",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367863768509739008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.2982601382, -74.6447780624 ]
  },
  "id_str" : "368009941225050112",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Awesome! You should add a Net Promoter Score question. \"Would you recommend following this account to your friends?\" #fun",
  "id" : 368009941225050112,
  "in_reply_to_status_id" : 367863768509739008,
  "created_at" : "2013-08-15 14:03:01 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 3, 13 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 27, 34 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/3W3l7QZjIa",
      "expanded_url" : "http:\/\/tomcoates.wufoo.com\/forms\/how-am-i-doing\/",
      "display_url" : "tomcoates.wufoo.com\/forms\/how-am-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "368009484817666048",
  "text" : "RT @tomcoates: Inspired by @buster, I knocked up this quick survey on my tweeting: http:\/\/t.co\/3W3l7QZjIa All opinions gratefully received.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 12, 19 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/3W3l7QZjIa",
        "expanded_url" : "http:\/\/tomcoates.wufoo.com\/forms\/how-am-i-doing\/",
        "display_url" : "tomcoates.wufoo.com\/forms\/how-am-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "367863768509739008",
    "text" : "Inspired by @buster, I knocked up this quick survey on my tweeting: http:\/\/t.co\/3W3l7QZjIa All opinions gratefully received.",
    "id" : 367863768509739008,
    "created_at" : "2013-08-15 04:22:11 +0000",
    "user" : {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "protected" : false,
      "id_str" : "12514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459820658327683072\/I_qV0WKP_normal.png",
      "id" : 12514,
      "verified" : false
    }
  },
  "id" : 368009484817666048,
  "created_at" : "2013-08-15 14:01:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0CA0_\u0CA0",
      "screen_name" : "MikeIsaac",
      "indices" : [ 23, 33 ],
      "id_str" : "19040598",
      "id" : 19040598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/LyNCr38Ael",
      "expanded_url" : "http:\/\/allthingsd.com\/20130815\/facebook-testing-out-paypal-competitor-in-bid-to-simplify-mobile-commerce-purchases\/",
      "display_url" : "allthingsd.com\/20130815\/faceb\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "368004125201424385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.2147070645, -74.7586776876 ]
  },
  "id_str" : "368009207439978496",
  "in_reply_to_user_id" : 19040598,
  "text" : "This could do well. RT @MikeIsaac: would you use Facebook to do your online mobile purchases? FB certainly hoped so. http:\/\/t.co\/LyNCr38Ael",
  "id" : 368009207439978496,
  "in_reply_to_status_id" : 368004125201424385,
  "created_at" : "2013-08-15 14:00:06 +0000",
  "in_reply_to_screen_name" : "MikeIsaac",
  "in_reply_to_user_id_str" : "19040598",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miguel R\u00EDos",
      "screen_name" : "miguelrios",
      "indices" : [ 3, 14 ],
      "id_str" : "14717846",
      "id" : 14717846
    }, {
      "name" : " Amazing Maps ",
      "screen_name" : "Amazing_Maps",
      "indices" : [ 30, 43 ],
      "id_str" : "1571270053",
      "id" : 1571270053
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Amazing_Maps\/status\/367043207177052160\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/vVxGq0R7Kc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRf_2i6CEAAn279.png",
      "id_str" : "367043207202213888",
      "id" : 367043207202213888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRf_2i6CEAAn279.png",
      "sizes" : [ {
        "h" : 546,
        "resize" : "fit",
        "w" : 970
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 546,
        "resize" : "fit",
        "w" : 970
      } ],
      "display_url" : "pic.twitter.com\/vVxGq0R7Kc"
    } ],
    "hashtags" : [ {
      "text" : "meritocracy",
      "indices" : [ 16, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367855172711481346",
  "text" : "RT @miguelrios: #meritocracy \u201C@Amazing_Maps: Is your state's highest paid public employee a football coach? Probably. http:\/\/t.co\/vVxGq0R7K\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : " Amazing Maps ",
        "screen_name" : "Amazing_Maps",
        "indices" : [ 14, 27 ],
        "id_str" : "1571270053",
        "id" : 1571270053
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Amazing_Maps\/status\/367043207177052160\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/vVxGq0R7Kc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRf_2i6CEAAn279.png",
        "id_str" : "367043207202213888",
        "id" : 367043207202213888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRf_2i6CEAAn279.png",
        "sizes" : [ {
          "h" : 546,
          "resize" : "fit",
          "w" : 970
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 546,
          "resize" : "fit",
          "w" : 970
        } ],
        "display_url" : "pic.twitter.com\/vVxGq0R7Kc"
      } ],
      "hashtags" : [ {
        "text" : "meritocracy",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7618822903, -122.4215709874 ]
    },
    "id_str" : "367854619793162240",
    "text" : "#meritocracy \u201C@Amazing_Maps: Is your state's highest paid public employee a football coach? Probably. http:\/\/t.co\/vVxGq0R7Kc\u201D",
    "id" : 367854619793162240,
    "created_at" : "2013-08-15 03:45:50 +0000",
    "user" : {
      "name" : "Miguel R\u00EDos",
      "screen_name" : "miguelrios",
      "protected" : false,
      "id_str" : "14717846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438437190415028225\/tVIkD0cf_normal.jpeg",
      "id" : 14717846,
      "verified" : false
    }
  },
  "id" : 367855172711481346,
  "created_at" : "2013-08-15 03:48:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sadpants",
      "indices" : [ 7, 16 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367831710634749952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.761999285, -75.5083790318 ]
  },
  "id_str" : "367832916526501888",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc #sadpants but see you soon!",
  "id" : 367832916526501888,
  "in_reply_to_status_id" : 367831710634749952,
  "created_at" : "2013-08-15 02:19:35 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367781400562262016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7622150928, -75.5084026326 ]
  },
  "id_str" : "367830981417660416",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Awesome! Wanna come to Sleep No More with us tomorrow eve? We're doing the 6:30 with dinner option...",
  "id" : 367830981417660416,
  "in_reply_to_status_id" : 367781400562262016,
  "created_at" : "2013-08-15 02:11:54 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/gjMQ3GKGTh",
      "expanded_url" : "http:\/\/flic.kr\/p\/fuw3sk",
      "display_url" : "flic.kr\/p\/fuw3sk"
    } ]
  },
  "geo" : { },
  "id_str" : "367830590868824065",
  "text" : "8:36pm Dinner at Delaware's Big Fish with Kellianne's family http:\/\/t.co\/gjMQ3GKGTh",
  "id" : 367830590868824065,
  "created_at" : "2013-08-15 02:10:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367705137889808384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.8783935849, -75.2414325056 ]
  },
  "id_str" : "367766951206334464",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Yay! When do you arrive? Where are you staying? I'm clearly way out of the loop.",
  "id" : 367766951206334464,
  "in_reply_to_status_id" : 367705137889808384,
  "created_at" : "2013-08-14 21:57:28 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virgin America",
      "screen_name" : "VirginAmerica",
      "indices" : [ 51, 65 ],
      "id_str" : "12101862",
      "id" : 12101862
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 27, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/BtZAfUJ1oL",
      "expanded_url" : "http:\/\/4sq.com\/19t5Dy5",
      "display_url" : "4sq.com\/19t5Dy5"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6173928719, -122.3820734024 ]
  },
  "id_str" : "367676062433804288",
  "text" : "SF -&gt; PHL -&gt; NYC for #webbles til Monday (at @VirginAmerica w\/ 5 others) http:\/\/t.co\/BtZAfUJ1oL",
  "id" : 367676062433804288,
  "created_at" : "2013-08-14 15:56:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/N43VWVw5uv",
      "expanded_url" : "https:\/\/vine.co\/v\/hM151nWruxw",
      "display_url" : "vine.co\/v\/hM151nWruxw"
    } ]
  },
  "geo" : { },
  "id_str" : "367535429496877056",
  "text" : "Sopor likes the brain massager https:\/\/t.co\/N43VWVw5uv",
  "id" : 367535429496877056,
  "created_at" : "2013-08-14 06:37:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Kr\u00FCg",
      "screen_name" : "kk",
      "indices" : [ 3, 6 ],
      "id_str" : "13669",
      "id" : 13669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367517577951453186",
  "text" : "RT @kk: \"Life is mostly froth and bubble, two things stand like stone, kindness in another's trouble, courage in your own.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367516666554744832",
    "text" : "\"Life is mostly froth and bubble, two things stand like stone, kindness in another's trouble, courage in your own.\"",
    "id" : 367516666554744832,
    "created_at" : "2013-08-14 05:22:56 +0000",
    "user" : {
      "name" : "Kris Kr\u00FCg",
      "screen_name" : "kk",
      "protected" : false,
      "id_str" : "13669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1695093107\/kk-green_normal.jpg",
      "id" : 13669,
      "verified" : false
    }
  },
  "id" : 367517577951453186,
  "created_at" : "2013-08-14 05:26:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597179102, -122.2753993516 ]
  },
  "id_str" : "367516849254064128",
  "text" : "Variations of social networks and cross-posting exist so that you can fave something 50 times when you really want to.",
  "id" : 367516849254064128,
  "created_at" : "2013-08-14 05:23:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367495421901283329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597480738, -122.2756155487 ]
  },
  "id_str" : "367495721437507584",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates The best part is ignoring all the feedback and just doing what I feel like. It's more so I can say \"you had fair warning...\"",
  "id" : 367495721437507584,
  "in_reply_to_status_id" : 367495421901283329,
  "created_at" : "2013-08-14 03:59:42 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367484778213146624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597012302, -122.2755027843 ]
  },
  "id_str" : "367494705203793920",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Yeah it's pretty fun to get feedback like that. I encourage you to try it out!",
  "id" : 367494705203793920,
  "in_reply_to_status_id" : 367484778213146624,
  "created_at" : "2013-08-14 03:55:40 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Bogan",
      "screen_name" : "waferbaby",
      "indices" : [ 0, 10 ],
      "id_str" : "821753",
      "id" : 821753
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 11, 21 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 22, 30 ],
      "id_str" : "5699",
      "id" : 5699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/zS7D7vmtg7",
      "expanded_url" : "http:\/\/m.flickr.com\/#\/search\/advanced_QM_q_IS_buster_AND_ss_IS_2_AND_prefs_photos_IS_1_AND_prefs_screenshots_IS_1_AND_prefs_other_IS_1_AND_mt_IS_all_AND_w_IS_all",
      "display_url" : "m.flickr.com\/#\/search\/advan\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "367487409216172032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596903401, -122.2756932778 ]
  },
  "id_str" : "367494471371341824",
  "in_reply_to_user_id" : 821753,
  "text" : "@waferbaby @tomcoates @stewart Dog names are the best names: http:\/\/t.co\/zS7D7vmtg7",
  "id" : 367494471371341824,
  "in_reply_to_status_id" : 367487409216172032,
  "created_at" : "2013-08-14 03:54:44 +0000",
  "in_reply_to_screen_name" : "waferbaby",
  "in_reply_to_user_id_str" : "821753",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 19, 28 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "emma jane webb",
      "screen_name" : "emmarocks",
      "indices" : [ 33, 43 ],
      "id_str" : "766566",
      "id" : 766566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/7BCYUTL29C",
      "expanded_url" : "http:\/\/flic.kr\/p\/fubLCh",
      "display_url" : "flic.kr\/p\/fubLCh"
    } ]
  },
  "geo" : { },
  "id_str" : "367493275730460672",
  "text" : "8:36pm Packing for @rickwebb and @emmarocks awesome #webbles weekend.  http:\/\/t.co\/7BCYUTL29C",
  "id" : 367493275730460672,
  "created_at" : "2013-08-14 03:49:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 0, 8 ],
      "id_str" : "5699",
      "id" : 5699
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 9, 19 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Daniel Bogan",
      "screen_name" : "waferbaby",
      "indices" : [ 20, 30 ],
      "id_str" : "821753",
      "id" : 821753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367485467123388416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859759562, -122.2754751625 ]
  },
  "id_str" : "367485752294113281",
  "in_reply_to_user_id" : 5699,
  "text" : "@stewart @tomcoates @waferbaby It actually came down to a coin flip in the court house. I was sad too. Might've changed my life's course...",
  "id" : 367485752294113281,
  "in_reply_to_status_id" : 367485467123388416,
  "created_at" : "2013-08-14 03:20:05 +0000",
  "in_reply_to_screen_name" : "stewart",
  "in_reply_to_user_id_str" : "5699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Daniel Bogan",
      "screen_name" : "waferbaby",
      "indices" : [ 11, 21 ],
      "id_str" : "821753",
      "id" : 821753
    }, {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 53, 61 ],
      "id_str" : "5699",
      "id" : 5699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367483875519242240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859769921, -122.2754697851 ]
  },
  "id_str" : "367485114692804609",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates @waferbaby Had? I *still* have a crush on @stewart.",
  "id" : 367485114692804609,
  "in_reply_to_status_id" : 367483875519242240,
  "created_at" : "2013-08-14 03:17:33 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Bogan",
      "screen_name" : "waferbaby",
      "indices" : [ 0, 10 ],
      "id_str" : "821753",
      "id" : 821753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367481812714393600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596892441, -122.2754796502 ]
  },
  "id_str" : "367483132825444352",
  "in_reply_to_user_id" : 821753,
  "text" : "@waferbaby I was Buster Butterfield McLeod for a while. And Erik Benson before that.",
  "id" : 367483132825444352,
  "in_reply_to_status_id" : 367481812714393600,
  "created_at" : "2013-08-14 03:09:41 +0000",
  "in_reply_to_screen_name" : "waferbaby",
  "in_reply_to_user_id_str" : "821753",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367474061439287296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597486017, -122.2754344002 ]
  },
  "id_str" : "367474448569344000",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates At SXSW it's just called Tuesday.",
  "id" : 367474448569344000,
  "in_reply_to_status_id" : 367474061439287296,
  "created_at" : "2013-08-14 02:35:10 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367473520160145408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597770406, -122.2753741054 ]
  },
  "id_str" : "367473999996915714",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates See, right? Cause I totally remember you.",
  "id" : 367473999996915714,
  "in_reply_to_status_id" : 367473520160145408,
  "created_at" : "2013-08-14 02:33:23 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597159405, -122.2754508165 ]
  },
  "id_str" : "367473284612231168",
  "text" : "I fave your fave. As a service.",
  "id" : 367473284612231168,
  "created_at" : "2013-08-14 02:30:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Dorsey",
      "screen_name" : "jack",
      "indices" : [ 15, 20 ],
      "id_str" : "12",
      "id" : 12
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597114561, -122.2754369025 ]
  },
  "id_str" : "367472377166184449",
  "text" : "Surprised that @jack doesn't remember me. From SXSW. 2006. At a dark bar super late. When I had blue hair. And a different name. :(",
  "id" : 367472377166184449,
  "created_at" : "2013-08-14 02:26:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Reich",
      "screen_name" : "ohheygreat",
      "indices" : [ 3, 14 ],
      "id_str" : "9670142",
      "id" : 9670142
    }, {
      "name" : "Silvia Killingsworth",
      "screen_name" : "silviakillings",
      "indices" : [ 35, 50 ],
      "id_str" : "145773567",
      "id" : 145773567
    }, {
      "name" : "Dana",
      "screen_name" : "DanaDanger",
      "indices" : [ 62, 73 ],
      "id_str" : "821958",
      "id" : 821958
    }, {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 74, 84 ],
      "id_str" : "798542",
      "id" : 798542
    }, {
      "name" : "Anna Holmes",
      "screen_name" : "AnnaHolmes",
      "indices" : [ 85, 96 ],
      "id_str" : "20861943",
      "id" : 20861943
    }, {
      "name" : "Suzanne Fischer",
      "screen_name" : "publichistorian",
      "indices" : [ 97, 113 ],
      "id_str" : "16933278",
      "id" : 16933278
    }, {
      "name" : "Michelle Dean",
      "screen_name" : "michelledean",
      "indices" : [ 114, 127 ],
      "id_str" : "16526776",
      "id" : 16526776
    }, {
      "name" : "Jen Doll",
      "screen_name" : "thisisjendoll",
      "indices" : [ 139, 140 ],
      "id_str" : "46442771",
      "id" : 46442771
    }, {
      "name" : "maura johnston",
      "screen_name" : "maura",
      "indices" : [ 139, 140 ],
      "id_str" : "12912",
      "id" : 12912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367461685822369792",
  "text" : "RT @ohheygreat: More women I love: @silviakillings @grace6697 @danadanger @helenjane @annaholmes @publichistorian @michelledean @thisisjend\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Silvia Killingsworth",
        "screen_name" : "silviakillings",
        "indices" : [ 19, 34 ],
        "id_str" : "145773567",
        "id" : 145773567
      }, {
        "name" : "Dana",
        "screen_name" : "DanaDanger",
        "indices" : [ 46, 57 ],
        "id_str" : "821958",
        "id" : 821958
      }, {
        "name" : "Helen Jane",
        "screen_name" : "helenjane",
        "indices" : [ 58, 68 ],
        "id_str" : "798542",
        "id" : 798542
      }, {
        "name" : "Anna Holmes",
        "screen_name" : "AnnaHolmes",
        "indices" : [ 69, 80 ],
        "id_str" : "20861943",
        "id" : 20861943
      }, {
        "name" : "Suzanne Fischer",
        "screen_name" : "publichistorian",
        "indices" : [ 81, 97 ],
        "id_str" : "16933278",
        "id" : 16933278
      }, {
        "name" : "Michelle Dean",
        "screen_name" : "michelledean",
        "indices" : [ 98, 111 ],
        "id_str" : "16526776",
        "id" : 16526776
      }, {
        "name" : "Jen Doll",
        "screen_name" : "thisisjendoll",
        "indices" : [ 112, 126 ],
        "id_str" : "46442771",
        "id" : 46442771
      }, {
        "name" : "maura johnston",
        "screen_name" : "maura",
        "indices" : [ 127, 133 ],
        "id_str" : "12912",
        "id" : 12912
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367428536069402624",
    "text" : "More women I love: @silviakillings @grace6697 @danadanger @helenjane @annaholmes @publichistorian @michelledean @thisisjendoll @maura",
    "id" : 367428536069402624,
    "created_at" : "2013-08-13 23:32:44 +0000",
    "user" : {
      "name" : "Leah Reich",
      "screen_name" : "ohheygreat",
      "protected" : false,
      "id_str" : "9670142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461923328165298176\/wFNcIXOX_normal.jpeg",
      "id" : 9670142,
      "verified" : false
    }
  },
  "id" : 367461685822369792,
  "created_at" : "2013-08-14 01:44:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Reich",
      "screen_name" : "ohheygreat",
      "indices" : [ 3, 14 ],
      "id_str" : "9670142",
      "id" : 9670142
    }, {
      "name" : "Malcolm Ellis",
      "screen_name" : "malellis",
      "indices" : [ 89, 98 ],
      "id_str" : "45600944",
      "id" : 45600944
    }, {
      "name" : "Lisa McIntire",
      "screen_name" : "LisaMcIntire",
      "indices" : [ 100, 113 ],
      "id_str" : "133064711",
      "id" : 133064711
    }, {
      "name" : "Caitlin Kelly",
      "screen_name" : "atotalmonet",
      "indices" : [ 114, 126 ],
      "id_str" : "243896198",
      "id" : 243896198
    }, {
      "name" : "Elizabeth Lopatto",
      "screen_name" : "mslopatto",
      "indices" : [ 127, 137 ],
      "id_str" : "278083839",
      "id" : 278083839
    }, {
      "name" : "Casey N. Cep",
      "screen_name" : "cncep",
      "indices" : [ 139, 140 ],
      "id_str" : "438935496",
      "id" : 438935496
    }, {
      "name" : "Laura June",
      "screen_name" : "laura_june",
      "indices" : [ 139, 140 ],
      "id_str" : "11361262",
      "id" : 11361262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367461646572072961",
  "text" : "RT @ohheygreat: in light of all this stupid Bustle nonsense, here are some women I love: @malellis  @LisaMcIntire @atotalmonet @mslopatto @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Malcolm Ellis",
        "screen_name" : "malellis",
        "indices" : [ 73, 82 ],
        "id_str" : "45600944",
        "id" : 45600944
      }, {
        "name" : "Lisa McIntire",
        "screen_name" : "LisaMcIntire",
        "indices" : [ 84, 97 ],
        "id_str" : "133064711",
        "id" : 133064711
      }, {
        "name" : "Caitlin Kelly",
        "screen_name" : "atotalmonet",
        "indices" : [ 98, 110 ],
        "id_str" : "243896198",
        "id" : 243896198
      }, {
        "name" : "Elizabeth Lopatto",
        "screen_name" : "mslopatto",
        "indices" : [ 111, 121 ],
        "id_str" : "278083839",
        "id" : 278083839
      }, {
        "name" : "Casey N. Cep",
        "screen_name" : "cncep",
        "indices" : [ 122, 128 ],
        "id_str" : "438935496",
        "id" : 438935496
      }, {
        "name" : "Laura June",
        "screen_name" : "laura_june",
        "indices" : [ 129, 140 ],
        "id_str" : "11361262",
        "id" : 11361262
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367428112016875520",
    "text" : "in light of all this stupid Bustle nonsense, here are some women I love: @malellis  @LisaMcIntire @atotalmonet @mslopatto @cncep @laura_june",
    "id" : 367428112016875520,
    "created_at" : "2013-08-13 23:31:03 +0000",
    "user" : {
      "name" : "Leah Reich",
      "screen_name" : "ohheygreat",
      "protected" : false,
      "id_str" : "9670142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461923328165298176\/wFNcIXOX_normal.jpeg",
      "id" : 9670142,
      "verified" : false
    }
  },
  "id" : 367461646572072961,
  "created_at" : "2013-08-14 01:44:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 3, 10 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Lane Wood",
      "screen_name" : "lanewood",
      "indices" : [ 103, 112 ],
      "id_str" : "14325136",
      "id" : 14325136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/h7k29nyCNi",
      "expanded_url" : "https:\/\/medium.com\/architecting-a-life\/5e9d57919f06?utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
      "display_url" : "medium.com\/architecting-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367458234832936960",
  "text" : "RT @Medium: \u201COne Month with No Phone: Important lessons I learned while phoneless in San Francisco\u201D by @lanewood https:\/\/t.co\/h7k29nyCNi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lane Wood",
        "screen_name" : "lanewood",
        "indices" : [ 91, 100 ],
        "id_str" : "14325136",
        "id" : 14325136
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/h7k29nyCNi",
        "expanded_url" : "https:\/\/medium.com\/architecting-a-life\/5e9d57919f06?utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
        "display_url" : "medium.com\/architecting-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "367443260014202880",
    "text" : "\u201COne Month with No Phone: Important lessons I learned while phoneless in San Francisco\u201D by @lanewood https:\/\/t.co\/h7k29nyCNi",
    "id" : 367443260014202880,
    "created_at" : "2013-08-14 00:31:14 +0000",
    "user" : {
      "name" : "Medium",
      "screen_name" : "Medium",
      "protected" : false,
      "id_str" : "571202103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2504297462\/wtbq3hoquj8no6t2ysz4_normal.jpeg",
      "id" : 571202103,
      "verified" : true
    }
  },
  "id" : 367458234832936960,
  "created_at" : "2013-08-14 01:30:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 3, 15 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/hTLyxBfgZN",
      "expanded_url" : "http:\/\/bit.ly\/11G4RHm",
      "display_url" : "bit.ly\/11G4RHm"
    } ]
  },
  "geo" : { },
  "id_str" : "367426106237796352",
  "text" : "RT @nickcrocker: Too Much Smoke, Too Little Fire: The Problem With Wearables in 2013: http:\/\/t.co\/hTLyxBfgZN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/hTLyxBfgZN",
        "expanded_url" : "http:\/\/bit.ly\/11G4RHm",
        "display_url" : "bit.ly\/11G4RHm"
      } ]
    },
    "geo" : { },
    "id_str" : "367425182958223360",
    "text" : "Too Much Smoke, Too Little Fire: The Problem With Wearables in 2013: http:\/\/t.co\/hTLyxBfgZN",
    "id" : 367425182958223360,
    "created_at" : "2013-08-13 23:19:24 +0000",
    "user" : {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "protected" : false,
      "id_str" : "30801469",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460845803498516480\/1m9QG5iU_normal.jpeg",
      "id" : 30801469,
      "verified" : false
    }
  },
  "id" : 367426106237796352,
  "created_at" : "2013-08-13 23:23:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "stephdub",
      "screen_name" : "stephdub",
      "indices" : [ 8, 17 ],
      "id_str" : "14936359",
      "id" : 14936359
    }, {
      "name" : "#Webbles",
      "screen_name" : "hashtagwebbles",
      "indices" : [ 42, 57 ],
      "id_str" : "1666662469",
      "id" : 1666662469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367347197592879104",
  "geo" : { },
  "id_str" : "367352735240175616",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon @stephdub Definitely don't follow @hashtagwebbles then. :)\n\nWe'll be thinking of you! Have you started your own hashtag yet?",
  "id" : 367352735240175616,
  "in_reply_to_status_id" : 367347197592879104,
  "created_at" : "2013-08-13 18:31:31 +0000",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain Carle",
      "screen_name" : "froginthevalley",
      "indices" : [ 3, 19 ],
      "id_str" : "657693",
      "id" : 657693
    }, {
      "name" : "Twitter API",
      "screen_name" : "twitterapi",
      "indices" : [ 63, 74 ],
      "id_str" : "6253282",
      "id" : 6253282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "job",
      "indices" : [ 110, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/ImJmIHBYxy",
      "expanded_url" : "http:\/\/jobvite.com\/m?3WFz0gwV",
      "display_url" : "jobvite.com\/m?3WFz0gwV"
    } ]
  },
  "geo" : { },
  "id_str" : "367341658636947456",
  "text" : "RT @froginthevalley: You're an amazing PM with API experience? @twitterapi needs you!  http:\/\/t.co\/ImJmIHBYxy #job",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/jobvite.com\" rel=\"nofollow\"\u003EJobvite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter API",
        "screen_name" : "twitterapi",
        "indices" : [ 42, 53 ],
        "id_str" : "6253282",
        "id" : 6253282
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "job",
        "indices" : [ 89, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/ImJmIHBYxy",
        "expanded_url" : "http:\/\/jobvite.com\/m?3WFz0gwV",
        "display_url" : "jobvite.com\/m?3WFz0gwV"
      } ]
    },
    "geo" : { },
    "id_str" : "367340767951716352",
    "text" : "You're an amazing PM with API experience? @twitterapi needs you!  http:\/\/t.co\/ImJmIHBYxy #job",
    "id" : 367340767951716352,
    "created_at" : "2013-08-13 17:43:58 +0000",
    "user" : {
      "name" : "Sylvain Carle",
      "screen_name" : "froginthevalley",
      "protected" : false,
      "id_str" : "657693",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425774377657827328\/p8B9ooUc_normal.png",
      "id" : 657693,
      "verified" : false
    }
  },
  "id" : 367341658636947456,
  "created_at" : "2013-08-13 17:47:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phillip Bowden",
      "screen_name" : "pbowden",
      "indices" : [ 3, 11 ],
      "id_str" : "2134761",
      "id" : 2134761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367332935680008192",
  "text" : "RT @pbowden: *PRESS CONFERENCE*\n\nHYPERLOOP. MERELY A CODENAME. TRANSPORTATION, A RUSE.\n\nI INTRODUCE NOT A TRANSPORT, BUT A FRAGRANCE.\n\nMUSK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367021507014164480",
    "text" : "*PRESS CONFERENCE*\n\nHYPERLOOP. MERELY A CODENAME. TRANSPORTATION, A RUSE.\n\nI INTRODUCE NOT A TRANSPORT, BUT A FRAGRANCE.\n\nMUSK. BY MUSK.",
    "id" : 367021507014164480,
    "created_at" : "2013-08-12 20:35:20 +0000",
    "user" : {
      "name" : "Phillip Bowden",
      "screen_name" : "pbowden",
      "protected" : false,
      "id_str" : "2134761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443557129836711936\/L1lTYMjC_normal.png",
      "id" : 2134761,
      "verified" : false
    }
  },
  "id" : 367332935680008192,
  "created_at" : "2013-08-13 17:12:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/5bAUz9Grfi",
      "expanded_url" : "http:\/\/t.ritholtz.com\/bigpicture\/#!\/entry\/byron-wiens-20-rules-of-investing-life,51d990e9da27f5d9d0f3384a",
      "display_url" : "t.ritholtz.com\/bigpicture\/#!\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7761483658, -122.4164821209 ]
  },
  "id_str" : "367320623082516482",
  "text" : "Byron Wien's 20 lessons learned from the first 80 years of life http:\/\/t.co\/5bAUz9Grfi",
  "id" : 367320623082516482,
  "created_at" : "2013-08-13 16:23:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Porad",
      "screen_name" : "scottporad",
      "indices" : [ 3, 14 ],
      "id_str" : "15876737",
      "id" : 15876737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/XLfWruBk3p",
      "expanded_url" : "http:\/\/nyti.ms\/19fTwRr",
      "display_url" : "nyti.ms\/19fTwRr"
    } ]
  },
  "geo" : { },
  "id_str" : "367319697013735425",
  "text" : "RT @scottporad: If this doesn't break your heart, then nothing will: The Gun Report: August 13, 2013 - http:\/\/t.co\/XLfWruBk3p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/XLfWruBk3p",
        "expanded_url" : "http:\/\/nyti.ms\/19fTwRr",
        "display_url" : "nyti.ms\/19fTwRr"
      } ]
    },
    "geo" : { },
    "id_str" : "367313201891139584",
    "text" : "If this doesn't break your heart, then nothing will: The Gun Report: August 13, 2013 - http:\/\/t.co\/XLfWruBk3p",
    "id" : 367313201891139584,
    "created_at" : "2013-08-13 15:54:26 +0000",
    "user" : {
      "name" : "Scott Porad",
      "screen_name" : "scottporad",
      "protected" : false,
      "id_str" : "15876737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/58474218\/a545469291_443918_4159_normal.jpg",
      "id" : 15876737,
      "verified" : false
    }
  },
  "id" : 367319697013735425,
  "created_at" : "2013-08-13 16:20:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephdub",
      "screen_name" : "stephdub",
      "indices" : [ 0, 9 ],
      "id_str" : "14936359",
      "id" : 14936359
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367310479518994432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8394020483, -122.2696025531 ]
  },
  "id_str" : "367311368849854467",
  "in_reply_to_user_id" : 14936359,
  "text" : "@stephdub We will! (Thurs-Sun) Can't wait! #webbles",
  "id" : 367311368849854467,
  "in_reply_to_status_id" : 367310479518994432,
  "created_at" : "2013-08-13 15:47:09 +0000",
  "in_reply_to_screen_name" : "stephdub",
  "in_reply_to_user_id_str" : "14936359",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/HD5wp6mKXZ",
      "expanded_url" : "http:\/\/jlord.us\/fork-n-go\/",
      "display_url" : "jlord.us\/fork-n-go\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597302799, -122.2756837917 ]
  },
  "id_str" : "367294149893947392",
  "text" : "Clever. Use Google Spreadsheet as a database to power a simple website: http:\/\/t.co\/HD5wp6mKXZ",
  "id" : 367294149893947392,
  "created_at" : "2013-08-13 14:38:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webbles",
      "indices" : [ 22, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/sHBhWmiDod",
      "expanded_url" : "http:\/\/flic.kr\/p\/ftgsYk",
      "display_url" : "flic.kr\/p\/ftgsYk"
    } ]
  },
  "geo" : { },
  "id_str" : "367128206215610368",
  "text" : "8:36pm Playing around #webbles http:\/\/t.co\/sHBhWmiDod",
  "id" : 367128206215610368,
  "created_at" : "2013-08-13 03:39:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TwitterRevolution",
      "indices" : [ 48, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597927187, -122.2754063924 ]
  },
  "id_str" : "367112527051636736",
  "text" : "Late-learning that Twitter HQ has a gym through #TwitterRevolution.",
  "id" : 367112527051636736,
  "created_at" : "2013-08-13 02:37:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TwitterRevolution",
      "indices" : [ 13, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/8yLBFedWbt",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=VBSvdv07DCk",
      "display_url" : "youtube.com\/watch?v=VBSvdv\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597715125, -122.2754441948 ]
  },
  "id_str" : "367110154887503874",
  "text" : "Watching the #TwitterRevolution documentary on YouTube: http:\/\/t.co\/8yLBFedWbt (watch while you can, tv-less friends!)",
  "id" : 367110154887503874,
  "created_at" : "2013-08-13 02:27:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367105639165599744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8571060673, -122.2721118015 ]
  },
  "id_str" : "367105797953560576",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall Yes please!",
  "id" : 367105797953560576,
  "in_reply_to_status_id" : 367105639165599744,
  "created_at" : "2013-08-13 02:10:17 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367105335145676800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8572281916, -122.2707872094 ]
  },
  "id_str" : "367105449759211521",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall Ha! Got a link of picture of it?",
  "id" : 367105449759211521,
  "in_reply_to_status_id" : 367105335145676800,
  "created_at" : "2013-08-13 02:08:54 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367101535781937152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8572537983, -122.2677282338 ]
  },
  "id_str" : "367102202189328385",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb It's all based on a public google spreadsheet, which makes it easy to get started at least. But yeah. Nothing does that.",
  "id" : 367102202189328385,
  "in_reply_to_status_id" : 367101535781937152,
  "created_at" : "2013-08-13 01:56:00 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/IvdOJ3gZfQ",
      "expanded_url" : "http:\/\/timeline.verite.co",
      "display_url" : "timeline.verite.co"
    } ]
  },
  "in_reply_to_status_id_str" : "367099403682975744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8572235816, -122.2676994001 ]
  },
  "id_str" : "367101356261130242",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb I've wanted to make one forever! But if you have somewhere to embed an iframe, this one ain't bad: http:\/\/t.co\/IvdOJ3gZfQ",
  "id" : 367101356261130242,
  "in_reply_to_status_id" : 367099403682975744,
  "created_at" : "2013-08-13 01:52:38 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/read-it-later-pro\/id309601447?mt=8&uo=4\" rel=\"nofollow\"\u003EPocket for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 3, 11 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "longreads",
      "indices" : [ 89, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/hIl8dYNzfv",
      "expanded_url" : "http:\/\/www.citypages.com\/2011-01-19\/news\/oregon-trail-how-three-minnesotans-forged-its-path\/",
      "display_url" : "citypages.com\/2011-01-19\/new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367097236888367104",
  "text" : "RT @rsarver: The awesome story of how Oregon Trail was born and how it died of dysentery #longreads http:\/\/t.co\/hIl8dYNzfv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "longreads",
        "indices" : [ 76, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/hIl8dYNzfv",
        "expanded_url" : "http:\/\/www.citypages.com\/2011-01-19\/news\/oregon-trail-how-three-minnesotans-forged-its-path\/",
        "display_url" : "citypages.com\/2011-01-19\/new\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "366954770767949824",
    "text" : "The awesome story of how Oregon Trail was born and how it died of dysentery #longreads http:\/\/t.co\/hIl8dYNzfv",
    "id" : 366954770767949824,
    "created_at" : "2013-08-12 16:10:09 +0000",
    "user" : {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "protected" : false,
      "id_str" : "795649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3015419114\/3dc096c48ef6167d1b26fd0d6b01814d_normal.jpeg",
      "id" : 795649,
      "verified" : false
    }
  },
  "id" : 367097236888367104,
  "created_at" : "2013-08-13 01:36:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367034925284728833",
  "geo" : { },
  "id_str" : "367035305297059841",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Oh yeah, I definitely did, and love it.",
  "id" : 367035305297059841,
  "in_reply_to_status_id" : 367034925284728833,
  "created_at" : "2013-08-12 21:30:10 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/cir.ca\/\" rel=\"nofollow\"\u003ECirca News\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/WyaNutA4xM",
      "expanded_url" : "http:\/\/cir.ca\/s\/RRd",
      "display_url" : "cir.ca\/s\/RRd"
    } ]
  },
  "geo" : { },
  "id_str" : "367034929206407168",
  "text" : "Niko's gonna love this: \"Elon Musk reveals Hyperloop design: San Francisco to Los Angeles in under an hour\" http:\/\/t.co\/WyaNutA4xM",
  "id" : 367034929206407168,
  "created_at" : "2013-08-12 21:28:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TweetDeck",
      "screen_name" : "TweetDeck",
      "indices" : [ 11, 21 ],
      "id_str" : "14803701",
      "id" : 14803701
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TweetDeck\/status\/366978637020426240\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/HVqc758vWX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRfFIERCcAAM-oo.png",
      "id_str" : "366978637028814848",
      "id" : 366978637028814848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRfFIERCcAAM-oo.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 629
      }, {
        "h" : 505,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 629
      } ],
      "display_url" : "pic.twitter.com\/HVqc758vWX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/LtCNhO5A6B",
      "expanded_url" : "https:\/\/blog.twitter.com\/2013\/a-better-experience-for-sending-tweets",
      "display_url" : "blog.twitter.com\/2013\/a-better-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "366999249407311873",
  "text" : "Get it. RT @TweetDeck: We are launching a better experience for sending Tweets and DMs: https:\/\/t.co\/LtCNhO5A6B http:\/\/t.co\/HVqc758vWX",
  "id" : 366999249407311873,
  "created_at" : "2013-08-12 19:06:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "indices" : [ 3, 16 ],
      "id_str" : "16906137",
      "id" : 16906137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366960182917468161",
  "text" : "RT @pourmecoffee: It's Erwin Schr\u00F6dinger's birthday, OR IS IT? You will not know until you read this tweet. It totally is.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "366955655879335937",
    "text" : "It's Erwin Schr\u00F6dinger's birthday, OR IS IT? You will not know until you read this tweet. It totally is.",
    "id" : 366955655879335937,
    "created_at" : "2013-08-12 16:13:40 +0000",
    "user" : {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "protected" : false,
      "id_str" : "16906137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421566216\/coffee1242220886_normal.jpg",
      "id" : 16906137,
      "verified" : true
    }
  },
  "id" : 366960182917468161,
  "created_at" : "2013-08-12 16:31:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julien Smith",
      "screen_name" : "julien",
      "indices" : [ 96, 103 ],
      "id_str" : "10203",
      "id" : 10203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/SMpOSHCxGe",
      "expanded_url" : "http:\/\/inoveryourhead.net\/the-short-and-sweet-guide-to-being-fucking-awesome\/",
      "display_url" : "inoveryourhead.net\/the-short-and-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7986843742, -122.2776361843 ]
  },
  "id_str" : "366957893943164928",
  "text" : "Pretty awesome: \"The Short and Sweet Guide to Being Fucking Awesome\" http:\/\/t.co\/SMpOSHCxGe \/by @julien",
  "id" : 366957893943164928,
  "created_at" : "2013-08-12 16:22:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366929598002372609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596599313, -122.2755011638 ]
  },
  "id_str" : "366934496697782273",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall Yeah.",
  "id" : 366934496697782273,
  "in_reply_to_status_id" : 366929598002372609,
  "created_at" : "2013-08-12 14:49:35 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sorry",
      "indices" : [ 51, 57 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366803941817716736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597391715, -122.2756835826 ]
  },
  "id_str" : "366805171403096065",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Then you should turn on the heater. #sorry",
  "id" : 366805171403096065,
  "in_reply_to_status_id" : 366803941817716736,
  "created_at" : "2013-08-12 06:15:42 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ibrahim bashir",
      "screen_name" : "ibrahimbashir",
      "indices" : [ 0, 14 ],
      "id_str" : "19079210",
      "id" : 19079210
    }, {
      "name" : "Quora",
      "screen_name" : "Quora",
      "indices" : [ 15, 21 ],
      "id_str" : "33696409",
      "id" : 33696409
    }, {
      "name" : "Chris Lambert",
      "screen_name" : "trichris",
      "indices" : [ 22, 31 ],
      "id_str" : "40340735",
      "id" : 40340735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366790147821412352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597305338, -122.2756250201 ]
  },
  "id_str" : "366790615939293184",
  "in_reply_to_user_id" : 19079210,
  "text" : "@ibrahimbashir @Quora @trichris Looking forward to the answer!",
  "id" : 366790615939293184,
  "in_reply_to_status_id" : 366790147821412352,
  "created_at" : "2013-08-12 05:17:52 +0000",
  "in_reply_to_screen_name" : "ibrahimbashir",
  "in_reply_to_user_id_str" : "19079210",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/IthW29isVy",
      "expanded_url" : "http:\/\/flic.kr\/p\/fszKMr",
      "display_url" : "flic.kr\/p\/fszKMr"
    } ]
  },
  "geo" : { },
  "id_str" : "366769203300147201",
  "text" : "8:36pm Yup there was a Big Book of Big Trains that we didn't have yet. http:\/\/t.co\/IthW29isVy",
  "id" : 366769203300147201,
  "created_at" : "2013-08-12 03:52:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/Fl6Nx5sJvj",
      "expanded_url" : "https:\/\/vine.co\/v\/hhVKYUvulZm",
      "display_url" : "vine.co\/v\/hhVKYUvulZm"
    } ]
  },
  "geo" : { },
  "id_str" : "366732103020318721",
  "text" : "Niko discovers bike gears. Loop 100x. https:\/\/t.co\/Fl6Nx5sJvj",
  "id" : 366732103020318721,
  "created_at" : "2013-08-12 01:25:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "strava",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/UBjiiKfsFu",
      "expanded_url" : "https:\/\/www.strava.com\/activities\/73956321",
      "display_url" : "strava.com\/activities\/739\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859701, -122.275481 ]
  },
  "id_str" : "366645835930411008",
  "text" : "My new favorite weekend ride. Went for a 18 mi ride. #strava https:\/\/t.co\/UBjiiKfsFu",
  "id" : 366645835930411008,
  "created_at" : "2013-08-11 19:42:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "skylinedrive",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/WJ7zBuaqt1",
      "expanded_url" : "http:\/\/flic.kr\/p\/fsybbm",
      "display_url" : "flic.kr\/p\/fsybbm"
    } ]
  },
  "geo" : { },
  "id_str" : "366640868175781888",
  "text" : "#skylinedrive ride number 2 http:\/\/t.co\/WJ7zBuaqt1",
  "id" : 366640868175781888,
  "created_at" : "2013-08-11 19:22:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alison Agosti",
      "screen_name" : "AlisonAgosti",
      "indices" : [ 3, 16 ],
      "id_str" : "14990751",
      "id" : 14990751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366435165137944577",
  "text" : "RT @AlisonAgosti: Which is heavier: a pound of feathers or realizing that you're going to die?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "366397820191772675",
    "text" : "Which is heavier: a pound of feathers or realizing that you're going to die?",
    "id" : 366397820191772675,
    "created_at" : "2013-08-11 03:17:02 +0000",
    "user" : {
      "name" : "Alison Agosti",
      "screen_name" : "AlisonAgosti",
      "protected" : false,
      "id_str" : "14990751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000514953263\/3d2604c361dd90b9a3f540097d52b6f1_normal.jpeg",
      "id" : 14990751,
      "verified" : false
    }
  },
  "id" : 366435165137944577,
  "created_at" : "2013-08-11 05:45:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 3, 10 ],
      "id_str" : "13257392",
      "id" : 13257392
    }, {
      "name" : "Zite ",
      "screen_name" : "Zite",
      "indices" : [ 120, 125 ],
      "id_str" : "110558385",
      "id" : 110558385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/zGOyZ6KC0B",
      "expanded_url" : "http:\/\/zite.to\/14EAd6n",
      "display_url" : "zite.to\/14EAd6n"
    } ]
  },
  "geo" : { },
  "id_str" : "366425206035714048",
  "text" : "RT @eismcc: Shark inception: This is a picture of a shark eating another shark. That is all. http:\/\/t.co\/zGOyZ6KC0B via @zite",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zite ",
        "screen_name" : "Zite",
        "indices" : [ 108, 113 ],
        "id_str" : "110558385",
        "id" : 110558385
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/zGOyZ6KC0B",
        "expanded_url" : "http:\/\/zite.to\/14EAd6n",
        "display_url" : "zite.to\/14EAd6n"
      } ]
    },
    "geo" : { },
    "id_str" : "366412383800922112",
    "text" : "Shark inception: This is a picture of a shark eating another shark. That is all. http:\/\/t.co\/zGOyZ6KC0B via @zite",
    "id" : 366412383800922112,
    "created_at" : "2013-08-11 04:14:54 +0000",
    "user" : {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "protected" : false,
      "id_str" : "13257392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000776196063\/f3b4eb47415ca5d483a8ec77b8a4995f_normal.jpeg",
      "id" : 13257392,
      "verified" : false
    }
  },
  "id" : 366425206035714048,
  "created_at" : "2013-08-11 05:05:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366418266702352384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8347652821, -122.2630390092 ]
  },
  "id_str" : "366419731592388609",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane Let us make this happeneth!",
  "id" : 366419731592388609,
  "in_reply_to_status_id" : 366418266702352384,
  "created_at" : "2013-08-11 04:44:06 +0000",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/366411106748604416\/photo\/1",
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/3OJDhPF1oc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRXA9dPCIAAQwKH.jpg",
      "id_str" : "366411106752798720",
      "id" : 366411106752798720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRXA9dPCIAAQwKH.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/3OJDhPF1oc"
    } ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8348755837, -122.2633296625 ]
  },
  "id_str" : "366411106748604416",
  "text" : "#oakland http:\/\/t.co\/3OJDhPF1oc",
  "id" : 366411106748604416,
  "created_at" : "2013-08-11 04:09:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/vZkBhvG9il",
      "expanded_url" : "http:\/\/flic.kr\/p\/fs68X3",
      "display_url" : "flic.kr\/p\/fs68X3"
    } ]
  },
  "geo" : { },
  "id_str" : "366403449669160960",
  "text" : "8:36pm DATE NIGHT! http:\/\/t.co\/vZkBhvG9il",
  "id" : 366403449669160960,
  "created_at" : "2013-08-11 03:39:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 3, 14 ],
      "id_str" : "8710082",
      "id" : 8710082
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 16, 23 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366402437797527552",
  "text" : "RT @matthickey: @buster Phave. Faiv. Faev.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "366400027238731780",
    "geo" : { },
    "id_str" : "366401694495555584",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster Phave. Faiv. Faev.",
    "id" : 366401694495555584,
    "in_reply_to_status_id" : 366400027238731780,
    "created_at" : "2013-08-11 03:32:26 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "protected" : false,
      "id_str" : "8710082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3459148151\/6249cee5120097d6da19a87465b9a670_normal.png",
      "id" : 8710082,
      "verified" : false
    }
  },
  "id" : 366402437797527552,
  "created_at" : "2013-08-11 03:35:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8349302056, -122.262891125 ]
  },
  "id_str" : "366400027238731780",
  "text" : "Fav this if you spell it \"fav\" and fave this if you spell it \"fave\".",
  "id" : 366400027238731780,
  "created_at" : "2013-08-11 03:25:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 0, 4 ],
      "id_str" : "12720772",
      "id" : 12720772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justmakingsure",
      "indices" : [ 44, 59 ]
    }, {
      "text" : "donthurtme",
      "indices" : [ 60, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366399254631153664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8349334484, -122.2628249073 ]
  },
  "id_str" : "366399834267205633",
  "in_reply_to_user_id" : 12720772,
  "text" : "@gwb Is that a double ragefav or a lovefav? #justmakingsure #donthurtme",
  "id" : 366399834267205633,
  "in_reply_to_status_id" : 366399254631153664,
  "created_at" : "2013-08-11 03:25:02 +0000",
  "in_reply_to_screen_name" : "gwb",
  "in_reply_to_user_id_str" : "12720772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 0, 4 ],
      "id_str" : "12720772",
      "id" : 12720772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366394823609028608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8349752425, -122.2628024825 ]
  },
  "id_str" : "366399090159915010",
  "in_reply_to_user_id" : 12720772,
  "text" : "@gwb Stole it from some kid.",
  "id" : 366399090159915010,
  "in_reply_to_status_id" : 366394823609028608,
  "created_at" : "2013-08-11 03:22:05 +0000",
  "in_reply_to_screen_name" : "gwb",
  "in_reply_to_user_id_str" : "12720772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8348175899, -122.2630773846 ]
  },
  "id_str" : "366390906150060032",
  "text" : "Snapchat me: busterbenson.",
  "id" : 366390906150060032,
  "created_at" : "2013-08-11 02:49:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366344852356603904",
  "text" : "Good times: alone time with self, explore time with new things, quality time with people, flow time with interests, slog time with labor.",
  "id" : 366344852356603904,
  "created_at" : "2013-08-10 23:46:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelsey Falter",
      "screen_name" : "kfalter",
      "indices" : [ 0, 8 ],
      "id_str" : "253578873",
      "id" : 253578873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366325494087565313",
  "in_reply_to_user_id" : 253578873,
  "text" : "@kfalter Wow, super impressed with Poptip. Just tried my first question. Nice work.",
  "id" : 366325494087565313,
  "created_at" : "2013-08-10 22:29:38 +0000",
  "in_reply_to_screen_name" : "kfalter",
  "in_reply_to_user_id_str" : "253578873",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 0, 7 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Poptip",
      "screen_name" : "Poptip",
      "indices" : [ 81, 88 ],
      "id_str" : "332012070",
      "id" : 332012070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/Aj5Qf7ZpTV",
      "expanded_url" : "http:\/\/poptip.com\/buster\/which-word-is-closest-to-how-you-feel-right-now-excited-drained-content-or-anxious",
      "display_url" : "poptip.com\/buster\/which-w\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "366322244999331842",
  "geo" : { },
  "id_str" : "366324260429512705",
  "in_reply_to_user_id" : 2185,
  "text" : "@buster Reply first and see really cool results here: http:\/\/t.co\/Aj5Qf7ZpTV via @Poptip",
  "id" : 366324260429512705,
  "in_reply_to_status_id" : 366322244999331842,
  "created_at" : "2013-08-10 22:24:44 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/poptip.com\" rel=\"nofollow\"\u003EPoptip\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366322244999331842",
  "text" : "Which word is closest to how you feel right now: excited, drained, content, or anxious?",
  "id" : 366322244999331842,
  "created_at" : "2013-08-10 22:16:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan D. Gantz, CPK",
      "screen_name" : "sixfoot6",
      "indices" : [ 3, 12 ],
      "id_str" : "822030",
      "id" : 822030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366317085372059649",
  "text" : "RT @sixfoot6: All You Need Is Love, Plus Food And Water, Which Probably Requires A Job, Which Means You Need An Address, Ugh Now The Gov'me\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "366316493547372546",
    "text" : "All You Need Is Love, Plus Food And Water, Which Probably Requires A Job, Which Means You Need An Address, Ugh Now The Gov'ment Is On You",
    "id" : 366316493547372546,
    "created_at" : "2013-08-10 21:53:52 +0000",
    "user" : {
      "name" : "Ryan D. Gantz, CPK",
      "screen_name" : "sixfoot6",
      "protected" : false,
      "id_str" : "822030",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000829597705\/6bf03b227d7a7b2d405d198cdbb221f0_normal.jpeg",
      "id" : 822030,
      "verified" : false
    }
  },
  "id" : 366317085372059649,
  "created_at" : "2013-08-10 21:56:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Polonca \u0160tritof",
      "screen_name" : "streetof",
      "indices" : [ 0, 9 ],
      "id_str" : "141535924",
      "id" : 141535924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366269094896480256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.858014917, -122.2529864778 ]
  },
  "id_str" : "366278587176861697",
  "in_reply_to_user_id" : 141535924,
  "text" : "@streetof Glad you like the post! How did you find it?",
  "id" : 366278587176861697,
  "in_reply_to_status_id" : 366269094896480256,
  "created_at" : "2013-08-10 19:23:14 +0000",
  "in_reply_to_screen_name" : "streetof",
  "in_reply_to_user_id_str" : "141535924",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    }, {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 12, 17 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366241999466143744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597239871, -122.2754266766 ]
  },
  "id_str" : "366257435373092864",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner @tara omg awesome!",
  "id" : 366257435373092864,
  "in_reply_to_status_id" : 366241999466143744,
  "created_at" : "2013-08-10 17:59:11 +0000",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Brewer",
      "screen_name" : "jbrewer",
      "indices" : [ 3, 11 ],
      "id_str" : "12555",
      "id" : 12555
    }, {
      "name" : "Scott Jenson",
      "screen_name" : "scottjenson",
      "indices" : [ 88, 100 ],
      "id_str" : "730373",
      "id" : 730373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/qQBnDFq6qX",
      "expanded_url" : "http:\/\/jenson.org\/we-need-more-communism\/#more-201",
      "display_url" : "jenson.org\/we-need-more-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "366238587110428672",
  "text" : "RT @jbrewer: \u201CIf we don\u2019t think big, we\u2019re just going to increment ourselves to death.\u201D\u2014@scottjenson \n\nhttp:\/\/t.co\/qQBnDFq6qX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott Jenson",
        "screen_name" : "scottjenson",
        "indices" : [ 75, 87 ],
        "id_str" : "730373",
        "id" : 730373
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/qQBnDFq6qX",
        "expanded_url" : "http:\/\/jenson.org\/we-need-more-communism\/#more-201",
        "display_url" : "jenson.org\/we-need-more-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "366225966231592960",
    "text" : "\u201CIf we don\u2019t think big, we\u2019re just going to increment ourselves to death.\u201D\u2014@scottjenson \n\nhttp:\/\/t.co\/qQBnDFq6qX",
    "id" : 366225966231592960,
    "created_at" : "2013-08-10 15:54:09 +0000",
    "user" : {
      "name" : "Josh Brewer",
      "screen_name" : "jbrewer",
      "protected" : false,
      "id_str" : "12555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000470238857\/de3847a968ebe1c0cb700f4e07356dd3_normal.jpeg",
      "id" : 12555,
      "verified" : false
    }
  },
  "id" : 366238587110428672,
  "created_at" : "2013-08-10 16:44:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VentureBeat",
      "screen_name" : "VentureBeat",
      "indices" : [ 15, 27 ],
      "id_str" : "60642052",
      "id" : 60642052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/BrAGhqWcWt",
      "expanded_url" : "http:\/\/wp.me\/p1re2-3kdj",
      "display_url" : "wp.me\/p1re2-3kdj"
    } ]
  },
  "in_reply_to_status_id_str" : "366216340857552896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859798735, -122.2753331426 ]
  },
  "id_str" : "366218145351995392",
  "in_reply_to_user_id" : 60642052,
  "text" : "I want this RT @VentureBeat: Google launches charity app to funnel $1 at a time toward good causes http:\/\/t.co\/BrAGhqWcWt",
  "id" : 366218145351995392,
  "in_reply_to_status_id" : 366216340857552896,
  "created_at" : "2013-08-10 15:23:04 +0000",
  "in_reply_to_screen_name" : "VentureBeat",
  "in_reply_to_user_id_str" : "60642052",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 3, 14 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/lAQT3yb4F0",
      "expanded_url" : "http:\/\/tmblr.co\/ZgwobyrvyJoy",
      "display_url" : "tmblr.co\/ZgwobyrvyJoy"
    } ]
  },
  "geo" : { },
  "id_str" : "366209228551098369",
  "text" : "RT @seanbonner: Photo: text-mode: ot.pdf. The data of an image in a PDF-book, as represented by text. Made by Holger Friese... http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/lAQT3yb4F0",
        "expanded_url" : "http:\/\/tmblr.co\/ZgwobyrvyJoy",
        "display_url" : "tmblr.co\/ZgwobyrvyJoy"
      } ]
    },
    "geo" : { },
    "id_str" : "366199337853784066",
    "text" : "Photo: text-mode: ot.pdf. The data of an image in a PDF-book, as represented by text. Made by Holger Friese... http:\/\/t.co\/lAQT3yb4F0",
    "id" : 366199337853784066,
    "created_at" : "2013-08-10 14:08:20 +0000",
    "user" : {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "protected" : false,
      "id_str" : "765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416764038962348032\/rQuyO9H-_normal.png",
      "id" : 765,
      "verified" : false
    }
  },
  "id" : 366209228551098369,
  "created_at" : "2013-08-10 14:47:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 29, 33 ],
      "id_str" : "259",
      "id" : 259
    }, {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 38, 45 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/nfbEMgBHrL",
      "expanded_url" : "http:\/\/flic.kr\/p\/fru2mj",
      "display_url" : "flic.kr\/p\/fru2mj"
    } ]
  },
  "geo" : { },
  "id_str" : "366047143758278657",
  "text" : "8:36pm Fun dinner times with @ian and @sharon http:\/\/t.co\/nfbEMgBHrL",
  "id" : 366047143758278657,
  "created_at" : "2013-08-10 04:03:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/366008190221041668\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/PQoktZXsOu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRRSgoOCQAAERMj.jpg",
      "id_str" : "366008190229430272",
      "id" : 366008190229430272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRRSgoOCQAAERMj.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PQoktZXsOu"
    } ],
    "hashtags" : [ {
      "text" : "california",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8057041299, -122.2969988455 ]
  },
  "id_str" : "366008190221041668",
  "text" : "#california http:\/\/t.co\/PQoktZXsOu",
  "id" : 366008190221041668,
  "created_at" : "2013-08-10 01:28:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763991524, -122.4166559615 ]
  },
  "id_str" : "365870970684194816",
  "text" : "\"Elevator H, hotel, on your right, behind you, to floor 9.\" x 10 people going to the same floor.",
  "id" : 365870970684194816,
  "created_at" : "2013-08-09 16:23:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 11, 21 ],
      "id_str" : "7943892",
      "id" : 7943892
    }, {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 22, 32 ],
      "id_str" : "10015122",
      "id" : 10015122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365862679711203328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8026445585, -122.2888990729 ]
  },
  "id_str" : "365864494724952065",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne @ingopixel @andypixel Woah, you're right! Time really has hopped, hasn't it.",
  "id" : 365864494724952065,
  "in_reply_to_status_id" : 365862679711203328,
  "created_at" : "2013-08-09 15:57:47 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/timehop.com\/\" rel=\"nofollow\"\u003ETimehop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    }, {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 11, 21 ],
      "id_str" : "10015122",
      "id" : 10015122
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 26, 36 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/CpScouAzpX",
      "expanded_url" : "http:\/\/t.imehop.com\/1exH1kK",
      "display_url" : "t.imehop.com\/1exH1kK"
    } ]
  },
  "geo" : { },
  "id_str" : "365862015555747840",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel @andypixel and @kellianne in a drunk pile 5 years ago. See you next week! http:\/\/t.co\/CpScouAzpX",
  "id" : 365862015555747840,
  "created_at" : "2013-08-09 15:47:56 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Hayes",
      "screen_name" : "laurenahayes",
      "indices" : [ 21, 34 ],
      "id_str" : "21176973",
      "id" : 21176973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/eqpJmCW9NB",
      "expanded_url" : "http:\/\/huff.to\/1eu5N5l",
      "display_url" : "huff.to\/1eu5N5l"
    } ]
  },
  "in_reply_to_status_id_str" : "365363452191059969",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596767168, -122.2755714837 ]
  },
  "id_str" : "365716570640617472",
  "in_reply_to_user_id" : 21176973,
  "text" : "Such a good idea! RT @laurenahayes: Apple rejects game that measures how high you can throw your phone http:\/\/t.co\/eqpJmCW9NB",
  "id" : 365716570640617472,
  "in_reply_to_status_id" : 365363452191059969,
  "created_at" : "2013-08-09 06:09:59 +0000",
  "in_reply_to_screen_name" : "laurenahayes",
  "in_reply_to_user_id_str" : "21176973",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597154376, -122.2753593699 ]
  },
  "id_str" : "365709348497928194",
  "text" : "Try tweeting when someone's reading over your shoulder. It's not possible.",
  "id" : 365709348497928194,
  "created_at" : "2013-08-09 05:41:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "carlos",
      "screen_name" : "famouscrab",
      "indices" : [ 3, 14 ],
      "id_str" : "385412164",
      "id" : 385412164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365707621925261312",
  "text" : "RT @famouscrab: comedy is all about .....*Really long pause* .......really long pauses",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365703127082610689",
    "text" : "comedy is all about .....*Really long pause* .......really long pauses",
    "id" : 365703127082610689,
    "created_at" : "2013-08-09 05:16:34 +0000",
    "user" : {
      "name" : "carlos",
      "screen_name" : "famouscrab",
      "protected" : false,
      "id_str" : "385412164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3349183341\/2639ed7c4eb6105d5fdef0857d4466fb_normal.jpeg",
      "id" : 385412164,
      "verified" : false
    }
  },
  "id" : 365707621925261312,
  "created_at" : "2013-08-09 05:34:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/zbzIJTYz9o",
      "expanded_url" : "http:\/\/flic.kr\/p\/fqTBZC",
      "display_url" : "flic.kr\/p\/fqTBZC"
    } ]
  },
  "geo" : { },
  "id_str" : "365682665795489792",
  "text" : "8:36pm We're all grouchy ladybugs tonight http:\/\/t.co\/zbzIJTYz9o",
  "id" : 365682665795489792,
  "created_at" : "2013-08-09 03:55:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/XaypBJ0mox",
      "expanded_url" : "https:\/\/vine.co\/v\/hhhwJXAuOHn",
      "display_url" : "vine.co\/v\/hhhwJXAuOHn"
    } ]
  },
  "geo" : { },
  "id_str" : "365681155002994689",
  "text" : "Migraine FTL https:\/\/t.co\/XaypBJ0mox",
  "id" : 365681155002994689,
  "created_at" : "2013-08-09 03:49:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McAllister",
      "screen_name" : "ianmcall",
      "indices" : [ 0, 9 ],
      "id_str" : "2035631",
      "id" : 2035631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365647944126439424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8087108673, -122.2683286624 ]
  },
  "id_str" : "365649132804784129",
  "in_reply_to_user_id" : 2035631,
  "text" : "@ianmcall Better not let your boss find out.",
  "id" : 365649132804784129,
  "in_reply_to_status_id" : 365647944126439424,
  "created_at" : "2013-08-09 01:42:01 +0000",
  "in_reply_to_screen_name" : "ianmcall",
  "in_reply_to_user_id_str" : "2035631",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8041887359, -122.2942423349 ]
  },
  "id_str" : "365647582439018499",
  "text" : "Yeah, well how many slides did *you* make today?",
  "id" : 365647582439018499,
  "created_at" : "2013-08-09 01:35:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 11, 18 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365637189998088193",
  "geo" : { },
  "id_str" : "365637537349386241",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler @isaach Yeah, Twitter mostly, and sometimes Prismatic for random stuff when I'm in the mood.",
  "id" : 365637537349386241,
  "in_reply_to_status_id" : 365637189998088193,
  "created_at" : "2013-08-09 00:55:56 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 11, 18 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neverlookback",
      "indices" : [ 26, 40 ]
    }, {
      "text" : "nofomo",
      "indices" : [ 41, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365637077620105216",
  "geo" : { },
  "id_str" : "365637214547357697",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler @isaach DO IT. #neverlookback #nofomo",
  "id" : 365637214547357697,
  "in_reply_to_status_id" : 365637077620105216,
  "created_at" : "2013-08-09 00:54:39 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 11, 18 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365636751143874562",
  "geo" : { },
  "id_str" : "365636916604973056",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler @isaach Nope. Gave that up a while ago.",
  "id" : 365636916604973056,
  "in_reply_to_status_id" : 365636751143874562,
  "created_at" : "2013-08-09 00:53:28 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/frontback.me\" rel=\"nofollow\"\u003EFrontback\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/365497368386342912\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/bmwZ5SvaLf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRKB64mCEAIRz_F.jpg",
      "id_str" : "365497368394731522",
      "id" : 365497368394731522,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRKB64mCEAIRz_F.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1096,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 582,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1096,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1028,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/bmwZ5SvaLf"
    } ],
    "hashtags" : [ {
      "text" : "frontback",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/gMOvqUHcwY",
      "expanded_url" : "http:\/\/frontback.me\/r\/tw",
      "display_url" : "frontback.me\/r\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "365497368386342912",
  "text" : "Just setting up my frontback http:\/\/t.co\/gMOvqUHcwY #frontback http:\/\/t.co\/bmwZ5SvaLf",
  "id" : 365497368386342912,
  "created_at" : "2013-08-08 15:38:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mat honan",
      "screen_name" : "mat",
      "indices" : [ 30, 34 ],
      "id_str" : "11113",
      "id" : 11113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/nlYSKMgsbh",
      "expanded_url" : "http:\/\/www.wired.com\/gadgetlab\/2013\/08\/why-vine-just-wont-die\/",
      "display_url" : "wired.com\/gadgetlab\/2013\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "365489594822696960",
  "geo" : { },
  "id_str" : "365489866181578755",
  "in_reply_to_user_id" : 11113,
  "text" : "This has been fun to watch RT @mat: Why Vine keeps growing, despite Instagram's Big Numbers http:\/\/t.co\/nlYSKMgsbh",
  "id" : 365489866181578755,
  "in_reply_to_status_id" : 365489594822696960,
  "created_at" : "2013-08-08 15:09:09 +0000",
  "in_reply_to_screen_name" : "mat",
  "in_reply_to_user_id_str" : "11113",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "indices" : [ 3, 14 ],
      "id_str" : "419710142",
      "id" : 419710142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/0lqeXfbOaH",
      "expanded_url" : "http:\/\/pndo.ly\/14ocsfJ",
      "display_url" : "pndo.ly\/14ocsfJ"
    } ]
  },
  "geo" : { },
  "id_str" : "365489251426643969",
  "text" : "RT @PandoDaily: Next time you lose your keys, you'll probably wish you'd signed up for KeyMe: http:\/\/t.co\/0lqeXfbOaH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/0lqeXfbOaH",
        "expanded_url" : "http:\/\/pndo.ly\/14ocsfJ",
        "display_url" : "pndo.ly\/14ocsfJ"
      } ]
    },
    "geo" : { },
    "id_str" : "365485836067799041",
    "text" : "Next time you lose your keys, you'll probably wish you'd signed up for KeyMe: http:\/\/t.co\/0lqeXfbOaH",
    "id" : 365485836067799041,
    "created_at" : "2013-08-08 14:53:08 +0000",
    "user" : {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "protected" : false,
      "id_str" : "419710142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1764819620\/Pando_Twitter_Logo_normal.jpg",
      "id" : 419710142,
      "verified" : false
    }
  },
  "id" : 365489251426643969,
  "created_at" : "2013-08-08 15:06:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Valenti IV",
      "screen_name" : "VALENTI",
      "indices" : [ 0, 8 ],
      "id_str" : "218558150",
      "id" : 218558150
    }, {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 9, 17 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 18, 27 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365478196323426306",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595782258, -122.275409677 ]
  },
  "id_str" : "365486778355957760",
  "in_reply_to_user_id" : 218558150,
  "text" : "@VALENTI @rsarver @RickWebb Can someone build a 6 degrees of Rick Webb app for this event?",
  "id" : 365486778355957760,
  "in_reply_to_status_id" : 365478196323426306,
  "created_at" : "2013-08-08 14:56:53 +0000",
  "in_reply_to_screen_name" : "VALENTI",
  "in_reply_to_user_id_str" : "218558150",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark S. Luckie  \u261C",
      "screen_name" : "marksluckie",
      "indices" : [ 29, 41 ],
      "id_str" : "27261369",
      "id" : 27261369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/OiO4uzrP6k",
      "expanded_url" : "https:\/\/blog.twitter.com\/2013\/behind-the-numbers-how-to-understand-big-moments-on-twitter",
      "display_url" : "blog.twitter.com\/2013\/behind-th\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "365480848599941120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597367509, -122.2754091828 ]
  },
  "id_str" : "365485293199048705",
  "in_reply_to_user_id" : 27261369,
  "text" : "All big numbers look same RT @marksluckie: How to put Twitter numbers and tweet counts into perspective: https:\/\/t.co\/OiO4uzrP6k",
  "id" : 365485293199048705,
  "in_reply_to_status_id" : 365480848599941120,
  "created_at" : "2013-08-08 14:50:58 +0000",
  "in_reply_to_screen_name" : "marksluckie",
  "in_reply_to_user_id_str" : "27261369",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "megan hunt",
      "screen_name" : "lasertron",
      "indices" : [ 53, 63 ],
      "id_str" : "17915737",
      "id" : 17915737
    }, {
      "name" : "Amber Eeeeeee",
      "screen_name" : "rare_basement",
      "indices" : [ 64, 78 ],
      "id_str" : "30957285",
      "id" : 30957285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365364487290748931",
  "geo" : { },
  "id_str" : "365365543198400513",
  "in_reply_to_user_id" : 17915737,
  "text" : "How Online Diaries Changed The World [SLIDESHOW] \/cc @lasertron @rare_basement",
  "id" : 365365543198400513,
  "in_reply_to_status_id" : 365364487290748931,
  "created_at" : "2013-08-08 06:55:08 +0000",
  "in_reply_to_screen_name" : "lasertron",
  "in_reply_to_user_id_str" : "17915737",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365364461697118208",
  "geo" : { },
  "id_str" : "365365072014479360",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker Still probably worth a blog post though. PS. I'm still reeling from your Elephants post. Haven't had a chance to respond yet.",
  "id" : 365365072014479360,
  "in_reply_to_status_id" : 365364461697118208,
  "created_at" : "2013-08-08 06:53:15 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365364461697118208",
  "geo" : { },
  "id_str" : "365364950413213696",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker I can confabulate a reason, but the theory wouldn't be repeatable or predictable in any other set of circumstances.",
  "id" : 365364950413213696,
  "in_reply_to_status_id" : 365364461697118208,
  "created_at" : "2013-08-08 06:52:46 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 10, 22 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365354224629977089",
  "geo" : { },
  "id_str" : "365354398379028481",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @nickcrocker Someone should start one of those things up.",
  "id" : 365354398379028481,
  "in_reply_to_status_id" : 365354224629977089,
  "created_at" : "2013-08-08 06:10:51 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365352363839590401",
  "geo" : { },
  "id_str" : "365352907475918848",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker Yeah, it's a complete mystery to me why that was the one habit that has stuck longest. :)",
  "id" : 365352907475918848,
  "in_reply_to_status_id" : 365352363839590401,
  "created_at" : "2013-08-08 06:04:55 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 0, 10 ],
      "id_str" : "13349",
      "id" : 13349
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 11, 20 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 21, 30 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365347639224578048",
  "geo" : { },
  "id_str" : "365347832842043393",
  "in_reply_to_user_id" : 13349,
  "text" : "@ryanchris @anildash @rickwebb From this thread I can't tell who's on what side, so I think you all agree.",
  "id" : 365347832842043393,
  "in_reply_to_status_id" : 365347639224578048,
  "created_at" : "2013-08-08 05:44:45 +0000",
  "in_reply_to_screen_name" : "ryanchris",
  "in_reply_to_user_id_str" : "13349",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelsey Falter",
      "screen_name" : "kfalter",
      "indices" : [ 0, 8 ],
      "id_str" : "253578873",
      "id" : 253578873
    }, {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 9, 17 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 82, 91 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365306637323481091",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596566804, -122.2754361482 ]
  },
  "id_str" : "365331173049778176",
  "in_reply_to_user_id" : 253578873,
  "text" : "@kfalter @rsarver Might be possible! We'll be in Williamsburg for our good friend @rickwebb's wedding.",
  "id" : 365331173049778176,
  "in_reply_to_status_id" : 365306637323481091,
  "created_at" : "2013-08-08 04:38:33 +0000",
  "in_reply_to_screen_name" : "kfalter",
  "in_reply_to_user_id_str" : "253578873",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/lf66ZVlgye",
      "expanded_url" : "http:\/\/flic.kr\/p\/fqj1RG",
      "display_url" : "flic.kr\/p\/fqj1RG"
    } ]
  },
  "geo" : { },
  "id_str" : "365330458239713281",
  "text" : "8:36pm Fell asleep with this guy http:\/\/t.co\/lf66ZVlgye",
  "id" : 365330458239713281,
  "created_at" : "2013-08-08 04:35:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Morga",
      "screen_name" : "AliciaMorga",
      "indices" : [ 0, 12 ],
      "id_str" : "19053875",
      "id" : 19053875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365250882767552512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769380087, -122.4168762103 ]
  },
  "id_str" : "365254985002397696",
  "in_reply_to_user_id" : 19053875,
  "text" : "@AliciaMorga Gotta keep it fresh. :)",
  "id" : 365254985002397696,
  "in_reply_to_status_id" : 365250882767552512,
  "created_at" : "2013-08-07 23:35:49 +0000",
  "in_reply_to_screen_name" : "AliciaMorga",
  "in_reply_to_user_id_str" : "19053875",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365214380100562945",
  "geo" : { },
  "id_str" : "365216779947094016",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler Definitely! We're about to head to NYC for a couple weeks but let's plan it shortly thereafter!",
  "id" : 365216779947094016,
  "in_reply_to_status_id" : 365214380100562945,
  "created_at" : "2013-08-07 21:04:00 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 46, 56 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/365215993007587328\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/nv4Rr7hn5K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRGCAoYCIAAD8K7.jpg",
      "id_str" : "365215992143552512",
      "id" : 365215992143552512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRGCAoYCIAAD8K7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/nv4Rr7hn5K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763638372, -122.4174002663 ]
  },
  "id_str" : "365215993007587328",
  "text" : "Got a tour of the Twitter Command Center from @jayholler. T'was cooler than it seems. http:\/\/t.co\/nv4Rr7hn5K",
  "id" : 365215993007587328,
  "created_at" : "2013-08-07 21:00:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 3, 8 ],
      "id_str" : "418",
      "id" : 418
    }, {
      "name" : "Fast Company",
      "screen_name" : "FastCompany",
      "indices" : [ 116, 128 ],
      "id_str" : "2735591",
      "id" : 2735591
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 140, 143 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/OTq695ZHXE",
      "expanded_url" : "http:\/\/dashes.com\/anil\/2013\/08\/on-location-with-foursquare.html",
      "display_url" : "dashes.com\/anil\/2013\/08\/o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365121062532423680",
  "text" : "RT @dens: \"On Location with Foursquare\" - by Anil Dash http:\/\/t.co\/OTq695ZHXE &lt;- great follow-up post to the 4SQ @FastCompany article by @a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fast Company",
        "screen_name" : "FastCompany",
        "indices" : [ 106, 118 ],
        "id_str" : "2735591",
        "id" : 2735591
      }, {
        "name" : "Anil Dash",
        "screen_name" : "anildash",
        "indices" : [ 130, 139 ],
        "id_str" : "36823",
        "id" : 36823
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/OTq695ZHXE",
        "expanded_url" : "http:\/\/dashes.com\/anil\/2013\/08\/on-location-with-foursquare.html",
        "display_url" : "dashes.com\/anil\/2013\/08\/o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365116386579718145",
    "text" : "\"On Location with Foursquare\" - by Anil Dash http:\/\/t.co\/OTq695ZHXE &lt;- great follow-up post to the 4SQ @FastCompany article by @anildash",
    "id" : 365116386579718145,
    "created_at" : "2013-08-07 14:25:04 +0000",
    "user" : {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "protected" : false,
      "id_str" : "418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3180393492\/9236f9d84c75e755a98de9d67f8d1460_normal.jpeg",
      "id" : 418,
      "verified" : true
    }
  },
  "id" : 365121062532423680,
  "created_at" : "2013-08-07 14:43:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Chang",
      "screen_name" : "emilychangtv",
      "indices" : [ 3, 16 ],
      "id_str" : "74130577",
      "id" : 74130577
    }, {
      "name" : "Om Malik",
      "screen_name" : "om",
      "indices" : [ 80, 83 ],
      "id_str" : "989",
      "id" : 989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/79jEvJ5TKL",
      "expanded_url" : "http:\/\/gigaom.com\/2013\/08\/06\/a-new-babylon-and-the-rise-of-the-tech-tycoon\/",
      "display_url" : "gigaom.com\/2013\/08\/06\/a-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365118382598668289",
  "text" : "RT @emilychangtv: Jeff Bezos: The rise of a new Babylon &amp; a tech tycoon, by @om  http:\/\/t.co\/79jEvJ5TKL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Om Malik",
        "screen_name" : "om",
        "indices" : [ 62, 65 ],
        "id_str" : "989",
        "id" : 989
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/79jEvJ5TKL",
        "expanded_url" : "http:\/\/gigaom.com\/2013\/08\/06\/a-new-babylon-and-the-rise-of-the-tech-tycoon\/",
        "display_url" : "gigaom.com\/2013\/08\/06\/a-n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365114400346083328",
    "text" : "Jeff Bezos: The rise of a new Babylon &amp; a tech tycoon, by @om  http:\/\/t.co\/79jEvJ5TKL",
    "id" : 365114400346083328,
    "created_at" : "2013-08-07 14:17:11 +0000",
    "user" : {
      "name" : "Emily Chang",
      "screen_name" : "emilychangtv",
      "protected" : false,
      "id_str" : "74130577",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1153501347\/emily-chang_normal.jpg",
      "id" : 74130577,
      "verified" : true
    }
  },
  "id" : 365118382598668289,
  "created_at" : "2013-08-07 14:33:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Pickard",
      "screen_name" : "megpickard",
      "indices" : [ 3, 14 ],
      "id_str" : "20056740",
      "id" : 20056740
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/megpickard\/status\/365106723515682816\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/F4p4s3DYrV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BREeoXDCUAAkW9L.png",
      "id_str" : "365106723524071424",
      "id" : 365106723524071424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BREeoXDCUAAkW9L.png",
      "sizes" : [ {
        "h" : 451,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 770,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 899,
        "resize" : "fit",
        "w" : 1196
      } ],
      "display_url" : "pic.twitter.com\/F4p4s3DYrV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365113458435440641",
  "text" : "RT @megpickard: Ever noticed how viral videos\/links spread out across the social web like a Tsunami, or nuclear fallout? Here's a map http:\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/megpickard\/status\/365106723515682816\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/F4p4s3DYrV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BREeoXDCUAAkW9L.png",
        "id_str" : "365106723524071424",
        "id" : 365106723524071424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BREeoXDCUAAkW9L.png",
        "sizes" : [ {
          "h" : 451,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 256,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 770,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 899,
          "resize" : "fit",
          "w" : 1196
        } ],
        "display_url" : "pic.twitter.com\/F4p4s3DYrV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365106723515682816",
    "text" : "Ever noticed how viral videos\/links spread out across the social web like a Tsunami, or nuclear fallout? Here's a map http:\/\/t.co\/F4p4s3DYrV",
    "id" : 365106723515682816,
    "created_at" : "2013-08-07 13:46:41 +0000",
    "user" : {
      "name" : "Meg Pickard",
      "screen_name" : "megpickard",
      "protected" : false,
      "id_str" : "20056740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000679671944\/05457b490ab13373c07d187450e6071b_normal.jpeg",
      "id" : 20056740,
      "verified" : false
    }
  },
  "id" : 365113458435440641,
  "created_at" : "2013-08-07 14:13:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365009423128723457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597215563, -122.275615018 ]
  },
  "id_str" : "365012214404485120",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel So amazing! Especially that tall crazy lady.",
  "id" : 365012214404485120,
  "in_reply_to_status_id" : 365009423128723457,
  "created_at" : "2013-08-07 07:31:08 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/8ggh6hZMvG",
      "expanded_url" : "http:\/\/youtu.be\/xMG2oNqBy-Y",
      "display_url" : "youtu.be\/xMG2oNqBy-Y"
    } ]
  },
  "geo" : { },
  "id_str" : "365003654132015104",
  "text" : "Have to tweet it even though I'm late: JAY Z \"Picasso Baby\" http:\/\/t.co\/8ggh6hZMvG",
  "id" : 365003654132015104,
  "created_at" : "2013-08-07 06:57:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelsey Falter",
      "screen_name" : "kfalter",
      "indices" : [ 0, 8 ],
      "id_str" : "253578873",
      "id" : 253578873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364970662772744193",
  "geo" : { },
  "id_str" : "364983289699774464",
  "in_reply_to_user_id" : 253578873,
  "text" : "@kfalter I think it's a pretty clever way to help everyone get used to change before unveiling it. PS. Ooh, what are you launching?",
  "id" : 364983289699774464,
  "in_reply_to_status_id" : 364970662772744193,
  "created_at" : "2013-08-07 05:36:11 +0000",
  "in_reply_to_screen_name" : "kfalter",
  "in_reply_to_user_id_str" : "253578873",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 3, 12 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/5XW6FgS306",
      "expanded_url" : "https:\/\/www.facebook.com\/facebookforbusiness\/news\/News-Feed-FYI-A-Window-Into-News-Feed",
      "display_url" : "facebook.com\/facebookforbus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364968882492030977",
  "text" : "RT @facebook: We\u2019re announcing a new blog series to highlight major updates to News Feed and explain the thinking behind them. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/5XW6FgS306",
        "expanded_url" : "https:\/\/www.facebook.com\/facebookforbusiness\/news\/News-Feed-FYI-A-Window-Into-News-Feed",
        "display_url" : "facebook.com\/facebookforbus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "364808950278914048",
    "text" : "We\u2019re announcing a new blog series to highlight major updates to News Feed and explain the thinking behind them. https:\/\/t.co\/5XW6FgS306",
    "id" : 364808950278914048,
    "created_at" : "2013-08-06 18:03:26 +0000",
    "user" : {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "protected" : false,
      "id_str" : "2425151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3513354941\/24aaffa670e634a7da9a087bfa83abe6_normal.png",
      "id" : 2425151,
      "verified" : true
    }
  },
  "id" : 364968882492030977,
  "created_at" : "2013-08-07 04:38:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yahoooooo",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/eUcx6sL271",
      "expanded_url" : "http:\/\/thenextweb.com\/insider\/2013\/08\/07\/yahoo-is-getting-a-new-logo-but-its-keeping-its-infamous-exclamation-mark\/",
      "display_url" : "thenextweb.com\/insider\/2013\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595852655, -122.2756453586 ]
  },
  "id_str" : "364968567919222784",
  "text" : "30 days of Yahoo logos before they unveil the real new one. #yahoooooo! http:\/\/t.co\/eUcx6sL271",
  "id" : 364968567919222784,
  "created_at" : "2013-08-07 04:37:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 0, 4 ],
      "id_str" : "12720772",
      "id" : 12720772
    }, {
      "name" : "Expensify",
      "screen_name" : "expensify",
      "indices" : [ 12, 22 ],
      "id_str" : "18461565",
      "id" : 18461565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364932783463866370",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596698116, -122.2756831726 ]
  },
  "id_str" : "364966970770206720",
  "in_reply_to_user_id" : 12720772,
  "text" : "@gwb +1 for @expensify. Used them during my last startup and it did things well. There may be better ones created in the last year though.",
  "id" : 364966970770206720,
  "in_reply_to_status_id" : 364932783463866370,
  "created_at" : "2013-08-07 04:31:21 +0000",
  "in_reply_to_screen_name" : "gwb",
  "in_reply_to_user_id_str" : "12720772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 17, 27 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yum",
      "indices" : [ 98, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/YMjDefYM40",
      "expanded_url" : "http:\/\/flic.kr\/p\/fpq386",
      "display_url" : "flic.kr\/p\/fpq386"
    } ]
  },
  "geo" : { },
  "id_str" : "364954015584362497",
  "text" : "8:36pm Convinced @kellianne we needed another piece of this so I could take my 8:36 picture of it #yum http:\/\/t.co\/YMjDefYM40",
  "id" : 364954015584362497,
  "created_at" : "2013-08-07 03:39:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 0, 4 ],
      "id_str" : "12720772",
      "id" : 12720772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364940560039034881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859702278, -122.275514016 ]
  },
  "id_str" : "364945144681730048",
  "in_reply_to_user_id" : 12720772,
  "text" : "@gwb For better and for worse til crash do us part.",
  "id" : 364945144681730048,
  "in_reply_to_status_id" : 364940560039034881,
  "created_at" : "2013-08-07 03:04:37 +0000",
  "in_reply_to_screen_name" : "gwb",
  "in_reply_to_user_id_str" : "12720772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8573477384, -122.2684830054 ]
  },
  "id_str" : "364941883228696576",
  "text" : "Cute old Berkeley Bowl ladies who sneak 35 items in the 12 items or less lane because they're small items.",
  "id" : 364941883228696576,
  "created_at" : "2013-08-07 02:51:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/364938702654423040\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/AHVSgxq0Ht",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRCF0QjCQAExeFw.jpg",
      "id_str" : "364938702658617345",
      "id" : 364938702658617345,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRCF0QjCQAExeFw.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/AHVSgxq0Ht"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8571125633, -122.2675513757 ]
  },
  "id_str" : "364938702654423040",
  "text" : "I often play a dog on Instagram http:\/\/t.co\/AHVSgxq0Ht",
  "id" : 364938702654423040,
  "created_at" : "2013-08-07 02:39:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "longreads",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/5IzGHyK8np",
      "expanded_url" : "http:\/\/pocket.co\/sPT23",
      "display_url" : "pocket.co\/sPT23"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.819012, -122.27016 ]
  },
  "id_str" : "364932290473758721",
  "text" : "I &lt;3 the Pixar Theory. Took me a while to read though. #longreads http:\/\/t.co\/5IzGHyK8np",
  "id" : 364932290473758721,
  "created_at" : "2013-08-07 02:13:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Abrams",
      "screen_name" : "MrAaronAbrams",
      "indices" : [ 3, 17 ],
      "id_str" : "547068965",
      "id" : 547068965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364926069360443392",
  "text" : "RT @MrAaronAbrams: So wait are \"bros\" what \"hipsters\"call normal guys or are \"hipsters\" what \"bros\" call normal guys or both or neither als\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364802098988191744",
    "text" : "So wait are \"bros\" what \"hipsters\"call normal guys or are \"hipsters\" what \"bros\" call normal guys or both or neither also what is this life.",
    "id" : 364802098988191744,
    "created_at" : "2013-08-06 17:36:12 +0000",
    "user" : {
      "name" : "Aaron Abrams",
      "screen_name" : "MrAaronAbrams",
      "protected" : false,
      "id_str" : "547068965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000070978227\/f88c7c4e5c28a5db07e76176b30f7f65_normal.jpeg",
      "id" : 547068965,
      "verified" : true
    }
  },
  "id" : 364926069360443392,
  "created_at" : "2013-08-07 01:48:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Stamatiou",
      "screen_name" : "Stammy",
      "indices" : [ 3, 10 ],
      "id_str" : "624683",
      "id" : 624683
    }, {
      "name" : "Yuriy Rzhemovskiy",
      "screen_name" : "yuriyr",
      "indices" : [ 31, 38 ],
      "id_str" : "45027998",
      "id" : 45027998
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 39, 46 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Dom Hofmann",
      "screen_name" : "dhof",
      "indices" : [ 47, 52 ],
      "id_str" : "13258512",
      "id" : 13258512
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Stammy\/status\/364863900094693377\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/o2s1JfIpjZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRBByJwCUAAfTEK.jpg",
      "id_str" : "364863899683672064",
      "id" : 364863899683672064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRBByJwCUAAfTEK.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/o2s1JfIpjZ"
    } ],
    "hashtags" : [ {
      "text" : "greatmindsthinkalike",
      "indices" : [ 106, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364869310717497344",
  "text" : "RT @Stammy: In a meeting where @yuriyr @buster @dhof and I are all wearing the same gray  button-up shirt #greatmindsthinkalike http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yuriy Rzhemovskiy",
        "screen_name" : "yuriyr",
        "indices" : [ 19, 26 ],
        "id_str" : "45027998",
        "id" : 45027998
      }, {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 27, 34 ],
        "id_str" : "2185",
        "id" : 2185
      }, {
        "name" : "Dom Hofmann",
        "screen_name" : "dhof",
        "indices" : [ 35, 40 ],
        "id_str" : "13258512",
        "id" : 13258512
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Stammy\/status\/364863900094693377\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/o2s1JfIpjZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRBByJwCUAAfTEK.jpg",
        "id_str" : "364863899683672064",
        "id" : 364863899683672064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRBByJwCUAAfTEK.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/o2s1JfIpjZ"
      } ],
      "hashtags" : [ {
        "text" : "greatmindsthinkalike",
        "indices" : [ 94, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7763567, -122.4167914 ]
    },
    "id_str" : "364863900094693377",
    "text" : "In a meeting where @yuriyr @buster @dhof and I are all wearing the same gray  button-up shirt #greatmindsthinkalike http:\/\/t.co\/o2s1JfIpjZ",
    "id" : 364863900094693377,
    "created_at" : "2013-08-06 21:41:47 +0000",
    "user" : {
      "name" : "Paul Stamatiou",
      "screen_name" : "Stammy",
      "protected" : false,
      "id_str" : "624683",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1778867511\/Screen_Shot_2012-01-24_at_2.03.52_PM_normal.png",
      "id" : 624683,
      "verified" : false
    }
  },
  "id" : 364869310717497344,
  "created_at" : "2013-08-06 22:03:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 24, 31 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/tQGGulpgaj",
      "expanded_url" : "http:\/\/torrez.org\/the-reader-meter.html",
      "display_url" : "torrez.org\/the-reader-met\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "364806408455196673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7766038896, -122.4173606491 ]
  },
  "id_str" : "364828849785151488",
  "in_reply_to_user_id" : 11604,
  "text" : "This is a cool idea: RT @torrez: Here is a post I just did about micro payments. http:\/\/t.co\/tQGGulpgaj",
  "id" : 364828849785151488,
  "in_reply_to_status_id" : 364806408455196673,
  "created_at" : "2013-08-06 19:22:30 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/timehop.com\/\" rel=\"nofollow\"\u003ETimehop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/HznIHMEKhJ",
      "expanded_url" : "http:\/\/t.imehop.com\/188gusL",
      "display_url" : "t.imehop.com\/188gusL"
    } ]
  },
  "geo" : { },
  "id_str" : "364828062031953923",
  "text" : "Because this is what the internet was built for http:\/\/t.co\/HznIHMEKhJ",
  "id" : 364828062031953923,
  "created_at" : "2013-08-06 19:19:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenn Van Grove",
      "screen_name" : "jbruin",
      "indices" : [ 0, 7 ],
      "id_str" : "6193182",
      "id" : 6193182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364824405689384962",
  "geo" : { },
  "id_str" : "364824775706685440",
  "in_reply_to_user_id" : 6193182,
  "text" : "@jbruin Can you email me a screenshot and details to buster@twitter.com - I'll file a bug if it's not a known problem yet.",
  "id" : 364824775706685440,
  "in_reply_to_status_id" : 364824405689384962,
  "created_at" : "2013-08-06 19:06:19 +0000",
  "in_reply_to_screen_name" : "jbruin",
  "in_reply_to_user_id_str" : "6193182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenn Van Grove",
      "screen_name" : "jbruin",
      "indices" : [ 0, 7 ],
      "id_str" : "6193182",
      "id" : 6193182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364823813369769984",
  "geo" : { },
  "id_str" : "364824146649157633",
  "in_reply_to_user_id" : 6193182,
  "text" : "@jbruin What's broken for you?",
  "id" : 364824146649157633,
  "in_reply_to_status_id" : 364823813369769984,
  "created_at" : "2013-08-06 19:03:49 +0000",
  "in_reply_to_screen_name" : "jbruin",
  "in_reply_to_user_id_str" : "6193182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poonam Mathur",
      "screen_name" : "pmathur13",
      "indices" : [ 0, 10 ],
      "id_str" : "17458054",
      "id" : 17458054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364814128948322304",
  "geo" : { },
  "id_str" : "364814323832459265",
  "in_reply_to_user_id" : 17458054,
  "text" : "@pmathur13 Only the best people use lists. :)",
  "id" : 364814323832459265,
  "in_reply_to_status_id" : 364814128948322304,
  "created_at" : "2013-08-06 18:24:47 +0000",
  "in_reply_to_screen_name" : "pmathur13",
  "in_reply_to_user_id_str" : "17458054",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/w1Do7MwTvC",
      "expanded_url" : "https:\/\/blog.twitter.com\/2013\/improvements-to-login-verification-photos-and-more",
      "display_url" : "blog.twitter.com\/2013\/improveme\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364812630168322049",
  "text" : "Hidden at the bottom of the notes for what's in the latest Twitter iPhone app is that you can manage Lists again! https:\/\/t.co\/w1Do7MwTvC",
  "id" : 364812630168322049,
  "created_at" : "2013-08-06 18:18:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 17, 22 ],
      "id_str" : "418",
      "id" : 418
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 27, 38 ],
      "id_str" : "14120151",
      "id" : 14120151
    }, {
      "name" : "Austin Carr",
      "screen_name" : "AustinCarr",
      "indices" : [ 83, 94 ],
      "id_str" : "225847395",
      "id" : 225847395
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foursquare4lyfe",
      "indices" : [ 39, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/3IZVbL0AID",
      "expanded_url" : "http:\/\/www.fastcompany.com\/3014821\/will-foursquare-ceo-dennis-crowley-finally-get-it-right",
      "display_url" : "fastcompany.com\/3014821\/will-f\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "364735032117563393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8430722887, -122.2704676074 ]
  },
  "id_str" : "364787253882519553",
  "in_reply_to_user_id" : 225847395,
  "text" : "Great article on @dens and @foursquare #foursquare4lyfe http:\/\/t.co\/3IZVbL0AID \/by @AustinCarr",
  "id" : 364787253882519553,
  "in_reply_to_status_id" : 364735032117563393,
  "created_at" : "2013-08-06 16:37:13 +0000",
  "in_reply_to_screen_name" : "AustinCarr",
  "in_reply_to_user_id_str" : "225847395",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364677155323514882",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596343845, -122.2754815781 ]
  },
  "id_str" : "364757982434689028",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar Holy macaroni!",
  "id" : 364757982434689028,
  "in_reply_to_status_id" : 364677155323514882,
  "created_at" : "2013-08-06 14:40:54 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364627954917048320",
  "geo" : { },
  "id_str" : "364628385957298176",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne Yeah, it's cool tech. :)",
  "id" : 364628385957298176,
  "in_reply_to_status_id" : 364627954917048320,
  "created_at" : "2013-08-06 06:05:56 +0000",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/0wlZkr0c9V",
      "expanded_url" : "http:\/\/fcc.us\/1903whD",
      "display_url" : "fcc.us\/1903whD"
    } ]
  },
  "geo" : { },
  "id_str" : "364627414476791808",
  "text" : "Information on what Wireless Emergency Alerts are and how they work: http:\/\/t.co\/0wlZkr0c9V",
  "id" : 364627414476791808,
  "created_at" : "2013-08-06 06:02:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/ASHhArM891",
      "expanded_url" : "http:\/\/flic.kr\/p\/fp5GLC",
      "display_url" : "flic.kr\/p\/fp5GLC"
    } ]
  },
  "geo" : { },
  "id_str" : "364626958555947008",
  "text" : "Getting the alert is as scary as the threat. Apparently it's an FCC-mandated cell phone alert system. Who sends it? http:\/\/t.co\/ASHhArM891",
  "id" : 364626958555947008,
  "created_at" : "2013-08-06 06:00:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 17, 26 ],
      "id_str" : "2391",
      "id" : 2391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/uN2OzcKZQ9",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/danielwcarlson\/13-benedict-cumberbatch-gifs-that-are-all-the-same-d62y",
      "display_url" : "buzzfeed.com\/danielwcarlson\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364620763489243139",
  "text" : "I am changed. RT @mulegirl: Buzzfeed may have just crossed over into genius. \nhttp:\/\/t.co\/uN2OzcKZQ9",
  "id" : 364620763489243139,
  "created_at" : "2013-08-06 05:35:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364614298443591680",
  "geo" : { },
  "id_str" : "364615503425187842",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel I'm definitely not a collector. So... STICKING!",
  "id" : 364615503425187842,
  "in_reply_to_status_id" : 364614298443591680,
  "created_at" : "2013-08-06 05:14:44 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan Donohoe",
      "screen_name" : "bdonohoe",
      "indices" : [ 0, 9 ],
      "id_str" : "1193421",
      "id" : 1193421
    }, {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 10, 17 ],
      "id_str" : "23640904",
      "id" : 23640904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364598949564264451",
  "geo" : { },
  "id_str" : "364603151023747075",
  "in_reply_to_user_id" : 1193421,
  "text" : "@bdonohoe @emoore All of the above. And live tweet it for those of us still sitting on our asses.",
  "id" : 364603151023747075,
  "in_reply_to_status_id" : 364598949564264451,
  "created_at" : "2013-08-06 04:25:39 +0000",
  "in_reply_to_screen_name" : "bdonohoe",
  "in_reply_to_user_id_str" : "1193421",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/cYBm9ZDIUk",
      "expanded_url" : "http:\/\/flic.kr\/p\/fp3nZS",
      "display_url" : "flic.kr\/p\/fp3nZS"
    } ]
  },
  "geo" : { },
  "id_str" : "364598944036171778",
  "text" : "8:36pm Niko's helping the last of the bath water down the drain http:\/\/t.co\/cYBm9ZDIUk",
  "id" : 364598944036171778,
  "created_at" : "2013-08-06 04:08:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859702278, -122.2755592783 ]
  },
  "id_str" : "364579531631239169",
  "text" : "Confession: I just enjoyed stickers.",
  "id" : 364579531631239169,
  "created_at" : "2013-08-06 02:51:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364539938143875072",
  "geo" : { },
  "id_str" : "364543948930297857",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar Holy sweet jacket and necklace there, Chris!",
  "id" : 364543948930297857,
  "in_reply_to_status_id" : 364539938143875072,
  "created_at" : "2013-08-06 00:30:24 +0000",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "indices" : [ 50, 63 ],
      "id_str" : "174958347",
      "id" : 174958347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/QjAHB1Mchl",
      "expanded_url" : "https:\/\/medium.com\/how-to-use-the-internet\/7e3b7130f131",
      "display_url" : "medium.com\/how-to-use-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364525510178508800",
  "text" : "Happy 3rd birthday to Twitter's favorite spambot, @horse_ebooks https:\/\/t.co\/QjAHB1Mchl",
  "id" : 364525510178508800,
  "created_at" : "2013-08-05 23:17:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "steve blank",
      "screen_name" : "sgblank",
      "indices" : [ 3, 11 ],
      "id_str" : "22747624",
      "id" : 22747624
    }, {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 68, 72 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/dlzWnnp5al",
      "expanded_url" : "http:\/\/on.wsj.com\/19IIO94",
      "display_url" : "on.wsj.com\/19IIO94"
    } ]
  },
  "geo" : { },
  "id_str" : "364509233523343360",
  "text" : "RT @sgblank: The Curse of a New Building http:\/\/t.co\/dlzWnnp5al via @WSJ  Happens every time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wall Street Journal",
        "screen_name" : "WSJ",
        "indices" : [ 55, 59 ],
        "id_str" : "3108351",
        "id" : 3108351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/dlzWnnp5al",
        "expanded_url" : "http:\/\/on.wsj.com\/19IIO94",
        "display_url" : "on.wsj.com\/19IIO94"
      } ]
    },
    "geo" : { },
    "id_str" : "364504586985291777",
    "text" : "The Curse of a New Building http:\/\/t.co\/dlzWnnp5al via @WSJ  Happens every time.",
    "id" : 364504586985291777,
    "created_at" : "2013-08-05 21:54:00 +0000",
    "user" : {
      "name" : "steve blank",
      "screen_name" : "sgblank",
      "protected" : false,
      "id_str" : "22747624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2912811960\/15de2786cae224752bd52c4c50810d36_normal.png",
      "id" : 22747624,
      "verified" : true
    }
  },
  "id" : 364509233523343360,
  "created_at" : "2013-08-05 22:12:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 3, 11 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 27, 30 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/dmUplMmSKl",
      "expanded_url" : "http:\/\/bit.ly\/15nzxkF",
      "display_url" : "bit.ly\/15nzxkF"
    } ]
  },
  "geo" : { },
  "id_str" : "364447219996307456",
  "text" : "RT @rsarver: Wicked crazy \u201C@AP: New York Times selling The Boston Globe for $70M; it paid a record $1.1B for the paper in 1993: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Associated Press",
        "screen_name" : "AP",
        "indices" : [ 14, 17 ],
        "id_str" : "51241574",
        "id" : 51241574
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/dmUplMmSKl",
        "expanded_url" : "http:\/\/bit.ly\/15nzxkF",
        "display_url" : "bit.ly\/15nzxkF"
      } ]
    },
    "geo" : { },
    "id_str" : "364418056744742914",
    "text" : "Wicked crazy \u201C@AP: New York Times selling The Boston Globe for $70M; it paid a record $1.1B for the paper in 1993: http:\/\/t.co\/dmUplMmSKl\u201D",
    "id" : 364418056744742914,
    "created_at" : "2013-08-05 16:10:09 +0000",
    "user" : {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "protected" : false,
      "id_str" : "795649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3015419114\/3dc096c48ef6167d1b26fd0d6b01814d_normal.jpeg",
      "id" : 795649,
      "verified" : false
    }
  },
  "id" : 364447219996307456,
  "created_at" : "2013-08-05 18:06:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nirav Shah",
      "screen_name" : "niravsshah",
      "indices" : [ 0, 11 ],
      "id_str" : "101266929",
      "id" : 101266929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364436840859709441",
  "geo" : { },
  "id_str" : "364437163565260800",
  "in_reply_to_user_id" : 101266929,
  "text" : "@niravsshah Do something big to show how interested you are. Depending on what you do, show them the kind of work you could do here.",
  "id" : 364437163565260800,
  "in_reply_to_status_id" : 364436840859709441,
  "created_at" : "2013-08-05 17:26:05 +0000",
  "in_reply_to_screen_name" : "niravsshah",
  "in_reply_to_user_id_str" : "101266929",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nirav Shah",
      "screen_name" : "niravsshah",
      "indices" : [ 0, 11 ],
      "id_str" : "101266929",
      "id" : 101266929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364435660171522048",
  "geo" : { },
  "id_str" : "364436309290385408",
  "in_reply_to_user_id" : 101266929,
  "text" : "@niravsshah I thought it might too, but since I can't personally vouch for you it ends up with the same result. Keep trying!",
  "id" : 364436309290385408,
  "in_reply_to_status_id" : 364435660171522048,
  "created_at" : "2013-08-05 17:22:41 +0000",
  "in_reply_to_screen_name" : "niravsshah",
  "in_reply_to_user_id_str" : "101266929",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nirav Shah",
      "screen_name" : "niravsshah",
      "indices" : [ 0, 11 ],
      "id_str" : "101266929",
      "id" : 101266929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/UYazIs27y3",
      "expanded_url" : "http:\/\/twitter.com\/jobs",
      "display_url" : "twitter.com\/jobs"
    } ]
  },
  "in_reply_to_status_id_str" : "364434909726654465",
  "geo" : { },
  "id_str" : "364435099153993730",
  "in_reply_to_user_id" : 101266929,
  "text" : "@niravsshah I could, but honestly, that would probably be less effective than just submitting it to http:\/\/t.co\/UYazIs27y3",
  "id" : 364435099153993730,
  "in_reply_to_status_id" : 364434909726654465,
  "created_at" : "2013-08-05 17:17:53 +0000",
  "in_reply_to_screen_name" : "niravsshah",
  "in_reply_to_user_id_str" : "101266929",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nirav Shah",
      "screen_name" : "niravsshah",
      "indices" : [ 0, 11 ],
      "id_str" : "101266929",
      "id" : 101266929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363583276369195008",
  "geo" : { },
  "id_str" : "364428300157845504",
  "in_reply_to_user_id" : 101266929,
  "text" : "@niravsshah Awesome! How can I help?",
  "id" : 364428300157845504,
  "in_reply_to_status_id" : 363583276369195008,
  "created_at" : "2013-08-05 16:50:52 +0000",
  "in_reply_to_screen_name" : "niravsshah",
  "in_reply_to_user_id_str" : "101266929",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ReadWrite",
      "screen_name" : "RWW",
      "indices" : [ 9, 13 ],
      "id_str" : "4641021",
      "id" : 4641021
    }, {
      "name" : "Matt Asay",
      "screen_name" : "mjasay",
      "indices" : [ 59, 66 ],
      "id_str" : "7617702",
      "id" : 7617702
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lies",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/h6SevPvMXO",
      "expanded_url" : "http:\/\/readwr.it\/eR3",
      "display_url" : "readwr.it\/eR3"
    } ]
  },
  "in_reply_to_status_id_str" : "364403951363305472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859664819, -122.2756327244 ]
  },
  "id_str" : "364406861895696384",
  "in_reply_to_user_id" : 4641021,
  "text" : "#lies RT @RWW: Why The Quantified Self Needs A Monopoly by @mjasay http:\/\/t.co\/h6SevPvMXO",
  "id" : 364406861895696384,
  "in_reply_to_status_id" : 364403951363305472,
  "created_at" : "2013-08-05 15:25:40 +0000",
  "in_reply_to_screen_name" : "RWW",
  "in_reply_to_user_id_str" : "4641021",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.mapmyride.com\" rel=\"nofollow\"\u003EMapMyRide Mobile\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/oBxgLn5pOa",
      "expanded_url" : "http:\/\/mmf.cc\/11GG1bn",
      "display_url" : "mmf.cc\/11GG1bn"
    } ]
  },
  "geo" : { },
  "id_str" : "364259193475186689",
  "text" : "Strongly considering converting to a biking religion after today's ride.  http:\/\/t.co\/oBxgLn5pOa",
  "id" : 364259193475186689,
  "created_at" : "2013-08-05 05:38:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 56, 72 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/jZxP9TarUD",
      "expanded_url" : "http:\/\/flic.kr\/p\/fo8ija",
      "display_url" : "flic.kr\/p\/fo8ija"
    } ]
  },
  "geo" : { },
  "id_str" : "364240387465949185",
  "text" : "8:36pm Reading some pretty hilarious bike zines left by @ameliagreenhall http:\/\/t.co\/jZxP9TarUD",
  "id" : 364240387465949185,
  "created_at" : "2013-08-05 04:24:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "california",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/76x5YPXAax",
      "expanded_url" : "http:\/\/flic.kr\/p\/fo2eqa",
      "display_url" : "flic.kr\/p\/fo2eqa"
    } ]
  },
  "geo" : { },
  "id_str" : "364183434513485824",
  "text" : "Berkeley hills: 1, me on a bike: 0. #california http:\/\/t.co\/76x5YPXAax",
  "id" : 364183434513485824,
  "created_at" : "2013-08-05 00:37:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/6lljzgU9DZ",
      "expanded_url" : "http:\/\/flic.kr\/p\/fnWA3F",
      "display_url" : "flic.kr\/p\/fnWA3F"
    } ]
  },
  "geo" : { },
  "id_str" : "364142458516422656",
  "text" : "Using dollar bills to patch tires.  http:\/\/t.co\/6lljzgU9DZ",
  "id" : 364142458516422656,
  "created_at" : "2013-08-04 21:55:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364063355729743872",
  "geo" : { },
  "id_str" : "364075051965878273",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk They must have some \"just add water\" fine print on the teleporter.",
  "id" : 364075051965878273,
  "in_reply_to_status_id" : 364063355729743872,
  "created_at" : "2013-08-04 17:27:11 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364073381353623552",
  "text" : "According to 23andme, I'm somehow 51.3% Japanese. Does that mean I got more of my mother's genes, or that my father was part Japanese too?",
  "id" : 364073381353623552,
  "created_at" : "2013-08-04 17:20:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Yglesias",
      "screen_name" : "mattyglesias",
      "indices" : [ 33, 46 ],
      "id_str" : "15446531",
      "id" : 15446531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/lD1fidCQqp",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/moneybox\/2013\/08\/04\/physics_of_teleportation_it_doesn_t_work.html",
      "display_url" : "slate.com\/blogs\/moneybox\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "364021957022330883",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596866085, -122.2755120957 ]
  },
  "id_str" : "364057669465677824",
  "in_reply_to_user_id" : 15446531,
  "text" : "Plus cloning != teleportation RT @mattyglesias: Physicists: we don\u2019t have enough bandwidth to make teleportation work http:\/\/t.co\/lD1fidCQqp",
  "id" : 364057669465677824,
  "in_reply_to_status_id" : 364021957022330883,
  "created_at" : "2013-08-04 16:18:06 +0000",
  "in_reply_to_screen_name" : "mattyglesias",
  "in_reply_to_user_id_str" : "15446531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 8, 18 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 19, 30 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363861980232167424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596516932, -122.2755850946 ]
  },
  "id_str" : "363877869677588481",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon @kellianne @nikobenson Not til the 14th. Come over for dinner this week!",
  "id" : 363877869677588481,
  "in_reply_to_status_id" : 363861980232167424,
  "created_at" : "2013-08-04 04:23:39 +0000",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/MYrSznuatr",
      "expanded_url" : "http:\/\/flic.kr\/p\/fnDopf",
      "display_url" : "flic.kr\/p\/fnDopf"
    } ]
  },
  "geo" : { },
  "id_str" : "363866570809819138",
  "text" : "8:36pm Wrestling http:\/\/t.co\/MYrSznuatr",
  "id" : 363866570809819138,
  "created_at" : "2013-08-04 03:38:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/XML373iufJ",
      "expanded_url" : "http:\/\/flic.kr\/p\/fnnYke",
      "display_url" : "flic.kr\/p\/fnnYke"
    } ]
  },
  "geo" : { },
  "id_str" : "363853389416767488",
  "text" : "T-ball with a Thomas football is the new black http:\/\/t.co\/XML373iufJ",
  "id" : 363853389416767488,
  "created_at" : "2013-08-04 02:46:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 9, 20 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/363812454339313664\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/CG0cUpFl5N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQyFf-pCAAAKF0c.jpg",
      "id_str" : "363812454347702272",
      "id" : 363812454347702272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQyFf-pCAAAKF0c.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/CG0cUpFl5N"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/6jwNZFsd9L",
      "expanded_url" : "http:\/\/4sq.com\/15DM4hN",
      "display_url" : "4sq.com\/15DM4hN"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.850635, -122.278658 ]
  },
  "id_str" : "363812454339313664",
  "text" : "Cool new @foursquare chart post checkin (@ Moxy Beer Garden) http:\/\/t.co\/6jwNZFsd9L http:\/\/t.co\/CG0cUpFl5N",
  "id" : 363812454339313664,
  "created_at" : "2013-08-04 00:03:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 11, 23 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363731648182886400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.0602804423, -122.0051518419 ]
  },
  "id_str" : "363732393317777409",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame @nickcrocker Me too!",
  "id" : 363732393317777409,
  "in_reply_to_status_id" : 363731648182886400,
  "created_at" : "2013-08-03 18:45:35 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 25, 37 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Cx2NlDClGw",
      "expanded_url" : "https:\/\/medium.com\/health-the-future\/182870501589",
      "display_url" : "medium.com\/health-the-fut\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "359250362445737984",
  "geo" : { },
  "id_str" : "363729753401860096",
  "in_reply_to_user_id" : 30801469,
  "text" : "Everybody, read this: RT @nickcrocker: A post in which I describe one of the most powerful guiding forces in my life https:\/\/t.co\/Cx2NlDClGw",
  "id" : 363729753401860096,
  "in_reply_to_status_id" : 359250362445737984,
  "created_at" : "2013-08-03 18:35:05 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/E42a6DufGn",
      "expanded_url" : "http:\/\/flic.kr\/p\/fnaaWi",
      "display_url" : "flic.kr\/p\/fnaaWi"
    } ]
  },
  "geo" : { },
  "id_str" : "363726967373185024",
  "text" : "Bet it'll take you a while to even notice a truck in front of us.  http:\/\/t.co\/E42a6DufGn",
  "id" : 363726967373185024,
  "created_at" : "2013-08-03 18:24:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/UlqspNwcTm",
      "expanded_url" : "http:\/\/youarenotsosmart.com\/2010\/02\/10\/placebo-buttons\/",
      "display_url" : "youarenotsosmart.com\/2010\/02\/10\/pla\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.261824, -121.951469 ]
  },
  "id_str" : "363723284883316738",
  "text" : "Placebo buttons http:\/\/t.co\/UlqspNwcTm",
  "id" : 363723284883316738,
  "created_at" : "2013-08-03 18:09:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 3, 12 ],
      "id_str" : "376502929",
      "id" : 376502929
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Snapchat\/status\/363717681653886977\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/KccOpYnQvZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQwvTe3CMAABnBu.png",
      "id_str" : "363717681658081280",
      "id" : 363717681658081280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQwvTe3CMAABnBu.png",
      "sizes" : [ {
        "h" : 928,
        "resize" : "fit",
        "w" : 650
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 928,
        "resize" : "fit",
        "w" : 650
      }, {
        "h" : 857,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/KccOpYnQvZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363719099374780416",
  "text" : "RT @Snapchat: Love this infographic! http:\/\/t.co\/KccOpYnQvZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Snapchat\/status\/363717681653886977\/photo\/1",
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/KccOpYnQvZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQwvTe3CMAABnBu.png",
        "id_str" : "363717681658081280",
        "id" : 363717681658081280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQwvTe3CMAABnBu.png",
        "sizes" : [ {
          "h" : 928,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 485,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 928,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 857,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/KccOpYnQvZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363717681653886977",
    "text" : "Love this infographic! http:\/\/t.co\/KccOpYnQvZ",
    "id" : 363717681653886977,
    "created_at" : "2013-08-03 17:47:07 +0000",
    "user" : {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "protected" : false,
      "id_str" : "376502929",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261574473862\/f99109d38ff0884216cee667e77dc50e_normal.png",
      "id" : 376502929,
      "verified" : true
    }
  },
  "id" : 363719099374780416,
  "created_at" : "2013-08-03 17:52:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/FpWHFRFDxH",
      "expanded_url" : "http:\/\/flic.kr\/p\/fnnai3",
      "display_url" : "flic.kr\/p\/fnnai3"
    } ]
  },
  "geo" : { },
  "id_str" : "363708361167994880",
  "text" : "Heading to Santa Cruz aka the Island of Sodor for \"A Day Out With Thomas\"  http:\/\/t.co\/FpWHFRFDxH",
  "id" : 363708361167994880,
  "created_at" : "2013-08-03 17:10:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596409839, -122.2756132211 ]
  },
  "id_str" : "363674790931869698",
  "text" : "\u30D0\u30EB\u30B9!",
  "id" : 363674790931869698,
  "created_at" : "2013-08-03 14:56:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheWorldStories\/status\/363367156819304448\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/9JPDnO7mfQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQrwgQGCIAE6KDk.jpg",
      "id_str" : "363367156823498753",
      "id" : 363367156823498753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQrwgQGCIAE6KDk.jpg",
      "sizes" : [ {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/9JPDnO7mfQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363670276392751104",
  "text" : "RT @LaughHardPics: Mind = blown http:\/\/t.co\/9JPDnO7mfQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheWorldStories\/status\/363367156819304448\/photo\/1",
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/9JPDnO7mfQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQrwgQGCIAE6KDk.jpg",
        "id_str" : "363367156823498753",
        "id" : 363367156823498753,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQrwgQGCIAE6KDk.jpg",
        "sizes" : [ {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/9JPDnO7mfQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363367156819304448",
    "text" : "Mind = blown http:\/\/t.co\/9JPDnO7mfQ",
    "id" : 363367156819304448,
    "created_at" : "2013-08-02 18:34:15 +0000",
    "user" : {
      "name" : "Secret World Pics\u2122",
      "screen_name" : "TheWorldStories",
      "protected" : false,
      "id_str" : "284441324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465949612621045761\/9y8u_KOS_normal.jpeg",
      "id" : 284441324,
      "verified" : false
    }
  },
  "id" : 363670276392751104,
  "created_at" : "2013-08-03 14:38:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/uzBQdX6Rln",
      "expanded_url" : "http:\/\/flic.kr\/p\/fmPdHz",
      "display_url" : "flic.kr\/p\/fmPdHz"
    } ]
  },
  "geo" : { },
  "id_str" : "363507678183559169",
  "text" : "8:36pm Blasting the Muppets http:\/\/t.co\/uzBQdX6Rln",
  "id" : 363507678183559169,
  "created_at" : "2013-08-03 03:52:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Bogan",
      "screen_name" : "waferbaby",
      "indices" : [ 0, 10 ],
      "id_str" : "821753",
      "id" : 821753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363493103744720898",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859922525, -122.2752426161 ]
  },
  "id_str" : "363494254011621376",
  "in_reply_to_user_id" : 821753,
  "text" : "@waferbaby Fax me your vote.",
  "id" : 363494254011621376,
  "in_reply_to_status_id" : 363493103744720898,
  "created_at" : "2013-08-03 02:59:18 +0000",
  "in_reply_to_screen_name" : "waferbaby",
  "in_reply_to_user_id_str" : "821753",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 0, 7 ],
      "id_str" : "47",
      "id" : 47
    }, {
      "name" : "Suyash Sonwalkar",
      "screen_name" : "suyash",
      "indices" : [ 8, 15 ],
      "id_str" : "18040828",
      "id" : 18040828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363476391360081921",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8577048704, -122.2741011624 ]
  },
  "id_str" : "363476737968979970",
  "in_reply_to_user_id" : 47,
  "text" : "@kellan @suyash Agreed.",
  "id" : 363476737968979970,
  "in_reply_to_status_id" : 363476391360081921,
  "created_at" : "2013-08-03 01:49:42 +0000",
  "in_reply_to_screen_name" : "kellan",
  "in_reply_to_user_id_str" : "47",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8575874115, -122.273633821 ]
  },
  "id_str" : "363476616699052032",
  "text" : "Life will be better when we have iBoutonnieres.",
  "id" : 363476616699052032,
  "created_at" : "2013-08-03 01:49:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363474569140506625",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8557864002, -122.273041459 ]
  },
  "id_str" : "363475829549842432",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez Darn I think you managed to avoid my trick question unscathed.",
  "id" : 363475829549842432,
  "in_reply_to_status_id" : 363474569140506625,
  "created_at" : "2013-08-03 01:46:05 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8559238537, -122.2712454962 ]
  },
  "id_str" : "363475497914613760",
  "text" : "What % of your job is social engineering?",
  "id" : 363475497914613760,
  "created_at" : "2013-08-03 01:44:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7773405546, -122.4162783545 ]
  },
  "id_str" : "363470548694614018",
  "text" : "RT if you're a professional curmudgeon. Fave if you think curmudgeons are stupid.",
  "id" : 363470548694614018,
  "created_at" : "2013-08-03 01:25:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "indices" : [ 0, 13 ],
      "id_str" : "1186",
      "id" : 1186
    }, {
      "name" : "NeonMob",
      "screen_name" : "NeonMob",
      "indices" : [ 96, 104 ],
      "id_str" : "321034738",
      "id" : 321034738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363378387563192320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763044793, -122.417521174 ]
  },
  "id_str" : "363381401996890113",
  "in_reply_to_user_id" : 1186,
  "text" : "@chrismessina I was wondering about that from last night's subtle hints. Congrats! Checking out @NeonMob now...",
  "id" : 363381401996890113,
  "in_reply_to_status_id" : 363378387563192320,
  "created_at" : "2013-08-02 19:30:52 +0000",
  "in_reply_to_screen_name" : "chrismessina",
  "in_reply_to_user_id_str" : "1186",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Swizec",
      "screen_name" : "Swizec",
      "indices" : [ 0, 7 ],
      "id_str" : "15353121",
      "id" : 15353121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363365243642068992",
  "geo" : { },
  "id_str" : "363373970675863552",
  "in_reply_to_user_id" : 15353121,
  "text" : "@Swizec I appreciate it! Thanks!",
  "id" : 363373970675863552,
  "in_reply_to_status_id" : 363365243642068992,
  "created_at" : "2013-08-02 19:01:20 +0000",
  "in_reply_to_screen_name" : "Swizec",
  "in_reply_to_user_id_str" : "15353121",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nein.",
      "screen_name" : "NeinQuarterly",
      "indices" : [ 3, 17 ],
      "id_str" : "458966079",
      "id" : 458966079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363341508776165377",
  "text" : "RT @NeinQuarterly: An omniscient narrator walks into a bar. An unreliable narrator walks out.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363341356854280192",
    "text" : "An omniscient narrator walks into a bar. An unreliable narrator walks out.",
    "id" : 363341356854280192,
    "created_at" : "2013-08-02 16:51:44 +0000",
    "user" : {
      "name" : "Nein.",
      "screen_name" : "NeinQuarterly",
      "protected" : false,
      "id_str" : "458966079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000829092209\/ed4c25faaa25fbba40b11fabe8241a59_normal.jpeg",
      "id" : 458966079,
      "verified" : true
    }
  },
  "id" : 363341508776165377,
  "created_at" : "2013-08-02 16:52:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Mudede",
      "screen_name" : "mudede",
      "indices" : [ 0, 7 ],
      "id_str" : "33412856",
      "id" : 33412856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363318595310202880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8531366743, -122.2703319449 ]
  },
  "id_str" : "363322150783950848",
  "in_reply_to_user_id" : 33412856,
  "text" : "@mudede Thanks for making me create a model of the world inside my model of the world.",
  "id" : 363322150783950848,
  "in_reply_to_status_id" : 363318595310202880,
  "created_at" : "2013-08-02 15:35:25 +0000",
  "in_reply_to_screen_name" : "mudede",
  "in_reply_to_user_id_str" : "33412856",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hsiaoching",
      "screen_name" : "hsiaoching",
      "indices" : [ 0, 11 ],
      "id_str" : "14721244",
      "id" : 14721244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363143323768201218",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597054212, -122.2754052189 ]
  },
  "id_str" : "363145605524107264",
  "in_reply_to_user_id" : 14721244,
  "text" : "@hsiaoching I'm running late, it'll go out tonight! :)",
  "id" : 363145605524107264,
  "in_reply_to_status_id" : 363143323768201218,
  "created_at" : "2013-08-02 03:53:53 +0000",
  "in_reply_to_screen_name" : "hsiaoching",
  "in_reply_to_user_id_str" : "14721244",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mazarine ",
      "screen_name" : "wildwomanfund",
      "indices" : [ 0, 14 ],
      "id_str" : "93980220",
      "id" : 93980220
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363140576113209345",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597680526, -122.2755492952 ]
  },
  "id_str" : "363141813994913792",
  "in_reply_to_user_id" : 93980220,
  "text" : "@wildwomanfund Where do you see them?",
  "id" : 363141813994913792,
  "in_reply_to_status_id" : 363140576113209345,
  "created_at" : "2013-08-02 03:38:49 +0000",
  "in_reply_to_screen_name" : "wildwomanfund",
  "in_reply_to_user_id_str" : "93980220",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/H9hNxEVF1n",
      "expanded_url" : "http:\/\/flic.kr\/p\/fmdtHv",
      "display_url" : "flic.kr\/p\/fmdtHv"
    } ]
  },
  "geo" : { },
  "id_str" : "363132763106324481",
  "text" : "Kids started a band and are going on tour http:\/\/t.co\/H9hNxEVF1n",
  "id" : 363132763106324481,
  "created_at" : "2013-08-02 03:02:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler LePard",
      "screen_name" : "tylepard",
      "indices" : [ 1, 10 ],
      "id_str" : "18297300",
      "id" : 18297300
    }, {
      "name" : "Jen Walker",
      "screen_name" : "walkeje",
      "indices" : [ 11, 19 ],
      "id_str" : "20653041",
      "id" : 20653041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363108150171275264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7792997354, -122.4140316135 ]
  },
  "id_str" : "363114008104017920",
  "in_reply_to_user_id" : 18297300,
  "text" : ".@tylepard @walkeje Updated my bio.",
  "id" : 363114008104017920,
  "in_reply_to_status_id" : 363108150171275264,
  "created_at" : "2013-08-02 01:48:20 +0000",
  "in_reply_to_screen_name" : "tylepard",
  "in_reply_to_user_id_str" : "18297300",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler LePard",
      "screen_name" : "tylepard",
      "indices" : [ 3, 12 ],
      "id_str" : "18297300",
      "id" : 18297300
    }, {
      "name" : "Jen Walker",
      "screen_name" : "walkeje",
      "indices" : [ 51, 59 ],
      "id_str" : "20653041",
      "id" : 20653041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/7tJFdUTyvx",
      "expanded_url" : "http:\/\/bit.ly\/13bxO01",
      "display_url" : "bit.ly\/13bxO01"
    } ]
  },
  "geo" : { },
  "id_str" : "363111657951608834",
  "text" : "RT @tylepard: YES. All 100, but especially #42. RT @walkeje: 101 Everyday Ways for Men to be Allies to Women http:\/\/t.co\/7tJFdUTyvx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jen Walker",
        "screen_name" : "walkeje",
        "indices" : [ 37, 45 ],
        "id_str" : "20653041",
        "id" : 20653041
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/7tJFdUTyvx",
        "expanded_url" : "http:\/\/bit.ly\/13bxO01",
        "display_url" : "bit.ly\/13bxO01"
      } ]
    },
    "geo" : { },
    "id_str" : "363108150171275264",
    "text" : "YES. All 100, but especially #42. RT @walkeje: 101 Everyday Ways for Men to be Allies to Women http:\/\/t.co\/7tJFdUTyvx",
    "id" : 363108150171275264,
    "created_at" : "2013-08-02 01:25:03 +0000",
    "user" : {
      "name" : "Tyler LePard",
      "screen_name" : "tylepard",
      "protected" : false,
      "id_str" : "18297300",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2941157337\/d5cc7fb3ab9d65ca99f2054bb5a86fdf_normal.jpeg",
      "id" : 18297300,
      "verified" : false
    }
  },
  "id" : 363111657951608834,
  "created_at" : "2013-08-02 01:39:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randall Lucas",
      "screen_name" : "rlucas",
      "indices" : [ 0, 7 ],
      "id_str" : "7687432",
      "id" : 7687432
    }, {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 96, 106 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319143889535651840",
  "geo" : { },
  "id_str" : "363073171143925760",
  "in_reply_to_user_id" : 7687432,
  "text" : "@rlucas Yes, it is a Kahneman quote, from Thinking Fast and Slow, which is an awesome book. \/cc @galenward",
  "id" : 363073171143925760,
  "in_reply_to_status_id" : 319143889535651840,
  "created_at" : "2013-08-01 23:06:04 +0000",
  "in_reply_to_screen_name" : "rlucas",
  "in_reply_to_user_id_str" : "7687432",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363072607022616576",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward Thanks for favoriting my tweet from 121 days ago.",
  "id" : 363072607022616576,
  "created_at" : "2013-08-01 23:03:49 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexia Tsotsis",
      "screen_name" : "alexia",
      "indices" : [ 0, 7 ],
      "id_str" : "18327902",
      "id" : 18327902
    }, {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 82, 93 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362983738923163650",
  "in_reply_to_user_id" : 18327902,
  "text" : "@alexia Who can I bug over there to get you guys to update your Twitter Cards for @Techcrunch? There's an easy way to increase clickthru.",
  "id" : 362983738923163650,
  "created_at" : "2013-08-01 17:10:41 +0000",
  "in_reply_to_screen_name" : "alexia",
  "in_reply_to_user_id_str" : "18327902",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farzana Dudhwala",
      "screen_name" : "fuz_d",
      "indices" : [ 0, 6 ],
      "id_str" : "52801108",
      "id" : 52801108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362970738216550400",
  "geo" : { },
  "id_str" : "362977473660596226",
  "in_reply_to_user_id" : 52801108,
  "text" : "@fuz_d I just got it of the internet somewhere\u2026 so I have no idea. Where are your birds from?",
  "id" : 362977473660596226,
  "in_reply_to_status_id" : 362970738216550400,
  "created_at" : "2013-08-01 16:45:48 +0000",
  "in_reply_to_screen_name" : "fuz_d",
  "in_reply_to_user_id_str" : "52801108",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8386165458, -122.2694080451 ]
  },
  "id_str" : "362966592654548994",
  "text" : "Rabbit rabbit!",
  "id" : 362966592654548994,
  "created_at" : "2013-08-01 16:02:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]