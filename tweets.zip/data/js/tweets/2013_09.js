Grailbird.data.tweets_2013_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shutdown",
      "indices" : [ 34, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/4zPPwve38h",
      "expanded_url" : "http:\/\/flic.kr\/p\/ghsVqK",
      "display_url" : "flic.kr\/p\/ghsVqK"
    } ]
  },
  "geo" : { },
  "id_str" : "384889569130590208",
  "text" : "8:36pm Niko and I waiting for the #shutdown http:\/\/t.co\/4zPPwve38h",
  "id" : 384889569130590208,
  "created_at" : "2013-10-01 03:56:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "surprise",
      "indices" : [ 34, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/05NnTkxN7R",
      "expanded_url" : "https:\/\/vine.co\/v\/hguEEjvHJqY",
      "display_url" : "vine.co\/v\/hguEEjvHJqY"
    } ]
  },
  "geo" : { },
  "id_str" : "384867062700859392",
  "text" : "Niko chose his Halloween costume. #surprise! https:\/\/t.co\/05NnTkxN7R",
  "id" : 384867062700859392,
  "created_at" : "2013-10-01 02:27:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mother Jones",
      "screen_name" : "MotherJones",
      "indices" : [ 3, 15 ],
      "id_str" : "18510860",
      "id" : 18510860
    }, {
      "name" : "What Is Shut Down",
      "screen_name" : "WhatIsShutDown",
      "indices" : [ 21, 36 ],
      "id_str" : "1921455757",
      "id" : 1921455757
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 17, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384807759771738112",
  "text" : "RT @MotherJones: #FF @WhatIsShutDown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "What Is Shut Down",
        "screen_name" : "WhatIsShutDown",
        "indices" : [ 4, 19 ],
        "id_str" : "1921455757",
        "id" : 1921455757
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FF",
        "indices" : [ 0, 3 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384803029129515008",
    "text" : "#FF @WhatIsShutDown",
    "id" : 384803029129515008,
    "created_at" : "2013-09-30 22:12:46 +0000",
    "user" : {
      "name" : "Mother Jones",
      "screen_name" : "MotherJones",
      "protected" : false,
      "id_str" : "18510860",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451825504207638528\/2kBkscYK_normal.jpeg",
      "id" : 18510860,
      "verified" : true
    }
  },
  "id" : 384807759771738112,
  "created_at" : "2013-09-30 22:31:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy James Hall",
      "screen_name" : "JimmyJameson",
      "indices" : [ 7, 20 ],
      "id_str" : "35141809",
      "id" : 35141809
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 38, 49 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/MeJDlQfWJ2",
      "expanded_url" : "http:\/\/flic.kr\/p\/gfUxBe",
      "display_url" : "flic.kr\/p\/gfUxBe"
    } ]
  },
  "geo" : { },
  "id_str" : "384550654284668929",
  "text" : "8:36pm @JimmyJameson visits. Photo by @nikobenson. http:\/\/t.co\/MeJDlQfWJ2",
  "id" : 384550654284668929,
  "created_at" : "2013-09-30 05:29:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    }, {
      "name" : "Jessica Scheibach",
      "screen_name" : "jshy",
      "indices" : [ 12, 17 ],
      "id_str" : "804659",
      "id" : 804659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384416738760089600",
  "geo" : { },
  "id_str" : "384420766680248320",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold @jshy TweetDeck and Tweetbot have mute and I have long wished main Twitter apps did too.",
  "id" : 384420766680248320,
  "in_reply_to_status_id" : 384416738760089600,
  "created_at" : "2013-09-29 20:53:47 +0000",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/c8VXGGs60L",
      "expanded_url" : "https:\/\/vine.co\/v\/h6P73nAOQq0",
      "display_url" : "vine.co\/v\/h6P73nAOQq0"
    } ]
  },
  "geo" : { },
  "id_str" : "384409992583196672",
  "text" : "Butchering a whole pig https:\/\/t.co\/c8VXGGs60L",
  "id" : 384409992583196672,
  "created_at" : "2013-09-29 20:10:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "indices" : [ 8, 11 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/1Xv4VcdvL9",
      "expanded_url" : "https:\/\/twitter.com\/buster\/status\/381645475754962944",
      "display_url" : "twitter.com\/buster\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "384197785156722688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596987893, -122.2755166569 ]
  },
  "id_str" : "384210521307623424",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @ev Just remembered I played this game (without hashtag) last weekend: https:\/\/t.co\/1Xv4VcdvL9",
  "id" : 384210521307623424,
  "in_reply_to_status_id" : 384197785156722688,
  "created_at" : "2013-09-29 06:58:21 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "indices" : [ 3, 6 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TweetOrTwenty",
      "indices" : [ 8, 22 ]
    }, {
      "text" : "CardsAgainstHumanity",
      "indices" : [ 53, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384197102449864704",
  "text" : "RT @ev: #TweetOrTwenty rules: Draw a white card from #CardsAgainstHumanity. Either tweet what's on the card or add $20 to the pot. Tweeter \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TweetOrTwenty",
        "indices" : [ 0, 14 ]
      }, {
        "text" : "CardsAgainstHumanity",
        "indices" : [ 45, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384196711566286848",
    "text" : "#TweetOrTwenty rules: Draw a white card from #CardsAgainstHumanity. Either tweet what's on the card or add $20 to the pot. Tweeter gets pot.",
    "id" : 384196711566286848,
    "created_at" : "2013-09-29 06:03:28 +0000",
    "user" : {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "protected" : false,
      "id_str" : "20",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000541049107\/3b6dcbd9c0182688457f372b40483e50_normal.jpeg",
      "id" : 20,
      "verified" : true
    }
  },
  "id" : 384197102449864704,
  "created_at" : "2013-09-29 06:05:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/BuS5sH8Tbg",
      "expanded_url" : "http:\/\/flic.kr\/p\/gdZktr",
      "display_url" : "flic.kr\/p\/gdZktr"
    } ]
  },
  "geo" : { },
  "id_str" : "384160632784027648",
  "text" : "8:36pm Lazy night watching Tayo the Little Bus http:\/\/t.co\/BuS5sH8Tbg",
  "id" : 384160632784027648,
  "created_at" : "2013-09-29 03:40:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Cho",
      "screen_name" : "mark_cho",
      "indices" : [ 0, 9 ],
      "id_str" : "391248959",
      "id" : 391248959
    }, {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 62, 70 ],
      "id_str" : "22891211",
      "id" : 22891211
    }, {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 71, 77 ],
      "id_str" : "15310552",
      "id" : 15310552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383834264631910400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596767146, -122.2754835153 ]
  },
  "id_str" : "383839457691975680",
  "in_reply_to_user_id" : 391248959,
  "text" : "@mark_cho You did awesome! Plus built a good chunk of it. \/cc @chanian @singy",
  "id" : 383839457691975680,
  "in_reply_to_status_id" : 383834264631910400,
  "created_at" : "2013-09-28 06:23:52 +0000",
  "in_reply_to_screen_name" : "mark_cho",
  "in_reply_to_user_id_str" : "391248959",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/gY7yfpYI8G",
      "expanded_url" : "http:\/\/flic.kr\/p\/gcAGSm",
      "display_url" : "flic.kr\/p\/gcAGSm"
    } ]
  },
  "geo" : { },
  "id_str" : "383832119816249344",
  "text" : "8:36pm Was having a late dinner with this dude before passing out http:\/\/t.co\/gY7yfpYI8G",
  "id" : 383832119816249344,
  "created_at" : "2013-09-28 05:54:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andy kiang",
      "screen_name" : "andyk",
      "indices" : [ 0, 6 ],
      "id_str" : "2069",
      "id" : 2069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383767665468137474",
  "geo" : { },
  "id_str" : "383769514229243904",
  "in_reply_to_user_id" : 2069,
  "text" : "@andyk Now you have a good reason to log in! Though I assume it will also apply to their weekly emails.",
  "id" : 383769514229243904,
  "in_reply_to_status_id" : 383767665468137474,
  "created_at" : "2013-09-28 01:45:56 +0000",
  "in_reply_to_screen_name" : "andyk",
  "in_reply_to_user_id_str" : "2069",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 16, 23 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/WGgB4TI6Of",
      "expanded_url" : "https:\/\/medium.com\/about\/e80cb20d3f03",
      "display_url" : "medium.com\/about\/e80cb20d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383764023226802177",
  "text" : "Those people at @medium are smrt.  https:\/\/t.co\/WGgB4TI6Of",
  "id" : 383764023226802177,
  "created_at" : "2013-09-28 01:24:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Calder",
      "screen_name" : "keithcalder",
      "indices" : [ 0, 12 ],
      "id_str" : "19920027",
      "id" : 19920027
    }, {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 30, 44 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 68, 75 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383756128930123777",
  "geo" : { },
  "id_str" : "383756416030212096",
  "in_reply_to_user_id" : 19920027,
  "text" : "@keithcalder That's the plan. @buster_ebooks will live on long past @buster.",
  "id" : 383756416030212096,
  "in_reply_to_status_id" : 383756128930123777,
  "created_at" : "2013-09-28 00:53:54 +0000",
  "in_reply_to_screen_name" : "keithcalder",
  "in_reply_to_user_id_str" : "19920027",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Calder",
      "screen_name" : "keithcalder",
      "indices" : [ 0, 12 ],
      "id_str" : "19920027",
      "id" : 19920027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383750332506853376",
  "geo" : { },
  "id_str" : "383753731033927681",
  "in_reply_to_user_id" : 19920027,
  "text" : "@keithcalder I think it's getting smarter.",
  "id" : 383753731033927681,
  "in_reply_to_status_id" : 383750332506853376,
  "created_at" : "2013-09-28 00:43:13 +0000",
  "in_reply_to_screen_name" : "keithcalder",
  "in_reply_to_user_id_str" : "19920027",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383704278512455680",
  "geo" : { },
  "id_str" : "383708221019398144",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Wow, that's a lot of words. Well done!",
  "id" : 383708221019398144,
  "in_reply_to_status_id" : 383704278512455680,
  "created_at" : "2013-09-27 21:42:23 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/dev.twitter.com\/\" rel=\"nofollow\"\u003EAPI\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "indices" : [ 3, 14 ],
      "id_str" : "8070502",
      "id" : 8070502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/5g8Bz1y75y",
      "expanded_url" : "http:\/\/www.robotturtles.com",
      "display_url" : "robotturtles.com"
    } ]
  },
  "geo" : { },
  "id_str" : "383684371233775616",
  "text" : "RT @danshapiro: Robot Turtles - the best selling Kickstarter board game ever - goes out of print in four hours. http:\/\/t.co\/5g8Bz1y75y",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/5g8Bz1y75y",
        "expanded_url" : "http:\/\/www.robotturtles.com",
        "display_url" : "robotturtles.com"
      } ]
    },
    "geo" : { },
    "id_str" : "383682604358045696",
    "text" : "Robot Turtles - the best selling Kickstarter board game ever - goes out of print in four hours. http:\/\/t.co\/5g8Bz1y75y",
    "id" : 383682604358045696,
    "created_at" : "2013-09-27 20:00:36 +0000",
    "user" : {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "protected" : false,
      "id_str" : "8070502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/51828452\/eye_pic_normal.jpg",
      "id" : 8070502,
      "verified" : false
    }
  },
  "id" : 383684371233775616,
  "created_at" : "2013-09-27 20:07:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 102, 116 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383636163619078145",
  "geo" : { },
  "id_str" : "383636486135877632",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley I have the same feeling when I tweet too\u2026 \"Is this something I really need to tweet or will @buster_ebooks eventually get to it?\"",
  "id" : 383636486135877632,
  "in_reply_to_status_id" : 383636163619078145,
  "created_at" : "2013-09-27 16:57:20 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383635805669183489",
  "geo" : { },
  "id_str" : "383636028369563648",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Nostalgia for the nostalgia we had before.",
  "id" : 383636028369563648,
  "in_reply_to_status_id" : 383635805669183489,
  "created_at" : "2013-09-27 16:55:31 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7789179798, -122.4145665457 ]
  },
  "id_str" : "383628465800351745",
  "text" : "I like to think of information living somewhere. Waking up in the morning, putting on slippers, sipping tea.",
  "id" : 383628465800351745,
  "created_at" : "2013-09-27 16:25:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cole Reinke",
      "screen_name" : "colereinke",
      "indices" : [ 0, 11 ],
      "id_str" : "15886171",
      "id" : 15886171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383621804754882561",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8289502906, -122.2671795544 ]
  },
  "id_str" : "383622800499421184",
  "in_reply_to_user_id" : 15886171,
  "text" : "@colereinke Yup!",
  "id" : 383622800499421184,
  "in_reply_to_status_id" : 383621804754882561,
  "created_at" : "2013-09-27 16:02:57 +0000",
  "in_reply_to_screen_name" : "colereinke",
  "in_reply_to_user_id_str" : "15886171",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383611088224284672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.853239904, -122.270708176 ]
  },
  "id_str" : "383620216468434944",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim OK, let me know if it continues and I can file a bug.",
  "id" : 383620216468434944,
  "in_reply_to_status_id" : 383611088224284672,
  "created_at" : "2013-09-27 15:52:41 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cole Reinke",
      "screen_name" : "colereinke",
      "indices" : [ 0, 11 ],
      "id_str" : "15886171",
      "id" : 15886171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383616908366319616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.853239904, -122.270708176 ]
  },
  "id_str" : "383619887790174208",
  "in_reply_to_user_id" : 15886171,
  "text" : "@colereinke Yeah it's running every 20 minutes on one of my servers.",
  "id" : 383619887790174208,
  "in_reply_to_status_id" : 383616908366319616,
  "created_at" : "2013-09-27 15:51:23 +0000",
  "in_reply_to_screen_name" : "colereinke",
  "in_reply_to_user_id_str" : "15886171",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383589198545948674",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596780124, -122.2754659039 ]
  },
  "id_str" : "383591877594710016",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim What are you referring to?",
  "id" : 383591877594710016,
  "in_reply_to_status_id" : 383589198545948674,
  "created_at" : "2013-09-27 14:00:05 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/XE2N5AJogm",
      "expanded_url" : "http:\/\/flic.kr\/p\/gbb5Zc",
      "display_url" : "flic.kr\/p\/gbb5Zc"
    } ]
  },
  "geo" : { },
  "id_str" : "383437134126133248",
  "text" : "8:36pm Katie's in town http:\/\/t.co\/XE2N5AJogm",
  "id" : 383437134126133248,
  "created_at" : "2013-09-27 03:45:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 0, 7 ],
      "id_str" : "1530531",
      "id" : 1530531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383409900237230080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8584174443, -122.2750249734 ]
  },
  "id_str" : "383411822545494017",
  "in_reply_to_user_id" : 1530531,
  "text" : "@miradu I have a friend in town (plus East Bay) but I need some team time so will plan to make it next time!",
  "id" : 383411822545494017,
  "in_reply_to_status_id" : 383409900237230080,
  "created_at" : "2013-09-27 02:04:36 +0000",
  "in_reply_to_screen_name" : "miradu",
  "in_reply_to_user_id_str" : "1530531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cheers",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383405948649234432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8016537009, -122.2845167668 ]
  },
  "id_str" : "383406491236962305",
  "in_reply_to_user_id" : 2185,
  "text" : "I may need an actual drink to recover. #cheers",
  "id" : 383406491236962305,
  "in_reply_to_status_id" : 383405948649234432,
  "created_at" : "2013-09-27 01:43:25 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8047631355, -122.2943740525 ]
  },
  "id_str" : "383405948649234432",
  "text" : "I'm a bit drunk from swimming in the collective brain of the Twitter product management team today.",
  "id" : 383405948649234432,
  "created_at" : "2013-09-27 01:41:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383402699024121856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7789228946, -122.4145947533 ]
  },
  "id_str" : "383403144136253440",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel I agree! But I think you may be the only other person that finds them funny.",
  "id" : 383403144136253440,
  "in_reply_to_status_id" : 383402699024121856,
  "created_at" : "2013-09-27 01:30:07 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 17, 31 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383397872374259712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7789228946, -122.4145947533 ]
  },
  "id_str" : "383401622681833472",
  "in_reply_to_user_id" : 1901375096,
  "text" : "Best one yet. RT @buster_ebooks: Sopor got into a true\/false statement",
  "id" : 383401622681833472,
  "in_reply_to_status_id" : 383397872374259712,
  "created_at" : "2013-09-27 01:24:04 +0000",
  "in_reply_to_screen_name" : "buster_ebooks",
  "in_reply_to_user_id_str" : "1901375096",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383342458102226944",
  "geo" : { },
  "id_str" : "383342746829737985",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver I don't know, that was a pretty great post. I especially liked distinction between SaaS and platform.",
  "id" : 383342746829737985,
  "in_reply_to_status_id" : 383342458102226944,
  "created_at" : "2013-09-26 21:30:07 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 40, 48 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/rbQqrlw962",
      "expanded_url" : "http:\/\/bit.ly\/1eKHHYw",
      "display_url" : "bit.ly\/1eKHHYw"
    } ]
  },
  "geo" : { },
  "id_str" : "383342316963893248",
  "text" : "\"WTF is a platform?\" by the much-missed @rsarver http:\/\/t.co\/rbQqrlw962 (looking forward to more posts, Ryan!)",
  "id" : 383342316963893248,
  "created_at" : "2013-09-26 21:28:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/dev.twitter.com\/\" rel=\"nofollow\"\u003EAPI\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/k0bAqOlBpe",
      "expanded_url" : "https:\/\/blog.twitter.com\/2013\/rich-photo-experience-now-in-embedded-tweets-3",
      "display_url" : "blog.twitter.com\/2013\/rich-phot\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383313919336386561",
  "text" : "RT @twitter: Putting the photo front and center, now in embedded Tweets: https:\/\/t.co\/k0bAqOlBpe",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/k0bAqOlBpe",
        "expanded_url" : "https:\/\/blog.twitter.com\/2013\/rich-photo-experience-now-in-embedded-tweets-3",
        "display_url" : "blog.twitter.com\/2013\/rich-phot\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "383304965432672257",
    "text" : "Putting the photo front and center, now in embedded Tweets: https:\/\/t.co\/k0bAqOlBpe",
    "id" : 383304965432672257,
    "created_at" : "2013-09-26 18:59:59 +0000",
    "user" : {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "protected" : false,
      "id_str" : "783214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2284174758\/v65oai7fxn47qv9nectx_normal.png",
      "id" : 783214,
      "verified" : true
    }
  },
  "id" : 383313919336386561,
  "created_at" : "2013-09-26 19:35:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 3, 14 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/ji7I4oHXBR",
      "expanded_url" : "http:\/\/imgur.com\/a\/p0tKn",
      "display_url" : "imgur.com\/a\/p0tKn"
    } ]
  },
  "geo" : { },
  "id_str" : "383312538546368512",
  "text" : "RT @waxpancake: Steve Albini's letter to Nirvana about producing In Utero is something else. Oi! http:\/\/t.co\/ji7I4oHXBR",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/ji7I4oHXBR",
        "expanded_url" : "http:\/\/imgur.com\/a\/p0tKn",
        "display_url" : "imgur.com\/a\/p0tKn"
      } ]
    },
    "geo" : { },
    "id_str" : "383310543102025731",
    "text" : "Steve Albini's letter to Nirvana about producing In Utero is something else. Oi! http:\/\/t.co\/ji7I4oHXBR",
    "id" : 383310543102025731,
    "created_at" : "2013-09-26 19:22:09 +0000",
    "user" : {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "protected" : false,
      "id_str" : "13461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416642320574844928\/Gz7V2B6r_normal.jpeg",
      "id" : 13461,
      "verified" : false
    }
  },
  "id" : 383312538546368512,
  "created_at" : "2013-09-26 19:30:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 65, 72 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/9E4y9PwWad",
      "expanded_url" : "http:\/\/torrez.org\/how-about-some-fucking-whimsy.html",
      "display_url" : "torrez.org\/how-about-some\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383283394974466048",
  "text" : "Amen. \"How about some fucking whimsy\" http:\/\/t.co\/9E4y9PwWad \/by @torrez",
  "id" : 383283394974466048,
  "created_at" : "2013-09-26 17:34:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764151618, -122.4166582247 ]
  },
  "id_str" : "383266599685193729",
  "text" : "Live eulogy first.",
  "id" : 383266599685193729,
  "created_at" : "2013-09-26 16:27:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 0, 14 ],
      "id_str" : "820661",
      "id" : 820661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383259895442972672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7844942269, -122.4076830046 ]
  },
  "id_str" : "383263231780741120",
  "in_reply_to_user_id" : 820661,
  "text" : "@daveschappell Twitter's been fighting spambots for a while... they're just continuing to evolve.",
  "id" : 383263231780741120,
  "in_reply_to_status_id" : 383259895442972672,
  "created_at" : "2013-09-26 16:14:09 +0000",
  "in_reply_to_screen_name" : "daveschappell",
  "in_reply_to_user_id_str" : "820661",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/eUx7MQdpPu",
      "expanded_url" : "http:\/\/flic.kr\/p\/g9KZP7",
      "display_url" : "flic.kr\/p\/g9KZP7"
    } ]
  },
  "geo" : { },
  "id_str" : "383075188839313408",
  "text" : "8:36pm What do you want to say, Niko? \"I really love a lot of ice cream!\" http:\/\/t.co\/eUx7MQdpPu",
  "id" : 383075188839313408,
  "created_at" : "2013-09-26 03:46:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 3, 17 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 28, 39 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383051831724613633",
  "text" : "RT @buster_ebooks: I\u2019ve had @nikobenson for almost everyone else got so young",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/busterbenson.com\" rel=\"nofollow\"\u003EBuster eBooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Niko Benson",
        "screen_name" : "nikobenson",
        "indices" : [ 9, 20 ],
        "id_str" : "142467448",
        "id" : 142467448
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383050840837062656",
    "text" : "I\u2019ve had @nikobenson for almost everyone else got so young",
    "id" : 383050840837062656,
    "created_at" : "2013-09-26 02:10:11 +0000",
    "user" : {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "protected" : false,
      "id_str" : "1901375096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000503050571\/228ccabfeeb4e55bd8e172595babe02e_normal.jpeg",
      "id" : 1901375096,
      "verified" : false
    }
  },
  "id" : 383051831724613633,
  "created_at" : "2013-09-26 02:14:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 0, 6 ],
      "id_str" : "1928021",
      "id" : 1928021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382998159779045376",
  "geo" : { },
  "id_str" : "382999115937746944",
  "in_reply_to_user_id" : 1928021,
  "text" : "@parkr Thanks for gem-ifying that! I might switch to your implementation myself!",
  "id" : 382999115937746944,
  "in_reply_to_status_id" : 382998159779045376,
  "created_at" : "2013-09-25 22:44:39 +0000",
  "in_reply_to_screen_name" : "parkr",
  "in_reply_to_user_id_str" : "1928021",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parker",
      "screen_name" : "parkr",
      "indices" : [ 9, 15 ],
      "id_str" : "1928021",
      "id" : 1928021
    }, {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "indices" : [ 31, 44 ],
      "id_str" : "174958347",
      "id" : 174958347
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 56, 63 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Ci0HCtdgo9",
      "expanded_url" : "https:\/\/github.com\/parkr\/ebooks",
      "display_url" : "github.com\/parkr\/ebooks"
    } ]
  },
  "geo" : { },
  "id_str" : "382998977328590848",
  "text" : "Cool! RT @parkr: Want your own @horse_ebooks? Thanks to @buster (and some reorganization\/additions by me), you can: https:\/\/t.co\/Ci0HCtdgo9",
  "id" : 382998977328590848,
  "created_at" : "2013-09-25 22:44:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Shapiro",
      "screen_name" : "ZackShapiro",
      "indices" : [ 0, 12 ],
      "id_str" : "15999465",
      "id" : 15999465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/XkUUcdJOZa",
      "expanded_url" : "http:\/\/wayoftheduck.com\/diy-horse-ebooks",
      "display_url" : "wayoftheduck.com\/diy-horse-eboo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "382975822912434176",
  "geo" : { },
  "id_str" : "382977852645191680",
  "in_reply_to_user_id" : 15999465,
  "text" : "@ZackShapiro Apologies, Zack. You've been Markov'd: http:\/\/t.co\/XkUUcdJOZa",
  "id" : 382977852645191680,
  "in_reply_to_status_id" : 382975822912434176,
  "created_at" : "2013-09-25 21:20:10 +0000",
  "in_reply_to_screen_name" : "ZackShapiro",
  "in_reply_to_user_id_str" : "15999465",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 0, 7 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764613214, -122.4167771753 ]
  },
  "id_str" : "382900254883868673",
  "in_reply_to_user_id" : 2185,
  "text" : "@buster Yeah probably! Only one way to find out!",
  "id" : 382900254883868673,
  "created_at" : "2013-09-25 16:11:49 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 0, 14 ],
      "id_str" : "820661",
      "id" : 820661
    }, {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 15, 29 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/XkUUcdJOZa",
      "expanded_url" : "http:\/\/wayoftheduck.com\/diy-horse-ebooks",
      "display_url" : "wayoftheduck.com\/diy-horse-eboo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "382827722684526592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7936238804, -122.3961327955 ]
  },
  "id_str" : "382895992783122432",
  "in_reply_to_user_id" : 820661,
  "text" : "@daveschappell @buster_ebooks You've been Markov'd: http:\/\/t.co\/XkUUcdJOZa",
  "id" : 382895992783122432,
  "in_reply_to_status_id" : 382827722684526592,
  "created_at" : "2013-09-25 15:54:53 +0000",
  "in_reply_to_screen_name" : "daveschappell",
  "in_reply_to_user_id_str" : "820661",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 3, 17 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382879778786643968",
  "text" : "RT @buster_ebooks: I continue the 1 thing I knew how to be loved.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/busterbenson.com\" rel=\"nofollow\"\u003EBuster eBooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382879716954222592",
    "text" : "I continue the 1 thing I knew how to be loved.",
    "id" : 382879716954222592,
    "created_at" : "2013-09-25 14:50:12 +0000",
    "user" : {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "protected" : false,
      "id_str" : "1901375096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000503050571\/228ccabfeeb4e55bd8e172595babe02e_normal.jpeg",
      "id" : 1901375096,
      "verified" : false
    }
  },
  "id" : 382879778786643968,
  "created_at" : "2013-09-25 14:50:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382857498325422080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597155302, -122.2754035333 ]
  },
  "id_str" : "382874937448349697",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik You do good work, Erik!",
  "id" : 382874937448349697,
  "in_reply_to_status_id" : 382857498325422080,
  "created_at" : "2013-09-25 14:31:13 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/HzSnTv5oV9",
      "expanded_url" : "http:\/\/m.huffpost.com\/us\/entry\/3936937",
      "display_url" : "m.huffpost.com\/us\/entry\/39369\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597295322, -122.2754485444 ]
  },
  "id_str" : "382868727319887872",
  "text" : "\"Have you noticed that eulogies celebrate life very differently from how we define success in everyday existence?\" http:\/\/t.co\/HzSnTv5oV9",
  "id" : 382868727319887872,
  "created_at" : "2013-09-25 14:06:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382770766800252928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597610389, -122.2754713868 ]
  },
  "id_str" : "382853635886948352",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik It's one of my favorite gems ever made!",
  "id" : 382853635886948352,
  "in_reply_to_status_id" : 382770766800252928,
  "created_at" : "2013-09-25 13:06:34 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    }, {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 9, 23 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382746760797360128",
  "geo" : { },
  "id_str" : "382747165321220096",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean @buster_ebooks Better than an away message.",
  "id" : 382747165321220096,
  "in_reply_to_status_id" : 382746760797360128,
  "created_at" : "2013-09-25 06:03:29 +0000",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382745714758918144",
  "text" : "ebooks accounts are the new stellar bots",
  "id" : 382745714758918144,
  "created_at" : "2013-09-25 05:57:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Reich",
      "screen_name" : "ohheygreat",
      "indices" : [ 0, 11 ],
      "id_str" : "9670142",
      "id" : 9670142
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 12, 18 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382738218459742208",
  "geo" : { },
  "id_str" : "382745058450997248",
  "in_reply_to_user_id" : 9670142,
  "text" : "@ohheygreat @couch Best line: \"XOXO was great fun, and I didn\u2019t hate it.\"",
  "id" : 382745058450997248,
  "in_reply_to_status_id" : 382738218459742208,
  "created_at" : "2013-09-25 05:55:07 +0000",
  "in_reply_to_screen_name" : "ohheygreat",
  "in_reply_to_user_id_str" : "9670142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 10, 24 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382739899658424320",
  "geo" : { },
  "id_str" : "382742304143855616",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @buster_ebooks Then my work here is done?",
  "id" : 382742304143855616,
  "in_reply_to_status_id" : 382739899658424320,
  "created_at" : "2013-09-25 05:44:10 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Horse ebooks",
      "screen_name" : "Horse_ebooks",
      "indices" : [ 27, 40 ],
      "id_str" : "174958347",
      "id" : 174958347
    }, {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 61, 75 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/XkUUcdJOZa",
      "expanded_url" : "http:\/\/wayoftheduck.com\/diy-horse-ebooks",
      "display_url" : "wayoftheduck.com\/diy-horse-eboo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382741545612353536",
  "text" : "Hey! Want to make your own @Horse_ebooks? Here's how I built @buster_ebooks: http:\/\/t.co\/XkUUcdJOZa",
  "id" : 382741545612353536,
  "created_at" : "2013-09-25 05:41:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 18, 32 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/pvLrebUyLj",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/erikbenson\/9928091075\/",
      "display_url" : "flickr.com\/photos\/erikben\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382735048224407552",
  "text" : "8:36pm Gisting my @buster_ebooks script http:\/\/t.co\/pvLrebUyLj",
  "id" : 382735048224407552,
  "created_at" : "2013-09-25 05:15:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aurelia Cotta",
      "screen_name" : "AureliaCotta",
      "indices" : [ 0, 13 ],
      "id_str" : "19055125",
      "id" : 19055125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382706532388859904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597508672, -122.2755274899 ]
  },
  "id_str" : "382707536782036992",
  "in_reply_to_user_id" : 19055125,
  "text" : "@AureliaCotta Yes, every employee has at least half a dozen parody, private, and bot accounts.",
  "id" : 382707536782036992,
  "in_reply_to_status_id" : 382706532388859904,
  "created_at" : "2013-09-25 03:26:01 +0000",
  "in_reply_to_screen_name" : "AureliaCotta",
  "in_reply_to_user_id_str" : "19055125",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 0, 3 ],
      "id_str" : "15504330",
      "id" : 15504330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382704753756471296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597613201, -122.2755939267 ]
  },
  "id_str" : "382707233538060288",
  "in_reply_to_user_id" : 15504330,
  "text" : "@wm Totally. And also feed the auto tweets into future Markov chains so they can evolve independently. Guess I need some random sources too.",
  "id" : 382707233538060288,
  "in_reply_to_status_id" : 382704753756471296,
  "created_at" : "2013-09-25 03:24:49 +0000",
  "in_reply_to_screen_name" : "wm",
  "in_reply_to_user_id_str" : "15504330",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Chimero",
      "screen_name" : "fchimero",
      "indices" : [ 87, 96 ],
      "id_str" : "13212522",
      "id" : 13212522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/q6Nvvi13zg",
      "expanded_url" : "http:\/\/frankchimero.com\/blog\/2013\/09\/the-inferno-of-independence\/",
      "display_url" : "frankchimero.com\/blog\/2013\/09\/t\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597457868, -122.2754604807 ]
  },
  "id_str" : "382701657638715392",
  "text" : "We need many more blog posts like this please -&gt; http:\/\/t.co\/q6Nvvi13zg (thank you, @fchimero!)",
  "id" : 382701657638715392,
  "created_at" : "2013-09-25 03:02:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aurelia Cotta",
      "screen_name" : "AureliaCotta",
      "indices" : [ 0, 13 ],
      "id_str" : "19055125",
      "id" : 19055125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382699380433633280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597264674, -122.2755078989 ]
  },
  "id_str" : "382699813499723776",
  "in_reply_to_user_id" : 19055125,
  "text" : "@AureliaCotta Good question. 170k+ tweets... impressive! How do you use to?",
  "id" : 382699813499723776,
  "in_reply_to_status_id" : 382699380433633280,
  "created_at" : "2013-09-25 02:55:20 +0000",
  "in_reply_to_screen_name" : "AureliaCotta",
  "in_reply_to_user_id_str" : "19055125",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Fine",
      "screen_name" : "samuelfine",
      "indices" : [ 0, 11 ],
      "id_str" : "200236063",
      "id" : 200236063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382698313960914944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597250777, -122.2756363987 ]
  },
  "id_str" : "382699456858038272",
  "in_reply_to_user_id" : 200236063,
  "text" : "@samuelfine I'll put up the code for others to use tonight. Currently requires your archive of tweets to work... could be adapted though.",
  "id" : 382699456858038272,
  "in_reply_to_status_id" : 382698313960914944,
  "created_at" : "2013-09-25 02:53:55 +0000",
  "in_reply_to_screen_name" : "samuelfine",
  "in_reply_to_user_id_str" : "200236063",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Betts",
      "screen_name" : "paulcbetts",
      "indices" : [ 43, 54 ],
      "id_str" : "7482442",
      "id" : 7482442
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 56, 63 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382698358206255104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596315766, -122.2753581965 ]
  },
  "id_str" : "382699093350289409",
  "in_reply_to_user_id" : 7482442,
  "text" : "Would be happy to post it later tonight RT @paulcbetts: @buster is the source available?",
  "id" : 382699093350289409,
  "in_reply_to_status_id" : 382698358206255104,
  "created_at" : "2013-09-25 02:52:28 +0000",
  "in_reply_to_screen_name" : "paulcbetts",
  "in_reply_to_user_id_str" : "7482442",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 0, 3 ],
      "id_str" : "15504330",
      "id" : 15504330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382698736901578752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598222249, -122.2754322167 ]
  },
  "id_str" : "382698910809980928",
  "in_reply_to_user_id" : 15504330,
  "text" : "@wm But that's my marketing strategy!",
  "id" : 382698910809980928,
  "in_reply_to_status_id" : 382698736901578752,
  "created_at" : "2013-09-25 02:51:45 +0000",
  "in_reply_to_screen_name" : "wm",
  "in_reply_to_user_id_str" : "15504330",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 3, 17 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382698564041732098",
  "text" : "RT @buster_ebooks: The death of loved ones can change the size of a cat named Stoli for 10.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/busterbenson.com\" rel=\"nofollow\"\u003EBuster eBooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382648190358417408",
    "text" : "The death of loved ones can change the size of a cat named Stoli for 10.",
    "id" : 382648190358417408,
    "created_at" : "2013-09-24 23:30:12 +0000",
    "user" : {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "protected" : false,
      "id_str" : "1901375096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000503050571\/228ccabfeeb4e55bd8e172595babe02e_normal.jpeg",
      "id" : 1901375096,
      "verified" : false
    }
  },
  "id" : 382698564041732098,
  "created_at" : "2013-09-25 02:50:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 3, 17 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382698477144121346",
  "text" : "RT @buster_ebooks: Nothing much happening other than it makes a huge inspiration",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/busterbenson.com\" rel=\"nofollow\"\u003EBuster eBooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382645672496754688",
    "text" : "Nothing much happening other than it makes a huge inspiration",
    "id" : 382645672496754688,
    "created_at" : "2013-09-24 23:20:12 +0000",
    "user" : {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "protected" : false,
      "id_str" : "1901375096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000503050571\/228ccabfeeb4e55bd8e172595babe02e_normal.jpeg",
      "id" : 1901375096,
      "verified" : false
    }
  },
  "id" : 382698477144121346,
  "created_at" : "2013-09-25 02:50:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382697401313525760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859741758, -122.2754473423 ]
  },
  "id_str" : "382698036566040577",
  "in_reply_to_user_id" : 2185,
  "text" : "Resulting random Frankenstein tweets are probably only funny to me. Plus side: now I can live forever!",
  "id" : 382698036566040577,
  "in_reply_to_status_id" : 382697401313525760,
  "created_at" : "2013-09-25 02:48:16 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382696338728574976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859772308, -122.2754901841 ]
  },
  "id_str" : "382697401313525760",
  "in_reply_to_user_id" : 2185,
  "text" : "Just downloaded my 15k tweet archive, stripped links, and ran a Markov chain engine over them. About 10 lines of code.",
  "id" : 382697401313525760,
  "in_reply_to_status_id" : 382696338728574976,
  "created_at" : "2013-09-25 02:45:45 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 59, 73 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382696338728574976",
  "text" : "My own personal horse ebooks to fill the hole in my heart: @buster_ebooks",
  "id" : 382696338728574976,
  "created_at" : "2013-09-25 02:41:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382543758836781057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7770299158, -122.4169287898 ]
  },
  "id_str" : "382551320369963008",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Dude I get your posts via email!",
  "id" : 382551320369963008,
  "in_reply_to_status_id" : 382543758836781057,
  "created_at" : "2013-09-24 17:05:16 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382525719433052161",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764543667, -122.4166040431 ]
  },
  "id_str" : "382540799457492992",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Great post. Now I'm even extra-sadder to have missed it. Next year I hope the stars align. Will you go again?",
  "id" : 382540799457492992,
  "in_reply_to_status_id" : 382525719433052161,
  "created_at" : "2013-09-24 16:23:28 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "indices" : [ 26, 37 ],
      "id_str" : "419710142",
      "id" : 419710142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/OPrAkfCxCh",
      "expanded_url" : "http:\/\/pndo.ly\/1bDjVfY",
      "display_url" : "pndo.ly\/1bDjVfY"
    } ]
  },
  "in_reply_to_status_id_str" : "382500036489125889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597198169, -122.2755805212 ]
  },
  "id_str" : "382508016693571585",
  "in_reply_to_user_id" : 419710142,
  "text" : "So much confabulation: RT @PandoDaily: How do you succeed against Facebook? Make your network \"antisocial.\" http:\/\/t.co\/OPrAkfCxCh",
  "id" : 382508016693571585,
  "in_reply_to_status_id" : 382500036489125889,
  "created_at" : "2013-09-24 14:13:12 +0000",
  "in_reply_to_screen_name" : "PandoDaily",
  "in_reply_to_user_id_str" : "419710142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain Carle",
      "screen_name" : "froginthevalley",
      "indices" : [ 3, 19 ],
      "id_str" : "657693",
      "id" : 657693
    }, {
      "name" : "Instapaper",
      "screen_name" : "instapaper",
      "indices" : [ 119, 130 ],
      "id_str" : "16240267",
      "id" : 16240267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/p1tqVGBrFu",
      "expanded_url" : "http:\/\/j.mp\/18jBbDF",
      "display_url" : "j.mp\/18jBbDF"
    } ]
  },
  "geo" : { },
  "id_str" : "382380866481057792",
  "text" : "RT @froginthevalley: What Clayton Christensen Got Wrong in his Theory of Low-End Disruption http:\/\/t.co\/p1tqVGBrFu via @instapaper",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.instapaper.com\/\" rel=\"nofollow\"\u003EInstapaper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Instapaper",
        "screen_name" : "instapaper",
        "indices" : [ 98, 109 ],
        "id_str" : "16240267",
        "id" : 16240267
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/p1tqVGBrFu",
        "expanded_url" : "http:\/\/j.mp\/18jBbDF",
        "display_url" : "j.mp\/18jBbDF"
      } ]
    },
    "geo" : { },
    "id_str" : "382373682850455552",
    "text" : "What Clayton Christensen Got Wrong in his Theory of Low-End Disruption http:\/\/t.co\/p1tqVGBrFu via @instapaper",
    "id" : 382373682850455552,
    "created_at" : "2013-09-24 05:19:24 +0000",
    "user" : {
      "name" : "Sylvain Carle",
      "screen_name" : "froginthevalley",
      "protected" : false,
      "id_str" : "657693",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425774377657827328\/p8B9ooUc_normal.png",
      "id" : 657693,
      "verified" : false
    }
  },
  "id" : 382380866481057792,
  "created_at" : "2013-09-24 05:47:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Knauss",
      "screen_name" : "gknauss",
      "indices" : [ 0, 8 ],
      "id_str" : "3163591",
      "id" : 3163591
    }, {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 9, 16 ],
      "id_str" : "11604",
      "id" : 11604
    }, {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 17, 26 ],
      "id_str" : "761975",
      "id" : 761975
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 27, 36 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382323284957605888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597187995, -122.2754940626 ]
  },
  "id_str" : "382358561738612736",
  "in_reply_to_user_id" : 11604,
  "text" : "@gknauss @torrez @mathowie @anildash I'm in too.",
  "id" : 382358561738612736,
  "in_reply_to_status_id" : 382323284957605888,
  "created_at" : "2013-09-24 04:19:19 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Knauss",
      "screen_name" : "gknauss",
      "indices" : [ 3, 11 ],
      "id_str" : "3163591",
      "id" : 3163591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/v6c9HRftQ0",
      "expanded_url" : "http:\/\/www.eod.com\/blog\/2013\/09\/talking-about-failure\/",
      "display_url" : "eod.com\/blog\/2013\/09\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382357805283299328",
  "text" : "RT @gknauss: Talking About Failure: http:\/\/t.co\/v6c9HRftQ0.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/v6c9HRftQ0",
        "expanded_url" : "http:\/\/www.eod.com\/blog\/2013\/09\/talking-about-failure\/",
        "display_url" : "eod.com\/blog\/2013\/09\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "382297495230894081",
    "text" : "Talking About Failure: http:\/\/t.co\/v6c9HRftQ0.",
    "id" : 382297495230894081,
    "created_at" : "2013-09-24 00:16:40 +0000",
    "user" : {
      "name" : "Greg Knauss",
      "screen_name" : "gknauss",
      "protected" : false,
      "id_str" : "3163591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/38137892\/greg-icon-128_normal.gif",
      "id" : 3163591,
      "verified" : false
    }
  },
  "id" : 382357805283299328,
  "created_at" : "2013-09-24 04:16:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/ja6NZcE2sa",
      "expanded_url" : "http:\/\/flic.kr\/p\/g6E6q9",
      "display_url" : "flic.kr\/p\/g6E6q9"
    } ]
  },
  "geo" : { },
  "id_str" : "382348951468666880",
  "text" : "8:36pm Niko's pretty stoked about his new shoes http:\/\/t.co\/ja6NZcE2sa",
  "id" : 382348951468666880,
  "created_at" : "2013-09-24 03:41:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Glass",
      "screen_name" : "Baxley",
      "indices" : [ 0, 7 ],
      "id_str" : "5667292",
      "id" : 5667292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382293984909225984",
  "geo" : { },
  "id_str" : "382295570972295168",
  "in_reply_to_user_id" : 5667292,
  "text" : "@Baxley I *do* love it. Haven't been to CalShakes yet though\u2026 have barely scratched the surface.",
  "id" : 382295570972295168,
  "in_reply_to_status_id" : 382293984909225984,
  "created_at" : "2013-09-24 00:09:01 +0000",
  "in_reply_to_screen_name" : "Baxley",
  "in_reply_to_user_id_str" : "5667292",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Glass",
      "screen_name" : "Baxley",
      "indices" : [ 0, 7 ],
      "id_str" : "5667292",
      "id" : 5667292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382289482755489793",
  "geo" : { },
  "id_str" : "382293812833288192",
  "in_reply_to_user_id" : 5667292,
  "text" : "@Baxley Close\u2026 moved to Berkeley earlier this year.",
  "id" : 382293812833288192,
  "in_reply_to_status_id" : 382289482755489793,
  "created_at" : "2013-09-24 00:02:02 +0000",
  "in_reply_to_screen_name" : "Baxley",
  "in_reply_to_user_id_str" : "5667292",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Glass",
      "screen_name" : "Baxley",
      "indices" : [ 0, 7 ],
      "id_str" : "5667292",
      "id" : 5667292
    }, {
      "name" : "Brian Goldfarb",
      "screen_name" : "bgoldy",
      "indices" : [ 8, 15 ],
      "id_str" : "7062302",
      "id" : 7062302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382280682182934528",
  "in_reply_to_user_id" : 5667292,
  "text" : "@Baxley @bgoldy Ha, yes, that was a night to remember.",
  "id" : 382280682182934528,
  "created_at" : "2013-09-23 23:09:51 +0000",
  "in_reply_to_screen_name" : "Baxley",
  "in_reply_to_user_id_str" : "5667292",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arthur Zey",
      "screen_name" : "LogicalArthur",
      "indices" : [ 0, 14 ],
      "id_str" : "40284074",
      "id" : 40284074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382008047796637696",
  "geo" : { },
  "id_str" : "382008767698583552",
  "in_reply_to_user_id" : 40284074,
  "text" : "@LogicalArthur Wow, awesome! We were even in that general neighborhood as well.",
  "id" : 382008767698583552,
  "in_reply_to_status_id" : 382008047796637696,
  "created_at" : "2013-09-23 05:09:22 +0000",
  "in_reply_to_screen_name" : "LogicalArthur",
  "in_reply_to_user_id_str" : "40284074",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/UiElu9vugh",
      "expanded_url" : "http:\/\/www.jacobian.org\/writing\/xoxo\/",
      "display_url" : "jacobian.org\/writing\/xoxo\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596537787, -122.2755605071 ]
  },
  "id_str" : "382003108366147585",
  "text" : "\"The longer you go, the harder it gets because it feels like you have to break that silence with something awesome.\" http:\/\/t.co\/UiElu9vugh",
  "id" : 382003108366147585,
  "created_at" : "2013-09-23 04:46:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/0YM9auo6gp",
      "expanded_url" : "http:\/\/flic.kr\/p\/g4UskC",
      "display_url" : "flic.kr\/p\/g4UskC"
    } ]
  },
  "geo" : { },
  "id_str" : "381989452350255104",
  "text" : "8:36pm Exhausted sleepy and really tired. http:\/\/t.co\/0YM9auo6gp",
  "id" : 381989452350255104,
  "created_at" : "2013-09-23 03:52:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 39, 46 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 51, 55 ],
      "id_str" : "259",
      "id" : 259
    }, {
      "name" : "Scribe Winery",
      "screen_name" : "scribewinery",
      "indices" : [ 88, 101 ],
      "id_str" : "209727447",
      "id" : 209727447
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/381907496438222848\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/No88zG8Gtp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUzO2DBCMAASPPr.jpg",
      "id_str" : "381907496337551360",
      "id" : 381907496337551360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUzO2DBCMAASPPr.jpg",
      "sizes" : [ {
        "h" : 131,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 74,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/No88zG8Gtp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381907496438222848",
  "text" : "Just topped off a perfect weekend with @sharon and @ian by visiting\/becoming members at @scribewinery. http:\/\/t.co\/No88zG8Gtp",
  "id" : 381907496438222848,
  "created_at" : "2013-09-22 22:26:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 3, 14 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381905503451754496",
  "text" : "RT @nikobenson: On being stung by two bees: I think the bee stung me in the eye because he thought I was tasty but then he was like pbbbbth\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381905326007517184",
    "text" : "On being stung by two bees: I think the bee stung me in the eye because he thought I was tasty but then he was like pbbbbthh and stung me.",
    "id" : 381905326007517184,
    "created_at" : "2013-09-22 22:18:19 +0000",
    "user" : {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "protected" : false,
      "id_str" : "142467448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000616213793\/9f77fe6693d877565cd97b6a2381c40c_normal.jpeg",
      "id" : 142467448,
      "verified" : false
    }
  },
  "id" : 381905503451754496,
  "created_at" : "2013-09-22 22:19:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/frontback.me\" rel=\"nofollow\"\u003EFrontback\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "frontback",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/fKSLmYUu8w",
      "expanded_url" : "http:\/\/frontback.me\/p\/l8z1G9d7",
      "display_url" : "frontback.me\/p\/l8z1G9d7"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.2749023438, -122.4133911133 ]
  },
  "id_str" : "381896991007342592",
  "text" : "Crazy old house http:\/\/t.co\/fKSLmYUu8w #frontback",
  "id" : 381896991007342592,
  "created_at" : "2013-09-22 21:45:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Brewer",
      "screen_name" : "jbrewer",
      "indices" : [ 0, 8 ],
      "id_str" : "12555",
      "id" : 12555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381890443224428544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.2748656534, -122.4131835067 ]
  },
  "id_str" : "381891668095422464",
  "in_reply_to_user_id" : 12555,
  "text" : "@jbrewer I agree. Rare to actually learn something from a tech article.",
  "id" : 381891668095422464,
  "in_reply_to_status_id" : 381890443224428544,
  "created_at" : "2013-09-22 21:24:03 +0000",
  "in_reply_to_screen_name" : "jbrewer",
  "in_reply_to_user_id_str" : "12555",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/mjktmjRZ4Q",
      "expanded_url" : "https:\/\/vine.co\/v\/hrqOZAi0bB1",
      "display_url" : "vine.co\/v\/hrqOZAi0bB1"
    } ]
  },
  "geo" : { },
  "id_str" : "381889836933996544",
  "text" : "Spinning at Scribe https:\/\/t.co\/mjktmjRZ4Q",
  "id" : 381889836933996544,
  "created_at" : "2013-09-22 21:16:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/GntJxJwZlR",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/09\/22\/technology\/life-as-instant-replay-over-and-over-again.html?_r=2&",
      "display_url" : "nytimes.com\/2013\/09\/22\/tec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381869813154336768",
  "text" : "\"The real-time Web is in a state of hyperactive stasis, like amped-up fans waiting for a concert to start.\" http:\/\/t.co\/GntJxJwZlR",
  "id" : 381869813154336768,
  "created_at" : "2013-09-22 19:57:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381656144449511424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.6178761746, -122.6720630569 ]
  },
  "id_str" : "381667300538978304",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey It is a hilarious and sad thing.",
  "id" : 381667300538978304,
  "in_reply_to_status_id" : 381656144449511424,
  "created_at" : "2013-09-22 06:32:30 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381653397620809728",
  "text" : "Doing Tarot with Cards Against Humanity cards.",
  "id" : 381653397620809728,
  "created_at" : "2013-09-22 05:37:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.6180417659, -122.672658479 ]
  },
  "id_str" : "381645475754962944",
  "text" : "A fat old dragon with no friends.",
  "id" : 381645475754962944,
  "created_at" : "2013-09-22 05:05:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 51, 58 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 63, 67 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/WB9lq1nrjp",
      "expanded_url" : "http:\/\/flic.kr\/p\/g2WVMZ",
      "display_url" : "flic.kr\/p\/g2WVMZ"
    } ]
  },
  "geo" : { },
  "id_str" : "381634105911570432",
  "text" : "8:36pm Weekend vacation BBQ dinner with the lovely @sharon and @ian http:\/\/t.co\/WB9lq1nrjp",
  "id" : 381634105911570432,
  "created_at" : "2013-09-22 04:20:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/kRA0nd0GA0",
      "expanded_url" : "http:\/\/flic.kr\/p\/g2AZfk",
      "display_url" : "flic.kr\/p\/g2AZfk"
    } ]
  },
  "geo" : { },
  "id_str" : "381556969171329024",
  "text" : "Drinking some sparkling wine from Yolo County http:\/\/t.co\/kRA0nd0GA0",
  "id" : 381556969171329024,
  "created_at" : "2013-09-21 23:14:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/381548523310702592\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/ouLqj2NkmI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUuIXDdCYAAcQG5.jpg",
      "id_str" : "381548523088404480",
      "id" : 381548523088404480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUuIXDdCYAAcQG5.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 129,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 73,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ouLqj2NkmI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.6182716915, -122.6721611894 ]
  },
  "id_str" : "381548523310702592",
  "text" : "Another ugly day http:\/\/t.co\/ouLqj2NkmI",
  "id" : 381548523310702592,
  "created_at" : "2013-09-21 22:40:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 0, 4 ],
      "id_str" : "12720772",
      "id" : 12720772
    }, {
      "name" : "Geoffy Drama",
      "screen_name" : "GeoffyDrama",
      "indices" : [ 5, 17 ],
      "id_str" : "1312118102",
      "id" : 1312118102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381306725036331008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.617945374, -122.6726298967 ]
  },
  "id_str" : "381307020520857600",
  "in_reply_to_user_id" : 12720772,
  "text" : "@gwb @GeoffyDrama I hope that day is soon because the end is nigh.",
  "id" : 381307020520857600,
  "in_reply_to_status_id" : 381306725036331008,
  "created_at" : "2013-09-21 06:40:52 +0000",
  "in_reply_to_screen_name" : "gwb",
  "in_reply_to_user_id_str" : "12720772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffy Drama",
      "screen_name" : "GeoffyDrama",
      "indices" : [ 0, 12 ],
      "id_str" : "1312118102",
      "id" : 1312118102
    }, {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 13, 17 ],
      "id_str" : "12720772",
      "id" : 12720772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "death",
      "indices" : [ 65, 71 ]
    }, {
      "text" : "existentialism",
      "indices" : [ 72, 87 ]
    }, {
      "text" : "futility",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381293193737674752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.6179110082, -122.6725777612 ]
  },
  "id_str" : "381306312627191808",
  "in_reply_to_user_id" : 1312118102,
  "text" : "@GeoffyDrama @gwb Come baaaaack! You'll still die anyway though. #death #existentialism #futility",
  "id" : 381306312627191808,
  "in_reply_to_status_id" : 381293193737674752,
  "created_at" : "2013-09-21 06:38:03 +0000",
  "in_reply_to_screen_name" : "GeoffyDrama",
  "in_reply_to_user_id_str" : "1312118102",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/jRpmYblKd6",
      "expanded_url" : "http:\/\/flic.kr\/p\/g1fL6S",
      "display_url" : "flic.kr\/p\/g1fL6S"
    } ]
  },
  "geo" : { },
  "id_str" : "381281268799131648",
  "text" : "8:36pm We drank a lot of wine and sat in a hot tub http:\/\/t.co\/jRpmYblKd6",
  "id" : 381281268799131648,
  "created_at" : "2013-09-21 04:58:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.868474303, -122.2955458428 ]
  },
  "id_str" : "381195063465766912",
  "text" : "Just saw 7 turkeys cross the street at a crosswalk in Berkeley.",
  "id" : 381195063465766912,
  "created_at" : "2013-09-20 23:16:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/isaach\/status\/381116460661104640\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/OXK57vYYWV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUn_ZsMCUAE6aS-.png",
      "id_str" : "381116460312973313",
      "id" : 381116460312973313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUn_ZsMCUAE6aS-.png",
      "sizes" : [ {
        "h" : 736,
        "resize" : "fit",
        "w" : 964
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 736,
        "resize" : "fit",
        "w" : 964
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OXK57vYYWV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/ySRGiFf2WA",
      "expanded_url" : "http:\/\/www.dailymail.co.uk\/news\/article-2139914\/A-rare-insight-Kowloon-Walled-City.html",
      "display_url" : "dailymail.co.uk\/news\/article-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381155402194223104",
  "text" : "RT @isaach: stunning photos of the most densely populated place on earth before it was demolished in 1992 http:\/\/t.co\/ySRGiFf2WA http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/isaach\/status\/381116460661104640\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/OXK57vYYWV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUn_ZsMCUAE6aS-.png",
        "id_str" : "381116460312973313",
        "id" : 381116460312973313,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUn_ZsMCUAE6aS-.png",
        "sizes" : [ {
          "h" : 736,
          "resize" : "fit",
          "w" : 964
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 736,
          "resize" : "fit",
          "w" : 964
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OXK57vYYWV"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/ySRGiFf2WA",
        "expanded_url" : "http:\/\/www.dailymail.co.uk\/news\/article-2139914\/A-rare-insight-Kowloon-Walled-City.html",
        "display_url" : "dailymail.co.uk\/news\/article-2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381116460661104640",
    "text" : "stunning photos of the most densely populated place on earth before it was demolished in 1992 http:\/\/t.co\/ySRGiFf2WA http:\/\/t.co\/OXK57vYYWV",
    "id" : 381116460661104640,
    "created_at" : "2013-09-20 18:03:39 +0000",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430605387117494272\/lmplHwca_normal.png",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 381155402194223104,
  "created_at" : "2013-09-20 20:38:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Owen Thomas",
      "screen_name" : "owenthomas",
      "indices" : [ 0, 11 ],
      "id_str" : "3034251",
      "id" : 3034251
    }, {
      "name" : "Erin Frey",
      "screen_name" : "erinfrey",
      "indices" : [ 12, 21 ],
      "id_str" : "20031223",
      "id" : 20031223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381138849797120000",
  "geo" : { },
  "id_str" : "381139520684433409",
  "in_reply_to_user_id" : 3034251,
  "text" : "@owenthomas @erinfrey I've Pocket'd the article for the subway home\u2026 looks great. So happy that the ideas are gaining steam.",
  "id" : 381139520684433409,
  "in_reply_to_status_id" : 381138849797120000,
  "created_at" : "2013-09-20 19:35:17 +0000",
  "in_reply_to_screen_name" : "owenthomas",
  "in_reply_to_user_id_str" : "3034251",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Owen Thomas",
      "screen_name" : "owenthomas",
      "indices" : [ 0, 11 ],
      "id_str" : "3034251",
      "id" : 3034251
    }, {
      "name" : "Erin Frey",
      "screen_name" : "erinfrey",
      "indices" : [ 12, 21 ],
      "id_str" : "20031223",
      "id" : 20031223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381133564894408704",
  "geo" : { },
  "id_str" : "381138290734141440",
  "in_reply_to_user_id" : 3034251,
  "text" : "@owenthomas @erinfrey I love that quote you had about integrated regulation. The idea of behavior change = identity change is so important.",
  "id" : 381138290734141440,
  "in_reply_to_status_id" : 381133564894408704,
  "created_at" : "2013-09-20 19:30:24 +0000",
  "in_reply_to_screen_name" : "owenthomas",
  "in_reply_to_user_id_str" : "3034251",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "indices" : [ 0, 12 ],
      "id_str" : "289534689",
      "id" : 289534689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381101377398665216",
  "geo" : { },
  "id_str" : "381102216402042880",
  "in_reply_to_user_id" : 289534689,
  "text" : "@seriouspony Be autonomous! It's easy! Just do what I'm doing!",
  "id" : 381102216402042880,
  "in_reply_to_status_id" : 381101377398665216,
  "created_at" : "2013-09-20 17:07:03 +0000",
  "in_reply_to_screen_name" : "seriouspony",
  "in_reply_to_user_id_str" : "289534689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/uMW4v309Lz",
      "expanded_url" : "http:\/\/www.goodreads.com\/book\/show\/255127",
      "display_url" : "goodreads.com\/book\/show\/2551\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381083018225414144",
  "text" : "5 out of 5 stars for The Fifth Discipline: The Art &amp; Practice of The Learning Organization by Peter M. Senge http:\/\/t.co\/uMW4v309Lz",
  "id" : 381083018225414144,
  "created_at" : "2013-09-20 15:50:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 3, 14 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381070656638423041",
  "text" : "RT @nikobenson: Chickens are alive and then they die. That's when we eat them!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381069669064400897",
    "text" : "Chickens are alive and then they die. That's when we eat them!",
    "id" : 381069669064400897,
    "created_at" : "2013-09-20 14:57:43 +0000",
    "user" : {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "protected" : false,
      "id_str" : "142467448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000616213793\/9f77fe6693d877565cd97b6a2381c40c_normal.jpeg",
      "id" : 142467448,
      "verified" : false
    }
  },
  "id" : 381070656638423041,
  "created_at" : "2013-09-20 15:01:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Cho",
      "screen_name" : "mark_cho",
      "indices" : [ 0, 9 ],
      "id_str" : "391248959",
      "id" : 391248959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381022545593376768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596388949, -122.2756728752 ]
  },
  "id_str" : "381057298019278848",
  "in_reply_to_user_id" : 391248959,
  "text" : "@mark_cho Well, technically it's for my wife, but had to make sure the order for in as early as possible. Are you in line somewhere? :)",
  "id" : 381057298019278848,
  "in_reply_to_status_id" : 381022545593376768,
  "created_at" : "2013-09-20 14:08:34 +0000",
  "in_reply_to_screen_name" : "mark_cho",
  "in_reply_to_user_id_str" : "391248959",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Singleton",
      "screen_name" : "msingleton",
      "indices" : [ 0, 11 ],
      "id_str" : "1980271",
      "id" : 1980271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380951426824142848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597574064, -122.2753770165 ]
  },
  "id_str" : "380952724407214081",
  "in_reply_to_user_id" : 1980271,
  "text" : "@msingleton Mine is 7-10 days. :(",
  "id" : 380952724407214081,
  "in_reply_to_status_id" : 380951426824142848,
  "created_at" : "2013-09-20 07:13:01 +0000",
  "in_reply_to_screen_name" : "msingleton",
  "in_reply_to_user_id_str" : "1980271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/380951306216546305\/photo\/1",
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/21wqvXZAab",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUlpMcvCMAAEARY.png",
      "id_str" : "380951306082332672",
      "id" : 380951306082332672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUlpMcvCMAAEARY.png",
      "sizes" : [ {
        "h" : 69,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 209,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 123,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 326,
        "resize" : "fit",
        "w" : 1596
      } ],
      "display_url" : "pic.twitter.com\/21wqvXZAab"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380951306216546305",
  "text" : "Got one. http:\/\/t.co\/21wqvXZAab",
  "id" : 380951306216546305,
  "created_at" : "2013-09-20 07:07:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    }, {
      "name" : "Michael Buffington",
      "screen_name" : "go",
      "indices" : [ 14, 17 ],
      "id_str" : "2984",
      "id" : 2984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380911103649136640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597557964, -122.275143955 ]
  },
  "id_str" : "380918826860171264",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel @go Oh shit!!! Did I never reply to that??? I suck at many things... email and conferences near the top of the list...",
  "id" : 380918826860171264,
  "in_reply_to_status_id" : 380911103649136640,
  "created_at" : "2013-09-20 04:58:20 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/mhEMgkUjnM",
      "expanded_url" : "http:\/\/flic.kr\/p\/fYDVbw",
      "display_url" : "flic.kr\/p\/fYDVbw"
    } ]
  },
  "geo" : { },
  "id_str" : "380901617199247360",
  "text" : "8:36pm Rosie is on a whistle-stop tour apologizing for running everyone off the rails http:\/\/t.co\/mhEMgkUjnM",
  "id" : 380901617199247360,
  "created_at" : "2013-09-20 03:49:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roving Typist",
      "screen_name" : "rovingtypist",
      "indices" : [ 73, 86 ],
      "id_str" : "305646163",
      "id" : 305646163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/YQGXeFzR3X",
      "expanded_url" : "http:\/\/www.theawl.com\/2013\/09\/i-was-a-hated-hipster-meme-and-then-it-got-worse",
      "display_url" : "theawl.com\/2013\/09\/i-was-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380770491415281664",
  "text" : "\"The Internet has both a long memory and the attention of a goldfish.\" - @rovingtypist http:\/\/t.co\/YQGXeFzR3X",
  "id" : 380770491415281664,
  "created_at" : "2013-09-19 19:08:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Graham",
      "screen_name" : "paulg",
      "indices" : [ 3, 9 ],
      "id_str" : "183749519",
      "id" : 183749519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/nI4ZZRJHQv",
      "expanded_url" : "http:\/\/bit.ly\/1gA4xPa",
      "display_url" : "bit.ly\/1gA4xPa"
    } ]
  },
  "geo" : { },
  "id_str" : "380768426676875264",
  "text" : "RT @paulg: Imaginative guy does interesting thing. Internet mob attacks him.  http:\/\/t.co\/nI4ZZRJHQv",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/nI4ZZRJHQv",
        "expanded_url" : "http:\/\/bit.ly\/1gA4xPa",
        "display_url" : "bit.ly\/1gA4xPa"
      } ]
    },
    "geo" : { },
    "id_str" : "380745967756013568",
    "text" : "Imaginative guy does interesting thing. Internet mob attacks him.  http:\/\/t.co\/nI4ZZRJHQv",
    "id" : 380745967756013568,
    "created_at" : "2013-09-19 17:31:27 +0000",
    "user" : {
      "name" : "Paul Graham",
      "screen_name" : "paulg",
      "protected" : false,
      "id_str" : "183749519",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1824002576\/pg-railsconf_normal.jpg",
      "id" : 183749519,
      "verified" : true
    }
  },
  "id" : 380768426676875264,
  "created_at" : "2013-09-19 19:00:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Lastname",
      "screen_name" : "JasonLastname",
      "indices" : [ 3, 17 ],
      "id_str" : "630728313",
      "id" : 630728313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380759788709101568",
  "text" : "RT @JasonLastname: Top baby names for Llamas:\nDolly Llama\nLlama Del Ray\nLlamageddon\nBarack O'Llama\nLlamabeans\nCliff\nLlamadeus\nVince Llambar\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "379420045589618688",
    "text" : "Top baby names for Llamas:\nDolly Llama\nLlama Del Ray\nLlamageddon\nBarack O'Llama\nLlamabeans\nCliff\nLlamadeus\nVince Llambardi\nKendrick Llamar",
    "id" : 379420045589618688,
    "created_at" : "2013-09-16 01:42:42 +0000",
    "user" : {
      "name" : "Jason Lastname",
      "screen_name" : "JasonLastname",
      "protected" : false,
      "id_str" : "630728313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/418466338701471746\/wb_A8iWw_normal.jpeg",
      "id" : 630728313,
      "verified" : false
    }
  },
  "id" : 380759788709101568,
  "created_at" : "2013-09-19 18:26:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380539857115688960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859690669, -122.2755018623 ]
  },
  "id_str" : "380545942115454976",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel He was born drunk.",
  "id" : 380545942115454976,
  "in_reply_to_status_id" : 380539857115688960,
  "created_at" : "2013-09-19 04:16:37 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/hEKVxdR8ER",
      "expanded_url" : "http:\/\/flic.kr\/p\/fX4zG5",
      "display_url" : "flic.kr\/p\/fX4zG5"
    } ]
  },
  "geo" : { },
  "id_str" : "380539277547143168",
  "text" : "8:36pm New bath time strategy worked! Plus, discovered new Thom Yorke.  http:\/\/t.co\/hEKVxdR8ER",
  "id" : 380539277547143168,
  "created_at" : "2013-09-19 03:50:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8571064445, -122.2729256005 ]
  },
  "id_str" : "380511224225468416",
  "text" : "\"It's not what the vision is, it's what the vision does.\" - Peter Senge",
  "id" : 380511224225468416,
  "created_at" : "2013-09-19 01:58:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 9, 14 ],
      "id_str" : "10959642",
      "id" : 10959642
    }, {
      "name" : "Arduino",
      "screen_name" : "arduino",
      "indices" : [ 50, 58 ],
      "id_str" : "266400754",
      "id" : 266400754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/ptiHnKzV6m",
      "expanded_url" : "http:\/\/bit.ly\/18cefEl",
      "display_url" : "bit.ly\/18cefEl"
    } ]
  },
  "geo" : { },
  "id_str" : "380493233718964224",
  "text" : "WANT! RT @tara: Can't wait to get my hands on the @arduino Robot http:\/\/t.co\/ptiHnKzV6m",
  "id" : 380493233718964224,
  "created_at" : "2013-09-19 00:47:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "indices" : [ 3, 8 ],
      "id_str" : "949521",
      "id" : 949521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/TRZK4t1g8w",
      "expanded_url" : "https:\/\/blog.twitter.com\/2013\/welcoming-ios-7",
      "display_url" : "blog.twitter.com\/2013\/welcoming\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380406779605053441",
  "text" : "RT @stop: Today we\u2019re introducing new versions of Twitter for iPhone and iPad for iOS 7... https:\/\/t.co\/TRZK4t1g8w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/TRZK4t1g8w",
        "expanded_url" : "https:\/\/blog.twitter.com\/2013\/welcoming-ios-7",
        "display_url" : "blog.twitter.com\/2013\/welcoming\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "380406615452565504",
    "text" : "Today we\u2019re introducing new versions of Twitter for iPhone and iPad for iOS 7... https:\/\/t.co\/TRZK4t1g8w",
    "id" : 380406615452565504,
    "created_at" : "2013-09-18 19:02:59 +0000",
    "user" : {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "protected" : false,
      "id_str" : "949521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441691596375863296\/H7LzEpDT_normal.jpeg",
      "id" : 949521,
      "verified" : false
    }
  },
  "id" : 380406779605053441,
  "created_at" : "2013-09-18 19:03:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Dodds",
      "screen_name" : "johndodds",
      "indices" : [ 0, 10 ],
      "id_str" : "5409812",
      "id" : 5409812
    }, {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "indices" : [ 11, 23 ],
      "id_str" : "289534689",
      "id" : 289534689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380376451649781760",
  "geo" : { },
  "id_str" : "380376735880986624",
  "in_reply_to_user_id" : 5409812,
  "text" : "@johndodds @seriouspony I listened to the audiobooks of both and found them immensely enjoyable\u2026 perfect walking\/commute listening.",
  "id" : 380376735880986624,
  "in_reply_to_status_id" : 380376451649781760,
  "created_at" : "2013-09-18 17:04:15 +0000",
  "in_reply_to_screen_name" : "johndodds",
  "in_reply_to_user_id_str" : "5409812",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "indices" : [ 0, 12 ],
      "id_str" : "289534689",
      "id" : 289534689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380372311821414400",
  "geo" : { },
  "id_str" : "380375394769059840",
  "in_reply_to_user_id" : 289534689,
  "text" : "@seriouspony Now *that* would be awesome. A children's version of Antifragile would be great too.",
  "id" : 380375394769059840,
  "in_reply_to_status_id" : 380372311821414400,
  "created_at" : "2013-09-18 16:58:55 +0000",
  "in_reply_to_screen_name" : "seriouspony",
  "in_reply_to_user_id_str" : "289534689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "indices" : [ 0, 12 ],
      "id_str" : "289534689",
      "id" : 289534689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380371775223111680",
  "geo" : { },
  "id_str" : "380371983411597312",
  "in_reply_to_user_id" : 289534689,
  "text" : "@seriouspony We should all read that book 10 times.",
  "id" : 380371983411597312,
  "in_reply_to_status_id" : 380371775223111680,
  "created_at" : "2013-09-18 16:45:22 +0000",
  "in_reply_to_screen_name" : "seriouspony",
  "in_reply_to_user_id_str" : "289534689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Edwards",
      "screen_name" : "RobertCEdwards",
      "indices" : [ 0, 15 ],
      "id_str" : "31470838",
      "id" : 31470838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379478106504830977",
  "geo" : { },
  "id_str" : "380224346444152832",
  "in_reply_to_user_id" : 31470838,
  "text" : "@RobertCEdwards If I could wave a magic open-source wand I would... since I can't I am waiting for a period of time to do the work.",
  "id" : 380224346444152832,
  "in_reply_to_status_id" : 379478106504830977,
  "created_at" : "2013-09-18 06:58:43 +0000",
  "in_reply_to_screen_name" : "RobertCEdwards",
  "in_reply_to_user_id_str" : "31470838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "coder school dropout",
      "screen_name" : "meat",
      "indices" : [ 0, 5 ],
      "id_str" : "21006515",
      "id" : 21006515
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lost",
      "indices" : [ 6, 11 ]
    }, {
      "text" : "forever",
      "indices" : [ 12, 20 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380199007483486208",
  "geo" : { },
  "id_str" : "380199166690873344",
  "in_reply_to_user_id" : 21006515,
  "text" : "@meat #lost #forever",
  "id" : 380199166690873344,
  "in_reply_to_status_id" : 380199007483486208,
  "created_at" : "2013-09-18 05:18:39 +0000",
  "in_reply_to_screen_name" : "meat",
  "in_reply_to_user_id_str" : "21006515",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burma Superstar",
      "screen_name" : "BurmaSuperstar",
      "indices" : [ 34, 49 ],
      "id_str" : "39210675",
      "id" : 39210675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380198573733715968",
  "text" : "I wish I could tweet the taste of @BurmaSuperstar's rainbow salad.",
  "id" : 380198573733715968,
  "created_at" : "2013-09-18 05:16:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/lbiN7nsnwn",
      "expanded_url" : "http:\/\/flic.kr\/p\/fVxDim",
      "display_url" : "flic.kr\/p\/fVxDim"
    } ]
  },
  "geo" : { },
  "id_str" : "380176988579061760",
  "text" : "8:36pm Starving at Burma Superstar. A good condition to be in. http:\/\/t.co\/lbiN7nsnwn",
  "id" : 380176988579061760,
  "created_at" : "2013-09-18 03:50:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/timehop.com\/\" rel=\"nofollow\"\u003ETimehop\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 31, 41 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Timehop",
      "screen_name" : "timehop",
      "indices" : [ 81, 89 ],
      "id_str" : "436143123",
      "id" : 436143123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/xuTBKsJXKy",
      "expanded_url" : "http:\/\/timehop.com\/c\/t:275481782:2185:80600:e6c43",
      "display_url" : "timehop.com\/c\/t:275481782:\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380070761035476992",
  "text" : "Announced I was going to marry @kellianne on LiveJournal 6 years ago today. \/via @timehop http:\/\/t.co\/xuTBKsJXKy",
  "id" : 380070761035476992,
  "created_at" : "2013-09-17 20:48:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Morning News",
      "screen_name" : "TheMorningNews",
      "indices" : [ 3, 18 ],
      "id_str" : "16539190",
      "id" : 16539190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/bmIVnqNQGY",
      "expanded_url" : "http:\/\/tmne.ws\/3zgwCs",
      "display_url" : "tmne.ws\/3zgwCs"
    } ]
  },
  "geo" : { },
  "id_str" : "380062530682359808",
  "text" : "RT @TheMorningNews: It's quite common for an individual to have multiple genomes. Some people...have genomes that came from other... http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/bmIVnqNQGY",
        "expanded_url" : "http:\/\/tmne.ws\/3zgwCs",
        "display_url" : "tmne.ws\/3zgwCs"
      } ]
    },
    "geo" : { },
    "id_str" : "380062065932505089",
    "text" : "It's quite common for an individual to have multiple genomes. Some people...have genomes that came from other... http:\/\/t.co\/bmIVnqNQGY",
    "id" : 380062065932505089,
    "created_at" : "2013-09-17 20:13:52 +0000",
    "user" : {
      "name" : "The Morning News",
      "screen_name" : "TheMorningNews",
      "protected" : false,
      "id_str" : "16539190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2874633077\/d338f787e09282765a8259599da44b97_normal.png",
      "id" : 16539190,
      "verified" : false
    }
  },
  "id" : 380062530682359808,
  "created_at" : "2013-09-17 20:15:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Sandquist",
      "screen_name" : "jeffsand",
      "indices" : [ 0, 9 ],
      "id_str" : "229523",
      "id" : 229523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380019216671186944",
  "geo" : { },
  "id_str" : "380030574653493249",
  "in_reply_to_user_id" : 229523,
  "text" : "@jeffsand Excited to work with you!",
  "id" : 380030574653493249,
  "in_reply_to_status_id" : 380019216671186944,
  "created_at" : "2013-09-17 18:08:44 +0000",
  "in_reply_to_screen_name" : "jeffsand",
  "in_reply_to_user_id_str" : "229523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 3, 14 ],
      "id_str" : "2384071",
      "id" : 2384071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/oRbzZBsBj7",
      "expanded_url" : "http:\/\/linkd.in\/15YsiS3",
      "display_url" : "linkd.in\/15YsiS3"
    } ]
  },
  "geo" : { },
  "id_str" : "380015248259825664",
  "text" : "RT @timoreilly: I'm delighted by the response to my post about growing a great company, w\/ the counterintuitive title \"How I Failed\" http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/oRbzZBsBj7",
        "expanded_url" : "http:\/\/linkd.in\/15YsiS3",
        "display_url" : "linkd.in\/15YsiS3"
      } ]
    },
    "geo" : { },
    "id_str" : "378631191378661377",
    "text" : "I'm delighted by the response to my post about growing a great company, w\/ the counterintuitive title \"How I Failed\" http:\/\/t.co\/oRbzZBsBj7",
    "id" : 378631191378661377,
    "created_at" : "2013-09-13 21:28:05 +0000",
    "user" : {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "protected" : false,
      "id_str" : "2384071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2823681988\/f4f6f2bed8ab4d5a48dea4b9ea85d5f1_normal.jpeg",
      "id" : 2384071,
      "verified" : true
    }
  },
  "id" : 380015248259825664,
  "created_at" : "2013-09-17 17:07:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.goodreads.com\" rel=\"nofollow\"\u003EGoodreads\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/fniqa8P9V7",
      "expanded_url" : "http:\/\/bit.ly\/18vfbYr",
      "display_url" : "bit.ly\/18vfbYr"
    } ]
  },
  "geo" : { },
  "id_str" : "380005618481762304",
  "text" : "5 of 5 stars to Antifragile by Nassim Nicholas Taleb http:\/\/t.co\/fniqa8P9V7",
  "id" : 380005618481762304,
  "created_at" : "2013-09-17 16:29:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nassim N. Taleb",
      "screen_name" : "nntaleb",
      "indices" : [ 83, 91 ],
      "id_str" : "381289719",
      "id" : 381289719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380004558807642112",
  "text" : "\"The best way to verify if you are alive is by checking if you like variations.\" - @nntaleb in Antifragile",
  "id" : 380004558807642112,
  "created_at" : "2013-09-17 16:25:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bodge",
      "screen_name" : "mikebodge",
      "indices" : [ 0, 10 ],
      "id_str" : "19344531",
      "id" : 19344531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379969111700541440",
  "geo" : { },
  "id_str" : "379972898674331648",
  "in_reply_to_user_id" : 19344531,
  "text" : "@mikebodge Me!",
  "id" : 379972898674331648,
  "in_reply_to_status_id" : 379969111700541440,
  "created_at" : "2013-09-17 14:19:33 +0000",
  "in_reply_to_screen_name" : "mikebodge",
  "in_reply_to_user_id_str" : "19344531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Scheibach",
      "screen_name" : "jshy",
      "indices" : [ 0, 5 ],
      "id_str" : "804659",
      "id" : 804659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379833890677874688",
  "geo" : { },
  "id_str" : "379835275322482688",
  "in_reply_to_user_id" : 804659,
  "text" : "@jshy I say give in! It's what the kids are all doing these days.",
  "id" : 379835275322482688,
  "in_reply_to_status_id" : 379833890677874688,
  "created_at" : "2013-09-17 05:12:41 +0000",
  "in_reply_to_screen_name" : "jshy",
  "in_reply_to_user_id_str" : "804659",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Gordon",
      "screen_name" : "JeremySF",
      "indices" : [ 59, 68 ],
      "id_str" : "19872718",
      "id" : 19872718
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 70, 77 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379829209293549568",
  "geo" : { },
  "id_str" : "379831748600684545",
  "in_reply_to_user_id" : 19872718,
  "text" : "Suggestions for coolest bath toy ever for a 3-year-old? RT @JeremySF: @buster +1 on more bath toys.",
  "id" : 379831748600684545,
  "in_reply_to_status_id" : 379829209293549568,
  "created_at" : "2013-09-17 04:58:40 +0000",
  "in_reply_to_screen_name" : "JeremySF",
  "in_reply_to_user_id_str" : "19872718",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379829485287116800",
  "geo" : { },
  "id_str" : "379830403986489345",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey I'm picturing rusty saws and scrap metal.",
  "id" : 379830403986489345,
  "in_reply_to_status_id" : 379829485287116800,
  "created_at" : "2013-09-17 04:53:19 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisa Bonsignore",
      "screen_name" : "clearwriter",
      "indices" : [ 0, 12 ],
      "id_str" : "17029915",
      "id" : 17029915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379829023590727680",
  "geo" : { },
  "id_str" : "379830097902989312",
  "in_reply_to_user_id" : 17029915,
  "text" : "@clearwriter Yeah, and the switch happened so quickly! My emotions take hours to shift gears these days.",
  "id" : 379830097902989312,
  "in_reply_to_status_id" : 379829023590727680,
  "created_at" : "2013-09-17 04:52:06 +0000",
  "in_reply_to_screen_name" : "clearwriter",
  "in_reply_to_user_id_str" : "17029915",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Scheibach",
      "screen_name" : "jshy",
      "indices" : [ 0, 5 ],
      "id_str" : "804659",
      "id" : 804659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nostalgia",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379829002208178177",
  "geo" : { },
  "id_str" : "379829658516086784",
  "in_reply_to_user_id" : 804659,
  "text" : "@jshy It's been a while since I totally gave into my rage like Niko can. I sorta miss burn all bridges take no survivors anger. #nostalgia",
  "id" : 379829658516086784,
  "in_reply_to_status_id" : 379829002208178177,
  "created_at" : "2013-09-17 04:50:22 +0000",
  "in_reply_to_screen_name" : "jshy",
  "in_reply_to_user_id_str" : "804659",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379828035014238208",
  "geo" : { },
  "id_str" : "379828603602468864",
  "in_reply_to_user_id" : 2185,
  "text" : "Basically boiled down to playing with more toys in the bath, which is totally reasonable. Just excited to have had a successful negotiation.",
  "id" : 379828603602468864,
  "in_reply_to_status_id" : 379828035014238208,
  "created_at" : "2013-09-17 04:46:10 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379828035014238208",
  "text" : "Post-meltdown I asked Niko if he had ideas on how to make bath time more fun \/ less tantrum-y &amp; for the first time he actually did!",
  "id" : 379828035014238208,
  "created_at" : "2013-09-17 04:43:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/3Qchk4ZLON",
      "expanded_url" : "http:\/\/thehundreds.com\/blog\/2013\/09\/09\/at-twitter\/",
      "display_url" : "thehundreds.com\/blog\/2013\/09\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379827151521857536",
  "text" : "RT @isaach: some nice pictures from behind the scenes at Twitter HQ http:\/\/t.co\/3Qchk4ZLON",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/3Qchk4ZLON",
        "expanded_url" : "http:\/\/thehundreds.com\/blog\/2013\/09\/09\/at-twitter\/",
        "display_url" : "thehundreds.com\/blog\/2013\/09\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "379716323288576000",
    "text" : "some nice pictures from behind the scenes at Twitter HQ http:\/\/t.co\/3Qchk4ZLON",
    "id" : 379716323288576000,
    "created_at" : "2013-09-16 21:20:00 +0000",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430605387117494272\/lmplHwca_normal.png",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 379827151521857536,
  "created_at" : "2013-09-17 04:40:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 1, 4 ],
      "id_str" : "15504330",
      "id" : 15504330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379815890646093826",
  "geo" : { },
  "id_str" : "379826696079175680",
  "in_reply_to_user_id" : 15504330,
  "text" : ".@wm The beautiful thing about children is that they can remind us of how we used to be filled with pure rage.",
  "id" : 379826696079175680,
  "in_reply_to_status_id" : 379815890646093826,
  "created_at" : "2013-09-17 04:38:35 +0000",
  "in_reply_to_screen_name" : "wm",
  "in_reply_to_user_id_str" : "15504330",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/X88LvteQHy",
      "expanded_url" : "http:\/\/flic.kr\/p\/fUiKKG",
      "display_url" : "flic.kr\/p\/fUiKKG"
    } ]
  },
  "geo" : { },
  "id_str" : "379812222631178240",
  "text" : "8:36pm Scream into the tub time http:\/\/t.co\/X88LvteQHy",
  "id" : 379812222631178240,
  "created_at" : "2013-09-17 03:41:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Brault",
      "screen_name" : "adambrault",
      "indices" : [ 16, 27 ],
      "id_str" : "1568",
      "id" : 1568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/UXgAnvKxcW",
      "expanded_url" : "https:\/\/speakerdeck.com\/adambrault\/people-first",
      "display_url" : "speakerdeck.com\/adambrault\/peo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379748982454374400",
  "text" : "Amazing talk by @adambrault: \"People First\" https:\/\/t.co\/UXgAnvKxcW",
  "id" : 379748982454374400,
  "created_at" : "2013-09-16 23:29:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Pell",
      "screen_name" : "davepell",
      "indices" : [ 3, 12 ],
      "id_str" : "224",
      "id" : 224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379685986927509504",
  "text" : "RT @davepell: Google acquired Bump. If they incorporate it into Google Glass, I'll be able to share my contact information with a head-butt.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "379685697818750976",
    "text" : "Google acquired Bump. If they incorporate it into Google Glass, I'll be able to share my contact information with a head-butt.",
    "id" : 379685697818750976,
    "created_at" : "2013-09-16 19:18:19 +0000",
    "user" : {
      "name" : "Dave Pell",
      "screen_name" : "davepell",
      "protected" : false,
      "id_str" : "224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458818845373784064\/Ugb_RTHJ_normal.png",
      "id" : 224,
      "verified" : false
    }
  },
  "id" : 379685986927509504,
  "created_at" : "2013-09-16 19:19:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379679160425148416",
  "geo" : { },
  "id_str" : "379679462717005824",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Hopefully something comes of it. Sorry to hear this is happening\u2026 such a cruel thing to do.",
  "id" : 379679462717005824,
  "in_reply_to_status_id" : 379679160425148416,
  "created_at" : "2013-09-16 18:53:32 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/EjrSecz2MP",
      "expanded_url" : "https:\/\/support.twitter.com\/forms\/abusiveuser",
      "display_url" : "support.twitter.com\/forms\/abusiveu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "379677485446615040",
  "geo" : { },
  "id_str" : "379678971001991168",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Definitely report the abuse. https:\/\/t.co\/EjrSecz2MP",
  "id" : 379678971001991168,
  "in_reply_to_status_id" : 379677485446615040,
  "created_at" : "2013-09-16 18:51:35 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 3, 14 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/EH00c284Ts",
      "expanded_url" : "http:\/\/www.theguardian.com\/culture\/2013\/sep\/13\/russell-brand-gq-awards-hugo-boss",
      "display_url" : "theguardian.com\/culture\/2013\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379646940805214208",
  "text" : "RT @waxpancake: This Russell Brand essay is the best. http:\/\/t.co\/EH00c284Ts The crazy thing is that he speaks exactly like this.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/EH00c284Ts",
        "expanded_url" : "http:\/\/www.theguardian.com\/culture\/2013\/sep\/13\/russell-brand-gq-awards-hugo-boss",
        "display_url" : "theguardian.com\/culture\/2013\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "379434199226130432",
    "text" : "This Russell Brand essay is the best. http:\/\/t.co\/EH00c284Ts The crazy thing is that he speaks exactly like this.",
    "id" : 379434199226130432,
    "created_at" : "2013-09-16 02:38:57 +0000",
    "user" : {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "protected" : false,
      "id_str" : "13461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416642320574844928\/Gz7V2B6r_normal.jpeg",
      "id" : 13461,
      "verified" : false
    }
  },
  "id" : 379646940805214208,
  "created_at" : "2013-09-16 16:44:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379475350826135552",
  "geo" : { },
  "id_str" : "379477596020305921",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Ha. That's when my import script broke. Don't worry, my high output has remained high! Just need to backfill...",
  "id" : 379477596020305921,
  "in_reply_to_status_id" : 379475350826135552,
  "created_at" : "2013-09-16 05:31:23 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Rheingold",
      "screen_name" : "tedr",
      "indices" : [ 0, 5 ],
      "id_str" : "997",
      "id" : 997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379475402978115584",
  "geo" : { },
  "id_str" : "379477318751629312",
  "in_reply_to_user_id" : 997,
  "text" : "@tedr My first reply also provided a good example. :) Bug filed.",
  "id" : 379477318751629312,
  "in_reply_to_status_id" : 379475402978115584,
  "created_at" : "2013-09-16 05:30:17 +0000",
  "in_reply_to_screen_name" : "tedr",
  "in_reply_to_user_id_str" : "997",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Rheingold",
      "screen_name" : "tedr",
      "indices" : [ 0, 5 ],
      "id_str" : "997",
      "id" : 997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379470359637917697",
  "geo" : { },
  "id_str" : "379473241137356800",
  "in_reply_to_user_id" : 997,
  "text" : "@tedr Send me a screenshot? I can file a bug.",
  "id" : 379473241137356800,
  "in_reply_to_status_id" : 379470359637917697,
  "created_at" : "2013-09-16 05:14:05 +0000",
  "in_reply_to_screen_name" : "tedr",
  "in_reply_to_user_id_str" : "997",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/ddcYDnBpGN",
      "expanded_url" : "http:\/\/busterbenson.com",
      "display_url" : "busterbenson.com"
    }, {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/ANI9MlzCc5",
      "expanded_url" : "http:\/\/flic.kr\/p\/fTdG3A",
      "display_url" : "flic.kr\/p\/fTdG3A"
    } ]
  },
  "geo" : { },
  "id_str" : "379469747089575936",
  "text" : "8:36pm Just messing around with http:\/\/t.co\/ddcYDnBpGN. Added embedded tweets. http:\/\/t.co\/ANI9MlzCc5",
  "id" : 379469747089575936,
  "created_at" : "2013-09-16 05:00:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379336368557531136",
  "geo" : { },
  "id_str" : "379370154171187200",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Love it! Keep collecting evidence for my side! :)",
  "id" : 379370154171187200,
  "in_reply_to_status_id" : 379336368557531136,
  "created_at" : "2013-09-15 22:24:27 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379100962985480194",
  "geo" : { },
  "id_str" : "379109774257684480",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Before or after you sip it?",
  "id" : 379109774257684480,
  "in_reply_to_status_id" : 379100962985480194,
  "created_at" : "2013-09-15 05:09:48 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/ykHmRnI9hh",
      "expanded_url" : "http:\/\/flic.kr\/p\/fRYScu",
      "display_url" : "flic.kr\/p\/fRYScu"
    } ]
  },
  "geo" : { },
  "id_str" : "379091435091681280",
  "text" : "8:36pm Playing Wild Thing http:\/\/t.co\/ykHmRnI9hh",
  "id" : 379091435091681280,
  "created_at" : "2013-09-15 03:56:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Fox",
      "screen_name" : "heychrisfox",
      "indices" : [ 0, 12 ],
      "id_str" : "9354282",
      "id" : 9354282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379001189456547840",
  "geo" : { },
  "id_str" : "379001489093447680",
  "in_reply_to_user_id" : 9354282,
  "text" : "@heychrisfox It's been stable... people seem to be okay with the idea.",
  "id" : 379001489093447680,
  "in_reply_to_status_id" : 379001189456547840,
  "created_at" : "2013-09-14 21:59:31 +0000",
  "in_reply_to_screen_name" : "heychrisfox",
  "in_reply_to_user_id_str" : "9354282",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Norbert Mocsnik",
      "screen_name" : "norbert_m",
      "indices" : [ 0, 10 ],
      "id_str" : "5759322",
      "id" : 5759322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378975534010859520",
  "geo" : { },
  "id_str" : "378985556597673984",
  "in_reply_to_user_id" : 5759322,
  "text" : "@norbert_m Not really. This is my one project that grows despite tremendous neglect.",
  "id" : 378985556597673984,
  "in_reply_to_status_id" : 378975534010859520,
  "created_at" : "2013-09-14 20:56:12 +0000",
  "in_reply_to_screen_name" : "norbert_m",
  "in_reply_to_user_id_str" : "5759322",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cool",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/qjUH5AFHun",
      "expanded_url" : "http:\/\/750words.com",
      "display_url" : "750words.com"
    } ]
  },
  "geo" : { },
  "id_str" : "378971332228022272",
  "text" : "I just did \"select count(*) from people;\" on http:\/\/t.co\/qjUH5AFHun and got: 191531! That's sort of crazy for a fun side project. #cool",
  "id" : 378971332228022272,
  "created_at" : "2013-09-14 19:59:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 11, 19 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 46, 53 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "indices" : [ 79, 82 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/gPiCUUTAGR",
      "expanded_url" : "http:\/\/techcrunch.com\/2013\/09\/14\/twitter-co-founder-evan-williams-lays-out-his-vision-for-medium\/",
      "display_url" : "techcrunch.com\/2013\/09\/14\/twi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "378902372656762880",
  "geo" : { },
  "id_str" : "378909760692563968",
  "in_reply_to_user_id" : 795649,
  "text" : "Me too. RT @rsarver: I'm excited to see where @Medium goes \"Twitter Co-Founder @Ev Lays Out Plan For Future Of Media\" http:\/\/t.co\/gPiCUUTAGR",
  "id" : 378909760692563968,
  "in_reply_to_status_id" : 378902372656762880,
  "created_at" : "2013-09-14 15:55:01 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 36, 46 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 74, 83 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 88, 93 ],
      "id_str" : "541",
      "id" : 541
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lildude",
      "indices" : [ 7, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/6ZgNUQfTO2",
      "expanded_url" : "http:\/\/flic.kr\/p\/fQDBjb",
      "display_url" : "flic.kr\/p\/fQDBjb"
    } ]
  },
  "geo" : { },
  "id_str" : "378728203785093120",
  "text" : "8:36pm #lildude and Niko sitting on @kellianne post delicious dinner with @spangley and @lane http:\/\/t.co\/6ZgNUQfTO2",
  "id" : 378728203785093120,
  "created_at" : "2013-09-14 03:53:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 16, 25 ],
      "id_str" : "2391",
      "id" : 2391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/OpuFqq55Gn",
      "expanded_url" : "http:\/\/www.abookapart.com\/products\/just-enough-research",
      "display_url" : "abookapart.com\/products\/just-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378577727961321472",
  "text" : "Excited to read @mulegirl's new book, \"Just Enough Research\". Currently loaded on my Kindle for the BART ride home: http:\/\/t.co\/OpuFqq55Gn",
  "id" : 378577727961321472,
  "created_at" : "2013-09-13 17:55:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378561052373307394",
  "text" : "Nothing like a nice quiet breakfast to start the day.",
  "id" : 378561052373307394,
  "created_at" : "2013-09-13 16:49:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/K3XIYGHsFG",
      "expanded_url" : "http:\/\/instagram.com\/p\/eMVHjRo0Ef\/",
      "display_url" : "instagram.com\/p\/eMVHjRo0Ef\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.783283028, -122.407135947 ]
  },
  "id_str" : "378424232184922112",
  "text" : "8:36pm Late:36 because we had a fun dinner with Cameron and Amanda but forgot to take a picture then\u2026 http:\/\/t.co\/K3XIYGHsFG",
  "id" : 378424232184922112,
  "created_at" : "2013-09-13 07:45:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 0, 6 ],
      "id_str" : "15310552",
      "id" : 15310552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378387651780300800",
  "geo" : { },
  "id_str" : "378409264521289728",
  "in_reply_to_user_id" : 15310552,
  "text" : "@singy Condolences to you and your family. Sad times.",
  "id" : 378409264521289728,
  "in_reply_to_status_id" : 378387651780300800,
  "created_at" : "2013-09-13 06:46:13 +0000",
  "in_reply_to_screen_name" : "singy",
  "in_reply_to_user_id_str" : "15310552",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reeve S. Thompson ",
      "screen_name" : "Reeve",
      "indices" : [ 0, 6 ],
      "id_str" : "9317922",
      "id" : 9317922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pumpkineater",
      "indices" : [ 7, 20 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378405603376246784",
  "geo" : { },
  "id_str" : "378407011899015169",
  "in_reply_to_user_id" : 9317922,
  "text" : "@Reeve #pumpkineater",
  "id" : 378407011899015169,
  "in_reply_to_status_id" : 378405603376246784,
  "created_at" : "2013-09-13 06:37:16 +0000",
  "in_reply_to_screen_name" : "Reeve",
  "in_reply_to_user_id_str" : "9317922",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "soccerpachinko",
      "indices" : [ 13, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/4mmpYq0OIR",
      "expanded_url" : "https:\/\/vine.co\/v\/hnav61KiHYe",
      "display_url" : "vine.co\/v\/hnav61KiHYe"
    } ]
  },
  "geo" : { },
  "id_str" : "378405364775256064",
  "text" : "8 at a time! #soccerpachinko https:\/\/t.co\/4mmpYq0OIR",
  "id" : 378405364775256064,
  "created_at" : "2013-09-13 06:30:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/FviVo8CRyj",
      "expanded_url" : "https:\/\/vine.co\/v\/hnaeOlXQq1a",
      "display_url" : "vine.co\/v\/hnaeOlXQq1a"
    } ]
  },
  "geo" : { },
  "id_str" : "378401178784370688",
  "text" : "Soccer pachinko https:\/\/t.co\/FviVo8CRyj",
  "id" : 378401178784370688,
  "created_at" : "2013-09-13 06:14:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378326391072104448",
  "text" : "Mmmmm cashews.",
  "id" : 378326391072104448,
  "created_at" : "2013-09-13 01:16:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378292242479194112",
  "geo" : { },
  "id_str" : "378293276366761985",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april I &lt;3 apples!",
  "id" : 378293276366761985,
  "in_reply_to_status_id" : 378292242479194112,
  "created_at" : "2013-09-12 23:05:20 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378286324374962176",
  "geo" : { },
  "id_str" : "378287067010043905",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker Wouldn't the slippery slope argument imply that if I skip lunch then I might start skipping all meals? Sounds dangerous.",
  "id" : 378287067010043905,
  "in_reply_to_status_id" : 378286324374962176,
  "created_at" : "2013-09-12 22:40:39 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378279763854376961",
  "text" : "I'm hungry. Should I have a late lunch or wait for dinner?",
  "id" : 378279763854376961,
  "created_at" : "2013-09-12 22:11:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378262680101875712",
  "text" : "RT @twitter: We\u2019ve confidentially submitted an S-1 to the SEC for a planned IPO. This Tweet does not constitute an offer of any securities \u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378261932148416512",
    "text" : "We\u2019ve confidentially submitted an S-1 to the SEC for a planned IPO. This Tweet does not constitute an offer of any securities for sale.",
    "id" : 378261932148416512,
    "created_at" : "2013-09-12 21:00:47 +0000",
    "user" : {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "protected" : false,
      "id_str" : "783214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2284174758\/v65oai7fxn47qv9nectx_normal.png",
      "id" : 783214,
      "verified" : true
    }
  },
  "id" : 378262680101875712,
  "created_at" : "2013-09-12 21:03:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Babauta",
      "screen_name" : "zen_habits",
      "indices" : [ 19, 30 ],
      "id_str" : "15859268",
      "id" : 15859268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378242771951161344",
  "text" : "Finally met Leo of @zen_habits. A++ Would meet again!",
  "id" : 378242771951161344,
  "created_at" : "2013-09-12 19:44:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nassim N. Taleb",
      "screen_name" : "nntaleb",
      "indices" : [ 55, 63 ],
      "id_str" : "381289719",
      "id" : 381289719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378200166312189952",
  "geo" : { },
  "id_str" : "378200909613772800",
  "in_reply_to_user_id" : 381289719,
  "text" : "Trying to reduce variability often multiplies risk. RT @nntaleb: Our central problem is the unshakable conflation of variability and risk.",
  "id" : 378200909613772800,
  "in_reply_to_status_id" : 378200166312189952,
  "created_at" : "2013-09-12 16:58:18 +0000",
  "in_reply_to_screen_name" : "nntaleb",
  "in_reply_to_user_id_str" : "381289719",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378195145478262785",
  "text" : "My new doctor wears a bow tie. His advice is therefore 50% more authoritative.",
  "id" : 378195145478262785,
  "created_at" : "2013-09-12 16:35:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandy Brown",
      "screen_name" : "aworkinglibrary",
      "indices" : [ 3, 19 ],
      "id_str" : "11133442",
      "id" : 11133442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/Btv4SNQ9aC",
      "expanded_url" : "http:\/\/www.garann.com\/dev\/2013\/how-to-blog-about-code-and-give-zero-fucks\/",
      "display_url" : "garann.com\/dev\/2013\/how-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378158418227253249",
  "text" : "RT @aworkinglibrary: How to blog about code and give zero fucks: http:\/\/t.co\/Btv4SNQ9aC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/Btv4SNQ9aC",
        "expanded_url" : "http:\/\/www.garann.com\/dev\/2013\/how-to-blog-about-code-and-give-zero-fucks\/",
        "display_url" : "garann.com\/dev\/2013\/how-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "378151108671438848",
    "text" : "How to blog about code and give zero fucks: http:\/\/t.co\/Btv4SNQ9aC",
    "id" : 378151108671438848,
    "created_at" : "2013-09-12 13:40:24 +0000",
    "user" : {
      "name" : "Mandy Brown",
      "screen_name" : "aworkinglibrary",
      "protected" : false,
      "id_str" : "11133442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2919538988\/9aeb1ced2ce1134c5eb38038b4c38f3a_normal.jpeg",
      "id" : 11133442,
      "verified" : false
    }
  },
  "id" : 378158418227253249,
  "created_at" : "2013-09-12 14:09:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wifeymaterial",
      "indices" : [ 74, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378103895639093248",
  "text" : "Kellianne just chased some raccoons out of our house at 3 in the morning. #wifeymaterial",
  "id" : 378103895639093248,
  "created_at" : "2013-09-12 10:32:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 35, 42 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 47, 51 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Tlan00OLRd",
      "expanded_url" : "http:\/\/flic.kr\/p\/fPNvUL",
      "display_url" : "flic.kr\/p\/fPNvUL"
    } ]
  },
  "geo" : { },
  "id_str" : "378010864911011840",
  "text" : "8:36pm Dinner at Lanesplitter with @sharon and @ian http:\/\/t.co\/Tlan00OLRd",
  "id" : 378010864911011840,
  "created_at" : "2013-09-12 04:23:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A. Smith",
      "screen_name" : "michaelasmith",
      "indices" : [ 0, 14 ],
      "id_str" : "16609638",
      "id" : 16609638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377970306247192576",
  "geo" : { },
  "id_str" : "377973900224626689",
  "in_reply_to_user_id" : 16609638,
  "text" : "@michaelasmith Oh yeah that too!",
  "id" : 377973900224626689,
  "in_reply_to_status_id" : 377970306247192576,
  "created_at" : "2013-09-12 01:56:14 +0000",
  "in_reply_to_screen_name" : "michaelasmith",
  "in_reply_to_user_id_str" : "16609638",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A. Smith",
      "screen_name" : "michaelasmith",
      "indices" : [ 0, 14 ],
      "id_str" : "16609638",
      "id" : 16609638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377969595887259650",
  "geo" : { },
  "id_str" : "377969921600143361",
  "in_reply_to_user_id" : 16609638,
  "text" : "@michaelasmith What makes you think so?",
  "id" : 377969921600143361,
  "in_reply_to_status_id" : 377969595887259650,
  "created_at" : "2013-09-12 01:40:26 +0000",
  "in_reply_to_screen_name" : "michaelasmith",
  "in_reply_to_user_id_str" : "16609638",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377969740783702016",
  "text" : "I wonder what the oldest still active string of DNA, oldest still in print sentence, and oldest still running line of code are.",
  "id" : 377969740783702016,
  "created_at" : "2013-09-12 01:39:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tothedeath",
      "indices" : [ 74, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377969003244695552",
  "text" : "DNA vs books vs software in the battle for ultimate information survival. #tothedeath",
  "id" : 377969003244695552,
  "created_at" : "2013-09-12 01:36:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 3, 17 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/oPp0pnTp5N",
      "expanded_url" : "http:\/\/www.humansofnewyork.com\/post\/60942607020",
      "display_url" : "humansofnewyork.com\/post\/609426070\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377896573377585152",
  "text" : "RT @marcprecipice: \"If you had spent more time with your family, do you think you\u2019d regret not having progressed as far...?\" http:\/\/t.co\/oP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/newsblur\/id463981119?mt=8&uo=4\" rel=\"nofollow\"\u003ENewsBlur on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/oPp0pnTp5N",
        "expanded_url" : "http:\/\/www.humansofnewyork.com\/post\/60942607020",
        "display_url" : "humansofnewyork.com\/post\/609426070\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377846429618016256",
    "text" : "\"If you had spent more time with your family, do you think you\u2019d regret not having progressed as far...?\" http:\/\/t.co\/oPp0pnTp5N",
    "id" : 377846429618016256,
    "created_at" : "2013-09-11 17:29:43 +0000",
    "user" : {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "protected" : false,
      "id_str" : "226976689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2321403275\/b546axjksj5f7z194wjm_normal.jpeg",
      "id" : 226976689,
      "verified" : false
    }
  },
  "id" : 377896573377585152,
  "created_at" : "2013-09-11 20:48:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 3, 9 ],
      "id_str" : "8285392",
      "id" : 8285392
    }, {
      "name" : "Lady Gaga",
      "screen_name" : "ladygaga",
      "indices" : [ 23, 32 ],
      "id_str" : "14230524",
      "id" : 14230524
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/raffi\/status\/377481543108665344\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/PFlcLYhS4X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT0VdqaCIAA1SNs.jpg",
      "id_str" : "377481543112859648",
      "id" : 377481543112859648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT0VdqaCIAA1SNs.jpg",
      "sizes" : [ {
        "h" : 553,
        "resize" : "fit",
        "w" : 553
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 553
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 553
      } ],
      "display_url" : "pic.twitter.com\/PFlcLYhS4X"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377885450746486784",
  "text" : "RT @raffi: ask \"what's @ladygaga saying?\", and siri pulls up her most recent tweets in iOS 7 http:\/\/t.co\/PFlcLYhS4X",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lady Gaga",
        "screen_name" : "ladygaga",
        "indices" : [ 12, 21 ],
        "id_str" : "14230524",
        "id" : 14230524
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/raffi\/status\/377481543108665344\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/PFlcLYhS4X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BT0VdqaCIAA1SNs.jpg",
        "id_str" : "377481543112859648",
        "id" : 377481543112859648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT0VdqaCIAA1SNs.jpg",
        "sizes" : [ {
          "h" : 553,
          "resize" : "fit",
          "w" : 553
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 553,
          "resize" : "fit",
          "w" : 553
        }, {
          "h" : 553,
          "resize" : "fit",
          "w" : 553
        } ],
        "display_url" : "pic.twitter.com\/PFlcLYhS4X"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377481543108665344",
    "text" : "ask \"what's @ladygaga saying?\", and siri pulls up her most recent tweets in iOS 7 http:\/\/t.co\/PFlcLYhS4X",
    "id" : 377481543108665344,
    "created_at" : "2013-09-10 17:19:47 +0000",
    "user" : {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "protected" : false,
      "id_str" : "8285392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1270234259\/raffi-headshot-casual_normal.png",
      "id" : 8285392,
      "verified" : false
    }
  },
  "id" : 377885450746486784,
  "created_at" : "2013-09-11 20:04:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377844525445566464",
  "geo" : { },
  "id_str" : "377848520943751168",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine Don't let them push you around. You're the boss.",
  "id" : 377848520943751168,
  "in_reply_to_status_id" : 377844525445566464,
  "created_at" : "2013-09-11 17:38:02 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Mod",
      "screen_name" : "craigmod",
      "indices" : [ 53, 62 ],
      "id_str" : "1835951",
      "id" : 1835951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377550926866706432",
  "text" : "Gadgets should focus on non-accelerometer sensors RT @craigmod: As expected, iPhone becoming the fitbit\/Nike+\/jawbone Up replacement device.",
  "id" : 377550926866706432,
  "created_at" : "2013-09-10 21:55:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377471854585192448",
  "geo" : { },
  "id_str" : "377472134009737217",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler There should be! Looks like something went wrong on this tweet though... it's not loading the image for me.",
  "id" : 377472134009737217,
  "in_reply_to_status_id" : 377471854585192448,
  "created_at" : "2013-09-10 16:42:24 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "indices" : [ 3, 9 ],
      "id_str" : "8708232",
      "id" : 8708232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/fhyVXLWJh1",
      "expanded_url" : "http:\/\/blog.kissmetrics.com\/single-startup-metric\/",
      "display_url" : "blog.kissmetrics.com\/single-startup\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377471821202726912",
  "text" : "RT @brynn: How to use a single metric to run your startup. What would you choose? http:\/\/t.co\/fhyVXLWJh1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/fhyVXLWJh1",
        "expanded_url" : "http:\/\/blog.kissmetrics.com\/single-startup-metric\/",
        "display_url" : "blog.kissmetrics.com\/single-startup\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377464482693255168",
    "text" : "How to use a single metric to run your startup. What would you choose? http:\/\/t.co\/fhyVXLWJh1",
    "id" : 377464482693255168,
    "created_at" : "2013-09-10 16:12:00 +0000",
    "user" : {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "protected" : false,
      "id_str" : "8708232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451517791091167232\/ycYsDdzq_normal.jpeg",
      "id" : 8708232,
      "verified" : false
    }
  },
  "id" : 377471821202726912,
  "created_at" : "2013-09-10 16:41:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/cCf6x4LYel",
      "expanded_url" : "http:\/\/flic.kr\/p\/fNzPPp",
      "display_url" : "flic.kr\/p\/fNzPPp"
    } ]
  },
  "geo" : { },
  "id_str" : "377469054338215936",
  "text" : "New Twitter sign looking good http:\/\/t.co\/cCf6x4LYel",
  "id" : 377469054338215936,
  "created_at" : "2013-09-10 16:30:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Pullara",
      "screen_name" : "sampullara",
      "indices" : [ 3, 14 ],
      "id_str" : "668473",
      "id" : 668473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/J586EvZy7n",
      "expanded_url" : "https:\/\/www.usenix.org\/blog\/my-daughters-high-school-programming-teacher",
      "display_url" : "usenix.org\/blog\/my-daught\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377310819349831680",
  "text" : "RT @sampullara: A hard to read account of a young girl ready to learn to program only to be harassed https:\/\/t.co\/J586EvZy7n",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/J586EvZy7n",
        "expanded_url" : "https:\/\/www.usenix.org\/blog\/my-daughters-high-school-programming-teacher",
        "display_url" : "usenix.org\/blog\/my-daught\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377309303553552384",
    "text" : "A hard to read account of a young girl ready to learn to program only to be harassed https:\/\/t.co\/J586EvZy7n",
    "id" : 377309303553552384,
    "created_at" : "2013-09-10 05:55:22 +0000",
    "user" : {
      "name" : "Sam Pullara",
      "screen_name" : "sampullara",
      "protected" : false,
      "id_str" : "668473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/426260830733094912\/7EbEfiaQ_normal.jpeg",
      "id" : 668473,
      "verified" : false
    }
  },
  "id" : 377310819349831680,
  "created_at" : "2013-09-10 06:01:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kris",
      "screen_name" : "kris",
      "indices" : [ 0, 5 ],
      "id_str" : "115734106",
      "id" : 115734106
    }, {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "indices" : [ 6, 11 ],
      "id_str" : "949521",
      "id" : 949521
    }, {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 12, 23 ],
      "id_str" : "26123649",
      "id" : 26123649
    }, {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 24, 31 ],
      "id_str" : "1530531",
      "id" : 1530531
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 32, 39 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377305694891806720",
  "geo" : { },
  "id_str" : "377307377696927744",
  "in_reply_to_user_id" : 115734106,
  "text" : "@kris @stop @brianellin @miradu @sippey Replace \"reply\" with \"mutter\" when appropriate. And long tap for \"scream into pillow\".",
  "id" : 377307377696927744,
  "in_reply_to_status_id" : 377305694891806720,
  "created_at" : "2013-09-10 05:47:43 +0000",
  "in_reply_to_screen_name" : "kris",
  "in_reply_to_user_id_str" : "115734106",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/qLJWXXelIT",
      "expanded_url" : "http:\/\/flic.kr\/p\/fNfk12",
      "display_url" : "flic.kr\/p\/fNfk12"
    } ]
  },
  "geo" : { },
  "id_str" : "377275340655050752",
  "text" : "8:36pm Playing Chutes and Ladders, anarchy edition http:\/\/t.co\/qLJWXXelIT",
  "id" : 377275340655050752,
  "created_at" : "2013-09-10 03:40:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Kathleen Peck",
      "screen_name" : "sarahkpeck",
      "indices" : [ 0, 11 ],
      "id_str" : "196745496",
      "id" : 196745496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377257115309445120",
  "geo" : { },
  "id_str" : "377257941683814402",
  "in_reply_to_user_id" : 196745496,
  "text" : "@sarahkpeck Like who?? I'd love to follow...",
  "id" : 377257941683814402,
  "in_reply_to_status_id" : 377257115309445120,
  "created_at" : "2013-09-10 02:31:17 +0000",
  "in_reply_to_screen_name" : "sarahkpeck",
  "in_reply_to_user_id_str" : "196745496",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Josuweit",
      "screen_name" : "josablack",
      "indices" : [ 0, 10 ],
      "id_str" : "26769877",
      "id" : 26769877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377182292994572288",
  "geo" : { },
  "id_str" : "377182425517809664",
  "in_reply_to_user_id" : 26769877,
  "text" : "@josablack Go for it!",
  "id" : 377182425517809664,
  "in_reply_to_status_id" : 377182292994572288,
  "created_at" : "2013-09-09 21:31:12 +0000",
  "in_reply_to_screen_name" : "josablack",
  "in_reply_to_user_id_str" : "26769877",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Josuweit",
      "screen_name" : "josablack",
      "indices" : [ 0, 10 ],
      "id_str" : "26769877",
      "id" : 26769877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377157392003108866",
  "geo" : { },
  "id_str" : "377181858171088896",
  "in_reply_to_user_id" : 26769877,
  "text" : "@josablack I wrote my own parser for that stuff. Keep meaning to find time to open it up, but haven't yet.",
  "id" : 377181858171088896,
  "in_reply_to_status_id" : 377157392003108866,
  "created_at" : "2013-09-09 21:28:57 +0000",
  "in_reply_to_screen_name" : "josablack",
  "in_reply_to_user_id_str" : "26769877",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377125514932011008",
  "geo" : { },
  "id_str" : "377146188778065921",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler Most reports I heard when I asked around for similar reasons is that AT&amp;T is probably best for Seattle.",
  "id" : 377146188778065921,
  "in_reply_to_status_id" : 377125514932011008,
  "created_at" : "2013-09-09 19:07:13 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 0, 14 ],
      "id_str" : "18749271",
      "id" : 18749271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377075327899824128",
  "geo" : { },
  "id_str" : "377085617470861312",
  "in_reply_to_user_id" : 18749271,
  "text" : "@libbybrittain Have you created an ads account already? What kind of analytics do you want? I can help: buster@twitter.com",
  "id" : 377085617470861312,
  "in_reply_to_status_id" : 377075327899824128,
  "created_at" : "2013-09-09 15:06:31 +0000",
  "in_reply_to_screen_name" : "libbybrittain",
  "in_reply_to_user_id_str" : "18749271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/HXW2dNdfpB",
      "expanded_url" : "http:\/\/bit.ly\/17OSDvm",
      "display_url" : "bit.ly\/17OSDvm"
    } ]
  },
  "geo" : { },
  "id_str" : "376963783584784384",
  "text" : "I updated my guide to being enraged on the internet with a 3rd option due to recent events on the internet: http:\/\/t.co\/HXW2dNdfpB",
  "id" : 376963783584784384,
  "created_at" : "2013-09-09 07:02:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "megan quinn",
      "screen_name" : "msquinn",
      "indices" : [ 0, 8 ],
      "id_str" : "15293504",
      "id" : 15293504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376943942840758273",
  "geo" : { },
  "id_str" : "376959728187740161",
  "in_reply_to_user_id" : 15293504,
  "text" : "@msquinn Or have 3yo boys. I'm totally showing this to Niko first thing tomorrow morning!",
  "id" : 376959728187740161,
  "in_reply_to_status_id" : 376943942840758273,
  "created_at" : "2013-09-09 06:46:17 +0000",
  "in_reply_to_screen_name" : "msquinn",
  "in_reply_to_user_id_str" : "15293504",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/Vy7sdqS0GO",
      "expanded_url" : "http:\/\/flic.kr\/p\/fMyL6X",
      "display_url" : "flic.kr\/p\/fMyL6X"
    } ]
  },
  "geo" : { },
  "id_str" : "376917830559490048",
  "text" : "8:36pm Teaching Niko about selfies http:\/\/t.co\/Vy7sdqS0GO",
  "id" : 376917830559490048,
  "created_at" : "2013-09-09 03:59:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376837653963890688",
  "text" : "\"Perhaps there is a realm of wisdom from which the logician is exiled.\" - Nietzsche via Antifragile",
  "id" : 376837653963890688,
  "created_at" : "2013-09-08 22:41:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 31, 42 ],
      "id_str" : "26123649",
      "id" : 26123649
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 44, 51 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/YO2dahbCJZ",
      "expanded_url" : "https:\/\/twitter.com\/search?q=mt%20diablo%20fire",
      "display_url" : "twitter.com\/search?q=mt%20\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "376833532477206529",
  "geo" : { },
  "id_str" : "376835388607696896",
  "in_reply_to_user_id" : 26123649,
  "text" : "I swear we didn't start it. RT @brianellin: @buster https:\/\/t.co\/YO2dahbCJZ looks to be just getting started.  glad you made it down!",
  "id" : 376835388607696896,
  "in_reply_to_status_id" : 376833532477206529,
  "created_at" : "2013-09-08 22:32:12 +0000",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 0, 11 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376830950555938816",
  "geo" : { },
  "id_str" : "376831229531652096",
  "in_reply_to_user_id" : 26123649,
  "text" : "@brianellin Woah! Back down now... it was pretty dry up there...",
  "id" : 376831229531652096,
  "in_reply_to_status_id" : 376830950555938816,
  "created_at" : "2013-09-08 22:15:40 +0000",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.mapmyride.com\" rel=\"nofollow\"\u003EMapMyRide Mobile\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/9oirejcAwm",
      "expanded_url" : "http:\/\/mmf.cc\/17JF0l7",
      "display_url" : "mmf.cc\/17JF0l7"
    } ]
  },
  "geo" : { },
  "id_str" : "376825301340131329",
  "text" : "The route we took yesterday up to Mt Diablo Live Oak campgrounds. Niko's first biking camping trip, of many we hope. http:\/\/t.co\/9oirejcAwm",
  "id" : 376825301340131329,
  "created_at" : "2013-09-08 21:52:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/376817039286861825\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xJSB77CnfR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTq5Gb0CMAAXrzi.jpg",
      "id_str" : "376817039035215872",
      "id" : 376817039035215872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTq5Gb0CMAAXrzi.jpg",
      "sizes" : [ {
        "h" : 232,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 77,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 136,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xJSB77CnfR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376817039286861825",
  "text" : "http:\/\/t.co\/xJSB77CnfR",
  "id" : 376817039286861825,
  "created_at" : "2013-09-08 21:19:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/GN3xmBLGlE",
      "expanded_url" : "http:\/\/flic.kr\/p\/fMm7cT",
      "display_url" : "flic.kr\/p\/fMm7cT"
    } ]
  },
  "geo" : { },
  "id_str" : "376815044157132803",
  "text" : "Tucked in one of the smaller Mt Diablo wind caves http:\/\/t.co\/GN3xmBLGlE",
  "id" : 376815044157132803,
  "created_at" : "2013-09-08 21:11:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/4VLxOLxEav",
      "expanded_url" : "http:\/\/flic.kr\/p\/fM3Srw",
      "display_url" : "flic.kr\/p\/fM3Srw"
    } ]
  },
  "geo" : { },
  "id_str" : "376550409277415425",
  "text" : "8:36pm Claiming our camp at Live Oak http:\/\/t.co\/4VLxOLxEav",
  "id" : 376550409277415425,
  "created_at" : "2013-09-08 03:39:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ciNxnFPNyT",
      "expanded_url" : "https:\/\/vine.co\/v\/hJVm2pbaV6X",
      "display_url" : "vine.co\/v\/hJVm2pbaV6X"
    } ]
  },
  "geo" : { },
  "id_str" : "376501830924369920",
  "text" : "Protip: don't carry a kid trailer up to Mt Diablo if you're a biking newbie https:\/\/t.co\/ciNxnFPNyT",
  "id" : 376501830924369920,
  "created_at" : "2013-09-08 00:26:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Molina",
      "screen_name" : "noradio",
      "indices" : [ 0, 8 ],
      "id_str" : "3191321",
      "id" : 3191321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376382668289478656",
  "geo" : { },
  "id_str" : "376383566264811520",
  "in_reply_to_user_id" : 3191321,
  "text" : "@noradio I've already forgotten what we were talking about.",
  "id" : 376383566264811520,
  "in_reply_to_status_id" : 376382668289478656,
  "created_at" : "2013-09-07 16:36:49 +0000",
  "in_reply_to_screen_name" : "noradio",
  "in_reply_to_user_id_str" : "3191321",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376224481133334528",
  "geo" : { },
  "id_str" : "376227734592032768",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach On your phone too?",
  "id" : 376227734592032768,
  "in_reply_to_status_id" : 376224481133334528,
  "created_at" : "2013-09-07 06:17:36 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Porad",
      "screen_name" : "scottporad",
      "indices" : [ 3, 14 ],
      "id_str" : "15876737",
      "id" : 15876737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/W7rMBRpDLP",
      "expanded_url" : "http:\/\/bit.ly\/15FyWMP",
      "display_url" : "bit.ly\/15FyWMP"
    } ]
  },
  "geo" : { },
  "id_str" : "376227588630249472",
  "text" : "RT @scottporad: My 11-year old son just shipped his first iOS app called Kinoki!!  Check it out: http:\/\/t.co\/W7rMBRpDLP",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/W7rMBRpDLP",
        "expanded_url" : "http:\/\/bit.ly\/15FyWMP",
        "display_url" : "bit.ly\/15FyWMP"
      } ]
    },
    "geo" : { },
    "id_str" : "376121591043600384",
    "text" : "My 11-year old son just shipped his first iOS app called Kinoki!!  Check it out: http:\/\/t.co\/W7rMBRpDLP",
    "id" : 376121591043600384,
    "created_at" : "2013-09-06 23:15:49 +0000",
    "user" : {
      "name" : "Scott Porad",
      "screen_name" : "scottporad",
      "protected" : false,
      "id_str" : "15876737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/58474218\/a545469291_443918_4159_normal.jpg",
      "id" : 15876737,
      "verified" : false
    }
  },
  "id" : 376227588630249472,
  "created_at" : "2013-09-07 06:17:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/A7yW6PssXF",
      "expanded_url" : "http:\/\/instagram.com\/p\/d8cKo4o0Jg\/",
      "display_url" : "instagram.com\/p\/d8cKo4o0Jg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "376188829851721728",
  "text" : "8:36pm Thomas Percy Papa Amelia Adam wasn't in there. Have a nice day!!! (Post by Niko) http:\/\/t.co\/A7yW6PssXF",
  "id" : 376188829851721728,
  "created_at" : "2013-09-07 03:43:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "indices" : [ 3, 14 ],
      "id_str" : "809641",
      "id" : 809641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/6JTwRCw4bp",
      "expanded_url" : "http:\/\/tinyletter.com\/ben\/letters",
      "display_url" : "tinyletter.com\/ben\/letters"
    } ]
  },
  "geo" : { },
  "id_str" : "376144138955001857",
  "text" : "RT @adamloving: Our ads \"defy logic because they're for our existing customers. We're not going for new leads\" http:\/\/t.co\/6JTwRCw4bp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/6JTwRCw4bp",
        "expanded_url" : "http:\/\/tinyletter.com\/ben\/letters",
        "display_url" : "tinyletter.com\/ben\/letters"
      } ]
    },
    "geo" : { },
    "id_str" : "376142139857444865",
    "text" : "Our ads \"defy logic because they're for our existing customers. We're not going for new leads\" http:\/\/t.co\/6JTwRCw4bp",
    "id" : 376142139857444865,
    "created_at" : "2013-09-07 00:37:29 +0000",
    "user" : {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "protected" : false,
      "id_str" : "809641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3596120795\/6bc52037ad90fa33da999b74316df179_normal.jpeg",
      "id" : 809641,
      "verified" : false
    }
  },
  "id" : 376144138955001857,
  "created_at" : "2013-09-07 00:45:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 3, 10 ],
      "id_str" : "11604",
      "id" : 11604
    }, {
      "name" : "Andy Yang",
      "screen_name" : "andyyang",
      "indices" : [ 79, 88 ],
      "id_str" : "774850",
      "id" : 774850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/9UJG8ga4rb",
      "expanded_url" : "http:\/\/coldattic.info\/shvedsky\/pro\/blogs\/a-foo-walks-into-a-bar\/posts\/98",
      "display_url" : "coldattic.info\/shvedsky\/pro\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376133892798812160",
  "text" : "RT @torrez: So here is your weekend hacking project http:\/\/t.co\/9UJG8ga4rb via @andyyang",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Yang",
        "screen_name" : "andyyang",
        "indices" : [ 67, 76 ],
        "id_str" : "774850",
        "id" : 774850
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/9UJG8ga4rb",
        "expanded_url" : "http:\/\/coldattic.info\/shvedsky\/pro\/blogs\/a-foo-walks-into-a-bar\/posts\/98",
        "display_url" : "coldattic.info\/shvedsky\/pro\/b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "376133177217015808",
    "text" : "So here is your weekend hacking project http:\/\/t.co\/9UJG8ga4rb via @andyyang",
    "id" : 376133177217015808,
    "created_at" : "2013-09-07 00:01:52 +0000",
    "user" : {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "protected" : false,
      "id_str" : "11604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463439738167238656\/nhxNlsQL_normal.png",
      "id" : 11604,
      "verified" : false
    }
  },
  "id" : 376133892798812160,
  "created_at" : "2013-09-07 00:04:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    }, {
      "name" : "Andy Yang",
      "screen_name" : "andyyang",
      "indices" : [ 8, 17 ],
      "id_str" : "774850",
      "id" : 774850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376133177217015808",
  "geo" : { },
  "id_str" : "376133873492434944",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez @andyyang That's rad. Totally gonna copy this idea.",
  "id" : 376133873492434944,
  "in_reply_to_status_id" : 376133177217015808,
  "created_at" : "2013-09-07 00:04:38 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376124193567289344",
  "geo" : { },
  "id_str" : "376124838923890688",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler Hilarious! So bad! :)",
  "id" : 376124838923890688,
  "in_reply_to_status_id" : 376124193567289344,
  "created_at" : "2013-09-06 23:28:44 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "indices" : [ 0, 5 ],
      "id_str" : "949521",
      "id" : 949521
    }, {
      "name" : "Mike Kruzeniski",
      "screen_name" : "mkruz",
      "indices" : [ 6, 12 ],
      "id_str" : "6604912",
      "id" : 6604912
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowPlaying",
      "indices" : [ 13, 24 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376093541945987072",
  "geo" : { },
  "id_str" : "376094785167032320",
  "in_reply_to_user_id" : 949521,
  "text" : "@stop @mkruz #NowPlaying",
  "id" : 376094785167032320,
  "in_reply_to_status_id" : 376093541945987072,
  "created_at" : "2013-09-06 21:29:18 +0000",
  "in_reply_to_screen_name" : "stop",
  "in_reply_to_user_id_str" : "949521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Kruzeniski",
      "screen_name" : "mkruz",
      "indices" : [ 0, 6 ],
      "id_str" : "6604912",
      "id" : 6604912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376092917292490752",
  "geo" : { },
  "id_str" : "376093077972062208",
  "in_reply_to_user_id" : 6604912,
  "text" : "@mkruz Go crazy.",
  "id" : 376093077972062208,
  "in_reply_to_status_id" : 376092917292490752,
  "created_at" : "2013-09-06 21:22:31 +0000",
  "in_reply_to_screen_name" : "mkruz",
  "in_reply_to_user_id_str" : "6604912",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    }, {
      "name" : "Derek Powazek",
      "screen_name" : "fraying",
      "indices" : [ 8, 16 ],
      "id_str" : "4999",
      "id" : 4999
    }, {
      "name" : "Taylor Singletary",
      "screen_name" : "episod",
      "indices" : [ 68, 75 ],
      "id_str" : "819797",
      "id" : 819797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376089990481985536",
  "geo" : { },
  "id_str" : "376090403247640576",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez @fraying Looks like a bug. Do you know anything about this, @episod?",
  "id" : 376090403247640576,
  "in_reply_to_status_id" : 376089990481985536,
  "created_at" : "2013-09-06 21:11:54 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "timoni west",
      "screen_name" : "timoni",
      "indices" : [ 0, 7 ],
      "id_str" : "12615",
      "id" : 12615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375991079038111744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596360118, -122.2754488794 ]
  },
  "id_str" : "375999273315221507",
  "in_reply_to_user_id" : 12615,
  "text" : "@timoni Probably because they're easy to hand off to our younger siblings.",
  "id" : 375999273315221507,
  "in_reply_to_status_id" : 375991079038111744,
  "created_at" : "2013-09-06 15:09:47 +0000",
  "in_reply_to_screen_name" : "timoni",
  "in_reply_to_user_id_str" : "12615",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 3, 10 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Julie Zhuo",
      "screen_name" : "joulee",
      "indices" : [ 101, 108 ],
      "id_str" : "17611446",
      "id" : 17611446
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/lrMy0exJGI",
      "expanded_url" : "https:\/\/medium.com\/the-year-of-the-looking-glass\/dbb1a8b173c1?utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
      "display_url" : "medium.com\/the-year-of-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375988924776075264",
  "text" : "RT @Medium: \u201CThe Game of Life: how to deal with the fact that we are all completely irrational. \u201D by @joulee https:\/\/t.co\/lrMy0exJGI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Zhuo",
        "screen_name" : "joulee",
        "indices" : [ 89, 96 ],
        "id_str" : "17611446",
        "id" : 17611446
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/lrMy0exJGI",
        "expanded_url" : "https:\/\/medium.com\/the-year-of-the-looking-glass\/dbb1a8b173c1?utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
        "display_url" : "medium.com\/the-year-of-th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "375984483947663360",
    "text" : "\u201CThe Game of Life: how to deal with the fact that we are all completely irrational. \u201D by @joulee https:\/\/t.co\/lrMy0exJGI",
    "id" : 375984483947663360,
    "created_at" : "2013-09-06 14:11:01 +0000",
    "user" : {
      "name" : "Medium",
      "screen_name" : "Medium",
      "protected" : false,
      "id_str" : "571202103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2504297462\/wtbq3hoquj8no6t2ysz4_normal.jpeg",
      "id" : 571202103,
      "verified" : true
    }
  },
  "id" : 375988924776075264,
  "created_at" : "2013-09-06 14:28:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/lUFSGP2uS0",
      "expanded_url" : "http:\/\/flic.kr\/p\/fKxUzv",
      "display_url" : "flic.kr\/p\/fKxUzv"
    } ]
  },
  "geo" : { },
  "id_str" : "375837965152317440",
  "text" : "8:36pm Watching Skins 3 for no particular reason http:\/\/t.co\/lUFSGP2uS0",
  "id" : 375837965152317440,
  "created_at" : "2013-09-06 04:28:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Quinn",
      "screen_name" : "maxbot3000",
      "indices" : [ 0, 11 ],
      "id_str" : "1193706962",
      "id" : 1193706962
    }, {
      "name" : "Magic Recs",
      "screen_name" : "MagicRecs",
      "indices" : [ 12, 22 ],
      "id_str" : "1270746139",
      "id" : 1270746139
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 23, 30 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375770946587480064",
  "geo" : { },
  "id_str" : "375782280683196417",
  "in_reply_to_user_id" : 1193706962,
  "text" : "@maxbot3000 @magicrecs @sippey That's exactly what I was hoping.",
  "id" : 375782280683196417,
  "in_reply_to_status_id" : 375770946587480064,
  "created_at" : "2013-09-06 00:47:32 +0000",
  "in_reply_to_screen_name" : "maxbot3000",
  "in_reply_to_user_id_str" : "1193706962",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magic Recs",
      "screen_name" : "MagicRecs",
      "indices" : [ 19, 29 ],
      "id_str" : "1270746139",
      "id" : 1270746139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375762126763073536",
  "text" : "I want to see your @magicrecs.",
  "id" : 375762126763073536,
  "created_at" : "2013-09-05 23:27:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375753343747903488",
  "geo" : { },
  "id_str" : "375754202108022784",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk Write about whatever you're currently learning about. The biggest questions you can't currently answer, or only recently solved.",
  "id" : 375754202108022784,
  "in_reply_to_status_id" : 375753343747903488,
  "created_at" : "2013-09-05 22:55:57 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 3, 15 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/JPGfNJ4LVc",
      "expanded_url" : "http:\/\/bit.ly\/17AX0u0",
      "display_url" : "bit.ly\/17AX0u0"
    } ]
  },
  "geo" : { },
  "id_str" : "375747825964818432",
  "text" : "RT @nickcrocker: Males. Can you try my 7 Minute Man Stretch and report back pls? http:\/\/t.co\/JPGfNJ4LVc",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/JPGfNJ4LVc",
        "expanded_url" : "http:\/\/bit.ly\/17AX0u0",
        "display_url" : "bit.ly\/17AX0u0"
      } ]
    },
    "geo" : { },
    "id_str" : "375747119816011776",
    "text" : "Males. Can you try my 7 Minute Man Stretch and report back pls? http:\/\/t.co\/JPGfNJ4LVc",
    "id" : 375747119816011776,
    "created_at" : "2013-09-05 22:27:49 +0000",
    "user" : {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "protected" : false,
      "id_str" : "30801469",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460845803498516480\/1m9QG5iU_normal.jpeg",
      "id" : 30801469,
      "verified" : false
    }
  },
  "id" : 375747825964818432,
  "created_at" : "2013-09-05 22:30:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375747119816011776",
  "geo" : { },
  "id_str" : "375747775616389120",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker I'll try it tonight!",
  "id" : 375747775616389120,
  "in_reply_to_status_id" : 375747119816011776,
  "created_at" : "2013-09-05 22:30:25 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah, agirlandaboy",
      "screen_name" : "agirlandaboy",
      "indices" : [ 0, 13 ],
      "id_str" : "80895925",
      "id" : 80895925
    }, {
      "name" : "Doing My Best",
      "screen_name" : "am_doingmybest",
      "indices" : [ 14, 29 ],
      "id_str" : "292386130",
      "id" : 292386130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375711395712495616",
  "geo" : { },
  "id_str" : "375711648347979776",
  "in_reply_to_user_id" : 80895925,
  "text" : "@agirlandaboy @am_doingmybest Yes, definitely send me screenshots and notes! The team has fixed several bugs and is open to all feedback.",
  "id" : 375711648347979776,
  "in_reply_to_status_id" : 375711395712495616,
  "created_at" : "2013-09-05 20:06:52 +0000",
  "in_reply_to_screen_name" : "agirlandaboy",
  "in_reply_to_user_id_str" : "80895925",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Kedrosky",
      "screen_name" : "pkedrosky",
      "indices" : [ 3, 13 ],
      "id_str" : "1717291",
      "id" : 1717291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/mKqflRWAhq",
      "expanded_url" : "http:\/\/www.wimp.com\/vegetablemarket\/",
      "display_url" : "wimp.com\/vegetablemarke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375703272125771777",
  "text" : "RT @pkedrosky: Remarkable: How close to a train track can you set up a vegetable market? http:\/\/t.co\/mKqflRWAhq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/mKqflRWAhq",
        "expanded_url" : "http:\/\/www.wimp.com\/vegetablemarket\/",
        "display_url" : "wimp.com\/vegetablemarke\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "375697212040155136",
    "text" : "Remarkable: How close to a train track can you set up a vegetable market? http:\/\/t.co\/mKqflRWAhq",
    "id" : 375697212040155136,
    "created_at" : "2013-09-05 19:09:30 +0000",
    "user" : {
      "name" : "Paul Kedrosky",
      "screen_name" : "pkedrosky",
      "protected" : false,
      "id_str" : "1717291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3293726938\/94d9c55d04adce1174aefa25eb0d6a02_normal.jpeg",
      "id" : 1717291,
      "verified" : true
    }
  },
  "id" : 375703272125771777,
  "created_at" : "2013-09-05 19:33:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "right",
      "indices" : [ 77, 83 ]
    }, {
      "text" : "whatever",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/zmDIZEjn9O",
      "expanded_url" : "http:\/\/m.adage.com\/article?articleSection=digital&articleSectionName=Digital&articleid=http%3A%2F%2Fadage.com%2Fdigital%2Farticle%3Farticle_id%3D243986",
      "display_url" : "m.adage.com\/article?articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8094119451, -122.2728829489 ]
  },
  "id_str" : "375471963927359488",
  "text" : "\"This represents a significant evolution of the logo\" http:\/\/t.co\/zmDIZEjn9O #right #whatever",
  "id" : 375471963927359488,
  "created_at" : "2013-09-05 04:14:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/hzjXUKKnrx",
      "expanded_url" : "http:\/\/flic.kr\/p\/fJVRkP",
      "display_url" : "flic.kr\/p\/fJVRkP"
    } ]
  },
  "geo" : { },
  "id_str" : "375469868973187072",
  "text" : "8:36pm Date night talking about other people's bizniz http:\/\/t.co\/hzjXUKKnrx",
  "id" : 375469868973187072,
  "created_at" : "2013-09-05 04:06:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver",
      "screen_name" : "orvtech",
      "indices" : [ 3, 11 ],
      "id_str" : "4412471",
      "id" : 4412471
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 13, 20 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375427649599832064",
  "text" : "RT @orvtech: @buster 85.7% of people will believe this",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "375423557959819264",
    "geo" : { },
    "id_str" : "375425300034629632",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster 85.7% of people will believe this",
    "id" : 375425300034629632,
    "in_reply_to_status_id" : 375423557959819264,
    "created_at" : "2013-09-05 01:09:01 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Oliver",
      "screen_name" : "orvtech",
      "protected" : false,
      "id_str" : "4412471",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431132354422132736\/1dyV-rR1_normal.jpeg",
      "id" : 4412471,
      "verified" : false
    }
  },
  "id" : 375427649599832064,
  "created_at" : "2013-09-05 01:18:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7775546397, -122.4160553982 ]
  },
  "id_str" : "375423557959819264",
  "text" : "\"Providing someone with a random numerical forecast increases his risk taking even if he knows the predictions are random.\" - Antifragile",
  "id" : 375423557959819264,
  "created_at" : "2013-09-05 01:02:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelton Lynn",
      "screen_name" : "keltonlynn",
      "indices" : [ 0, 11 ],
      "id_str" : "27674040",
      "id" : 27674040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375115423571668992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597686298, -122.2755667226 ]
  },
  "id_str" : "375115980927557632",
  "in_reply_to_user_id" : 27674040,
  "text" : "@keltonlynn Oh just meant the $400+ options for more data from the blood test. Will definitely let you know how it goes.",
  "id" : 375115980927557632,
  "in_reply_to_status_id" : 375115423571668992,
  "created_at" : "2013-09-04 04:39:53 +0000",
  "in_reply_to_screen_name" : "keltonlynn",
  "in_reply_to_user_id_str" : "27674040",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelton Lynn",
      "screen_name" : "keltonlynn",
      "indices" : [ 0, 11 ],
      "id_str" : "27674040",
      "id" : 27674040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375111350969573376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597878572, -122.2753849347 ]
  },
  "id_str" : "375111626921238528",
  "in_reply_to_user_id" : 27674040,
  "text" : "@keltonlynn Just signed up. Want to do the more expensive ones but will try it out first. Thanks for the rec!",
  "id" : 375111626921238528,
  "in_reply_to_status_id" : 375111350969573376,
  "created_at" : "2013-09-04 04:22:35 +0000",
  "in_reply_to_screen_name" : "keltonlynn",
  "in_reply_to_user_id_str" : "27674040",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelton Lynn",
      "screen_name" : "keltonlynn",
      "indices" : [ 0, 11 ],
      "id_str" : "27674040",
      "id" : 27674040
    }, {
      "name" : "WellnessFX",
      "screen_name" : "WellnessFX",
      "indices" : [ 12, 23 ],
      "id_str" : "154189407",
      "id" : 154189407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375109364287156224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597854991, -122.2754557871 ]
  },
  "id_str" : "375109834602844160",
  "in_reply_to_user_id" : 27674040,
  "text" : "@keltonlynn @WellnessFX Thinking of trying it out. What kinds of things did you learn?",
  "id" : 375109834602844160,
  "in_reply_to_status_id" : 375109364287156224,
  "created_at" : "2013-09-04 04:15:28 +0000",
  "in_reply_to_screen_name" : "keltonlynn",
  "in_reply_to_user_id_str" : "27674040",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/WalnXfu1Op",
      "expanded_url" : "http:\/\/flic.kr\/p\/fJgyrt",
      "display_url" : "flic.kr\/p\/fJgyrt"
    } ]
  },
  "geo" : { },
  "id_str" : "375109477474660352",
  "text" : "8:36pm Late dinner http:\/\/t.co\/WalnXfu1Op",
  "id" : 375109477474660352,
  "created_at" : "2013-09-04 04:14:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nassim N. Taleb",
      "screen_name" : "nntaleb",
      "indices" : [ 106, 114 ],
      "id_str" : "381289719",
      "id" : 381289719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8588038218, -122.2756136769 ]
  },
  "id_str" : "375092956207656960",
  "text" : "\"We have managed to transfer religious belief into gullibility for whatever can masquerade as science.\" - @nntaleb in Antifragility",
  "id" : 375092956207656960,
  "created_at" : "2013-09-04 03:08:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776781272, -122.4172618877 ]
  },
  "id_str" : "375075579143258112",
  "text" : "I just learneded some things.",
  "id" : 375075579143258112,
  "created_at" : "2013-09-04 01:59:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374980804448776192",
  "geo" : { },
  "id_str" : "374981039942160384",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Okay, no worries if it's too much trouble. Just gathering feedback.",
  "id" : 374981039942160384,
  "in_reply_to_status_id" : 374980804448776192,
  "created_at" : "2013-09-03 19:43:41 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374980531605090304",
  "geo" : { },
  "id_str" : "374980640069795840",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Yeah, just take a screenshot of it and let me know what it is about it that you don't like.",
  "id" : 374980640069795840,
  "in_reply_to_status_id" : 374980531605090304,
  "created_at" : "2013-09-03 19:42:06 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374979717406789632",
  "geo" : { },
  "id_str" : "374980242516881408",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Can you send me a screenshot of it when it's in a state that you hate? Collecting them to pass on.",
  "id" : 374980242516881408,
  "in_reply_to_status_id" : 374979717406789632,
  "created_at" : "2013-09-03 19:40:31 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "indices" : [ 0, 11 ],
      "id_str" : "8070502",
      "id" : 8070502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374976111249072129",
  "geo" : { },
  "id_str" : "374976257764495360",
  "in_reply_to_user_id" : 8070502,
  "text" : "@danshapiro It's the smartest thing I've seen in a long time. Well done! Can't wait to play.",
  "id" : 374976257764495360,
  "in_reply_to_status_id" : 374976111249072129,
  "created_at" : "2013-09-03 19:24:41 +0000",
  "in_reply_to_screen_name" : "danshapiro",
  "in_reply_to_user_id_str" : "8070502",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "indices" : [ 44, 55 ],
      "id_str" : "8070502",
      "id" : 8070502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/MqC1SoRphA",
      "expanded_url" : "http:\/\/kck.st\/17BKz3h",
      "display_url" : "kck.st\/17BKz3h"
    } ]
  },
  "geo" : { },
  "id_str" : "374962032384040960",
  "text" : "If you have kids 3-8, you HAVE to check out @DanShapiro's Kickstarter game that helps teach programming. Amazing. http:\/\/t.co\/MqC1SoRphA",
  "id" : 374962032384040960,
  "created_at" : "2013-09-03 18:28:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Brewer",
      "screen_name" : "jbrewer",
      "indices" : [ 3, 11 ],
      "id_str" : "12555",
      "id" : 12555
    }, {
      "name" : "Stijn Debrouwere",
      "screen_name" : "stdbrouw",
      "indices" : [ 125, 134 ],
      "id_str" : "334912156",
      "id" : 334912156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374958666757062657",
  "text" : "RT @jbrewer: \u201CMetrics are for doing, not for staring. Never measure just because you can. Measure to learn. Measure to fix.\u201D\u2014@stdbrouw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stijn Debrouwere",
        "screen_name" : "stdbrouw",
        "indices" : [ 112, 121 ],
        "id_str" : "334912156",
        "id" : 334912156
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374958595852357632",
    "text" : "\u201CMetrics are for doing, not for staring. Never measure just because you can. Measure to learn. Measure to fix.\u201D\u2014@stdbrouw",
    "id" : 374958595852357632,
    "created_at" : "2013-09-03 18:14:30 +0000",
    "user" : {
      "name" : "Josh Brewer",
      "screen_name" : "jbrewer",
      "protected" : false,
      "id_str" : "12555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000470238857\/de3847a968ebe1c0cb700f4e07356dd3_normal.jpeg",
      "id" : 12555,
      "verified" : false
    }
  },
  "id" : 374958666757062657,
  "created_at" : "2013-09-03 18:14:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "indices" : [ 13, 22 ],
      "id_str" : "255784266",
      "id" : 255784266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/birsDFhOKD",
      "expanded_url" : "http:\/\/goo.gl\/fb\/u56cP",
      "display_url" : "goo.gl\/fb\/u56cP"
    } ]
  },
  "in_reply_to_status_id_str" : "374920504635035648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597762215, -122.2755710712 ]
  },
  "id_str" : "374922181014085632",
  "in_reply_to_user_id" : 255784266,
  "text" : "Exciting! RT @geekwire: Amazon leaks new Kindle Paperwhite set to ship Sept. 30 with Goodreads integration http:\/\/t.co\/birsDFhOKD",
  "id" : 374922181014085632,
  "in_reply_to_status_id" : 374920504635035648,
  "created_at" : "2013-09-03 15:49:48 +0000",
  "in_reply_to_screen_name" : "geekwire",
  "in_reply_to_user_id_str" : "255784266",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Linden",
      "screen_name" : "greglinden",
      "indices" : [ 3, 14 ],
      "id_str" : "87719108",
      "id" : 87719108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/FCMU8zgxEc",
      "expanded_url" : "http:\/\/www.schneier.com\/blog\/archives\/2013\/09\/our_newfound_fe.html",
      "display_url" : "schneier.com\/blog\/archives\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374919079187841024",
  "text" : "RT @greglinden: \"We need to relearn how to accept risk, and even embrace it, as essential to human progress and our free society.\" http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/FCMU8zgxEc",
        "expanded_url" : "http:\/\/www.schneier.com\/blog\/archives\/2013\/09\/our_newfound_fe.html",
        "display_url" : "schneier.com\/blog\/archives\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "374918783464259585",
    "text" : "\"We need to relearn how to accept risk, and even embrace it, as essential to human progress and our free society.\" http:\/\/t.co\/FCMU8zgxEc",
    "id" : 374918783464259585,
    "created_at" : "2013-09-03 15:36:18 +0000",
    "user" : {
      "name" : "Greg Linden",
      "screen_name" : "greglinden",
      "protected" : false,
      "id_str" : "87719108",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441427879809675264\/NUsuaTou_normal.png",
      "id" : 87719108,
      "verified" : false
    }
  },
  "id" : 374919079187841024,
  "created_at" : "2013-09-03 15:37:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt",
      "screen_name" : "upthesaints",
      "indices" : [ 0, 12 ],
      "id_str" : "53439304",
      "id" : 53439304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374798264102830081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597551902, -122.2755960191 ]
  },
  "id_str" : "374918464097361920",
  "in_reply_to_user_id" : 53439304,
  "text" : "@upthesaints If you find specifics that illustrate these points, send them along. It helps us figure out how to improve things.",
  "id" : 374918464097361920,
  "in_reply_to_status_id" : 374798264102830081,
  "created_at" : "2013-09-03 15:35:02 +0000",
  "in_reply_to_screen_name" : "upthesaints",
  "in_reply_to_user_id_str" : "53439304",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/5XuhyoaPdT",
      "expanded_url" : "http:\/\/flic.kr\/p\/fHRyh4",
      "display_url" : "flic.kr\/p\/fHRyh4"
    } ]
  },
  "geo" : { },
  "id_str" : "374917688125956096",
  "text" : "Niko and Shylo, heading to first day back at preschool together http:\/\/t.co\/5XuhyoaPdT",
  "id" : 374917688125956096,
  "created_at" : "2013-09-03 15:31:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt",
      "screen_name" : "upthesaints",
      "indices" : [ 0, 12 ],
      "id_str" : "53439304",
      "id" : 53439304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374787097179062272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597631688, -122.2755712269 ]
  },
  "id_str" : "374787443553091584",
  "in_reply_to_user_id" : 53439304,
  "text" : "@upthesaints Can you send me screenshots with notes to buster@twitter.com? I can investigate.",
  "id" : 374787443553091584,
  "in_reply_to_status_id" : 374787097179062272,
  "created_at" : "2013-09-03 06:54:24 +0000",
  "in_reply_to_screen_name" : "upthesaints",
  "in_reply_to_user_id_str" : "53439304",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/9K1PuCU1vw",
      "expanded_url" : "http:\/\/flic.kr\/p\/fHM8Mm",
      "display_url" : "flic.kr\/p\/fHM8Mm"
    } ]
  },
  "geo" : { },
  "id_str" : "374738262390104064",
  "text" : "8:36pm \"That's a family selfie for the ages.\" http:\/\/t.co\/9K1PuCU1vw",
  "id" : 374738262390104064,
  "created_at" : "2013-09-03 03:38:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doing My Best",
      "screen_name" : "am_doingmybest",
      "indices" : [ 0, 15 ],
      "id_str" : "292386130",
      "id" : 292386130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374642025993236480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596278801, -122.2757402485 ]
  },
  "id_str" : "374647965794578432",
  "in_reply_to_user_id" : 292386130,
  "text" : "@am_doingmybest Can you send me a screenshot with some notes on what you hate about it? buster@twitter.com",
  "id" : 374647965794578432,
  "in_reply_to_status_id" : 374642025993236480,
  "created_at" : "2013-09-02 21:40:10 +0000",
  "in_reply_to_screen_name" : "am_doingmybest",
  "in_reply_to_user_id_str" : "292386130",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong ",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Matthew Cobb",
      "screen_name" : "matthewcobb",
      "indices" : [ 131, 140 ],
      "id_str" : "1524781",
      "id" : 1524781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/WjEhar9ke7",
      "expanded_url" : "http:\/\/whyevolutionistrue.wordpress.com\/2013\/08\/29\/a-most-bizarre-and-mysterious-cocoon\/",
      "display_url" : "whyevolutionistrue.wordpress.com\/2013\/08\/29\/a-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374571276435611648",
  "text" : "RT @edyong209: Some weird insect is building a white fence around its eggs, and no one knows what it is. http:\/\/t.co\/WjEhar9ke7 HT @matthew\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew Cobb",
        "screen_name" : "matthewcobb",
        "indices" : [ 116, 128 ],
        "id_str" : "1524781",
        "id" : 1524781
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/WjEhar9ke7",
        "expanded_url" : "http:\/\/whyevolutionistrue.wordpress.com\/2013\/08\/29\/a-most-bizarre-and-mysterious-cocoon\/",
        "display_url" : "whyevolutionistrue.wordpress.com\/2013\/08\/29\/a-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "374569605932384256",
    "text" : "Some weird insect is building a white fence around its eggs, and no one knows what it is. http:\/\/t.co\/WjEhar9ke7 HT @matthewcobb",
    "id" : 374569605932384256,
    "created_at" : "2013-09-02 16:28:47 +0000",
    "user" : {
      "name" : "Ed Yong ",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/418825738603597824\/W93KppIS_normal.jpeg",
      "id" : 19767193,
      "verified" : false
    }
  },
  "id" : 374571276435611648,
  "created_at" : "2013-09-02 16:35:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Ted Rheingold",
      "screen_name" : "tedr",
      "indices" : [ 9, 14 ],
      "id_str" : "997",
      "id" : 997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374568869567803392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597382312, -122.2755081596 ]
  },
  "id_str" : "374569482133327872",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver @tedr I'm just cheap. :) That said, once the initial backup happened, it now works like a charm.",
  "id" : 374569482133327872,
  "in_reply_to_status_id" : 374568869567803392,
  "created_at" : "2013-09-02 16:28:18 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Rheingold",
      "screen_name" : "tedr",
      "indices" : [ 0, 5 ],
      "id_str" : "997",
      "id" : 997
    }, {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 6, 14 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Backblaze",
      "screen_name" : "backblaze",
      "indices" : [ 15, 25 ],
      "id_str" : "18236716",
      "id" : 18236716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374565245135495168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597218602, -122.2755196823 ]
  },
  "id_str" : "374568210080608256",
  "in_reply_to_user_id" : 997,
  "text" : "@tedr @rsarver @backblaze It definitely slowed my network down. I had it start synching at 1am and paused it every morning. Took weeks.",
  "id" : 374568210080608256,
  "in_reply_to_status_id" : 374565245135495168,
  "created_at" : "2013-09-02 16:23:15 +0000",
  "in_reply_to_screen_name" : "tedr",
  "in_reply_to_user_id_str" : "997",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "indices" : [ 3, 14 ],
      "id_str" : "135316691",
      "id" : 135316691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/UCrYyXr9ow",
      "expanded_url" : "http:\/\/buff.ly\/15wWvAr",
      "display_url" : "buff.ly\/15wWvAr"
    } ]
  },
  "geo" : { },
  "id_str" : "374566369150259200",
  "text" : "RT @JadAbumrad: An astronaut's meditation on friendship, loneliness &amp; spaceship Earth - http:\/\/t.co\/UCrYyXr9ow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/UCrYyXr9ow",
        "expanded_url" : "http:\/\/buff.ly\/15wWvAr",
        "display_url" : "buff.ly\/15wWvAr"
      } ]
    },
    "geo" : { },
    "id_str" : "374562138242969600",
    "text" : "An astronaut's meditation on friendship, loneliness &amp; spaceship Earth - http:\/\/t.co\/UCrYyXr9ow",
    "id" : 374562138242969600,
    "created_at" : "2013-09-02 15:59:07 +0000",
    "user" : {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "protected" : false,
      "id_str" : "135316691",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1529014082\/Jad-Pic2_normal.jpg",
      "id" : 135316691,
      "verified" : true
    }
  },
  "id" : 374566369150259200,
  "created_at" : "2013-09-02 16:15:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tikva Morowati",
      "screen_name" : "tikkers",
      "indices" : [ 14, 22 ],
      "id_str" : "1054551",
      "id" : 1054551
    }, {
      "name" : "Tim Harford",
      "screen_name" : "TimHarford",
      "indices" : [ 26, 37 ],
      "id_str" : "32493647",
      "id" : 32493647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/eeHJpP8F0m",
      "expanded_url" : "http:\/\/dlvr.it\/3v4mm6",
      "display_url" : "dlvr.it\/3v4mm6"
    } ]
  },
  "in_reply_to_status_id_str" : "374419561937780736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598025748, -122.2759899339 ]
  },
  "id_str" : "374420984968650752",
  "in_reply_to_user_id" : 32493647,
  "text" : "On legacy \/cc @tikkers RT @TimHarford: xkcd: \"Bee Orchid\" Beautiful http:\/\/t.co\/eeHJpP8F0m",
  "id" : 374420984968650752,
  "in_reply_to_status_id" : 374419561937780736,
  "created_at" : "2013-09-02 06:38:13 +0000",
  "in_reply_to_screen_name" : "TimHarford",
  "in_reply_to_user_id_str" : "32493647",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chachasikes",
      "screen_name" : "chachasikes",
      "indices" : [ 0, 12 ],
      "id_str" : "14353952",
      "id" : 14353952
    }, {
      "name" : "Tikva Morowati",
      "screen_name" : "tikkers",
      "indices" : [ 13, 21 ],
      "id_str" : "1054551",
      "id" : 1054551
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 22, 32 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374389156132040704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859771037, -122.2755667468 ]
  },
  "id_str" : "374390623903571968",
  "in_reply_to_user_id" : 14353952,
  "text" : "@chachasikes @tikkers @kellianne More bikes and food and hanging out must happen!",
  "id" : 374390623903571968,
  "in_reply_to_status_id" : 374389156132040704,
  "created_at" : "2013-09-02 04:37:35 +0000",
  "in_reply_to_screen_name" : "chachasikes",
  "in_reply_to_user_id_str" : "14353952",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tikva Morowati",
      "screen_name" : "tikkers",
      "indices" : [ 72, 80 ],
      "id_str" : "1054551",
      "id" : 1054551
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 82, 92 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/KIKK9NkPul",
      "expanded_url" : "http:\/\/flic.kr\/p\/fGWGMN",
      "display_url" : "flic.kr\/p\/fGWGMN"
    } ]
  },
  "geo" : { },
  "id_str" : "374380854836883457",
  "text" : "8:36pm Coming home from a beautiful day of biking and eating spent with @tikkers, @kellianne, and new friends http:\/\/t.co\/KIKK9NkPul",
  "id" : 374380854836883457,
  "created_at" : "2013-09-02 03:58:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Martell",
      "screen_name" : "danmartell",
      "indices" : [ 3, 14 ],
      "id_str" : "10638782",
      "id" : 10638782
    }, {
      "name" : "Dave McClure",
      "screen_name" : "davemcclure",
      "indices" : [ 139, 140 ],
      "id_str" : "1081",
      "id" : 1081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374336467192930305",
  "text" : "RT @danmartell: A \u2018startup\u2019 is a company that is confused about - \n1. What its product is, \n2. Who its customers are. \n3. How to make money\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dave McClure",
        "screen_name" : "davemcclure",
        "indices" : [ 128, 140 ],
        "id_str" : "1081",
        "id" : 1081
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374336008156090368",
    "text" : "A \u2018startup\u2019 is a company that is confused about - \n1. What its product is, \n2. Who its customers are. \n3. How to make money.\n\n- @DaveMcClure",
    "id" : 374336008156090368,
    "created_at" : "2013-09-02 01:00:33 +0000",
    "user" : {
      "name" : "Dan Martell",
      "screen_name" : "danmartell",
      "protected" : false,
      "id_str" : "10638782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465852106419621888\/KbEQgsE__normal.jpeg",
      "id" : 10638782,
      "verified" : false
    }
  },
  "id" : 374336467192930305,
  "created_at" : "2013-09-02 01:02:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "almost",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597388231, -122.2754618806 ]
  },
  "id_str" : "374332330397024256",
  "text" : "The first day of not being sick after being sick for over a week almost makes it worth being sick. #almost",
  "id" : 374332330397024256,
  "created_at" : "2013-09-02 00:45:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596635117, -122.2754823324 ]
  },
  "id_str" : "374183948286312448",
  "text" : "Rabbit rabbit! \uD83D\uDC30\uD83D\uDC30",
  "id" : 374183948286312448,
  "created_at" : "2013-09-01 14:56:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]