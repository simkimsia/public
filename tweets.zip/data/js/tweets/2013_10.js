Grailbird.data.tweets_2013_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweetacoffee",
      "screen_name" : "Tweetacoffee",
      "indices" : [ 0, 13 ],
      "id_str" : "1553972634",
      "id" : 1553972634
    }, {
      "name" : "Andy Sack",
      "screen_name" : "AndySack",
      "indices" : [ 17, 26 ],
      "id_str" : "39362168",
      "id" : 39362168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396153016664850432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597368533, -122.2754156125 ]
  },
  "id_str" : "396153452469817345",
  "in_reply_to_user_id" : 39362168,
  "text" : "@tweetacoffee to @AndySack and let me know what you get.",
  "id" : 396153452469817345,
  "in_reply_to_status_id" : 396153016664850432,
  "created_at" : "2013-11-01 05:55:17 +0000",
  "in_reply_to_screen_name" : "AndySack",
  "in_reply_to_user_id_str" : "39362168",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McAllister",
      "screen_name" : "ianmcall",
      "indices" : [ 20, 29 ],
      "id_str" : "2035631",
      "id" : 2035631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "worthatry",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396147945570975744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597069299, -122.275294494 ]
  },
  "id_str" : "396148177826361345",
  "in_reply_to_user_id" : 2035631,
  "text" : "@tweetamanhattan to @ianmcall #worthatry",
  "id" : 396148177826361345,
  "in_reply_to_status_id" : 396147945570975744,
  "created_at" : "2013-11-01 05:34:20 +0000",
  "in_reply_to_screen_name" : "ianmcall",
  "in_reply_to_user_id_str" : "2035631",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "TriemTeam",
      "screen_name" : "TriemTeam",
      "indices" : [ 11, 21 ],
      "id_str" : "24792603",
      "id" : 24792603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396127207568842752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597482188, -122.2754720986 ]
  },
  "id_str" : "396128331554254848",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne @TriemTeam Good research. Oops, I got 3 letter right at least.",
  "id" : 396128331554254848,
  "in_reply_to_status_id" : 396127207568842752,
  "created_at" : "2013-11-01 04:15:28 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/3sPD3QdLuG",
      "expanded_url" : "http:\/\/flic.kr\/p\/h9XrWE",
      "display_url" : "flic.kr\/p\/h9XrWE"
    } ]
  },
  "geo" : { },
  "id_str" : "396126245777596416",
  "text" : "8:36pm Aleca shares her trains with her new BFF http:\/\/t.co\/3sPD3QdLuG",
  "id" : 396126245777596416,
  "created_at" : "2013-11-01 04:07:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Tweetacoffee",
      "screen_name" : "Tweetacoffee",
      "indices" : [ 9, 22 ],
      "id_str" : "1553972634",
      "id" : 1553972634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396030152066359296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763867453, -122.4174728624 ]
  },
  "id_str" : "396030495579848705",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs @Tweetacoffee Let me know how you like it.",
  "id" : 396030495579848705,
  "in_reply_to_status_id" : 396030152066359296,
  "created_at" : "2013-10-31 21:46:42 +0000",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweetacoffee",
      "screen_name" : "Tweetacoffee",
      "indices" : [ 0, 13 ],
      "id_str" : "1553972634",
      "id" : 1553972634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396027138312511488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763867453, -122.4174728624 ]
  },
  "id_str" : "396030338079535104",
  "in_reply_to_user_id" : 1553972634,
  "text" : "@Tweetacoffee Can you just tweet me a refund please?",
  "id" : 396030338079535104,
  "in_reply_to_status_id" : 396027138312511488,
  "created_at" : "2013-10-31 21:46:05 +0000",
  "in_reply_to_screen_name" : "Tweetacoffee",
  "in_reply_to_user_id_str" : "1553972634",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 3, 17 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396010817423822848",
  "text" : "RT @buster_ebooks: New habit challenge: don\u2019t look at today",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/busterbenson.com\" rel=\"nofollow\"\u003EBuster eBooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396005945362624513",
    "text" : "New habit challenge: don\u2019t look at today",
    "id" : 396005945362624513,
    "created_at" : "2013-10-31 20:09:09 +0000",
    "user" : {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "protected" : false,
      "id_str" : "1901375096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000503050571\/228ccabfeeb4e55bd8e172595babe02e_normal.jpeg",
      "id" : 1901375096,
      "verified" : false
    }
  },
  "id" : 396010817423822848,
  "created_at" : "2013-10-31 20:28:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "justin avery",
      "screen_name" : "justinavery",
      "indices" : [ 0, 12 ],
      "id_str" : "16613918",
      "id" : 16613918
    }, {
      "name" : "Tweetacoffee",
      "screen_name" : "Tweetacoffee",
      "indices" : [ 13, 26 ],
      "id_str" : "1553972634",
      "id" : 1553972634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396009777622679552",
  "geo" : { },
  "id_str" : "396010302753345537",
  "in_reply_to_user_id" : 16613918,
  "text" : "@justinavery @tweetacoffee Ah, bummer.",
  "id" : 396010302753345537,
  "in_reply_to_status_id" : 396009777622679552,
  "created_at" : "2013-10-31 20:26:28 +0000",
  "in_reply_to_screen_name" : "justinavery",
  "in_reply_to_user_id_str" : "16613918",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Becky Jewell",
      "screen_name" : "beckyjewell",
      "indices" : [ 0, 12 ],
      "id_str" : "26406166",
      "id" : 26406166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395999010286088192",
  "geo" : { },
  "id_str" : "396008653389455360",
  "in_reply_to_user_id" : 26406166,
  "text" : "@beckyjewell Totally. Tweeting gifts is fun.",
  "id" : 396008653389455360,
  "in_reply_to_status_id" : 395999010286088192,
  "created_at" : "2013-10-31 20:19:55 +0000",
  "in_reply_to_screen_name" : "beckyjewell",
  "in_reply_to_user_id_str" : "26406166",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395994755013672961",
  "text" : "All out of tweet coffees.",
  "id" : 395994755013672961,
  "created_at" : "2013-10-31 19:24:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweetacoffee",
      "screen_name" : "Tweetacoffee",
      "indices" : [ 0, 13 ],
      "id_str" : "1553972634",
      "id" : 1553972634
    }, {
      "name" : "Becky Jewell",
      "screen_name" : "beckyjewell",
      "indices" : [ 17, 29 ],
      "id_str" : "26406166",
      "id" : 26406166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395994283624251393",
  "in_reply_to_user_id" : 1553972634,
  "text" : "@tweetacoffee to @beckyjewell",
  "id" : 395994283624251393,
  "created_at" : "2013-10-31 19:22:49 +0000",
  "in_reply_to_screen_name" : "Tweetacoffee",
  "in_reply_to_user_id_str" : "1553972634",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Collette",
      "screen_name" : "sfposhy",
      "indices" : [ 0, 8 ],
      "id_str" : "268453413",
      "id" : 268453413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395993027392466944",
  "geo" : { },
  "id_str" : "395993755745910784",
  "in_reply_to_user_id" : 268453413,
  "text" : "@sfposhy Now see if you can figure out how to redeem it. :)",
  "id" : 395993755745910784,
  "in_reply_to_status_id" : 395993027392466944,
  "created_at" : "2013-10-31 19:20:43 +0000",
  "in_reply_to_screen_name" : "sfposhy",
  "in_reply_to_user_id_str" : "268453413",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweetacoffee",
      "screen_name" : "Tweetacoffee",
      "indices" : [ 0, 13 ],
      "id_str" : "1553972634",
      "id" : 1553972634
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 17, 25 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395992402264993792",
  "in_reply_to_user_id" : 1553972634,
  "text" : "@tweetacoffee to @djacobs",
  "id" : 395992402264993792,
  "created_at" : "2013-10-31 19:15:20 +0000",
  "in_reply_to_screen_name" : "Tweetacoffee",
  "in_reply_to_user_id_str" : "1553972634",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweetacoffee",
      "screen_name" : "Tweetacoffee",
      "indices" : [ 0, 13 ],
      "id_str" : "1553972634",
      "id" : 1553972634
    }, {
      "name" : "Lynn Collette",
      "screen_name" : "sfposhy",
      "indices" : [ 17, 25 ],
      "id_str" : "268453413",
      "id" : 268453413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395990882463133696",
  "in_reply_to_user_id" : 1553972634,
  "text" : "@tweetacoffee to @sfposhy",
  "id" : 395990882463133696,
  "created_at" : "2013-10-31 19:09:18 +0000",
  "in_reply_to_screen_name" : "Tweetacoffee",
  "in_reply_to_user_id_str" : "1553972634",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweetacoffee",
      "screen_name" : "Tweetacoffee",
      "indices" : [ 0, 13 ],
      "id_str" : "1553972634",
      "id" : 1553972634
    }, {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 17, 24 ],
      "id_str" : "1530531",
      "id" : 1530531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395990813508788224",
  "in_reply_to_user_id" : 1553972634,
  "text" : "@tweetacoffee to @miradu",
  "id" : 395990813508788224,
  "created_at" : "2013-10-31 19:09:01 +0000",
  "in_reply_to_screen_name" : "Tweetacoffee",
  "in_reply_to_user_id_str" : "1553972634",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweetacoffee",
      "screen_name" : "Tweetacoffee",
      "indices" : [ 0, 13 ],
      "id_str" : "1553972634",
      "id" : 1553972634
    }, {
      "name" : "Adam Besvinick",
      "screen_name" : "Besvinick",
      "indices" : [ 17, 27 ],
      "id_str" : "22745680",
      "id" : 22745680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395990736862056448",
  "in_reply_to_user_id" : 1553972634,
  "text" : "@tweetacoffee to @Besvinick",
  "id" : 395990736862056448,
  "created_at" : "2013-10-31 19:08:43 +0000",
  "in_reply_to_screen_name" : "Tweetacoffee",
  "in_reply_to_user_id_str" : "1553972634",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweetacoffee",
      "screen_name" : "Tweetacoffee",
      "indices" : [ 0, 13 ],
      "id_str" : "1553972634",
      "id" : 1553972634
    }, {
      "name" : "justin avery",
      "screen_name" : "justinavery",
      "indices" : [ 17, 29 ],
      "id_str" : "16613918",
      "id" : 16613918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395990686933073920",
  "in_reply_to_user_id" : 1553972634,
  "text" : "@tweetacoffee to @justinavery",
  "id" : 395990686933073920,
  "created_at" : "2013-10-31 19:08:31 +0000",
  "in_reply_to_screen_name" : "Tweetacoffee",
  "in_reply_to_user_id_str" : "1553972634",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395990277447368704",
  "text" : "Who wants to be tweeted a coffee?",
  "id" : 395990277447368704,
  "created_at" : "2013-10-31 19:06:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cayley",
      "screen_name" : "cayley",
      "indices" : [ 0, 7 ],
      "id_str" : "16867621",
      "id" : 16867621
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hepworthscale",
      "indices" : [ 55, 69 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395970494135955457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764312104, -122.4167729087 ]
  },
  "id_str" : "395971285102362624",
  "in_reply_to_user_id" : 16867621,
  "text" : "@cayley I took notes and plan to score an 8 next time. #hepworthscale",
  "id" : 395971285102362624,
  "in_reply_to_status_id" : 395970494135955457,
  "created_at" : "2013-10-31 17:51:25 +0000",
  "in_reply_to_screen_name" : "cayley",
  "in_reply_to_user_id_str" : "16867621",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cayley",
      "screen_name" : "cayley",
      "indices" : [ 19, 26 ],
      "id_str" : "16867621",
      "id" : 16867621
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corevalue",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764254997, -122.416761874 ]
  },
  "id_str" : "395964983894212608",
  "text" : "Getting trolled by @cayley in front of the whole company. #corevalue",
  "id" : 395964983894212608,
  "created_at" : "2013-10-31 17:26:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marisa Williams",
      "screen_name" : "marisa",
      "indices" : [ 3, 10 ],
      "id_str" : "320537046",
      "id" : 320537046
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 16, 31 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    }, {
      "name" : "Twoffice",
      "screen_name" : "twoffice",
      "indices" : [ 59, 68 ],
      "id_str" : "529817556",
      "id" : 529817556
    }, {
      "name" : "Lena",
      "screen_name" : "lenazun",
      "indices" : [ 83, 91 ],
      "id_str" : "88717547",
      "id" : 88717547
    }, {
      "name" : "Matthew Winfield",
      "screen_name" : "winfield",
      "indices" : [ 92, 101 ],
      "id_str" : "16881995",
      "id" : 16881995
    }, {
      "name" : "Carolina Janssen",
      "screen_name" : "lija",
      "indices" : [ 102, 107 ],
      "id_str" : "198684338",
      "id" : 198684338
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/marisa\/status\/395956746386440192\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/u8WOkM22Vy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX64kBHIIAE6oH-.jpg",
      "id_str" : "395956746168311809",
      "id" : 395956746168311809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX64kBHIIAE6oH-.jpg",
      "sizes" : [ {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/u8WOkM22Vy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395963301420474368",
  "text" : "RT @marisa: The @HillaryClinton pantsuit rainbow in effect @twoffice. Looking good @lenazun @winfield @lija ! http:\/\/t.co\/u8WOkM22Vy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hillary Clinton",
        "screen_name" : "HillaryClinton",
        "indices" : [ 4, 19 ],
        "id_str" : "1339835893",
        "id" : 1339835893
      }, {
        "name" : "Twoffice",
        "screen_name" : "twoffice",
        "indices" : [ 47, 56 ],
        "id_str" : "529817556",
        "id" : 529817556
      }, {
        "name" : "Lena",
        "screen_name" : "lenazun",
        "indices" : [ 71, 79 ],
        "id_str" : "88717547",
        "id" : 88717547
      }, {
        "name" : "Matthew Winfield",
        "screen_name" : "winfield",
        "indices" : [ 80, 89 ],
        "id_str" : "16881995",
        "id" : 16881995
      }, {
        "name" : "Carolina Janssen",
        "screen_name" : "lija",
        "indices" : [ 90, 95 ],
        "id_str" : "198684338",
        "id" : 198684338
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/marisa\/status\/395956746386440192\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/u8WOkM22Vy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BX64kBHIIAE6oH-.jpg",
        "id_str" : "395956746168311809",
        "id" : 395956746168311809,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX64kBHIIAE6oH-.jpg",
        "sizes" : [ {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/u8WOkM22Vy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395956746386440192",
    "text" : "The @HillaryClinton pantsuit rainbow in effect @twoffice. Looking good @lenazun @winfield @lija ! http:\/\/t.co\/u8WOkM22Vy",
    "id" : 395956746386440192,
    "created_at" : "2013-10-31 16:53:39 +0000",
    "user" : {
      "name" : "Marisa Williams",
      "screen_name" : "marisa",
      "protected" : false,
      "id_str" : "320537046",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465269458273976320\/GFxZy8Yt_normal.png",
      "id" : 320537046,
      "verified" : false
    }
  },
  "id" : 395963301420474368,
  "created_at" : "2013-10-31 17:19:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/DHlDiv2TsK",
      "expanded_url" : "http:\/\/mobile.reuters.com\/article\/idUSBRE99T02L20131030?irpc=932",
      "display_url" : "mobile.reuters.com\/article\/idUSBR\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596180236, -122.2755007776 ]
  },
  "id_str" : "395931612438745088",
  "text" : "Google's mystery barge in SF Bay is registered to By and Large LLC, a reference to co in Wall-E &amp; other Pixar movies http:\/\/t.co\/DHlDiv2TsK",
  "id" : 395931612438745088,
  "created_at" : "2013-10-31 15:13:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Fenwick",
      "screen_name" : "pjf",
      "indices" : [ 0, 4 ],
      "id_str" : "8845232",
      "id" : 8845232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395763356570619904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.795549338, -122.2702807708 ]
  },
  "id_str" : "395771824534859776",
  "in_reply_to_user_id" : 8845232,
  "text" : "@pjf No API other than an RSS feed. What would you want to have programmatic access to?",
  "id" : 395771824534859776,
  "in_reply_to_status_id" : 395763356570619904,
  "created_at" : "2013-10-31 04:38:50 +0000",
  "in_reply_to_screen_name" : "pjf",
  "in_reply_to_user_id_str" : "8845232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 23, 33 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/395756557033426944\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/QYc7MBGYW6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX4CfcICMAAEGnU.jpg",
      "id_str" : "395756556404273152",
      "id" : 395756556404273152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX4CfcICMAAEGnU.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/QYc7MBGYW6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7955665909, -122.2702613636 ]
  },
  "id_str" : "395756557033426944",
  "text" : "8:36pm Date night with @kellianne http:\/\/t.co\/QYc7MBGYW6",
  "id" : 395756557033426944,
  "created_at" : "2013-10-31 03:38:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logan Bowers",
      "screen_name" : "loganb",
      "indices" : [ 0, 7 ],
      "id_str" : "6072622",
      "id" : 6072622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395728599967223808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8233548673, -122.2685102654 ]
  },
  "id_str" : "395729169503383552",
  "in_reply_to_user_id" : 6072622,
  "text" : "@loganb how much $$$? :)",
  "id" : 395729169503383552,
  "in_reply_to_status_id" : 395728599967223808,
  "created_at" : "2013-10-31 01:49:20 +0000",
  "in_reply_to_screen_name" : "loganb",
  "in_reply_to_user_id_str" : "6072622",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/395723727310049280\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/HNkYx46Hho",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX3kohrCIAAXSIz.jpg",
      "id_str" : "395723727163236352",
      "id" : 395723727163236352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX3kohrCIAAXSIz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HNkYx46Hho"
    } ],
    "hashtags" : [ {
      "text" : "bestdadever",
      "indices" : [ 63, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7781730146, -122.4153174554 ]
  },
  "id_str" : "395723727310049280",
  "text" : "Thinking about my father today, 20 years after he passed away. #bestdadever http:\/\/t.co\/HNkYx46Hho",
  "id" : 395723727310049280,
  "created_at" : "2013-10-31 01:27:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wesley Verhoeve",
      "screen_name" : "wesleyverhoeve",
      "indices" : [ 0, 15 ],
      "id_str" : "15393128",
      "id" : 15393128
    }, {
      "name" : "Mike Singleton",
      "screen_name" : "msingleton",
      "indices" : [ 16, 27 ],
      "id_str" : "1980271",
      "id" : 1980271
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 28, 37 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395717269784772608",
  "geo" : { },
  "id_str" : "395717824175280128",
  "in_reply_to_user_id" : 15393128,
  "text" : "@wesleyverhoeve @msingleton @arainert Oh, yeah, that could very well be the case\u2026 I just learned about it today, and only in iOS context.",
  "id" : 395717824175280128,
  "in_reply_to_status_id" : 395717269784772608,
  "created_at" : "2013-10-31 01:04:16 +0000",
  "in_reply_to_screen_name" : "wesleyverhoeve",
  "in_reply_to_user_id_str" : "15393128",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Singleton",
      "screen_name" : "msingleton",
      "indices" : [ 0, 11 ],
      "id_str" : "1980271",
      "id" : 1980271
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 20, 29 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395716351957794816",
  "geo" : { },
  "id_str" : "395716995804454912",
  "in_reply_to_user_id" : 1980271,
  "text" : "@msingleton You and @arainert should just switch accounts. (Also, there's a setting to disable images in the timeline.)",
  "id" : 395716995804454912,
  "in_reply_to_status_id" : 395716351957794816,
  "created_at" : "2013-10-31 01:00:58 +0000",
  "in_reply_to_screen_name" : "msingleton",
  "in_reply_to_user_id_str" : "1980271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Scott Beale",
      "screen_name" : "ScottBeale",
      "indices" : [ 10, 21 ],
      "id_str" : "14397792",
      "id" : 14397792
    }, {
      "name" : "Laughing Squid",
      "screen_name" : "LaughingSquid",
      "indices" : [ 22, 36 ],
      "id_str" : "2172",
      "id" : 2172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395663714487001088",
  "geo" : { },
  "id_str" : "395663861379915777",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert @scottbeale @laughingsquid Yes, feel free to email me at buster@twitter.com with any details.",
  "id" : 395663861379915777,
  "in_reply_to_status_id" : 395663714487001088,
  "created_at" : "2013-10-30 21:29:50 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 10, 17 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Aza Raskin",
      "screen_name" : "aza",
      "indices" : [ 18, 22 ],
      "id_str" : "13370272",
      "id" : 13370272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395651969299120128",
  "geo" : { },
  "id_str" : "395658671390072832",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus @cwhogg @aza I only go out about once a quarter these days, but if you can make it on a Monday I can probably attend.",
  "id" : 395658671390072832,
  "in_reply_to_status_id" : 395651969299120128,
  "created_at" : "2013-10-30 21:09:12 +0000",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395610853635936256",
  "geo" : { },
  "id_str" : "395611250916225024",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april moar tweets!!! (but yeah, I get what your point.)",
  "id" : 395611250916225024,
  "in_reply_to_status_id" : 395610853635936256,
  "created_at" : "2013-10-30 18:00:46 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "precision",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395594947379732480",
  "geo" : { },
  "id_str" : "395602743043190784",
  "in_reply_to_user_id" : 2185,
  "text" : "When working on the Idea Tool for Bezos he was *adamant* about replacing the 1-5 star rating for ideas with a 1-100 star rating. #precision",
  "id" : 395602743043190784,
  "in_reply_to_status_id" : 395594947379732480,
  "created_at" : "2013-10-30 17:26:58 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aza Raskin",
      "screen_name" : "aza",
      "indices" : [ 0, 4 ],
      "id_str" : "13370272",
      "id" : 13370272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395598108962222080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7772177033, -122.4192583444 ]
  },
  "id_str" : "395598279410339840",
  "in_reply_to_user_id" : 13370272,
  "text" : "@aza Awesome. Let me know.",
  "id" : 395598279410339840,
  "in_reply_to_status_id" : 395598108962222080,
  "created_at" : "2013-10-30 17:09:14 +0000",
  "in_reply_to_screen_name" : "aza",
  "in_reply_to_user_id_str" : "13370272",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aza Raskin",
      "screen_name" : "aza",
      "indices" : [ 0, 4 ],
      "id_str" : "13370272",
      "id" : 13370272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395592279915642880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7779138042, -122.4157767837 ]
  },
  "id_str" : "395595332194537472",
  "in_reply_to_user_id" : 13370272,
  "text" : "@aza What's your definition of \"the Apple of consumer health\"? I might take you on that wager (though hoping to lose).",
  "id" : 395595332194537472,
  "in_reply_to_status_id" : 395592279915642880,
  "created_at" : "2013-10-30 16:57:31 +0000",
  "in_reply_to_screen_name" : "aza",
  "in_reply_to_user_id_str" : "13370272",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Harbick",
      "screen_name" : "aharbick",
      "indices" : [ 78, 87 ],
      "id_str" : "815996",
      "id" : 815996
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theeverythingstore",
      "indices" : [ 117, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8125444339, -122.2916117327 ]
  },
  "id_str" : "395594947379732480",
  "text" : "Excited to read that Amazon Prime was an idea submitted to the Idea Tool that @aharbick, Eric Crampton, and I built. #theeverythingstore",
  "id" : 395594947379732480,
  "created_at" : "2013-10-30 16:55:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McAllister",
      "screen_name" : "ianmcall",
      "indices" : [ 26, 35 ],
      "id_str" : "2035631",
      "id" : 2035631
    }, {
      "name" : "AmazonSmile",
      "screen_name" : "amazonsmile",
      "indices" : [ 75, 87 ],
      "id_str" : "525853846",
      "id" : 525853846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/f60dM72H8h",
      "expanded_url" : "http:\/\/smile.amazon.com",
      "display_url" : "smile.amazon.com"
    } ]
  },
  "in_reply_to_status_id_str" : "395536947038277634",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8015483404, -122.2840213963 ]
  },
  "id_str" : "395591380153548800",
  "in_reply_to_user_id" : 2035631,
  "text" : "Congrats! Looks great! RT @ianmcall: I'm pleased to announce the launch of @AmazonSmile http:\/\/t.co\/f60dM72H8h",
  "id" : 395591380153548800,
  "in_reply_to_status_id" : 395536947038277634,
  "created_at" : "2013-10-30 16:41:49 +0000",
  "in_reply_to_screen_name" : "ianmcall",
  "in_reply_to_user_id_str" : "2035631",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 0, 10 ],
      "id_str" : "1771141",
      "id" : 1771141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395582323602640896",
  "geo" : { },
  "id_str" : "395584384792666112",
  "in_reply_to_user_id" : 1771141,
  "text" : "@samantham I do wish Instagram expanded.",
  "id" : 395584384792666112,
  "in_reply_to_status_id" : 395582323602640896,
  "created_at" : "2013-10-30 16:14:01 +0000",
  "in_reply_to_screen_name" : "samantham",
  "in_reply_to_user_id_str" : "1771141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Herrman",
      "screen_name" : "jwherrman",
      "indices" : [ 117, 127 ],
      "id_str" : "27941766",
      "id" : 27941766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395576507654889472",
  "text" : "\"Taps are expensive, swiping is cheap. Clicking is a choice, like jumping; scrolling is inevitable, like falling.\u201D - @jwherrman",
  "id" : 395576507654889472,
  "created_at" : "2013-10-30 15:42:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395407179529715712",
  "geo" : { },
  "id_str" : "395407341882863618",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward Yes! Wanna come by Twitter HQ? Or thereabouts?",
  "id" : 395407341882863618,
  "in_reply_to_status_id" : 395407179529715712,
  "created_at" : "2013-10-30 04:30:31 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395403565352505344",
  "geo" : { },
  "id_str" : "395405626970341378",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward Still recovering.",
  "id" : 395405626970341378,
  "in_reply_to_status_id" : 395403565352505344,
  "created_at" : "2013-10-30 04:23:42 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395403269960253440",
  "geo" : { },
  "id_str" : "395405450364985344",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward Man I totally forgot I knew you pre-McLeod years as Bethany's brother cousin. Seems lifetimes ago.",
  "id" : 395405450364985344,
  "in_reply_to_status_id" : 395403269960253440,
  "created_at" : "2013-10-30 04:23:00 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Livia Labate",
      "screen_name" : "livlab",
      "indices" : [ 0, 7 ],
      "id_str" : "769920",
      "id" : 769920
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "youarewelcome",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395400457335488512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598056232, -122.2753846945 ]
  },
  "id_str" : "395400759782539264",
  "in_reply_to_user_id" : 769920,
  "text" : "@livlab I had nothing to do with that but am willing to accept credit when it's positive. #youarewelcome",
  "id" : 395400759782539264,
  "in_reply_to_status_id" : 395400457335488512,
  "created_at" : "2013-10-30 04:04:21 +0000",
  "in_reply_to_screen_name" : "livlab",
  "in_reply_to_user_id_str" : "769920",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395399017372209153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597963648, -122.275586268 ]
  },
  "id_str" : "395399388278702081",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward Woah where did you get that?",
  "id" : 395399388278702081,
  "in_reply_to_status_id" : 395399017372209153,
  "created_at" : "2013-10-30 03:58:54 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/395399103099592705\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/XXiMwED9A4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXy9Y2nCYAILyIa.jpg",
      "id_str" : "395399101975519234",
      "id" : 395399101975519234,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXy9Y2nCYAILyIa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XXiMwED9A4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597572412, -122.2755735385 ]
  },
  "id_str" : "395399103099592705",
  "text" : "8:36pm Pan licker http:\/\/t.co\/XXiMwED9A4",
  "id" : 395399103099592705,
  "created_at" : "2013-10-30 03:57:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/JpbQoZYrmd",
      "expanded_url" : "https:\/\/vine.co\/v\/hDgdEJTMugL",
      "display_url" : "vine.co\/v\/hDgdEJTMugL"
    } ]
  },
  "geo" : { },
  "id_str" : "395392402858725376",
  "text" : "Oldest trick in the book https:\/\/t.co\/JpbQoZYrmd",
  "id" : 395392402858725376,
  "created_at" : "2013-10-30 03:31:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aza Raskin",
      "screen_name" : "aza",
      "indices" : [ 0, 4 ],
      "id_str" : "13370272",
      "id" : 13370272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395364315810652160",
  "geo" : { },
  "id_str" : "395382107188383744",
  "in_reply_to_user_id" : 13370272,
  "text" : "@aza That was in my pitch deck 3-5 years ago. But I do hope someone cracks the code.",
  "id" : 395382107188383744,
  "in_reply_to_status_id" : 395364315810652160,
  "created_at" : "2013-10-30 02:50:14 +0000",
  "in_reply_to_screen_name" : "aza",
  "in_reply_to_user_id_str" : "13370272",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395381811544461312",
  "text" : "I wonder who has the world record for number of opinions.",
  "id" : 395381811544461312,
  "created_at" : "2013-10-30 02:49:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Balt",
      "screen_name" : "chrisbalt",
      "indices" : [ 0, 10 ],
      "id_str" : "23610657",
      "id" : 23610657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395380116039024640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596585197, -122.2754458117 ]
  },
  "id_str" : "395380622782238720",
  "in_reply_to_user_id" : 23610657,
  "text" : "@chrisbalt People don't use toggles.",
  "id" : 395380622782238720,
  "in_reply_to_status_id" : 395380116039024640,
  "created_at" : "2013-10-30 02:44:20 +0000",
  "in_reply_to_screen_name" : "chrisbalt",
  "in_reply_to_user_id_str" : "23610657",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395378044912689152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597113304, -122.2753690091 ]
  },
  "id_str" : "395378574800064512",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew I remember calling you the morning of 9\/11.",
  "id" : 395378574800064512,
  "in_reply_to_status_id" : 395378044912689152,
  "created_at" : "2013-10-30 02:36:12 +0000",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "me",
      "indices" : [ 75, 78 ]
    }, {
      "text" : "TheEverythingStore",
      "indices" : [ 79, 98 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395376958084640768",
  "geo" : { },
  "id_str" : "395377648907481088",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew Don't forget to mention great 1:1s with your favorite direct report. #me #TheEverythingStore",
  "id" : 395377648907481088,
  "in_reply_to_status_id" : 395376958084640768,
  "created_at" : "2013-10-30 02:32:31 +0000",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395375683741839360",
  "geo" : { },
  "id_str" : "395377175018221569",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew Amabot! 2 pizza teams! Fitness functions! Like reading an old yearbook.",
  "id" : 395377175018221569,
  "in_reply_to_status_id" : 395375683741839360,
  "created_at" : "2013-10-30 02:30:38 +0000",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baby Animals",
      "screen_name" : "BabyAnimalPics",
      "indices" : [ 3, 18 ],
      "id_str" : "1372975219",
      "id" : 1372975219
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BabyAnimalPics\/status\/395374262296801280\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/TQO1T8QDlQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXymy_FIQAADOFR.jpg",
      "id_str" : "395374262158376960",
      "id" : 395374262158376960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXymy_FIQAADOFR.jpg",
      "sizes" : [ {
        "h" : 589,
        "resize" : "fit",
        "w" : 589
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 589
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 589
      } ],
      "display_url" : "pic.twitter.com\/TQO1T8QDlQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395376827608203264",
  "text" : "RT @BabyAnimalPics: fennec fox exploring the desert http:\/\/t.co\/TQO1T8QDlQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BabyAnimalPics\/status\/395374262296801280\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/TQO1T8QDlQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXymy_FIQAADOFR.jpg",
        "id_str" : "395374262158376960",
        "id" : 395374262158376960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXymy_FIQAADOFR.jpg",
        "sizes" : [ {
          "h" : 589,
          "resize" : "fit",
          "w" : 589
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 589,
          "resize" : "fit",
          "w" : 589
        }, {
          "h" : 589,
          "resize" : "fit",
          "w" : 589
        } ],
        "display_url" : "pic.twitter.com\/TQO1T8QDlQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395374262296801280",
    "text" : "fennec fox exploring the desert http:\/\/t.co\/TQO1T8QDlQ",
    "id" : 395374262296801280,
    "created_at" : "2013-10-30 02:19:04 +0000",
    "user" : {
      "name" : "Baby Animals",
      "screen_name" : "BabyAnimalPics",
      "protected" : false,
      "id_str" : "1372975219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446982707994587136\/TRvk59EE_normal.jpeg",
      "id" : 1372975219,
      "verified" : false
    }
  },
  "id" : 395376827608203264,
  "created_at" : "2013-10-30 02:29:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395374546749911040",
  "geo" : { },
  "id_str" : "395376030111633408",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Valid opinion.",
  "id" : 395376030111633408,
  "in_reply_to_status_id" : 395374546749911040,
  "created_at" : "2013-10-30 02:26:06 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 3, 12 ],
      "id_str" : "761975",
      "id" : 761975
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 14, 21 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395374922656014336",
  "text" : "RT @mathowie: @buster I like everything but the follow button on the right, since I'm very careful about adding followers so I'll rarely ne\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "395373072351383552",
    "geo" : { },
    "id_str" : "395373978065186817",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster I like everything but the follow button on the right, since I'm very careful about adding followers so I'll rarely need it.",
    "id" : 395373978065186817,
    "in_reply_to_status_id" : 395373072351383552,
    "created_at" : "2013-10-30 02:17:56 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "protected" : false,
      "id_str" : "761975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463101305972465664\/xjD_-7Jl_normal.jpeg",
      "id" : 761975,
      "verified" : false
    }
  },
  "id" : 395374922656014336,
  "created_at" : "2013-10-30 02:21:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395373719872614401",
  "geo" : { },
  "id_str" : "395374828678422528",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Sad face.",
  "id" : 395374828678422528,
  "in_reply_to_status_id" : 395373719872614401,
  "created_at" : "2013-10-30 02:21:19 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 0, 8 ],
      "id_str" : "5699",
      "id" : 5699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395373505341968385",
  "geo" : { },
  "id_str" : "395374073359761408",
  "in_reply_to_user_id" : 5699,
  "text" : "@stewart I'm still catching up on public sentiment. Do people have opinions??? :)",
  "id" : 395374073359761408,
  "in_reply_to_status_id" : 395373505341968385,
  "created_at" : "2013-10-30 02:18:19 +0000",
  "in_reply_to_screen_name" : "stewart",
  "in_reply_to_user_id_str" : "5699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Livia Labate",
      "screen_name" : "livlab",
      "indices" : [ 0, 7 ],
      "id_str" : "769920",
      "id" : 769920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395373407337861120",
  "geo" : { },
  "id_str" : "395373554285305856",
  "in_reply_to_user_id" : 769920,
  "text" : "@livlab Yay!",
  "id" : 395373554285305856,
  "in_reply_to_status_id" : 395373407337861120,
  "created_at" : "2013-10-30 02:16:15 +0000",
  "in_reply_to_screen_name" : "livlab",
  "in_reply_to_user_id_str" : "769920",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Livia Labate",
      "screen_name" : "livlab",
      "indices" : [ 3, 10 ],
      "id_str" : "769920",
      "id" : 769920
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 12, 19 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395373504305983488",
  "text" : "RT @livlab: @buster LOVE the photos in the timeline.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "395373072351383552",
    "geo" : { },
    "id_str" : "395373407337861120",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster LOVE the photos in the timeline.",
    "id" : 395373407337861120,
    "in_reply_to_status_id" : 395373072351383552,
    "created_at" : "2013-10-30 02:15:40 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Livia Labate",
      "screen_name" : "livlab",
      "protected" : false,
      "id_str" : "769920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458774528856846337\/eOclLHVn_normal.jpeg",
      "id" : 769920,
      "verified" : false
    }
  },
  "id" : 395373504305983488,
  "created_at" : "2013-10-30 02:16:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395373166891368449",
  "geo" : { },
  "id_str" : "395373454288883712",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Did you get the update? Do you have any other accounts to test with?",
  "id" : 395373454288883712,
  "in_reply_to_status_id" : 395373166891368449,
  "created_at" : "2013-10-30 02:15:51 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395373072351383552",
  "text" : "What do y'all think of the photos and reply, rt, fave buttons in the timeline?",
  "id" : 395373072351383552,
  "created_at" : "2013-10-30 02:14:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 0, 8 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395305589586145282",
  "geo" : { },
  "id_str" : "395305816829329408",
  "in_reply_to_user_id" : 958581,
  "text" : "@rdicker There should be products too.",
  "id" : 395305816829329408,
  "in_reply_to_status_id" : 395305589586145282,
  "created_at" : "2013-10-29 21:47:05 +0000",
  "in_reply_to_screen_name" : "rdicker",
  "in_reply_to_user_id_str" : "958581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 0, 8 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395279019370762240",
  "geo" : { },
  "id_str" : "395305122068045824",
  "in_reply_to_user_id" : 958581,
  "text" : "@rdicker Don't make me screenshot the Amazon homepage right now.",
  "id" : 395305122068045824,
  "in_reply_to_status_id" : 395279019370762240,
  "created_at" : "2013-10-29 21:44:20 +0000",
  "in_reply_to_screen_name" : "rdicker",
  "in_reply_to_user_id_str" : "958581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 3, 6 ],
      "id_str" : "22273667",
      "id" : 22273667
    }, {
      "name" : "Sean Percival",
      "screen_name" : "Percival",
      "indices" : [ 58, 67 ],
      "id_str" : "2156951",
      "id" : 2156951
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/sm\/status\/395273793934876672\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/PGgUr4f50W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXxLa9TCIAADhkJ.jpg",
      "id_str" : "395273793804836864",
      "id" : 395273793804836864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXxLa9TCIAADhkJ.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/PGgUr4f50W"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395273979142733824",
  "text" : "RT @sm: Best use of the new Twitter update so far goes to @Percival http:\/\/t.co\/PGgUr4f50W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sean Percival",
        "screen_name" : "Percival",
        "indices" : [ 50, 59 ],
        "id_str" : "2156951",
        "id" : 2156951
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/sm\/status\/395273793934876672\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/PGgUr4f50W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXxLa9TCIAADhkJ.jpg",
        "id_str" : "395273793804836864",
        "id" : 395273793804836864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXxLa9TCIAADhkJ.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/PGgUr4f50W"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395273793934876672",
    "text" : "Best use of the new Twitter update so far goes to @Percival http:\/\/t.co\/PGgUr4f50W",
    "id" : 395273793934876672,
    "created_at" : "2013-10-29 19:39:50 +0000",
    "user" : {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "protected" : false,
      "id_str" : "22273667",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464258309130694656\/qEKpCniG_normal.jpeg",
      "id" : 22273667,
      "verified" : false
    }
  },
  "id" : 395273979142733824,
  "created_at" : "2013-10-29 19:40:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/kDaXj3G2W7",
      "expanded_url" : "https:\/\/blog.twitter.com\/2013\/picture-this-more-visual-tweets",
      "display_url" : "blog.twitter.com\/2013\/picture-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395273303553634304",
  "text" : "My fave update in a long time. Update your Twitter app to see more photos + videos + faves right in the timeline: https:\/\/t.co\/kDaXj3G2W7",
  "id" : 395273303553634304,
  "created_at" : "2013-10-29 19:37:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/395233434315927552\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/pAXzx1yOGP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXwmtt6CUAAgN-z.png",
      "id_str" : "395233434160746496",
      "id" : 395233434160746496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXwmtt6CUAAgN-z.png",
      "sizes" : [ {
        "h" : 751,
        "resize" : "fit",
        "w" : 1015
      }, {
        "h" : 444,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 751,
        "resize" : "fit",
        "w" : 1015
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/pAXzx1yOGP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395233243043487744",
  "geo" : { },
  "id_str" : "395233434315927552",
  "in_reply_to_user_id" : 761628,
  "text" : "@rickwebb No books I actually want on Kindle\u2026 maybe Creativity\u2026 but I'm all about audiobooks these days. http:\/\/t.co\/pAXzx1yOGP",
  "id" : 395233434315927552,
  "in_reply_to_status_id" : 395233243043487744,
  "created_at" : "2013-10-29 16:59:28 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 12, 21 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395231176279228416",
  "geo" : { },
  "id_str" : "395232990495653888",
  "in_reply_to_user_id" : 761628,
  "text" : "I had 6. RT @RickWebb: I was so excited about Amazon Kindle MatchBook, but out of the 500 or so books I've bought on Amazon, only 4 qualify.",
  "id" : 395232990495653888,
  "in_reply_to_status_id" : 395231176279228416,
  "created_at" : "2013-10-29 16:57:42 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 3, 15 ],
      "id_str" : "195863654",
      "id" : 195863654
    }, {
      "name" : "Arcade Fire",
      "screen_name" : "arcadefire",
      "indices" : [ 23, 34 ],
      "id_str" : "18396706",
      "id" : 18396706
    }, {
      "name" : "laura olin",
      "screen_name" : "lauraolin",
      "indices" : [ 105, 115 ],
      "id_str" : "14069365",
      "id" : 14069365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/xTsg5G1XEJ",
      "expanded_url" : "http:\/\/open.spotify.com\/album\/4E0m7AIVc2d2QZMrMNXdMZ",
      "display_url" : "open.spotify.com\/album\/4E0m7AIV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395231614357082112",
  "text" : "RT @marihuertas: Also, @arcadefire's new album, Reflektor, is now on Spotify: http:\/\/t.co\/xTsg5G1XEJ h\/t @lauraolin",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arcade Fire",
        "screen_name" : "arcadefire",
        "indices" : [ 6, 17 ],
        "id_str" : "18396706",
        "id" : 18396706
      }, {
        "name" : "laura olin",
        "screen_name" : "lauraolin",
        "indices" : [ 88, 98 ],
        "id_str" : "14069365",
        "id" : 14069365
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/xTsg5G1XEJ",
        "expanded_url" : "http:\/\/open.spotify.com\/album\/4E0m7AIVc2d2QZMrMNXdMZ",
        "display_url" : "open.spotify.com\/album\/4E0m7AIV\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "395231341135937538",
    "text" : "Also, @arcadefire's new album, Reflektor, is now on Spotify: http:\/\/t.co\/xTsg5G1XEJ h\/t @lauraolin",
    "id" : 395231341135937538,
    "created_at" : "2013-10-29 16:51:09 +0000",
    "user" : {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "protected" : false,
      "id_str" : "195863654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000420864707\/b827233ecd1cd9452628cff95555c284_normal.jpeg",
      "id" : 195863654,
      "verified" : false
    }
  },
  "id" : 395231614357082112,
  "created_at" : "2013-10-29 16:52:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asa",
      "screen_name" : "asa",
      "indices" : [ 0, 4 ],
      "id_str" : "407",
      "id" : 407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395058348124422144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596907109, -122.2754579411 ]
  },
  "id_str" : "395059605132148736",
  "in_reply_to_user_id" : 407,
  "text" : "@asa I was first.",
  "id" : 395059605132148736,
  "in_reply_to_status_id" : 395058348124422144,
  "created_at" : "2013-10-29 05:28:44 +0000",
  "in_reply_to_screen_name" : "asa",
  "in_reply_to_user_id_str" : "407",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 0, 8 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395057127510663168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596745758, -122.2754964979 ]
  },
  "id_str" : "395059473435222016",
  "in_reply_to_user_id" : 958581,
  "text" : "@rdicker Excellent!",
  "id" : 395059473435222016,
  "in_reply_to_status_id" : 395057127510663168,
  "created_at" : "2013-10-29 05:28:12 +0000",
  "in_reply_to_screen_name" : "rdicker",
  "in_reply_to_user_id_str" : "958581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 59, 67 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597095283, -122.2754949891 ]
  },
  "id_str" : "395053532895657984",
  "text" : "Enjoyed reliving P13N Amabot drama through the Bezos book. @rdicker is a picture of the valentine online anywhere?",
  "id" : 395053532895657984,
  "created_at" : "2013-10-29 05:04:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Brewer",
      "screen_name" : "jbrewer",
      "indices" : [ 3, 11 ],
      "id_str" : "12555",
      "id" : 12555
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thankful",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395047265196204032",
  "text" : "RT @jbrewer: It's really good to pause and remember how fortunate we are to get to do the work we do. #thankful",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thankful",
        "indices" : [ 89, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395037037868232704",
    "text" : "It's really good to pause and remember how fortunate we are to get to do the work we do. #thankful",
    "id" : 395037037868232704,
    "created_at" : "2013-10-29 03:59:03 +0000",
    "user" : {
      "name" : "Josh Brewer",
      "screen_name" : "jbrewer",
      "protected" : false,
      "id_str" : "12555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000470238857\/de3847a968ebe1c0cb700f4e07356dd3_normal.jpeg",
      "id" : 12555,
      "verified" : false
    }
  },
  "id" : 395047265196204032,
  "created_at" : "2013-10-29 04:39:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/395033338114629634\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/gCNhGgSHsP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXtwuljCYAEGHK1.jpg",
      "id_str" : "395033337980411905",
      "id" : 395033337980411905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXtwuljCYAEGHK1.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gCNhGgSHsP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596990509, -122.2754752916 ]
  },
  "id_str" : "395033338114629634",
  "text" : "8:36pm Reading \"if you give a pig a pancake\" to a little guy with a 102.5 fever http:\/\/t.co\/gCNhGgSHsP",
  "id" : 395033338114629634,
  "created_at" : "2013-10-29 03:44:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7791933806, -122.414279838 ]
  },
  "id_str" : "394996651892297728",
  "text" : "I have nothing to add at the moment.",
  "id" : 394996651892297728,
  "created_at" : "2013-10-29 01:18:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "One Tweet Tony",
      "screen_name" : "OneTweetTony",
      "indices" : [ 3, 16 ],
      "id_str" : "607500595",
      "id" : 607500595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394937164925898752",
  "text" : "RT @OneTweetTony: Nailed it! That's a wrap!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "212995188929474560",
    "text" : "Nailed it! That's a wrap!",
    "id" : 212995188929474560,
    "created_at" : "2012-06-13 19:49:44 +0000",
    "user" : {
      "name" : "One Tweet Tony",
      "screen_name" : "OneTweetTony",
      "protected" : false,
      "id_str" : "607500595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2305412894\/522454_normal.jpeg",
      "id" : 607500595,
      "verified" : false
    }
  },
  "id" : 394937164925898752,
  "created_at" : "2013-10-28 21:22:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Support",
      "screen_name" : "Support",
      "indices" : [ 15, 23 ],
      "id_str" : "17874544",
      "id" : 17874544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/FtR27QabCe",
      "expanded_url" : "http:\/\/twitter.com",
      "display_url" : "twitter.com"
    } ]
  },
  "in_reply_to_status_id_str" : "394900174142595073",
  "geo" : { },
  "id_str" : "394923368584994816",
  "in_reply_to_user_id" : 17874544,
  "text" : "Lookee here RT @Support: Get to your DMs faster: We've moved the DM button to the top navigation bar on http:\/\/t.co\/FtR27QabCe",
  "id" : 394923368584994816,
  "in_reply_to_status_id" : 394900174142595073,
  "created_at" : "2013-10-28 20:27:23 +0000",
  "in_reply_to_screen_name" : "Support",
  "in_reply_to_user_id_str" : "17874544",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logan Bowers",
      "screen_name" : "loganb",
      "indices" : [ 0, 7 ],
      "id_str" : "6072622",
      "id" : 6072622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394832804371906560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598057945, -122.2754721903 ]
  },
  "id_str" : "394834952082059264",
  "in_reply_to_user_id" : 6072622,
  "text" : "@loganb It must be exhausting to be in a constant arms race with exponentially rising costs.",
  "id" : 394834952082059264,
  "in_reply_to_status_id" : 394832804371906560,
  "created_at" : "2013-10-28 14:36:02 +0000",
  "in_reply_to_screen_name" : "loganb",
  "in_reply_to_user_id_str" : "6072622",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394630841101332480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596685408, -122.275373703 ]
  },
  "id_str" : "394834524917354496",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach I think it'll be scarier when algorithms start making long term \"buy and hold\" trades with lots of confidence.",
  "id" : 394834524917354496,
  "in_reply_to_status_id" : 394630841101332480,
  "created_at" : "2013-10-28 14:34:21 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logan Bowers",
      "screen_name" : "loganb",
      "indices" : [ 0, 7 ],
      "id_str" : "6072622",
      "id" : 6072622
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 8, 15 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394831608223510528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597067204, -122.2754609586 ]
  },
  "id_str" : "394832418206523393",
  "in_reply_to_user_id" : 6072622,
  "text" : "@loganb @isaach Is there a proposal of that that I could read somewhere?",
  "id" : 394832418206523393,
  "in_reply_to_status_id" : 394831608223510528,
  "created_at" : "2013-10-28 14:25:58 +0000",
  "in_reply_to_screen_name" : "loganb",
  "in_reply_to_user_id_str" : "6072622",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/WjhCTUYVzL",
      "expanded_url" : "http:\/\/queue.acm.org\/detail.cfm?id=2536492",
      "display_url" : "queue.acm.org\/detail.cfm?id=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394826448361373696",
  "text" : "RT @isaach: high-frequency trading and the move \"from milliseconds to microseconds to nanoseconds\": \"Barbarians at the Gateways\" http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/WjhCTUYVzL",
        "expanded_url" : "http:\/\/queue.acm.org\/detail.cfm?id=2536492",
        "display_url" : "queue.acm.org\/detail.cfm?id=\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7450416877, -122.4061887251 ]
    },
    "id_str" : "394630841101332480",
    "text" : "high-frequency trading and the move \"from milliseconds to microseconds to nanoseconds\": \"Barbarians at the Gateways\" http:\/\/t.co\/WjhCTUYVzL",
    "id" : 394630841101332480,
    "created_at" : "2013-10-28 01:04:59 +0000",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430605387117494272\/lmplHwca_normal.png",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 394826448361373696,
  "created_at" : "2013-10-28 14:02:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelton Lynn",
      "screen_name" : "keltonlynn",
      "indices" : [ 0, 11 ],
      "id_str" : "27674040",
      "id" : 27674040
    }, {
      "name" : "Annie Kadavy",
      "screen_name" : "AnnieKadavy",
      "indices" : [ 12, 24 ],
      "id_str" : "2469858480",
      "id" : 2469858480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394708710292877312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597381525, -122.2754988448 ]
  },
  "id_str" : "394709222069252096",
  "in_reply_to_user_id" : 27674040,
  "text" : "@keltonlynn @anniekadavy Agreed. You know it's bad when the German word is shorter: abk\u00FCrzung.",
  "id" : 394709222069252096,
  "in_reply_to_status_id" : 394708710292877312,
  "created_at" : "2013-10-28 06:16:26 +0000",
  "in_reply_to_screen_name" : "keltonlynn",
  "in_reply_to_user_id_str" : "27674040",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelton Lynn",
      "screen_name" : "keltonlynn",
      "indices" : [ 0, 11 ],
      "id_str" : "27674040",
      "id" : 27674040
    }, {
      "name" : "Annie Kadavy",
      "screen_name" : "AnnieKadavy",
      "indices" : [ 12, 24 ],
      "id_str" : "2469858480",
      "id" : 2469858480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394701140975054848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596864001, -122.2755604011 ]
  },
  "id_str" : "394708133987110913",
  "in_reply_to_user_id" : 27674040,
  "text" : "@keltonlynn @anniekadavy Abbr, right?",
  "id" : 394708133987110913,
  "in_reply_to_status_id" : 394701140975054848,
  "created_at" : "2013-10-28 06:12:07 +0000",
  "in_reply_to_screen_name" : "keltonlynn",
  "in_reply_to_user_id_str" : "27674040",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 0, 7 ],
      "id_str" : "1530531",
      "id" : 1530531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394677219747823616",
  "geo" : { },
  "id_str" : "394678841521610752",
  "in_reply_to_user_id" : 1530531,
  "text" : "@miradu Sounds like a great wall for a ten thousand startups to throw themselves against.",
  "id" : 394678841521610752,
  "in_reply_to_status_id" : 394677219747823616,
  "created_at" : "2013-10-28 04:15:43 +0000",
  "in_reply_to_screen_name" : "miradu",
  "in_reply_to_user_id_str" : "1530531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 0, 7 ],
      "id_str" : "1530531",
      "id" : 1530531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394675158545223680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597623497, -122.2754912954 ]
  },
  "id_str" : "394675848797630464",
  "in_reply_to_user_id" : 1530531,
  "text" : "@miradu I can usually tell by the meeting names (1:1s, standups) but yeah that's not an exact science. People should use \"optional\" more.",
  "id" : 394675848797630464,
  "in_reply_to_status_id" : 394675158545223680,
  "created_at" : "2013-10-28 04:03:49 +0000",
  "in_reply_to_screen_name" : "miradu",
  "in_reply_to_user_id_str" : "1530531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 0, 7 ],
      "id_str" : "1530531",
      "id" : 1530531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394673062898974720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597293691, -122.2755291566 ]
  },
  "id_str" : "394674967536599040",
  "in_reply_to_user_id" : 1530531,
  "text" : "@miradu Using Google Calendar's \"find times\" tab actually works way better than anything I've ever used... what part do you wish was easier?",
  "id" : 394674967536599040,
  "in_reply_to_status_id" : 394673062898974720,
  "created_at" : "2013-10-28 04:00:19 +0000",
  "in_reply_to_screen_name" : "miradu",
  "in_reply_to_user_id_str" : "1530531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/wsTDiaYfzT",
      "expanded_url" : "http:\/\/flic.kr\/p\/h3o3mp",
      "display_url" : "flic.kr\/p\/h3o3mp"
    } ]
  },
  "geo" : { },
  "id_str" : "394670585131065344",
  "text" : "8:36pm Laundry + movie night. http:\/\/t.co\/wsTDiaYfzT",
  "id" : 394670585131065344,
  "created_at" : "2013-10-28 03:42:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "data",
      "indices" : [ 124, 129 ]
    }, {
      "text" : "nodata",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394664630645030913",
  "text" : "To know that we can measure what we can measure, and that we cannot measure what we cannot measure, that is true knowledge. #data #nodata",
  "id" : 394664630645030913,
  "created_at" : "2013-10-28 03:19:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 3, 17 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394662447740506112",
  "text" : "RT @marcprecipice: \"Later we realized the 3 hardest problems in computer science were actually imposter syndrome, checking your privilege, \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "394625118564909057",
    "text" : "\"Later we realized the 3 hardest problems in computer science were actually imposter syndrome, checking your privilege, and Dunning\u2013Kruger.\"",
    "id" : 394625118564909057,
    "created_at" : "2013-10-28 00:42:14 +0000",
    "user" : {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "protected" : false,
      "id_str" : "226976689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2321403275\/b546axjksj5f7z194wjm_normal.jpeg",
      "id" : 226976689,
      "verified" : false
    }
  },
  "id" : 394662447740506112,
  "created_at" : "2013-10-28 03:10:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394655896644485120",
  "geo" : { },
  "id_str" : "394657258769899520",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit I\u2019ve somehow avoided both the book and movie version of The Road. Maybe I\u2019ll give it a try.",
  "id" : 394657258769899520,
  "in_reply_to_status_id" : 394655896644485120,
  "created_at" : "2013-10-28 02:49:57 +0000",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 0, 14 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394649129852227584",
  "geo" : { },
  "id_str" : "394656620036096000",
  "in_reply_to_user_id" : 226976689,
  "text" : "@marcprecipice I haven\u2019t seen that one. Tried to watch that today but Nemo won out in the vote.",
  "id" : 394656620036096000,
  "in_reply_to_status_id" : 394649129852227584,
  "created_at" : "2013-10-28 02:47:25 +0000",
  "in_reply_to_screen_name" : "marcprecipice",
  "in_reply_to_user_id_str" : "226976689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "coder school dropout",
      "screen_name" : "meat",
      "indices" : [ 0, 5 ],
      "id_str" : "21006515",
      "id" : 21006515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394648663474970624",
  "geo" : { },
  "id_str" : "394656438359830529",
  "in_reply_to_user_id" : 21006515,
  "text" : "@meat fail.",
  "id" : 394656438359830529,
  "in_reply_to_status_id" : 394648663474970624,
  "created_at" : "2013-10-28 02:46:41 +0000",
  "in_reply_to_screen_name" : "meat",
  "in_reply_to_user_id_str" : "21006515",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597368952, -122.275475124 ]
  },
  "id_str" : "394648319604969473",
  "text" : "Finding Nemo is the only movie I can recall at the moment where a father's protective love for his child is central to the story. Others?",
  "id" : 394648319604969473,
  "created_at" : "2013-10-28 02:14:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stef Lewandowski",
      "screen_name" : "stef",
      "indices" : [ 0, 5 ],
      "id_str" : "853471",
      "id" : 853471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394598962205704192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597201733, -122.2754170374 ]
  },
  "id_str" : "394599223183679488",
  "in_reply_to_user_id" : 853471,
  "text" : "@stef If you haven't read it yet, definitely do!",
  "id" : 394599223183679488,
  "in_reply_to_status_id" : 394598962205704192,
  "created_at" : "2013-10-27 22:59:20 +0000",
  "in_reply_to_screen_name" : "stef",
  "in_reply_to_user_id_str" : "853471",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stef Lewandowski",
      "screen_name" : "stef",
      "indices" : [ 0, 5 ],
      "id_str" : "853471",
      "id" : 853471
    }, {
      "name" : "Nassim N. Taleb",
      "screen_name" : "nntaleb",
      "indices" : [ 87, 95 ],
      "id_str" : "381289719",
      "id" : 381289719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394597640446304256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597737522, -122.2755503956 ]
  },
  "id_str" : "394598559493791744",
  "in_reply_to_user_id" : 853471,
  "text" : "@stef What's unusual about it? I interpreted it as optionality in the sense defined in @nntaleb's Antifragile.",
  "id" : 394598559493791744,
  "in_reply_to_status_id" : 394597640446304256,
  "created_at" : "2013-10-27 22:56:42 +0000",
  "in_reply_to_screen_name" : "stef",
  "in_reply_to_user_id_str" : "853471",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 23, 34 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/394566766984048640\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/X3jACwcZ9o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXnIYkjCYAEkMK7.jpg",
      "id_str" : "394566766824677377",
      "id" : 394566766824677377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXnIYkjCYAEkMK7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 912,
        "resize" : "fit",
        "w" : 912
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 912,
        "resize" : "fit",
        "w" : 912
      } ],
      "display_url" : "pic.twitter.com\/X3jACwcZ9o"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597415472, -122.2755244934 ]
  },
  "id_str" : "394566766984048640",
  "text" : "Low energy Sunday with @nikobenson http:\/\/t.co\/X3jACwcZ9o",
  "id" : 394566766984048640,
  "created_at" : "2013-10-27 20:50:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Shafrir",
      "screen_name" : "mcs",
      "indices" : [ 0, 4 ],
      "id_str" : "4612141",
      "id" : 4612141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394302740618178560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8614700213, -122.2808615026 ]
  },
  "id_str" : "394539566108901376",
  "in_reply_to_user_id" : 4612141,
  "text" : "@mcs Read the article (end especially). He's a bit of an eccentric. In a good way.",
  "id" : 394539566108901376,
  "in_reply_to_status_id" : 394302740618178560,
  "created_at" : "2013-10-27 19:02:17 +0000",
  "in_reply_to_screen_name" : "mcs",
  "in_reply_to_user_id_str" : "4612141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/youtube-capture\/id576941441?mt=8&uo=4\" rel=\"nofollow\"\u003EYouTube Capture on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/ES6Gj6LnVM",
      "expanded_url" : "http:\/\/youtu.be\/3DnxLHIou6I?ac",
      "display_url" : "youtu.be\/3DnxLHIou6I?ac"
    } ]
  },
  "geo" : { },
  "id_str" : "394517363111886848",
  "text" : "Railroad song remix http:\/\/t.co\/ES6Gj6LnVM",
  "id" : 394517363111886848,
  "created_at" : "2013-10-27 17:34:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Feng",
      "screen_name" : "efeng",
      "indices" : [ 3, 9 ],
      "id_str" : "12439842",
      "id" : 12439842
    }, {
      "name" : "Eugene Wei",
      "screen_name" : "eugenewei",
      "indices" : [ 45, 55 ],
      "id_str" : "1547221",
      "id" : 1547221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/pTqTiyixv1",
      "expanded_url" : "http:\/\/www.eugenewei.com\/blog\/2013\/10\/25\/amazon-and-the-profitless-business-model-narrative",
      "display_url" : "eugenewei.com\/blog\/2013\/10\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394338737892511744",
  "text" : "RT @efeng: Two words: dropping knowledge. RT @eugenewei Amazon and the \"profitless business model fallacy http:\/\/t.co\/pTqTiyixv1",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eugene Wei",
        "screen_name" : "eugenewei",
        "indices" : [ 34, 44 ],
        "id_str" : "1547221",
        "id" : 1547221
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/pTqTiyixv1",
        "expanded_url" : "http:\/\/www.eugenewei.com\/blog\/2013\/10\/25\/amazon-and-the-profitless-business-model-narrative",
        "display_url" : "eugenewei.com\/blog\/2013\/10\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "394329641575395329",
    "text" : "Two words: dropping knowledge. RT @eugenewei Amazon and the \"profitless business model fallacy http:\/\/t.co\/pTqTiyixv1",
    "id" : 394329641575395329,
    "created_at" : "2013-10-27 05:08:07 +0000",
    "user" : {
      "name" : "Eric Feng",
      "screen_name" : "efeng",
      "protected" : false,
      "id_str" : "12439842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1415802190\/profile_normal.jpg",
      "id" : 12439842,
      "verified" : false
    }
  },
  "id" : 394338737892511744,
  "created_at" : "2013-10-27 05:44:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394310965702840320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859636941, -122.2754654848 ]
  },
  "id_str" : "394311312403988483",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april I had to write a script. I'm sure a website does it somewhere too.",
  "id" : 394311312403988483,
  "in_reply_to_status_id" : 394310965702840320,
  "created_at" : "2013-10-27 03:55:17 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/4ChQnzL9Nl",
      "expanded_url" : "http:\/\/flic.kr\/p\/h1j2Fh",
      "display_url" : "flic.kr\/p\/h1j2Fh"
    } ]
  },
  "geo" : { },
  "id_str" : "394310479767928832",
  "text" : "8:36pm Sick = kale chips, movies, blankets http:\/\/t.co\/4ChQnzL9Nl",
  "id" : 394310479767928832,
  "created_at" : "2013-10-27 03:51:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelsey Falter",
      "screen_name" : "kfalter",
      "indices" : [ 0, 8 ],
      "id_str" : "253578873",
      "id" : 253578873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394308325200117760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8599325708, -122.2755303608 ]
  },
  "id_str" : "394309244167524353",
  "in_reply_to_user_id" : 253578873,
  "text" : "@kfalter At the moment it's Nassim Taleb more for topics than style. Haven't read much fiction lately but Nabokov is still a fave. You?",
  "id" : 394309244167524353,
  "in_reply_to_status_id" : 394308325200117760,
  "created_at" : "2013-10-27 03:47:04 +0000",
  "in_reply_to_screen_name" : "kfalter",
  "in_reply_to_user_id_str" : "253578873",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelsey Falter",
      "screen_name" : "kfalter",
      "indices" : [ 0, 8 ],
      "id_str" : "253578873",
      "id" : 253578873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394302371251355648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596875677, -122.2754868587 ]
  },
  "id_str" : "394307547105992704",
  "in_reply_to_user_id" : 253578873,
  "text" : "@kfalter Interesting! I know them primarily through other routes but it's a cool pattern to pick out.",
  "id" : 394307547105992704,
  "in_reply_to_status_id" : 394302371251355648,
  "created_at" : "2013-10-27 03:40:19 +0000",
  "in_reply_to_screen_name" : "kfalter",
  "in_reply_to_user_id_str" : "253578873",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelsey Falter",
      "screen_name" : "kfalter",
      "indices" : [ 0, 8 ],
      "id_str" : "253578873",
      "id" : 253578873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394301440963145728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596591531, -122.2754855176 ]
  },
  "id_str" : "394302076060053504",
  "in_reply_to_user_id" : 253578873,
  "text" : "@kfalter I do know them, though interact with a few more on the internet. And yes to reading\/lit too... majored in it back in the day.",
  "id" : 394302076060053504,
  "in_reply_to_status_id" : 394301440963145728,
  "created_at" : "2013-10-27 03:18:35 +0000",
  "in_reply_to_screen_name" : "kfalter",
  "in_reply_to_user_id_str" : "253578873",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 8, 19 ],
      "id_str" : "784078",
      "id" : 784078
    }, {
      "name" : "Marie Claire",
      "screen_name" : "marieclaire",
      "indices" : [ 20, 32 ],
      "id_str" : "19074134",
      "id" : 19074134
    }, {
      "name" : "Katie Davies",
      "screen_name" : "dothisdont",
      "indices" : [ 33, 44 ],
      "id_str" : "25799452",
      "id" : 25799452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394301109054877696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596897889, -122.2755332944 ]
  },
  "id_str" : "394301280224440320",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon @alicetiara @marieclaire @dothisdont Cool! Is there a link available?",
  "id" : 394301280224440320,
  "in_reply_to_status_id" : 394301109054877696,
  "created_at" : "2013-10-27 03:15:25 +0000",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394299015568711680",
  "geo" : { },
  "id_str" : "394299178739695616",
  "in_reply_to_user_id" : 2185,
  "text" : "\u201COne can report steady progress, all the way to the top of the tree.\u201D",
  "id" : 394299178739695616,
  "in_reply_to_status_id" : 394299015568711680,
  "created_at" : "2013-10-27 03:07:04 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/ghWnxP8z3g",
      "expanded_url" : "http:\/\/www.theatlantic.com\/magazine\/archive\/2013\/11\/the-man-who-would-teach-machines-to-think\/309529\/",
      "display_url" : "theatlantic.com\/magazine\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394299015568711680",
  "text" : "I love Douglas Hofstadter. \"AI has become too much like the man who tries to get to the moon by climbing a tree\" http:\/\/t.co\/ghWnxP8z3g",
  "id" : 394299015568711680,
  "created_at" : "2013-10-27 03:06:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394295070469275648",
  "geo" : { },
  "id_str" : "394297549462335488",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne The bike ride. Breakfast. And then there was my nap. My nap was awesome. Being sick sucks.",
  "id" : 394297549462335488,
  "in_reply_to_status_id" : 394295070469275648,
  "created_at" : "2013-10-27 03:00:36 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394293563686539264",
  "geo" : { },
  "id_str" : "394294142160732161",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne If you can get me to reply 12 more times then you'll take first place.",
  "id" : 394294142160732161,
  "in_reply_to_status_id" : 394293563686539264,
  "created_at" : "2013-10-27 02:47:03 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394293271825895424",
  "geo" : { },
  "id_str" : "394293812102574080",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall I did it for the last 3200 tweets, so about 1\/5 of my total tweeting history.",
  "id" : 394293812102574080,
  "in_reply_to_status_id" : 394293271825895424,
  "created_at" : "2013-10-27 02:45:45 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394291001965047809",
  "geo" : { },
  "id_str" : "394291254730563584",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Barely made the cut. I\u2019ve only tweeted you 26 times. 27 now. Moving on up!",
  "id" : 394291254730563584,
  "in_reply_to_status_id" : 394291001965047809,
  "created_at" : "2013-10-27 02:35:35 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 38, 47 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 48, 58 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 59, 69 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 70, 79 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 80, 90 ],
      "id_str" : "7943892",
      "id" : 7943892
    }, {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 91, 101 ],
      "id_str" : "16644937",
      "id" : 16644937
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 102, 111 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 112, 122 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 123, 136 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394290907710623744",
  "text" : "Top 10 people I talk with on Twitter: @rickwebb @kellianne @avantgame @eramirez @ingopixel @the_april @anildash @tomcoates @offbeatariel #ff",
  "id" : 394290907710623744,
  "created_at" : "2013-10-27 02:34:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596273857, -122.2754602042 ]
  },
  "id_str" : "394160611526840320",
  "text" : "Spending a sunny Fall morning teaching my son how to ride a real bike turns out to be just as rewarding as my parenting manual promised.",
  "id" : 394160611526840320,
  "created_at" : "2013-10-26 17:56:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Moore",
      "screen_name" : "matthewcmoore",
      "indices" : [ 0, 14 ],
      "id_str" : "17996149",
      "id" : 17996149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394140619544592384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8622130973, -122.2775378054 ]
  },
  "id_str" : "394149306673815553",
  "in_reply_to_user_id" : 17996149,
  "text" : "@matthewcmoore Cool, glad you like it! Extra stats get unlocked after a couple days too...",
  "id" : 394149306673815553,
  "in_reply_to_status_id" : 394140619544592384,
  "created_at" : "2013-10-26 17:11:32 +0000",
  "in_reply_to_screen_name" : "matthewcmoore",
  "in_reply_to_user_id_str" : "17996149",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/XIp7rRGuZf",
      "expanded_url" : "https:\/\/vine.co\/v\/hpUKiKHXIli",
      "display_url" : "vine.co\/v\/hpUKiKHXIli"
    } ]
  },
  "geo" : { },
  "id_str" : "394148857481015296",
  "text" : "Niko's new bike in action https:\/\/t.co\/XIp7rRGuZf",
  "id" : 394148857481015296,
  "created_at" : "2013-10-26 17:09:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 3, 18 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/9usHslFTzH",
      "expanded_url" : "http:\/\/kottke.org\/13\/10\/amazing-robot-gymnast",
      "display_url" : "kottke.org\/13\/10\/amazing-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394141390415753216",
  "text" : "RT @mikeindustries: \"I wasn't expecting a whole lot from this video of a robotic gymnast doing a routine on the high bar...\" http:\/\/t.co\/9u\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/9usHslFTzH",
        "expanded_url" : "http:\/\/kottke.org\/13\/10\/amazing-robot-gymnast",
        "display_url" : "kottke.org\/13\/10\/amazing-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "394138893164888064",
    "text" : "\"I wasn't expecting a whole lot from this video of a robotic gymnast doing a routine on the high bar...\" http:\/\/t.co\/9usHslFTzH",
    "id" : 394138893164888064,
    "created_at" : "2013-10-26 16:30:09 +0000",
    "user" : {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "protected" : false,
      "id_str" : "74523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430955581830995968\/sSqK3_b9_normal.jpeg",
      "id" : 74523,
      "verified" : false
    }
  },
  "id" : 394141390415753216,
  "created_at" : "2013-10-26 16:40:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theriotisover",
      "screen_name" : "theriotisover",
      "indices" : [ 16, 30 ],
      "id_str" : "47740113",
      "id" : 47740113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/Osrki24g8p",
      "expanded_url" : "https:\/\/twitter.com\/_HillValley\/the-hill-valley-project",
      "display_url" : "twitter.com\/_HillValley\/th\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "393976041368088576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596778028, -122.2754529958 ]
  },
  "id_str" : "394116258431397888",
  "in_reply_to_user_id" : 47740113,
  "text" : "This is good RT @theriotisover: holy shit you guys someone made 49 twitter accts &amp; is reenacting Back to the Future https:\/\/t.co\/Osrki24g8p",
  "id" : 394116258431397888,
  "in_reply_to_status_id" : 393976041368088576,
  "created_at" : "2013-10-26 15:00:13 +0000",
  "in_reply_to_screen_name" : "theriotisover",
  "in_reply_to_user_id_str" : "47740113",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393967852878712832",
  "geo" : { },
  "id_str" : "393985226004647936",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm Pyramids.",
  "id" : 393985226004647936,
  "in_reply_to_status_id" : 393967852878712832,
  "created_at" : "2013-10-26 06:19:32 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/393979420437803008\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/Z6RaW4uLGi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXeyMgNCcAATqGA.jpg",
      "id_str" : "393979420291002368",
      "id" : 393979420291002368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXeyMgNCcAATqGA.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/Z6RaW4uLGi"
    } ],
    "hashtags" : [ {
      "text" : "california",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "twitterhq",
      "indices" : [ 12, 22 ]
    }, {
      "text" : "light",
      "indices" : [ 23, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596469574, -122.2753757146 ]
  },
  "id_str" : "393979420437803008",
  "text" : "#california #twitterhq #light http:\/\/t.co\/Z6RaW4uLGi",
  "id" : 393979420437803008,
  "created_at" : "2013-10-26 05:56:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/w3KZdZ51bl",
      "expanded_url" : "http:\/\/www.geekwire.com\/2012\/day-rest-life\/",
      "display_url" : "geekwire.com\/2012\/day-rest-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "393977424553070592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596810717, -122.2754749564 ]
  },
  "id_str" : "393978671855177728",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm I've just been doing it a while: http:\/\/t.co\/w3KZdZ51bl",
  "id" : 393978671855177728,
  "in_reply_to_status_id" : 393977424553070592,
  "created_at" : "2013-10-26 05:53:29 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/34bDTXdvHD",
      "expanded_url" : "http:\/\/flic.kr\/p\/gYKtUP",
      "display_url" : "flic.kr\/p\/gYKtUP"
    } ]
  },
  "geo" : { },
  "id_str" : "393975395202379776",
  "text" : "8:36pm Was putting Thomas to bed after an exciting day. http:\/\/t.co\/34bDTXdvHD",
  "id" : 393975395202379776,
  "created_at" : "2013-10-26 05:40:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/P9l6AcbNTs",
      "expanded_url" : "https:\/\/vine.co\/v\/hpdeavlzemh",
      "display_url" : "vine.co\/v\/hpdeavlzemh"
    } ]
  },
  "geo" : { },
  "id_str" : "393887565797142528",
  "text" : "Shy Thomas https:\/\/t.co\/P9l6AcbNTs",
  "id" : 393887565797142528,
  "created_at" : "2013-10-25 23:51:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/YAfyrvlel2",
      "expanded_url" : "https:\/\/vine.co\/v\/hpdBgiMVHJD",
      "display_url" : "vine.co\/v\/hpdBgiMVHJD"
    } ]
  },
  "geo" : { },
  "id_str" : "393877680661463040",
  "text" : "Niko surveys the Twitter Halloween party (come to the Commons!) https:\/\/t.co\/YAfyrvlel2",
  "id" : 393877680661463040,
  "created_at" : "2013-10-25 23:12:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Inman",
      "screen_name" : "Oatmeal",
      "indices" : [ 43, 51 ],
      "id_str" : "4519121",
      "id" : 4519121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/e4hZri8vgF",
      "expanded_url" : "http:\/\/bit.ly\/1hgbsjI",
      "display_url" : "bit.ly\/1hgbsjI"
    } ]
  },
  "geo" : { },
  "id_str" : "393815886660108289",
  "text" : "Cat vs Internet http:\/\/t.co\/e4hZri8vgF \/by @Oatmeal",
  "id" : 393815886660108289,
  "created_at" : "2013-10-25 19:06:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 33, 41 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/PCw0fDAXpj",
      "expanded_url" : "http:\/\/www.humansofnewyork.com\/post\/64990304397\/if-any-of-you-drove-by-the-brooklyn-navy-yards-at",
      "display_url" : "humansofnewyork.com\/post\/649903043\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393758429505802241",
  "text" : "Humans of New York reaches #1 on @nytimes best seller list. Amazing. http:\/\/t.co\/PCw0fDAXpj",
  "id" : 393758429505802241,
  "created_at" : "2013-10-25 15:18:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Wenzel",
      "screen_name" : "georgewenzel",
      "indices" : [ 13, 26 ],
      "id_str" : "14753638",
      "id" : 14753638
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 82, 89 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/georgewenzel\/status\/393703201519570944\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/xabZyC9a7h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXa2-c2CMAEA66H.jpg",
      "id_str" : "393703201452470273",
      "id" : 393703201452470273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXa2-c2CMAEA66H.jpg",
      "sizes" : [ {
        "h" : 208,
        "resize" : "fit",
        "w" : 828
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 151,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 208,
        "resize" : "fit",
        "w" : 828
      }, {
        "h" : 85,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xabZyC9a7h"
    } ],
    "hashtags" : [ {
      "text" : "750words",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/abOy5lGgdR",
      "expanded_url" : "http:\/\/www.750words.com",
      "display_url" : "750words.com"
    } ]
  },
  "in_reply_to_status_id_str" : "393703201519570944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597146325, -122.275605508 ]
  },
  "id_str" : "393750632978325504",
  "in_reply_to_user_id" : 14753638,
  "text" : "Congrats! RT @georgewenzel: I made it to 1000 days in a row! Thanks #750words and @buster! http:\/\/t.co\/abOy5lGgdR http:\/\/t.co\/xabZyC9a7h",
  "id" : 393750632978325504,
  "in_reply_to_status_id" : 393703201519570944,
  "created_at" : "2013-10-25 14:47:21 +0000",
  "in_reply_to_screen_name" : "georgewenzel",
  "in_reply_to_user_id_str" : "14753638",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lazyweb",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393612374952783873",
  "geo" : { },
  "id_str" : "393613621491548161",
  "in_reply_to_user_id" : 2185,
  "text" : "#lazyweb",
  "id" : 393613621491548161,
  "in_reply_to_status_id" : 393612374952783873,
  "created_at" : "2013-10-25 05:42:55 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393612374952783873",
  "text" : "Why are socks so expensive? Someone please disrupt the sock industry.",
  "id" : 393612374952783873,
  "created_at" : "2013-10-25 05:37:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 0, 4 ],
      "id_str" : "12720772",
      "id" : 12720772
    }, {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 5, 20 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393602794088706048",
  "geo" : { },
  "id_str" : "393610250395201536",
  "in_reply_to_user_id" : 12720772,
  "text" : "@gwb @mikeindustries I'm all about the rantifesto. Which is pretty much what Medium was built for.",
  "id" : 393610250395201536,
  "in_reply_to_status_id" : 393602794088706048,
  "created_at" : "2013-10-25 05:29:31 +0000",
  "in_reply_to_screen_name" : "gwb",
  "in_reply_to_user_id_str" : "12720772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/bN4njvxBLE",
      "expanded_url" : "http:\/\/instagram.com\/p\/f4CTO6OFQ8\/",
      "display_url" : "instagram.com\/p\/f4CTO6OFQ8\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859704, -122.275465 ]
  },
  "id_str" : "393605971815047168",
  "text" : "It's been this kind of a day http:\/\/t.co\/bN4njvxBLE",
  "id" : 393605971815047168,
  "created_at" : "2013-10-25 05:12:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393580811535937538",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597052954, -122.2753701826 ]
  },
  "id_str" : "393582866975576064",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries And where do you plan on posting said rant?",
  "id" : 393582866975576064,
  "in_reply_to_status_id" : 393580811535937538,
  "created_at" : "2013-10-25 03:40:42 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/g6sJQHn9BU",
      "expanded_url" : "http:\/\/flic.kr\/p\/gX7pCJ",
      "display_url" : "flic.kr\/p\/gX7pCJ"
    } ]
  },
  "geo" : { },
  "id_str" : "393582595487051776",
  "text" : "8:36pm Eating chocolate chips for dessert http:\/\/t.co\/g6sJQHn9BU",
  "id" : 393582595487051776,
  "created_at" : "2013-10-25 03:39:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 3, 17 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393563159253876736",
  "text" : "RT @buster_ebooks: It's mostly silly",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/busterbenson.com\" rel=\"nofollow\"\u003EBuster eBooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393534659419979776",
    "text" : "It's mostly silly",
    "id" : 393534659419979776,
    "created_at" : "2013-10-25 00:29:08 +0000",
    "user" : {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "protected" : false,
      "id_str" : "1901375096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000503050571\/228ccabfeeb4e55bd8e172595babe02e_normal.jpeg",
      "id" : 1901375096,
      "verified" : false
    }
  },
  "id" : 393563159253876736,
  "created_at" : "2013-10-25 02:22:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 0, 7 ],
      "id_str" : "23640904",
      "id" : 23640904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/yw7j0vm61s",
      "expanded_url" : "http:\/\/bit.ly\/1bk0x3I",
      "display_url" : "bit.ly\/1bk0x3I"
    } ]
  },
  "in_reply_to_status_id_str" : "393522213543895040",
  "geo" : { },
  "id_str" : "393533706935095297",
  "in_reply_to_user_id" : 23640904,
  "text" : "@emoore Awesome. This post came out of it: http:\/\/t.co\/yw7j0vm61s but I'll find you sometime soon to discuss more...",
  "id" : 393533706935095297,
  "in_reply_to_status_id" : 393522213543895040,
  "created_at" : "2013-10-25 00:25:21 +0000",
  "in_reply_to_screen_name" : "emoore",
  "in_reply_to_user_id_str" : "23640904",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/c3rgdJ7GaV",
      "expanded_url" : "http:\/\/bit.ly\/1aflgoW",
      "display_url" : "bit.ly\/1aflgoW"
    } ]
  },
  "geo" : { },
  "id_str" : "393526092155588608",
  "text" : "I love this note from a user of 750 Words, which tells the story of his new writing habit forming: http:\/\/t.co\/c3rgdJ7GaV",
  "id" : 393526092155588608,
  "created_at" : "2013-10-24 23:55:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Panzarino",
      "screen_name" : "panzer",
      "indices" : [ 22, 29 ],
      "id_str" : "19312115",
      "id" : 19312115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/qCQP70uM1o",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/tweetbot-3-for-twitter-iphone\/id722294701?mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/tweetbo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "393499124672122880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764431839, -122.4173662365 ]
  },
  "id_str" : "393511447671472128",
  "in_reply_to_user_id" : 19312115,
  "text" : "Looks really nice. RT @panzer: Here\u2019s a direct link to Tweetbot 3 https:\/\/t.co\/qCQP70uM1o",
  "id" : 393511447671472128,
  "in_reply_to_status_id" : 393499124672122880,
  "created_at" : "2013-10-24 22:56:54 +0000",
  "in_reply_to_screen_name" : "panzer",
  "in_reply_to_user_id_str" : "19312115",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/n6BW4Dsyan",
      "expanded_url" : "http:\/\/www.onthemedia.org\/story\/eavesdropping-former-nsa-head-amtrak\/",
      "display_url" : "onthemedia.org\/story\/eavesdro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393495239857414144",
  "text" : "Someone live-tweeted \"off-record\" interviews with a former NSA head: http:\/\/t.co\/n6BW4Dsyan",
  "id" : 393495239857414144,
  "created_at" : "2013-10-24 21:52:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley holtgraver",
      "screen_name" : "ashleyluvspizza",
      "indices" : [ 0, 16 ],
      "id_str" : "1208571",
      "id" : 1208571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393463335200370688",
  "geo" : { },
  "id_str" : "393467326852395008",
  "in_reply_to_user_id" : 1208571,
  "text" : "@ashleyluvspizza Ooh, I didn't know there was a new Deltron. Thanks!",
  "id" : 393467326852395008,
  "in_reply_to_status_id" : 393463335200370688,
  "created_at" : "2013-10-24 20:01:35 +0000",
  "in_reply_to_screen_name" : "ashleyluvspizza",
  "in_reply_to_user_id_str" : "1208571",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 0, 8 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nofilter",
      "indices" : [ 37, 46 ]
    }, {
      "text" : "HipsterVision",
      "indices" : [ 47, 61 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393447384677494785",
  "geo" : { },
  "id_str" : "393448285584650240",
  "in_reply_to_user_id" : 22891211,
  "text" : "@chanian Real hipsters would get the #nofilter #HipsterVision contacts.",
  "id" : 393448285584650240,
  "in_reply_to_status_id" : 393447384677494785,
  "created_at" : "2013-10-24 18:45:55 +0000",
  "in_reply_to_screen_name" : "chanian",
  "in_reply_to_user_id_str" : "22891211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Padgham",
      "screen_name" : "origiful",
      "indices" : [ 3, 12 ],
      "id_str" : "15603374",
      "id" : 15603374
    }, {
      "name" : "Ian Padgham",
      "screen_name" : "origiful",
      "indices" : [ 71, 80 ],
      "id_str" : "15603374",
      "id" : 15603374
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "loop",
      "indices" : [ 62, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/hy0YCxRfaq",
      "expanded_url" : "https:\/\/vine.co\/v\/hpObpqFLFzi",
      "display_url" : "vine.co\/v\/hpObpqFLFzi"
    } ]
  },
  "geo" : { },
  "id_str" : "393420843436363776",
  "text" : "RT @origiful: The new Vine update is AMAZING! Check it out :) #loop by @origiful https:\/\/t.co\/hy0YCxRfaq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ian Padgham",
        "screen_name" : "origiful",
        "indices" : [ 57, 66 ],
        "id_str" : "15603374",
        "id" : 15603374
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "loop",
        "indices" : [ 48, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/hy0YCxRfaq",
        "expanded_url" : "https:\/\/vine.co\/v\/hpObpqFLFzi",
        "display_url" : "vine.co\/v\/hpObpqFLFzi"
      } ]
    },
    "geo" : { },
    "id_str" : "393419947776688129",
    "text" : "The new Vine update is AMAZING! Check it out :) #loop by @origiful https:\/\/t.co\/hy0YCxRfaq",
    "id" : 393419947776688129,
    "created_at" : "2013-10-24 16:53:19 +0000",
    "user" : {
      "name" : "Ian Padgham",
      "screen_name" : "origiful",
      "protected" : false,
      "id_str" : "15603374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3760492781\/129672f7e46b9842d9833d38f006c45a_normal.jpeg",
      "id" : 15603374,
      "verified" : false
    }
  },
  "id" : 393420843436363776,
  "created_at" : "2013-10-24 16:56:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vine",
      "screen_name" : "vineapp",
      "indices" : [ 3, 11 ],
      "id_str" : "586671909",
      "id" : 586671909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/PQUX5HP0jc",
      "expanded_url" : "http:\/\/blog.vine.co\/post\/64962401268\/back-to-the-future",
      "display_url" : "blog.vine.co\/post\/649624012\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393413565819809792",
  "text" : "RT @vineapp: Introducing powerful additions to the Vine camera: Sessions and Time Travel -- available for iOS and Android. http:\/\/t.co\/PQUX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/PQUX5HP0jc",
        "expanded_url" : "http:\/\/blog.vine.co\/post\/64962401268\/back-to-the-future",
        "display_url" : "blog.vine.co\/post\/649624012\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "393411234575294464",
    "text" : "Introducing powerful additions to the Vine camera: Sessions and Time Travel -- available for iOS and Android. http:\/\/t.co\/PQUX5HP0jc",
    "id" : 393411234575294464,
    "created_at" : "2013-10-24 16:18:42 +0000",
    "user" : {
      "name" : "Vine",
      "screen_name" : "vineapp",
      "protected" : false,
      "id_str" : "586671909",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3578238864\/50d7e05aa6fe5d477e48a63047e38ce7_normal.png",
      "id" : 586671909,
      "verified" : true
    }
  },
  "id" : 393413565819809792,
  "created_at" : "2013-10-24 16:27:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "megan quinn",
      "screen_name" : "msquinn",
      "indices" : [ 0, 8 ],
      "id_str" : "15293504",
      "id" : 15293504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393385427492540416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596330854, -122.2755928898 ]
  },
  "id_str" : "393392871870455808",
  "in_reply_to_user_id" : 15293504,
  "text" : "@msquinn Thank you!",
  "id" : 393392871870455808,
  "in_reply_to_status_id" : 393385427492540416,
  "created_at" : "2013-10-24 15:05:44 +0000",
  "in_reply_to_screen_name" : "msquinn",
  "in_reply_to_user_id_str" : "15293504",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Penner",
      "screen_name" : "cpen",
      "indices" : [ 0, 5 ],
      "id_str" : "7694352",
      "id" : 7694352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/MAT8tcqOL2",
      "expanded_url" : "https:\/\/medium.com\/sunday-post\/62e639ffb09d",
      "display_url" : "medium.com\/sunday-post\/62\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "393267787562373121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597259149, -122.2755093222 ]
  },
  "id_str" : "393268522811265025",
  "in_reply_to_user_id" : 7694352,
  "text" : "@cpen It is really fun to think about... you should post your list! I kept thinking about it so posted this too: https:\/\/t.co\/MAT8tcqOL2",
  "id" : 393268522811265025,
  "in_reply_to_status_id" : 393267787562373121,
  "created_at" : "2013-10-24 06:51:37 +0000",
  "in_reply_to_screen_name" : "cpen",
  "in_reply_to_user_id_str" : "7694352",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393265574668562432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597656032, -122.2754650657 ]
  },
  "id_str" : "393267178994016256",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm The first 3 are amazing and I've totally been taking them for granted.",
  "id" : 393267178994016256,
  "in_reply_to_status_id" : 393265574668562432,
  "created_at" : "2013-10-24 06:46:16 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "soawesome",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/yuoIreYClr",
      "expanded_url" : "http:\/\/flic.kr\/p\/gVHheX",
      "display_url" : "flic.kr\/p\/gVHheX"
    } ]
  },
  "geo" : { },
  "id_str" : "393254687660863488",
  "text" : "Kellianne bought Niko his first pedal bike today. He chose it out himself. #soawesome http:\/\/t.co\/yuoIreYClr",
  "id" : 393254687660863488,
  "created_at" : "2013-10-24 05:56:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 0, 10 ],
      "id_str" : "10015122",
      "id" : 10015122
    }, {
      "name" : "The Daily Show",
      "screen_name" : "TheDailyShow",
      "indices" : [ 44, 57 ],
      "id_str" : "158414847",
      "id" : 158414847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393237827745361920",
  "in_reply_to_user_id" : 10015122,
  "text" : "@andypixel I'm watching Malcolm Gladwell on @TheDailyShow and reminiscing about your Malcolm Gladwell phase.",
  "id" : 393237827745361920,
  "created_at" : "2013-10-24 04:49:38 +0000",
  "in_reply_to_screen_name" : "andypixel",
  "in_reply_to_user_id_str" : "10015122",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryce Roberts",
      "screen_name" : "bryce",
      "indices" : [ 3, 9 ],
      "id_str" : "6160742",
      "id" : 6160742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/7bVMHznGhZ",
      "expanded_url" : "http:\/\/bit.ly\/Hfqd8V",
      "display_url" : "bit.ly\/Hfqd8V"
    } ]
  },
  "geo" : { },
  "id_str" : "393227177581236224",
  "text" : "RT @bryce: Most People Won't http:\/\/t.co\/7bVMHznGhZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/7bVMHznGhZ",
        "expanded_url" : "http:\/\/bit.ly\/Hfqd8V",
        "display_url" : "bit.ly\/Hfqd8V"
      } ]
    },
    "geo" : { },
    "id_str" : "393108824686886912",
    "text" : "Most People Won't http:\/\/t.co\/7bVMHznGhZ",
    "id" : 393108824686886912,
    "created_at" : "2013-10-23 20:17:02 +0000",
    "user" : {
      "name" : "Bryce Roberts",
      "screen_name" : "bryce",
      "protected" : false,
      "id_str" : "6160742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1760909983\/me_normal.jpg",
      "id" : 6160742,
      "verified" : false
    }
  },
  "id" : 393227177581236224,
  "created_at" : "2013-10-24 04:07:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/YEg1fkl3T2",
      "expanded_url" : "http:\/\/flic.kr\/p\/gVAqdP",
      "display_url" : "flic.kr\/p\/gVAqdP"
    } ]
  },
  "geo" : { },
  "id_str" : "393224636944879616",
  "text" : "8:36pm Listening to purring. http:\/\/t.co\/YEg1fkl3T2",
  "id" : 393224636944879616,
  "created_at" : "2013-10-24 03:57:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393062898588610560",
  "geo" : { },
  "id_str" : "393063009687314432",
  "in_reply_to_user_id" : 2185,
  "text" : "@rickwebb *insert years and years of identity confusion*",
  "id" : 393063009687314432,
  "in_reply_to_status_id" : 393062898588610560,
  "created_at" : "2013-10-23 17:14:58 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393052728282583040",
  "geo" : { },
  "id_str" : "393062898588610560",
  "in_reply_to_user_id" : 761628,
  "text" : "@rickwebb I *love* the implication here, but Eric Benson with a \"c\" joined a few years earlier than I did, and built BookMatcher.",
  "id" : 393062898588610560,
  "in_reply_to_status_id" : 393052728282583040,
  "created_at" : "2013-10-23 17:14:32 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "everythingstore",
      "indices" : [ 120, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8004785162, -122.282982627 ]
  },
  "id_str" : "393055078128447488",
  "text" : "Amazon's strengths: customer (not competitor) focused, long-term focused (not pivoting), inventive (not fast follower). #everythingstore",
  "id" : 393055078128447488,
  "created_at" : "2013-10-23 16:43:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/8sy0D9O6MW",
      "expanded_url" : "http:\/\/flic.kr\/p\/gTYUbi",
      "display_url" : "flic.kr\/p\/gTYUbi"
    } ]
  },
  "geo" : { },
  "id_str" : "392861059402706944",
  "text" : "8:36pm Acknowledging rumors of some similarity of appearance http:\/\/t.co\/8sy0D9O6MW",
  "id" : 392861059402706944,
  "created_at" : "2013-10-23 03:52:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Long",
      "screen_name" : "jasonlong",
      "indices" : [ 3, 13 ],
      "id_str" : "9869852",
      "id" : 9869852
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jasonlong\/status\/392664083339563009\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/GOFacgy8Dq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXMF5zxCEAA9UFN.jpg",
      "id_str" : "392664083217911808",
      "id" : 392664083217911808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXMF5zxCEAA9UFN.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 178
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3131,
        "resize" : "fit",
        "w" : 820
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 314
      } ],
      "display_url" : "pic.twitter.com\/GOFacgy8Dq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392818167547830272",
  "text" : "RT @jasonlong: There some really original and innovative design work going on in the productivity app space. http:\/\/t.co\/GOFacgy8Dq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jasonlong\/status\/392664083339563009\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/GOFacgy8Dq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXMF5zxCEAA9UFN.jpg",
        "id_str" : "392664083217911808",
        "id" : 392664083217911808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXMF5zxCEAA9UFN.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 178
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3131,
          "resize" : "fit",
          "w" : 820
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 314
        } ],
        "display_url" : "pic.twitter.com\/GOFacgy8Dq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392664083339563009",
    "text" : "There some really original and innovative design work going on in the productivity app space. http:\/\/t.co\/GOFacgy8Dq",
    "id" : 392664083339563009,
    "created_at" : "2013-10-22 14:49:47 +0000",
    "user" : {
      "name" : "Jason Long",
      "screen_name" : "jasonlong",
      "protected" : false,
      "id_str" : "9869852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453611992431865856\/q9LM0WQd_normal.jpeg",
      "id" : 9869852,
      "verified" : false
    }
  },
  "id" : 392818167547830272,
  "created_at" : "2013-10-23 01:02:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "marshal",
      "indices" : [ 0, 8 ],
      "id_str" : "19028099",
      "id" : 19028099
    }, {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 75, 81 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392698154467880960",
  "geo" : { },
  "id_str" : "392698441815453696",
  "in_reply_to_user_id" : 19028099,
  "text" : "@marshal I love the idea. It's like reverse Netflix. I'd like to create an @ifttt script to blogify the notebook too.",
  "id" : 392698441815453696,
  "in_reply_to_status_id" : 392698154467880960,
  "created_at" : "2013-10-22 17:06:19 +0000",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "marshal",
      "indices" : [ 114, 122 ],
      "id_str" : "19028099",
      "id" : 19028099
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 127, 139 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/CcasuZi7G0",
      "expanded_url" : "http:\/\/kck.st\/160tRfG",
      "display_url" : "kck.st\/160tRfG"
    } ]
  },
  "geo" : { },
  "id_str" : "392698078806806529",
  "text" : "I just backed a physical notebook that gets scanned + uploaded the cloud every month: http:\/\/t.co\/CcasuZi7G0 \/via @marshal \/on @kickstarter",
  "id" : 392698078806806529,
  "created_at" : "2013-10-22 17:04:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596680386, -122.2755885608 ]
  },
  "id_str" : "392532251772084224",
  "text" : "My instinct for what to do during an earthquake while driving across the Bay Bridge is to roll down the windows.",
  "id" : 392532251772084224,
  "created_at" : "2013-10-22 06:05:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "news.yc Popular",
      "screen_name" : "newsycombinator",
      "indices" : [ 9, 25 ],
      "id_str" : "14335498",
      "id" : 14335498
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oops",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/bRGcMfSAnb",
      "expanded_url" : "http:\/\/pythonsweetness.tumblr.com\/post\/64740079543\/how-to-lose-172-222-a-second-for-45-minutes",
      "display_url" : "pythonsweetness.tumblr.com\/post\/647400795\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "392500833507893248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597681156, -122.2756438489 ]
  },
  "id_str" : "392518015616430080",
  "in_reply_to_user_id" : 14335498,
  "text" : "#oops RT @newsycombinator: How to lose $172,222 a second for 45 minutes http:\/\/t.co\/bRGcMfSAnb",
  "id" : 392518015616430080,
  "in_reply_to_status_id" : 392500833507893248,
  "created_at" : "2013-10-22 05:09:22 +0000",
  "in_reply_to_screen_name" : "newsycombinator",
  "in_reply_to_user_id_str" : "14335498",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/z2jzFdHyii",
      "expanded_url" : "http:\/\/flic.kr\/p\/gSofvz",
      "display_url" : "flic.kr\/p\/gSofvz"
    } ]
  },
  "geo" : { },
  "id_str" : "392500083838963712",
  "text" : "8:36pm Clean hands check http:\/\/t.co\/z2jzFdHyii",
  "id" : 392500083838963712,
  "created_at" : "2013-10-22 03:58:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/RI0X62amRr",
      "expanded_url" : "http:\/\/bit.ly\/16nuUIV",
      "display_url" : "bit.ly\/16nuUIV"
    } ]
  },
  "geo" : { },
  "id_str" : "392366230419804160",
  "text" : "Which basic human desires do your favorite products satisfy? http:\/\/t.co\/RI0X62amRr",
  "id" : 392366230419804160,
  "created_at" : "2013-10-21 19:06:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 9, 16 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Event Parrot",
      "screen_name" : "eventparrot",
      "indices" : [ 45, 57 ],
      "id_str" : "1411434049",
      "id" : 1411434049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392336802830221312",
  "geo" : { },
  "id_str" : "392351493254168576",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs @sippey I like that idea too\u2026 I bet @eventparrot is probably listening.",
  "id" : 392351493254168576,
  "in_reply_to_status_id" : 392336802830221312,
  "created_at" : "2013-10-21 18:07:40 +0000",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/nq4fp8UDU5",
      "expanded_url" : "http:\/\/flic.kr\/p\/gQFE4c",
      "display_url" : "flic.kr\/p\/gQFE4c"
    } ]
  },
  "geo" : { },
  "id_str" : "392133748294451200",
  "text" : "8:36pm Quiet night, hoping I don't get sick like the rest of them http:\/\/t.co\/nq4fp8UDU5",
  "id" : 392133748294451200,
  "created_at" : "2013-10-21 03:42:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 0, 12 ],
      "id_str" : "195863654",
      "id" : 195863654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392099442133708800",
  "geo" : { },
  "id_str" : "392119190242353152",
  "in_reply_to_user_id" : 195863654,
  "text" : "@marihuertas Thanks, Mari! And I agree about the design being a big part of what makes me love a product.",
  "id" : 392119190242353152,
  "in_reply_to_status_id" : 392099442133708800,
  "created_at" : "2013-10-21 02:44:34 +0000",
  "in_reply_to_screen_name" : "marihuertas",
  "in_reply_to_user_id_str" : "195863654",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/4XC9SCD2Vq",
      "expanded_url" : "https:\/\/vine.co\/v\/hdvx3vMvbXU",
      "display_url" : "vine.co\/v\/hdvx3vMvbXU"
    } ]
  },
  "geo" : { },
  "id_str" : "392042716391309312",
  "text" : "East Bay Maker Faire is cool enough to warrant skipping a nap I think https:\/\/t.co\/4XC9SCD2Vq",
  "id" : 392042716391309312,
  "created_at" : "2013-10-20 21:40:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/KJCf0Xyly9",
      "expanded_url" : "https:\/\/vine.co\/v\/hdvwlOw5mnF",
      "display_url" : "vine.co\/v\/hdvwlOw5mnF"
    } ]
  },
  "geo" : { },
  "id_str" : "392035280297136128",
  "text" : "Buried alive in Jenga https:\/\/t.co\/KJCf0Xyly9",
  "id" : 392035280297136128,
  "created_at" : "2013-10-20 21:11:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391996297990787072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8324517049, -122.257734323 ]
  },
  "id_str" : "392017808646619138",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim Thanks! It's a long game. :)",
  "id" : 392017808646619138,
  "in_reply_to_status_id" : 391996297990787072,
  "created_at" : "2013-10-20 20:01:43 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/RRgxqoDvV8",
      "expanded_url" : "https:\/\/vine.co\/v\/hdvutIazUge",
      "display_url" : "vine.co\/v\/hdvutIazUge"
    } ]
  },
  "geo" : { },
  "id_str" : "392017457457926144",
  "text" : "Niko's racing a found car in lane 1, an unmodified block of wood https:\/\/t.co\/RRgxqoDvV8",
  "id" : 392017457457926144,
  "created_at" : "2013-10-20 20:00:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/rKnnbt2qD9",
      "expanded_url" : "http:\/\/flic.kr\/p\/gPYVrZ",
      "display_url" : "flic.kr\/p\/gPYVrZ"
    } ]
  },
  "geo" : { },
  "id_str" : "392012780104347648",
  "text" : "The Nerdy Derby: racing cars down a slide http:\/\/t.co\/rKnnbt2qD9",
  "id" : 392012780104347648,
  "created_at" : "2013-10-20 19:41:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Quinn",
      "screen_name" : "maxbot3000",
      "indices" : [ 0, 11 ],
      "id_str" : "1193706962",
      "id" : 1193706962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392003889135755264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8324390063, -122.2577510868 ]
  },
  "id_str" : "392010289530429440",
  "in_reply_to_user_id" : 1193706962,
  "text" : "@maxbot3000 Come work with us! :)",
  "id" : 392010289530429440,
  "in_reply_to_status_id" : 392003889135755264,
  "created_at" : "2013-10-20 19:31:50 +0000",
  "in_reply_to_screen_name" : "maxbot3000",
  "in_reply_to_user_id_str" : "1193706962",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erica Anderson",
      "screen_name" : "EricaAmerica",
      "indices" : [ 0, 13 ],
      "id_str" : "14124673",
      "id" : 14124673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391995347515371520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8339760797, -122.2559473851 ]
  },
  "id_str" : "392000265496170496",
  "in_reply_to_user_id" : 14124673,
  "text" : "@EricaAmerica Thanks, Erica!",
  "id" : 392000265496170496,
  "in_reply_to_status_id" : 391995347515371520,
  "created_at" : "2013-10-20 18:52:00 +0000",
  "in_reply_to_screen_name" : "EricaAmerica",
  "in_reply_to_user_id_str" : "14124673",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sundaypost",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/MAT8tcqOL2",
      "expanded_url" : "https:\/\/medium.com\/sunday-post\/62e639ffb09d",
      "display_url" : "medium.com\/sunday-post\/62\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391992658991665153",
  "text" : "Products I love &amp; how they're related to desires, identity, and building a product others love too https:\/\/t.co\/MAT8tcqOL2 #sundaypost",
  "id" : 391992658991665153,
  "created_at" : "2013-10-20 18:21:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    }, {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 15, 25 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391971808494108672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8622429873, -122.2812763891 ]
  },
  "id_str" : "391983252631613440",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin @ingopixel Maybe you need to show them Napoleon Dynamite and The Social Network a few more times.",
  "id" : 391983252631613440,
  "in_reply_to_status_id" : 391971808494108672,
  "created_at" : "2013-10-20 17:44:24 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/I0KR32mdOy",
      "expanded_url" : "http:\/\/m.fastcolabs.com\/3020181\/open-company\/inside-githubs-super-lean-management-strategy-and-how-it-drives-innovation?utm_content=buffer8c309&utm_source=buffer&utm_medium=twitter&utm_campaign=Buffer",
      "display_url" : "m.fastcolabs.com\/3020181\/open-c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596945247, -122.2754457874 ]
  },
  "id_str" : "391959251960070146",
  "text" : "Details on how Github uses Open Allocation -- super interesting http:\/\/t.co\/I0KR32mdOy",
  "id" : 391959251960070146,
  "created_at" : "2013-10-20 16:09:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/p6RCXGp0XF",
      "expanded_url" : "http:\/\/m.fastcolabs.com\/3010972\/open-company\/how-github-uses-deprivation-testing-to-hone-product-design",
      "display_url" : "m.fastcolabs.com\/3010972\/open-c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597469808, -122.2757136791 ]
  },
  "id_str" : "391959025748692992",
  "text" : "Deprivation testing sounds interesting http:\/\/t.co\/p6RCXGp0XF",
  "id" : 391959025748692992,
  "created_at" : "2013-10-20 16:08:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 0, 14 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391939152029032448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597541329, -122.2757086746 ]
  },
  "id_str" : "391946954218811392",
  "in_reply_to_user_id" : 1901375096,
  "text" : "@buster_ebooks Tired of my tweets already?",
  "id" : 391946954218811392,
  "in_reply_to_status_id" : 391939152029032448,
  "created_at" : "2013-10-20 15:20:10 +0000",
  "in_reply_to_screen_name" : "buster_ebooks",
  "in_reply_to_user_id_str" : "1901375096",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Gilman",
      "screen_name" : "jongilman",
      "indices" : [ 0, 10 ],
      "id_str" : "16908938",
      "id" : 16908938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391936439182561280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597596743, -122.2754946951 ]
  },
  "id_str" : "391946570486124544",
  "in_reply_to_user_id" : 16908938,
  "text" : "@jongilman Great post! I've got a post along similar lines for later today...",
  "id" : 391946570486124544,
  "in_reply_to_status_id" : 391936439182561280,
  "created_at" : "2013-10-20 15:18:39 +0000",
  "in_reply_to_screen_name" : "jongilman",
  "in_reply_to_user_id_str" : "16908938",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Gilman",
      "screen_name" : "jongilman",
      "indices" : [ 40, 50 ],
      "id_str" : "16908938",
      "id" : 16908938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/7G5JmekPVX",
      "expanded_url" : "https:\/\/medium.com\/product-people\/4b17f8295039",
      "display_url" : "medium.com\/product-people\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391945799329783808",
  "text" : "\u201CGreat products come from the heart\u201D by @jongilman https:\/\/t.co\/7G5JmekPVX",
  "id" : 391945799329783808,
  "created_at" : "2013-10-20 15:15:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 0, 4 ],
      "id_str" : "12720772",
      "id" : 12720772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391791586507370496",
  "geo" : { },
  "id_str" : "391793750298460160",
  "in_reply_to_user_id" : 12720772,
  "text" : "@gwb You can borrow mine.",
  "id" : 391793750298460160,
  "in_reply_to_status_id" : 391791586507370496,
  "created_at" : "2013-10-20 05:11:23 +0000",
  "in_reply_to_screen_name" : "gwb",
  "in_reply_to_user_id_str" : "12720772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391788259828699137",
  "geo" : { },
  "id_str" : "391789179027218432",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane Poor kids have so much important cultural history to catch up on. The 70s, the 80s, the 90s, the 00s\u2026",
  "id" : 391789179027218432,
  "in_reply_to_status_id" : 391788259828699137,
  "created_at" : "2013-10-20 04:53:14 +0000",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391786982151446529",
  "geo" : { },
  "id_str" : "391788259019206656",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel I know, right? Strange to think how quickly culture has shifted around those derogative names.",
  "id" : 391788259019206656,
  "in_reply_to_status_id" : 391786982151446529,
  "created_at" : "2013-10-20 04:49:34 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391787491130232832",
  "geo" : { },
  "id_str" : "391787791983443969",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane Yeah, I spent an extra minute or two explaining that it was a good to be called those names these days.",
  "id" : 391787791983443969,
  "in_reply_to_status_id" : 391787491130232832,
  "created_at" : "2013-10-20 04:47:43 +0000",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/391784339685400576\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/BKN9ejEujF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BW_lx_WCIAAnbft.jpg",
      "id_str" : "391784339584720896",
      "id" : 391784339584720896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BW_lx_WCIAAnbft.jpg",
      "sizes" : [ {
        "h" : 828,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 275,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 828,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/BKN9ejEujF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597223549, -122.2755562859 ]
  },
  "id_str" : "391784339685400576",
  "text" : "Was so excited about reading Spider Man to Niko until I got to this page http:\/\/t.co\/BKN9ejEujF",
  "id" : 391784339685400576,
  "created_at" : "2013-10-20 04:34:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Rowghani",
      "screen_name" : "ROWGHANI",
      "indices" : [ 0, 9 ],
      "id_str" : "28506038",
      "id" : 28506038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391753117592592385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596780124, -122.2754603719 ]
  },
  "id_str" : "391783539093405696",
  "in_reply_to_user_id" : 28506038,
  "text" : "@ROWGHANI Ah, I miss that place.",
  "id" : 391783539093405696,
  "in_reply_to_status_id" : 391753117592592385,
  "created_at" : "2013-10-20 04:30:49 +0000",
  "in_reply_to_screen_name" : "ROWGHANI",
  "in_reply_to_user_id_str" : "28506038",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/uPVggc5N8i",
      "expanded_url" : "http:\/\/flic.kr\/p\/gNFZWn",
      "display_url" : "flic.kr\/p\/gNFZWn"
    } ]
  },
  "geo" : { },
  "id_str" : "391773200360947712",
  "text" : "8:36pm Driving home, singing songs about how cold Sopor is because she's locked out without a sweater http:\/\/t.co\/uPVggc5N8i",
  "id" : 391773200360947712,
  "created_at" : "2013-10-20 03:49:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 3, 10 ],
      "id_str" : "14290242",
      "id" : 14290242
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 12, 19 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Sol to Seed Farm",
      "screen_name" : "soltoseedfarm",
      "indices" : [ 105, 119 ],
      "id_str" : "70124848",
      "id" : 70124848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391687564005867520",
  "text" : "RT @maggim: @buster TWITTER, wooly yarns, Dior mascara, Kevin Murphy shampoo, vegetables &amp; eggs from @soltoseedfarm, Spit Spray for my swim\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      }, {
        "name" : "Sol to Seed Farm",
        "screen_name" : "soltoseedfarm",
        "indices" : [ 93, 107 ],
        "id_str" : "70124848",
        "id" : 70124848
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "391648380679880704",
    "geo" : { },
    "id_str" : "391686977092730880",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster TWITTER, wooly yarns, Dior mascara, Kevin Murphy shampoo, vegetables &amp; eggs from @soltoseedfarm, Spit Spray for my swim goggles",
    "id" : 391686977092730880,
    "in_reply_to_status_id" : 391648380679880704,
    "created_at" : "2013-10-19 22:07:07 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "maggim",
      "screen_name" : "maggim",
      "protected" : false,
      "id_str" : "14290242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432172984455806978\/-abdQjqR_normal.jpeg",
      "id" : 14290242,
      "verified" : false
    }
  },
  "id" : 391687564005867520,
  "created_at" : "2013-10-19 22:09:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "earndit",
      "screen_name" : "earndit",
      "indices" : [ 10, 18 ],
      "id_str" : "108300819",
      "id" : 108300819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391685052330815488",
  "geo" : { },
  "id_str" : "391685194001833984",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @earndit Ah, cool. But if it's one of your *favorite things* it's probably worth it, right?",
  "id" : 391685194001833984,
  "in_reply_to_status_id" : 391685052330815488,
  "created_at" : "2013-10-19 22:00:02 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Baxter",
      "screen_name" : "lorenbaxter",
      "indices" : [ 0, 12 ],
      "id_str" : "15649565",
      "id" : 15649565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391678546592010240",
  "geo" : { },
  "id_str" : "391685084043956224",
  "in_reply_to_user_id" : 15649565,
  "text" : "@lorenbaxter If I had more time on my hands, that would definitely be a fun thing to do. Surely it's been done before?",
  "id" : 391685084043956224,
  "in_reply_to_status_id" : 391678546592010240,
  "created_at" : "2013-10-19 21:59:35 +0000",
  "in_reply_to_screen_name" : "lorenbaxter",
  "in_reply_to_user_id_str" : "15649565",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391679097526435840",
  "geo" : { },
  "id_str" : "391684779990872065",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Can't you get a new one? Or was it special somehow?",
  "id" : 391684779990872065,
  "in_reply_to_status_id" : 391679097526435840,
  "created_at" : "2013-10-19 21:58:23 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 3, 13 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 15, 22 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391684607906570242",
  "text" : "RT @avantgame: @buster kindle, Nike running shoes, Mac lipgloss, larabars, fishermans friends, kong toys for dogs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "391648380679880704",
    "geo" : { },
    "id_str" : "391679434144489472",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster kindle, Nike running shoes, Mac lipgloss, larabars, fishermans friends, kong toys for dogs",
    "id" : 391679434144489472,
    "in_reply_to_status_id" : 391648380679880704,
    "created_at" : "2013-10-19 21:37:08 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "protected" : false,
      "id_str" : "681813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000116152853\/47c4501ee2d80e97b423129fe0db016a_normal.jpeg",
      "id" : 681813,
      "verified" : false
    }
  },
  "id" : 391684607906570242,
  "created_at" : "2013-10-19 21:57:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Wild",
      "screen_name" : "dorkitude",
      "indices" : [ 18, 28 ],
      "id_str" : "12626542",
      "id" : 12626542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/lTLuXTrfMR",
      "expanded_url" : "http:\/\/bit.ly\/H3GBJp",
      "display_url" : "bit.ly\/H3GBJp"
    } ]
  },
  "geo" : { },
  "id_str" : "391666756101488640",
  "text" : "Great article. RT @dorkitude: \"A thoughtful user of data knows not everything they want to understand is measurable.\" http:\/\/t.co\/lTLuXTrfMR",
  "id" : 391666756101488640,
  "created_at" : "2013-10-19 20:46:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marie-Soleil",
      "screen_name" : "msoleil_",
      "indices" : [ 3, 12 ],
      "id_str" : "16058215",
      "id" : 16058215
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 14, 21 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391660880124858368",
  "text" : "RT @msoleil_: @buster  Red scarf w\/ birds, coffee, gin w\/ tonic (lime), Netflix, fluffy duvet, pool, bubble bath, iPad, black boots, books,\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "391660733500772352",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster  Red scarf w\/ birds, coffee, gin w\/ tonic (lime), Netflix, fluffy duvet, pool, bubble bath, iPad, black boots, books, chili peppers.",
    "id" : 391660733500772352,
    "created_at" : "2013-10-19 20:22:50 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Marie-Soleil",
      "screen_name" : "msoleil_",
      "protected" : false,
      "id_str" : "16058215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000795717493\/b5c31a2ef307a36e1e9e25afdc3d5fcb_normal.jpeg",
      "id" : 16058215,
      "verified" : false
    }
  },
  "id" : 391660880124858368,
  "created_at" : "2013-10-19 20:23:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kunal Tandon",
      "screen_name" : "KunalTandon",
      "indices" : [ 3, 15 ],
      "id_str" : "22681759",
      "id" : 22681759
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 17, 24 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391660116090437632",
  "text" : "RT @KunalTandon: @buster Google Maps, Twitter, iPhone, North Face fleece, burt's bees lip balm, field notes, Instagram, orbit gum, NYC Subw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "391648380679880704",
    "geo" : { },
    "id_str" : "391660062352998400",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster Google Maps, Twitter, iPhone, North Face fleece, burt's bees lip balm, field notes, Instagram, orbit gum, NYC Subway, nike sneakers.",
    "id" : 391660062352998400,
    "in_reply_to_status_id" : 391648380679880704,
    "created_at" : "2013-10-19 20:20:10 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Kunal Tandon",
      "screen_name" : "KunalTandon",
      "protected" : false,
      "id_str" : "22681759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459003778927034369\/GaJANJ4w_normal.png",
      "id" : 22681759,
      "verified" : false
    }
  },
  "id" : 391660116090437632,
  "created_at" : "2013-10-19 20:20:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 0, 7 ],
      "id_str" : "23640904",
      "id" : 23640904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/fM6yn25e1m",
      "expanded_url" : "http:\/\/bit.ly\/H3E3ek",
      "display_url" : "bit.ly\/H3E3ek"
    } ]
  },
  "geo" : { },
  "id_str" : "391659504200212481",
  "in_reply_to_user_id" : 23640904,
  "text" : "@emoore Can you tell me more about that exercise you did that went something like this:  http:\/\/t.co\/fM6yn25e1m What were follow-up steps?",
  "id" : 391659504200212481,
  "created_at" : "2013-10-19 20:17:57 +0000",
  "in_reply_to_screen_name" : "emoore",
  "in_reply_to_user_id_str" : "23640904",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelsey Falter",
      "screen_name" : "kfalter",
      "indices" : [ 0, 8 ],
      "id_str" : "253578873",
      "id" : 253578873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391658644070494208",
  "geo" : { },
  "id_str" : "391658884663754753",
  "in_reply_to_user_id" : 253578873,
  "text" : "@kfalter PS. I wish poptip would let me mark a reply with multiple answers.",
  "id" : 391658884663754753,
  "in_reply_to_status_id" : 391658644070494208,
  "created_at" : "2013-10-19 20:15:29 +0000",
  "in_reply_to_screen_name" : "kfalter",
  "in_reply_to_user_id_str" : "253578873",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelsey Falter",
      "screen_name" : "kfalter",
      "indices" : [ 3, 11 ],
      "id_str" : "253578873",
      "id" : 253578873
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 13, 20 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391658695915872257",
  "text" : "RT @kfalter: @buster caffeine, hip chat, good jeans, good boots, my monitor, good computer bag, twitter, read receipts, spicy tequila, cont\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "391648380679880704",
    "geo" : { },
    "id_str" : "391658644070494208",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster caffeine, hip chat, good jeans, good boots, my monitor, good computer bag, twitter, read receipts, spicy tequila, contact lenses",
    "id" : 391658644070494208,
    "in_reply_to_status_id" : 391648380679880704,
    "created_at" : "2013-10-19 20:14:32 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Kelsey Falter",
      "screen_name" : "kfalter",
      "protected" : false,
      "id_str" : "253578873",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/439760639733821440\/En24d3kn_normal.jpeg",
      "id" : 253578873,
      "verified" : false
    }
  },
  "id" : 391658695915872257,
  "created_at" : "2013-10-19 20:14:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "indices" : [ 35, 43 ],
      "id_str" : "4030",
      "id" : 4030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/RvdJCmWDZO",
      "expanded_url" : "http:\/\/bit.ly\/H3DO2N",
      "display_url" : "bit.ly\/H3DO2N"
    } ]
  },
  "geo" : { },
  "id_str" : "391658570015465472",
  "text" : "I like the format of this post. RT @monstro: \u201CYou will reinvent yourself many times in an interesting life.\u201D http:\/\/t.co\/RvdJCmWDZO",
  "id" : 391658570015465472,
  "created_at" : "2013-10-19 20:14:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriemTeam",
      "screen_name" : "TriemTeam",
      "indices" : [ 3, 13 ],
      "id_str" : "24792603",
      "id" : 24792603
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 15, 22 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391658154112466944",
  "text" : "RT @TriemTeam: @buster iPhone, high thread count sheets, bourbon, ShopHouse, Levenger notebooks, wool socks, Ceylon tea, good pens.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "391648380679880704",
    "geo" : { },
    "id_str" : "391658067462742016",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster iPhone, high thread count sheets, bourbon, ShopHouse, Levenger notebooks, wool socks, Ceylon tea, good pens.",
    "id" : 391658067462742016,
    "in_reply_to_status_id" : 391648380679880704,
    "created_at" : "2013-10-19 20:12:14 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "TriemTeam",
      "screen_name" : "TriemTeam",
      "protected" : false,
      "id_str" : "24792603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425327152259923968\/mTUq7Ytm_normal.jpeg",
      "id" : 24792603,
      "verified" : false
    }
  },
  "id" : 391658154112466944,
  "created_at" : "2013-10-19 20:12:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 3, 11 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 13, 20 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391655363956592641",
  "text" : "RT @dreeves: @buster iPhone, coffeemaker, Netflix, csa box, bicycle, motorcycle, camera, air travel, strava, twitter",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "391648380679880704",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 47.6173715838, -122.3208403797 ]
    },
    "id_str" : "391653397889167360",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster iPhone, coffeemaker, Netflix, csa box, bicycle, motorcycle, camera, air travel, strava, twitter",
    "id" : 391653397889167360,
    "in_reply_to_status_id" : 391648380679880704,
    "created_at" : "2013-10-19 19:53:41 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "protected" : false,
      "id_str" : "947851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3053671574\/f10ead459d0886bc28633dd1fef83cb5_normal.jpeg",
      "id" : 947851,
      "verified" : false
    }
  },
  "id" : 391655363956592641,
  "created_at" : "2013-10-19 20:01:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 3, 13 ],
      "id_str" : "7943892",
      "id" : 7943892
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 15, 22 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391655348785778688",
  "text" : "RT @ingopixel: @buster iPhone, Netflix (or is that a service?), couch, bed, stove, new yellow scarf, Dr. Jart BB Cream, lipgloss.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "391648380679880704",
    "geo" : { },
    "id_str" : "391650547540824064",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster iPhone, Netflix (or is that a service?), couch, bed, stove, new yellow scarf, Dr. Jart BB Cream, lipgloss.",
    "id" : 391650547540824064,
    "in_reply_to_status_id" : 391648380679880704,
    "created_at" : "2013-10-19 19:42:21 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "protected" : false,
      "id_str" : "7943892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/452094641945333761\/rcOR5jJX_normal.jpeg",
      "id" : 7943892,
      "verified" : false
    }
  },
  "id" : 391655348785778688,
  "created_at" : "2013-10-19 20:01:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391648380679880704",
  "geo" : { },
  "id_str" : "391655292426911744",
  "in_reply_to_user_id" : 2185,
  "text" : "A couple more: Google Maps, spreadsheets, Cards Against Humanity, Netflix Streaming, TrunkClub, Rdio, wifi, Macbook Pro w\/ Retina.",
  "id" : 391655292426911744,
  "in_reply_to_status_id" : 391648380679880704,
  "created_at" : "2013-10-19 20:01:12 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391650547540824064",
  "geo" : { },
  "id_str" : "391650717535965184",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Netflix definitely counts. Great answers.",
  "id" : 391650717535965184,
  "in_reply_to_status_id" : 391650547540824064,
  "created_at" : "2013-10-19 19:43:02 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/poptip.com\" rel=\"nofollow\"\u003EPoptip\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391648380679880704",
  "text" : "What products (tech and non-tech) do you love the most? Some of mine: my bike, my iPhone, my bed, coffee, wine, audio books, Twitter, Vine.",
  "id" : 391648380679880704,
  "created_at" : "2013-10-19 19:33:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/healthmonth.com\" rel=\"nofollow\"\u003EHealth Month\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/oFHQ8LM6FG",
      "expanded_url" : "http:\/\/healthmonth.com",
      "display_url" : "healthmonth.com"
    }, {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ha4CFKZ8ph",
      "expanded_url" : "http:\/\/healthmonth.com\/n\/294544",
      "display_url" : "healthmonth.com\/n\/294544"
    } ]
  },
  "geo" : { },
  "id_str" : "391646531449024513",
  "text" : "Using my old site, http:\/\/t.co\/oFHQ8LM6FG, for the first time in at least a year. It's still fun! http:\/\/t.co\/ha4CFKZ8ph",
  "id" : 391646531449024513,
  "created_at" : "2013-10-19 19:26:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391633703958372352",
  "text" : "Who else does Twitter searches filtered by \"people you follow\" before posting links to memes? If under 4, go. Otherwise, retweet or hold.",
  "id" : 391633703958372352,
  "created_at" : "2013-10-19 18:35:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodadvice",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/gba0Fs24Ey",
      "expanded_url" : "http:\/\/sufjan.com\/post\/64008392202\/dear-miley-i-cant-stop-listening-to-getitright",
      "display_url" : "sufjan.com\/post\/640083922\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391633199031259137",
  "text" : "Sufjan to Miley -- the last line is the best: \"Live brightly before your fire fades into total darkness.\" http:\/\/t.co\/gba0Fs24Ey #goodadvice",
  "id" : 391633199031259137,
  "created_at" : "2013-10-19 18:33:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "XOXO",
      "screen_name" : "xoxo",
      "indices" : [ 22, 27 ],
      "id_str" : "516875194",
      "id" : 516875194
    }, {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "indices" : [ 29, 32 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "xoxofest",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/EVnYigo60q",
      "expanded_url" : "http:\/\/youtu.be\/zR1xDBFdRZ0",
      "display_url" : "youtu.be\/zR1xDBFdRZ0"
    } ]
  },
  "in_reply_to_status_id_str" : "390605925393776640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596579796, -122.2755752039 ]
  },
  "id_str" : "391607971425554432",
  "in_reply_to_user_id" : 516875194,
  "text" : "Required watching! RT @xoxo: @ev shares what's he's learned about the Internet at #xoxofest http:\/\/t.co\/EVnYigo60q",
  "id" : 391607971425554432,
  "in_reply_to_status_id" : 390605925393776640,
  "created_at" : "2013-10-19 16:53:10 +0000",
  "in_reply_to_screen_name" : "xoxo",
  "in_reply_to_user_id_str" : "516875194",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Emberton",
      "screen_name" : "oliveremberton",
      "indices" : [ 120, 135 ],
      "id_str" : "16004473",
      "id" : 16004473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/AAQdaBq94U",
      "expanded_url" : "http:\/\/oliveremberton.com\/2013\/to-make-better-decisions-shut-up\/",
      "display_url" : "oliveremberton.com\/2013\/to-make-b\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597551552, -122.2754541204 ]
  },
  "id_str" : "391577066937675776",
  "text" : "\"The leading force behind most debates is not logic. It\u2019s people defending their integrity.\" http:\/\/t.co\/AAQdaBq94U \/by @oliveremberton",
  "id" : 391577066937675776,
  "created_at" : "2013-10-19 14:50:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/kkZ42WsDTX",
      "expanded_url" : "http:\/\/flic.kr\/p\/gMbeC6",
      "display_url" : "flic.kr\/p\/gMbeC6"
    } ]
  },
  "geo" : { },
  "id_str" : "391436185861894144",
  "text" : "8:36pm Niko insisting on late night bookshelf reorg projects http:\/\/t.co\/kkZ42WsDTX",
  "id" : 391436185861894144,
  "created_at" : "2013-10-19 05:30:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 0, 3 ],
      "id_str" : "15504330",
      "id" : 15504330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391395336385998848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859693477, -122.2754630541 ]
  },
  "id_str" : "391415239675101184",
  "in_reply_to_user_id" : 15504330,
  "text" : "@wm A yam in hand is worth two in the bush.",
  "id" : 391415239675101184,
  "in_reply_to_status_id" : 391395336385998848,
  "created_at" : "2013-10-19 04:07:19 +0000",
  "in_reply_to_screen_name" : "wm",
  "in_reply_to_user_id_str" : "15504330",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Lodwick",
      "screen_name" : "jakelodwick",
      "indices" : [ 0, 12 ],
      "id_str" : "237262300",
      "id" : 237262300
    }, {
      "name" : "Pasquale D'Silva",
      "screen_name" : "pasql",
      "indices" : [ 13, 19 ],
      "id_str" : "187793",
      "id" : 187793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391385059959533568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597218916, -122.2754201387 ]
  },
  "id_str" : "391394991634800640",
  "in_reply_to_user_id" : 237262300,
  "text" : "@jakelodwick @pasql But that's backwards. It's memes who made us to become immortal.",
  "id" : 391394991634800640,
  "in_reply_to_status_id" : 391385059959533568,
  "created_at" : "2013-10-19 02:46:52 +0000",
  "in_reply_to_screen_name" : "jakelodwick",
  "in_reply_to_user_id_str" : "237262300",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/FHMW1uOAnR",
      "expanded_url" : "http:\/\/flic.kr\/p\/gLZRGy",
      "display_url" : "flic.kr\/p\/gLZRGy"
    } ]
  },
  "geo" : { },
  "id_str" : "391383208740544512",
  "text" : "Bensons &lt;3 patterns http:\/\/t.co\/FHMW1uOAnR",
  "id" : 391383208740544512,
  "created_at" : "2013-10-19 02:00:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Chen",
      "screen_name" : "leftparen",
      "indices" : [ 0, 10 ],
      "id_str" : "78154150",
      "id" : 78154150
    }, {
      "name" : "Bastille SF",
      "screen_name" : "BastilleSF",
      "indices" : [ 17, 28 ],
      "id_str" : "124580431",
      "id" : 124580431
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 35, 46 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391378285982003200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597156827, -122.2756614425 ]
  },
  "id_str" : "391381670886010880",
  "in_reply_to_user_id" : 78154150,
  "text" : "@leftparen Added @BastilleSF to my @foursquare to-do list.",
  "id" : 391381670886010880,
  "in_reply_to_status_id" : 391378285982003200,
  "created_at" : "2013-10-19 01:53:56 +0000",
  "in_reply_to_screen_name" : "leftparen",
  "in_reply_to_user_id_str" : "78154150",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Chen",
      "screen_name" : "leftparen",
      "indices" : [ 0, 10 ],
      "id_str" : "78154150",
      "id" : 78154150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391356717771935744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597492166, -122.2758932133 ]
  },
  "id_str" : "391378059636379648",
  "in_reply_to_user_id" : 78154150,
  "text" : "@leftparen Ha, it sort of is! Where are you?",
  "id" : 391378059636379648,
  "in_reply_to_status_id" : 391356717771935744,
  "created_at" : "2013-10-19 01:39:35 +0000",
  "in_reply_to_screen_name" : "leftparen",
  "in_reply_to_user_id_str" : "78154150",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "indices" : [ 3, 15 ],
      "id_str" : "1532061",
      "id" : 1532061
    }, {
      "name" : "Clay Shirky",
      "screen_name" : "cshirky",
      "indices" : [ 139, 140 ],
      "id_str" : "6141832",
      "id" : 6141832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391272491017961472",
  "text" : "RT @kevin2kelly: If you want to feel like a genius go to where people are trying something new and tell them they will fail. It's a cheap h\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Clay Shirky",
        "screen_name" : "cshirky",
        "indices" : [ 131, 139 ],
        "id_str" : "6141832",
        "id" : 6141832
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "391272359446855681",
    "text" : "If you want to feel like a genius go to where people are trying something new and tell them they will fail. It's a cheap high.  -- @cshirky",
    "id" : 391272359446855681,
    "created_at" : "2013-10-18 18:39:34 +0000",
    "user" : {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "protected" : false,
      "id_str" : "1532061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/65000713\/KKlaughsm_normal.jpg",
      "id" : 1532061,
      "verified" : false
    }
  },
  "id" : 391272491017961472,
  "created_at" : "2013-10-18 18:40:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teamblue",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/cnT5mZIK6x",
      "expanded_url" : "http:\/\/flic.kr\/p\/gKDKRj",
      "display_url" : "flic.kr\/p\/gKDKRj"
    } ]
  },
  "geo" : { },
  "id_str" : "391049924860997632",
  "text" : "8:36pm Laying on the couch listening to crickets, remembering our 7-0 curling victory earlier today #teamblue http:\/\/t.co\/cnT5mZIK6x",
  "id" : 391049924860997632,
  "created_at" : "2013-10-18 03:55:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/9zw7b2Uo7G",
      "expanded_url" : "https:\/\/vine.co\/v\/hwPEDgAYi7X",
      "display_url" : "vine.co\/v\/hwPEDgAYi7X"
    } ]
  },
  "geo" : { },
  "id_str" : "390948520636993536",
  "text" : "Sweep it! https:\/\/t.co\/9zw7b2Uo7G",
  "id" : 390948520636993536,
  "created_at" : "2013-10-17 21:12:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/Q4pyQtZNi2",
      "expanded_url" : "https:\/\/vine.co\/v\/hwPT9xMi033",
      "display_url" : "vine.co\/v\/hwPT9xMi033"
    } ]
  },
  "geo" : { },
  "id_str" : "390942601605828608",
  "text" : "Justin on the curl https:\/\/t.co\/Q4pyQtZNi2",
  "id" : 390942601605828608,
  "created_at" : "2013-10-17 20:49:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/5uu46CZGDF",
      "expanded_url" : "http:\/\/isthegovernmentshutdown.com",
      "display_url" : "isthegovernmentshutdown.com"
    }, {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/DeeGX2mE7u",
      "expanded_url" : "http:\/\/flic.kr\/p\/gJbvLz",
      "display_url" : "flic.kr\/p\/gJbvLz"
    } ]
  },
  "geo" : { },
  "id_str" : "390699876830691328",
  "text" : "8:36pm Reloading http:\/\/t.co\/5uu46CZGDF http:\/\/t.co\/DeeGX2mE7u",
  "id" : 390699876830691328,
  "created_at" : "2013-10-17 04:44:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 9, 12 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/hq82n2Ipoh",
      "expanded_url" : "https:\/\/github.com\/twitter\/scala_school",
      "display_url" : "github.com\/twitter\/scala_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "390650905533505536",
  "geo" : { },
  "id_str" : "390697681108353024",
  "in_reply_to_user_id" : 15275073,
  "text" : "@tberman @rk Haven't looked at the docs at all, but did find this: https:\/\/t.co\/hq82n2Ipoh",
  "id" : 390697681108353024,
  "in_reply_to_status_id" : 390650905533505536,
  "created_at" : "2013-10-17 04:36:00 +0000",
  "in_reply_to_screen_name" : "tberman",
  "in_reply_to_user_id_str" : "15275073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 9, 12 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/PZir4ZahrD",
      "expanded_url" : "http:\/\/twitter.github.io\/scala_school\/",
      "display_url" : "twitter.github.io\/scala_school\/"
    } ]
  },
  "in_reply_to_status_id_str" : "390649535783247873",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7787196218, -122.4147015626 ]
  },
  "id_str" : "390650685886189568",
  "in_reply_to_user_id" : 15275073,
  "text" : "@tberman @rk This? http:\/\/t.co\/PZir4ZahrD",
  "id" : 390650685886189568,
  "in_reply_to_status_id" : 390649535783247873,
  "created_at" : "2013-10-17 01:29:16 +0000",
  "in_reply_to_screen_name" : "tberman",
  "in_reply_to_user_id_str" : "15275073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanner Christensen",
      "screen_name" : "tannerc",
      "indices" : [ 0, 8 ],
      "id_str" : "9161482",
      "id" : 9161482
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 66, 74 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390598964333903874",
  "geo" : { },
  "id_str" : "390610767470284801",
  "in_reply_to_user_id" : 9161482,
  "text" : "@tannerc Not impossible, but the only route is to write to support@twitter.com...",
  "id" : 390610767470284801,
  "in_reply_to_status_id" : 390598964333903874,
  "created_at" : "2013-10-16 22:50:38 +0000",
  "in_reply_to_screen_name" : "tannerc",
  "in_reply_to_user_id_str" : "9161482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanner Christensen",
      "screen_name" : "tannerc",
      "indices" : [ 0, 8 ],
      "id_str" : "9161482",
      "id" : 9161482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390589906457600001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769075698, -122.4173287053 ]
  },
  "id_str" : "390598693734596609",
  "in_reply_to_user_id" : 9161482,
  "text" : "@tannerc It's pretty difficult these days.",
  "id" : 390598693734596609,
  "in_reply_to_status_id" : 390589906457600001,
  "created_at" : "2013-10-16 22:02:40 +0000",
  "in_reply_to_screen_name" : "tannerc",
  "in_reply_to_user_id_str" : "9161482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390581289402650624",
  "geo" : { },
  "id_str" : "390581823475945472",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon Post a pic!",
  "id" : 390581823475945472,
  "in_reply_to_status_id" : 390581289402650624,
  "created_at" : "2013-10-16 20:55:38 +0000",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jointheflock",
      "indices" : [ 24, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/Zmk9iBkcF3",
      "expanded_url" : "http:\/\/flic.kr\/p\/gHwqev",
      "display_url" : "flic.kr\/p\/gHwqev"
    } ]
  },
  "geo" : { },
  "id_str" : "390552933651476480",
  "text" : "Four Roses for the team #jointheflock http:\/\/t.co\/Zmk9iBkcF3",
  "id" : 390552933651476480,
  "created_at" : "2013-10-16 19:00:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 0, 7 ],
      "id_str" : "1530531",
      "id" : 1530531
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mlpsecrethandshake",
      "indices" : [ 19, 38 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390515177457582080",
  "geo" : { },
  "id_str" : "390526496353157120",
  "in_reply_to_user_id" : 1530531,
  "text" : "@miradu Same here. #mlpsecrethandshake",
  "id" : 390526496353157120,
  "in_reply_to_status_id" : 390515177457582080,
  "created_at" : "2013-10-16 17:15:47 +0000",
  "in_reply_to_screen_name" : "miradu",
  "in_reply_to_user_id_str" : "1530531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390496392738660352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7829099007, -122.4190975426 ]
  },
  "id_str" : "390506856038166528",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Are we all just Markov chain bots of our parents?",
  "id" : 390506856038166528,
  "in_reply_to_status_id" : 390496392738660352,
  "created_at" : "2013-10-16 15:57:44 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8531813775, -122.2705361034 ]
  },
  "id_str" : "390498801041293312",
  "text" : "MLP: minimum lovable product.",
  "id" : 390498801041293312,
  "created_at" : "2013-10-16 15:25:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Andersen",
      "screen_name" : "rsa",
      "indices" : [ 23, 27 ],
      "id_str" : "6735",
      "id" : 6735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/Oew0NXttT6",
      "expanded_url" : "http:\/\/square.com\/cash",
      "display_url" : "square.com\/cash"
    } ]
  },
  "in_reply_to_status_id_str" : "390282210370015232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596933931, -122.2755562608 ]
  },
  "id_str" : "390358094514884608",
  "in_reply_to_user_id" : 6735,
  "text" : "This is pretty rad. RT @rsa: A better way to pay your pals: Square Cash. http:\/\/t.co\/Oew0NXttT6",
  "id" : 390358094514884608,
  "in_reply_to_status_id" : 390282210370015232,
  "created_at" : "2013-10-16 06:06:36 +0000",
  "in_reply_to_screen_name" : "rsa",
  "in_reply_to_user_id_str" : "6735",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/2ENfGYDQp2",
      "expanded_url" : "http:\/\/flic.kr\/p\/gGtT9d",
      "display_url" : "flic.kr\/p\/gGtT9d"
    } ]
  },
  "geo" : { },
  "id_str" : "390321115287281665",
  "text" : "8:36pm Even cool dudes gotta bathe http:\/\/t.co\/2ENfGYDQp2",
  "id" : 390321115287281665,
  "created_at" : "2013-10-16 03:39:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Stamatiou",
      "screen_name" : "Stammy",
      "indices" : [ 0, 7 ],
      "id_str" : "624683",
      "id" : 624683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390216471583784960",
  "geo" : { },
  "id_str" : "390216675800272896",
  "in_reply_to_user_id" : 624683,
  "text" : "@Stammy That would be awesome.",
  "id" : 390216675800272896,
  "in_reply_to_status_id" : 390216471583784960,
  "created_at" : "2013-10-15 20:44:40 +0000",
  "in_reply_to_screen_name" : "Stammy",
  "in_reply_to_user_id_str" : "624683",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/u6jfja3EJk",
      "expanded_url" : "https:\/\/www.thinkup.com\/join",
      "display_url" : "thinkup.com\/join"
    } ]
  },
  "geo" : { },
  "id_str" : "390197779827392512",
  "text" : "Join ThinkUp and be happy about all the time you spend on Twitter https:\/\/t.co\/u6jfja3EJk",
  "id" : 390197779827392512,
  "created_at" : "2013-10-15 19:29:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 3, 14 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 35, 47 ],
      "id_str" : "930061",
      "id" : 930061
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 52, 61 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/QWRYZmaYhR",
      "expanded_url" : "https:\/\/www.thinkup.com\/join",
      "display_url" : "thinkup.com\/join"
    } ]
  },
  "geo" : { },
  "id_str" : "390197221011902464",
  "text" : "RT @waxpancake: When I worked with @ginatrapani and @anildash, we always talked about making ThinkUp a hosted app. And now they are: https:\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gina Trapani",
        "screen_name" : "ginatrapani",
        "indices" : [ 19, 31 ],
        "id_str" : "930061",
        "id" : 930061
      }, {
        "name" : "Anil Dash",
        "screen_name" : "anildash",
        "indices" : [ 36, 45 ],
        "id_str" : "36823",
        "id" : 36823
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/QWRYZmaYhR",
        "expanded_url" : "https:\/\/www.thinkup.com\/join",
        "display_url" : "thinkup.com\/join"
      } ]
    },
    "geo" : { },
    "id_str" : "390196866861649920",
    "text" : "When I worked with @ginatrapani and @anildash, we always talked about making ThinkUp a hosted app. And now they are: https:\/\/t.co\/QWRYZmaYhR",
    "id" : 390196866861649920,
    "created_at" : "2013-10-15 19:25:57 +0000",
    "user" : {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "protected" : false,
      "id_str" : "13461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416642320574844928\/Gz7V2B6r_normal.jpeg",
      "id" : 13461,
      "verified" : false
    }
  },
  "id" : 390197221011902464,
  "created_at" : "2013-10-15 19:27:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Jordan Crook",
      "screen_name" : "jordanrcrook",
      "indices" : [ 100, 113 ],
      "id_str" : "296338717",
      "id" : 296338717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/ruwZIrmliF",
      "expanded_url" : "http:\/\/tcrn.ch\/19KK8lZ",
      "display_url" : "tcrn.ch\/19KK8lZ"
    } ]
  },
  "geo" : { },
  "id_str" : "390110449791815680",
  "text" : "RT @TechCrunch: General Assembly Launches Dash, A Tool For Coding Newbies http:\/\/t.co\/ruwZIrmliF by @jordanrcrook",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/10up.com\" rel=\"nofollow\"\u003E10up Publish Tweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jordan Crook",
        "screen_name" : "jordanrcrook",
        "indices" : [ 84, 97 ],
        "id_str" : "296338717",
        "id" : 296338717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/ruwZIrmliF",
        "expanded_url" : "http:\/\/tcrn.ch\/19KK8lZ",
        "display_url" : "tcrn.ch\/19KK8lZ"
      } ]
    },
    "geo" : { },
    "id_str" : "390100984305057792",
    "text" : "General Assembly Launches Dash, A Tool For Coding Newbies http:\/\/t.co\/ruwZIrmliF by @jordanrcrook",
    "id" : 390100984305057792,
    "created_at" : "2013-10-15 13:04:57 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2176846885\/-5-1_normal.jpeg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 390110449791815680,
  "created_at" : "2013-10-15 13:42:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 16, 26 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "loml",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597523329, -122.2755149375 ]
  },
  "id_str" : "390013553710600192",
  "text" : "Happy birthday, @kellianne! #loml",
  "id" : 390013553710600192,
  "created_at" : "2013-10-15 07:17:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Morga",
      "screen_name" : "AliciaMorga",
      "indices" : [ 0, 12 ],
      "id_str" : "19053875",
      "id" : 19053875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389941108479774721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596811975, -122.2755105795 ]
  },
  "id_str" : "390009803033964546",
  "in_reply_to_user_id" : 19053875,
  "text" : "@AliciaMorga They are on short notice but will definitely let you know about the next one!",
  "id" : 390009803033964546,
  "in_reply_to_status_id" : 389941108479774721,
  "created_at" : "2013-10-15 07:02:37 +0000",
  "in_reply_to_screen_name" : "AliciaMorga",
  "in_reply_to_user_id_str" : "19053875",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Dearman",
      "screen_name" : "dearman",
      "indices" : [ 28, 36 ],
      "id_str" : "14061523",
      "id" : 14061523
    }, {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 37, 44 ],
      "id_str" : "23640904",
      "id" : 23640904
    }, {
      "name" : "Reeve S. Thompson ",
      "screen_name" : "Reeve",
      "indices" : [ 49, 55 ],
      "id_str" : "9317922",
      "id" : 9317922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/lrM0hWATGg",
      "expanded_url" : "http:\/\/flic.kr\/p\/gEPLM8",
      "display_url" : "flic.kr\/p\/gEPLM8"
    } ]
  },
  "geo" : { },
  "id_str" : "389973764303503360",
  "text" : "8:36pm Drinks and food with @dearman @emoore and @reeve who left http:\/\/t.co\/lrM0hWATGg",
  "id" : 389973764303503360,
  "created_at" : "2013-10-15 04:39:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Capecelatro",
      "screen_name" : "jcap49",
      "indices" : [ 0, 7 ],
      "id_str" : "78733683",
      "id" : 78733683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389948513028546560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7793323897, -122.4234399496 ]
  },
  "id_str" : "389953494863458304",
  "in_reply_to_user_id" : 78733683,
  "text" : "@jcap49 An hour at least!",
  "id" : 389953494863458304,
  "in_reply_to_status_id" : 389948513028546560,
  "created_at" : "2013-10-15 03:18:52 +0000",
  "in_reply_to_screen_name" : "jcap49",
  "in_reply_to_user_id_str" : "78733683",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smuggler's Cove SF",
      "screen_name" : "smugglerscovesf",
      "indices" : [ 56, 72 ],
      "id_str" : "44229739",
      "id" : 44229739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Bg7VB1G16a",
      "expanded_url" : "http:\/\/4sq.com\/H0vWym",
      "display_url" : "4sq.com\/H0vWym"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7793898026, -122.4234462883 ]
  },
  "id_str" : "389928036029972480",
  "text" : "Quarterly night out. Why not stop by and say hello? (at @SmugglersCoveSf w\/ 3 others) http:\/\/t.co\/Bg7VB1G16a",
  "id" : 389928036029972480,
  "created_at" : "2013-10-15 01:37:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Biz Stone",
      "screen_name" : "biz",
      "indices" : [ 3, 7 ],
      "id_str" : "13",
      "id" : 13
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389797285527171072",
  "text" : "RT @biz: \"If you only do things where you know the answer in advance, your company goes away.\"\u2014Jeff Bezos",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389595974638653440",
    "text" : "\"If you only do things where you know the answer in advance, your company goes away.\"\u2014Jeff Bezos",
    "id" : 389595974638653440,
    "created_at" : "2013-10-14 03:38:13 +0000",
    "user" : {
      "name" : "Biz Stone",
      "screen_name" : "biz",
      "protected" : false,
      "id_str" : "13",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3459395559\/19cde4b0eb9bfaecc5713ab835fe9f6b_normal.jpeg",
      "id" : 13,
      "verified" : true
    }
  },
  "id" : 389797285527171072,
  "created_at" : "2013-10-14 16:58:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Inman",
      "screen_name" : "Oatmeal",
      "indices" : [ 119, 127 ],
      "id_str" : "4519121",
      "id" : 4519121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/GEG3wqbGXG",
      "expanded_url" : "http:\/\/theoatmeal.com\/comics\/columbus_day",
      "display_url" : "theoatmeal.com\/comics\/columbu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597373981, -122.275530696 ]
  },
  "id_str" : "389773046057160704",
  "text" : "Christopher Columbus discovered the New World much like a meteor discovered the dinosaurs. http:\/\/t.co\/GEG3wqbGXG \/via @Oatmeal",
  "id" : 389773046057160704,
  "created_at" : "2013-10-14 15:21:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "XOXO",
      "screen_name" : "xoxo",
      "indices" : [ 28, 33 ],
      "id_str" : "516875194",
      "id" : 516875194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/sMAFRS5uHs",
      "expanded_url" : "http:\/\/flic.kr\/p\/gCNnVQ",
      "display_url" : "flic.kr\/p\/gCNnVQ"
    } ]
  },
  "geo" : { },
  "id_str" : "389602947514245121",
  "text" : "8:36pm Watching videos from @xoxo http:\/\/t.co\/sMAFRS5uHs",
  "id" : 389602947514245121,
  "created_at" : "2013-10-14 04:05:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reeve S. Thompson ",
      "screen_name" : "Reeve",
      "indices" : [ 0, 6 ],
      "id_str" : "9317922",
      "id" : 9317922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389536724964999169",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596767551, -122.2754692567 ]
  },
  "id_str" : "389541607692722176",
  "in_reply_to_user_id" : 9317922,
  "text" : "@Reeve Yes! Loved it. Mr Brainwash... quite a run.",
  "id" : 389541607692722176,
  "in_reply_to_status_id" : 389536724964999169,
  "created_at" : "2013-10-14 00:02:11 +0000",
  "in_reply_to_screen_name" : "Reeve",
  "in_reply_to_user_id_str" : "9317922",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 12, 21 ],
      "id_str" : "761975",
      "id" : 761975
    }, {
      "name" : "XOXO",
      "screen_name" : "xoxo",
      "indices" : [ 22, 27 ],
      "id_str" : "516875194",
      "id" : 516875194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389536878577614848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597142688, -122.2756075956 ]
  },
  "id_str" : "389540314316144640",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake @mathowie @xoxo Awesome!",
  "id" : 389540314316144640,
  "in_reply_to_status_id" : 389536878577614848,
  "created_at" : "2013-10-13 23:57:02 +0000",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "banksy",
      "screen_name" : "banksyny",
      "indices" : [ 5, 14 ],
      "id_str" : "1924391640",
      "id" : 1924391640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389529614738915328",
  "geo" : { },
  "id_str" : "389530480032235522",
  "in_reply_to_user_id" : 2185,
  "text" : "It's @banksyny's context and narrative that are valuable. The physical pieces just create a scarce object through which to trade that value.",
  "id" : 389530480032235522,
  "in_reply_to_status_id" : 389529614738915328,
  "created_at" : "2013-10-13 23:17:58 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "banksy",
      "screen_name" : "banksyny",
      "indices" : [ 25, 34 ],
      "id_str" : "1924391640",
      "id" : 1924391640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/W6XoXpB3u0",
      "expanded_url" : "http:\/\/www.banksyny.com\/2013\/10\/13\/central-park",
      "display_url" : "banksyny.com\/2013\/10\/13\/cen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389529614738915328",
  "text" : "Only a couple people buy @banksyny original art for $30-$60 a pop when it's sold at a stand in Central Park: http:\/\/t.co\/W6XoXpB3u0",
  "id" : 389529614738915328,
  "created_at" : "2013-10-13 23:14:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "XOXO",
      "screen_name" : "xoxo",
      "indices" : [ 32, 37 ],
      "id_str" : "516875194",
      "id" : 516875194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/GA7MgYbgzQ",
      "expanded_url" : "http:\/\/xoxofest.com",
      "display_url" : "xoxofest.com"
    } ]
  },
  "geo" : { },
  "id_str" : "389523364940767232",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake Will you be posting @xoxo videos of talks? I keep reloading http:\/\/t.co\/GA7MgYbgzQ in the hopes that they'll show up.",
  "id" : 389523364940767232,
  "created_at" : "2013-10-13 22:49:41 +0000",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 71, 75 ],
      "id_str" : "259",
      "id" : 259
    }, {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 76, 83 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 84, 94 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/O3C4AQPM6t",
      "expanded_url" : "http:\/\/4sq.com\/17ACoT5",
      "display_url" : "4sq.com\/17ACoT5"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7742870489, -122.4136294142 ]
  },
  "id_str" : "389474219542994945",
  "text" : "Bring you empty bottle, fill them up with Ros\u00E8 for $7.99 (@ Tank 18 w\/ @ian @sharon @kellianne) http:\/\/t.co\/O3C4AQPM6t",
  "id" : 389474219542994945,
  "created_at" : "2013-10-13 19:34:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/9subTsGlUp",
      "expanded_url" : "http:\/\/youtu.be\/wE3fmFTtP9g",
      "display_url" : "youtu.be\/wE3fmFTtP9g"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8226401843, -122.3224706111 ]
  },
  "id_str" : "389465163939598337",
  "text" : "A four-legged military robot named WildCat that can gallop at 16mph, turn, and recover from falls: http:\/\/t.co\/9subTsGlUp",
  "id" : 389465163939598337,
  "created_at" : "2013-10-13 18:58:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597415316, -122.2756022904 ]
  },
  "id_str" : "389452940169080832",
  "text" : "Niko found some Thomas + My Little Pony YouTube fanfic videos. Sort of impressed with the execution... where does one learn to do this?",
  "id" : 389452940169080832,
  "created_at" : "2013-10-13 18:09:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tofu",
      "screen_name" : "tofu_product",
      "indices" : [ 0, 13 ],
      "id_str" : "1918202534",
      "id" : 1918202534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596909205, -122.2754187976 ]
  },
  "id_str" : "389268182545883136",
  "in_reply_to_user_id" : 1918202534,
  "text" : "@tofu_product Should I got to bed or watch the Daily Show?",
  "id" : 389268182545883136,
  "created_at" : "2013-10-13 05:55:41 +0000",
  "in_reply_to_screen_name" : "tofu_product",
  "in_reply_to_user_id_str" : "1918202534",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389254665977606144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595801955, -122.2755202187 ]
  },
  "id_str" : "389263879684911104",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Ooh really???",
  "id" : 389263879684911104,
  "in_reply_to_status_id" : 389254665977606144,
  "created_at" : "2013-10-13 05:38:35 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Morelli",
      "screen_name" : "pmorelli",
      "indices" : [ 0, 9 ],
      "id_str" : "14161459",
      "id" : 14161459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389238453721780224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598248633, -122.2755505611 ]
  },
  "id_str" : "389263772906303488",
  "in_reply_to_user_id" : 14161459,
  "text" : "@pmorelli I learn from the best.",
  "id" : 389263772906303488,
  "in_reply_to_status_id" : 389238453721780224,
  "created_at" : "2013-10-13 05:38:10 +0000",
  "in_reply_to_screen_name" : "pmorelli",
  "in_reply_to_user_id_str" : "14161459",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/frontback.me\" rel=\"nofollow\"\u003EFrontback\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "frontback",
      "indices" : [ 38, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/yFZWGMwsq8",
      "expanded_url" : "http:\/\/frontback.me\/p\/QjZicyy0",
      "display_url" : "frontback.me\/p\/QjZicyy0"
    } ]
  },
  "geo" : { },
  "id_str" : "389236783353192448",
  "text" : "8:36pm Mini-me http:\/\/t.co\/yFZWGMwsq8 #frontback",
  "id" : 389236783353192448,
  "created_at" : "2013-10-13 03:50:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinterest",
      "screen_name" : "Pinterest",
      "indices" : [ 8, 18 ],
      "id_str" : "106837463",
      "id" : 106837463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8632063463, -122.2789927562 ]
  },
  "id_str" : "389197801512386560",
  "text" : "Oops my @Pinterest got hacked. On the plus side I've started a new amazing diet plan that's free all month.",
  "id" : 389197801512386560,
  "created_at" : "2013-10-13 01:16:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/389163871144923137\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/yytS4X6JnY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWaWepPCMAAsXFw.jpg",
      "id_str" : "389163871023280128",
      "id" : 389163871023280128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWaWepPCMAAsXFw.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yytS4X6JnY"
    } ],
    "hashtags" : [ {
      "text" : "california",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "wildcatcanyon",
      "indices" : [ 12, 26 ]
    }, {
      "text" : "picnic",
      "indices" : [ 27, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.9620762868, -122.3021881656 ]
  },
  "id_str" : "389163871144923137",
  "text" : "#california #wildcatcanyon #picnic http:\/\/t.co\/yytS4X6JnY",
  "id" : 389163871144923137,
  "created_at" : "2013-10-12 23:01:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Sharples",
      "screen_name" : "fredsharples",
      "indices" : [ 0, 13 ],
      "id_str" : "18338254",
      "id" : 18338254
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389157125475160064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.9620545358, -122.3021646963 ]
  },
  "id_str" : "389163212978925568",
  "in_reply_to_user_id" : 18338254,
  "text" : "@fredsharples So far away then, so delicious now. Cheers and congrats!",
  "id" : 389163212978925568,
  "in_reply_to_status_id" : 389157125475160064,
  "created_at" : "2013-10-12 22:58:34 +0000",
  "in_reply_to_screen_name" : "fredsharples",
  "in_reply_to_user_id_str" : "18338254",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/BqDaIuKrbD",
      "expanded_url" : "http:\/\/flic.kr\/p\/gAmEXv",
      "display_url" : "flic.kr\/p\/gAmEXv"
    } ]
  },
  "geo" : { },
  "id_str" : "389153683491287040",
  "text" : "Picnic on a hill, drinking a bottle of wine we bought 5 years ago on our honeymoon http:\/\/t.co\/BqDaIuKrbD",
  "id" : 389153683491287040,
  "created_at" : "2013-10-12 22:20:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/389123363370582016\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/gXHD86d4Dn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWZxox6CIAEhOys.jpg",
      "id_str" : "389123363219578881",
      "id" : 389123363219578881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWZxox6CIAEhOys.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gXHD86d4Dn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.9192182748, -122.2360432987 ]
  },
  "id_str" : "389123363370582016",
  "text" : "Spot the buzzard. Spot the lens crack. http:\/\/t.co\/gXHD86d4Dn",
  "id" : 389123363370582016,
  "created_at" : "2013-10-12 20:20:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 11, 21 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 22, 36 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thefinitelyamusingone",
      "indices" : [ 45, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388917149504270337",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597046668, -122.2755350546 ]
  },
  "id_str" : "388917318815739904",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april @kellianne @buster_ebooks Thanks. #thefinitelyamusingone",
  "id" : 388917318815739904,
  "in_reply_to_status_id" : 388917149504270337,
  "created_at" : "2013-10-12 06:41:29 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whitney erin boesel",
      "screen_name" : "weboesel",
      "indices" : [ 0, 9 ],
      "id_str" : "264101497",
      "id" : 264101497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388871312677941248",
  "geo" : { },
  "id_str" : "388885457792008192",
  "in_reply_to_user_id" : 264101497,
  "text" : "@weboesel Ha, that's awesome.",
  "id" : 388885457792008192,
  "in_reply_to_status_id" : 388871312677941248,
  "created_at" : "2013-10-12 04:34:52 +0000",
  "in_reply_to_screen_name" : "weboesel",
  "in_reply_to_user_id_str" : "264101497",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/cKk9iECkCL",
      "expanded_url" : "http:\/\/flic.kr\/p\/gz1jXA",
      "display_url" : "flic.kr\/p\/gz1jXA"
    } ]
  },
  "geo" : { },
  "id_str" : "388876435198603264",
  "text" : "8:36pm Niko showing me how he can suck his stomach in http:\/\/t.co\/cKk9iECkCL",
  "id" : 388876435198603264,
  "created_at" : "2013-10-12 03:59:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aiko",
      "screen_name" : "twerpherder",
      "indices" : [ 0, 12 ],
      "id_str" : "304743558",
      "id" : 304743558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388862729424887808",
  "in_reply_to_user_id" : 304743558,
  "text" : "@twerpherder Your Twitter handle just cracked me up.",
  "id" : 388862729424887808,
  "created_at" : "2013-10-12 03:04:34 +0000",
  "in_reply_to_screen_name" : "twerpherder",
  "in_reply_to_user_id_str" : "304743558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tofu",
      "screen_name" : "tofu_product",
      "indices" : [ 0, 13 ],
      "id_str" : "1918202534",
      "id" : 1918202534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763375025, -122.4173957298 ]
  },
  "id_str" : "388744044806807552",
  "in_reply_to_user_id" : 1918202534,
  "text" : "@tofu_product Hey Tof.",
  "id" : 388744044806807552,
  "created_at" : "2013-10-11 19:12:57 +0000",
  "in_reply_to_screen_name" : "tofu_product",
  "in_reply_to_user_id_str" : "1918202534",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whitney erin boesel",
      "screen_name" : "weboesel",
      "indices" : [ 0, 9 ],
      "id_str" : "264101497",
      "id" : 264101497
    }, {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 86, 102 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388722926695874560",
  "geo" : { },
  "id_str" : "388723272272990208",
  "in_reply_to_user_id" : 264101497,
  "text" : "@weboesel I unfortunately can't make it this time. But you should say hi to my friend @ameliagreenhall if you haven't met her yet.",
  "id" : 388723272272990208,
  "in_reply_to_status_id" : 388722926695874560,
  "created_at" : "2013-10-11 17:50:24 +0000",
  "in_reply_to_screen_name" : "weboesel",
  "in_reply_to_user_id_str" : "264101497",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whitney erin boesel",
      "screen_name" : "weboesel",
      "indices" : [ 0, 9 ],
      "id_str" : "264101497",
      "id" : 264101497
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "qs13",
      "indices" : [ 34, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388722239228493824",
  "geo" : { },
  "id_str" : "388722699377197056",
  "in_reply_to_user_id" : 264101497,
  "text" : "@weboesel Thanks for livetweeting #qs13, Whitney! I'm watching jealously from down the street.",
  "id" : 388722699377197056,
  "in_reply_to_status_id" : 388722239228493824,
  "created_at" : "2013-10-11 17:48:08 +0000",
  "in_reply_to_screen_name" : "weboesel",
  "in_reply_to_user_id_str" : "264101497",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Fujiu",
      "screen_name" : "ryanfujiu",
      "indices" : [ 3, 13 ],
      "id_str" : "29645492",
      "id" : 29645492
    }, {
      "name" : "ann friedman",
      "screen_name" : "annfriedman",
      "indices" : [ 60, 72 ],
      "id_str" : "20153725",
      "id" : 20153725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/LdcRpkNcoO",
      "expanded_url" : "http:\/\/bit.ly\/1ecoBYD",
      "display_url" : "bit.ly\/1ecoBYD"
    } ]
  },
  "geo" : { },
  "id_str" : "388712036466565120",
  "text" : "RT @ryanfujiu: How Tinder Solved Online Dating for Women by @annfriedman http:\/\/t.co\/LdcRpkNcoO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ann friedman",
        "screen_name" : "annfriedman",
        "indices" : [ 45, 57 ],
        "id_str" : "20153725",
        "id" : 20153725
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/LdcRpkNcoO",
        "expanded_url" : "http:\/\/bit.ly\/1ecoBYD",
        "display_url" : "bit.ly\/1ecoBYD"
      } ]
    },
    "geo" : { },
    "id_str" : "388711121391452160",
    "text" : "How Tinder Solved Online Dating for Women by @annfriedman http:\/\/t.co\/LdcRpkNcoO",
    "id" : 388711121391452160,
    "created_at" : "2013-10-11 17:02:07 +0000",
    "user" : {
      "name" : "Ryan Fujiu",
      "screen_name" : "ryanfujiu",
      "protected" : false,
      "id_str" : "29645492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458483495652696064\/g36y_x78_normal.jpeg",
      "id" : 29645492,
      "verified" : false
    }
  },
  "id" : 388712036466565120,
  "created_at" : "2013-10-11 17:05:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7936246771, -122.3961087735 ]
  },
  "id_str" : "388708830416084992",
  "text" : "New word: rantifesto.",
  "id" : 388708830416084992,
  "created_at" : "2013-10-11 16:53:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thefutureisweird",
      "indices" : [ 65, 82 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388703805271191552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.793670756, -122.3958715183 ]
  },
  "id_str" : "388708062912970752",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz So would the Dread Pirate Roberts (not the Silk Road one). #thefutureisweird",
  "id" : 388708062912970752,
  "in_reply_to_status_id" : 388703805271191552,
  "created_at" : "2013-10-11 16:49:58 +0000",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara M. Watson",
      "screen_name" : "smwat",
      "indices" : [ 0, 6 ],
      "id_str" : "20609587",
      "id" : 20609587
    }, {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 37, 53 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388704000658268160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8156795487, -122.2703534778 ]
  },
  "id_str" : "388707898563383297",
  "in_reply_to_user_id" : 20609587,
  "text" : "@smwat Yeah. :( Hey, you should meet @ameliagreenhall!",
  "id" : 388707898563383297,
  "in_reply_to_status_id" : 388704000658268160,
  "created_at" : "2013-10-11 16:49:19 +0000",
  "in_reply_to_screen_name" : "smwat",
  "in_reply_to_user_id_str" : "20609587",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara M. Watson",
      "screen_name" : "smwat",
      "indices" : [ 0, 6 ],
      "id_str" : "20609587",
      "id" : 20609587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388702841012908032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8335673994, -122.2668922182 ]
  },
  "id_str" : "388703758663684096",
  "in_reply_to_user_id" : 20609587,
  "text" : "@smwat Sadly not gonna make it this time. Jealous, and there in spirit. (Plus lurking on the hashtag stream.)",
  "id" : 388703758663684096,
  "in_reply_to_status_id" : 388702841012908032,
  "created_at" : "2013-10-11 16:32:52 +0000",
  "in_reply_to_screen_name" : "smwat",
  "in_reply_to_user_id_str" : "20609587",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "tofu",
      "screen_name" : "tofu_product",
      "indices" : [ 13, 26 ],
      "id_str" : "1918202534",
      "id" : 1918202534
    }, {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 95, 109 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388702698755088384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8532461858, -122.270548926 ]
  },
  "id_str" : "388703345633816576",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz Ha, is @tofu_product not a bot? Yeah, I do find myself being stylistically influenced by @buster_ebooks.",
  "id" : 388703345633816576,
  "in_reply_to_status_id" : 388702698755088384,
  "created_at" : "2013-10-11 16:31:14 +0000",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388695132947890176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8532321361, -122.2705461897 ]
  },
  "id_str" : "388702392897650688",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz I'm not sure what more Markov than Markov means but I agree.",
  "id" : 388702392897650688,
  "in_reply_to_status_id" : 388695132947890176,
  "created_at" : "2013-10-11 16:27:26 +0000",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8532321361, -122.2705461897 ]
  },
  "id_str" : "388701585250856961",
  "text" : "There are two kinds of days: \"head down\" days (focus), and \"head up\" days (explore). And the third kind requires you do both at once.",
  "id" : 388701585250856961,
  "created_at" : "2013-10-11 16:24:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First Class Meh",
      "screen_name" : "TheAlexNevil",
      "indices" : [ 3, 16 ],
      "id_str" : "246035604",
      "id" : 246035604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388683475508662273",
  "text" : "RT @TheAlexNevil: How does a cricket know if his joke has bombed?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "369608361622646784",
    "text" : "How does a cricket know if his joke has bombed?",
    "id" : 369608361622646784,
    "created_at" : "2013-08-19 23:54:35 +0000",
    "user" : {
      "name" : "First Class Meh",
      "screen_name" : "TheAlexNevil",
      "protected" : false,
      "id_str" : "246035604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000848282925\/06922a7c50f18fe61fafa9b74b06cfa0_normal.jpeg",
      "id" : 246035604,
      "verified" : false
    }
  },
  "id" : 388683475508662273,
  "created_at" : "2013-10-11 15:12:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/D5ZFNv2Dfq",
      "expanded_url" : "http:\/\/flic.kr\/p\/gxpgiN",
      "display_url" : "flic.kr\/p\/gxpgiN"
    } ]
  },
  "geo" : { },
  "id_str" : "388508871024984064",
  "text" : "8:36pm Eating and listening to a white noise boom box http:\/\/t.co\/D5ZFNv2Dfq",
  "id" : 388508871024984064,
  "created_at" : "2013-10-11 03:38:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Quintano",
      "screen_name" : "AnthonyQuintano",
      "indices" : [ 3, 19 ],
      "id_str" : "8241232",
      "id" : 8241232
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AnthonyQuintano\/status\/388432844210450432\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/uDFQncfIle",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWP9nSLCMAEYuGN.png",
      "id_str" : "388432844218839041",
      "id" : 388432844218839041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWP9nSLCMAEYuGN.png",
      "sizes" : [ {
        "h" : 775,
        "resize" : "fit",
        "w" : 980
      }, {
        "h" : 775,
        "resize" : "fit",
        "w" : 980
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 474,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/uDFQncfIle"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/39TwCl0NXS",
      "expanded_url" : "http:\/\/www.socialguide.com\/nielsen-twitter-tv-ratings\/",
      "display_url" : "socialguide.com\/nielsen-twitte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388483035697401858",
  "text" : "RT @AnthonyQuintano: First set of stats from Nielsen's new Twitter TV rankings are in http:\/\/t.co\/39TwCl0NXS http:\/\/t.co\/uDFQncfIle",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AnthonyQuintano\/status\/388432844210450432\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/uDFQncfIle",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BWP9nSLCMAEYuGN.png",
        "id_str" : "388432844218839041",
        "id" : 388432844218839041,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWP9nSLCMAEYuGN.png",
        "sizes" : [ {
          "h" : 775,
          "resize" : "fit",
          "w" : 980
        }, {
          "h" : 775,
          "resize" : "fit",
          "w" : 980
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 269,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 474,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/uDFQncfIle"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/39TwCl0NXS",
        "expanded_url" : "http:\/\/www.socialguide.com\/nielsen-twitter-tv-ratings\/",
        "display_url" : "socialguide.com\/nielsen-twitte\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "388432844210450432",
    "text" : "First set of stats from Nielsen's new Twitter TV rankings are in http:\/\/t.co\/39TwCl0NXS http:\/\/t.co\/uDFQncfIle",
    "id" : 388432844210450432,
    "created_at" : "2013-10-10 22:36:21 +0000",
    "user" : {
      "name" : "Anthony Quintano",
      "screen_name" : "AnthonyQuintano",
      "protected" : false,
      "id_str" : "8241232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/457293615652278273\/8pKz8-dV_normal.jpeg",
      "id" : 8241232,
      "verified" : true
    }
  },
  "id" : 388483035697401858,
  "created_at" : "2013-10-11 01:55:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Werner Vogels",
      "screen_name" : "Werner",
      "indices" : [ 3, 10 ],
      "id_str" : "113963",
      "id" : 113963
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AWS",
      "indices" : [ 62, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/DMMirYO8Xv",
      "expanded_url" : "http:\/\/wv.ly\/162bV15",
      "display_url" : "wv.ly\/162bV15"
    } ]
  },
  "geo" : { },
  "id_str" : "388393752500269057",
  "text" : "RT @Werner: Introducing AWS Activate \u2013 Supporting Startups on #AWS  http:\/\/t.co\/DMMirYO8Xv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AWS",
        "indices" : [ 50, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/DMMirYO8Xv",
        "expanded_url" : "http:\/\/wv.ly\/162bV15",
        "display_url" : "wv.ly\/162bV15"
      } ]
    },
    "geo" : { },
    "id_str" : "388238148167544832",
    "text" : "Introducing AWS Activate \u2013 Supporting Startups on #AWS  http:\/\/t.co\/DMMirYO8Xv",
    "id" : 388238148167544832,
    "created_at" : "2013-10-10 09:42:42 +0000",
    "user" : {
      "name" : "Werner Vogels",
      "screen_name" : "Werner",
      "protected" : false,
      "id_str" : "113963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430747926944415745\/vIhN5-Qi_normal.jpeg",
      "id" : 113963,
      "verified" : false
    }
  },
  "id" : 388393752500269057,
  "created_at" : "2013-10-10 20:01:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Bell",
      "screen_name" : "workjon",
      "indices" : [ 0, 8 ],
      "id_str" : "228178806",
      "id" : 228178806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388362332281126912",
  "geo" : { },
  "id_str" : "388363244261232641",
  "in_reply_to_user_id" : 228178806,
  "text" : "@workjon It's an experiment so it'll probably change over time. But my personal experience so far has been that it's pretty rare.",
  "id" : 388363244261232641,
  "in_reply_to_status_id" : 388362332281126912,
  "created_at" : "2013-10-10 17:59:47 +0000",
  "in_reply_to_screen_name" : "workjon",
  "in_reply_to_user_id_str" : "228178806",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388355906225709056",
  "geo" : { },
  "id_str" : "388356064602648576",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward I didn't, but I too love the approach. :)",
  "id" : 388356064602648576,
  "in_reply_to_status_id" : 388355906225709056,
  "created_at" : "2013-10-10 17:31:15 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Hage",
      "screen_name" : "JackPointNL",
      "indices" : [ 0, 12 ],
      "id_str" : "44141700",
      "id" : 44141700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388353324472619008",
  "geo" : { },
  "id_str" : "388353492164702208",
  "in_reply_to_user_id" : 44141700,
  "text" : "@JackPointNL No, but the idea is near and dear to my heart. :)",
  "id" : 388353492164702208,
  "in_reply_to_status_id" : 388353324472619008,
  "created_at" : "2013-10-10 17:21:02 +0000",
  "in_reply_to_screen_name" : "JackPointNL",
  "in_reply_to_user_id_str" : "44141700",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Event Parrot",
      "screen_name" : "eventparrot",
      "indices" : [ 46, 58 ],
      "id_str" : "1411434049",
      "id" : 1411434049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388348964409311232",
  "text" : "Wanna test another Twitter experiment? Follow @eventparrot for timely DMs when big things happen in the world.",
  "id" : 388348964409311232,
  "created_at" : "2013-10-10 17:03:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Bogan",
      "screen_name" : "waferbaby",
      "indices" : [ 0, 10 ],
      "id_str" : "821753",
      "id" : 821753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388339410829209600",
  "geo" : { },
  "id_str" : "388345256783007745",
  "in_reply_to_user_id" : 821753,
  "text" : "@waferbaby That's pretty rad.",
  "id" : 388345256783007745,
  "in_reply_to_status_id" : 388339410829209600,
  "created_at" : "2013-10-10 16:48:18 +0000",
  "in_reply_to_screen_name" : "waferbaby",
  "in_reply_to_user_id_str" : "821753",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 7, 17 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/eZZvpo0Cne",
      "expanded_url" : "http:\/\/flic.kr\/p\/gvGhCR",
      "display_url" : "flic.kr\/p\/gvGhCR"
    } ]
  },
  "geo" : { },
  "id_str" : "388151013913686016",
  "text" : "8:36pm @Kellianne at the dinner table, by Niko http:\/\/t.co\/eZZvpo0Cne",
  "id" : 388151013913686016,
  "created_at" : "2013-10-10 03:56:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Deterding",
      "screen_name" : "dingstweets",
      "indices" : [ 111, 123 ],
      "id_str" : "14435477",
      "id" : 14435477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/9v2MJTjNyt",
      "expanded_url" : "http:\/\/j.mp\/1e9QhgO",
      "display_url" : "j.mp\/1e9QhgO"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7935867051, -122.3961157616 ]
  },
  "id_str" : "388119375309312001",
  "text" : "A beautiful immersive comic about driving home in the back seat of a car as a kid: http:\/\/t.co\/9v2MJTjNyt \/via @dingstweets",
  "id" : 388119375309312001,
  "created_at" : "2013-10-10 01:50:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robotuaries",
      "screen_name" : "robotuaries",
      "indices" : [ 3, 15 ],
      "id_str" : "1939976834",
      "id" : 1939976834
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 139, 140 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388107239468191744",
  "text" : "RT @robotuaries: Buster, gaming dealer, died today at 89 from a sudden bout with personality disorders. Buster was passionate about life. \/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 122, 129 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388106955723911168",
    "text" : "Buster, gaming dealer, died today at 89 from a sudden bout with personality disorders. Buster was passionate about life. \/@buster",
    "id" : 388106955723911168,
    "created_at" : "2013-10-10 01:01:23 +0000",
    "user" : {
      "name" : "Robotuaries",
      "screen_name" : "robotuaries",
      "protected" : false,
      "id_str" : "1939976834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000555795370\/b61354c016ffef12bbc0e1846a8c4309_normal.png",
      "id" : 1939976834,
      "verified" : false
    }
  },
  "id" : 388107239468191744,
  "created_at" : "2013-10-10 01:02:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    }, {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 12, 22 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/XkUUcdJOZa",
      "expanded_url" : "http:\/\/wayoftheduck.com\/diy-horse-ebooks",
      "display_url" : "wayoftheduck.com\/diy-horse-eboo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "388062403109199873",
  "geo" : { },
  "id_str" : "388069130567299073",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler @ingopixel It's a robot version of me. I explain it a bit here: http:\/\/t.co\/XkUUcdJOZa",
  "id" : 388069130567299073,
  "in_reply_to_status_id" : 388062403109199873,
  "created_at" : "2013-10-09 22:31:05 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388045108567740416",
  "geo" : { },
  "id_str" : "388045329376870400",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel No, I get it. *cry*",
  "id" : 388045329376870400,
  "in_reply_to_status_id" : 388045108567740416,
  "created_at" : "2013-10-09 20:56:30 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388044851733729280",
  "geo" : { },
  "id_str" : "388045109276594176",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Totally. Looks like my job here is done.",
  "id" : 388045109276594176,
  "in_reply_to_status_id" : 388044851733729280,
  "created_at" : "2013-10-09 20:55:38 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388044403530416128",
  "geo" : { },
  "id_str" : "388044671823273984",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Ha! I'm starting to feel like ebook-me is out tweeting me lately.",
  "id" : 388044671823273984,
  "in_reply_to_status_id" : 388044403530416128,
  "created_at" : "2013-10-09 20:53:53 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/I2ExP9JWOi",
      "expanded_url" : "http:\/\/flic.kr\/p\/guhqT1",
      "display_url" : "flic.kr\/p\/guhqT1"
    } ]
  },
  "geo" : { },
  "id_str" : "387835504680775680",
  "text" : "Sleepy heads http:\/\/t.co\/I2ExP9JWOi",
  "id" : 387835504680775680,
  "created_at" : "2013-10-09 07:02:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/5Pl2aCLpDz",
      "expanded_url" : "http:\/\/flic.kr\/p\/guafqn",
      "display_url" : "flic.kr\/p\/guafqn"
    } ]
  },
  "geo" : { },
  "id_str" : "387791662577381376",
  "text" : "8:36pm Taking an evening stroll http:\/\/t.co\/5Pl2aCLpDz",
  "id" : 387791662577381376,
  "created_at" : "2013-10-09 04:08:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Chen",
      "screen_name" : "leftparen",
      "indices" : [ 0, 10 ],
      "id_str" : "78154150",
      "id" : 78154150
    }, {
      "name" : "Hilary Mason",
      "screen_name" : "hmason",
      "indices" : [ 11, 18 ],
      "id_str" : "765548",
      "id" : 765548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387772834921336832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596721829, -122.2755624197 ]
  },
  "id_str" : "387780207119048704",
  "in_reply_to_user_id" : 78154150,
  "text" : "@leftparen @hmason That was a great comment, but doubt people would heed that advice. Maybe with self-driving cars?",
  "id" : 387780207119048704,
  "in_reply_to_status_id" : 387772834921336832,
  "created_at" : "2013-10-09 03:23:00 +0000",
  "in_reply_to_screen_name" : "leftparen",
  "in_reply_to_user_id_str" : "78154150",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hilary Mason",
      "screen_name" : "hmason",
      "indices" : [ 3, 10 ],
      "id_str" : "765548",
      "id" : 765548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/V8fkp1yvcs",
      "expanded_url" : "http:\/\/bit.ly\/GLMVEJ",
      "display_url" : "bit.ly\/GLMVEJ"
    } ]
  },
  "geo" : { },
  "id_str" : "387766931266486272",
  "text" : "RT @hmason: Fascinating. How traffic actually works http:\/\/t.co\/V8fkp1yvcs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/V8fkp1yvcs",
        "expanded_url" : "http:\/\/bit.ly\/GLMVEJ",
        "display_url" : "bit.ly\/GLMVEJ"
      } ]
    },
    "geo" : { },
    "id_str" : "387641177954332672",
    "text" : "Fascinating. How traffic actually works http:\/\/t.co\/V8fkp1yvcs",
    "id" : 387641177954332672,
    "created_at" : "2013-10-08 18:10:33 +0000",
    "user" : {
      "name" : "Hilary Mason",
      "screen_name" : "hmason",
      "protected" : false,
      "id_str" : "765548",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1290564266\/me_square_normal.jpg",
      "id" : 765548,
      "verified" : false
    }
  },
  "id" : 387766931266486272,
  "created_at" : "2013-10-09 02:30:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/sneS0mVSuV",
      "expanded_url" : "http:\/\/nyti.ms\/17j3xJX",
      "display_url" : "nyti.ms\/17j3xJX"
    } ]
  },
  "geo" : { },
  "id_str" : "387669274422030336",
  "text" : "\"What Is the Higgs?\" a beautiful hand-drawn set of slides: http:\/\/t.co\/sneS0mVSuV",
  "id" : 387669274422030336,
  "created_at" : "2013-10-08 20:02:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 0, 14 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387653637133975552",
  "geo" : { },
  "id_str" : "387654074948022273",
  "in_reply_to_user_id" : 226976689,
  "text" : "@marcprecipice Wait, the methodology doesn't have a framework for completing important tasks in absence of time?",
  "id" : 387654074948022273,
  "in_reply_to_status_id" : 387653637133975552,
  "created_at" : "2013-10-08 19:01:48 +0000",
  "in_reply_to_screen_name" : "marcprecipice",
  "in_reply_to_user_id_str" : "226976689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "indices" : [ 18, 30 ],
      "id_str" : "289534689",
      "id" : 289534689
    }, {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 32, 46 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387653521257947136",
  "text" : "I'd read that. RT @seriouspony: @marcprecipice \"The Whatever It Is GitHub, Valve, and Stripe Are Doing Methodology\" should be a book.",
  "id" : 387653521257947136,
  "created_at" : "2013-10-08 18:59:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Goldberg",
      "screen_name" : "bostonsteamer",
      "indices" : [ 0, 14 ],
      "id_str" : "2029651",
      "id" : 2029651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387621518076698625",
  "geo" : { },
  "id_str" : "387622402248540160",
  "in_reply_to_user_id" : 2029651,
  "text" : "@bostonsteamer It was really very thoughtful of them.",
  "id" : 387622402248540160,
  "in_reply_to_status_id" : 387621518076698625,
  "created_at" : "2013-10-08 16:55:57 +0000",
  "in_reply_to_screen_name" : "bostonsteamer",
  "in_reply_to_user_id_str" : "2029651",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Goldberg",
      "screen_name" : "bostonsteamer",
      "indices" : [ 0, 14 ],
      "id_str" : "2029651",
      "id" : 2029651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387439113307037696",
  "geo" : { },
  "id_str" : "387619128967577601",
  "in_reply_to_user_id" : 2029651,
  "text" : "@bostonsteamer Niko knows most of the words to this song now\u2026 and it's been stuck in my head for days!",
  "id" : 387619128967577601,
  "in_reply_to_status_id" : 387439113307037696,
  "created_at" : "2013-10-08 16:42:56 +0000",
  "in_reply_to_screen_name" : "bostonsteamer",
  "in_reply_to_user_id_str" : "2029651",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387445817797533696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596764443, -122.2755633012 ]
  },
  "id_str" : "387467168612237312",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Indeed, but glad it momentarily passed the Turing test!",
  "id" : 387467168612237312,
  "in_reply_to_status_id" : 387445817797533696,
  "created_at" : "2013-10-08 06:39:06 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/wlfqG8cWfI",
      "expanded_url" : "http:\/\/flic.kr\/p\/gsUis8",
      "display_url" : "flic.kr\/p\/gsUis8"
    } ]
  },
  "geo" : { },
  "id_str" : "387429283893084161",
  "text" : "8:36pm Sad to see the Kathy, Patrick, and Georgia heading back home http:\/\/t.co\/wlfqG8cWfI",
  "id" : 387429283893084161,
  "created_at" : "2013-10-08 04:08:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8571699793, -122.2729605531 ]
  },
  "id_str" : "387390857063587840",
  "text" : "Is \"it could always be worse\" optimistic or pessimistic?",
  "id" : 387390857063587840,
  "created_at" : "2013-10-08 01:35:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sandy fleischer",
      "screen_name" : "pescatore",
      "indices" : [ 0, 10 ],
      "id_str" : "2554371",
      "id" : 2554371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387288549785354240",
  "geo" : { },
  "id_str" : "387289730464763905",
  "in_reply_to_user_id" : 2554371,
  "text" : "@pescatore Thanks! You should be able to DM me.",
  "id" : 387289730464763905,
  "in_reply_to_status_id" : 387288549785354240,
  "created_at" : "2013-10-07 18:54:01 +0000",
  "in_reply_to_screen_name" : "pescatore",
  "in_reply_to_user_id_str" : "2554371",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 0, 9 ],
      "id_str" : "14986129",
      "id" : 14986129
    }, {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 16, 30 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387253641263857664",
  "geo" : { },
  "id_str" : "387257545997295616",
  "in_reply_to_user_id" : 14986129,
  "text" : "@irondavy I set @buster_ebooks to 3x an hour, which seems like too much. 1x an hour seems about right.",
  "id" : 387257545997295616,
  "in_reply_to_status_id" : 387253641263857664,
  "created_at" : "2013-10-07 16:46:08 +0000",
  "in_reply_to_screen_name" : "irondavy",
  "in_reply_to_user_id_str" : "14986129",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 0, 11 ],
      "id_str" : "784078",
      "id" : 784078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387208035871252480",
  "geo" : { },
  "id_str" : "387254169028935680",
  "in_reply_to_user_id" : 784078,
  "text" : "@alicetiara Shared via status update no less. Can't wait to read it. Can you please self-narrate an audio version?",
  "id" : 387254169028935680,
  "in_reply_to_status_id" : 387208035871252480,
  "created_at" : "2013-10-07 16:32:43 +0000",
  "in_reply_to_screen_name" : "alicetiara",
  "in_reply_to_user_id_str" : "784078",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/3qejuOoUEQ",
      "expanded_url" : "http:\/\/news.bbc.co.uk\/earth\/hi\/earth_news\/newsid_8135000\/8135844.stm",
      "display_url" : "news.bbc.co.uk\/earth\/hi\/earth\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859716, -122.275595 ]
  },
  "id_str" : "387107242358476800",
  "text" : "\"There is a species of spider that builds models of itself, which it uses as decoys to distract predators.\" http:\/\/t.co\/3qejuOoUEQ",
  "id" : 387107242358476800,
  "created_at" : "2013-10-07 06:48:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/nNGQ3yufF2",
      "expanded_url" : "http:\/\/flic.kr\/p\/grjK7t",
      "display_url" : "flic.kr\/p\/grjK7t"
    } ]
  },
  "geo" : { },
  "id_str" : "387075484057890816",
  "text" : "8:36pm Hanging with Georgia (and her parents) after a small but close earthquake http:\/\/t.co\/nNGQ3yufF2",
  "id" : 387075484057890816,
  "created_at" : "2013-10-07 04:42:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/i8dO5stvhH",
      "expanded_url" : "http:\/\/earthquake.usgs.gov\/earthquakes\/eventpage\/nc72082611",
      "display_url" : "earthquake.usgs.gov\/earthquakes\/ev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387073473475932160",
  "text" : "\"Due to a lapse in Federal funding, the USGS Earthquake Hazards Program has suspended most of its operations.\" http:\/\/t.co\/i8dO5stvhH",
  "id" : 387073473475932160,
  "created_at" : "2013-10-07 04:34:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "EmilyGannett",
      "screen_name" : "EmilyGannett",
      "indices" : [ 8, 21 ],
      "id_str" : "11133492",
      "id" : 11133492
    }, {
      "name" : "Sloane Crosley",
      "screen_name" : "askanyone",
      "indices" : [ 22, 32 ],
      "id_str" : "27699224",
      "id" : 27699224
    }, {
      "name" : "Scribe Winery",
      "screen_name" : "scribewinery",
      "indices" : [ 87, 100 ],
      "id_str" : "209727447",
      "id" : 209727447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386971228432396288",
  "geo" : { },
  "id_str" : "386972397829496832",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @EmilyGannett @askanyone There's some serious competition for the Mayorship of @scribewinery going on.",
  "id" : 386972397829496832,
  "in_reply_to_status_id" : 386971228432396288,
  "created_at" : "2013-10-06 21:53:03 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/386970141986013184\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Us95SAn8aS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BV7LSy3CEAA92UM.jpg",
      "id_str" : "386970141751119872",
      "id" : 386970141751119872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BV7LSy3CEAA92UM.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Us95SAn8aS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386970141986013184",
  "text" : "http:\/\/t.co\/Us95SAn8aS",
  "id" : 386970141986013184,
  "created_at" : "2013-10-06 21:44:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/9UjOyKH1pB",
      "expanded_url" : "https:\/\/vine.co\/v\/hXenxMWgKQq",
      "display_url" : "vine.co\/v\/hXenxMWgKQq"
    } ]
  },
  "geo" : { },
  "id_str" : "386945757317971968",
  "text" : "Another ugly day https:\/\/t.co\/9UjOyKH1pB",
  "id" : 386945757317971968,
  "created_at" : "2013-10-06 20:07:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 0, 7 ],
      "id_str" : "23640904",
      "id" : 23640904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386650943502045184",
  "geo" : { },
  "id_str" : "386738519072190466",
  "in_reply_to_user_id" : 23640904,
  "text" : "@emoore Woah that's amazing!",
  "id" : 386738519072190466,
  "in_reply_to_status_id" : 386650943502045184,
  "created_at" : "2013-10-06 06:23:42 +0000",
  "in_reply_to_screen_name" : "emoore",
  "in_reply_to_user_id_str" : "23640904",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samir mezrahi",
      "screen_name" : "samir",
      "indices" : [ 0, 6 ],
      "id_str" : "115396965",
      "id" : 115396965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386701142568103936",
  "geo" : { },
  "id_str" : "386701316312932352",
  "in_reply_to_user_id" : 115396965,
  "text" : "@samir You have to restore from backup with iOS 7.02. I think that's the only solution.",
  "id" : 386701316312932352,
  "in_reply_to_status_id" : 386701142568103936,
  "created_at" : "2013-10-06 03:55:53 +0000",
  "in_reply_to_screen_name" : "samir",
  "in_reply_to_user_id_str" : "115396965",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386700990759444480",
  "text" : "Got locked out of my iPhone again due to using their beta build of iOS 7. Stupid.",
  "id" : 386700990759444480,
  "created_at" : "2013-10-06 03:54:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 46, 56 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/RZBjN8NuPo",
      "expanded_url" : "http:\/\/flic.kr\/p\/gnZopp",
      "display_url" : "flic.kr\/p\/gnZopp"
    } ]
  },
  "geo" : { },
  "id_str" : "386345072583016448",
  "text" : "8:36pm Celebrating 5 awesome crazy years with @kellianne  http:\/\/t.co\/RZBjN8NuPo",
  "id" : 386345072583016448,
  "created_at" : "2013-10-05 04:20:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omid Ashtari",
      "screen_name" : "omid",
      "indices" : [ 0, 5 ],
      "id_str" : "114971521",
      "id" : 114971521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386302032723709952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8695547429, -122.2662896976 ]
  },
  "id_str" : "386338866291953664",
  "in_reply_to_user_id" : 114971521,
  "text" : "@omid Book called The Reason I Jump by a 13-yo autistic boy from Japan. Amazing book.",
  "id" : 386338866291953664,
  "in_reply_to_status_id" : 386302032723709952,
  "created_at" : "2013-10-05 03:55:38 +0000",
  "in_reply_to_screen_name" : "omid",
  "in_reply_to_user_id_str" : "114971521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 71, 81 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/OnIxW4gdLk",
      "expanded_url" : "http:\/\/flic.kr\/p\/5FGNAK",
      "display_url" : "flic.kr\/p\/5FGNAK"
    } ]
  },
  "geo" : { },
  "id_str" : "386311766638338048",
  "text" : "Happy 5th anniversary to my beauteous maximus forevercore universalis, @kellianne! http:\/\/t.co\/OnIxW4gdLk",
  "id" : 386311766638338048,
  "created_at" : "2013-10-05 02:07:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8003138477, -122.281700955 ]
  },
  "id_str" : "386296034105630720",
  "text" : "\"It's hard for us people with autism to be around other people because we think we're getting on your nerves. We get used to being alone.\"",
  "id" : 386296034105630720,
  "created_at" : "2013-10-05 01:05:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/386290566712946688\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/Y5Hm4bkQnM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVxhOUOCUAA1wMZ.jpg",
      "id_str" : "386290566620663808",
      "id" : 386290566620663808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVxhOUOCUAA1wMZ.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/Y5Hm4bkQnM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7791969312, -122.41427692 ]
  },
  "id_str" : "386290566712946688",
  "text" : "This book (The Reason I Jump) is blowing my mind. http:\/\/t.co\/Y5Hm4bkQnM",
  "id" : 386290566712946688,
  "created_at" : "2013-10-05 00:43:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.vizify.com\" rel=\"nofollow\"\u003EVizify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 4, 13 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 15, 25 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 27, 37 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 39, 49 ],
      "id_str" : "7943892",
      "id" : 7943892
    }, {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 51, 64 ],
      "id_str" : "14095370",
      "id" : 14095370
    }, {
      "name" : "Vizify",
      "screen_name" : "vizify",
      "indices" : [ 132, 139 ],
      "id_str" : "295513152",
      "id" : 295513152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/SCEIx1iZ9A",
      "expanded_url" : "https:\/\/www.vizify.com\/buster-benson\/connections?s=twitter&u=430&f=8309&t=connections_share_inner_circle",
      "display_url" : "vizify.com\/buster-benson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386238698737909760",
  "text" : "Hey @RickWebb, @kellianne, @avantgame, @ingopixel, @OffbeatAriel, you're in my inner circle on Twitter: https:\/\/t.co\/SCEIx1iZ9A via @vizify",
  "id" : 386238698737909760,
  "created_at" : "2013-10-04 21:17:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 10, 20 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386225359802597376",
  "geo" : { },
  "id_str" : "386226022879739905",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @kellianne Yup it's today!",
  "id" : 386226022879739905,
  "in_reply_to_status_id" : 386225359802597376,
  "created_at" : "2013-10-04 20:27:14 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 10, 15 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 16, 22 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386222807866433536",
  "geo" : { },
  "id_str" : "386223239212457984",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @buzz @couch Pruning is essential for a healthy tree\/social graph.",
  "id" : 386223239212457984,
  "in_reply_to_status_id" : 386222807866433536,
  "created_at" : "2013-10-04 20:16:10 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 10, 15 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 16, 22 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386219425663549440",
  "geo" : { },
  "id_str" : "386221119637684224",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @buzz @couch I unfriend on Facebook pretty often. My line is if I wouldn't stop to say hello on the street.",
  "id" : 386221119637684224,
  "in_reply_to_status_id" : 386219425663549440,
  "created_at" : "2013-10-04 20:07:45 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 6, 15 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 16, 22 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386219693721546752",
  "geo" : { },
  "id_str" : "386220300553039872",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz @rickwebb @couch You can always just start @-mentioning them in all your tweets so they still get them.",
  "id" : 386220300553039872,
  "in_reply_to_status_id" : 386219693721546752,
  "created_at" : "2013-10-04 20:04:29 +0000",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 6, 12 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386219272680517633",
  "geo" : { },
  "id_str" : "386219464741498880",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz @couch I've been inoculating myself with the Sayonara app. It stings a little, but then again life is suffering. :)",
  "id" : 386219464741498880,
  "in_reply_to_status_id" : 386219272680517633,
  "created_at" : "2013-10-04 20:01:10 +0000",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 6, 12 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386217937516105728",
  "geo" : { },
  "id_str" : "386218671871258624",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz @couch Really? I think people overestimate it. First of all, most people never know. Second, you can blame it on a bug. :)",
  "id" : 386218671871258624,
  "in_reply_to_status_id" : 386217937516105728,
  "created_at" : "2013-10-04 19:58:01 +0000",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 0, 6 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 7, 12 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Magic Recs",
      "screen_name" : "MagicRecs",
      "indices" : [ 13, 23 ],
      "id_str" : "1270746139",
      "id" : 1270746139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386205753129713664",
  "geo" : { },
  "id_str" : "386217236370710528",
  "in_reply_to_user_id" : 631823,
  "text" : "@couch @buzz @MagicRecs I think it's healthy to have a low follow threshold as long as it's paired with a low unfollow threshold.",
  "id" : 386217236370710528,
  "in_reply_to_status_id" : 386205753129713664,
  "created_at" : "2013-10-04 19:52:19 +0000",
  "in_reply_to_screen_name" : "couch",
  "in_reply_to_user_id_str" : "631823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 3, 12 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Steve Cheney",
      "screen_name" : "stevecheney",
      "indices" : [ 63, 75 ],
      "id_str" : "20495458",
      "id" : 20495458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/s9y4CkX2zh",
      "expanded_url" : "http:\/\/stevecheney.com\/how-apple-ibeacon-will-transform-local-commerce\/",
      "display_url" : "stevecheney.com\/how-apple-ibea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386142400856354816",
  "text" : "RT @arainert: Best piece I've read on iBeacon + Apple yet from @stevecheney. The potential here is *really* exciting: http:\/\/t.co\/s9y4CkX2zh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Cheney",
        "screen_name" : "stevecheney",
        "indices" : [ 49, 61 ],
        "id_str" : "20495458",
        "id" : 20495458
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/s9y4CkX2zh",
        "expanded_url" : "http:\/\/stevecheney.com\/how-apple-ibeacon-will-transform-local-commerce\/",
        "display_url" : "stevecheney.com\/how-apple-ibea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "386125115005493248",
    "text" : "Best piece I've read on iBeacon + Apple yet from @stevecheney. The potential here is *really* exciting: http:\/\/t.co\/s9y4CkX2zh",
    "id" : 386125115005493248,
    "created_at" : "2013-10-04 13:46:15 +0000",
    "user" : {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "protected" : false,
      "id_str" : "7482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444089158274154496\/ZePPNQzQ_normal.jpeg",
      "id" : 7482,
      "verified" : false
    }
  },
  "id" : 386142400856354816,
  "created_at" : "2013-10-04 14:54:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 6, 15 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386002190093279232",
  "geo" : { },
  "id_str" : "386002341796671488",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz @RickWebb I've had some wine.",
  "id" : 386002341796671488,
  "in_reply_to_status_id" : 386002190093279232,
  "created_at" : "2013-10-04 05:38:24 +0000",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 6, 15 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Kate Lee",
      "screen_name" : "katelaurielee",
      "indices" : [ 16, 30 ],
      "id_str" : "16063378",
      "id" : 16063378
    }, {
      "name" : "Abe Burmeister",
      "screen_name" : "abe1x",
      "indices" : [ 31, 37 ],
      "id_str" : "676033",
      "id" : 676033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386000901246550016",
  "geo" : { },
  "id_str" : "386001216364232704",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz @RickWebb @katelaurielee @abe1x It's funny. Like many false dichotomies are.",
  "id" : 386001216364232704,
  "in_reply_to_status_id" : 386000901246550016,
  "created_at" : "2013-10-04 05:33:56 +0000",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 0, 13 ],
      "id_str" : "1784841",
      "id" : 1784841
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 14, 23 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386000410642636800",
  "geo" : { },
  "id_str" : "386000968082411520",
  "in_reply_to_user_id" : 1784841,
  "text" : "@sawickipedia @RickWebb You're definitely not the target audience, then. :)",
  "id" : 386000968082411520,
  "in_reply_to_status_id" : 386000410642636800,
  "created_at" : "2013-10-04 05:32:57 +0000",
  "in_reply_to_screen_name" : "sawickipedia",
  "in_reply_to_user_id_str" : "1784841",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 6, 15 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385999835171930112",
  "geo" : { },
  "id_str" : "386000097416183808",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz @RickWebb Posts like Rick's post. Personal, but accessible to a wide audience beyond our own social graphs.",
  "id" : 386000097416183808,
  "in_reply_to_status_id" : 385999835171930112,
  "created_at" : "2013-10-04 05:29:29 +0000",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 10, 23 ],
      "id_str" : "1784841",
      "id" : 1784841
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 68, 75 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385999507353505792",
  "geo" : { },
  "id_str" : "385999907124805632",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @sawickipedia Yeah, so wrong. I have been really enjoying @Medium recently, I think you would too.",
  "id" : 385999907124805632,
  "in_reply_to_status_id" : 385999507353505792,
  "created_at" : "2013-10-04 05:28:44 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 10, 17 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Kate Lee",
      "screen_name" : "katelaurielee",
      "indices" : [ 18, 32 ],
      "id_str" : "16063378",
      "id" : 16063378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385999135104860161",
  "geo" : { },
  "id_str" : "385999378348912641",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @Medium @katelaurielee Wait, I can get you in...",
  "id" : 385999378348912641,
  "in_reply_to_status_id" : 385999135104860161,
  "created_at" : "2013-10-04 05:26:37 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 10, 23 ],
      "id_str" : "1784841",
      "id" : 1784841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385998976484651008",
  "geo" : { },
  "id_str" : "385999249663479808",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @sawickipedia Last reader standing. How many of your friends are on Tumblr? It seems more of a professional outlet for you.",
  "id" : 385999249663479808,
  "in_reply_to_status_id" : 385998976484651008,
  "created_at" : "2013-10-04 05:26:07 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 10, 23 ],
      "id_str" : "1784841",
      "id" : 1784841
    }, {
      "name" : "LiveJournal",
      "screen_name" : "LiveJournal",
      "indices" : [ 55, 67 ],
      "id_str" : "15729357",
      "id" : 15729357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385998526410674176",
  "geo" : { },
  "id_str" : "385998822012227585",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @sawickipedia Well then it should've been on @LiveJournal.",
  "id" : 385998822012227585,
  "in_reply_to_status_id" : 385998526410674176,
  "created_at" : "2013-10-04 05:24:25 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 0, 13 ],
      "id_str" : "1784841",
      "id" : 1784841
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 14, 23 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385998443539218432",
  "geo" : { },
  "id_str" : "385998740491739136",
  "in_reply_to_user_id" : 1784841,
  "text" : "@sawickipedia @RickWebb Contextual comments, mostly. And it probably would've gotten a bunch more people reading it.",
  "id" : 385998740491739136,
  "in_reply_to_status_id" : 385998443539218432,
  "created_at" : "2013-10-04 05:24:05 +0000",
  "in_reply_to_screen_name" : "sawickipedia",
  "in_reply_to_user_id_str" : "1784841",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 46, 53 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385836539252867072",
  "geo" : { },
  "id_str" : "385998326979506177",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb This post should've totally been on @Medium.",
  "id" : 385998326979506177,
  "in_reply_to_status_id" : 385836539252867072,
  "created_at" : "2013-10-04 05:22:27 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/x9J8lIVNWH",
      "expanded_url" : "http:\/\/flic.kr\/p\/gmDJVk",
      "display_url" : "flic.kr\/p\/gmDJVk"
    } ]
  },
  "geo" : { },
  "id_str" : "385973101278031872",
  "text" : "8:36pm Kathy and Patrick in town for a while! http:\/\/t.co\/x9J8lIVNWH",
  "id" : 385973101278031872,
  "created_at" : "2013-10-04 03:42:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Margaret E. Atwood",
      "screen_name" : "MargaretAtwood",
      "indices" : [ 3, 18 ],
      "id_str" : "54730258",
      "id" : 54730258
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 40, 48 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385939957841293313",
  "text" : "RT @MargaretAtwood: What is here inside @twitter? Some bird seed. Some snails. Some bread crumbs. How do I get out?",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 20, 28 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385892023808454656",
    "text" : "What is here inside @twitter? Some bird seed. Some snails. Some bread crumbs. How do I get out?",
    "id" : 385892023808454656,
    "created_at" : "2013-10-03 22:20:02 +0000",
    "user" : {
      "name" : "Margaret E. Atwood",
      "screen_name" : "MargaretAtwood",
      "protected" : false,
      "id_str" : "54730258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/355188578\/P_at_FLicKeR-01_normal.jpg",
      "id" : 54730258,
      "verified" : true
    }
  },
  "id" : 385939957841293313,
  "created_at" : "2013-10-04 01:30:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385888568591126529",
  "text" : "RT @twitter: Our S-1 will be filed publicly with the SEC momentarily. This Tweet does not constitute an offer of any securities for sale.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385873373353361408",
    "text" : "Our S-1 will be filed publicly with the SEC momentarily. This Tweet does not constitute an offer of any securities for sale.",
    "id" : 385873373353361408,
    "created_at" : "2013-10-03 21:05:56 +0000",
    "user" : {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "protected" : false,
      "id_str" : "783214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2284174758\/v65oai7fxn47qv9nectx_normal.png",
      "id" : 783214,
      "verified" : true
    }
  },
  "id" : 385888568591126529,
  "created_at" : "2013-10-03 22:06:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385833298523860992",
  "geo" : { },
  "id_str" : "385833403276214272",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Agreed. This is one app I'm glad they flat-ified.",
  "id" : 385833403276214272,
  "in_reply_to_status_id" : 385833298523860992,
  "created_at" : "2013-10-03 18:27:06 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 3, 11 ],
      "id_str" : "22891211",
      "id" : 22891211
    }, {
      "name" : "Biz Stone",
      "screen_name" : "biz",
      "indices" : [ 27, 31 ],
      "id_str" : "13",
      "id" : 13
    }, {
      "name" : "Jack Dorsey",
      "screen_name" : "jack",
      "indices" : [ 32, 37 ],
      "id_str" : "12",
      "id" : 12
    }, {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "indices" : [ 38, 41 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/chanian\/status\/385818125641338881\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/Aam8DMW1g2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVqzinyCcAA22QP.jpg",
      "id_str" : "385818125469380608",
      "id" : 385818125469380608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVqzinyCcAA22QP.jpg",
      "sizes" : [ {
        "h" : 634,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 211,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 371,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 634,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Aam8DMW1g2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385830710897958912",
  "text" : "RT @chanian: The Founders: @biz @jack @ev http:\/\/t.co\/Aam8DMW1g2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Biz Stone",
        "screen_name" : "biz",
        "indices" : [ 14, 18 ],
        "id_str" : "13",
        "id" : 13
      }, {
        "name" : "Jack Dorsey",
        "screen_name" : "jack",
        "indices" : [ 19, 24 ],
        "id_str" : "12",
        "id" : 12
      }, {
        "name" : "Ev Williams",
        "screen_name" : "ev",
        "indices" : [ 25, 28 ],
        "id_str" : "20",
        "id" : 20
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/chanian\/status\/385818125641338881\/photo\/1",
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/Aam8DMW1g2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BVqzinyCcAA22QP.jpg",
        "id_str" : "385818125469380608",
        "id" : 385818125469380608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVqzinyCcAA22QP.jpg",
        "sizes" : [ {
          "h" : 634,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 211,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 371,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 634,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Aam8DMW1g2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.77199363, -122.42245789 ]
    },
    "id_str" : "385818125641338881",
    "text" : "The Founders: @biz @jack @ev http:\/\/t.co\/Aam8DMW1g2",
    "id" : 385818125641338881,
    "created_at" : "2013-10-03 17:26:23 +0000",
    "user" : {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "protected" : false,
      "id_str" : "22891211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2467844172\/image_normal.jpg",
      "id" : 22891211,
      "verified" : false
    }
  },
  "id" : 385830710897958912,
  "created_at" : "2013-10-03 18:16:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "indices" : [ 88, 91 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763765982, -122.4168170828 ]
  },
  "id_str" : "385821540337451008",
  "text" : "\"Only a few things matter. And you don't really know what those things are at first.\" - @ev",
  "id" : 385821540337451008,
  "created_at" : "2013-10-03 17:39:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Cho",
      "screen_name" : "mark_cho",
      "indices" : [ 19, 28 ],
      "id_str" : "391248959",
      "id" : 391248959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385814515188641793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763795531, -122.4168197436 ]
  },
  "id_str" : "385820948206600192",
  "in_reply_to_user_id" : 391248959,
  "text" : "Super exciting. RT @mark_cho: About to demo my team's project in front of the entire company. Exciting!",
  "id" : 385820948206600192,
  "in_reply_to_status_id" : 385814515188641793,
  "created_at" : "2013-10-03 17:37:36 +0000",
  "in_reply_to_screen_name" : "mark_cho",
  "in_reply_to_user_id_str" : "391248959",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 0, 8 ],
      "id_str" : "22891211",
      "id" : 22891211
    }, {
      "name" : "Mark Cho",
      "screen_name" : "mark_cho",
      "indices" : [ 9, 18 ],
      "id_str" : "391248959",
      "id" : 391248959
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "treephy",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763776111, -122.4168242458 ]
  },
  "id_str" : "385816333360713729",
  "in_reply_to_user_id" : 22891211,
  "text" : "@chanian @mark_cho you rocked it! #treephy",
  "id" : 385816333360713729,
  "created_at" : "2013-10-03 17:19:16 +0000",
  "in_reply_to_screen_name" : "chanian",
  "in_reply_to_user_id_str" : "22891211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Jordan Crook",
      "screen_name" : "jordanrcrook",
      "indices" : [ 116, 129 ],
      "id_str" : "296338717",
      "id" : 296338717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/xgAAKtvbGS",
      "expanded_url" : "http:\/\/tcrn.ch\/1hnluNb",
      "display_url" : "tcrn.ch\/1hnluNb"
    } ]
  },
  "geo" : { },
  "id_str" : "385770328867102720",
  "text" : "RT @TechCrunch: With An Eye On Revenue, Snapchat \"Experiments\" With A Click-To-Buy Button http:\/\/t.co\/xgAAKtvbGS by @jordanrcrook",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/10up.com\" rel=\"nofollow\"\u003E10up Publish Tweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jordan Crook",
        "screen_name" : "jordanrcrook",
        "indices" : [ 100, 113 ],
        "id_str" : "296338717",
        "id" : 296338717
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/xgAAKtvbGS",
        "expanded_url" : "http:\/\/tcrn.ch\/1hnluNb",
        "display_url" : "tcrn.ch\/1hnluNb"
      } ]
    },
    "geo" : { },
    "id_str" : "385762338412199936",
    "text" : "With An Eye On Revenue, Snapchat \"Experiments\" With A Click-To-Buy Button http:\/\/t.co\/xgAAKtvbGS by @jordanrcrook",
    "id" : 385762338412199936,
    "created_at" : "2013-10-03 13:44:43 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2176846885\/-5-1_normal.jpeg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 385770328867102720,
  "created_at" : "2013-10-03 14:16:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nitasha Tiku",
      "screen_name" : "nitashatiku",
      "indices" : [ 3, 15 ],
      "id_str" : "24421464",
      "id" : 24421464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/pWDJpeFtMQ",
      "expanded_url" : "http:\/\/allthingsd.com\/20131003\/narrative-formerly-known-as-memoto-launches-life-logging-camera-raises-3m\/?mod=atd_homepage_carousel",
      "display_url" : "allthingsd.com\/20131003\/narra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385769397333131264",
  "text" : "RT @nitashatiku: \u201CIt is creepy and interesting\" CEO describing his product http:\/\/t.co\/pWDJpeFtMQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/pWDJpeFtMQ",
        "expanded_url" : "http:\/\/allthingsd.com\/20131003\/narrative-formerly-known-as-memoto-launches-life-logging-camera-raises-3m\/?mod=atd_homepage_carousel",
        "display_url" : "allthingsd.com\/20131003\/narra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "385761497793576960",
    "text" : "\u201CIt is creepy and interesting\" CEO describing his product http:\/\/t.co\/pWDJpeFtMQ",
    "id" : 385761497793576960,
    "created_at" : "2013-10-03 13:41:22 +0000",
    "user" : {
      "name" : "Nitasha Tiku",
      "screen_name" : "nitashatiku",
      "protected" : false,
      "id_str" : "24421464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000827157594\/255c9dffd4c64a0199d5d3e01cdf7d04_normal.jpeg",
      "id" : 24421464,
      "verified" : false
    }
  },
  "id" : 385769397333131264,
  "created_at" : "2013-10-03 14:12:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kris",
      "screen_name" : "kris",
      "indices" : [ 3, 8 ],
      "id_str" : "115734106",
      "id" : 115734106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/SsV736IEsc",
      "expanded_url" : "http:\/\/www.businessinsider.com\/meet-ross-ulbricht-the-brilliant-alleged-mastermind-of-silk-road-2013-10",
      "display_url" : "businessinsider.com\/meet-ross-ulbr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385768553351094272",
  "text" : "RT @kris: A cute engineer, bitcoin, the SF library and a princess bride reference. An amazingly-SF crime story: http:\/\/t.co\/SsV736IEsc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/SsV736IEsc",
        "expanded_url" : "http:\/\/www.businessinsider.com\/meet-ross-ulbricht-the-brilliant-alleged-mastermind-of-silk-road-2013-10",
        "display_url" : "businessinsider.com\/meet-ross-ulbr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "385662554229313536",
    "text" : "A cute engineer, bitcoin, the SF library and a princess bride reference. An amazingly-SF crime story: http:\/\/t.co\/SsV736IEsc",
    "id" : 385662554229313536,
    "created_at" : "2013-10-03 07:08:12 +0000",
    "user" : {
      "name" : "kris",
      "screen_name" : "kris",
      "protected" : false,
      "id_str" : "115734106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462663809056796673\/N9B-WTNo_normal.jpeg",
      "id" : 115734106,
      "verified" : false
    }
  },
  "id" : 385768553351094272,
  "created_at" : "2013-10-03 14:09:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Agam Misra",
      "screen_name" : "AgamMisra",
      "indices" : [ 0, 10 ],
      "id_str" : "1706400674",
      "id" : 1706400674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385638883737608192",
  "in_reply_to_user_id" : 1706400674,
  "text" : "@AgamMisra Depends on what you're looking for\u2026 but my general advice is to try a bunch and keep trying until something works for you.",
  "id" : 385638883737608192,
  "created_at" : "2013-10-03 05:34:09 +0000",
  "in_reply_to_screen_name" : "AgamMisra",
  "in_reply_to_user_id_str" : "1706400674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596979056, -122.2755958484 ]
  },
  "id_str" : "385635553284075520",
  "text" : "In order of Niko knowing how to use them: touch screen, track pad, Siri. He still doesn't know the keyboard other than the space bar.",
  "id" : 385635553284075520,
  "created_at" : "2013-10-03 05:20:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Agam Misra",
      "screen_name" : "AgamMisra",
      "indices" : [ 0, 10 ],
      "id_str" : "1706400674",
      "id" : 1706400674
    }, {
      "name" : "Budge",
      "screen_name" : "budge",
      "indices" : [ 17, 23 ],
      "id_str" : "286384512",
      "id" : 286384512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385628066950557696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859771683, -122.2754041473 ]
  },
  "id_str" : "385628251889999872",
  "in_reply_to_user_id" : 1706400674,
  "text" : "@AgamMisra Nope, @budge is dead.",
  "id" : 385628251889999872,
  "in_reply_to_status_id" : 385628066950557696,
  "created_at" : "2013-10-03 04:51:54 +0000",
  "in_reply_to_screen_name" : "AgamMisra",
  "in_reply_to_user_id_str" : "1706400674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 0, 7 ],
      "id_str" : "23640904",
      "id" : 23640904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385615157889478656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597640049, -122.2755839874 ]
  },
  "id_str" : "385626479406505984",
  "in_reply_to_user_id" : 23640904,
  "text" : "@emoore I need some new Twitter tricks too please.",
  "id" : 385626479406505984,
  "in_reply_to_status_id" : 385615157889478656,
  "created_at" : "2013-10-03 04:44:51 +0000",
  "in_reply_to_screen_name" : "emoore",
  "in_reply_to_user_id_str" : "23640904",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/W4QeJD2uFP",
      "expanded_url" : "http:\/\/flic.kr\/p\/gkiqjX",
      "display_url" : "flic.kr\/p\/gkiqjX"
    } ]
  },
  "geo" : { },
  "id_str" : "385614473530458112",
  "text" : "8:36pm Dinner in Emeryville public market wasn't as bad as i thought it would be http:\/\/t.co\/W4QeJD2uFP",
  "id" : 385614473530458112,
  "created_at" : "2013-10-03 03:57:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/Bd5JGXLdit",
      "expanded_url" : "https:\/\/vine.co\/v\/hg6FtQxdhH5",
      "display_url" : "vine.co\/v\/hg6FtQxdhH5"
    } ]
  },
  "geo" : { },
  "id_str" : "385593331369394176",
  "text" : "Pumpkin patch Titanic sliding https:\/\/t.co\/Bd5JGXLdit",
  "id" : 385593331369394176,
  "created_at" : "2013-10-03 02:33:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 3, 17 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385555226251374592",
  "text" : "RT @buster_ebooks: I don't believe in 2,869.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/busterbenson.com\" rel=\"nofollow\"\u003EBuster eBooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385552067726565376",
    "text" : "I don't believe in 2,869.",
    "id" : 385552067726565376,
    "created_at" : "2013-10-02 23:49:10 +0000",
    "user" : {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "protected" : false,
      "id_str" : "1901375096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000503050571\/228ccabfeeb4e55bd8e172595babe02e_normal.jpeg",
      "id" : 1901375096,
      "verified" : false
    }
  },
  "id" : 385555226251374592,
  "created_at" : "2013-10-03 00:01:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin L. Haas",
      "screen_name" : "delohaas",
      "indices" : [ 0, 9 ],
      "id_str" : "24212532",
      "id" : 24212532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385459499592458240",
  "geo" : { },
  "id_str" : "385459859337920512",
  "in_reply_to_user_id" : 24212532,
  "text" : "@delohaas True, but they're shorter and it takes effort to find new podcasts and the quality varies more frequently.",
  "id" : 385459859337920512,
  "in_reply_to_status_id" : 385459499592458240,
  "created_at" : "2013-10-02 17:42:46 +0000",
  "in_reply_to_screen_name" : "delohaas",
  "in_reply_to_user_id_str" : "24212532",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin L. Haas",
      "screen_name" : "delohaas",
      "indices" : [ 0, 9 ],
      "id_str" : "24212532",
      "id" : 24212532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385458857650040832",
  "geo" : { },
  "id_str" : "385459095232200704",
  "in_reply_to_user_id" : 24212532,
  "text" : "@delohaas I think it improves it a ton. I've completed many books via audiobook that I could never finish reading. It's less effort.",
  "id" : 385459095232200704,
  "in_reply_to_status_id" : 385458857650040832,
  "created_at" : "2013-10-02 17:39:44 +0000",
  "in_reply_to_screen_name" : "delohaas",
  "in_reply_to_user_id_str" : "24212532",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin L. Haas",
      "screen_name" : "delohaas",
      "indices" : [ 0, 9 ],
      "id_str" : "24212532",
      "id" : 24212532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385458276134944769",
  "geo" : { },
  "id_str" : "385458469211357184",
  "in_reply_to_user_id" : 24212532,
  "text" : "@delohaas I'm listening to the audiobook during my commutes which I think does a lot for making it easier to get through.",
  "id" : 385458469211357184,
  "in_reply_to_status_id" : 385458276134944769,
  "created_at" : "2013-10-02 17:37:15 +0000",
  "in_reply_to_screen_name" : "delohaas",
  "in_reply_to_user_id_str" : "24212532",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8290012945, -122.2671780457 ]
  },
  "id_str" : "385442708728197120",
  "text" : "Got quickly bored by Dawkins' new memoir... re-listening to Kahneman's Thinking Fast and Slow instead.",
  "id" : 385442708728197120,
  "created_at" : "2013-10-02 16:34:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385279584679124992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596238862, -122.2755582089 ]
  },
  "id_str" : "385280582604701696",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach Growth hackers these days love a viral loop for its own sake.",
  "id" : 385280582604701696,
  "in_reply_to_status_id" : 385279584679124992,
  "created_at" : "2013-10-02 05:50:23 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/9LCETyRCCl",
      "expanded_url" : "http:\/\/flic.kr\/p\/giVJy2",
      "display_url" : "flic.kr\/p\/giVJy2"
    } ]
  },
  "geo" : { },
  "id_str" : "385247843403194368",
  "text" : "8:36pm Having a sticker conversation with Niko on Kellianne's new gold 5s http:\/\/t.co\/9LCETyRCCl",
  "id" : 385247843403194368,
  "created_at" : "2013-10-02 03:40:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 3, 17 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385164635260743680",
  "text" : "RT @buster_ebooks: Write Your Own Adventures as a good one",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/busterbenson.com\" rel=\"nofollow\"\u003EBuster eBooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385164516306071552",
    "text" : "Write Your Own Adventures as a good one",
    "id" : 385164516306071552,
    "created_at" : "2013-10-01 22:09:11 +0000",
    "user" : {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "protected" : false,
      "id_str" : "1901375096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000503050571\/228ccabfeeb4e55bd8e172595babe02e_normal.jpeg",
      "id" : 1901375096,
      "verified" : false
    }
  },
  "id" : 385164635260743680,
  "created_at" : "2013-10-01 22:09:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 3, 15 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385081383963484160",
  "text" : "RT @BarackObama: Obamacare is here. #GetCovered",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 19, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385081333917036545",
    "text" : "Obamacare is here. #GetCovered",
    "id" : 385081333917036545,
    "created_at" : "2013-10-01 16:38:39 +0000",
    "user" : {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "protected" : false,
      "id_str" : "813286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451007105391022080\/iu1f7brY_normal.png",
      "id" : 813286,
      "verified" : true
    }
  },
  "id" : 385081383963484160,
  "created_at" : "2013-10-01 16:38:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "indices" : [ 101, 104 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/i0AOh0WbE8",
      "expanded_url" : "http:\/\/www.wired.com\/business\/2013\/09\/ev-williams-xoxo\/",
      "display_url" : "wired.com\/business\/2013\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596607037, -122.2754510679 ]
  },
  "id_str" : "385041538075463681",
  "text" : "Yes. \u201CConvenience on the internet is basically achieved by two things: speed, and cognitive ease.\u201D - @ev http:\/\/t.co\/i0AOh0WbE8",
  "id" : 385041538075463681,
  "created_at" : "2013-10-01 14:00:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596249968, -122.2754571029 ]
  },
  "id_str" : "385041282046771201",
  "text" : "Rabbit rabbit",
  "id" : 385041282046771201,
  "created_at" : "2013-10-01 13:59:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "N Bront\u00EB Neel",
      "screen_name" : "nbronten",
      "indices" : [ 3, 12 ],
      "id_str" : "157380392",
      "id" : 157380392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384939055021973504",
  "text" : "RT @nbronten: Have you tried turning your government off and on again?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/devices\" rel=\"nofollow\"\u003Etxt\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384904449858101249",
    "text" : "Have you tried turning your government off and on again?",
    "id" : 384904449858101249,
    "created_at" : "2013-10-01 04:55:46 +0000",
    "user" : {
      "name" : "N Bront\u00EB Neel",
      "screen_name" : "nbronten",
      "protected" : false,
      "id_str" : "157380392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441815476771909633\/joNLKcJi_normal.jpeg",
      "id" : 157380392,
      "verified" : false
    }
  },
  "id" : 384939055021973504,
  "created_at" : "2013-10-01 07:13:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]