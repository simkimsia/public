Grailbird.data.tweets_2013_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 6, 16 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407033232148807680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595976731, -122.2755813001 ]
  },
  "id_str" : "407033828834689024",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara @kellianne Ha, come visit us! :) Also, we're headed to Southern California for Xmas week... will you be around?",
  "id" : 407033828834689024,
  "in_reply_to_status_id" : 407033232148807680,
  "created_at" : "2013-12-01 06:30:01 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Buckhouse",
      "screen_name" : "buckhouse",
      "indices" : [ 3, 13 ],
      "id_str" : "16896060",
      "id" : 16896060
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buckhouse\/status\/407015290006818816\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ZLSQSPTZxP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaYCP_OCUAAb8Vl.jpg",
      "id_str" : "407015290015207424",
      "id" : 407015290015207424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaYCP_OCUAAb8Vl.jpg",
      "sizes" : [ {
        "h" : 194,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 342,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 740,
        "resize" : "fit",
        "w" : 1300
      } ],
      "display_url" : "pic.twitter.com\/ZLSQSPTZxP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407018602026397697",
  "text" : "RT @buckhouse: No big deal... Bach wrote a piece of music you can play, and then flip it upside down and play it again. http:\/\/t.co\/ZLSQSPT\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/buckhouse\/status\/407015290006818816\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/ZLSQSPTZxP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaYCP_OCUAAb8Vl.jpg",
        "id_str" : "407015290015207424",
        "id" : 407015290015207424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaYCP_OCUAAb8Vl.jpg",
        "sizes" : [ {
          "h" : 194,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 342,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 740,
          "resize" : "fit",
          "w" : 1300
        } ],
        "display_url" : "pic.twitter.com\/ZLSQSPTZxP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "407015290006818816",
    "text" : "No big deal... Bach wrote a piece of music you can play, and then flip it upside down and play it again. http:\/\/t.co\/ZLSQSPTZxP",
    "id" : 407015290006818816,
    "created_at" : "2013-12-01 05:16:21 +0000",
    "user" : {
      "name" : "James Buckhouse",
      "screen_name" : "buckhouse",
      "protected" : false,
      "id_str" : "16896060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000694618170\/67572a98964dad666e0935b32d1fdcf7_normal.jpeg",
      "id" : 16896060,
      "verified" : false
    }
  },
  "id" : 407018602026397697,
  "created_at" : "2013-12-01 05:29:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/ym3DDqV2ao",
      "expanded_url" : "http:\/\/flic.kr\/p\/hYRY2R",
      "display_url" : "flic.kr\/p\/hYRY2R"
    } ]
  },
  "geo" : { },
  "id_str" : "407005858422616064",
  "text" : "8:36pm Katie's here! http:\/\/t.co\/ym3DDqV2ao",
  "id" : 407005858422616064,
  "created_at" : "2013-12-01 04:38:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/406942378411319296\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/wfypQAt3zp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaW_79aCQAAGig5.jpg",
      "id_str" : "406942378163847168",
      "id" : 406942378163847168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaW_79aCQAAGig5.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wfypQAt3zp"
    } ],
    "hashtags" : [ {
      "text" : "california",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8568764459, -122.2722143196 ]
  },
  "id_str" : "406942378411319296",
  "text" : "#california http:\/\/t.co\/wfypQAt3zp",
  "id" : 406942378411319296,
  "created_at" : "2013-12-01 00:26:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/ZeYJriFDZS",
      "expanded_url" : "https:\/\/vine.co\/v\/hPpWMtw37et",
      "display_url" : "vine.co\/v\/hPpWMtw37et"
    } ]
  },
  "geo" : { },
  "id_str" : "406940788032278529",
  "text" : "Golden hour bikes https:\/\/t.co\/ZeYJriFDZS",
  "id" : 406940788032278529,
  "created_at" : "2013-12-01 00:20:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "indices" : [ 3, 15 ],
      "id_str" : "1532061",
      "id" : 1532061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ckir4RuIwN",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/parmyolson\/2013\/11\/27\/cryptolocker-thieves-likely-making-millions-as-bitcoin-breaks-1000\/",
      "display_url" : "forbes.com\/sites\/parmyols\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406657770767663104",
  "text" : "RT @kevin2kelly: This is diabolical malware infects your computer, then encrypts your files and demands bitcoin ransom to decrypt it. http:\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/ckir4RuIwN",
        "expanded_url" : "http:\/\/www.forbes.com\/sites\/parmyolson\/2013\/11\/27\/cryptolocker-thieves-likely-making-millions-as-bitcoin-breaks-1000\/",
        "display_url" : "forbes.com\/sites\/parmyols\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "406630474123984896",
    "text" : "This is diabolical malware infects your computer, then encrypts your files and demands bitcoin ransom to decrypt it. http:\/\/t.co\/ckir4RuIwN",
    "id" : 406630474123984896,
    "created_at" : "2013-11-30 03:47:14 +0000",
    "user" : {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "protected" : false,
      "id_str" : "1532061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/65000713\/KKlaughsm_normal.jpg",
      "id" : 1532061,
      "verified" : false
    }
  },
  "id" : 406657770767663104,
  "created_at" : "2013-11-30 05:35:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/ajy2DWDnYX",
      "expanded_url" : "http:\/\/flic.kr\/p\/hXhRn3",
      "display_url" : "flic.kr\/p\/hXhRn3"
    } ]
  },
  "geo" : { },
  "id_str" : "406645497026605056",
  "text" : "8:36pm Talking about the Thomas items Niko needs in order to complete his set http:\/\/t.co\/ajy2DWDnYX",
  "id" : 406645497026605056,
  "created_at" : "2013-11-30 04:46:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597228018, -122.2755104252 ]
  },
  "id_str" : "406293213012426753",
  "text" : "Happy thanksgiving, tweeterheads! I'm doubly thankful for everyone that faves this.",
  "id" : 406293213012426753,
  "created_at" : "2013-11-29 05:27:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/8bQOpwvotV",
      "expanded_url" : "http:\/\/flic.kr\/p\/hVVxeg",
      "display_url" : "flic.kr\/p\/hVVxeg"
    } ]
  },
  "geo" : { },
  "id_str" : "406292694030639104",
  "text" : "8:36pm Delicious turkey day with friends and family http:\/\/t.co\/8bQOpwvotV",
  "id" : 406292694030639104,
  "created_at" : "2013-11-29 05:25:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/0VBmSTvw0S",
      "expanded_url" : "http:\/\/flic.kr\/p\/hUtKFu",
      "display_url" : "flic.kr\/p\/hUtKFu"
    } ]
  },
  "geo" : { },
  "id_str" : "405919789623025664",
  "text" : "8:36pm Niko just saw a raccoon in our front yard http:\/\/t.co\/0VBmSTvw0S",
  "id" : 405919789623025664,
  "created_at" : "2013-11-28 04:43:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jana Messerschmidt",
      "screen_name" : "janamal",
      "indices" : [ 0, 8 ],
      "id_str" : "15526110",
      "id" : 15526110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405886647675277312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597370323, -122.2754649308 ]
  },
  "id_str" : "405887895203897344",
  "in_reply_to_user_id" : 15526110,
  "text" : "@janamal Typos are Twitter's wabi sabi.",
  "id" : 405887895203897344,
  "in_reply_to_status_id" : 405886647675277312,
  "created_at" : "2013-11-28 02:36:29 +0000",
  "in_reply_to_screen_name" : "janamal",
  "in_reply_to_user_id_str" : "15526110",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/dt9Y5ywWam",
      "expanded_url" : "https:\/\/medium.com\/p\/ac6364c5c63b",
      "display_url" : "medium.com\/p\/ac6364c5c63b"
    } ]
  },
  "geo" : { },
  "id_str" : "405858834087817216",
  "text" : "I had to write this: \u201CDoes your cat love you?\u201D https:\/\/t.co\/dt9Y5ywWam",
  "id" : 405858834087817216,
  "created_at" : "2013-11-28 00:41:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristen Hawley",
      "screen_name" : "kh",
      "indices" : [ 0, 3 ],
      "id_str" : "14589956",
      "id" : 14589956
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 4, 7 ],
      "id_str" : "19853",
      "id" : 19853
    }, {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 8, 18 ],
      "id_str" : "13349",
      "id" : 13349
    }, {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 19, 23 ],
      "id_str" : "2182141",
      "id" : 2182141
    }, {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 98, 109 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405819043325558784",
  "geo" : { },
  "id_str" : "405819721221550080",
  "in_reply_to_user_id" : 14589956,
  "text" : "@kh @rk @ryanchris @cap Yeah, it's a brand new product, but I think it has lots of potential! \/cc @brianellin",
  "id" : 405819721221550080,
  "in_reply_to_status_id" : 405819043325558784,
  "created_at" : "2013-11-27 22:05:35 +0000",
  "in_reply_to_screen_name" : "kh",
  "in_reply_to_user_id_str" : "14589956",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 0, 10 ],
      "id_str" : "13349",
      "id" : 13349
    }, {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 11, 15 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/27joVYKL0k",
      "expanded_url" : "https:\/\/blog.twitter.com\/2013\/custom-timelines-in-tweetdeck",
      "display_url" : "blog.twitter.com\/2013\/custom-ti\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "405807235797757954",
  "geo" : { },
  "id_str" : "405808141230538752",
  "in_reply_to_user_id" : 13349,
  "text" : "@ryanchris @cap Though it currently only works in TweetDeck, you could curate a custom timeline: https:\/\/t.co\/27joVYKL0k",
  "id" : 405808141230538752,
  "in_reply_to_status_id" : 405807235797757954,
  "created_at" : "2013-11-27 21:19:35 +0000",
  "in_reply_to_screen_name" : "ryanchris",
  "in_reply_to_user_id_str" : "13349",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Linden",
      "screen_name" : "greglinden",
      "indices" : [ 0, 11 ],
      "id_str" : "87719108",
      "id" : 87719108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405773533491380225",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764163425, -122.4175172696 ]
  },
  "id_str" : "405798426090033153",
  "in_reply_to_user_id" : 87719108,
  "text" : "@greglinden Ooh can't wait to try this out! Can you make a version for 4 year olds? :)",
  "id" : 405798426090033153,
  "in_reply_to_status_id" : 405773533491380225,
  "created_at" : "2013-11-27 20:40:58 +0000",
  "in_reply_to_screen_name" : "greglinden",
  "in_reply_to_user_id_str" : "87719108",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Linden",
      "screen_name" : "greglinden",
      "indices" : [ 3, 14 ],
      "id_str" : "87719108",
      "id" : 87719108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/3S1SE5JPy6",
      "expanded_url" : "http:\/\/glinden.blogspot.com\/2013\/11\/game-maven-learn-to-code-by-writing.html",
      "display_url" : "glinden.blogspot.com\/2013\/11\/game-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "405798219034013696",
  "text" : "RT @greglinden: Game Maven: Learn to code by writing games http:\/\/t.co\/3S1SE5JPy6",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/3S1SE5JPy6",
        "expanded_url" : "http:\/\/glinden.blogspot.com\/2013\/11\/game-maven-learn-to-code-by-writing.html",
        "display_url" : "glinden.blogspot.com\/2013\/11\/game-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "405773533491380225",
    "text" : "Game Maven: Learn to code by writing games http:\/\/t.co\/3S1SE5JPy6",
    "id" : 405773533491380225,
    "created_at" : "2013-11-27 19:02:03 +0000",
    "user" : {
      "name" : "Greg Linden",
      "screen_name" : "greglinden",
      "protected" : false,
      "id_str" : "87719108",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441427879809675264\/NUsuaTou_normal.png",
      "id" : 87719108,
      "verified" : false
    }
  },
  "id" : 405798219034013696,
  "created_at" : "2013-11-27 20:40:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reeve S. Thompson ",
      "screen_name" : "Reeve",
      "indices" : [ 0, 6 ],
      "id_str" : "9317922",
      "id" : 9317922
    }, {
      "name" : "Ryan Choi",
      "screen_name" : "rchoi",
      "indices" : [ 7, 13 ],
      "id_str" : "54256387",
      "id" : 54256387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405761790765580290",
  "geo" : { },
  "id_str" : "405762068512403456",
  "in_reply_to_user_id" : 9317922,
  "text" : "@reeve @rchoi I want to see it too!",
  "id" : 405762068512403456,
  "in_reply_to_status_id" : 405761790765580290,
  "created_at" : "2013-11-27 18:16:30 +0000",
  "in_reply_to_screen_name" : "Reeve",
  "in_reply_to_user_id_str" : "9317922",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caitlin Thornton",
      "screen_name" : "caitlinthornton",
      "indices" : [ 0, 16 ],
      "id_str" : "22081885",
      "id" : 22081885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405708145432870912",
  "geo" : { },
  "id_str" : "405756378133700608",
  "in_reply_to_user_id" : 22081885,
  "text" : "@caitlinthornton You're welcome! We're happy that others find it useful! Flow is a tough thing to find.",
  "id" : 405756378133700608,
  "in_reply_to_status_id" : 405708145432870912,
  "created_at" : "2013-11-27 17:53:53 +0000",
  "in_reply_to_screen_name" : "caitlinthornton",
  "in_reply_to_user_id_str" : "22081885",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "indices" : [ 3, 17 ],
      "id_str" : "1236101",
      "id" : 1236101
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BenedictEvans\/status\/405730787003097090\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/mmb7dQg0wj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaFyAD2CUAAUBI5.jpg",
      "id_str" : "405730786797572096",
      "id" : 405730786797572096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaFyAD2CUAAUBI5.jpg",
      "sizes" : [ {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 853,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/mmb7dQg0wj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405732861812027392",
  "text" : "RT @BenedictEvans: The great Guru boom is over http:\/\/t.co\/mmb7dQg0wj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BenedictEvans\/status\/405730787003097090\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/mmb7dQg0wj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaFyAD2CUAAUBI5.jpg",
        "id_str" : "405730786797572096",
        "id" : 405730786797572096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaFyAD2CUAAUBI5.jpg",
        "sizes" : [ {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 569,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 853,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/mmb7dQg0wj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405730787003097090",
    "text" : "The great Guru boom is over http:\/\/t.co\/mmb7dQg0wj",
    "id" : 405730787003097090,
    "created_at" : "2013-11-27 16:12:12 +0000",
    "user" : {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "protected" : false,
      "id_str" : "1236101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454333621331976193\/AX-M-ESC_normal.jpeg",
      "id" : 1236101,
      "verified" : false
    }
  },
  "id" : 405732861812027392,
  "created_at" : "2013-11-27 16:20:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/TXTbbXbIQw",
      "expanded_url" : "http:\/\/flic.kr\/p\/hT1JDi",
      "display_url" : "flic.kr\/p\/hT1JDi"
    } ]
  },
  "geo" : { },
  "id_str" : "405561763682590720",
  "text" : "8:36pm 1) get blog post idea 2) wait for free time in evening 3) drink a glass of wine &amp; watch Doctor Who 4) repeat http:\/\/t.co\/TXTbbXbIQw",
  "id" : 405561763682590720,
  "created_at" : "2013-11-27 05:00:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405531392013897729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8583745819, -122.27508382 ]
  },
  "id_str" : "405539378803392512",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley That is ridiculously cute.",
  "id" : 405539378803392512,
  "in_reply_to_status_id" : 405531392013897729,
  "created_at" : "2013-11-27 03:31:37 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 17, 28 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "manualfave",
      "indices" : [ 2, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/EpKgquZcVa",
      "expanded_url" : "http:\/\/f.cl.ly\/items\/0b3z1n3j23392Q2A1Z03\/Image%202013.11.26%205%3A20%3A22%20PM.png",
      "display_url" : "f.cl.ly\/items\/0b3z1n3j\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "405506486916239360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7825903127, -122.4048083091 ]
  },
  "id_str" : "405530845621923841",
  "in_reply_to_user_id" : 13461,
  "text" : "\uD83C\uDF1F #manualfave RT @waxpancake: These new Twitter notifications are getting out of control. http:\/\/t.co\/EpKgquZcVa",
  "id" : 405530845621923841,
  "in_reply_to_status_id" : 405506486916239360,
  "created_at" : "2013-11-27 02:57:42 +0000",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mycoffeeshopnames",
      "indices" : [ 24, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77919759, -122.41427638 ]
  },
  "id_str" : "405525602737725440",
  "text" : "Oscar. Lester. Mustard. #mycoffeeshopnames",
  "id" : 405525602737725440,
  "created_at" : "2013-11-27 02:36:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    }, {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 8, 20 ],
      "id_str" : "195863654",
      "id" : 195863654
    }, {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 105, 116 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405448376604303360",
  "geo" : { },
  "id_str" : "405462306743521280",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez @marihuertas That's such a great post. Thanks for reminding me of it. And thanks for writing it, @robinsloan.",
  "id" : 405462306743521280,
  "in_reply_to_status_id" : 405448376604303360,
  "created_at" : "2013-11-26 22:25:21 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 0, 12 ],
      "id_str" : "195863654",
      "id" : 195863654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405447957949857792",
  "geo" : { },
  "id_str" : "405460196001976320",
  "in_reply_to_user_id" : 195863654,
  "text" : "@marihuertas I like that way of thinking of it, though I admittedly do a very poor job of providing a clean signal for others. :)",
  "id" : 405460196001976320,
  "in_reply_to_status_id" : 405447957949857792,
  "created_at" : "2013-11-26 22:16:58 +0000",
  "in_reply_to_screen_name" : "marihuertas",
  "in_reply_to_user_id_str" : "195863654",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 0, 12 ],
      "id_str" : "195863654",
      "id" : 195863654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405445609991045122",
  "geo" : { },
  "id_str" : "405445901826523136",
  "in_reply_to_user_id" : 195863654,
  "text" : "@marihuertas Interesting. Do you mean becoming a better filter of good stuff for people who follow you?",
  "id" : 405445901826523136,
  "in_reply_to_status_id" : 405445609991045122,
  "created_at" : "2013-11-26 21:20:10 +0000",
  "in_reply_to_screen_name" : "marihuertas",
  "in_reply_to_user_id_str" : "195863654",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405444305369567233",
  "text" : "What do you think it means to get better at Twitter?",
  "id" : 405444305369567233,
  "created_at" : "2013-11-26 21:13:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Davidson",
      "screen_name" : "tdavidson",
      "indices" : [ 0, 10 ],
      "id_str" : "8466962",
      "id" : 8466962
    }, {
      "name" : "Jonathan Basker",
      "screen_name" : "basker",
      "indices" : [ 11, 18 ],
      "id_str" : "14126365",
      "id" : 14126365
    }, {
      "name" : "Ghost Of J2 Labs",
      "screen_name" : "j2labs",
      "indices" : [ 19, 26 ],
      "id_str" : "2420564064",
      "id" : 2420564064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405387466367963136",
  "geo" : { },
  "id_str" : "405389254076813312",
  "in_reply_to_user_id" : 8466962,
  "text" : "@tdavidson @basker @j2labs Nice. I'm seeing more and more people picking up on this. I like how you've used it.",
  "id" : 405389254076813312,
  "in_reply_to_status_id" : 405387466367963136,
  "created_at" : "2013-11-26 17:35:04 +0000",
  "in_reply_to_screen_name" : "tdavidson",
  "in_reply_to_user_id_str" : "8466962",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/405202997111578624\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bTzXofn3RQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ-R-pOCUAEPGqf.jpg",
      "id_str" : "405202996889276417",
      "id" : 405202996889276417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ-R-pOCUAEPGqf.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bTzXofn3RQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7756942343, -122.414968433 ]
  },
  "id_str" : "405202997111578624",
  "text" : "http:\/\/t.co\/bTzXofn3RQ",
  "id" : 405202997111578624,
  "created_at" : "2013-11-26 05:14:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/hezdvdYu79",
      "expanded_url" : "http:\/\/flic.kr\/p\/hRsTha",
      "display_url" : "flic.kr\/p\/hRsTha"
    } ]
  },
  "geo" : { },
  "id_str" : "405193942318465024",
  "text" : "8:36pm What's your favorite book? http:\/\/t.co\/hezdvdYu79",
  "id" : 405193942318465024,
  "created_at" : "2013-11-26 04:38:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/JSVlLaNEWB",
      "expanded_url" : "http:\/\/www.telegraph.co.uk\/technology\/internet\/10468112\/The-internet-mystery-that-has-the-world-baffled.html",
      "display_url" : "telegraph.co.uk\/technology\/int\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "405145592881360896",
  "text" : "RT @isaach: this is great. \"The internet mystery that has the world baffled\" http:\/\/t.co\/JSVlLaNEWB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/JSVlLaNEWB",
        "expanded_url" : "http:\/\/www.telegraph.co.uk\/technology\/internet\/10468112\/The-internet-mystery-that-has-the-world-baffled.html",
        "display_url" : "telegraph.co.uk\/technology\/int\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "405139697120194560",
    "text" : "this is great. \"The internet mystery that has the world baffled\" http:\/\/t.co\/JSVlLaNEWB",
    "id" : 405139697120194560,
    "created_at" : "2013-11-26 01:03:25 +0000",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430605387117494272\/lmplHwca_normal.png",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 405145592881360896,
  "created_at" : "2013-11-26 01:26:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristen Hawley",
      "screen_name" : "kh",
      "indices" : [ 3, 6 ],
      "id_str" : "14589956",
      "id" : 14589956
    }, {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 27, 38 ],
      "id_str" : "784078",
      "id" : 784078
    }, {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 65, 71 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/OWfwmI8ERp",
      "expanded_url" : "http:\/\/www.wired.com\/opinion\/2013\/11\/silicon-valley-isnt-a-meritocracy-and-the-cult-of-the-entrepreneur-holds-people-back\/",
      "display_url" : "wired.com\/opinion\/2013\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "405046497151954944",
  "text" : "RT @kh: Read: excerpt from @alicetiara's book, Status Update, in @WIRED http:\/\/t.co\/OWfwmI8ERp (It's better than that other social networki\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "alicetiara",
        "screen_name" : "alicetiara",
        "indices" : [ 19, 30 ],
        "id_str" : "784078",
        "id" : 784078
      }, {
        "name" : "WIRED",
        "screen_name" : "WIRED",
        "indices" : [ 57, 63 ],
        "id_str" : "1344951",
        "id" : 1344951
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/OWfwmI8ERp",
        "expanded_url" : "http:\/\/www.wired.com\/opinion\/2013\/11\/silicon-valley-isnt-a-meritocracy-and-the-cult-of-the-entrepreneur-holds-people-back\/",
        "display_url" : "wired.com\/opinion\/2013\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "405046242368974849",
    "text" : "Read: excerpt from @alicetiara's book, Status Update, in @WIRED http:\/\/t.co\/OWfwmI8ERp (It's better than that other social networking book.)",
    "id" : 405046242368974849,
    "created_at" : "2013-11-25 18:52:04 +0000",
    "user" : {
      "name" : "Kristen Hawley",
      "screen_name" : "kh",
      "protected" : false,
      "id_str" : "14589956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000324849644\/abd9e0de9a10e0bf0e909782637605d9_normal.png",
      "id" : 14589956,
      "verified" : false
    }
  },
  "id" : 405046497151954944,
  "created_at" : "2013-11-25 18:53:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/yyGcCeH6ga",
      "expanded_url" : "http:\/\/flic.kr\/p\/hPQBcJ",
      "display_url" : "flic.kr\/p\/hPQBcJ"
    } ]
  },
  "geo" : { },
  "id_str" : "404834550943322112",
  "text" : "8:36pm Nap-skipping Niko went to bed early http:\/\/t.co\/yyGcCeH6ga",
  "id" : 404834550943322112,
  "created_at" : "2013-11-25 04:50:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/404752761222205440\/photo\/1",
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/ElTWB3djw2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ34feWCUAAXP3Z.jpg",
      "id_str" : "404752761138335744",
      "id" : 404752761138335744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ34feWCUAAXP3Z.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 769
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 769
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ElTWB3djw2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404746602889216000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8698104504, -122.3005931351 ]
  },
  "id_str" : "404752761222205440",
  "in_reply_to_user_id" : 2185,
  "text" : "After: http:\/\/t.co\/ElTWB3djw2",
  "id" : 404752761222205440,
  "in_reply_to_status_id" : 404746602889216000,
  "created_at" : "2013-11-24 23:25:52 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/404746602889216000\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/61RZkkPJqN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ3y4_3CAAA3rEB.jpg",
      "id_str" : "404746602562060288",
      "id" : 404746602562060288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ3y4_3CAAA3rEB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/61RZkkPJqN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8698415729, -122.3004116212 ]
  },
  "id_str" : "404746602889216000",
  "text" : "Niko vs pancake souffl\u00E9. Who win win? http:\/\/t.co\/61RZkkPJqN",
  "id" : 404746602889216000,
  "created_at" : "2013-11-24 23:01:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "indices" : [ 0, 13 ],
      "id_str" : "1186",
      "id" : 1186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404675247300833280",
  "geo" : { },
  "id_str" : "404680054065487874",
  "in_reply_to_user_id" : 1186,
  "text" : "@chrismessina I still see stuff happening behind the scenes but am not in the loop for future plans.",
  "id" : 404680054065487874,
  "in_reply_to_status_id" : 404675247300833280,
  "created_at" : "2013-11-24 18:36:58 +0000",
  "in_reply_to_screen_name" : "chrismessina",
  "in_reply_to_user_id_str" : "1186",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "indices" : [ 0, 13 ],
      "id_str" : "1186",
      "id" : 1186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404675247300833280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595206106, -122.2754974595 ]
  },
  "id_str" : "404679398420262912",
  "in_reply_to_user_id" : 1186,
  "text" : "@chrismessina Yeah sold it to some people who actually work on it regularly.",
  "id" : 404679398420262912,
  "in_reply_to_status_id" : 404675247300833280,
  "created_at" : "2013-11-24 18:34:21 +0000",
  "in_reply_to_screen_name" : "chrismessina",
  "in_reply_to_user_id_str" : "1186",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404484083557752832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596398919, -122.2754812718 ]
  },
  "id_str" : "404485905609539584",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim That's a good book.",
  "id" : 404485905609539584,
  "in_reply_to_status_id" : 404484083557752832,
  "created_at" : "2013-11-24 05:45:29 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 3, 17 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404484693883510786",
  "text" : "RT @buster_ebooks: Door to beautiful accordion musico",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/busterbenson.com\" rel=\"nofollow\"\u003EBuster eBooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "404481796051460096",
    "text" : "Door to beautiful accordion musico",
    "id" : 404481796051460096,
    "created_at" : "2013-11-24 05:29:09 +0000",
    "user" : {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "protected" : false,
      "id_str" : "1901375096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000503050571\/228ccabfeeb4e55bd8e172595babe02e_normal.jpeg",
      "id" : 1901375096,
      "verified" : false
    }
  },
  "id" : 404484693883510786,
  "created_at" : "2013-11-24 05:40:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Casey",
      "screen_name" : "woodbury",
      "indices" : [ 0, 9 ],
      "id_str" : "2321572915",
      "id" : 2321572915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597199131, -122.2754628383 ]
  },
  "id_str" : "404479791824244736",
  "text" : "@woodbury Sure! Just ask me.",
  "id" : 404479791824244736,
  "created_at" : "2013-11-24 05:21:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/jdJ05m2zh6",
      "expanded_url" : "http:\/\/flic.kr\/p\/hMZyjb",
      "display_url" : "flic.kr\/p\/hMZyjb"
    } ]
  },
  "geo" : { },
  "id_str" : "404478530182217728",
  "text" : "8:36pm Meet Bulstrode, a highly disagreeable barge http:\/\/t.co\/jdJ05m2zh6",
  "id" : 404478530182217728,
  "created_at" : "2013-11-24 05:16:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/aN4M8p4BZy",
      "expanded_url" : "https:\/\/vine.co\/v\/hUzMjIzXIt7",
      "display_url" : "vine.co\/v\/hUzMjIzXIt7"
    } ]
  },
  "geo" : { },
  "id_str" : "404421438930956288",
  "text" : "Playing Goldie Blox https:\/\/t.co\/aN4M8p4BZy",
  "id" : 404421438930956288,
  "created_at" : "2013-11-24 01:29:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/WsyVR2a5Ds",
      "expanded_url" : "https:\/\/vine.co\/v\/hUBXelBrHZJ",
      "display_url" : "vine.co\/v\/hUBXelBrHZJ"
    } ]
  },
  "geo" : { },
  "id_str" : "404362893984272385",
  "text" : "Niko found his happy place https:\/\/t.co\/WsyVR2a5Ds",
  "id" : 404362893984272385,
  "created_at" : "2013-11-23 21:36:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pratik",
      "screen_name" : "pratiktandel",
      "indices" : [ 0, 13 ],
      "id_str" : "259246576",
      "id" : 259246576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404319528114327553",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597106871, -122.275534287 ]
  },
  "id_str" : "404319978049925120",
  "in_reply_to_user_id" : 259246576,
  "text" : "@pratiktandel I think the UFO\/aliens is excessive.",
  "id" : 404319978049925120,
  "in_reply_to_status_id" : 404319528114327553,
  "created_at" : "2013-11-23 18:46:09 +0000",
  "in_reply_to_screen_name" : "pratiktandel",
  "in_reply_to_user_id_str" : "259246576",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/404315825479229440\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/MrwNxdp15q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZxrGdmCIAAjT_1.jpg",
      "id_str" : "404315825324040192",
      "id" : 404315825324040192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZxrGdmCIAAjT_1.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 769
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 769
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/MrwNxdp15q"
    } ],
    "hashtags" : [ {
      "text" : "bestparent",
      "indices" : [ 79, 90 ]
    }, {
      "text" : "worstparent",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596931532, -122.275573766 ]
  },
  "id_str" : "404315825479229440",
  "text" : "Niko just asked me what this postcard said and we had a conversation about it. #bestparent or #worstparent? http:\/\/t.co\/MrwNxdp15q",
  "id" : 404315825479229440,
  "created_at" : "2013-11-23 18:29:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruslan Belkin",
      "screen_name" : "ruslansv",
      "indices" : [ 22, 31 ],
      "id_str" : "14656296",
      "id" : 14656296
    }, {
      "name" : "Herdwick Shepherd",
      "screen_name" : "herdyshepherd1",
      "indices" : [ 52, 67 ],
      "id_str" : "467507215",
      "id" : 467507215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/IU7sxXs28x",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2013\/11\/why-this-shepherd-loves-twitter\/281702\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "404111580280811520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859771111, -122.2752401699 ]
  },
  "id_str" : "404120127211196416",
  "in_reply_to_user_id" : 14656296,
  "text" : "Really cool story! RT @ruslansv: Why This Shepherd (@herdyshepherd1) Loves Twitter - The Atlantic http:\/\/t.co\/IU7sxXs28x",
  "id" : 404120127211196416,
  "in_reply_to_status_id" : 404111580280811520,
  "created_at" : "2013-11-23 05:32:01 +0000",
  "in_reply_to_screen_name" : "ruslansv",
  "in_reply_to_user_id_str" : "14656296",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 27, 34 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 39, 43 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/9hbzLOmy2Q",
      "expanded_url" : "http:\/\/flic.kr\/p\/hLpAcq",
      "display_url" : "flic.kr\/p\/hLpAcq"
    } ]
  },
  "geo" : { },
  "id_str" : "404107725145399296",
  "text" : "8:36pm Saying goodnight to @sharon and @ian http:\/\/t.co\/9hbzLOmy2Q",
  "id" : 404107725145399296,
  "created_at" : "2013-11-23 04:42:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77919759, -122.41427638 ]
  },
  "id_str" : "404064267411804160",
  "text" : "When you get subtweeted by your Timehop.",
  "id" : 404064267411804160,
  "created_at" : "2013-11-23 01:50:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/D1nFfgCEse",
      "expanded_url" : "http:\/\/flic.kr\/p\/hK4p8A",
      "display_url" : "flic.kr\/p\/hK4p8A"
    } ]
  },
  "geo" : { },
  "id_str" : "403745847240060928",
  "text" : "8:36pm Selfie day http:\/\/t.co\/D1nFfgCEse",
  "id" : 403745847240060928,
  "created_at" : "2013-11-22 04:44:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vine",
      "screen_name" : "vineapp",
      "indices" : [ 3, 11 ],
      "id_str" : "586671909",
      "id" : 586671909
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vineapp\/status\/403672529404821504\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/CA35FoLug2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZoiBtlCAAABLEE.png",
      "id_str" : "403672529413210112",
      "id" : 403672529413210112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZoiBtlCAAABLEE.png",
      "sizes" : [ {
        "h" : 648,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 797,
        "resize" : "fit",
        "w" : 1260
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CA35FoLug2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/0gMOG7tDKV",
      "expanded_url" : "http:\/\/blog.vine.co\/post\/67701516135\/vine-now-in-more-languages",
      "display_url" : "blog.vine.co\/post\/677015161\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403674616154963968",
  "text" : "RT @vineapp: Vine's going global. You can now use Vine in many new languages: http:\/\/t.co\/0gMOG7tDKV http:\/\/t.co\/CA35FoLug2",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vineapp\/status\/403672529404821504\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/CA35FoLug2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZoiBtlCAAABLEE.png",
        "id_str" : "403672529413210112",
        "id" : 403672529413210112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZoiBtlCAAABLEE.png",
        "sizes" : [ {
          "h" : 648,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 797,
          "resize" : "fit",
          "w" : 1260
        }, {
          "h" : 215,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CA35FoLug2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/0gMOG7tDKV",
        "expanded_url" : "http:\/\/blog.vine.co\/post\/67701516135\/vine-now-in-more-languages",
        "display_url" : "blog.vine.co\/post\/677015161\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "403672529404821504",
    "text" : "Vine's going global. You can now use Vine in many new languages: http:\/\/t.co\/0gMOG7tDKV http:\/\/t.co\/CA35FoLug2",
    "id" : 403672529404821504,
    "created_at" : "2013-11-21 23:53:25 +0000",
    "user" : {
      "name" : "Vine",
      "screen_name" : "vineapp",
      "protected" : false,
      "id_str" : "586671909",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3578238864\/50d7e05aa6fe5d477e48a63047e38ce7_normal.png",
      "id" : 586671909,
      "verified" : true
    }
  },
  "id" : 403674616154963968,
  "created_at" : "2013-11-22 00:01:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pasquale D'Silva",
      "screen_name" : "pasql",
      "indices" : [ 0, 6 ],
      "id_str" : "187793",
      "id" : 187793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403641384629833728",
  "geo" : { },
  "id_str" : "403641603375394816",
  "in_reply_to_user_id" : 187793,
  "text" : "@pasql On your profile page (scroll down). Or, little known shortcut, hold down the compose button.",
  "id" : 403641603375394816,
  "in_reply_to_status_id" : 403641384629833728,
  "created_at" : "2013-11-21 21:50:32 +0000",
  "in_reply_to_screen_name" : "pasql",
  "in_reply_to_user_id_str" : "187793",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Benenson",
      "screen_name" : "fredbenenson",
      "indices" : [ 3, 16 ],
      "id_str" : "2254561",
      "id" : 2254561
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheAtlantic\/status\/403380502884671488\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/sAZzGAiN6M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZkYbg9CEAEsFu3.jpg",
      "id_str" : "403380502607826945",
      "id" : 403380502607826945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZkYbg9CEAEsFu3.jpg",
      "sizes" : [ {
        "h" : 407,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/sAZzGAiN6M"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/S2GaBuMHEw",
      "expanded_url" : "http:\/\/theatln.tc\/1diiDZz",
      "display_url" : "theatln.tc\/1diiDZz"
    } ]
  },
  "geo" : { },
  "id_str" : "403628922174058496",
  "text" : "RT @fredbenenson: Welp, we now know what the beginning of the end looks like, fellow humans: http:\/\/t.co\/S2GaBuMHEw http:\/\/t.co\/sAZzGAiN6M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheAtlantic\/status\/403380502884671488\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/sAZzGAiN6M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZkYbg9CEAEsFu3.jpg",
        "id_str" : "403380502607826945",
        "id" : 403380502607826945,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZkYbg9CEAEsFu3.jpg",
        "sizes" : [ {
          "h" : 407,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/sAZzGAiN6M"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/S2GaBuMHEw",
        "expanded_url" : "http:\/\/theatln.tc\/1diiDZz",
        "display_url" : "theatln.tc\/1diiDZz"
      } ]
    },
    "geo" : { },
    "id_str" : "403383115755700224",
    "text" : "Welp, we now know what the beginning of the end looks like, fellow humans: http:\/\/t.co\/S2GaBuMHEw http:\/\/t.co\/sAZzGAiN6M",
    "id" : 403383115755700224,
    "created_at" : "2013-11-21 04:43:23 +0000",
    "user" : {
      "name" : "Fred Benenson",
      "screen_name" : "fredbenenson",
      "protected" : false,
      "id_str" : "2254561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000407635648\/9f300517424886d011bbab20c87fe0c3_normal.jpeg",
      "id" : 2254561,
      "verified" : false
    }
  },
  "id" : 403628922174058496,
  "created_at" : "2013-11-21 21:00:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 0, 11 ],
      "id_str" : "1586501",
      "id" : 1586501
    }, {
      "name" : "Daniel Thomas May",
      "screen_name" : "iamDTMay",
      "indices" : [ 12, 21 ],
      "id_str" : "32436407",
      "id" : 32436407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403604034008780800",
  "geo" : { },
  "id_str" : "403604609828007936",
  "in_reply_to_user_id" : 1586501,
  "text" : "@nickbilton @iamdtmay I especially enjoyed the voice treatment for Bill Campbell: \"You did a fucking great job.\"",
  "id" : 403604609828007936,
  "in_reply_to_status_id" : 403604034008780800,
  "created_at" : "2013-11-21 19:23:32 +0000",
  "in_reply_to_screen_name" : "nickbilton",
  "in_reply_to_user_id_str" : "1586501",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/drawquest.com\" rel=\"nofollow\"\u003EDrawQuest\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DrawQuest",
      "screen_name" : "DrawQuest",
      "indices" : [ 45, 55 ],
      "id_str" : "608895792",
      "id" : 608895792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/f5PZ1QybvE",
      "expanded_url" : "http:\/\/drawquest.com\/s\/givabe",
      "display_url" : "drawquest.com\/s\/givabe"
    } ]
  },
  "geo" : { },
  "id_str" : "403581061009264640",
  "text" : "Give him a smile! http:\/\/t.co\/f5PZ1QybvE via @DrawQuest",
  "id" : 403581061009264640,
  "created_at" : "2013-11-21 17:49:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859689524, -122.2756180562 ]
  },
  "id_str" : "403402223905812480",
  "text" : "In Niko's head if a bath is too hot then it needs to become warmer. Makes sense to me.",
  "id" : 403402223905812480,
  "created_at" : "2013-11-21 05:59:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reload",
      "indices" : [ 33, 40 ]
    }, {
      "text" : "reload",
      "indices" : [ 41, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403392004886781952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597179083, -122.2756229771 ]
  },
  "id_str" : "403392146796863488",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Give it 2 seconds! #reload #reload",
  "id" : 403392146796863488,
  "in_reply_to_status_id" : 403392004886781952,
  "created_at" : "2013-11-21 05:19:17 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/youtube-capture\/id576941441?mt=8&uo=4\" rel=\"nofollow\"\u003EYouTube Capture on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/cHwvk4iwQr",
      "expanded_url" : "http:\/\/youtu.be\/zDCWQ0b74VI?ac",
      "display_url" : "youtu.be\/zDCWQ0b74VI?ac"
    } ]
  },
  "geo" : { },
  "id_str" : "403391600945938432",
  "text" : "Niko resells the tale of his crash today http:\/\/t.co\/cHwvk4iwQr",
  "id" : 403391600945938432,
  "created_at" : "2013-11-21 05:17:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/0dWCHhd9gA",
      "expanded_url" : "http:\/\/flic.kr\/p\/hHEh2T",
      "display_url" : "flic.kr\/p\/hHEh2T"
    } ]
  },
  "geo" : { },
  "id_str" : "403389330141376512",
  "text" : "8:36pm Taking leave of Alycka and Brasa's house http:\/\/t.co\/0dWCHhd9gA",
  "id" : 403389330141376512,
  "created_at" : "2013-11-21 05:08:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 8, 18 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403369294504812546",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8562236624, -122.275405638 ]
  },
  "id_str" : "403370122313605120",
  "in_reply_to_user_id" : 2185,
  "text" : "And now @kellianne's trying to skew my score.",
  "id" : 403370122313605120,
  "in_reply_to_status_id" : 403369294504812546,
  "created_at" : "2013-11-21 03:51:46 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.856353174, -122.2752538982 ]
  },
  "id_str" : "403369294504812546",
  "text" : "8.8 on lulu",
  "id" : 403369294504812546,
  "created_at" : "2013-11-21 03:48:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403328839817756672",
  "geo" : { },
  "id_str" : "403329326294130688",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates You've missed Doctor Who episodes?",
  "id" : 403329326294130688,
  "in_reply_to_status_id" : 403328839817756672,
  "created_at" : "2013-11-21 01:09:39 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403327445761155072",
  "geo" : { },
  "id_str" : "403328592102178817",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates It's a tough problem to solve but here's the answer: it's a bunch of things (hashtags, people, tweets) that we think you'll like.",
  "id" : 403328592102178817,
  "in_reply_to_status_id" : 403327445761155072,
  "created_at" : "2013-11-21 01:06:44 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403326498578239488",
  "geo" : { },
  "id_str" : "403326763968643072",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Ha. So your first tweet about understanding the Discover tab was a trick!",
  "id" : 403326763968643072,
  "in_reply_to_status_id" : 403326498578239488,
  "created_at" : "2013-11-21 00:59:28 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403325710028132352",
  "geo" : { },
  "id_str" : "403326369712447488",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Yeah but do you remember what was there before? Pretty much the same content but organized more strangely IMO.",
  "id" : 403326369712447488,
  "in_reply_to_status_id" : 403325710028132352,
  "created_at" : "2013-11-21 00:57:54 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403324740745428992",
  "geo" : { },
  "id_str" : "403325148335312897",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Like what?",
  "id" : 403325148335312897,
  "in_reply_to_status_id" : 403324740745428992,
  "created_at" : "2013-11-21 00:53:03 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Baxter",
      "screen_name" : "lorenbaxter",
      "indices" : [ 44, 56 ],
      "id_str" : "15649565",
      "id" : 15649565
    }, {
      "name" : "Exposure",
      "screen_name" : "exposure",
      "indices" : [ 84, 93 ],
      "id_str" : "1884366962",
      "id" : 1884366962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/S83CmHSz4V",
      "expanded_url" : "https:\/\/loren.exposure.so\/double-exposures",
      "display_url" : "loren.exposure.so\/double-exposur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403313281877565440",
  "text" : "This is really great: \u201CDouble Exposures\u201D by @lorenbaxter https:\/\/t.co\/S83CmHSz4V on @exposure",
  "id" : 403313281877565440,
  "created_at" : "2013-11-21 00:05:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 48, 64 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/KTBigW9bmy",
      "expanded_url" : "http:\/\/blog.lift.do\/post\/67591152617\/announcing-lift-for-android",
      "display_url" : "blog.lift.do\/post\/675911526\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "403276507537096704",
  "geo" : { },
  "id_str" : "403276944453541888",
  "in_reply_to_user_id" : 17,
  "text" : "Have an Android? Like tracking habits? \u2014&gt; RT @tonystubblebine: We just opened up Lift for Android to everyone: http:\/\/t.co\/KTBigW9bmy",
  "id" : 403276944453541888,
  "in_reply_to_status_id" : 403276507537096704,
  "created_at" : "2013-11-20 21:41:30 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Abdilova",
      "screen_name" : "abdilisa",
      "indices" : [ 3, 12 ],
      "id_str" : "19940268",
      "id" : 19940268
    }, {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 46, 55 ],
      "id_str" : "376502929",
      "id" : 376502929
    }, {
      "name" : "she++",
      "screen_name" : "sheplusplus",
      "indices" : [ 77, 89 ],
      "id_str" : "522901844",
      "id" : 522901844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "womenintech",
      "indices" : [ 59, 71 ]
    }, {
      "text" : "ftw",
      "indices" : [ 72, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/jQzi89sy3P",
      "expanded_url" : "http:\/\/www.businessinsider.com\/snapchat-early-and-first-employees-2013-11?op=1",
      "display_url" : "businessinsider.com\/snapchat-early\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403272864100405248",
  "text" : "RT @abdilisa: check out all the girls working @Snapchat :) #womenintech #ftw @sheplusplus http:\/\/t.co\/jQzi89sy3P",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Snapchat",
        "screen_name" : "Snapchat",
        "indices" : [ 32, 41 ],
        "id_str" : "376502929",
        "id" : 376502929
      }, {
        "name" : "she++",
        "screen_name" : "sheplusplus",
        "indices" : [ 63, 75 ],
        "id_str" : "522901844",
        "id" : 522901844
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "womenintech",
        "indices" : [ 45, 57 ]
      }, {
        "text" : "ftw",
        "indices" : [ 58, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/jQzi89sy3P",
        "expanded_url" : "http:\/\/www.businessinsider.com\/snapchat-early-and-first-employees-2013-11?op=1",
        "display_url" : "businessinsider.com\/snapchat-early\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "403267912003121152",
    "text" : "check out all the girls working @Snapchat :) #womenintech #ftw @sheplusplus http:\/\/t.co\/jQzi89sy3P",
    "id" : 403267912003121152,
    "created_at" : "2013-11-20 21:05:37 +0000",
    "user" : {
      "name" : "Lisa Abdilova",
      "screen_name" : "abdilisa",
      "protected" : false,
      "id_str" : "19940268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000154242865\/450fbfe81c352987c8d9f3108509bb00_normal.jpeg",
      "id" : 19940268,
      "verified" : false
    }
  },
  "id" : 403272864100405248,
  "created_at" : "2013-11-20 21:25:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "indices" : [ 3, 17 ],
      "id_str" : "1236101",
      "id" : 1236101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/kMgDXGV5uB",
      "expanded_url" : "http:\/\/ben-evans.com\/benedictevans\/2013\/11\/20\/the-meaning-of-really-cheap-android",
      "display_url" : "ben-evans.com\/benedictevans\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403272129149272064",
  "text" : "RT @BenedictEvans: The meaning of really cheap Android http:\/\/t.co\/kMgDXGV5uB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/kMgDXGV5uB",
        "expanded_url" : "http:\/\/ben-evans.com\/benedictevans\/2013\/11\/20\/the-meaning-of-really-cheap-android",
        "display_url" : "ben-evans.com\/benedictevans\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "403270778583801856",
    "text" : "The meaning of really cheap Android http:\/\/t.co\/kMgDXGV5uB",
    "id" : 403270778583801856,
    "created_at" : "2013-11-20 21:17:00 +0000",
    "user" : {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "protected" : false,
      "id_str" : "1236101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454333621331976193\/AX-M-ESC_normal.jpeg",
      "id" : 1236101,
      "verified" : false
    }
  },
  "id" : 403272129149272064,
  "created_at" : "2013-11-20 21:22:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sina Khanifar",
      "screen_name" : "sinak",
      "indices" : [ 18, 24 ],
      "id_str" : "3573701",
      "id" : 3573701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/IivAXMvxO3",
      "expanded_url" : "http:\/\/igg.me\/p\/build-out-double-union\/cstw\/1872842",
      "display_url" : "igg.me\/p\/build-out-do\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "403231912161837057",
  "geo" : { },
  "id_str" : "403234895226343424",
  "in_reply_to_user_id" : 3573701,
  "text" : "Supported! Go! RT @sinak: Help support Double Union, the first feminist hackerspace in SF. Just 37 hours left -&gt; http:\/\/t.co\/IivAXMvxO3",
  "id" : 403234895226343424,
  "in_reply_to_status_id" : 403231912161837057,
  "created_at" : "2013-11-20 18:54:25 +0000",
  "in_reply_to_screen_name" : "sinak",
  "in_reply_to_user_id_str" : "3573701",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 0, 9 ],
      "id_str" : "14986129",
      "id" : 14986129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403180945777258496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597215751, -122.275621066 ]
  },
  "id_str" : "403187978412908544",
  "in_reply_to_user_id" : 14986129,
  "text" : "@irondavy Ooh, thanks. Gonna read it immediately.",
  "id" : 403187978412908544,
  "in_reply_to_status_id" : 403180945777258496,
  "created_at" : "2013-11-20 15:47:59 +0000",
  "in_reply_to_screen_name" : "irondavy",
  "in_reply_to_user_id_str" : "14986129",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Seung",
      "screen_name" : "SebastianSeung",
      "indices" : [ 14, 29 ],
      "id_str" : "122080635",
      "id" : 122080635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/q1S3XC3HIk",
      "expanded_url" : "http:\/\/bit.ly\/I4LvXw",
      "display_url" : "bit.ly\/I4LvXw"
    } ]
  },
  "in_reply_to_status_id_str" : "403179242487160832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595550065, -122.2755847202 ]
  },
  "id_str" : "403186809284202496",
  "in_reply_to_user_id" : 122080635,
  "text" : "Great book RT @SebastianSeung: Society of Mind, wonderful book by AI pioneer Marvin Minsky now freely available http:\/\/t.co\/q1S3XC3HIk",
  "id" : 403186809284202496,
  "in_reply_to_status_id" : 403179242487160832,
  "created_at" : "2013-11-20 15:43:20 +0000",
  "in_reply_to_screen_name" : "SebastianSeung",
  "in_reply_to_user_id_str" : "122080635",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 16, 26 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "QuizUp",
      "screen_name" : "QuizUp",
      "indices" : [ 58, 65 ],
      "id_str" : "1447558507",
      "id" : 1447558507
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/403046253686030336\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/7g1JeKhWPT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZfobqECEAAEUY1.jpg",
      "id_str" : "403046253518262272",
      "id" : 403046253518262272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZfobqECEAAEUY1.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7g1JeKhWPT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/cZR9DGCZZt",
      "expanded_url" : "https:\/\/www.quizup.com?source=share",
      "display_url" : "quizup.com\/?source=share"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859715, -122.275626 ]
  },
  "id_str" : "403046253686030336",
  "text" : "I just defeated @Kellianne in General Knowledge trivia on @QuizUp! https:\/\/t.co\/cZR9DGCZZt http:\/\/t.co\/7g1JeKhWPT",
  "id" : 403046253686030336,
  "created_at" : "2013-11-20 06:24:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 15, 25 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "GhostGallery",
      "screen_name" : "GhostGallery",
      "indices" : [ 42, 55 ],
      "id_str" : "14997696",
      "id" : 14997696
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/403026216535351296\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/xD5b7Rrb8A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZfWNVyCIAAWn_e.jpg",
      "id_str" : "403026216346591232",
      "id" : 403026216346591232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZfWNVyCIAAWn_e.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xD5b7Rrb8A"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596581892, -122.2755184585 ]
  },
  "id_str" : "403026216535351296",
  "text" : "8:36pm New art @Kellianne brought me from @GhostGallery: Spirit Bear http:\/\/t.co\/xD5b7Rrb8A",
  "id" : 403026216535351296,
  "created_at" : "2013-11-20 05:05:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/aVHtuf4Z7N",
      "expanded_url" : "https:\/\/vine.co\/v\/hFK2HwrmVaB",
      "display_url" : "vine.co\/v\/hFK2HwrmVaB"
    } ]
  },
  "geo" : { },
  "id_str" : "403010663947460608",
  "text" : "Niko loves his rain gear https:\/\/t.co\/aVHtuf4Z7N",
  "id" : 403010663947460608,
  "created_at" : "2013-11-20 04:03:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402981032619569152",
  "geo" : { },
  "id_str" : "402982268202795008",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake Woah, where'd you find that?",
  "id" : 402982268202795008,
  "in_reply_to_status_id" : 402981032619569152,
  "created_at" : "2013-11-20 02:10:34 +0000",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Esteban Kozak",
      "screen_name" : "ekozak",
      "indices" : [ 0, 7 ],
      "id_str" : "12694962",
      "id" : 12694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402977780695986176",
  "geo" : { },
  "id_str" : "402978253893152768",
  "in_reply_to_user_id" : 12694962,
  "text" : "@ekozak Congrats on the new stuff in this launch. Looks really great.",
  "id" : 402978253893152768,
  "in_reply_to_status_id" : 402977780695986176,
  "created_at" : "2013-11-20 01:54:37 +0000",
  "in_reply_to_screen_name" : "ekozak",
  "in_reply_to_user_id_str" : "12694962",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lalo",
      "screen_name" : "lalo",
      "indices" : [ 0, 5 ],
      "id_str" : "396383898",
      "id" : 396383898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402975501771214848",
  "geo" : { },
  "id_str" : "402975721947017217",
  "in_reply_to_user_id" : 396383898,
  "text" : "@lalo I built my own app to do it.",
  "id" : 402975721947017217,
  "in_reply_to_status_id" : 402975501771214848,
  "created_at" : "2013-11-20 01:44:33 +0000",
  "in_reply_to_screen_name" : "lalo",
  "in_reply_to_user_id_str" : "396383898",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bellona",
      "screen_name" : "davidbellona",
      "indices" : [ 21, 34 ],
      "id_str" : "237472727",
      "id" : 237472727
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/davidbellona\/status\/402974747891232769\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/HnyDx7mCjh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZenZeDCUAAbFK3.jpg",
      "id_str" : "402974747677315072",
      "id" : 402974747677315072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZenZeDCUAAbFK3.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/HnyDx7mCjh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402974747891232769",
  "geo" : { },
  "id_str" : "402975049893683200",
  "in_reply_to_user_id" : 237472727,
  "text" : "Get yr cat vines! RT @davidbellona: new filters for search in our latest iOS and android apps. http:\/\/t.co\/HnyDx7mCjh",
  "id" : 402975049893683200,
  "in_reply_to_status_id" : 402974747891232769,
  "created_at" : "2013-11-20 01:41:53 +0000",
  "in_reply_to_screen_name" : "davidbellona",
  "in_reply_to_user_id_str" : "237472727",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 0, 8 ],
      "id_str" : "5699",
      "id" : 5699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402923248175693825",
  "geo" : { },
  "id_str" : "402935643895914496",
  "in_reply_to_user_id" : 5699,
  "text" : "@stewart I think it has something to do with the weird way mobile web locks zoom in order to prevent double tapping &amp; horizontal scrolling.",
  "id" : 402935643895914496,
  "in_reply_to_status_id" : 402923248175693825,
  "created_at" : "2013-11-19 23:05:18 +0000",
  "in_reply_to_screen_name" : "stewart",
  "in_reply_to_user_id_str" : "5699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 18, 26 ],
      "id_str" : "5699",
      "id" : 5699
    }, {
      "name" : "Glitch, the game",
      "screen_name" : "playglitch",
      "indices" : [ 33, 44 ],
      "id_str" : "103943240",
      "id" : 103943240
    }, {
      "name" : "Glitch, the game",
      "screen_name" : "playglitch",
      "indices" : [ 72, 83 ],
      "id_str" : "103943240",
      "id" : 103943240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/KO3U2Y3qmQ",
      "expanded_url" : "http:\/\/j.mp\/HVy1fM",
      "display_url" : "j.mp\/HVy1fM"
    } ]
  },
  "geo" : { },
  "id_str" : "402912644790636545",
  "text" : "Woah. So rad that @stewart &amp; @playglitch released 10,000+ pieces of @playglitch art into the public domain: http:\/\/t.co\/KO3U2Y3qmQ",
  "id" : 402912644790636545,
  "created_at" : "2013-11-19 21:33:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 0, 8 ],
      "id_str" : "5699",
      "id" : 5699
    }, {
      "name" : "Glitch, the game",
      "screen_name" : "playglitch",
      "indices" : [ 9, 20 ],
      "id_str" : "103943240",
      "id" : 103943240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402394519049494530",
  "geo" : { },
  "id_str" : "402912577035837440",
  "in_reply_to_user_id" : 5699,
  "text" : "@stewart @playglitch Don't make me change my middle name to Butterfield again. &lt;3 you guys.",
  "id" : 402912577035837440,
  "in_reply_to_status_id" : 402394519049494530,
  "created_at" : "2013-11-19 21:33:38 +0000",
  "in_reply_to_screen_name" : "stewart",
  "in_reply_to_user_id_str" : "5699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thoughts",
      "indices" : [ 5, 14 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402853324216492033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7767200023, -122.4168048859 ]
  },
  "id_str" : "402854442552152064",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm #thoughts?",
  "id" : 402854442552152064,
  "in_reply_to_status_id" : 402853324216492033,
  "created_at" : "2013-11-19 17:42:38 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Sharples",
      "screen_name" : "fredsharples",
      "indices" : [ 0, 13 ],
      "id_str" : "18338254",
      "id" : 18338254
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402848792489127936",
  "geo" : { },
  "id_str" : "402853390146748416",
  "in_reply_to_user_id" : 18338254,
  "text" : "@fredsharples Ha, that one flew over my head. It does have a bit of Flaming Lips, and LCD Soundsystem too.",
  "id" : 402853390146748416,
  "in_reply_to_status_id" : 402848792489127936,
  "created_at" : "2013-11-19 17:38:27 +0000",
  "in_reply_to_screen_name" : "fredsharples",
  "in_reply_to_user_id_str" : "18338254",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Sharples",
      "screen_name" : "fredsharples",
      "indices" : [ 0, 13 ],
      "id_str" : "18338254",
      "id" : 18338254
    }, {
      "name" : "Wayne Coyne",
      "screen_name" : "waynecoyne",
      "indices" : [ 89, 100 ],
      "id_str" : "172933437",
      "id" : 172933437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402656785405726723",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597213926, -122.2756207443 ]
  },
  "id_str" : "402674802147598336",
  "in_reply_to_user_id" : 18338254,
  "text" : "@fredsharples I've liked all their stuff but this one surpassed my expectations. How did @waynecoyne convince you?",
  "id" : 402674802147598336,
  "in_reply_to_status_id" : 402656785405726723,
  "created_at" : "2013-11-19 05:48:48 +0000",
  "in_reply_to_screen_name" : "fredsharples",
  "in_reply_to_user_id_str" : "18338254",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402632361524723713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597322218, -122.2756136123 ]
  },
  "id_str" : "402674488476581888",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach Now that I agree with! PS as I read this I realized I attended that talk in 2003. Hard to believe that was pre-Facebook and Twitter.",
  "id" : 402674488476581888,
  "in_reply_to_status_id" : 402632361524723713,
  "created_at" : "2013-11-19 05:47:34 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 21, 31 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/bKHQHifeZA",
      "expanded_url" : "http:\/\/flic.kr\/p\/hEByVr",
      "display_url" : "flic.kr\/p\/hEByVr"
    } ]
  },
  "geo" : { },
  "id_str" : "402660322676596736",
  "text" : "8:36pm Happy to have @kellianne back in town http:\/\/t.co\/bKHQHifeZA",
  "id" : 402660322676596736,
  "created_at" : "2013-11-19 04:51:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Oestlien",
      "screen_name" : "christianism",
      "indices" : [ 0, 13 ],
      "id_str" : "9295502",
      "id" : 9295502
    }, {
      "name" : "Sung Hu Kim",
      "screen_name" : "sunghu",
      "indices" : [ 14, 21 ],
      "id_str" : "11407672",
      "id" : 11407672
    }, {
      "name" : "Bryan Haggerty",
      "screen_name" : "bhaggs",
      "indices" : [ 22, 29 ],
      "id_str" : "1692881",
      "id" : 1692881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402650702771544064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597728132, -122.2754968144 ]
  },
  "id_str" : "402654491763175424",
  "in_reply_to_user_id" : 9295502,
  "text" : "@christianism @sunghu @bhaggs Can't decide if that's more or less rock n' roll than my Sat night: reading If You Give A Pig A Pancake 5x.",
  "id" : 402654491763175424,
  "in_reply_to_status_id" : 402650702771544064,
  "created_at" : "2013-11-19 04:28:06 +0000",
  "in_reply_to_screen_name" : "christianism",
  "in_reply_to_user_id_str" : "9295502",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sung Hu Kim",
      "screen_name" : "sunghu",
      "indices" : [ 0, 7 ],
      "id_str" : "11407672",
      "id" : 11407672
    }, {
      "name" : "Christian Oestlien",
      "screen_name" : "christianism",
      "indices" : [ 8, 21 ],
      "id_str" : "9295502",
      "id" : 9295502
    }, {
      "name" : "Bryan Haggerty",
      "screen_name" : "bhaggs",
      "indices" : [ 22, 29 ],
      "id_str" : "1692881",
      "id" : 1692881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402648021239734272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598013071, -122.2753632202 ]
  },
  "id_str" : "402650277448151041",
  "in_reply_to_user_id" : 11407672,
  "text" : "@sunghu @christianism @bhaggs That was actually the first CD I bought on my own.",
  "id" : 402650277448151041,
  "in_reply_to_status_id" : 402648021239734272,
  "created_at" : "2013-11-19 04:11:21 +0000",
  "in_reply_to_screen_name" : "sunghu",
  "in_reply_to_user_id_str" : "11407672",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402629776403210240",
  "geo" : { },
  "id_str" : "402631009318891520",
  "in_reply_to_user_id" : 2185,
  "text" : "@isaach I guess I just disagree that the best people leave a community first. We aren't econs managing our communities like day traders.",
  "id" : 402631009318891520,
  "in_reply_to_status_id" : 402629776403210240,
  "created_at" : "2013-11-19 02:54:47 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402621413112037376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8091668355, -122.2722624158 ]
  },
  "id_str" : "402629776403210240",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach The idea of plazas and warrens seems somewhat interesting but the rest of that post really rubs me the wrong way.",
  "id" : 402629776403210240,
  "in_reply_to_status_id" : 402621413112037376,
  "created_at" : "2013-11-19 02:49:53 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arcade Fire",
      "screen_name" : "arcadefire",
      "indices" : [ 32, 43 ],
      "id_str" : "18396706",
      "id" : 18396706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7886332344, -122.4045469798 ]
  },
  "id_str" : "402625806926487553",
  "text" : "Do some people not like the new @arcadefire album? I can't stop listening to it.",
  "id" : 402625806926487553,
  "created_at" : "2013-11-19 02:34:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402622937561174016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7792348875, -122.4142454434 ]
  },
  "id_str" : "402623758554247169",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall Oops, I use the tone argument against Niko all the time. :)",
  "id" : 402623758554247169,
  "in_reply_to_status_id" : 402622937561174016,
  "created_at" : "2013-11-19 02:25:59 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "roofbreakup",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/GfdQGEyUZW",
      "expanded_url" : "https:\/\/twitter.com\/isaach\/timelines\/402492214875394048",
      "display_url" : "twitter.com\/isaach\/timelin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402494234961276928",
  "text" : "RT @isaach: this #roofbreakup is fantastic https:\/\/t.co\/GfdQGEyUZW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "roofbreakup",
        "indices" : [ 5, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/GfdQGEyUZW",
        "expanded_url" : "https:\/\/twitter.com\/isaach\/timelines\/402492214875394048",
        "display_url" : "twitter.com\/isaach\/timelin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "402493448613158913",
    "text" : "this #roofbreakup is fantastic https:\/\/t.co\/GfdQGEyUZW",
    "id" : 402493448613158913,
    "created_at" : "2013-11-18 17:48:10 +0000",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430605387117494272\/lmplHwca_normal.png",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 402494234961276928,
  "created_at" : "2013-11-18 17:51:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402493448613158913",
  "geo" : { },
  "id_str" : "402494214878932992",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach Woah, and you reversed the order so oldest is on top... disorienting at first but also easier to read.",
  "id" : 402494214878932992,
  "in_reply_to_status_id" : 402493448613158913,
  "created_at" : "2013-11-18 17:51:13 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelton Lynn",
      "screen_name" : "keltonlynn",
      "indices" : [ 0, 11 ],
      "id_str" : "27674040",
      "id" : 27674040
    }, {
      "name" : "Annie Kadavy",
      "screen_name" : "AnnieKadavy",
      "indices" : [ 12, 24 ],
      "id_str" : "2469858480",
      "id" : 2469858480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402480676156354560",
  "geo" : { },
  "id_str" : "402490837306597376",
  "in_reply_to_user_id" : 27674040,
  "text" : "@keltonlynn @anniekadavy That's awesome, congrats!",
  "id" : 402490837306597376,
  "in_reply_to_status_id" : 402480676156354560,
  "created_at" : "2013-11-18 17:37:48 +0000",
  "in_reply_to_screen_name" : "keltonlynn",
  "in_reply_to_user_id_str" : "27674040",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chavi",
      "screen_name" : "ChavaRisa",
      "indices" : [ 118, 128 ],
      "id_str" : "19054503",
      "id" : 19054503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/eu3DCeQRYL",
      "expanded_url" : "http:\/\/www.aeonmagazine.com\/world-views\/does-each-click-of-attention-cost-a-bit-of-ourselves\/",
      "display_url" : "aeonmagazine.com\/world-views\/do\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "402156400064724992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763361113, -122.416835484 ]
  },
  "id_str" : "402490408661291008",
  "in_reply_to_user_id" : 2185,
  "text" : "And here's what I was clumsily circling around regarding the attention economy yesterday: http:\/\/t.co\/eu3DCeQRYL \/via @ChavaRisa",
  "id" : 402490408661291008,
  "in_reply_to_status_id" : 402156400064724992,
  "created_at" : "2013-11-18 17:36:05 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/read-it-later-pro\/id309601447?mt=8&uo=4\" rel=\"nofollow\"\u003EPocket for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chavi",
      "screen_name" : "ChavaRisa",
      "indices" : [ 0, 10 ],
      "id_str" : "19054503",
      "id" : 19054503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402178161510608896",
  "geo" : { },
  "id_str" : "402489603124248576",
  "in_reply_to_user_id" : 19054503,
  "text" : "@ChavaRisa That article said perfectly what I was trying to articulate. Thank you!",
  "id" : 402489603124248576,
  "in_reply_to_status_id" : 402178161510608896,
  "created_at" : "2013-11-18 17:32:53 +0000",
  "in_reply_to_screen_name" : "ChavaRisa",
  "in_reply_to_user_id_str" : "19054503",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Costa",
      "screen_name" : "jasoncosta",
      "indices" : [ 0, 11 ],
      "id_str" : "14927800",
      "id" : 14927800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596920685, -122.27567596 ]
  },
  "id_str" : "402343892323811329",
  "in_reply_to_user_id" : 14927800,
  "text" : "@jasoncosta Not sure how I stopped following you!",
  "id" : 402343892323811329,
  "created_at" : "2013-11-18 07:53:53 +0000",
  "in_reply_to_screen_name" : "jasoncosta",
  "in_reply_to_user_id_str" : "14927800",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/2TEZ1ylezI",
      "expanded_url" : "http:\/\/flic.kr\/p\/hCYXEz",
      "display_url" : "flic.kr\/p\/hCYXEz"
    } ]
  },
  "geo" : { },
  "id_str" : "402308384055361536",
  "text" : "8:36pm Finally finishing my morning coffee http:\/\/t.co\/2TEZ1ylezI",
  "id" : 402308384055361536,
  "created_at" : "2013-11-18 05:32:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pogue",
      "screen_name" : "Pogue",
      "indices" : [ 3, 9 ],
      "id_str" : "9534522",
      "id" : 9534522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/xnrgAGt7ih",
      "expanded_url" : "http:\/\/j.mp\/I0nDnE",
      "display_url" : "j.mp\/I0nDnE"
    } ]
  },
  "geo" : { },
  "id_str" : "402246586236805120",
  "text" : "RT @Pogue: Cool: A photographer has set out to find &amp; photograph unrelated people who look exactly alike. A few are amazing. http:\/\/t.co\/xn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/xnrgAGt7ih",
        "expanded_url" : "http:\/\/j.mp\/I0nDnE",
        "display_url" : "j.mp\/I0nDnE"
      } ]
    },
    "geo" : { },
    "id_str" : "402246321161388032",
    "text" : "Cool: A photographer has set out to find &amp; photograph unrelated people who look exactly alike. A few are amazing. http:\/\/t.co\/xnrgAGt7ih",
    "id" : 402246321161388032,
    "created_at" : "2013-11-18 01:26:11 +0000",
    "user" : {
      "name" : "David Pogue",
      "screen_name" : "Pogue",
      "protected" : false,
      "id_str" : "9534522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/69259417\/dp_photo__small__normal.jpg",
      "id" : 9534522,
      "verified" : true
    }
  },
  "id" : 402246586236805120,
  "created_at" : "2013-11-18 01:27:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 0, 7 ],
      "id_str" : "47",
      "id" : 47
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402213641472057344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8572554604, -122.2530997063 ]
  },
  "id_str" : "402220544445018112",
  "in_reply_to_user_id" : 47,
  "text" : "@kellan I've build a couple versions of this for hack weeks (and prior to joining). I might give your idea a shot.",
  "id" : 402220544445018112,
  "in_reply_to_status_id" : 402213641472057344,
  "created_at" : "2013-11-17 23:43:45 +0000",
  "in_reply_to_screen_name" : "kellan",
  "in_reply_to_user_id_str" : "47",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McAllister",
      "screen_name" : "ianmcall",
      "indices" : [ 0, 9 ],
      "id_str" : "2035631",
      "id" : 2035631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402160821733580800",
  "geo" : { },
  "id_str" : "402162225235763200",
  "in_reply_to_user_id" : 2035631,
  "text" : "@ianmcall Don't hold your breath. :)",
  "id" : 402162225235763200,
  "in_reply_to_status_id" : 402160821733580800,
  "created_at" : "2013-11-17 19:52:00 +0000",
  "in_reply_to_screen_name" : "ianmcall",
  "in_reply_to_user_id_str" : "2035631",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402161132506341376",
  "geo" : { },
  "id_str" : "402161536275185664",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler I have more questions than answers, but I am definitely curious to learn more.",
  "id" : 402161536275185664,
  "in_reply_to_status_id" : 402161132506341376,
  "created_at" : "2013-11-17 19:49:16 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sundaypost",
      "indices" : [ 110, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/xlqVrbI8F0",
      "expanded_url" : "https:\/\/medium.com\/sunday-post\/80643cc7c396",
      "display_url" : "medium.com\/sunday-post\/80\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "402149645280763905",
  "geo" : { },
  "id_str" : "402156400064724992",
  "in_reply_to_user_id" : 2185,
  "text" : "4 kinds of attention that people, products, and services can try to extract from you: https:\/\/t.co\/xlqVrbI8F0 #sundaypost",
  "id" : 402156400064724992,
  "in_reply_to_status_id" : 402149645280763905,
  "created_at" : "2013-11-17 19:28:52 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402149645280763905",
  "geo" : { },
  "id_str" : "402150034910609409",
  "in_reply_to_user_id" : 2185,
  "text" : "(And is this why the sex\/porn industry often pushes technology forward?)",
  "id" : 402150034910609409,
  "in_reply_to_status_id" : 402149645280763905,
  "created_at" : "2013-11-17 19:03:34 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402145457448554496",
  "geo" : { },
  "id_str" : "402149645280763905",
  "in_reply_to_user_id" : 2185,
  "text" : "Can technology enable quality time with the people and interests we love most? If so, which tools are currently best at it?",
  "id" : 402149645280763905,
  "in_reply_to_status_id" : 402145457448554496,
  "created_at" : "2013-11-17 19:02:01 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402142143948390401",
  "geo" : { },
  "id_str" : "402145457448554496",
  "in_reply_to_user_id" : 2185,
  "text" : "Curious to see if we're able to move towards quality attention (and past impulsive attention) in the next phase of this war.",
  "id" : 402145457448554496,
  "in_reply_to_status_id" : 402142143948390401,
  "created_at" : "2013-11-17 18:45:23 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/zmyNsOCvSa",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Attention_economy",
      "display_url" : "en.wikipedia.org\/wiki\/Attention\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "402141435832446977",
  "geo" : { },
  "id_str" : "402142143948390401",
  "in_reply_to_user_id" : 2185,
  "text" : "Browser Wars -&gt; Mobile OS Wars -&gt; Attention Wars. http:\/\/t.co\/zmyNsOCvSa",
  "id" : 402142143948390401,
  "in_reply_to_status_id" : 402141435832446977,
  "created_at" : "2013-11-17 18:32:13 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/pixpJAYxIU",
      "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/elements\/2013\/11\/why-did-snapchat-turn-down-three-billion-dollars.html",
      "display_url" : "newyorker.com\/online\/blogs\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402141435832446977",
  "text" : "Regarding Snapchat: \"The question is why and how attention has become so valuable, and if will continue to be.\" http:\/\/t.co\/pixpJAYxIU",
  "id" : 402141435832446977,
  "created_at" : "2013-11-17 18:29:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "QuizUp",
      "screen_name" : "QuizUp",
      "indices" : [ 74, 81 ],
      "id_str" : "1447558507",
      "id" : 1447558507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401929397956915201",
  "geo" : { },
  "id_str" : "401959853637115904",
  "in_reply_to_user_id" : 2185,
  "text" : "Forget about that blog post. I just burned through my brain cells playing @QuizUp.",
  "id" : 401959853637115904,
  "in_reply_to_status_id" : 401929397956915201,
  "created_at" : "2013-11-17 06:27:51 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 0, 6 ],
      "id_str" : "5469512",
      "id" : 5469512
    }, {
      "name" : "Marc Hemeon",
      "screen_name" : "hemeon",
      "indices" : [ 7, 14 ],
      "id_str" : "19010715",
      "id" : 19010715
    }, {
      "name" : "QuizUp",
      "screen_name" : "QuizUp",
      "indices" : [ 15, 22 ],
      "id_str" : "1447558507",
      "id" : 1447558507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401949152344424448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597299613, -122.2755145167 ]
  },
  "id_str" : "401949665320398848",
  "in_reply_to_user_id" : 5469512,
  "text" : "@micah @hemeon @QuizUp It's so good!",
  "id" : 401949665320398848,
  "in_reply_to_status_id" : 401949152344424448,
  "created_at" : "2013-11-17 05:47:22 +0000",
  "in_reply_to_screen_name" : "micah",
  "in_reply_to_user_id_str" : "5469512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "QuizUp",
      "screen_name" : "QuizUp",
      "indices" : [ 28, 35 ],
      "id_str" : "1447558507",
      "id" : 1447558507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/q9plSvNkSM",
      "expanded_url" : "http:\/\/venturebeat.com\/2013\/11\/07\/plain-vanillas-quizup-for-iphone-will-be-the-biggest-trivia-game-in-the-world\/",
      "display_url" : "venturebeat.com\/2013\/11\/07\/pla\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859658, -122.275635 ]
  },
  "id_str" : "401948574306422784",
  "text" : "Background on the makers of @quizup: best trivia game I've ever played. http:\/\/t.co\/q9plSvNkSM",
  "id" : 401948574306422784,
  "created_at" : "2013-11-17 05:43:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/401941553284784128\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/HvUmOhD751",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZP7toGCUAAnUPT.jpg",
      "id_str" : "401941553041526784",
      "id" : 401941553041526784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZP7toGCUAAnUPT.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HvUmOhD751"
    } ],
    "hashtags" : [ {
      "text" : "QuizUp",
      "indices" : [ 34, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/cZR9DGCZZt",
      "expanded_url" : "https:\/\/www.quizup.com?source=share",
      "display_url" : "quizup.com\/?source=share"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859697, -122.275619 ]
  },
  "id_str" : "401941553284784128",
  "text" : "I just lost 5 matches in a row in #QuizUp! Why am I even sharing this? https:\/\/t.co\/cZR9DGCZZt http:\/\/t.co\/HvUmOhD751",
  "id" : 401941553284784128,
  "created_at" : "2013-11-17 05:15:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "QuizUp",
      "screen_name" : "QuizUp",
      "indices" : [ 29, 36 ],
      "id_str" : "1447558507",
      "id" : 1447558507
    }, {
      "name" : "asa",
      "screen_name" : "asa",
      "indices" : [ 49, 53 ],
      "id_str" : "407",
      "id" : 407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/rcor2zYmS8",
      "expanded_url" : "http:\/\/flic.kr\/p\/hB1q4u",
      "display_url" : "flic.kr\/p\/hB1q4u"
    } ]
  },
  "geo" : { },
  "id_str" : "401937612703027201",
  "text" : "8:36pm Sort of blown away by @quizup even though @asa is killing me. Challenge me! http:\/\/t.co\/rcor2zYmS8",
  "id" : 401937612703027201,
  "created_at" : "2013-11-17 04:59:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Torres",
      "screen_name" : "TorresChess",
      "indices" : [ 0, 12 ],
      "id_str" : "928501447",
      "id" : 928501447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/xV3cj74J6w",
      "expanded_url" : "http:\/\/medium.com\/@buster",
      "display_url" : "medium.com\/@buster"
    }, {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/tJIh6O3LhU",
      "expanded_url" : "http:\/\/wayoftheduck.com",
      "display_url" : "wayoftheduck.com"
    } ]
  },
  "in_reply_to_status_id_str" : "401929908697317377",
  "geo" : { },
  "id_str" : "401930773705412608",
  "in_reply_to_user_id" : 928501447,
  "text" : "@TorresChess I've been doing most of my blogging on http:\/\/t.co\/xV3cj74J6w lately. But also http:\/\/t.co\/tJIh6O3LhU sometimes.",
  "id" : 401930773705412608,
  "in_reply_to_status_id" : 401929908697317377,
  "created_at" : "2013-11-17 04:32:18 +0000",
  "in_reply_to_screen_name" : "TorresChess",
  "in_reply_to_user_id_str" : "928501447",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yolo",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401929397956915201",
  "text" : "Niko's asleep, Kellianne's in Seattle, and I'm excited to drink a glass of wine and write a blog post. #yolo",
  "id" : 401929397956915201,
  "created_at" : "2013-11-17 04:26:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401928638611746816",
  "geo" : { },
  "id_str" : "401928988563480576",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Ha. The early birds of tech don't even wake up until 9am. I get in at 10 and am often the first person on my team to arrive.",
  "id" : 401928988563480576,
  "in_reply_to_status_id" : 401928638611746816,
  "created_at" : "2013-11-17 04:25:13 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Average Joey",
      "screen_name" : "startmyquest",
      "indices" : [ 63, 76 ],
      "id_str" : "925844149",
      "id" : 925844149
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 105, 115 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/7PLEHp5u4A",
      "expanded_url" : "http:\/\/www.yukaichou.com\/gamification-study\/gamification-750wordscom-writing-day\/",
      "display_url" : "yukaichou.com\/gamification-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401928185282969600",
  "text" : "A well-articulated and flattering review of 750 Words. Thanks, @startmyquest. http:\/\/t.co\/7PLEHp5u4A \/cc @kellianne",
  "id" : 401928185282969600,
  "created_at" : "2013-11-17 04:22:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401927506929807361",
  "geo" : { },
  "id_str" : "401927825113894912",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Unfortunately my commute is 45 minutes. I realize naps will not last forever but enjoying them while they last.",
  "id" : 401927825113894912,
  "in_reply_to_status_id" : 401927506929807361,
  "created_at" : "2013-11-17 04:20:35 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401916893180600321",
  "geo" : { },
  "id_str" : "401926455992385536",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Official time: sometime between 8:03 and 8:10pm pacific time. But his energy was sleepier all afternoon.",
  "id" : 401926455992385536,
  "in_reply_to_status_id" : 401916893180600321,
  "created_at" : "2013-11-17 04:15:09 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dudeweekend",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/uy5EQX24wX",
      "expanded_url" : "https:\/\/vine.co\/v\/htgOjVFgwOp",
      "display_url" : "vine.co\/v\/htgOjVFgwOp"
    } ]
  },
  "geo" : { },
  "id_str" : "401896417004113920",
  "text" : "#dudeweekend continues https:\/\/t.co\/uy5EQX24wX",
  "id" : 401896417004113920,
  "created_at" : "2013-11-17 02:15:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Bogan",
      "screen_name" : "waferbaby",
      "indices" : [ 0, 10 ],
      "id_str" : "821753",
      "id" : 821753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401861837555130368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8546105947, -122.278732069 ]
  },
  "id_str" : "401865861004132352",
  "in_reply_to_user_id" : 821753,
  "text" : "@waferbaby Simplify. \"Short URL designer.\" \"Bit.ly ninja.\"",
  "id" : 401865861004132352,
  "in_reply_to_status_id" : 401861837555130368,
  "created_at" : "2013-11-17 00:14:22 +0000",
  "in_reply_to_screen_name" : "waferbaby",
  "in_reply_to_user_id_str" : "821753",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/401858754603278336\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/2iTNIE5tOa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZOwaHcCIAAnIMJ.jpg",
      "id_str" : "401858754485821440",
      "id" : 401858754485821440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZOwaHcCIAAnIMJ.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2iTNIE5tOa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597251186, -122.2754903791 ]
  },
  "id_str" : "401858754603278336",
  "text" : "Sunny day \u2714\uFE0F \nHammock \u2714\uFE0F \nKettle corn \u2714\uFE0F \nDudes \u2714\uFE0F\nSkipped nap \u2714\uFE0F http:\/\/t.co\/2iTNIE5tOa",
  "id" : 401858754603278336,
  "created_at" : "2013-11-16 23:46:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401575337223405568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596609077, -122.2754630481 ]
  },
  "id_str" : "401608187683426304",
  "in_reply_to_user_id" : 2185,
  "text" : "Results: we both passed out before 10pm with the light on and toys in our hands.",
  "id" : 401608187683426304,
  "in_reply_to_status_id" : 401575337223405568,
  "created_at" : "2013-11-16 07:10:28 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 0, 13 ],
      "id_str" : "14471007",
      "id" : 14471007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401525234693844992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596876488, -122.2756210561 ]
  },
  "id_str" : "401584112458149888",
  "in_reply_to_user_id" : 14471007,
  "text" : "@dianakimball Wow. Need to retread that a couple times. Thank you.",
  "id" : 401584112458149888,
  "in_reply_to_status_id" : 401525234693844992,
  "created_at" : "2013-11-16 05:34:48 +0000",
  "in_reply_to_screen_name" : "dianakimball",
  "in_reply_to_user_id_str" : "14471007",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401577292150738944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597131325, -122.2754573544 ]
  },
  "id_str" : "401577745613725696",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara Yeah it's gonna be awesome!",
  "id" : 401577745613725696,
  "in_reply_to_status_id" : 401577292150738944,
  "created_at" : "2013-11-16 05:09:30 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 0, 5 ],
      "id_str" : "541",
      "id" : 541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401575516013998080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597061425, -122.275560145 ]
  },
  "id_str" : "401576717648535552",
  "in_reply_to_user_id" : 541,
  "text" : "@lane We like you too!",
  "id" : 401576717648535552,
  "in_reply_to_status_id" : 401575516013998080,
  "created_at" : "2013-11-16 05:05:25 +0000",
  "in_reply_to_screen_name" : "lane",
  "in_reply_to_user_id_str" : "541",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/401575337223405568\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/KocPzvitYQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZKupDLCYAAyNaA.jpg",
      "id_str" : "401575337038864384",
      "id" : 401575337038864384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZKupDLCYAAyNaA.jpg",
      "sizes" : [ {
        "h" : 769,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 769,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KocPzvitYQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597271136, -122.275524405 ]
  },
  "id_str" : "401575337223405568",
  "text" : "8:36pm Dude weekend! I've made Niko boss and he wants to see how late we can stay up. Stay tuned. http:\/\/t.co\/KocPzvitYQ",
  "id" : 401575337223405568,
  "created_at" : "2013-11-16 04:59:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 0, 6 ],
      "id_str" : "5469512",
      "id" : 5469512
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 7, 16 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401564825798463489",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859714249, -122.2756189983 ]
  },
  "id_str" : "401567596320784384",
  "in_reply_to_user_id" : 5469512,
  "text" : "@micah @anildash Thanks.",
  "id" : 401567596320784384,
  "in_reply_to_status_id" : 401564825798463489,
  "created_at" : "2013-11-16 04:29:10 +0000",
  "in_reply_to_screen_name" : "micah",
  "in_reply_to_user_id_str" : "5469512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Torres",
      "screen_name" : "TorresChess",
      "indices" : [ 0, 12 ],
      "id_str" : "928501447",
      "id" : 928501447
    }, {
      "name" : "Wilson Galyean",
      "screen_name" : "wgalyean",
      "indices" : [ 13, 22 ],
      "id_str" : "41497712",
      "id" : 41497712
    }, {
      "name" : "david",
      "screen_name" : "cycl3",
      "indices" : [ 23, 29 ],
      "id_str" : "69047334",
      "id" : 69047334
    }, {
      "name" : "Hadley Harris",
      "screen_name" : "Hadley",
      "indices" : [ 30, 37 ],
      "id_str" : "8956182",
      "id" : 8956182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401559428849082368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596732347, -122.2755381559 ]
  },
  "id_str" : "401560455778295808",
  "in_reply_to_user_id" : 928501447,
  "text" : "@TorresChess @wgalyean @cycl3 @Hadley I think it was an honest mistake. People see numbers and their brains fly out the window.",
  "id" : 401560455778295808,
  "in_reply_to_status_id" : 401559428849082368,
  "created_at" : "2013-11-16 04:00:47 +0000",
  "in_reply_to_screen_name" : "TorresChess",
  "in_reply_to_user_id_str" : "928501447",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Torres",
      "screen_name" : "TorresChess",
      "indices" : [ 1, 13 ],
      "id_str" : "928501447",
      "id" : 928501447
    }, {
      "name" : "Hadley Harris",
      "screen_name" : "Hadley",
      "indices" : [ 14, 21 ],
      "id_str" : "8956182",
      "id" : 8956182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401550918124331008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8593699717, -122.2735332112 ]
  },
  "id_str" : "401553042694082561",
  "in_reply_to_user_id" : 928501447,
  "text" : ".@TorresChess @Hadley Send a snap to 10 people it counts as 10 photos. Everyone else counts it as 1. 350M snaps\/day = ? unique photos?",
  "id" : 401553042694082561,
  "in_reply_to_status_id" : 401550918124331008,
  "created_at" : "2013-11-16 03:31:20 +0000",
  "in_reply_to_screen_name" : "TorresChess",
  "in_reply_to_user_id_str" : "928501447",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Harris",
      "screen_name" : "Hadley",
      "indices" : [ 31, 38 ],
      "id_str" : "8956182",
      "id" : 8956182
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Hadley\/status\/401103084014673920\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/jINirp011c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZEBIS8CMAEtpOc.jpg",
      "id_str" : "401103083846905857",
      "id" : 401103083846905857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZEBIS8CMAEtpOc.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/jINirp011c"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401103084014673920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.852917563, -122.2705916121 ]
  },
  "id_str" : "401549091114455042",
  "in_reply_to_user_id" : 8956182,
  "text" : "And yet, totally wrong data RT @Hadley: This is why Facebook made such a crazy offer for Snapchat http:\/\/t.co\/jINirp011c",
  "id" : 401549091114455042,
  "in_reply_to_status_id" : 401103084014673920,
  "created_at" : "2013-11-16 03:15:38 +0000",
  "in_reply_to_screen_name" : "Hadley",
  "in_reply_to_user_id_str" : "8956182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "truestory",
      "indices" : [ 43, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8370127337, -122.2682974899 ]
  },
  "id_str" : "401548093683818496",
  "text" : "Zulily's IPO raised about 5x Amazon's IPO. #truestory",
  "id" : 401548093683818496,
  "created_at" : "2013-11-16 03:11:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/nbbzPAvZeh",
      "expanded_url" : "https:\/\/medium.com\/better-humans\/20cc8d9c7494",
      "display_url" : "medium.com\/better-humans\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "401545314969993216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8019430986, -122.2739399414 ]
  },
  "id_str" : "401545754004574208",
  "in_reply_to_user_id" : 2185,
  "text" : "@anildash See https:\/\/t.co\/nbbzPAvZeh for details.",
  "id" : 401545754004574208,
  "in_reply_to_status_id" : 401545314969993216,
  "created_at" : "2013-11-16 03:02:22 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401545076288933888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8036618104, -122.2720091034 ]
  },
  "id_str" : "401545314969993216",
  "in_reply_to_user_id" : 2185,
  "text" : "@anildash Where quality time can be with either people or passions. This is what we value on our death beds.",
  "id" : 401545314969993216,
  "in_reply_to_status_id" : 401545076288933888,
  "created_at" : "2013-11-16 03:00:38 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401544650089299968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.803483054, -122.2722067862 ]
  },
  "id_str" : "401545076288933888",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash True. But I think it needs to be broken down beyond creating meaning. My preferred currency is enabling quality time.",
  "id" : 401545076288933888,
  "in_reply_to_status_id" : 401544650089299968,
  "created_at" : "2013-11-16 02:59:41 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401542153379520512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7989170398, -122.2774349444 ]
  },
  "id_str" : "401544562557984768",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Only problem is that making meaning is a function of autonomy. Helping people make meaning is like being a leader of anarchists.",
  "id" : 401544562557984768,
  "in_reply_to_status_id" : 401542153379520512,
  "created_at" : "2013-11-16 02:57:38 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sachin Agarwal",
      "screen_name" : "agarwal",
      "indices" : [ 0, 8 ],
      "id_str" : "15105000",
      "id" : 15105000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401491635315277824",
  "geo" : { },
  "id_str" : "401517194934120448",
  "in_reply_to_user_id" : 15105000,
  "text" : "@agarwal Use airplane mode whenever you're not actually using your phone. Super easy with the control center tray. Also saves battery.",
  "id" : 401517194934120448,
  "in_reply_to_status_id" : 401491635315277824,
  "created_at" : "2013-11-16 01:08:53 +0000",
  "in_reply_to_screen_name" : "agarwal",
  "in_reply_to_user_id_str" : "15105000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7771874546, -122.4165165236 ]
  },
  "id_str" : "401484422878212098",
  "text" : "*Slow golf clap*",
  "id" : 401484422878212098,
  "created_at" : "2013-11-15 22:58:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Gotwalt",
      "screen_name" : "gotwalt",
      "indices" : [ 3, 11 ],
      "id_str" : "1888",
      "id" : 1888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401444326128881664",
  "text" : "RT @gotwalt: Thinking about maybe robbing a bank this afternoon just to meet Batkid.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401443486718627840",
    "text" : "Thinking about maybe robbing a bank this afternoon just to meet Batkid.",
    "id" : 401443486718627840,
    "created_at" : "2013-11-15 20:16:00 +0000",
    "user" : {
      "name" : "Aaron Gotwalt",
      "screen_name" : "gotwalt",
      "protected" : false,
      "id_str" : "1888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2589391766\/m5mb10zw09c8ieytzy6o_normal.jpeg",
      "id" : 1888,
      "verified" : false
    }
  },
  "id" : 401444326128881664,
  "created_at" : "2013-11-15 20:19:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexis C. Madrigal",
      "screen_name" : "alexismadrigal",
      "indices" : [ 3, 18 ],
      "id_str" : "11107172",
      "id" : 11107172
    }, {
      "name" : "Rob Dubbin",
      "screen_name" : "robdubbin",
      "indices" : [ 40, 50 ],
      "id_str" : "9465252",
      "id" : 9465252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/z9cI0S1K76",
      "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/elements\/2013\/11\/the-rise-of-twitter-bots.html",
      "display_url" : "newyorker.com\/online\/blogs\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401442643051155456",
  "text" : "RT @alexismadrigal: More non-human web! @robdubbin's Twitter bots: http:\/\/t.co\/z9cI0S1K76",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rob Dubbin",
        "screen_name" : "robdubbin",
        "indices" : [ 20, 30 ],
        "id_str" : "9465252",
        "id" : 9465252
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/z9cI0S1K76",
        "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/elements\/2013\/11\/the-rise-of-twitter-bots.html",
        "display_url" : "newyorker.com\/online\/blogs\/e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "401441150596177920",
    "text" : "More non-human web! @robdubbin's Twitter bots: http:\/\/t.co\/z9cI0S1K76",
    "id" : 401441150596177920,
    "created_at" : "2013-11-15 20:06:43 +0000",
    "user" : {
      "name" : "Alexis C. Madrigal",
      "screen_name" : "alexismadrigal",
      "protected" : false,
      "id_str" : "11107172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455914184069218304\/2tTlfGo5_normal.jpeg",
      "id" : 11107172,
      "verified" : true
    }
  },
  "id" : 401442643051155456,
  "created_at" : "2013-11-15 20:12:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 3, 12 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 54, 66 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/1YsFIeTDOa",
      "expanded_url" : "https:\/\/medium.com\/health-the-future\/d6c1cf7ed25b",
      "display_url" : "medium.com\/health-the-fut\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401425057957683200",
  "text" : "RT @eramirez: Nice to read a real user\u2019s perspective: @nickcrocker reviews the the new Nike Fuelband SE -  https:\/\/t.co\/1YsFIeTDOa #quantif\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Crocker",
        "screen_name" : "nickcrocker",
        "indices" : [ 40, 52 ],
        "id_str" : "30801469",
        "id" : 30801469
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quantifiedself",
        "indices" : [ 117, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/1YsFIeTDOa",
        "expanded_url" : "https:\/\/medium.com\/health-the-future\/d6c1cf7ed25b",
        "display_url" : "medium.com\/health-the-fut\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 33.9988421306, -118.4365866618 ]
    },
    "id_str" : "401424755426750464",
    "text" : "Nice to read a real user\u2019s perspective: @nickcrocker reviews the the new Nike Fuelband SE -  https:\/\/t.co\/1YsFIeTDOa #quantifiedself",
    "id" : 401424755426750464,
    "created_at" : "2013-11-15 19:01:34 +0000",
    "user" : {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "protected" : false,
      "id_str" : "21135674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1777379809\/391870_10100894712944981_10004982_63155096_635581352_n_normal.jpg",
      "id" : 21135674,
      "verified" : false
    }
  },
  "id" : 401425057957683200,
  "created_at" : "2013-11-15 19:02:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Torres",
      "screen_name" : "TorresChess",
      "indices" : [ 0, 12 ],
      "id_str" : "928501447",
      "id" : 928501447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Clab4N7WAD",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/08\/17\/warren-buffet-explains-why-you.html",
      "display_url" : "boingboing.net\/2013\/08\/17\/war\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "401422246465400833",
  "geo" : { },
  "id_str" : "401422711270178816",
  "in_reply_to_user_id" : 928501447,
  "text" : "@torreschess \"I am certain that above-average performance cannot be maintained with large sums of managed money.\" http:\/\/t.co\/Clab4N7WAD",
  "id" : 401422711270178816,
  "in_reply_to_status_id" : 401422246465400833,
  "created_at" : "2013-11-15 18:53:27 +0000",
  "in_reply_to_screen_name" : "TorresChess",
  "in_reply_to_user_id_str" : "928501447",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Torres",
      "screen_name" : "TorresChess",
      "indices" : [ 0, 12 ],
      "id_str" : "928501447",
      "id" : 928501447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401415543774642177",
  "geo" : { },
  "id_str" : "401419987014799360",
  "in_reply_to_user_id" : 928501447,
  "text" : "@torreschess They are elite because they are given unfair advantages. When the playing field is level, luck often trumps skill.",
  "id" : 401419987014799360,
  "in_reply_to_status_id" : 401415543774642177,
  "created_at" : "2013-11-15 18:42:37 +0000",
  "in_reply_to_screen_name" : "TorresChess",
  "in_reply_to_user_id_str" : "928501447",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven",
      "screen_name" : "LuvzTech",
      "indices" : [ 3, 12 ],
      "id_str" : "65757993",
      "id" : 65757993
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFBatKid",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/xwGcffD85S",
      "expanded_url" : "http:\/\/bit.ly\/1789VYR",
      "display_url" : "bit.ly\/1789VYR"
    } ]
  },
  "geo" : { },
  "id_str" : "401419573674524672",
  "text" : "RT @LuvzTech: OMG this is so awesome! #SFBatKid  5 yr old cancer patient gets to be a super hero today in San Francisco!\n\nhttp:\/\/t.co\/xwGcf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SFBatKid",
        "indices" : [ 24, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/xwGcffD85S",
        "expanded_url" : "http:\/\/bit.ly\/1789VYR",
        "display_url" : "bit.ly\/1789VYR"
      } ]
    },
    "geo" : { },
    "id_str" : "401419436340834306",
    "text" : "OMG this is so awesome! #SFBatKid  5 yr old cancer patient gets to be a super hero today in San Francisco!\n\nhttp:\/\/t.co\/xwGcffD85S",
    "id" : 401419436340834306,
    "created_at" : "2013-11-15 18:40:26 +0000",
    "user" : {
      "name" : "Steven",
      "screen_name" : "LuvzTech",
      "protected" : false,
      "id_str" : "65757993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449156941420707840\/o6TyY5aY_normal.jpeg",
      "id" : 65757993,
      "verified" : false
    }
  },
  "id" : 401419573674524672,
  "created_at" : "2013-11-15 18:40:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Torres",
      "screen_name" : "TorresChess",
      "indices" : [ 0, 12 ],
      "id_str" : "928501447",
      "id" : 928501447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401410195638599682",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7758239443, -122.4167053309 ]
  },
  "id_str" : "401414206072684544",
  "in_reply_to_user_id" : 928501447,
  "text" : "@TorresChess Key word being seem.",
  "id" : 401414206072684544,
  "in_reply_to_status_id" : 401410195638599682,
  "created_at" : "2013-11-15 18:19:39 +0000",
  "in_reply_to_screen_name" : "TorresChess",
  "in_reply_to_user_id_str" : "928501447",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Geist",
      "screen_name" : "dalehgeist",
      "indices" : [ 0, 11 ],
      "id_str" : "281744819",
      "id" : 281744819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401409541427851264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7765778546, -122.4166465738 ]
  },
  "id_str" : "401414010496499713",
  "in_reply_to_user_id" : 281744819,
  "text" : "@dalehgeist Exactly.",
  "id" : 401414010496499713,
  "in_reply_to_status_id" : 401409541427851264,
  "created_at" : "2013-11-15 18:18:52 +0000",
  "in_reply_to_screen_name" : "dalehgeist",
  "in_reply_to_user_id_str" : "281744819",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    }, {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 17, 26 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401408920419201024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763215844, -122.416804379 ]
  },
  "id_str" : "401413923884122113",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall @agaricus Deal and deal. How about first Monday in Dec?",
  "id" : 401413923884122113,
  "in_reply_to_status_id" : 401408920419201024,
  "created_at" : "2013-11-15 18:18:32 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7987326056, -122.2782325093 ]
  },
  "id_str" : "401408293316198403",
  "text" : "One thing I've learned over time with some degree of certainty is that degree of certainty isn't correlated to chances of being right.",
  "id" : 401408293316198403,
  "created_at" : "2013-11-15 17:56:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401400402295287809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8508464295, -122.2697451999 ]
  },
  "id_str" : "401404184521474048",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus All the beer you can drink next time we meet? :) I think I also believe that statement is false but would love to see a proof.",
  "id" : 401404184521474048,
  "in_reply_to_status_id" : 401400402295287809,
  "created_at" : "2013-11-15 17:39:49 +0000",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 3, 19 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Potluck",
      "screen_name" : "potluck",
      "indices" : [ 80, 88 ],
      "id_str" : "1395445934",
      "id" : 1395445934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/csjCG7Q1e3",
      "expanded_url" : "http:\/\/www.kernelmag.com\/features\/how-to\/6763\/how-to-tweet-like-a-startup-ceo\/#",
      "display_url" : "kernelmag.com\/features\/how-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401256644991938560",
  "text" : "RT @tonystubblebine: How to tweet like a startup CEO http:\/\/t.co\/csjCG7Q1e3 via @potluck",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Potluck",
        "screen_name" : "potluck",
        "indices" : [ 59, 67 ],
        "id_str" : "1395445934",
        "id" : 1395445934
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/csjCG7Q1e3",
        "expanded_url" : "http:\/\/www.kernelmag.com\/features\/how-to\/6763\/how-to-tweet-like-a-startup-ceo\/#",
        "display_url" : "kernelmag.com\/features\/how-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "401240168587202561",
    "text" : "How to tweet like a startup CEO http:\/\/t.co\/csjCG7Q1e3 via @potluck",
    "id" : 401240168587202561,
    "created_at" : "2013-11-15 06:48:05 +0000",
    "user" : {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "protected" : false,
      "id_str" : "17",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2905030942\/687f575ee3d5833f02b65d17a4133fcb_normal.jpeg",
      "id" : 17,
      "verified" : false
    }
  },
  "id" : 401256644991938560,
  "created_at" : "2013-11-15 07:53:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401227488082161664",
  "geo" : { },
  "id_str" : "401227717980340224",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Shucks. Technical issues? Interpersonal? Act of God? No biggie\u2026 was just curious to watch it again.",
  "id" : 401227717980340224,
  "in_reply_to_status_id" : 401227488082161664,
  "created_at" : "2013-11-15 05:58:37 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401225565169938432",
  "geo" : { },
  "id_str" : "401227258725036033",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Thanks. Did the video for it ever get posted anywhere?",
  "id" : 401227258725036033,
  "in_reply_to_status_id" : 401225565169938432,
  "created_at" : "2013-11-15 05:56:47 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    }, {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 6, 17 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401224862468816896",
  "geo" : { },
  "id_str" : "401225823488708608",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara @seanbonner I haven\u2019t been back since we moved in Feb\u2026 I do miss all kinds of things about it, but also *love* it here in California.",
  "id" : 401225823488708608,
  "in_reply_to_status_id" : 401224862468816896,
  "created_at" : "2013-11-15 05:51:05 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "publicspeakingisscary",
      "indices" : [ 53, 75 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401224525871734784",
  "geo" : { },
  "id_str" : "401225309539663872",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Not sure, I was blacked out at that point. #publicspeakingisscary",
  "id" : 401225309539663872,
  "in_reply_to_status_id" : 401224525871734784,
  "created_at" : "2013-11-15 05:49:02 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rothmana",
      "screen_name" : "rothmana",
      "indices" : [ 0, 9 ],
      "id_str" : "17392577",
      "id" : 17392577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401224610634399744",
  "geo" : { },
  "id_str" : "401224784526061568",
  "in_reply_to_user_id" : 17392577,
  "text" : "@rothmana It\u2019s a toddler remake of Orange Is The New Black.",
  "id" : 401224784526061568,
  "in_reply_to_status_id" : 401224610634399744,
  "created_at" : "2013-11-15 05:46:57 +0000",
  "in_reply_to_screen_name" : "rothmana",
  "in_reply_to_user_id_str" : "17392577",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401224146706649088",
  "geo" : { },
  "id_str" : "401224285588451328",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Nothing other than a talk at a QS conference once.",
  "id" : 401224285588451328,
  "in_reply_to_status_id" : 401224146706649088,
  "created_at" : "2013-11-15 05:44:58 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/401223849959645184\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/hCSFhFZJcA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZFu9zACcAAJdJU.jpg",
      "id_str" : "401223849754128384",
      "id" : 401223849754128384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZFu9zACcAAJdJU.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hCSFhFZJcA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596670272, -122.2757701202 ]
  },
  "id_str" : "401223849959645184",
  "text" : "8:36pm Just had a long sad bedtime conversation with Niko about how his mama is going to Seattle for 3 days. http:\/\/t.co\/hCSFhFZJcA",
  "id" : 401223849959645184,
  "created_at" : "2013-11-15 05:43:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Refe Tuma",
      "screen_name" : "RefeUp",
      "indices" : [ 53, 60 ],
      "id_str" : "21930446",
      "id" : 21930446
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/iwT2HOaBrQ",
      "expanded_url" : "https:\/\/medium.com\/thoughts-on-creativity\/6f4cb1886d41",
      "display_url" : "medium.com\/thoughts-on-cr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401083547705806848",
  "text" : "\u201CMom and Dad, you should really lock the kitchen.\u201D - @RefeUp's kids say in response to his brilliant prank: https:\/\/t.co\/iwT2HOaBrQ",
  "id" : 401083547705806848,
  "created_at" : "2013-11-14 20:25:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Costa",
      "screen_name" : "jasoncosta",
      "indices" : [ 0, 11 ],
      "id_str" : "14927800",
      "id" : 14927800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401068288886599680",
  "geo" : { },
  "id_str" : "401079693148823552",
  "in_reply_to_user_id" : 14927800,
  "text" : "@jasoncosta Awesome work!",
  "id" : 401079693148823552,
  "in_reply_to_status_id" : 401068288886599680,
  "created_at" : "2013-11-14 20:10:25 +0000",
  "in_reply_to_screen_name" : "jasoncosta",
  "in_reply_to_user_id_str" : "14927800",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michael abbott",
      "screen_name" : "mabb0tt",
      "indices" : [ 3, 11 ],
      "id_str" : "22937232",
      "id" : 22937232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401079518527381504",
  "text" : "RT @mabb0tt: \"most people do not listen with the intent to understand; they listen with the intent to reply.\" - stephen covey",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400117421345738752",
    "text" : "\"most people do not listen with the intent to understand; they listen with the intent to reply.\" - stephen covey",
    "id" : 400117421345738752,
    "created_at" : "2013-11-12 04:26:41 +0000",
    "user" : {
      "name" : "michael abbott",
      "screen_name" : "mabb0tt",
      "protected" : false,
      "id_str" : "22937232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2338623735\/foadrx4jam4tn4gp2i8z_normal.jpeg",
      "id" : 22937232,
      "verified" : false
    }
  },
  "id" : 401079518527381504,
  "created_at" : "2013-11-14 20:09:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Music",
      "screen_name" : "TwitterMusic",
      "indices" : [ 3, 16 ],
      "id_str" : "373471064",
      "id" : 373471064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/SNZPAEO7f8",
      "expanded_url" : "https:\/\/twitter.com\/twittermusic\/timelines\/393773290356875264",
      "display_url" : "twitter.com\/twittermusic\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401079410247229440",
  "text" : "RT @TwitterMusic: Thanks to our brand new custom timelines you can now check out the most popular music Vines trending on Twitter https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/SNZPAEO7f8",
        "expanded_url" : "https:\/\/twitter.com\/twittermusic\/timelines\/393773290356875264",
        "display_url" : "twitter.com\/twittermusic\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "401055954151538688",
    "text" : "Thanks to our brand new custom timelines you can now check out the most popular music Vines trending on Twitter https:\/\/t.co\/SNZPAEO7f8",
    "id" : 401055954151538688,
    "created_at" : "2013-11-14 18:36:05 +0000",
    "user" : {
      "name" : "Twitter Music",
      "screen_name" : "TwitterMusic",
      "protected" : false,
      "id_str" : "373471064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000449287089\/70dea90873e8a0f92fd582b4d04cfd4b_normal.png",
      "id" : 373471064,
      "verified" : true
    }
  },
  "id" : 401079410247229440,
  "created_at" : "2013-11-14 20:09:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "coder school dropout",
      "screen_name" : "meat",
      "indices" : [ 10, 15 ],
      "id_str" : "21006515",
      "id" : 21006515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401078219568197633",
  "geo" : { },
  "id_str" : "401078883153215488",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus @meat But the only way to prove that wrong would be to have every thought and to prove that none of them were clear.",
  "id" : 401078883153215488,
  "in_reply_to_status_id" : 401078219568197633,
  "created_at" : "2013-11-14 20:07:12 +0000",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "coder school dropout",
      "screen_name" : "meat",
      "indices" : [ 9, 14 ],
      "id_str" : "21006515",
      "id" : 21006515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/LorvkSpGlg",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/ludwigwittgenstein\/fantastic-ways-to-distinguish-between-sense-and-nonsense",
      "display_url" : "buzzfeed.com\/ludwigwittgens\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "401074842755031041",
  "geo" : { },
  "id_str" : "401075225162289152",
  "in_reply_to_user_id" : 21006515,
  "text" : "Best. RT @meat: I don't often post Buzzfeed links, but: 7 Fantastic Ways To Distinguish Between Sense and Nonsense http:\/\/t.co\/LorvkSpGlg",
  "id" : 401075225162289152,
  "in_reply_to_status_id" : 401074842755031041,
  "created_at" : "2013-11-14 19:52:39 +0000",
  "in_reply_to_screen_name" : "meat",
  "in_reply_to_user_id_str" : "21006515",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "clothingfirst",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401073331555684352",
  "geo" : { },
  "id_str" : "401073690940420096",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine Wait, you're not talking to apparel companies as potential investors and acquirers? Get with the times! #clothingfirst",
  "id" : 401073690940420096,
  "in_reply_to_status_id" : 401073331555684352,
  "created_at" : "2013-11-14 19:46:34 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Courtney Love Cobain",
      "screen_name" : "Courtney",
      "indices" : [ 3, 12 ],
      "id_str" : "43522180",
      "id" : 43522180
    }, {
      "name" : "Evan Spiegel",
      "screen_name" : "evanspiegel",
      "indices" : [ 17, 29 ],
      "id_str" : "230287527",
      "id" : 230287527
    }, {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 37, 46 ],
      "id_str" : "376502929",
      "id" : 376502929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401059347255398400",
  "text" : "RT @Courtney: Ok @evanspiegel let's  @Snapchat I'm feeling frisky.  Bwahaa xc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evan Spiegel",
        "screen_name" : "evanspiegel",
        "indices" : [ 3, 15 ],
        "id_str" : "230287527",
        "id" : 230287527
      }, {
        "name" : "Snapchat",
        "screen_name" : "Snapchat",
        "indices" : [ 23, 32 ],
        "id_str" : "376502929",
        "id" : 376502929
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401059247812644864",
    "text" : "Ok @evanspiegel let's  @Snapchat I'm feeling frisky.  Bwahaa xc",
    "id" : 401059247812644864,
    "created_at" : "2013-11-14 18:49:10 +0000",
    "user" : {
      "name" : "Courtney Love Cobain",
      "screen_name" : "Courtney",
      "protected" : false,
      "id_str" : "43522180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000735985110\/d6c5c990b31b43f2b1c6e71025ec7fcf_normal.png",
      "id" : 43522180,
      "verified" : true
    }
  },
  "id" : 401059347255398400,
  "created_at" : "2013-11-14 18:49:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    }, {
      "name" : "Coin",
      "screen_name" : "coin",
      "indices" : [ 89, 94 ],
      "id_str" : "981273865",
      "id" : 981273865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401052778425896960",
  "geo" : { },
  "id_str" : "401052983904854016",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm Awesome! I think that means I get a cut of your airline miles whenever you use your @coin, right?",
  "id" : 401052983904854016,
  "in_reply_to_status_id" : 401052778425896960,
  "created_at" : "2013-11-14 18:24:17 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coin",
      "screen_name" : "coin",
      "indices" : [ 14, 19 ],
      "id_str" : "981273865",
      "id" : 981273865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/S32l5KYlL2",
      "expanded_url" : "https:\/\/onlycoin.com\/?referral=vZC911c8",
      "display_url" : "onlycoin.com\/?referral=vZC9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401050308303806464",
  "text" : "Pre-ordered a @Coin (a card that holds all cards). Killer feature: push notification when you leave it behind. https:\/\/t.co\/S32l5KYlL2",
  "id" : 401050308303806464,
  "created_at" : "2013-11-14 18:13:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/eiB3DLNm3n",
      "expanded_url" : "http:\/\/blog.stephenwolfram.com\/2013\/11\/something-very-big-is-coming-our-most-important-technology-project-yet\/",
      "display_url" : "blog.stephenwolfram.com\/2013\/11\/someth\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597081218, -122.2756657662 ]
  },
  "id_str" : "401017484272091136",
  "text" : "Stephen Wolfram is really excited about... something http:\/\/t.co\/eiB3DLNm3n",
  "id" : 401017484272091136,
  "created_at" : "2013-11-14 16:03:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "staycool",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400824230679306242",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597265496, -122.2755238936 ]
  },
  "id_str" : "400884612865343488",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew So much fun reading these! It's like the p13n yearbook that never happened! #staycool",
  "id" : 400884612865343488,
  "in_reply_to_status_id" : 400824230679306242,
  "created_at" : "2013-11-14 07:15:14 +0000",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400870293050101760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859674381, -122.2756644906 ]
  },
  "id_str" : "400880427344203776",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel I'm curious as well! But then I'll also be sad if I get to see him less.",
  "id" : 400880427344203776,
  "in_reply_to_status_id" : 400870293050101760,
  "created_at" : "2013-11-14 06:58:36 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400875102608162817",
  "geo" : { },
  "id_str" : "400875253938679808",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Do it! I'm busterbenson snap me!",
  "id" : 400875253938679808,
  "in_reply_to_status_id" : 400875102608162817,
  "created_at" : "2013-11-14 06:38:03 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400869344894132224",
  "geo" : { },
  "id_str" : "400870923315597313",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne It's funny because my ebooks account subtweets me all the time.",
  "id" : 400870923315597313,
  "in_reply_to_status_id" : 400869344894132224,
  "created_at" : "2013-11-14 06:20:50 +0000",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Capecelatro",
      "screen_name" : "jcap49",
      "indices" : [ 0, 7 ],
      "id_str" : "78733683",
      "id" : 78733683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400867440349163520",
  "geo" : { },
  "id_str" : "400867574436466688",
  "in_reply_to_user_id" : 78733683,
  "text" : "@jcap49 Thanks. I've been trying to get that spelling to catch on... :)",
  "id" : 400867574436466688,
  "in_reply_to_status_id" : 400867440349163520,
  "created_at" : "2013-11-14 06:07:32 +0000",
  "in_reply_to_screen_name" : "jcap49",
  "in_reply_to_user_id_str" : "78733683",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/JQZzCzLkJS",
      "expanded_url" : "http:\/\/flic.kr\/p\/hwJRMY",
      "display_url" : "flic.kr\/p\/hwJRMY"
    } ]
  },
  "geo" : { },
  "id_str" : "400865984040681472",
  "text" : "8:36pm Bath time per yuj http:\/\/t.co\/JQZzCzLkJS",
  "id" : 400865984040681472,
  "created_at" : "2013-11-14 06:01:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Newton",
      "screen_name" : "willdjthrill",
      "indices" : [ 0, 13 ],
      "id_str" : "45394577",
      "id" : 45394577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400847805339553792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596603759, -122.2756544056 ]
  },
  "id_str" : "400853416198430721",
  "in_reply_to_user_id" : 45394577,
  "text" : "@willdjthrill How do you know? Has it been explained somewhere?",
  "id" : 400853416198430721,
  "in_reply_to_status_id" : 400847805339553792,
  "created_at" : "2013-11-14 05:11:16 +0000",
  "in_reply_to_screen_name" : "willdjthrill",
  "in_reply_to_user_id_str" : "45394577",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400847205323374593",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596492749, -122.2754353267 ]
  },
  "id_str" : "400847745738473473",
  "in_reply_to_user_id" : 2185,
  "text" : "Also, when I send a photo to 5 people on Snapchat, do they count that as 1 or 5?",
  "id" : 400847745738473473,
  "in_reply_to_status_id" : 400847205323374593,
  "created_at" : "2013-11-14 04:48:44 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400843126018805760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596736369, -122.2753564108 ]
  },
  "id_str" : "400847205323374593",
  "in_reply_to_user_id" : 2185,
  "text" : "Personally, I think self-expression is safer on Snapchat and that is a loveable thing. My one doubt is the effort required to view a snap.",
  "id" : 400847205323374593,
  "in_reply_to_status_id" : 400843126018805760,
  "created_at" : "2013-11-14 04:46:35 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400844085780426752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598419591, -122.2754891144 ]
  },
  "id_str" : "400846306454695938",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm Totally agree.",
  "id" : 400846306454695938,
  "in_reply_to_status_id" : 400844085780426752,
  "created_at" : "2013-11-14 04:43:01 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400843433037684736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597227732, -122.2756233348 ]
  },
  "id_str" : "400845398513692672",
  "in_reply_to_user_id" : 149464163,
  "text" : "@andrewkonoff Great post. What do you think about snap fatigue?",
  "id" : 400845398513692672,
  "in_reply_to_status_id" : 400843433037684736,
  "created_at" : "2013-11-14 04:39:25 +0000",
  "in_reply_to_screen_name" : "andknf",
  "in_reply_to_user_id_str" : "149464163",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400843382915751936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859722746, -122.275623631 ]
  },
  "id_str" : "400843507448819712",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm Why do you think people love it?",
  "id" : 400843507448819712,
  "in_reply_to_status_id" : 400843382915751936,
  "created_at" : "2013-11-14 04:31:54 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597493066, -122.275526905 ]
  },
  "id_str" : "400843126018805760",
  "text" : "Do you love Snapchat?",
  "id" : 400843126018805760,
  "created_at" : "2013-11-14 04:30:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "indices" : [ 0, 12 ],
      "id_str" : "289534689",
      "id" : 289534689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400812655192985600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8355295273, -122.2671984437 ]
  },
  "id_str" : "400814844284112897",
  "in_reply_to_user_id" : 289534689,
  "text" : "@seriouspony Yeah I feel like he should've taken a more bold thesis than just musing about analogies. It's still enjoyable though.",
  "id" : 400814844284112897,
  "in_reply_to_status_id" : 400812655192985600,
  "created_at" : "2013-11-14 02:38:00 +0000",
  "in_reply_to_screen_name" : "seriouspony",
  "in_reply_to_user_id_str" : "289534689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400814152207175683",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8284255336, -122.2668156155 ]
  },
  "id_str" : "400814609403092992",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine I find that to be true for most authors too. I had higher hopes for Surfaces and Essences...",
  "id" : 400814609403092992,
  "in_reply_to_status_id" : 400814152207175683,
  "created_at" : "2013-11-14 02:37:04 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400810455339245569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8077418265, -122.3067479323 ]
  },
  "id_str" : "400811962763722752",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Hofstadter's Latest book about how all thinking is made up of analogies and categorization. A bit dry for Twitter perhaps.",
  "id" : 400811962763722752,
  "in_reply_to_status_id" : 400810455339245569,
  "created_at" : "2013-11-14 02:26:33 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400810060705583104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7935246624, -122.3963171643 ]
  },
  "id_str" : "400810332085436416",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Sounds like a good plan. I do like the topic and writing.",
  "id" : 400810332085436416,
  "in_reply_to_status_id" : 400810060705583104,
  "created_at" : "2013-11-14 02:20:04 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77919759, -122.41427638 ]
  },
  "id_str" : "400809781671124993",
  "text" : "What to do when an author states in the 1st chapter a thesis he hopes to convince you of by the last chapter, but you already believe it?",
  "id" : 400809781671124993,
  "created_at" : "2013-11-14 02:17:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 3, 14 ],
      "id_str" : "1586501",
      "id" : 1586501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/U6k6XqtyFt",
      "expanded_url" : "http:\/\/www.happier.co.uk\/infogram\/amount-top-companies-earn-per-second.html",
      "display_url" : "happier.co.uk\/infogram\/amoun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "400808397278175233",
  "text" : "RT @nickbilton: Facebook makes $230 in revenue per second.\nGoogle: $1873.\nAmazon: $1996.\nApple: $4540.\nSamsung: $6486.\n(Source: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/U6k6XqtyFt",
        "expanded_url" : "http:\/\/www.happier.co.uk\/infogram\/amount-top-companies-earn-per-second.html",
        "display_url" : "happier.co.uk\/infogram\/amoun\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "400665112727392258",
    "text" : "Facebook makes $230 in revenue per second.\nGoogle: $1873.\nAmazon: $1996.\nApple: $4540.\nSamsung: $6486.\n(Source: http:\/\/t.co\/U6k6XqtyFt)",
    "id" : 400665112727392258,
    "created_at" : "2013-11-13 16:43:01 +0000",
    "user" : {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "protected" : false,
      "id_str" : "1586501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453750282770341888\/SEwjZ2AI_normal.png",
      "id" : 1586501,
      "verified" : true
    }
  },
  "id" : 400808397278175233,
  "created_at" : "2013-11-14 02:12:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400799160070197248",
  "geo" : { },
  "id_str" : "400799339154399232",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm Yeah you definitely have to hike along the bottom for it to count.",
  "id" : 400799339154399232,
  "in_reply_to_status_id" : 400799160070197248,
  "created_at" : "2013-11-14 01:36:23 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400797223333539840",
  "geo" : { },
  "id_str" : "400798929303793664",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm Not even number 14: Grande Canyon? That's the only one I've been to.",
  "id" : 400798929303793664,
  "in_reply_to_status_id" : 400797223333539840,
  "created_at" : "2013-11-14 01:34:45 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400663420292587520",
  "geo" : { },
  "id_str" : "400707942132895744",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Woah, big news! I'm sure Foursquare will miss you dearly. Looking forward to whatever's next.",
  "id" : 400707942132895744,
  "in_reply_to_status_id" : 400663420292587520,
  "created_at" : "2013-11-13 19:33:12 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McAllister",
      "screen_name" : "ianmcall",
      "indices" : [ 0, 9 ],
      "id_str" : "2035631",
      "id" : 2035631
    }, {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 10, 18 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400518290356711424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596828431, -122.2756216535 ]
  },
  "id_str" : "400520195409580032",
  "in_reply_to_user_id" : 2035631,
  "text" : "@ianmcall @rsarver I finished it a while ago, and found it a great read. Fascinating contrast with Hatching Twitter.",
  "id" : 400520195409580032,
  "in_reply_to_status_id" : 400518290356711424,
  "created_at" : "2013-11-13 07:07:10 +0000",
  "in_reply_to_screen_name" : "ianmcall",
  "in_reply_to_user_id_str" : "2035631",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400494941555539968",
  "geo" : { },
  "id_str" : "400501624499482624",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey I\u2019ve been teaching him to go where the puck is going and it appears to be paying off.",
  "id" : 400501624499482624,
  "in_reply_to_status_id" : 400494941555539968,
  "created_at" : "2013-11-13 05:53:22 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/400483102612406272\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/vZpLgYaivl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY7NQoECcAAP9MN.jpg",
      "id_str" : "400483102398509056",
      "id" : 400483102398509056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY7NQoECcAAP9MN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/vZpLgYaivl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597547906, -122.2755126749 ]
  },
  "id_str" : "400483102612406272",
  "text" : "8:36pm Saving for train conductor college http:\/\/t.co\/vZpLgYaivl",
  "id" : 400483102612406272,
  "created_at" : "2013-11-13 04:39:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/pASah81dau",
      "expanded_url" : "https:\/\/vine.co\/v\/hTDU06QMeDB",
      "display_url" : "vine.co\/v\/hTDU06QMeDB"
    } ]
  },
  "geo" : { },
  "id_str" : "400482454244691969",
  "text" : "Niko's money saving habit https:\/\/t.co\/pASah81dau",
  "id" : 400482454244691969,
  "created_at" : "2013-11-13 04:37:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "indices" : [ 3, 15 ],
      "id_str" : "1532061",
      "id" : 1532061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/xmwOMljCQX",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/11\/17\/magazine\/switzerlands-proposal-to-pay-people-for-being-alive.html?pagewanted=all&src=ISMR_AP_LO_MST_FB",
      "display_url" : "nytimes.com\/2013\/11\/17\/mag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "400465391454912512",
  "text" : "RT @kevin2kelly: I like having my mind changed. The idea of getting paid to be alive - basic income - seems less crazy than I thought. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/xmwOMljCQX",
        "expanded_url" : "http:\/\/www.nytimes.com\/2013\/11\/17\/magazine\/switzerlands-proposal-to-pay-people-for-being-alive.html?pagewanted=all&src=ISMR_AP_LO_MST_FB",
        "display_url" : "nytimes.com\/2013\/11\/17\/mag\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "400462808539607040",
    "text" : "I like having my mind changed. The idea of getting paid to be alive - basic income - seems less crazy than I thought. http:\/\/t.co\/xmwOMljCQX",
    "id" : 400462808539607040,
    "created_at" : "2013-11-13 03:19:08 +0000",
    "user" : {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "protected" : false,
      "id_str" : "1532061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/65000713\/KKlaughsm_normal.jpg",
      "id" : 1532061,
      "verified" : false
    }
  },
  "id" : 400465391454912512,
  "created_at" : "2013-11-13 03:29:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Stump",
      "screen_name" : "joestump",
      "indices" : [ 0, 9 ],
      "id_str" : "4234581",
      "id" : 4234581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400456647312547840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8542540681, -122.2711723175 ]
  },
  "id_str" : "400457537603895296",
  "in_reply_to_user_id" : 4234581,
  "text" : "@joestump And even then it must not immediately bend back.",
  "id" : 400457537603895296,
  "in_reply_to_status_id" : 400456647312547840,
  "created_at" : "2013-11-13 02:58:11 +0000",
  "in_reply_to_screen_name" : "joestump",
  "in_reply_to_user_id_str" : "4234581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8534060458, -122.2708232662 ]
  },
  "id_str" : "400457180454723584",
  "text" : "\"Metaphors are nothing but will-o'-the-wisps that would lead one to wander in a wacky world.\" - Hobbes",
  "id" : 400457180454723584,
  "created_at" : "2013-11-13 02:56:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Stump",
      "screen_name" : "joestump",
      "indices" : [ 0, 9 ],
      "id_str" : "4234581",
      "id" : 4234581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400452814578515968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8283351943, -122.2673650596 ]
  },
  "id_str" : "400455539324223488",
  "in_reply_to_user_id" : 4234581,
  "text" : "@joestump Maybe zero even?",
  "id" : 400455539324223488,
  "in_reply_to_status_id" : 400452814578515968,
  "created_at" : "2013-11-13 02:50:15 +0000",
  "in_reply_to_screen_name" : "joestump",
  "in_reply_to_user_id_str" : "4234581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7796501689, -122.4138590978 ]
  },
  "id_str" : "400452529374232576",
  "text" : "How many dents have people made in the universe so far anyway?",
  "id" : 400452529374232576,
  "created_at" : "2013-11-13 02:38:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400388519899570176",
  "geo" : { },
  "id_str" : "400389661782069248",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler I just finished it too. The last few chapters were intense.",
  "id" : 400389661782069248,
  "in_reply_to_status_id" : 400388519899570176,
  "created_at" : "2013-11-12 22:28:28 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenn Van Grove",
      "screen_name" : "jbruin",
      "indices" : [ 3, 10 ],
      "id_str" : "6193182",
      "id" : 6193182
    }, {
      "name" : "Vine",
      "screen_name" : "vineapp",
      "indices" : [ 19, 27 ],
      "id_str" : "586671909",
      "id" : 586671909
    }, {
      "name" : "\u30CF\u30EA\u30CD\u30BA\u30DF\u2605\u307E\u308B\u305F\u308D\u3046",
      "screen_name" : "hedgehogdays",
      "indices" : [ 87, 100 ],
      "id_str" : "1714874952",
      "id" : 1714874952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/TFKXLNpaYH",
      "expanded_url" : "https:\/\/vine.co\/v\/hpOaedpJDtV",
      "display_url" : "vine.co\/v\/hpOaedpJDtV"
    } ]
  },
  "geo" : { },
  "id_str" : "400386556910792704",
  "text" : "RT @jbruin: OK! RT @vineapp: Take a 6 second hedgehog break https:\/\/t.co\/TFKXLNpaYH by @hedgehogdays",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vine",
        "screen_name" : "vineapp",
        "indices" : [ 7, 15 ],
        "id_str" : "586671909",
        "id" : 586671909
      }, {
        "name" : "\u30CF\u30EA\u30CD\u30BA\u30DF\u2605\u307E\u308B\u305F\u308D\u3046",
        "screen_name" : "hedgehogdays",
        "indices" : [ 75, 88 ],
        "id_str" : "1714874952",
        "id" : 1714874952
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/TFKXLNpaYH",
        "expanded_url" : "https:\/\/vine.co\/v\/hpOaedpJDtV",
        "display_url" : "vine.co\/v\/hpOaedpJDtV"
      } ]
    },
    "geo" : { },
    "id_str" : "400386429361991680",
    "text" : "OK! RT @vineapp: Take a 6 second hedgehog break https:\/\/t.co\/TFKXLNpaYH by @hedgehogdays",
    "id" : 400386429361991680,
    "created_at" : "2013-11-12 22:15:38 +0000",
    "user" : {
      "name" : "Jenn Van Grove",
      "screen_name" : "jbruin",
      "protected" : false,
      "id_str" : "6193182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443626110656344065\/D87I0ELg_normal.jpeg",
      "id" : 6193182,
      "verified" : true
    }
  },
  "id" : 400386556910792704,
  "created_at" : "2013-11-12 22:16:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julien Smith",
      "screen_name" : "julien",
      "indices" : [ 3, 10 ],
      "id_str" : "10203",
      "id" : 10203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/6GI8BQsWUA",
      "expanded_url" : "http:\/\/www.theguardian.com\/world\/2013\/nov\/12\/occupy-wall-street-activists-15m-personal-debt",
      "display_url" : "theguardian.com\/world\/2013\/nov\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "400377022641225728",
  "text" : "RT @julien: This is amazing. http:\/\/t.co\/6GI8BQsWUA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/6GI8BQsWUA",
        "expanded_url" : "http:\/\/www.theguardian.com\/world\/2013\/nov\/12\/occupy-wall-street-activists-15m-personal-debt",
        "display_url" : "theguardian.com\/world\/2013\/nov\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "400376617362784256",
    "text" : "This is amazing. http:\/\/t.co\/6GI8BQsWUA",
    "id" : 400376617362784256,
    "created_at" : "2013-11-12 21:36:38 +0000",
    "user" : {
      "name" : "Julien Smith",
      "screen_name" : "julien",
      "protected" : false,
      "id_str" : "10203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762363562\/4172101037_e57b931af9_o-1_3_normal.jpg",
      "id" : 10203,
      "verified" : true
    }
  },
  "id" : 400377022641225728,
  "created_at" : "2013-11-12 21:38:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    }, {
      "name" : "Galen",
      "screen_name" : "gln",
      "indices" : [ 12, 16 ],
      "id_str" : "4366051",
      "id" : 4366051
    }, {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 17, 28 ],
      "id_str" : "26123649",
      "id" : 26123649
    }, {
      "name" : "Arya Asemanfar",
      "screen_name" : "a_a",
      "indices" : [ 29, 33 ],
      "id_str" : "14653230",
      "id" : 14653230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400333224716423168",
  "geo" : { },
  "id_str" : "400333402148073472",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold @gln @brianellin @a_a Why can't you use it?",
  "id" : 400333402148073472,
  "in_reply_to_status_id" : 400333224716423168,
  "created_at" : "2013-11-12 18:44:55 +0000",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arya Asemanfar",
      "screen_name" : "a_a",
      "indices" : [ 71, 75 ],
      "id_str" : "14653230",
      "id" : 14653230
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "meta",
      "indices" : [ 100, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/Y4ea1lGqcU",
      "expanded_url" : "http:\/\/bit.ly\/1aCTdOp",
      "display_url" : "bit.ly\/1aCTdOp"
    } ]
  },
  "geo" : { },
  "id_str" : "400333281658277889",
  "text" : "A custom timeline of Tweets about the custom timeline announcement, by @a_a: http:\/\/t.co\/Y4ea1lGqcU #meta",
  "id" : 400333281658277889,
  "created_at" : "2013-11-12 18:44:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen",
      "screen_name" : "gln",
      "indices" : [ 0, 4 ],
      "id_str" : "4366051",
      "id" : 4366051
    }, {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 5, 16 ],
      "id_str" : "26123649",
      "id" : 26123649
    }, {
      "name" : "Arya Asemanfar",
      "screen_name" : "a_a",
      "indices" : [ 17, 21 ],
      "id_str" : "14653230",
      "id" : 14653230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400332477224325120",
  "geo" : { },
  "id_str" : "400332961247014912",
  "in_reply_to_user_id" : 4366051,
  "text" : "@gln @brianellin @a_a Found it, but how do I get the permalink for it from TweetDeck?",
  "id" : 400332961247014912,
  "in_reply_to_status_id" : 400332477224325120,
  "created_at" : "2013-11-12 18:43:10 +0000",
  "in_reply_to_screen_name" : "gln",
  "in_reply_to_user_id_str" : "4366051",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TweetDeck",
      "screen_name" : "TweetDeck",
      "indices" : [ 15, 25 ],
      "id_str" : "14803701",
      "id" : 14803701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/27joVYKL0k",
      "expanded_url" : "https:\/\/blog.twitter.com\/2013\/custom-timelines-in-tweetdeck",
      "display_url" : "blog.twitter.com\/2013\/custom-ti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "400331563927224320",
  "text" : "People who use @TweetDeck, here's how you can use it to create new custom timelines. It's fun: https:\/\/t.co\/27joVYKL0k",
  "id" : 400331563927224320,
  "created_at" : "2013-11-12 18:37:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 0, 11 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400331194375483392",
  "in_reply_to_user_id" : 26123649,
  "text" : "@brianellin Where's the custom timeline of responses to the custom timeline announcement?",
  "id" : 400331194375483392,
  "created_at" : "2013-11-12 18:36:09 +0000",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 96, 107 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/sqhZ6naDDk",
      "expanded_url" : "https:\/\/dev.twitter.com\/blog\/introducing-custom-timelines",
      "display_url" : "dev.twitter.com\/blog\/introduci\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7797317741, -122.4157407887 ]
  },
  "id_str" : "400325605310205952",
  "text" : "A new way to organize Tweets. SUPER excited to see where this goes: https:\/\/t.co\/sqhZ6naDDk \/cc @brianellin",
  "id" : 400325605310205952,
  "created_at" : "2013-11-12 18:13:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/dq8lnBv9Nd",
      "expanded_url" : "http:\/\/gagism.com\/86-year-beautiful-rage-comic\/",
      "display_url" : "gagism.com\/86-year-beauti\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596910139, -122.275699153 ]
  },
  "id_str" : "400293693195698176",
  "text" : "An 86-year old shares his life story via rage comic. So good! http:\/\/t.co\/dq8lnBv9Nd",
  "id" : 400293693195698176,
  "created_at" : "2013-11-12 16:07:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 0, 12 ],
      "id_str" : "195863654",
      "id" : 195863654
    }, {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 62, 72 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400136160673947648",
  "geo" : { },
  "id_str" : "400146522500628481",
  "in_reply_to_user_id" : 195863654,
  "text" : "@marihuertas Thank you! If you do, you should definitely meet @webwright--he's awesome. If you come to SF\/Berkeley, I want to meet you too!",
  "id" : 400146522500628481,
  "in_reply_to_status_id" : 400136160673947648,
  "created_at" : "2013-11-12 06:22:19 +0000",
  "in_reply_to_screen_name" : "marihuertas",
  "in_reply_to_user_id_str" : "195863654",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 36, 46 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/7mPWFd2LuZ",
      "expanded_url" : "http:\/\/50millionsteps.com",
      "display_url" : "50millionsteps.com"
    } ]
  },
  "in_reply_to_status_id_str" : "400126176351371264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597240749, -122.2756226908 ]
  },
  "id_str" : "400129225174167552",
  "in_reply_to_user_id" : 786818,
  "text" : "Somehow missed this amazingness: RT @webwright: We ARE blogging!  http:\/\/t.co\/7mPWFd2LuZ Travel has been SO GOOD for my brain\/heart\/body.",
  "id" : 400129225174167552,
  "in_reply_to_status_id" : 400126176351371264,
  "created_at" : "2013-11-12 05:13:35 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/bERDVZfpXW",
      "expanded_url" : "http:\/\/flic.kr\/p\/htz5Mc",
      "display_url" : "flic.kr\/p\/htz5Mc"
    } ]
  },
  "geo" : { },
  "id_str" : "400127527341277184",
  "text" : "8:36pm Reading about Gertrude McFuzz and Lolla Lee Lou http:\/\/t.co\/bERDVZfpXW",
  "id" : 400127527341277184,
  "created_at" : "2013-11-12 05:06:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400089382889078784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596742405, -122.2759278306 ]
  },
  "id_str" : "400107499711254528",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright Offense, pshaw. Always up for a beer with you. Also interested in hearing more about your travels! Are you blogging it all?",
  "id" : 400107499711254528,
  "in_reply_to_status_id" : 400089382889078784,
  "created_at" : "2013-11-12 03:47:16 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399974975446061056",
  "geo" : { },
  "id_str" : "399988699955732481",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright I see the logic in that as an extension of general conversation etiquette, but respectfully disagree that it applies to Twitter.",
  "id" : 399988699955732481,
  "in_reply_to_status_id" : 399974975446061056,
  "created_at" : "2013-11-11 19:55:12 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399803596746661889",
  "geo" : { },
  "id_str" : "399956429404401664",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright Your original tweet suggested that we avoid talking about a topic if others don't want to hear about it.",
  "id" : 399956429404401664,
  "in_reply_to_status_id" : 399803596746661889,
  "created_at" : "2013-11-11 17:46:58 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andrew hyde",
      "screen_name" : "andrewhyde",
      "indices" : [ 0, 11 ],
      "id_str" : "841791",
      "id" : 841791
    }, {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 12, 22 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399804019536715776",
  "geo" : { },
  "id_str" : "399956159005609984",
  "in_reply_to_user_id" : 841791,
  "text" : "@andrewhyde @webwright Yes but there are degrees of you-ness. And filtering\/hiding\/performing only adds noise to the signal.",
  "id" : 399956159005609984,
  "in_reply_to_status_id" : 399804019536715776,
  "created_at" : "2013-11-11 17:45:53 +0000",
  "in_reply_to_screen_name" : "andrewhyde",
  "in_reply_to_user_id_str" : "841791",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399800411046936576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597663576, -122.2753452045 ]
  },
  "id_str" : "399802648322260992",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright Self-expression and connection, both of which are compromised by attempts at second guessing what others want you to be.",
  "id" : 399802648322260992,
  "in_reply_to_status_id" : 399800411046936576,
  "created_at" : "2013-11-11 07:35:53 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399780544608620544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596939032, -122.2756144511 ]
  },
  "id_str" : "399792708509642752",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright As much as I am indifferent to sports, I don't think people should tweet for their followers. Tweet what you care about. Period.",
  "id" : 399792708509642752,
  "in_reply_to_status_id" : 399780544608620544,
  "created_at" : "2013-11-11 06:56:24 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/IMvKSZpzed",
      "expanded_url" : "http:\/\/flic.kr\/p\/hrMKGp",
      "display_url" : "flic.kr\/p\/hrMKGp"
    } ]
  },
  "geo" : { },
  "id_str" : "399771417363091456",
  "text" : "8:36pm Good peoples are over  http:\/\/t.co\/IMvKSZpzed",
  "id" : 399771417363091456,
  "created_at" : "2013-11-11 05:31:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Prevette",
      "screen_name" : "mikeprevette",
      "indices" : [ 0, 13 ],
      "id_str" : "1475531",
      "id" : 1475531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399644776724566017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596958032, -122.2755617348 ]
  },
  "id_str" : "399646154549260288",
  "in_reply_to_user_id" : 1475531,
  "text" : "@mikeprevette Come over tonight!",
  "id" : 399646154549260288,
  "in_reply_to_status_id" : 399644776724566017,
  "created_at" : "2013-11-10 21:14:02 +0000",
  "in_reply_to_screen_name" : "mikeprevette",
  "in_reply_to_user_id_str" : "1475531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399608638802649088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8564878728, -122.272000537 ]
  },
  "id_str" : "399609633414721537",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel I'm amazed. This was 15 minutes after we took off the training wheels.",
  "id" : 399609633414721537,
  "in_reply_to_status_id" : 399608638802649088,
  "created_at" : "2013-11-10 18:48:55 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/I79lzXosXV",
      "expanded_url" : "https:\/\/vine.co\/v\/hTW1zWb7YdM",
      "display_url" : "vine.co\/v\/hTW1zWb7YdM"
    } ]
  },
  "geo" : { },
  "id_str" : "399606324834865152",
  "text" : "No help! https:\/\/t.co\/I79lzXosXV",
  "id" : 399606324834865152,
  "created_at" : "2013-11-10 18:35:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/gwi3jzKYfU",
      "expanded_url" : "https:\/\/vine.co\/v\/hTWizg0TZXh",
      "display_url" : "vine.co\/v\/hTWizg0TZXh"
    } ]
  },
  "geo" : { },
  "id_str" : "399604294456193026",
  "text" : "Sans training wheels!!! https:\/\/t.co\/gwi3jzKYfU",
  "id" : 399604294456193026,
  "created_at" : "2013-11-10 18:27:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Brewer",
      "screen_name" : "jbrewer",
      "indices" : [ 0, 8 ],
      "id_str" : "12555",
      "id" : 12555
    }, {
      "name" : "Semil",
      "screen_name" : "semil",
      "indices" : [ 9, 15 ],
      "id_str" : "15227849",
      "id" : 15227849
    }, {
      "name" : "Josh Williams",
      "screen_name" : "jw",
      "indices" : [ 16, 19 ],
      "id_str" : "12528",
      "id" : 12528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399592130449920000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597527019, -122.2754666774 ]
  },
  "id_str" : "399593379647848448",
  "in_reply_to_user_id" : 12555,
  "text" : "@jbrewer @semil @jw I think that's the key right there.",
  "id" : 399593379647848448,
  "in_reply_to_status_id" : 399592130449920000,
  "created_at" : "2013-11-10 17:44:20 +0000",
  "in_reply_to_screen_name" : "jbrewer",
  "in_reply_to_user_id_str" : "12555",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "indices" : [ 3, 17 ],
      "id_str" : "14289835",
      "id" : 14289835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/zRzlGxqA9X",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/11\/09\/arts\/that-syllable-everyone-recognizes.html?_r=0",
      "display_url" : "nytimes.com\/2013\/11\/09\/art\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "399591224790622209",
  "text" : "RT @gretchenrubin: Who knew? Turns out that \"huh?\" is possibly the most universally understood word. http:\/\/t.co\/zRzlGxqA9X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/zRzlGxqA9X",
        "expanded_url" : "http:\/\/www.nytimes.com\/2013\/11\/09\/arts\/that-syllable-everyone-recognizes.html?_r=0",
        "display_url" : "nytimes.com\/2013\/11\/09\/art\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "399590055091523587",
    "text" : "Who knew? Turns out that \"huh?\" is possibly the most universally understood word. http:\/\/t.co\/zRzlGxqA9X",
    "id" : 399590055091523587,
    "created_at" : "2013-11-10 17:31:07 +0000",
    "user" : {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "protected" : false,
      "id_str" : "14289835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1436632135\/Gretchenonphone_normal.JPG",
      "id" : 14289835,
      "verified" : true
    }
  },
  "id" : 399591224790622209,
  "created_at" : "2013-11-10 17:35:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Prevette",
      "screen_name" : "mikeprevette",
      "indices" : [ 0, 13 ],
      "id_str" : "1475531",
      "id" : 1475531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399526843512291328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596869896, -122.2755284514 ]
  },
  "id_str" : "399551845481213952",
  "in_reply_to_user_id" : 1475531,
  "text" : "@mikeprevette How long in SF? Wanna come visit Berkeley?",
  "id" : 399551845481213952,
  "in_reply_to_status_id" : 399526843512291328,
  "created_at" : "2013-11-10 14:59:17 +0000",
  "in_reply_to_screen_name" : "mikeprevette",
  "in_reply_to_user_id_str" : "1475531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 3, 11 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 33, 41 ],
      "id_str" : "807095",
      "id" : 807095
    }, {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "indices" : [ 45, 48 ],
      "id_str" : "20",
      "id" : 20
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 53, 60 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/kDyPNotfHq",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/11\/10\/business\/a-founder-of-twitter-goes-long.html?partner=rss&emc=rss&smid=tw-nytimes&_r=0",
      "display_url" : "nytimes.com\/2013\/11\/10\/bus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "399215306721091584",
  "text" : "RT @rsarver: Nice profile in the @nytimes on @Ev and @medium. From 140 characters to longform \"A Founder of Twitter Goes Long\" http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 20, 28 ],
        "id_str" : "807095",
        "id" : 807095
      }, {
        "name" : "Ev Williams",
        "screen_name" : "ev",
        "indices" : [ 32, 35 ],
        "id_str" : "20",
        "id" : 20
      }, {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 40, 47 ],
        "id_str" : "571202103",
        "id" : 571202103
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/kDyPNotfHq",
        "expanded_url" : "http:\/\/www.nytimes.com\/2013\/11\/10\/business\/a-founder-of-twitter-goes-long.html?partner=rss&emc=rss&smid=tw-nytimes&_r=0",
        "display_url" : "nytimes.com\/2013\/11\/10\/bus\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7528041295, -122.4420562908 ]
    },
    "id_str" : "399212687214669824",
    "text" : "Nice profile in the @nytimes on @Ev and @medium. From 140 characters to longform \"A Founder of Twitter Goes Long\" http:\/\/t.co\/kDyPNotfHq",
    "id" : 399212687214669824,
    "created_at" : "2013-11-09 16:31:36 +0000",
    "user" : {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "protected" : false,
      "id_str" : "795649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3015419114\/3dc096c48ef6167d1b26fd0d6b01814d_normal.jpeg",
      "id" : 795649,
      "verified" : false
    }
  },
  "id" : 399215306721091584,
  "created_at" : "2013-11-09 16:42:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/Cw1jYAqS01",
      "expanded_url" : "http:\/\/www.brainpickings.org\/index.php\/2012\/05\/23\/carl-sagan-the-burden-of-skepticism\/?utm_content=buffer52bf7&utm_source=buffer&utm_medium=twitter&utm_campaign=Buffer",
      "display_url" : "brainpickings.org\/index.php\/2012\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596845083, -122.275490882 ]
  },
  "id_str" : "399213153692549120",
  "text" : "\"A balance between two conflicting needs: the most skeptical scrutiny of all hypotheses &amp; an openness to new ideas.\" http:\/\/t.co\/Cw1jYAqS01",
  "id" : 399213153692549120,
  "created_at" : "2013-11-09 16:33:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Atlantic",
      "screen_name" : "TheAtlantic",
      "indices" : [ 3, 15 ],
      "id_str" : "35773039",
      "id" : 35773039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/FarliuJA39",
      "expanded_url" : "http:\/\/theatln.tc\/1aeHf0t",
      "display_url" : "theatln.tc\/1aeHf0t"
    } ]
  },
  "geo" : { },
  "id_str" : "399205741426266112",
  "text" : "RT @TheAtlantic: The simplest way to get people biking http:\/\/t.co\/FarliuJA39",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/FarliuJA39",
        "expanded_url" : "http:\/\/theatln.tc\/1aeHf0t",
        "display_url" : "theatln.tc\/1aeHf0t"
      } ]
    },
    "geo" : { },
    "id_str" : "399204617122111488",
    "text" : "The simplest way to get people biking http:\/\/t.co\/FarliuJA39",
    "id" : 399204617122111488,
    "created_at" : "2013-11-09 15:59:32 +0000",
    "user" : {
      "name" : "The Atlantic",
      "screen_name" : "TheAtlantic",
      "protected" : false,
      "id_str" : "35773039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1268207868\/twitter-icon-main_normal.png",
      "id" : 35773039,
      "verified" : true
    }
  },
  "id" : 399205741426266112,
  "created_at" : "2013-11-09 16:04:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/ZMNYS3Lyng",
      "expanded_url" : "http:\/\/flic.kr\/p\/hod3BA",
      "display_url" : "flic.kr\/p\/hod3BA"
    } ]
  },
  "geo" : { },
  "id_str" : "399039914811355136",
  "text" : "8:36pm Our new friends down the street are awesome http:\/\/t.co\/ZMNYS3Lyng",
  "id" : 399039914811355136,
  "created_at" : "2013-11-09 05:05:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 3, 12 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "onlyhalfjoking",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398884530834010113",
  "text" : "RT @mathowie: \u00DCber for HBO GO subscriptions ($5 per hour while account owners are at work, not using the feature). #onlyhalfjoking",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "onlyhalfjoking",
        "indices" : [ 101, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398882962231418880",
    "text" : "\u00DCber for HBO GO subscriptions ($5 per hour while account owners are at work, not using the feature). #onlyhalfjoking",
    "id" : 398882962231418880,
    "created_at" : "2013-11-08 18:41:23 +0000",
    "user" : {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "protected" : false,
      "id_str" : "761975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463101305972465664\/xjD_-7Jl_normal.jpeg",
      "id" : 761975,
      "verified" : false
    }
  },
  "id" : 398884530834010113,
  "created_at" : "2013-11-08 18:47:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 3, 12 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "indices" : [ 24, 36 ],
      "id_str" : "1532061",
      "id" : 1532061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/IDQnudwyla",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=332hGlHLfMA&feature=youtu.be&a",
      "display_url" : "youtube.com\/watch?v=332hGl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398883891345227776",
  "text" : "RT @agaricus: My friend @kevin2kelly has a new book out: http:\/\/t.co\/IDQnudwyla I think this is going to be one of his best.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Kelly",
        "screen_name" : "kevin2kelly",
        "indices" : [ 10, 22 ],
        "id_str" : "1532061",
        "id" : 1532061
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/IDQnudwyla",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=332hGlHLfMA&feature=youtu.be&a",
        "display_url" : "youtube.com\/watch?v=332hGl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "398883714572115968",
    "text" : "My friend @kevin2kelly has a new book out: http:\/\/t.co\/IDQnudwyla I think this is going to be one of his best.",
    "id" : 398883714572115968,
    "created_at" : "2013-11-08 18:44:23 +0000",
    "user" : {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "protected" : false,
      "id_str" : "21678279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/105835994\/agaricus_normal.jpg",
      "id" : 21678279,
      "verified" : false
    }
  },
  "id" : 398883891345227776,
  "created_at" : "2013-11-08 18:45:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398735835903713280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597870159, -122.2755697846 ]
  },
  "id_str" : "398743133422243840",
  "in_reply_to_user_id" : 2185,
  "text" : "gonna sleeeeep now gnight",
  "id" : 398743133422243840,
  "in_reply_to_status_id" : 398735835903713280,
  "created_at" : "2013-11-08 09:25:45 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mira Crisp",
      "screen_name" : "misscrisp",
      "indices" : [ 0, 10 ],
      "id_str" : "16228258",
      "id" : 16228258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398739628695359488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597700738, -122.2755754404 ]
  },
  "id_str" : "398742119046590464",
  "in_reply_to_user_id" : 16228258,
  "text" : "@misscrisp It was more sublime. Maybz a lil drunkin. Need to drink the waters. Thank yous.",
  "id" : 398742119046590464,
  "in_reply_to_status_id" : 398739628695359488,
  "created_at" : "2013-11-08 09:21:44 +0000",
  "in_reply_to_screen_name" : "misscrisp",
  "in_reply_to_user_id_str" : "16228258",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398558120273657856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8532599053, -122.2706119438 ]
  },
  "id_str" : "398735835903713280",
  "in_reply_to_user_id" : 2185,
  "text" : "walking home",
  "id" : 398735835903713280,
  "in_reply_to_status_id" : 398558120273657856,
  "created_at" : "2013-11-08 08:56:46 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zhanna Shamis",
      "screen_name" : "Zhanna",
      "indices" : [ 0, 7 ],
      "id_str" : "51573",
      "id" : 51573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398720727966175232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7843757892, -122.4079403123 ]
  },
  "id_str" : "398728636854853632",
  "in_reply_to_user_id" : 51573,
  "text" : "@Zhanna A good night!",
  "id" : 398728636854853632,
  "in_reply_to_status_id" : 398720727966175232,
  "created_at" : "2013-11-08 08:28:09 +0000",
  "in_reply_to_screen_name" : "Zhanna",
  "in_reply_to_user_id_str" : "51573",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 10, 18 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/IIHadNl132",
      "expanded_url" : "http:\/\/flic.kr\/p\/hmLwnc",
      "display_url" : "flic.kr\/p\/hmLwnc"
    } ]
  },
  "geo" : { },
  "id_str" : "398674965563981824",
  "text" : "8:36pm At @rsarver's thing. Where are you, Ryan??? http:\/\/t.co\/IIHadNl132",
  "id" : 398674965563981824,
  "created_at" : "2013-11-08 04:54:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zhanna Shamis",
      "screen_name" : "Zhanna",
      "indices" : [ 3, 10 ],
      "id_str" : "51573",
      "id" : 51573
    }, {
      "name" : "David Bellona",
      "screen_name" : "davidbellona",
      "indices" : [ 31, 44 ],
      "id_str" : "237472727",
      "id" : 237472727
    }, {
      "name" : "Mike Kruzeniski",
      "screen_name" : "mkruz",
      "indices" : [ 45, 51 ],
      "id_str" : "6604912",
      "id" : 6604912
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Zhanna\/status\/398651002498187266\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/jsy5O9atzO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYhK-XgCEAApX4I.jpg",
      "id_str" : "398651002343002112",
      "id" : 398651002343002112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYhK-XgCEAApX4I.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jsy5O9atzO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398656100339163136",
  "text" : "RT @Zhanna: Dancin' designers\u2122 @davidbellona @mkruz http:\/\/t.co\/jsy5O9atzO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Bellona",
        "screen_name" : "davidbellona",
        "indices" : [ 19, 32 ],
        "id_str" : "237472727",
        "id" : 237472727
      }, {
        "name" : "Mike Kruzeniski",
        "screen_name" : "mkruz",
        "indices" : [ 33, 39 ],
        "id_str" : "6604912",
        "id" : 6604912
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Zhanna\/status\/398651002498187266\/photo\/1",
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/jsy5O9atzO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYhK-XgCEAApX4I.jpg",
        "id_str" : "398651002343002112",
        "id" : 398651002343002112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYhK-XgCEAApX4I.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jsy5O9atzO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398651002498187266",
    "text" : "Dancin' designers\u2122 @davidbellona @mkruz http:\/\/t.co\/jsy5O9atzO",
    "id" : 398651002498187266,
    "created_at" : "2013-11-08 03:19:40 +0000",
    "user" : {
      "name" : "Zhanna Shamis",
      "screen_name" : "Zhanna",
      "protected" : false,
      "id_str" : "51573",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000515321213\/eb59cd9b026a393a228b0c38c6b3abb9_normal.jpeg",
      "id" : 51573,
      "verified" : false
    }
  },
  "id" : 398656100339163136,
  "created_at" : "2013-11-08 03:39:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/398632015144046592\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/al2wUfnqWC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYg5tKNCUAE3o4R.jpg",
      "id_str" : "398632015018217473",
      "id" : 398632015018217473,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYg5tKNCUAE3o4R.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/al2wUfnqWC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763548959, -122.416965589 ]
  },
  "id_str" : "398632015144046592",
  "text" : "http:\/\/t.co\/al2wUfnqWC",
  "id" : 398632015144046592,
  "created_at" : "2013-11-08 02:04:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "indices" : [ 28, 31 ],
      "id_str" : "20",
      "id" : 20
    }, {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 59, 70 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/rBgwqF8CG6",
      "expanded_url" : "http:\/\/bit.ly\/19Ikrqw",
      "display_url" : "bit.ly\/19Ikrqw"
    }, {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/l4rxY63KEu",
      "expanded_url" : "http:\/\/bit.ly\/19Ikp1T",
      "display_url" : "bit.ly\/19Ikp1T"
    } ]
  },
  "geo" : { },
  "id_str" : "398592394859266048",
  "text" : "The real first tweet was by @ev: http:\/\/t.co\/rBgwqF8CG6 RT @waxpancake: setting up my twitlog http:\/\/t.co\/l4rxY63KEu",
  "id" : 398592394859266048,
  "created_at" : "2013-11-07 23:26:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398516651802365952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764465621, -122.4168001478 ]
  },
  "id_str" : "398558120273657856",
  "in_reply_to_user_id" : 2185,
  "text" : "got some lunch",
  "id" : 398558120273657856,
  "in_reply_to_status_id" : 398516651802365952,
  "created_at" : "2013-11-07 21:10:35 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 0, 4 ],
      "id_str" : "12720772",
      "id" : 12720772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398539103500648448",
  "geo" : { },
  "id_str" : "398549074430816256",
  "in_reply_to_user_id" : 12720772,
  "text" : "@gwb I go to some! Definitely let me know if you're going to one and I'll try to make it out too.",
  "id" : 398549074430816256,
  "in_reply_to_status_id" : 398539103500648448,
  "created_at" : "2013-11-07 20:34:38 +0000",
  "in_reply_to_screen_name" : "gwb",
  "in_reply_to_user_id_str" : "12720772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Oliveira",
      "screen_name" : "f",
      "indices" : [ 0, 2 ],
      "id_str" : "5511",
      "id" : 5511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398525663055208449",
  "geo" : { },
  "id_str" : "398525830030036992",
  "in_reply_to_user_id" : 5511,
  "text" : "@f If you want an early beta tester, let me know. :)",
  "id" : 398525830030036992,
  "in_reply_to_status_id" : 398525663055208449,
  "created_at" : "2013-11-07 19:02:16 +0000",
  "in_reply_to_screen_name" : "f",
  "in_reply_to_user_id_str" : "5511",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Oliveira",
      "screen_name" : "f",
      "indices" : [ 0, 2 ],
      "id_str" : "5511",
      "id" : 5511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398523491907272704",
  "geo" : { },
  "id_str" : "398525400441057282",
  "in_reply_to_user_id" : 5511,
  "text" : "@f Ooh, neat! I was just thinking about a side project that could use this data. Any plans for an API?",
  "id" : 398525400441057282,
  "in_reply_to_status_id" : 398523491907272704,
  "created_at" : "2013-11-07 19:00:34 +0000",
  "in_reply_to_screen_name" : "f",
  "in_reply_to_user_id_str" : "5511",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 0, 4 ],
      "id_str" : "12720772",
      "id" : 12720772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398516685289689088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764238193, -122.4175138934 ]
  },
  "id_str" : "398521742521401345",
  "in_reply_to_user_id" : 12720772,
  "text" : "@gwb I spoke last year. It was fun. Thinking of going?",
  "id" : 398521742521401345,
  "in_reply_to_status_id" : 398516685289689088,
  "created_at" : "2013-11-07 18:46:02 +0000",
  "in_reply_to_screen_name" : "gwb",
  "in_reply_to_user_id_str" : "12720772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "benji shine",
      "screen_name" : "bshine",
      "indices" : [ 0, 7 ],
      "id_str" : "7305682",
      "id" : 7305682
    }, {
      "name" : "Postmates",
      "screen_name" : "getitnow",
      "indices" : [ 65, 74 ],
      "id_str" : "539257610",
      "id" : 539257610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398516899786395648",
  "geo" : { },
  "id_str" : "398518580972515328",
  "in_reply_to_user_id" : 7305682,
  "text" : "@bshine Ooh, have you done this? What's a good place nearby? \/cc @getitnow",
  "id" : 398518580972515328,
  "in_reply_to_status_id" : 398516899786395648,
  "created_at" : "2013-11-07 18:33:28 +0000",
  "in_reply_to_screen_name" : "bshine",
  "in_reply_to_user_id_str" : "7305682",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776376339, -122.417469542 ]
  },
  "id_str" : "398516651802365952",
  "text" : "so hungry",
  "id" : 398516651802365952,
  "created_at" : "2013-11-07 18:25:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "megan gebhart",
      "screen_name" : "megangebhart",
      "indices" : [ 0, 13 ],
      "id_str" : "32966836",
      "id" : 32966836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398500756526874624",
  "geo" : { },
  "id_str" : "398502697889841153",
  "in_reply_to_user_id" : 32966836,
  "text" : "@megangebhart Loved our conversation! Thanks for including me in this amazing project!",
  "id" : 398502697889841153,
  "in_reply_to_status_id" : 398500756526874624,
  "created_at" : "2013-11-07 17:30:21 +0000",
  "in_reply_to_screen_name" : "megangebhart",
  "in_reply_to_user_id_str" : "32966836",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "megan gebhart",
      "screen_name" : "megangebhart",
      "indices" : [ 3, 16 ],
      "id_str" : "32966836",
      "id" : 32966836
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 56, 63 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "52Cups",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/PtaRGCenj8",
      "expanded_url" : "http:\/\/bit.ly\/192kr0n",
      "display_url" : "bit.ly\/192kr0n"
    } ]
  },
  "geo" : { },
  "id_str" : "398501803274170369",
  "text" : "RT @megangebhart: The #52Cups adventure begins! Cup 1 w\/@Buster: a conversation about scary thoughts, authenticity and life: http:\/\/t.co\/Pt\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 38, 45 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "52Cups",
        "indices" : [ 4, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/PtaRGCenj8",
        "expanded_url" : "http:\/\/bit.ly\/192kr0n",
        "display_url" : "bit.ly\/192kr0n"
      } ]
    },
    "geo" : { },
    "id_str" : "398500756526874624",
    "text" : "The #52Cups adventure begins! Cup 1 w\/@Buster: a conversation about scary thoughts, authenticity and life: http:\/\/t.co\/PtaRGCenj8",
    "id" : 398500756526874624,
    "created_at" : "2013-11-07 17:22:38 +0000",
    "user" : {
      "name" : "megan gebhart",
      "screen_name" : "megangebhart",
      "protected" : false,
      "id_str" : "32966836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2954262620\/74d96d552974676eb198edfd2b04ea76_normal.jpeg",
      "id" : 32966836,
      "verified" : false
    }
  },
  "id" : 398501803274170369,
  "created_at" : "2013-11-07 17:26:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MAKE A STAND",
      "screen_name" : "vivienneharr",
      "indices" : [ 3, 16 ],
      "id_str" : "68167893",
      "id" : 68167893
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vivienneharr\/status\/398464558479982592\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/jLZcfbAhe0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYehZ5RIUAAHI3-.jpg",
      "id_str" : "398464558287048704",
      "id" : 398464558287048704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYehZ5RIUAAHI3-.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/jLZcfbAhe0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398467750797918208",
  "text" : "RT @vivienneharr: Vivienne on TechCrunch: \"You don't have to be big or powerful to change the world. You can be just like me.\" http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vivienneharr\/status\/398464558479982592\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/jLZcfbAhe0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYehZ5RIUAAHI3-.jpg",
        "id_str" : "398464558287048704",
        "id" : 398464558287048704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYehZ5RIUAAHI3-.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/jLZcfbAhe0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398464558479982592",
    "text" : "Vivienne on TechCrunch: \"You don't have to be big or powerful to change the world. You can be just like me.\" http:\/\/t.co\/jLZcfbAhe0",
    "id" : 398464558479982592,
    "created_at" : "2013-11-07 14:58:48 +0000",
    "user" : {
      "name" : "MAKE A STAND",
      "screen_name" : "vivienneharr",
      "protected" : false,
      "id_str" : "68167893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/429277995128205313\/awEuAb14_normal.jpeg",
      "id" : 68167893,
      "verified" : false
    }
  },
  "id" : 398467750797918208,
  "created_at" : "2013-11-07 15:11:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twoffice",
      "screen_name" : "twoffice",
      "indices" : [ 57, 66 ],
      "id_str" : "529817556",
      "id" : 529817556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/gsAIgn6bHs",
      "expanded_url" : "http:\/\/4sq.com\/1cWXAY4",
      "display_url" : "4sq.com\/1cWXAY4"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7767589224, -122.4169147126 ]
  },
  "id_str" : "398456392551759872",
  "text" : "Watching $TWTR opening bell in 5 minutes (@ Twitter HQ - @twoffice w\/ 79 others) [pic]: http:\/\/t.co\/gsAIgn6bHs",
  "id" : 398456392551759872,
  "created_at" : "2013-11-07 14:26:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763250775, -122.4168391842 ]
  },
  "id_str" : "398452505903783936",
  "text" : "eating a donut",
  "id" : 398452505903783936,
  "created_at" : "2013-11-07 14:10:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763251831, -122.4168197899 ]
  },
  "id_str" : "398445978241343489",
  "text" : "just drinking my coffee",
  "id" : 398445978241343489,
  "created_at" : "2013-11-07 13:44:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.851679462, -122.2696889092 ]
  },
  "id_str" : "398437088137191424",
  "text" : "Good morning.",
  "id" : 398437088137191424,
  "created_at" : "2013-11-07 13:09:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Roomann-Kurrik",
      "screen_name" : "kurrik",
      "indices" : [ 0, 7 ],
      "id_str" : "7588892",
      "id" : 7588892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398323194903269376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597623774, -122.2757129679 ]
  },
  "id_str" : "398324414934032385",
  "in_reply_to_user_id" : 7588892,
  "text" : "@kurrik [tweet of the day]",
  "id" : 398324414934032385,
  "in_reply_to_status_id" : 398323194903269376,
  "created_at" : "2013-11-07 05:41:55 +0000",
  "in_reply_to_screen_name" : "kurrik",
  "in_reply_to_user_id_str" : "7588892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sterling White",
      "screen_name" : "hey_sterling",
      "indices" : [ 0, 13 ],
      "id_str" : "150863291",
      "id" : 150863291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398321308812865536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597165272, -122.2754499783 ]
  },
  "id_str" : "398322656501448704",
  "in_reply_to_user_id" : 150863291,
  "text" : "@hey_sterling That's what I've been told.",
  "id" : 398322656501448704,
  "in_reply_to_status_id" : 398321308812865536,
  "created_at" : "2013-11-07 05:34:56 +0000",
  "in_reply_to_screen_name" : "hey_sterling",
  "in_reply_to_user_id_str" : "150863291",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nicole sheikh",
      "screen_name" : "nicolesheikh",
      "indices" : [ 0, 13 ],
      "id_str" : "90800956",
      "id" : 90800956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398315893492424704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597319499, -122.2754119245 ]
  },
  "id_str" : "398322577631739904",
  "in_reply_to_user_id" : 90800956,
  "text" : "@nicolesheikh Exactly... though it has been debunked a bit it's still a fun experiment to play.",
  "id" : 398322577631739904,
  "in_reply_to_status_id" : 398315893492424704,
  "created_at" : "2013-11-07 05:34:37 +0000",
  "in_reply_to_screen_name" : "nicolesheikh",
  "in_reply_to_user_id_str" : "90800956",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/twitter\/status\/398235511254298624\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/NWXaO4Myq0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYbRFlJCEAATMmI.jpg",
      "id_str" : "398235510868414464",
      "id" : 398235510868414464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYbRFlJCEAATMmI.jpg",
      "sizes" : [ {
        "h" : 719,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 719,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/NWXaO4Myq0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398314529118892033",
  "text" : "RT @twitter: We just priced our IPO. http:\/\/t.co\/NWXaO4Myq0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/twitter\/status\/398235511254298624\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/NWXaO4Myq0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYbRFlJCEAATMmI.jpg",
        "id_str" : "398235510868414464",
        "id" : 398235510868414464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYbRFlJCEAATMmI.jpg",
        "sizes" : [ {
          "h" : 719,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 719,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 674,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/NWXaO4Myq0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398235511254298624",
    "text" : "We just priced our IPO. http:\/\/t.co\/NWXaO4Myq0",
    "id" : 398235511254298624,
    "created_at" : "2013-11-06 23:48:39 +0000",
    "user" : {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "protected" : false,
      "id_str" : "783214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2284174758\/v65oai7fxn47qv9nectx_normal.png",
      "id" : 783214,
      "verified" : true
    }
  },
  "id" : 398314529118892033,
  "created_at" : "2013-11-07 05:02:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill S.",
      "screen_name" : "outseide",
      "indices" : [ 0, 9 ],
      "id_str" : "143694663",
      "id" : 143694663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398310193089744896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597558715, -122.2756468952 ]
  },
  "id_str" : "398311074081935360",
  "in_reply_to_user_id" : 143694663,
  "text" : "@outseide He actually had no trouble with 2 out of 3. And 1 he automatically ate before catching himself.",
  "id" : 398311074081935360,
  "in_reply_to_status_id" : 398310193089744896,
  "created_at" : "2013-11-07 04:48:54 +0000",
  "in_reply_to_screen_name" : "outseide",
  "in_reply_to_user_id_str" : "143694663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/UhP8KZCUfR",
      "expanded_url" : "http:\/\/flic.kr\/p\/hkhPqv",
      "display_url" : "flic.kr\/p\/hkhPqv"
    } ]
  },
  "geo" : { },
  "id_str" : "398309489868558336",
  "text" : "8:36pm Put a chocolate chip on the back of Niko's hand and set a timer for a minute before he could eat it.... http:\/\/t.co\/UhP8KZCUfR",
  "id" : 398309489868558336,
  "created_at" : "2013-11-07 04:42:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 8, 12 ],
      "id_str" : "259",
      "id" : 259
    }, {
      "name" : "Alyson van H",
      "screen_name" : "crayolaly",
      "indices" : [ 13, 23 ],
      "id_str" : "22211646",
      "id" : 22211646
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 77, 87 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pileonenthusiasm",
      "indices" : [ 55, 72 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398263985566257152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763052751, -122.4175142684 ]
  },
  "id_str" : "398264646798303232",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon @ian @crayolaly I'd be in for a 5k in Jan too! #pileonenthusiasm \/cc @kellianne",
  "id" : 398264646798303232,
  "in_reply_to_status_id" : 398263985566257152,
  "created_at" : "2013-11-07 01:44:25 +0000",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eatthedonuts",
      "indices" : [ 80, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398183957600022528",
  "geo" : { },
  "id_str" : "398185147838652416",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez A small token of appreciation for all of your hard work over the years. #eatthedonuts",
  "id" : 398185147838652416,
  "in_reply_to_status_id" : 398183957600022528,
  "created_at" : "2013-11-06 20:28:31 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398183185663541249",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763700254, -122.4174550479 ]
  },
  "id_str" : "398183827907952640",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez Here ya go \uD83C\uDF69",
  "id" : 398183827907952640,
  "in_reply_to_status_id" : 398183185663541249,
  "created_at" : "2013-11-06 20:23:17 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/eRLpVFIgMe",
      "expanded_url" : "https:\/\/vine.co\/v\/hIWJKTlh0j5",
      "display_url" : "vine.co\/v\/hIWJKTlh0j5"
    } ]
  },
  "geo" : { },
  "id_str" : "397977323267686400",
  "text" : "Dinner. https:\/\/t.co\/eRLpVFIgMe",
  "id" : 397977323267686400,
  "created_at" : "2013-11-06 06:42:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/LbWkk657GQ",
      "expanded_url" : "https:\/\/vine.co\/v\/hIWexdDQ5IA",
      "display_url" : "vine.co\/v\/hIWexdDQ5IA"
    } ]
  },
  "geo" : { },
  "id_str" : "397975702827700224",
  "text" : "Birthday candle! https:\/\/t.co\/LbWkk657GQ",
  "id" : 397975702827700224,
  "created_at" : "2013-11-06 06:36:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "frontback",
      "indices" : [ 9, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/UPtmua78Y1",
      "expanded_url" : "http:\/\/frontback.me\/p\/amaqFGmg",
      "display_url" : "frontback.me\/p\/amaqFGmg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.879498, -122.269153 ]
  },
  "id_str" : "397971727075905536",
  "text" : "My first #frontback staff pick yo http:\/\/t.co\/UPtmua78Y1",
  "id" : 397971727075905536,
  "created_at" : "2013-11-06 06:20:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/397947766308999168\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/a42cEEgUG8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYXLYoGCYAATLep.jpg",
      "id_str" : "397947766032195584",
      "id" : 397947766032195584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYXLYoGCYAATLep.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/a42cEEgUG8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8795237917, -122.2693152823 ]
  },
  "id_str" : "397947766308999168",
  "text" : "Chez Panisse bday http:\/\/t.co\/a42cEEgUG8",
  "id" : 397947766308999168,
  "created_at" : "2013-11-06 04:45:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 40, 50 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/397926772345303040\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/RJYMnHe7OU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYW4Sn2CAAAaoKZ.jpg",
      "id_str" : "397926772164919296",
      "id" : 397926772164919296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYW4Sn2CAAAaoKZ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 597
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 597
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 597
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RJYMnHe7OU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597558771, -122.2755897789 ]
  },
  "id_str" : "397926772345303040",
  "text" : "Belated birthday dinner celebration for @kellianne, headed to Chez Panisse http:\/\/t.co\/RJYMnHe7OU",
  "id" : 397926772345303040,
  "created_at" : "2013-11-06 03:21:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liza Bernstein",
      "screen_name" : "itsthebunk",
      "indices" : [ 0, 11 ],
      "id_str" : "17044026",
      "id" : 17044026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397807508980367360",
  "geo" : { },
  "id_str" : "397819632435744768",
  "in_reply_to_user_id" : 17044026,
  "text" : "@itsthebunk Thanks for the kind words, Liza! How did you find it?",
  "id" : 397819632435744768,
  "in_reply_to_status_id" : 397807508980367360,
  "created_at" : "2013-11-05 20:16:06 +0000",
  "in_reply_to_screen_name" : "itsthebunk",
  "in_reply_to_user_id_str" : "17044026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7783070412, -122.4155539927 ]
  },
  "id_str" : "397784424709779456",
  "text" : "\"A modern day Beatles. Their instruments: laptops. Their music: code.\"",
  "id" : 397784424709779456,
  "created_at" : "2013-11-05 17:56:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "indices" : [ 0, 9 ],
      "id_str" : "22483",
      "id" : 22483
    }, {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 10, 18 ],
      "id_str" : "291",
      "id" : 291
    }, {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 19, 24 ],
      "id_str" : "541",
      "id" : 541
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/397782747717971968\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/7jgMPHWMTh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYU1TSaCcAAG08b.jpg",
      "id_str" : "397782747566993408",
      "id" : 397782747566993408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYU1TSaCcAAG08b.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/7jgMPHWMTh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397780546148786176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7899203035, -122.4008720715 ]
  },
  "id_str" : "397782747717971968",
  "in_reply_to_user_id" : 22483,
  "text" : "@pinwheel @goldman @lane http:\/\/t.co\/7jgMPHWMTh",
  "id" : 397782747717971968,
  "in_reply_to_status_id" : 397780546148786176,
  "created_at" : "2013-11-05 17:49:32 +0000",
  "in_reply_to_screen_name" : "pinwheel",
  "in_reply_to_user_id_str" : "22483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "indices" : [ 0, 9 ],
      "id_str" : "22483",
      "id" : 22483
    }, {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 59, 67 ],
      "id_str" : "291",
      "id" : 291
    }, {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 72, 77 ],
      "id_str" : "541",
      "id" : 541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7988921494, -122.2786108169 ]
  },
  "id_str" : "397780109005819904",
  "in_reply_to_user_id" : 22483,
  "text" : "@pinwheel You're in chapter 3 of Hatching Twitter trolling @goldman \/cc @lane",
  "id" : 397780109005819904,
  "created_at" : "2013-11-05 17:39:03 +0000",
  "in_reply_to_screen_name" : "pinwheel",
  "in_reply_to_user_id_str" : "22483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 14, 23 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Offbeat Bride",
      "screen_name" : "offbeatbride",
      "indices" : [ 24, 37 ],
      "id_str" : "35900211",
      "id" : 35900211
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 38, 48 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397768187623661568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8529860294, -122.270645339 ]
  },
  "id_str" : "397775409728606208",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel @RickWebb @offbeatbride @kellianne Awesome! Can't wait for the 5-year anniversary party *in space*!",
  "id" : 397775409728606208,
  "in_reply_to_status_id" : 397768187623661568,
  "created_at" : "2013-11-05 17:20:22 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Robertson",
      "screen_name" : "Loobylu",
      "indices" : [ 0, 8 ],
      "id_str" : "653333",
      "id" : 653333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397607246676258816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597687271, -122.2755402773 ]
  },
  "id_str" : "397610862858346496",
  "in_reply_to_user_id" : 653333,
  "text" : "@Loobylu I feel bad posting sad pictures like this, but console myself for not posting the super sad heart-breaking one.",
  "id" : 397610862858346496,
  "in_reply_to_status_id" : 397607246676258816,
  "created_at" : "2013-11-05 06:26:31 +0000",
  "in_reply_to_screen_name" : "Loobylu",
  "in_reply_to_user_id_str" : "653333",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 26, 37 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/397599950856413184\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/vJ3FLrBFUx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYSPDG9CcAEDiVn.jpg",
      "id_str" : "397599950684450817",
      "id" : 397599950684450817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYSPDG9CcAEDiVn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/vJ3FLrBFUx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596903047, -122.2755122492 ]
  },
  "id_str" : "397599950856413184",
  "text" : "8:36pm Epic meltdown with @nikobenson luckily ended up with a good resolution in the end http:\/\/t.co\/vJ3FLrBFUx",
  "id" : 397599950856413184,
  "created_at" : "2013-11-05 05:43:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/OhtT7Q3Oem",
      "expanded_url" : "https:\/\/vine.co\/v\/hj0AHdnFFYZ",
      "display_url" : "vine.co\/v\/hj0AHdnFFYZ"
    } ]
  },
  "geo" : { },
  "id_str" : "397572673121026048",
  "text" : "Practicing zombie eyes https:\/\/t.co\/OhtT7Q3Oem",
  "id" : 397572673121026048,
  "created_at" : "2013-11-05 03:54:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Arundel",
      "screen_name" : "bitfield",
      "indices" : [ 3, 12 ],
      "id_str" : "14375294",
      "id" : 14375294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/fFReJUEp1y",
      "expanded_url" : "http:\/\/hackingdistributed.com\/2013\/11\/04\/bitcoin-is-broken\/",
      "display_url" : "hackingdistributed.com\/2013\/11\/04\/bit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397570706604449793",
  "text" : "RT @bitfield: Bitcoin and the selfish miner problem: http:\/\/t.co\/fFReJUEp1y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/fFReJUEp1y",
        "expanded_url" : "http:\/\/hackingdistributed.com\/2013\/11\/04\/bitcoin-is-broken\/",
        "display_url" : "hackingdistributed.com\/2013\/11\/04\/bit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "397528649668526082",
    "text" : "Bitcoin and the selfish miner problem: http:\/\/t.co\/fFReJUEp1y",
    "id" : 397528649668526082,
    "created_at" : "2013-11-05 00:59:50 +0000",
    "user" : {
      "name" : "John Arundel",
      "screen_name" : "bitfield",
      "protected" : false,
      "id_str" : "14375294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2550451333\/upr558w4gb7mdgopk0af_normal.jpeg",
      "id" : 14375294,
      "verified" : false
    }
  },
  "id" : 397570706604449793,
  "created_at" : "2013-11-05 03:46:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Sandquist",
      "screen_name" : "jeffsand",
      "indices" : [ 3, 12 ],
      "id_str" : "229523",
      "id" : 229523
    }, {
      "name" : "WordPress ",
      "screen_name" : "WordPress",
      "indices" : [ 47, 57 ],
      "id_str" : "685513",
      "id" : 685513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/nv9kYEnASj",
      "expanded_url" : "https:\/\/dev.twitter.com\/docs\/cards\/twitter-cards-for-cms-wordpress-blogger-tumblr",
      "display_url" : "dev.twitter.com\/docs\/cards\/twi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397568960888987648",
  "text" : "RT @jeffsand: How to add Twitter Cards to your @wordpress blog. Developers https:\/\/t.co\/nv9kYEnASj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WordPress ",
        "screen_name" : "WordPress",
        "indices" : [ 33, 43 ],
        "id_str" : "685513",
        "id" : 685513
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/nv9kYEnASj",
        "expanded_url" : "https:\/\/dev.twitter.com\/docs\/cards\/twitter-cards-for-cms-wordpress-blogger-tumblr",
        "display_url" : "dev.twitter.com\/docs\/cards\/twi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "397564631331246080",
    "text" : "How to add Twitter Cards to your @wordpress blog. Developers https:\/\/t.co\/nv9kYEnASj",
    "id" : 397564631331246080,
    "created_at" : "2013-11-05 03:22:49 +0000",
    "user" : {
      "name" : "Jeff Sandquist",
      "screen_name" : "jeffsand",
      "protected" : false,
      "id_str" : "229523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448952747669200896\/Z98jUnog_normal.jpeg",
      "id" : 229523,
      "verified" : false
    }
  },
  "id" : 397568960888987648,
  "created_at" : "2013-11-05 03:40:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8541316523, -122.2710181103 ]
  },
  "id_str" : "397559112575119362",
  "text" : "\"You will enjoy this zeugma as much as a piece of chocolate, or of music.\"",
  "id" : 397559112575119362,
  "created_at" : "2013-11-05 03:00:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobookproblems",
      "indices" : [ 18, 36 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397552569725095936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7791975899, -122.41427638 ]
  },
  "id_str" : "397552941155897344",
  "in_reply_to_user_id" : 2185,
  "text" : "Or rather zeugma. #audiobookproblems",
  "id" : 397552941155897344,
  "in_reply_to_status_id" : 397552569725095936,
  "created_at" : "2013-11-05 02:36:22 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397549877002907648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7791975899, -122.41427638 ]
  },
  "id_str" : "397552569725095936",
  "in_reply_to_user_id" : 2185,
  "text" : "Already learned what a zoogma is. Example: \"I'll meet you in 5 minutes and the garden.\"",
  "id" : 397552569725095936,
  "in_reply_to_status_id" : 397549877002907648,
  "created_at" : "2013-11-05 02:34:53 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "indices" : [ 0, 12 ],
      "id_str" : "289534689",
      "id" : 289534689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397551601671344128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7791975899, -122.41427638 ]
  },
  "id_str" : "397552152383471618",
  "in_reply_to_user_id" : 289534689,
  "text" : "@seriouspony That works well with a strategy of multiple readings.",
  "id" : 397552152383471618,
  "in_reply_to_status_id" : 397551601671344128,
  "created_at" : "2013-11-05 02:33:13 +0000",
  "in_reply_to_screen_name" : "seriouspony",
  "in_reply_to_user_id_str" : "289534689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "indices" : [ 0, 12 ],
      "id_str" : "289534689",
      "id" : 289534689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397550613338136576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763689007, -122.4171843499 ]
  },
  "id_str" : "397551075395264512",
  "in_reply_to_user_id" : 289534689,
  "text" : "@seriouspony :) Thank goodness for the 30sec rewind button in the Audible app. I've already used it 3-4 times and I'm only about 10 mins in.",
  "id" : 397551075395264512,
  "in_reply_to_status_id" : 397550613338136576,
  "created_at" : "2013-11-05 02:28:57 +0000",
  "in_reply_to_screen_name" : "seriouspony",
  "in_reply_to_user_id_str" : "289534689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763689007, -122.4171843499 ]
  },
  "id_str" : "397549877002907648",
  "text" : "Hitting play on the 34-hour audiobook \"Surfaces and Essences\" by Douglas Hofstadter = my happy place for the next couple weeks.",
  "id" : 397549877002907648,
  "created_at" : "2013-11-05 02:24:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 3, 11 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/8Lm0x5p7SN",
      "expanded_url" : "http:\/\/nyti.ms\/1ed5OPx",
      "display_url" : "nyti.ms\/1ed5OPx"
    } ]
  },
  "geo" : { },
  "id_str" : "397518628737654784",
  "text" : "RT @nytimes: Book About Amazon Is Reviewed on Amazon, by Founder\u2019s Wife http:\/\/t.co\/8Lm0x5p7SN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/8Lm0x5p7SN",
        "expanded_url" : "http:\/\/nyti.ms\/1ed5OPx",
        "display_url" : "nyti.ms\/1ed5OPx"
      } ]
    },
    "geo" : { },
    "id_str" : "397509463718232064",
    "text" : "Book About Amazon Is Reviewed on Amazon, by Founder\u2019s Wife http:\/\/t.co\/8Lm0x5p7SN",
    "id" : 397509463718232064,
    "created_at" : "2013-11-04 23:43:36 +0000",
    "user" : {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "protected" : false,
      "id_str" : "807095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2044921128\/finals_normal.png",
      "id" : 807095,
      "verified" : true
    }
  },
  "id" : 397518628737654784,
  "created_at" : "2013-11-05 00:20:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "indices" : [ 3, 16 ],
      "id_str" : "16906137",
      "id" : 16906137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Ytg3KfqsxO",
      "expanded_url" : "http:\/\/news.yahoo.com\/one-5-milky-way-stars-hosts-potentially-life-222919215.html",
      "display_url" : "news.yahoo.com\/one-5-milky-wa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397505309096161280",
  "text" : "RT @pourmecoffee: An amazing stat. \u201COne in five Milky Way stars life-friendly - 10 billion potentially habitable worlds\u201D http:\/\/t.co\/Ytg3Kf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/Ytg3KfqsxO",
        "expanded_url" : "http:\/\/news.yahoo.com\/one-5-milky-way-stars-hosts-potentially-life-222919215.html",
        "display_url" : "news.yahoo.com\/one-5-milky-wa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "397504514866962432",
    "text" : "An amazing stat. \u201COne in five Milky Way stars life-friendly - 10 billion potentially habitable worlds\u201D http:\/\/t.co\/Ytg3KfqsxO",
    "id" : 397504514866962432,
    "created_at" : "2013-11-04 23:23:56 +0000",
    "user" : {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "protected" : false,
      "id_str" : "16906137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421566216\/coffee1242220886_normal.jpg",
      "id" : 16906137,
      "verified" : true
    }
  },
  "id" : 397505309096161280,
  "created_at" : "2013-11-04 23:27:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    }, {
      "name" : "No Snowden",
      "screen_name" : "OfficialSnowden",
      "indices" : [ 33, 49 ],
      "id_str" : "1960678296",
      "id" : 1960678296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397481845639491584",
  "text" : "RT @ggreenwald: Fake -----&gt;   @OfficialSnowden",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "No Snowden",
        "screen_name" : "OfficialSnowden",
        "indices" : [ 17, 33 ],
        "id_str" : "1960678296",
        "id" : 1960678296
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "397369906401771520",
    "text" : "Fake -----&gt;   @OfficialSnowden",
    "id" : 397369906401771520,
    "created_at" : "2013-11-04 14:29:03 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/418715960158068736\/Lv1oLH3A_normal.jpeg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 397481845639491584,
  "created_at" : "2013-11-04 21:53:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/ovWeOYmGwA",
      "expanded_url" : "http:\/\/www.dailymail.co.uk\/news\/article-2486251\/Discovered-Billion-pound-art-collection-seized-Nazis-ordered-destroyed-discovered-rotting-food-dishevelled-Munich-apartment.html",
      "display_url" : "dailymail.co.uk\/news\/article-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397284201499611136",
  "text" : "\u00A31billion of Nazi-stolen art (Picasso, Matisse, and others) have been found in a decrepit old apartment.  http:\/\/t.co\/ovWeOYmGwA",
  "id" : 397284201499611136,
  "created_at" : "2013-11-04 08:48:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397246565909143552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597002663, -122.2755332106 ]
  },
  "id_str" : "397255776953044992",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Not being sticky and\/or stinky was my main argument on the matter. His counter-argument was that he didn't want to.",
  "id" : 397255776953044992,
  "in_reply_to_status_id" : 397246565909143552,
  "created_at" : "2013-11-04 06:55:32 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/VKyiYjWtKC",
      "expanded_url" : "http:\/\/flic.kr\/p\/hfp3yU",
      "display_url" : "flic.kr\/p\/hfp3yU"
    } ]
  },
  "geo" : { },
  "id_str" : "397245687001522177",
  "text" : "8:36pm Was talking to Niko about the advantages of bathing http:\/\/t.co\/VKyiYjWtKC",
  "id" : 397245687001522177,
  "created_at" : "2013-11-04 06:15:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amar Anand",
      "screen_name" : "amar",
      "indices" : [ 0, 5 ],
      "id_str" : "14695938",
      "id" : 14695938
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 6, 13 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397233521804062720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597354703, -122.2753484735 ]
  },
  "id_str" : "397236266778910720",
  "in_reply_to_user_id" : 14695938,
  "text" : "@amar @isaach I'm iPhone and that looks neat, but seems like a problem that will fall into the uncanny valley. What % of time is it right?",
  "id" : 397236266778910720,
  "in_reply_to_status_id" : 397233521804062720,
  "created_at" : "2013-11-04 05:38:00 +0000",
  "in_reply_to_screen_name" : "amar",
  "in_reply_to_user_id_str" : "14695938",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397231437058813954",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597673312, -122.2755966746 ]
  },
  "id_str" : "397232074618183680",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach Sorting by letter is a lot easier than trying to categorize in most other ways. 100% auto-clever would be great; 90% would suck.",
  "id" : 397232074618183680,
  "in_reply_to_status_id" : 397231437058813954,
  "created_at" : "2013-11-04 05:21:21 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397224322923634688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597606818, -122.2755373769 ]
  },
  "id_str" : "397230967162556416",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach That wouldn't solve the cognitive effort of finding an app. I have my top 10 apps on first screen and rest in alphabetical folders.",
  "id" : 397230967162556416,
  "in_reply_to_status_id" : 397224322923634688,
  "created_at" : "2013-11-04 05:16:57 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 3, 17 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397166553390530560",
  "text" : "RT @buster_ebooks: Hey, I wanna be the last page of Bonk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/busterbenson.com\" rel=\"nofollow\"\u003EBuster eBooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "397163572192886784",
    "text" : "Hey, I wanna be the last page of Bonk",
    "id" : 397163572192886784,
    "created_at" : "2013-11-04 00:49:09 +0000",
    "user" : {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "protected" : false,
      "id_str" : "1901375096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000503050571\/228ccabfeeb4e55bd8e172595babe02e_normal.jpeg",
      "id" : 1901375096,
      "verified" : false
    }
  },
  "id" : 397166553390530560,
  "created_at" : "2013-11-04 01:01:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597625438, -122.2754642275 ]
  },
  "id_str" : "397165737246072832",
  "text" : "I'm participating in NaNoOneBlogPostMo.",
  "id" : 397165737246072832,
  "created_at" : "2013-11-04 00:57:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/397080402487025664\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/dXeZLZLXWF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYK2hJ7CAAA24tG.jpg",
      "id_str" : "397080397877477376",
      "id" : 397080397877477376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYK2hJ7CAAA24tG.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/dXeZLZLXWF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597229394, -122.2755966616 ]
  },
  "id_str" : "397080402487025664",
  "text" : "Bikes attached to trailers attached to bikes http:\/\/t.co\/dXeZLZLXWF",
  "id" : 397080402487025664,
  "created_at" : "2013-11-03 19:18:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Clammer",
      "screen_name" : "paulclammer",
      "indices" : [ 3, 15 ],
      "id_str" : "110378538",
      "id" : 110378538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Nstyoyw71m",
      "expanded_url" : "http:\/\/www.viralnova.com\/i-noticed-this-tiny-thing-on-google-maps-and-when-i-zoomed-in-well-nothing-could-prepare-me\/",
      "display_url" : "viralnova.com\/i-noticed-this\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397049883498004480",
  "text" : "RT @paulclammer: Simply put, astonishing: 'I Noticed This Tiny Thing On Google Maps. When I Zoomed In\u2026 Well, Nothing Could Prepare Me' http\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Nstyoyw71m",
        "expanded_url" : "http:\/\/www.viralnova.com\/i-noticed-this-tiny-thing-on-google-maps-and-when-i-zoomed-in-well-nothing-could-prepare-me\/",
        "display_url" : "viralnova.com\/i-noticed-this\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "397019477918756865",
    "text" : "Simply put, astonishing: 'I Noticed This Tiny Thing On Google Maps. When I Zoomed In\u2026 Well, Nothing Could Prepare Me' http:\/\/t.co\/Nstyoyw71m",
    "id" : 397019477918756865,
    "created_at" : "2013-11-03 15:16:34 +0000",
    "user" : {
      "name" : "Paul Clammer",
      "screen_name" : "paulclammer",
      "protected" : false,
      "id_str" : "110378538",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000720000179\/94197ae2f2e032e4fca35d49028595c0_normal.jpeg",
      "id" : 110378538,
      "verified" : false
    }
  },
  "id" : 397049883498004480,
  "created_at" : "2013-11-03 17:17:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/397022633574670337\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/kWSoOyeZil",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYKB-0NCYAAco5r.jpg",
      "id_str" : "397022633327222784",
      "id" : 397022633327222784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYKB-0NCYAAco5r.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kWSoOyeZil"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595977137, -122.2754747887 ]
  },
  "id_str" : "397022633574670337",
  "text" : "Told Niko he has eagle eyes, so he made this face. http:\/\/t.co\/kWSoOyeZil",
  "id" : 397022633574670337,
  "created_at" : "2013-11-03 15:29:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spoonflower",
      "screen_name" : "Spoonflower",
      "indices" : [ 3, 15 ],
      "id_str" : "15023066",
      "id" : 15023066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/FZToPwXugt",
      "expanded_url" : "http:\/\/nyti.ms\/1iB3IGJ",
      "display_url" : "nyti.ms\/1iB3IGJ"
    } ]
  },
  "geo" : { },
  "id_str" : "397017296155078656",
  "text" : "RT @Spoonflower: The record for the longest scarf knitted while running a marathon: http:\/\/t.co\/FZToPwXugt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/FZToPwXugt",
        "expanded_url" : "http:\/\/nyti.ms\/1iB3IGJ",
        "display_url" : "nyti.ms\/1iB3IGJ"
      } ]
    },
    "geo" : { },
    "id_str" : "397012318279565312",
    "text" : "The record for the longest scarf knitted while running a marathon: http:\/\/t.co\/FZToPwXugt",
    "id" : 397012318279565312,
    "created_at" : "2013-11-03 14:48:07 +0000",
    "user" : {
      "name" : "Spoonflower",
      "screen_name" : "Spoonflower",
      "protected" : false,
      "id_str" : "15023066",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460786350900264960\/gqBkseLM_normal.png",
      "id" : 15023066,
      "verified" : false
    }
  },
  "id" : 397017296155078656,
  "created_at" : "2013-11-03 15:07:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 7, 18 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/396863956934877184\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/9QEnsPymB5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYHxqlrCEAA7e3N.jpg",
      "id_str" : "396863956154716160",
      "id" : 396863956154716160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYHxqlrCEAA7e3N.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 638,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 638,
        "resize" : "fit",
        "w" : 638
      } ],
      "display_url" : "pic.twitter.com\/9QEnsPymB5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596644337, -122.2756805645 ]
  },
  "id_str" : "396863956934877184",
  "text" : "8:36pm @nikobenson brushing teeth in bed http:\/\/t.co\/9QEnsPymB5",
  "id" : 396863956934877184,
  "created_at" : "2013-11-03 04:58:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 65, 75 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/Y0y8y00YdH",
      "expanded_url" : "http:\/\/4sq.com\/1b3u5kJ",
      "display_url" : "4sq.com\/1b3u5kJ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8566306596, -122.2532611718 ]
  },
  "id_str" : "396819389376643072",
  "text" : "Chose this over Gravity (@ Rialto Cinemas Elmwood for Don Jon w\/ @kellianne) [pic]: http:\/\/t.co\/Y0y8y00YdH",
  "id" : 396819389376643072,
  "created_at" : "2013-11-03 02:01:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396779896619298817",
  "geo" : { },
  "id_str" : "396783802430652416",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine Super fun... until I stepped into a pile of salt. :)",
  "id" : 396783802430652416,
  "in_reply_to_status_id" : 396779896619298817,
  "created_at" : "2013-11-02 23:40:05 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aileenlee",
      "screen_name" : "aileenlee",
      "indices" : [ 0, 10 ],
      "id_str" : "17493187",
      "id" : 17493187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396777650120699904",
  "geo" : { },
  "id_str" : "396782554230972416",
  "in_reply_to_user_id" : 17493187,
  "text" : "@aileenlee That would be awesome. Who's your bet for next unicorn? Snapchat?",
  "id" : 396782554230972416,
  "in_reply_to_status_id" : 396777650120699904,
  "created_at" : "2013-11-02 23:35:07 +0000",
  "in_reply_to_screen_name" : "aileenlee",
  "in_reply_to_user_id_str" : "17493187",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aileenlee",
      "screen_name" : "aileenlee",
      "indices" : [ 0, 10 ],
      "id_str" : "17493187",
      "id" : 17493187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396777012674568192",
  "in_reply_to_user_id" : 17493187,
  "text" : "@aileenlee Loved your post! Have you posted the 39 unicorns as a list (or even better, spreadsheet) anywhere?",
  "id" : 396777012674568192,
  "created_at" : "2013-11-02 23:13:06 +0000",
  "in_reply_to_screen_name" : "aileenlee",
  "in_reply_to_user_id_str" : "17493187",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/U7F7qdwEBV",
      "expanded_url" : "http:\/\/tcrn.ch\/1cwGLqK",
      "display_url" : "tcrn.ch\/1cwGLqK"
    } ]
  },
  "geo" : { },
  "id_str" : "396774843758043137",
  "text" : "I\u2019ve worked at one super unicorn, one regular unicorn, a guinea pig, a  rolley polley, and a snail. http:\/\/t.co\/U7F7qdwEBV",
  "id" : 396774843758043137,
  "created_at" : "2013-11-02 23:04:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Broderick",
      "screen_name" : "MichelleBee",
      "indices" : [ 0, 12 ],
      "id_str" : "1059951",
      "id" : 1059951
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 64, 72 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396706873836986368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596357427, -122.2756305895 ]
  },
  "id_str" : "396708401725456384",
  "in_reply_to_user_id" : 1059951,
  "text" : "@MichelleBee I'd still make that bet, but there's a chance that @nytimes could train people (incl myself) to buy digital subscriptions.",
  "id" : 396708401725456384,
  "in_reply_to_status_id" : 396706873836986368,
  "created_at" : "2013-11-02 18:40:28 +0000",
  "in_reply_to_screen_name" : "MichelleBee",
  "in_reply_to_user_id_str" : "1059951",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Frontback",
      "screen_name" : "frontbackapp",
      "indices" : [ 28, 41 ],
      "id_str" : "1520453022",
      "id" : 1520453022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396676729177403393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596866019, -122.2756574648 ]
  },
  "id_str" : "396677087429267458",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Pic! Even better: @frontbackapp it.",
  "id" : 396677087429267458,
  "in_reply_to_status_id" : 396676729177403393,
  "created_at" : "2013-11-02 16:36:02 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MediaREDEF",
      "screen_name" : "MediaREDEF",
      "indices" : [ 29, 40 ],
      "id_str" : "24438551",
      "id" : 24438551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/ZwjrsIGoKs",
      "expanded_url" : "http:\/\/bit.ly\/Hu6br8",
      "display_url" : "bit.ly\/Hu6br8"
    } ]
  },
  "in_reply_to_status_id_str" : "396674343834763264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596980428, -122.2755899715 ]
  },
  "id_str" : "396675041225490432",
  "in_reply_to_user_id" : 24438551,
  "text" : "I would've lost this bet. RT @MediaREDEF: The NYT\u2019s paywall overtakes digital ads http:\/\/t.co\/ZwjrsIGoKs",
  "id" : 396675041225490432,
  "in_reply_to_status_id" : 396674343834763264,
  "created_at" : "2013-11-02 16:27:54 +0000",
  "in_reply_to_screen_name" : "MediaREDEF",
  "in_reply_to_user_id_str" : "24438551",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/mob0yCQHrX",
      "expanded_url" : "http:\/\/www.theguardian.com\/lifeandstyle\/2013\/nov\/02\/change-your-life-cut-yourself-slack",
      "display_url" : "theguardian.com\/lifeandstyle\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597243618, -122.2756489228 ]
  },
  "id_str" : "396669662856896512",
  "text" : "Cut yourself some artificial slack. \"Busyness serves as a kind of existential reassurance, a hedge against emptiness\" http:\/\/t.co\/mob0yCQHrX",
  "id" : 396669662856896512,
  "created_at" : "2013-11-02 16:06:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Broderick",
      "screen_name" : "MichelleBee",
      "indices" : [ 3, 15 ],
      "id_str" : "1059951",
      "id" : 1059951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/mgSfiMFL5W",
      "expanded_url" : "http:\/\/www.thisiscolossal.com\/2013\/11\/just-the-two-of-us-cosplay\/",
      "display_url" : "thisiscolossal.com\/2013\/11\/just-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396664326523604992",
  "text" : "RT @MichelleBee: Portraits of Cosplay Enthusiasts in their Homes. Beautiful: http:\/\/t.co\/mgSfiMFL5W",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/mgSfiMFL5W",
        "expanded_url" : "http:\/\/www.thisiscolossal.com\/2013\/11\/just-the-two-of-us-cosplay\/",
        "display_url" : "thisiscolossal.com\/2013\/11\/just-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "396662665918963712",
    "text" : "Portraits of Cosplay Enthusiasts in their Homes. Beautiful: http:\/\/t.co\/mgSfiMFL5W",
    "id" : 396662665918963712,
    "created_at" : "2013-11-02 15:38:43 +0000",
    "user" : {
      "name" : "Michelle Broderick",
      "screen_name" : "MichelleBee",
      "protected" : false,
      "id_str" : "1059951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026663454\/811fd451dbd2e45d1191076e4dcbfc00_normal.jpeg",
      "id" : 1059951,
      "verified" : false
    }
  },
  "id" : 396664326523604992,
  "created_at" : "2013-11-02 15:45:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Verrilli",
      "screen_name" : "jess",
      "indices" : [ 3, 8 ],
      "id_str" : "6331462",
      "id" : 6331462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/HgxviY1lBa",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/11\/02\/business\/twitter-helps-revive-a-seedy-san-francisco-neighborhood.html?hpw&_r=0",
      "display_url" : "nytimes.com\/2013\/11\/02\/bus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396663929947951105",
  "text" : "RT @jess: Twitter Helps Revive the Tenderloin in SF. http:\/\/t.co\/HgxviY1lBa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/HgxviY1lBa",
        "expanded_url" : "http:\/\/www.nytimes.com\/2013\/11\/02\/business\/twitter-helps-revive-a-seedy-san-francisco-neighborhood.html?hpw&_r=0",
        "display_url" : "nytimes.com\/2013\/11\/02\/bus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "396662265945915392",
    "text" : "Twitter Helps Revive the Tenderloin in SF. http:\/\/t.co\/HgxviY1lBa",
    "id" : 396662265945915392,
    "created_at" : "2013-11-02 15:37:08 +0000",
    "user" : {
      "name" : "Jessica Verrilli",
      "screen_name" : "jess",
      "protected" : false,
      "id_str" : "6331462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000833667387\/05e1eaad3b33070cff4fd66b4db90b52_normal.jpeg",
      "id" : 6331462,
      "verified" : false
    }
  },
  "id" : 396663929947951105,
  "created_at" : "2013-11-02 15:43:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tristan walker",
      "screen_name" : "tristanwalker",
      "indices" : [ 0, 14 ],
      "id_str" : "18206161",
      "id" : 18206161
    }, {
      "name" : "Virgin America",
      "screen_name" : "VirginAmerica",
      "indices" : [ 15, 29 ],
      "id_str" : "12101862",
      "id" : 12101862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396661357233180673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596797856, -122.2755454966 ]
  },
  "id_str" : "396661784238501889",
  "in_reply_to_user_id" : 18206161,
  "text" : "@tristanwalker @VirginAmerica The nun gets to keep some of her modems and toasters out after all?",
  "id" : 396661784238501889,
  "in_reply_to_status_id" : 396661357233180673,
  "created_at" : "2013-11-02 15:35:13 +0000",
  "in_reply_to_screen_name" : "tristanwalker",
  "in_reply_to_user_id_str" : "18206161",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 11, 22 ],
      "id_str" : "784078",
      "id" : 784078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/BdifDNa1o8",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/11\/03\/books\/review\/alice-e-marwicks-status-update.html?ref=books",
      "display_url" : "nytimes.com\/2013\/11\/03\/boo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "396639600804114432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597549385, -122.2754611443 ]
  },
  "id_str" : "396657338553094145",
  "in_reply_to_user_id" : 784078,
  "text" : "Bought! RT @alicetiara: NYT review of my book today! http:\/\/t.co\/BdifDNa1o8 Yes, it's negative but the reviewer doesn't like academic books.",
  "id" : 396657338553094145,
  "in_reply_to_status_id" : 396639600804114432,
  "created_at" : "2013-11-02 15:17:33 +0000",
  "in_reply_to_screen_name" : "alicetiara",
  "in_reply_to_user_id_str" : "784078",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 0, 11 ],
      "id_str" : "784078",
      "id" : 784078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396639600804114432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597660224, -122.2755773179 ]
  },
  "id_str" : "396656967638192129",
  "in_reply_to_user_id" : 784078,
  "text" : "@alicetiara Awesome, congrats! His criticisms are weak and occasionally offensive, and will hopefully intrigue the right audience to read!",
  "id" : 396656967638192129,
  "in_reply_to_status_id" : 396639600804114432,
  "created_at" : "2013-11-02 15:16:05 +0000",
  "in_reply_to_screen_name" : "alicetiara",
  "in_reply_to_user_id_str" : "784078",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "indices" : [ 3, 11 ],
      "id_str" : "6825792",
      "id" : 6825792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396654943945228288",
  "text" : "RT @ibogost: I have crushed\nthe candy\nthat was in\nthe saga\n\nand which\nyou were probably\nhoping\nto monetize\n\nSpare me\nyour greedy urges\nto b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396630146608037888",
    "text" : "I have crushed\nthe candy\nthat was in\nthe saga\n\nand which\nyou were probably\nhoping\nto monetize\n\nSpare me\nyour greedy urges\nto beat\nand cajole",
    "id" : 396630146608037888,
    "created_at" : "2013-11-02 13:29:30 +0000",
    "user" : {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "protected" : false,
      "id_str" : "6825792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000781335947\/35cf1c51da400cb25d07c6c471e12f2c_normal.jpeg",
      "id" : 6825792,
      "verified" : true
    }
  },
  "id" : 396654943945228288,
  "created_at" : "2013-11-02 15:08:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JT",
      "screen_name" : "JT_IV_",
      "indices" : [ 3, 10 ],
      "id_str" : "49501152",
      "id" : 49501152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396653508067225602",
  "text" : "RT @JT_IV_: I saw the best minds of my generation, staring at their phones.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396292811722870784",
    "text" : "I saw the best minds of my generation, staring at their phones.",
    "id" : 396292811722870784,
    "created_at" : "2013-11-01 15:09:03 +0000",
    "user" : {
      "name" : "JT",
      "screen_name" : "JT_IV_",
      "protected" : false,
      "id_str" : "49501152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462017241530114048\/5KdAvtG-_normal.jpeg",
      "id" : 49501152,
      "verified" : false
    }
  },
  "id" : 396653508067225602,
  "created_at" : "2013-11-02 15:02:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "megan gebhart",
      "screen_name" : "megangebhart",
      "indices" : [ 28, 41 ],
      "id_str" : "32966836",
      "id" : 32966836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/uFCYzIoh3O",
      "expanded_url" : "http:\/\/tmblr.co\/Z9OrEyzCb-v1",
      "display_url" : "tmblr.co\/Z9OrEyzCb-v1"
    } ]
  },
  "in_reply_to_status_id_str" : "396346040380833792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85972938, -122.2755458306 ]
  },
  "id_str" : "396494798036557824",
  "in_reply_to_user_id" : 32966836,
  "text" : "This is really really cool! @megangebhart had coffee with 52 people and shared their conversations. Pt 2 starts soon: http:\/\/t.co\/uFCYzIoh3O",
  "id" : 396494798036557824,
  "in_reply_to_status_id" : 396346040380833792,
  "created_at" : "2013-11-02 04:31:41 +0000",
  "in_reply_to_screen_name" : "megangebhart",
  "in_reply_to_user_id_str" : "32966836",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 0, 7 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 8, 17 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/71ExD3Ftv8",
      "expanded_url" : "https:\/\/twitter.com\/buster\/statuses\/394664630645030913",
      "display_url" : "twitter.com\/buster\/statuse\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "396488795027017728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597636253, -122.2755189506 ]
  },
  "id_str" : "396490128828289024",
  "in_reply_to_user_id" : 15727738,
  "text" : "@cwhogg @eramirez I have to finish my blog post about this mangling of a Confucius quote: https:\/\/t.co\/71ExD3Ftv8",
  "id" : 396490128828289024,
  "in_reply_to_status_id" : 396488795027017728,
  "created_at" : "2013-11-02 04:13:07 +0000",
  "in_reply_to_screen_name" : "cwhogg",
  "in_reply_to_user_id_str" : "15727738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 0, 7 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 8, 17 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396486327639633920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597671591, -122.2755111873 ]
  },
  "id_str" : "396486794633441280",
  "in_reply_to_user_id" : 15727738,
  "text" : "@cwhogg @eramirez And what's the prize?",
  "id" : 396486794633441280,
  "in_reply_to_status_id" : 396486327639633920,
  "created_at" : "2013-11-02 03:59:52 +0000",
  "in_reply_to_screen_name" : "cwhogg",
  "in_reply_to_user_id_str" : "15727738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 10, 17 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396485233693847552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596053712, -122.2755425479 ]
  },
  "id_str" : "396485720488955904",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @cwhogg *insert obligatory skeptical remark about the meaningless of steps* :)",
  "id" : 396485720488955904,
  "in_reply_to_status_id" : 396485233693847552,
  "created_at" : "2013-11-02 03:55:36 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aiko",
      "screen_name" : "twerpherder",
      "indices" : [ 0, 12 ],
      "id_str" : "304743558",
      "id" : 304743558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396482560832053248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597687623, -122.2754863918 ]
  },
  "id_str" : "396483547911192576",
  "in_reply_to_user_id" : 304743558,
  "text" : "@twerpherder Yay! You've hopped on the 8:36 train!",
  "id" : 396483547911192576,
  "in_reply_to_status_id" : 396482560832053248,
  "created_at" : "2013-11-02 03:46:58 +0000",
  "in_reply_to_screen_name" : "twerpherder",
  "in_reply_to_user_id_str" : "304743558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/396483094883999744\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/c7CilOMkde",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYCXRiUCYAEzyWA.jpg",
      "id_str" : "396483094733021185",
      "id" : 396483094733021185,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYCXRiUCYAEzyWA.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 597
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 597
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 597
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/c7CilOMkde"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596699657, -122.2755715997 ]
  },
  "id_str" : "396483094883999744",
  "text" : "8:36pm Waking up at 3:30am and subsequent insomnia have zapped my brain http:\/\/t.co\/c7CilOMkde",
  "id" : 396483094883999744,
  "created_at" : "2013-11-02 03:45:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396468933752274944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596771654, -122.2756273621 ]
  },
  "id_str" : "396477569932869632",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap Yeah, I remember feeling that way too, but always believed in Bezos' vision and focus.",
  "id" : 396477569932869632,
  "in_reply_to_status_id" : 396468933752274944,
  "created_at" : "2013-11-02 03:23:13 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aronchick",
      "screen_name" : "aronchick",
      "indices" : [ 0, 10 ],
      "id_str" : "15024407",
      "id" : 15024407
    }, {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 11, 15 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396475338810601472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597288486, -122.2754719389 ]
  },
  "id_str" : "396476673601724416",
  "in_reply_to_user_id" : 15024407,
  "text" : "@aronchick @cap Ooh didn't know you joined! Can you say which team? Have you read the book?",
  "id" : 396476673601724416,
  "in_reply_to_status_id" : 396475338810601472,
  "created_at" : "2013-11-02 03:19:39 +0000",
  "in_reply_to_screen_name" : "aronchick",
  "in_reply_to_user_id_str" : "15024407",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396462472015912960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597487191, -122.2755416161 ]
  },
  "id_str" : "396463194719277057",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Yeah there's some serious future-accelerating work &amp; customer obsession but it struck me as all being in service of the mercenary.",
  "id" : 396463194719277057,
  "in_reply_to_status_id" : 396462472015912960,
  "created_at" : "2013-11-02 02:26:06 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396448892226928640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597709429, -122.2754770726 ]
  },
  "id_str" : "396460371805880320",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert In the \"most mercenaries think they are missionaries\" sense?",
  "id" : 396460371805880320,
  "in_reply_to_status_id" : 396448892226928640,
  "created_at" : "2013-11-02 02:14:53 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.807090832, -122.3028110248 ]
  },
  "id_str" : "396448684650422272",
  "text" : "Ultimately, I think Bezos and Amazon ends up looking pretty evil by the end of The Everything Store.",
  "id" : 396448684650422272,
  "created_at" : "2013-11-02 01:28:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859763274, -122.2755224153 ]
  },
  "id_str" : "396293355568496640",
  "text" : "Rabbit rabbit.",
  "id" : 396293355568496640,
  "created_at" : "2013-11-01 15:11:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]