Grailbird.data.tweets_2013_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/418280992017612800\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VMgNoHZ7Ip",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bc4IWJFCUAEH7AW.jpg",
      "id_str" : "418280991879221249",
      "id" : 418280991879221249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bc4IWJFCUAEH7AW.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/VMgNoHZ7Ip"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8679683272, -122.2842079889 ]
  },
  "id_str" : "418280992017612800",
  "text" : "http:\/\/t.co\/VMgNoHZ7Ip",
  "id" : 418280992017612800,
  "created_at" : "2014-01-01 07:22:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/418245349996630016\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/p2WtMSosZF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bc3n7gJCEAA1f9v.jpg",
      "id_str" : "418245349841440768",
      "id" : 418245349841440768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bc3n7gJCEAA1f9v.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/p2WtMSosZF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8679446644, -122.2842537427 ]
  },
  "id_str" : "418245349996630016",
  "text" : "8:36pm Setting up kid nye so that we can head to adult nye! http:\/\/t.co\/p2WtMSosZF",
  "id" : 418245349996630016,
  "created_at" : "2014-01-01 05:00:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "momjams",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418201180750102528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859544923, -122.2755994428 ]
  },
  "id_str" : "418201444123045888",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley What does it mean if I'm really into #momjams too?",
  "id" : 418201444123045888,
  "in_reply_to_status_id" : 418201180750102528,
  "created_at" : "2014-01-01 02:06:08 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418164981340053504",
  "geo" : { },
  "id_str" : "418165396558987265",
  "in_reply_to_user_id" : 761628,
  "text" : "@rickwebb We'll need them because the boomers are gonna be moving in with us.",
  "id" : 418165396558987265,
  "in_reply_to_status_id" : 418164981340053504,
  "created_at" : "2013-12-31 23:42:54 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 3, 12 ],
      "id_str" : "14986129",
      "id" : 14986129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/KaCd5YZeTJ",
      "expanded_url" : "http:\/\/qr.ae\/GEeks",
      "display_url" : "qr.ae\/GEeks"
    } ]
  },
  "geo" : { },
  "id_str" : "418157337623269376",
  "text" : "RT @irondavy: Incredible. \"How would you programmatically parse a sentence and decide to answer 'that's what she said'?\" http:\/\/t.co\/KaCd5Y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/KaCd5YZeTJ",
        "expanded_url" : "http:\/\/qr.ae\/GEeks",
        "display_url" : "qr.ae\/GEeks"
      } ]
    },
    "geo" : { },
    "id_str" : "418152982643879937",
    "text" : "Incredible. \"How would you programmatically parse a sentence and decide to answer 'that's what she said'?\" http:\/\/t.co\/KaCd5YZeTJ",
    "id" : 418152982643879937,
    "created_at" : "2013-12-31 22:53:34 +0000",
    "user" : {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "protected" : false,
      "id_str" : "14986129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460097018266779648\/sDfnmwhH_normal.jpeg",
      "id" : 14986129,
      "verified" : false
    }
  },
  "id" : 418157337623269376,
  "created_at" : "2013-12-31 23:10:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 14, 23 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/V7g7iOGXzO",
      "expanded_url" : "https:\/\/medium.com\/p\/43218e800a54",
      "display_url" : "medium.com\/p\/43218e800a54"
    } ]
  },
  "geo" : { },
  "id_str" : "418144346248970240",
  "text" : "I really like @rickwebb's view of the tech world as one big company that actually works: https:\/\/t.co\/V7g7iOGXzO",
  "id" : 418144346248970240,
  "created_at" : "2013-12-31 22:19:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Clear",
      "screen_name" : "james_clear",
      "indices" : [ 0, 12 ],
      "id_str" : "226428094",
      "id" : 226428094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418140599514955776",
  "geo" : { },
  "id_str" : "418141246851256320",
  "in_reply_to_user_id" : 226428094,
  "text" : "@james_clear I generally agree, but by what magic can one just \"become the type of person that X\"? The cart is still before the horse.",
  "id" : 418141246851256320,
  "in_reply_to_status_id" : 418140599514955776,
  "created_at" : "2013-12-31 22:06:56 +0000",
  "in_reply_to_screen_name" : "james_clear",
  "in_reply_to_user_id_str" : "226428094",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    }, {
      "name" : "Hari Vasupuram",
      "screen_name" : "hvasupuram",
      "indices" : [ 6, 17 ],
      "id_str" : "554407670",
      "id" : 554407670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418108029062483968",
  "geo" : { },
  "id_str" : "418108201494515712",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara @hvasupuram That works too. Words are weird.",
  "id" : 418108201494515712,
  "in_reply_to_status_id" : 418108029062483968,
  "created_at" : "2013-12-31 19:55:37 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 0, 13 ],
      "id_str" : "14471007",
      "id" : 14471007
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 66, 73 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418103450497732610",
  "geo" : { },
  "id_str" : "418107625767567360",
  "in_reply_to_user_id" : 14471007,
  "text" : "@dianakimball Thanks, Diana! PS. I updated my username to be just @buster. :) Happy new year!",
  "id" : 418107625767567360,
  "in_reply_to_status_id" : 418103450497732610,
  "created_at" : "2013-12-31 19:53:20 +0000",
  "in_reply_to_screen_name" : "dianakimball",
  "in_reply_to_user_id_str" : "14471007",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    }, {
      "name" : "Hari Vasupuram",
      "screen_name" : "hvasupuram",
      "indices" : [ 6, 17 ],
      "id_str" : "554407670",
      "id" : 554407670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418104435236032512",
  "geo" : { },
  "id_str" : "418106382026428416",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara @hvasupuram It might just be words. I see goals as short term, interests as long term, and process as the framework for improvement.",
  "id" : 418106382026428416,
  "in_reply_to_status_id" : 418104435236032512,
  "created_at" : "2013-12-31 19:48:24 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/sL7Nf9ujJB",
      "expanded_url" : "https:\/\/medium.com\/buster-benson\/69cda443d387",
      "display_url" : "medium.com\/buster-benson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418100336369205248",
  "text" : "My 5 tips for making better resolutions: https:\/\/t.co\/sL7Nf9ujJB (Retweet if you must.)",
  "id" : 418100336369205248,
  "created_at" : "2013-12-31 19:24:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418082225846898688",
  "geo" : { },
  "id_str" : "418087982692704256",
  "in_reply_to_user_id" : 15275073,
  "text" : "@tberman True. They could be better, but they aren\u2019t the worse.",
  "id" : 418087982692704256,
  "in_reply_to_status_id" : 418082225846898688,
  "created_at" : "2013-12-31 18:35:17 +0000",
  "in_reply_to_screen_name" : "tberman",
  "in_reply_to_user_id_str" : "15275073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 9, 16 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418078777906692096",
  "geo" : { },
  "id_str" : "418081603147935744",
  "in_reply_to_user_id" : 15275073,
  "text" : "@tberman @harryh Maybe 12? You think too rationally, it's not binary. The fuzzy emotional drift of a brand *will* have long term impact.",
  "id" : 418081603147935744,
  "in_reply_to_status_id" : 418078777906692096,
  "created_at" : "2013-12-31 18:09:56 +0000",
  "in_reply_to_screen_name" : "tberman",
  "in_reply_to_user_id_str" : "15275073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 9, 16 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418077125816512512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859547621, -122.2755315258 ]
  },
  "id_str" : "418078547706523648",
  "in_reply_to_user_id" : 15275073,
  "text" : "@tberman @harryh My perception of the Uber brand is that they are smart, useful, forward-thinking, and most likely evil.",
  "id" : 418078547706523648,
  "in_reply_to_status_id" : 418077125816512512,
  "created_at" : "2013-12-31 17:57:47 +0000",
  "in_reply_to_screen_name" : "tberman",
  "in_reply_to_user_id_str" : "15275073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 9, 16 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418076889815609344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595777158, -122.2756060429 ]
  },
  "id_str" : "418077232293109760",
  "in_reply_to_user_id" : 2185,
  "text" : "@tberman @harryh I doubt it's good. It's probably not what they're going for. And once implanted it's difficult to erase. Rational or not.",
  "id" : 418077232293109760,
  "in_reply_to_status_id" : 418076889815609344,
  "created_at" : "2013-12-31 17:52:34 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 9, 16 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418075428905959424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859600884, -122.2756147737 ]
  },
  "id_str" : "418076889815609344",
  "in_reply_to_user_id" : 15275073,
  "text" : "@tberman @harryh Possibly. But we don't know enough about the long term impact of having surge pricing associated with your core brand.",
  "id" : 418076889815609344,
  "in_reply_to_status_id" : 418075428905959424,
  "created_at" : "2013-12-31 17:51:12 +0000",
  "in_reply_to_screen_name" : "tberman",
  "in_reply_to_user_id_str" : "15275073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin L. Haas",
      "screen_name" : "delohaas",
      "indices" : [ 0, 9 ],
      "id_str" : "24212532",
      "id" : 24212532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418073800903626752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596724803, -122.2754744535 ]
  },
  "id_str" : "418074547271659523",
  "in_reply_to_user_id" : 24212532,
  "text" : "@delohaas Exactly. :) I do love a good gamble.",
  "id" : 418074547271659523,
  "in_reply_to_status_id" : 418073800903626752,
  "created_at" : "2013-12-31 17:41:54 +0000",
  "in_reply_to_screen_name" : "delohaas",
  "in_reply_to_user_id_str" : "24212532",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Matteson",
      "screen_name" : "mattmatt",
      "indices" : [ 0, 9 ],
      "id_str" : "619303",
      "id" : 619303
    }, {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 10, 18 ],
      "id_str" : "353195232",
      "id" : 353195232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418073719072768000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595753524, -122.2755990744 ]
  },
  "id_str" : "418074283940659200",
  "in_reply_to_user_id" : 619303,
  "text" : "@mattmatt @liftapp Yup that works! But if I have to wait I suppose I can. :)",
  "id" : 418074283940659200,
  "in_reply_to_status_id" : 418073719072768000,
  "created_at" : "2013-12-31 17:40:51 +0000",
  "in_reply_to_screen_name" : "mattmatt",
  "in_reply_to_user_id_str" : "619303",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 9, 16 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417889814155776000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596216509, -122.2755696642 ]
  },
  "id_str" : "418073753075978241",
  "in_reply_to_user_id" : 15275073,
  "text" : "@tberman @harryh I've watch this issue surge up (get it?) three times at least. It's more than just a mindless mob if they keep coming back.",
  "id" : 418073753075978241,
  "in_reply_to_status_id" : 417889814155776000,
  "created_at" : "2013-12-31 17:38:44 +0000",
  "in_reply_to_screen_name" : "tberman",
  "in_reply_to_user_id_str" : "15275073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 0, 8 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418072599487197185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598764793, -122.2752421078 ]
  },
  "id_str" : "418073159397429249",
  "in_reply_to_user_id" : 22891211,
  "text" : "@chanian Gonna just buy a bunch of bitcoin on credit and cross my fingers. Just as fun as a jet ski.",
  "id" : 418073159397429249,
  "in_reply_to_status_id" : 418072599487197185,
  "created_at" : "2013-12-31 17:36:23 +0000",
  "in_reply_to_screen_name" : "chanian",
  "in_reply_to_user_id_str" : "22891211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Matteson",
      "screen_name" : "mattmatt",
      "indices" : [ 0, 9 ],
      "id_str" : "619303",
      "id" : 619303
    }, {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 10, 18 ],
      "id_str" : "353195232",
      "id" : 353195232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418071304814592001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597698134, -122.2754535414 ]
  },
  "id_str" : "418072388434026496",
  "in_reply_to_user_id" : 619303,
  "text" : "@mattmatt @liftapp Oh man you're gonna make me wait? Tell me and I'll promise to still visit.",
  "id" : 418072388434026496,
  "in_reply_to_status_id" : 418071304814592001,
  "created_at" : "2013-12-31 17:33:19 +0000",
  "in_reply_to_screen_name" : "mattmatt",
  "in_reply_to_user_id_str" : "619303",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418071329334521856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595494485, -122.2756161568 ]
  },
  "id_str" : "418072158443552768",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Thank you! Yes it feels liberating to have a clean slate. Worth every penny along the way too.",
  "id" : 418072158443552768,
  "in_reply_to_status_id" : 418071329334521856,
  "created_at" : "2013-12-31 17:32:24 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418070523008933888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596578185, -122.2755137683 ]
  },
  "id_str" : "418071627071356928",
  "in_reply_to_user_id" : 2185,
  "text" : "That debt we finally erased helped pay for 2 startups, a bar\/art gallery, a home birth, and 8 years of crazy fun. RIP debt.",
  "id" : 418071627071356928,
  "in_reply_to_status_id" : 418070523008933888,
  "created_at" : "2013-12-31 17:30:17 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859683293, -122.275448721 ]
  },
  "id_str" : "418070523008933888",
  "text" : "In the last week or so we sold our loft in Seattle and paid off our car and all of our credit cards. Back to $0, feels so good.",
  "id" : 418070523008933888,
  "created_at" : "2013-12-31 17:25:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Sterling",
      "screen_name" : "mistersterling",
      "indices" : [ 0, 15 ],
      "id_str" : "15910452",
      "id" : 15910452
    }, {
      "name" : "Hari Vasupuram",
      "screen_name" : "hvasupuram",
      "indices" : [ 16, 27 ],
      "id_str" : "554407670",
      "id" : 554407670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418039496752377859",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596748272, -122.2754121759 ]
  },
  "id_str" : "418040903685521409",
  "in_reply_to_user_id" : 15910452,
  "text" : "@mistersterling @hvasupuram I love that book. Probably need to reread it.",
  "id" : 418040903685521409,
  "in_reply_to_status_id" : 418039496752377859,
  "created_at" : "2013-12-31 15:28:12 +0000",
  "in_reply_to_screen_name" : "mistersterling",
  "in_reply_to_user_id_str" : "15910452",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Grundel",
      "screen_name" : "robgrundel",
      "indices" : [ 0, 11 ],
      "id_str" : "32865573",
      "id" : 32865573
    }, {
      "name" : "Hari Vasupuram",
      "screen_name" : "hvasupuram",
      "indices" : [ 12, 23 ],
      "id_str" : "554407670",
      "id" : 554407670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418035612168757248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597295611, -122.2754997668 ]
  },
  "id_str" : "418037391945789440",
  "in_reply_to_user_id" : 32865573,
  "text" : "@robgrundel @hvasupuram I like the article but think he's using the word system in place of habit, and focusing on habits also has problems.",
  "id" : 418037391945789440,
  "in_reply_to_status_id" : 418035612168757248,
  "created_at" : "2013-12-31 15:14:15 +0000",
  "in_reply_to_screen_name" : "robgrundel",
  "in_reply_to_user_id_str" : "32865573",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hari Vasupuram",
      "screen_name" : "hvasupuram",
      "indices" : [ 8, 19 ],
      "id_str" : "554407670",
      "id" : 554407670
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 21, 28 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417977014444773377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596431855, -122.2755782214 ]
  },
  "id_str" : "418034257110376448",
  "in_reply_to_user_id" : 554407670,
  "text" : "Yes! RT @hvasupuram: @buster Would it be more effective to stop setting goals and instead focus on the process?",
  "id" : 418034257110376448,
  "in_reply_to_status_id" : 417977014444773377,
  "created_at" : "2013-12-31 15:01:48 +0000",
  "in_reply_to_screen_name" : "hvasupuram",
  "in_reply_to_user_id_str" : "554407670",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 0, 7 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 8, 18 ],
      "id_str" : "125733",
      "id" : 125733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417928938241802241",
  "geo" : { },
  "id_str" : "417930219106729984",
  "in_reply_to_user_id" : 15727738,
  "text" : "@cwhogg @johnwrede Me too.",
  "id" : 417930219106729984,
  "in_reply_to_status_id" : 417928938241802241,
  "created_at" : "2013-12-31 08:08:23 +0000",
  "in_reply_to_screen_name" : "cwhogg",
  "in_reply_to_user_id_str" : "15727738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 0, 7 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 8, 18 ],
      "id_str" : "125733",
      "id" : 125733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417921245972144128",
  "geo" : { },
  "id_str" : "417927065560547328",
  "in_reply_to_user_id" : 15727738,
  "text" : "@cwhogg @johnwrede But isn't this just a new, more permanent form of naivet\u00E9, without the false confidence? :)",
  "id" : 417927065560547328,
  "in_reply_to_status_id" : 417921245972144128,
  "created_at" : "2013-12-31 07:55:51 +0000",
  "in_reply_to_screen_name" : "cwhogg",
  "in_reply_to_user_id_str" : "15727738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 0, 7 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417920321207803904",
  "geo" : { },
  "id_str" : "417920827019915264",
  "in_reply_to_user_id" : 15727738,
  "text" : "@cwhogg Totally. Does the meta-ness of that question also make your head explode?",
  "id" : 417920827019915264,
  "in_reply_to_status_id" : 417920321207803904,
  "created_at" : "2013-12-31 07:31:04 +0000",
  "in_reply_to_screen_name" : "cwhogg",
  "in_reply_to_user_id_str" : "15727738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 3, 7 ],
      "id_str" : "14616067",
      "id" : 14616067
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 9, 16 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417900434565525506",
  "text" : "RT @ltm: @buster how do I not lose interest after an unsuccessful day or week?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "417898305427734528",
    "geo" : { },
    "id_str" : "417900231942877184",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster how do I not lose interest after an unsuccessful day or week?",
    "id" : 417900231942877184,
    "in_reply_to_status_id" : 417898305427734528,
    "created_at" : "2013-12-31 06:09:14 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "protected" : false,
      "id_str" : "14616067",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000327820941\/98a12d185ff6963b8dc1c97e9a70b3d6_normal.jpeg",
      "id" : 14616067,
      "verified" : false
    }
  },
  "id" : 417900434565525506,
  "created_at" : "2013-12-31 06:10:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill S.",
      "screen_name" : "outseide",
      "indices" : [ 3, 12 ],
      "id_str" : "143694663",
      "id" : 143694663
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 14, 21 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417899734703947777",
  "text" : "RT @outseide: @buster why is information not enough to change behavior?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "417898305427734528",
    "geo" : { },
    "id_str" : "417899284017999872",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster why is information not enough to change behavior?",
    "id" : 417899284017999872,
    "in_reply_to_status_id" : 417898305427734528,
    "created_at" : "2013-12-31 06:05:28 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Jill S.",
      "screen_name" : "outseide",
      "protected" : false,
      "id_str" : "143694663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463770757353308161\/-GtAevlY_normal.jpeg",
      "id" : 143694663,
      "verified" : false
    }
  },
  "id" : 417899734703947777,
  "created_at" : "2013-12-31 06:07:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the daniel",
      "screen_name" : "thedaniel",
      "indices" : [ 0, 10 ],
      "id_str" : "2631",
      "id" : 2631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417899086977589249",
  "geo" : { },
  "id_str" : "417899181395546112",
  "in_reply_to_user_id" : 2631,
  "text" : "@thedaniel I'm on a 1 day streak at the moment. :)",
  "id" : 417899181395546112,
  "in_reply_to_status_id" : 417899086977589249,
  "created_at" : "2013-12-31 06:05:03 +0000",
  "in_reply_to_screen_name" : "thedaniel",
  "in_reply_to_user_id_str" : "2631",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 0, 10 ],
      "id_str" : "125733",
      "id" : 125733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417898958569340929",
  "geo" : { },
  "id_str" : "417899045953089536",
  "in_reply_to_user_id" : 125733,
  "text" : "@johnwrede Same.",
  "id" : 417899045953089536,
  "in_reply_to_status_id" : 417898958569340929,
  "created_at" : "2013-12-31 06:04:31 +0000",
  "in_reply_to_screen_name" : "JohnWrede",
  "in_reply_to_user_id_str" : "125733",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417898305427734528",
  "text" : "Writing a post about my updated thinking around habits, goals, and behavior change. What are your biggest unanswered questions?",
  "id" : 417898305427734528,
  "created_at" : "2013-12-31 06:01:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 0, 8 ],
      "id_str" : "14097392",
      "id" : 14097392
    }, {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 9, 18 ],
      "id_str" : "14417215",
      "id" : 14417215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417895410657542144",
  "geo" : { },
  "id_str" : "417895901202366464",
  "in_reply_to_user_id" : 14097392,
  "text" : "@nireyal @rrhoover I may ask for some extra eyes later tonight. We'll see how far I can get. :)",
  "id" : 417895901202366464,
  "in_reply_to_status_id" : 417895410657542144,
  "created_at" : "2013-12-31 05:52:01 +0000",
  "in_reply_to_screen_name" : "nireyal",
  "in_reply_to_user_id_str" : "14097392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 0, 8 ],
      "id_str" : "14097392",
      "id" : 14097392
    }, {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 9, 18 ],
      "id_str" : "14417215",
      "id" : 14417215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417889286323572736",
  "geo" : { },
  "id_str" : "417894779830038528",
  "in_reply_to_user_id" : 14097392,
  "text" : "@nireyal @rrhoover I've been trying to write a response to the year in behavior change stuff this week\u2026 it's having some trouble though.",
  "id" : 417894779830038528,
  "in_reply_to_status_id" : 417889286323572736,
  "created_at" : "2013-12-31 05:47:34 +0000",
  "in_reply_to_screen_name" : "nireyal",
  "in_reply_to_user_id_str" : "14097392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logan Bowers",
      "screen_name" : "loganb",
      "indices" : [ 0, 7 ],
      "id_str" : "6072622",
      "id" : 6072622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417874022202736641",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597339196, -122.2754188814 ]
  },
  "id_str" : "417888381641580544",
  "in_reply_to_user_id" : 6072622,
  "text" : "@loganb I'm guessing not without some dramz on the Twittersphere, however.",
  "id" : 417888381641580544,
  "in_reply_to_status_id" : 417874022202736641,
  "created_at" : "2013-12-31 05:22:08 +0000",
  "in_reply_to_screen_name" : "loganb",
  "in_reply_to_user_id_str" : "6072622",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/417888227941306368\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/jmwA89f3zp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcyjIQwCAAAChU8.jpg",
      "id_str" : "417888227769319424",
      "id" : 417888227769319424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcyjIQwCAAAChU8.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jmwA89f3zp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595268778, -122.2756606864 ]
  },
  "id_str" : "417888227941306368",
  "text" : "8:36pm Niko in his secret cardboard castle clubhouse http:\/\/t.co\/jmwA89f3zp",
  "id" : 417888227941306368,
  "created_at" : "2013-12-31 05:21:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 3, 12 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 142, 143 ],
      "url" : "http:\/\/t.co\/kXeBjGVfwy",
      "expanded_url" : "http:\/\/beekn.net\/2013\/12\/5-ux-predictions-for-ibeacons-2014\/",
      "display_url" : "beekn.net\/2013\/12\/5-ux-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417848683372085248",
  "text" : "RT @arainert: Exciting when relatively non-disruptive tech can create new + varied behaviors &gt; 5 UX Predictions for iBeacons in '14 http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/kXeBjGVfwy",
        "expanded_url" : "http:\/\/beekn.net\/2013\/12\/5-ux-predictions-for-ibeacons-2014\/",
        "display_url" : "beekn.net\/2013\/12\/5-ux-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "417838703159951360",
    "text" : "Exciting when relatively non-disruptive tech can create new + varied behaviors &gt; 5 UX Predictions for iBeacons in '14 http:\/\/t.co\/kXeBjGVfwy",
    "id" : 417838703159951360,
    "created_at" : "2013-12-31 02:04:44 +0000",
    "user" : {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "protected" : false,
      "id_str" : "7482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444089158274154496\/ZePPNQzQ_normal.jpeg",
      "id" : 7482,
      "verified" : false
    }
  },
  "id" : 417848683372085248,
  "created_at" : "2013-12-31 02:44:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417845000810938369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7991743768, -122.27717839 ]
  },
  "id_str" : "417845861834452992",
  "in_reply_to_user_id" : 2185,
  "text" : "@harryh Or just give a \"hide rates above $X\" option so one doesn't accidentally drunk Uber at a crazy rate. It's emotional not rational.",
  "id" : 417845861834452992,
  "in_reply_to_status_id" : 417845000810938369,
  "created_at" : "2013-12-31 02:33:11 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417842356700725248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8049264988, -122.295403937 ]
  },
  "id_str" : "417845000810938369",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh I'd have to conduct some user research but letting users suggest a surge price (with suggested rate) might make it better.",
  "id" : 417845000810938369,
  "in_reply_to_status_id" : 417842356700725248,
  "created_at" : "2013-12-31 02:29:46 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417799179600412672",
  "geo" : { },
  "id_str" : "417800124123709440",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Yeah, probably. Either way I think a few tweaks to the feature could disarm its tendency to emotionally trigger some people.",
  "id" : 417800124123709440,
  "in_reply_to_status_id" : 417799179600412672,
  "created_at" : "2013-12-30 23:31:26 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/yOJUnafKg1",
      "expanded_url" : "https:\/\/twitter.com\/buster\/status\/417797924601344000",
      "display_url" : "twitter.com\/buster\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "417797537571938304",
  "geo" : { },
  "id_str" : "417799061710716928",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm Ha. Uh oh: https:\/\/t.co\/yOJUnafKg1 The strategy is only bad because it assumes we're rational beings.",
  "id" : 417799061710716928,
  "in_reply_to_status_id" : 417797537571938304,
  "created_at" : "2013-12-30 23:27:13 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417797924601344000",
  "text" : "Uber is technically \"right\" &amp; \"rational\" to implement surge pricing, but continually tone deaf to the emotional side of the experience.",
  "id" : 417797924601344000,
  "created_at" : "2013-12-30 23:22:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417779409798430720",
  "geo" : { },
  "id_str" : "417779837630029824",
  "in_reply_to_user_id" : 2185,
  "text" : "@arainert Look at Jan 2013 and see how my morning routine morphed through the year into meditation then quality time tracking.",
  "id" : 417779837630029824,
  "in_reply_to_status_id" : 417779409798430720,
  "created_at" : "2013-12-30 22:10:49 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/imxvpkpfen",
      "expanded_url" : "https:\/\/github.com\/busterbenson\/public\/blob\/master\/ReviewEveryMonth.md",
      "display_url" : "github.com\/busterbenson\/p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "417779102041391104",
  "geo" : { },
  "id_str" : "417779409798430720",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert It went well! I stayed focused on it throughout the full year and learned a lot. Tracking it here: https:\/\/t.co\/imxvpkpfen",
  "id" : 417779409798430720,
  "in_reply_to_status_id" : 417779102041391104,
  "created_at" : "2013-12-30 22:09:07 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417776311323480064",
  "geo" : { },
  "id_str" : "417778336601886720",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert I did something similar in 2013\u2026 month long resolutions that were edited on the 1st of each month based on the previous month.",
  "id" : 417778336601886720,
  "in_reply_to_status_id" : 417776311323480064,
  "created_at" : "2013-12-30 22:04:52 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radiolab",
      "screen_name" : "Radiolab",
      "indices" : [ 33, 42 ],
      "id_str" : "28583197",
      "id" : 28583197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/9QQQ8AInD5",
      "expanded_url" : "http:\/\/radiolab.org\/support",
      "display_url" : "radiolab.org\/support"
    } ]
  },
  "in_reply_to_status_id_str" : "417773097140629504",
  "geo" : { },
  "id_str" : "417773671227215872",
  "in_reply_to_user_id" : 28583197,
  "text" : "Finally got around to supporting @Radiolab, my fave podcast by far: http:\/\/t.co\/9QQQ8AInD5",
  "id" : 417773671227215872,
  "in_reply_to_status_id" : 417773097140629504,
  "created_at" : "2013-12-30 21:46:19 +0000",
  "in_reply_to_screen_name" : "Radiolab",
  "in_reply_to_user_id_str" : "28583197",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Information",
      "screen_name" : "theinformation",
      "indices" : [ 17, 32 ],
      "id_str" : "1881168794",
      "id" : 1881168794
    }, {
      "name" : "Michael Arrington",
      "screen_name" : "arrington",
      "indices" : [ 59, 69 ],
      "id_str" : "37570179",
      "id" : 37570179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/mrdzroF1ZL",
      "expanded_url" : "http:\/\/wp.me\/p1RmvN-xf",
      "display_url" : "wp.me\/p1RmvN-xf"
    } ]
  },
  "in_reply_to_status_id_str" : "417771081970106368",
  "geo" : { },
  "id_str" : "417773136617021440",
  "in_reply_to_user_id" : 37570179,
  "text" : "Terrible move by @theinformation right out of the gate. RT @arrington: The Disinformation: http:\/\/t.co\/mrdzroF1ZL",
  "id" : 417773136617021440,
  "in_reply_to_status_id" : 417771081970106368,
  "created_at" : "2013-12-30 21:44:12 +0000",
  "in_reply_to_screen_name" : "arrington",
  "in_reply_to_user_id_str" : "37570179",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 24, 36 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/KVxr5hItmA",
      "expanded_url" : "https:\/\/medium.com\/changers-interviews\/9f3a89d600f8",
      "display_url" : "medium.com\/changers-inter\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417713116848209920",
  "text" : "An interview with me by @nickcrocker, who asked a bunch of interesting questions about behavior change: https:\/\/t.co\/KVxr5hItmA",
  "id" : 417713116848209920,
  "created_at" : "2013-12-30 17:45:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/OAePcYQbbn",
      "expanded_url" : "http:\/\/www.nytimes.com\/news\/the-lives-they-lived\/2013\/12\/21\/joy-johnson\/",
      "display_url" : "nytimes.com\/news\/the-lives\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764139055, -122.4167081058 ]
  },
  "id_str" : "417711635109658624",
  "text" : "Run in peace, Joy Johnson. http:\/\/t.co\/OAePcYQbbn",
  "id" : 417711635109658624,
  "created_at" : "2013-12-30 17:39:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mat honan",
      "screen_name" : "mat",
      "indices" : [ 3, 7 ],
      "id_str" : "11113",
      "id" : 11113
    }, {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 127, 136 ],
      "id_str" : "817386",
      "id" : 817386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/g2GygCcZRS",
      "expanded_url" : "http:\/\/www.wired.com\/gadgetlab\/2013\/12\/glasshole\/",
      "display_url" : "wired.com\/gadgetlab\/2013\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417676484451377153",
  "text" : "RT @mat: I wrote a long-ish thing looking back on my year with Glass. You can read it on your face: http:\/\/t.co\/g2GygCcZRS tip @techmeme",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Techmeme",
        "screen_name" : "Techmeme",
        "indices" : [ 118, 127 ],
        "id_str" : "817386",
        "id" : 817386
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/g2GygCcZRS",
        "expanded_url" : "http:\/\/www.wired.com\/gadgetlab\/2013\/12\/glasshole\/",
        "display_url" : "wired.com\/gadgetlab\/2013\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "417673837241569281",
    "text" : "I wrote a long-ish thing looking back on my year with Glass. You can read it on your face: http:\/\/t.co\/g2GygCcZRS tip @techmeme",
    "id" : 417673837241569281,
    "created_at" : "2013-12-30 15:09:37 +0000",
    "user" : {
      "name" : "mat honan",
      "screen_name" : "mat",
      "protected" : false,
      "id_str" : "11113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432654572876619776\/oF1EKBOV_normal.jpeg",
      "id" : 11113,
      "verified" : true
    }
  },
  "id" : 417676484451377153,
  "created_at" : "2013-12-30 15:20:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    }, {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 15, 24 ],
      "id_str" : "2391",
      "id" : 2391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417547235551768576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596831672, -122.2754684185 ]
  },
  "id_str" : "417548300397457409",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover From @mulegirl in Just Enough Research. Hooked quoted it and reminded me that I needed to read it. :)",
  "id" : 417548300397457409,
  "in_reply_to_status_id" : 417547235551768576,
  "created_at" : "2013-12-30 06:50:47 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 107, 116 ],
      "id_str" : "2391",
      "id" : 2391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417547907089174529",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595803727, -122.2755499196 ]
  },
  "id_str" : "417548079101771776",
  "in_reply_to_user_id" : 2185,
  "text" : "\"Quash all liking, and hating too. Plenty of people habitually engage in activities they claim to hate.\" - @mulegirl in Just Enough Research",
  "id" : 417548079101771776,
  "in_reply_to_status_id" : 417547907089174529,
  "created_at" : "2013-12-30 06:49:54 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417547347367706626",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595754647, -122.2755296479 ]
  },
  "id_str" : "417547907089174529",
  "in_reply_to_user_id" : 2185,
  "text" : "\"I like horses but I'm not going to buy any online.\"",
  "id" : 417547907089174529,
  "in_reply_to_status_id" : 417547347367706626,
  "created_at" : "2013-12-30 06:49:13 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417547011999547394",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859658451, -122.2755714917 ]
  },
  "id_str" : "417547347367706626",
  "in_reply_to_user_id" : 2185,
  "text" : "\"You can't get any useful insights from any given individual reporting that they like or hate a particular thing.\"",
  "id" : 417547347367706626,
  "in_reply_to_status_id" : 417547011999547394,
  "created_at" : "2013-12-30 06:46:59 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595637968, -122.2756549265 ]
  },
  "id_str" : "417547011999547394",
  "text" : "\"The concept of 'liking' is as subjective as it is empty. It's a superficial mental state unmoored from any particular behavior.\"",
  "id" : 417547011999547394,
  "created_at" : "2013-12-30 06:45:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    }, {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 10, 18 ],
      "id_str" : "14097392",
      "id" : 14097392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417537196975869952",
  "geo" : { },
  "id_str" : "417537642318680064",
  "in_reply_to_user_id" : 2185,
  "text" : "@rrhoover @nireyal I have a group of 6 people gambling on next billion dollar companies in a similar vein. It's the only way to validate.",
  "id" : 417537642318680064,
  "in_reply_to_status_id" : 417537196975869952,
  "created_at" : "2013-12-30 06:08:26 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    }, {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 10, 18 ],
      "id_str" : "14097392",
      "id" : 14097392
    }, {
      "name" : "Product Hunt",
      "screen_name" : "producthunt",
      "indices" : [ 39, 51 ],
      "id_str" : "2208027565",
      "id" : 2208027565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417535176403472386",
  "geo" : { },
  "id_str" : "417537196975869952",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover @nireyal Feature request for @producthunt: let us predict future monthly active users (perhaps based on adherence to Hook Model).",
  "id" : 417537196975869952,
  "in_reply_to_status_id" : 417535176403472386,
  "created_at" : "2013-12-30 06:06:39 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 0, 8 ],
      "id_str" : "14097392",
      "id" : 14097392
    }, {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 9, 18 ],
      "id_str" : "14417215",
      "id" : 14417215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417533678768500736",
  "geo" : { },
  "id_str" : "417533867768025088",
  "in_reply_to_user_id" : 2185,
  "text" : "@nireyal @rrhoover My fave chapter was the case study of the bible app. I would've loved to see a couple more deep dives like that.",
  "id" : 417533867768025088,
  "in_reply_to_status_id" : 417533678768500736,
  "created_at" : "2013-12-30 05:53:26 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 0, 8 ],
      "id_str" : "14097392",
      "id" : 14097392
    }, {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 9, 18 ],
      "id_str" : "14417215",
      "id" : 14417215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416255603313344512",
  "geo" : { },
  "id_str" : "417533678768500736",
  "in_reply_to_user_id" : 14097392,
  "text" : "@nireyal @rrhoover Just finished. Fun read and good synthesis of many of the latest thoughts on behavior change.",
  "id" : 417533678768500736,
  "in_reply_to_status_id" : 416255603313344512,
  "created_at" : "2013-12-30 05:52:41 +0000",
  "in_reply_to_screen_name" : "nireyal",
  "in_reply_to_user_id_str" : "14097392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 18, 28 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/417515165471371264\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/b4u7uagz2T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BctP1KlCUAAU7oh.jpg",
      "id_str" : "417515165253259264",
      "id" : 417515165253259264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BctP1KlCUAAU7oh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/b4u7uagz2T"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596463899, -122.2755614212 ]
  },
  "id_str" : "417515165471371264",
  "text" : "8:36pm Niko likes @Kellianne's new record player http:\/\/t.co\/b4u7uagz2T",
  "id" : 417515165471371264,
  "created_at" : "2013-12-30 04:39:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/cyiGS3xMkE",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=TM8L7bdwVaA&sns=tw",
      "display_url" : "youtube.com\/watch?v=TM8L7b\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596654395, -122.2755048798 ]
  },
  "id_str" : "417500063674667008",
  "text" : "The call to action this season: \"It's okay, you can admit it. If you bought an item or 2 or 10 for yourself...\" http:\/\/t.co\/cyiGS3xMkE",
  "id" : 417500063674667008,
  "created_at" : "2013-12-30 03:39:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vizify",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/gZMYgBFVOe",
      "expanded_url" : "https:\/\/www.vizify.com\/buster-benson\/twitter-video",
      "display_url" : "vizify.com\/buster-benson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417366734467633152",
  "text" : "My 2013 summary on Twitter includes me teaching Niko how to pour wine https:\/\/t.co\/gZMYgBFVOe #vizify",
  "id" : 417366734467633152,
  "created_at" : "2013-12-29 18:49:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417364863048888320",
  "geo" : { },
  "id_str" : "417365142079164416",
  "in_reply_to_user_id" : 2185,
  "text" : "@arainert But he also loves all things Toca Boca, Sagu Mini, Endless ABC, YouTube, Netflix, and also loves stickers in Facebook Messenger.",
  "id" : 417365142079164416,
  "in_reply_to_status_id" : 417364863048888320,
  "created_at" : "2013-12-29 18:42:58 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417296362200641536",
  "geo" : { },
  "id_str" : "417364863048888320",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert He\u2019s currently obsessed with learning how to do two-handed joystick-style controls on Paper Monsters.",
  "id" : 417364863048888320,
  "in_reply_to_status_id" : 417296362200641536,
  "created_at" : "2013-12-29 18:41:52 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417173252985720832",
  "geo" : { },
  "id_str" : "417174178517639168",
  "in_reply_to_user_id" : 2185,
  "text" : "And apparently the iPad likes its photos upside-down.",
  "id" : 417174178517639168,
  "in_reply_to_status_id" : 417173252985720832,
  "created_at" : "2013-12-29 06:04:09 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/417173252985720832\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/t8M6XFRKe9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcoY3QKCEAAO-25.jpg",
      "id_str" : "417173252994109440",
      "id" : 417173252994109440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcoY3QKCEAAO-25.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/t8M6XFRKe9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417173252985720832",
  "text" : "8:36pm Just arrived back home from Irvine. My iPhone somehow died so posting this with the iPad Mini Santa gave Niko. http:\/\/t.co\/t8M6XFRKe9",
  "id" : 417173252985720832,
  "created_at" : "2013-12-29 06:00:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417100957588021249",
  "geo" : { },
  "id_str" : "417172790752444416",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake Oh man. I hope she still has the receipt. :)",
  "id" : 417172790752444416,
  "in_reply_to_status_id" : 417100957588021249,
  "created_at" : "2013-12-29 05:58:38 +0000",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/416795374896951297\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/ww4dleeFqM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcjBL12CIAAAKDd.jpg",
      "id_str" : "416795374708203520",
      "id" : 416795374708203520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcjBL12CIAAAKDd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ww4dleeFqM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.7470603457, -117.8694622709 ]
  },
  "id_str" : "416795374896951297",
  "text" : "8:36pm Niko reunited with his girlfriend, Lily. http:\/\/t.co\/ww4dleeFqM",
  "id" : 416795374896951297,
  "created_at" : "2013-12-28 04:58:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416722929829695488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6295825197, -117.8623616976 ]
  },
  "id_str" : "416727494864027648",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Me!",
  "id" : 416727494864027648,
  "in_reply_to_status_id" : 416722929829695488,
  "created_at" : "2013-12-28 00:29:11 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/416718016517140480\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/tOnScUKHwa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bch60-GCQAALzlg.jpg",
      "id_str" : "416718015971868672",
      "id" : 416718015971868672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bch60-GCQAALzlg.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tOnScUKHwa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.5928549059, -117.8765286227 ]
  },
  "id_str" : "416718016517140480",
  "text" : "Rode our bikes to the beach for a quick selfie http:\/\/t.co\/tOnScUKHwa",
  "id" : 416718016517140480,
  "created_at" : "2013-12-27 23:51:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Franco",
      "screen_name" : "JamesFrancoTV",
      "indices" : [ 29, 43 ],
      "id_str" : "436292177",
      "id" : 436292177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/300otem03h",
      "expanded_url" : "http:\/\/nyti.ms\/1eGDZjO",
      "display_url" : "nyti.ms\/1eGDZjO"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6671753135, -117.7949843557 ]
  },
  "id_str" : "416601227917393920",
  "text" : "Words of strange wisdom from @JamesFrancoTV on the art of the selfie http:\/\/t.co\/300otem03h",
  "id" : 416601227917393920,
  "created_at" : "2013-12-27 16:07:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/416429343020052481\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/xHFdxpg4WH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bcd0R_ACcAAoelN.jpg",
      "id_str" : "416429342873251840",
      "id" : 416429342873251840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bcd0R_ACcAAoelN.jpg",
      "sizes" : [ {
        "h" : 1023,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1023,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 599,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xHFdxpg4WH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416423066260865024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.0573213902, -117.1883820837 ]
  },
  "id_str" : "416429343020052481",
  "in_reply_to_user_id" : 2185,
  "text" : "8:36pm Finishing up kaiseki dinner with the fam http:\/\/t.co\/xHFdxpg4WH",
  "id" : 416429343020052481,
  "in_reply_to_status_id" : 416423066260865024,
  "created_at" : "2013-12-27 04:44:26 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/416423066260865024\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/e9HmmzsJtp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcdukmxCQAASxAn.jpg",
      "id_str" : "416423065715621888",
      "id" : 416423065715621888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcdukmxCQAASxAn.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/e9HmmzsJtp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416420714606891008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.0572008165, -117.188439835 ]
  },
  "id_str" : "416423066260865024",
  "in_reply_to_user_id" : 2185,
  "text" : "Toro roll http:\/\/t.co\/e9HmmzsJtp",
  "id" : 416423066260865024,
  "in_reply_to_status_id" : 416420714606891008,
  "created_at" : "2013-12-27 04:19:30 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/416420714606891008\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/iJLvabl4wO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcdsbvbCEAAp7xJ.jpg",
      "id_str" : "416420714397175808",
      "id" : 416420714397175808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcdsbvbCEAAp7xJ.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iJLvabl4wO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416416008664924160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.057307099, -117.1884084867 ]
  },
  "id_str" : "416420714606891008",
  "in_reply_to_user_id" : 2185,
  "text" : "Lobster croquette salad http:\/\/t.co\/iJLvabl4wO",
  "id" : 416420714606891008,
  "in_reply_to_status_id" : 416416008664924160,
  "created_at" : "2013-12-27 04:10:09 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/416416008664924160\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/1U6cQ1tPrR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcdoJ0xCAAAhVoP.jpg",
      "id_str" : "416416008547467264",
      "id" : 416416008547467264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcdoJ0xCAAAhVoP.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1U6cQ1tPrR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416414912412266496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.0572373197, -117.1884519049 ]
  },
  "id_str" : "416416008664924160",
  "in_reply_to_user_id" : 2185,
  "text" : "Uni risotto http:\/\/t.co\/1U6cQ1tPrR",
  "id" : 416416008664924160,
  "in_reply_to_status_id" : 416414912412266496,
  "created_at" : "2013-12-27 03:51:27 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/416414912412266496\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Qqvw9YTcKh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcdnKA0CIAACATl.jpg",
      "id_str" : "416414912269656064",
      "id" : 416414912269656064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcdnKA0CIAACATl.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Qqvw9YTcKh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416411231860191232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.0572606214, -117.1884088219 ]
  },
  "id_str" : "416414912412266496",
  "in_reply_to_user_id" : 2185,
  "text" : "http:\/\/t.co\/Qqvw9YTcKh",
  "id" : 416414912412266496,
  "in_reply_to_status_id" : 416411231860191232,
  "created_at" : "2013-12-27 03:47:06 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Pepper",
      "screen_name" : "noahmp",
      "indices" : [ 0, 7 ],
      "id_str" : "20219699",
      "id" : 20219699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416411035004715008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.0571961974, -117.1881379061 ]
  },
  "id_str" : "416412835078344704",
  "in_reply_to_user_id" : 20219699,
  "text" : "@noahmp I will! It's a hidden gem. Come by if you're ever in the area.",
  "id" : 416412835078344704,
  "in_reply_to_status_id" : 416411035004715008,
  "created_at" : "2013-12-27 03:38:51 +0000",
  "in_reply_to_screen_name" : "noahmp",
  "in_reply_to_user_id_str" : "20219699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/416411231860191232\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VeP17KKNCj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcdjzxhCQAAt38z.jpg",
      "id_str" : "416411231671435264",
      "id" : 416411231671435264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcdjzxhCQAAt38z.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VeP17KKNCj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416410565842452480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.0572201787, -117.1884439421 ]
  },
  "id_str" : "416411231860191232",
  "in_reply_to_user_id" : 2185,
  "text" : "http:\/\/t.co\/VeP17KKNCj",
  "id" : 416411231860191232,
  "in_reply_to_status_id" : 416410565842452480,
  "created_at" : "2013-12-27 03:32:28 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Pepper",
      "screen_name" : "noahmp",
      "indices" : [ 0, 7 ],
      "id_str" : "20219699",
      "id" : 20219699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416410120151502848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.057226968, -117.1884604545 ]
  },
  "id_str" : "416410756200943616",
  "in_reply_to_user_id" : 20219699,
  "text" : "@noahmp At my mom's restaurant called Kimo Sushi in Redlands.",
  "id" : 416410756200943616,
  "in_reply_to_status_id" : 416410120151502848,
  "created_at" : "2013-12-27 03:30:35 +0000",
  "in_reply_to_screen_name" : "noahmp",
  "in_reply_to_user_id_str" : "20219699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/416410565842452480\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QNaeEXkGcr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcdjNAaCMAAmCbr.jpg",
      "id_str" : "416410565653704704",
      "id" : 416410565653704704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcdjNAaCMAAmCbr.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QNaeEXkGcr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416409086008127488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.057226968, -117.1884604545 ]
  },
  "id_str" : "416410565842452480",
  "in_reply_to_user_id" : 2185,
  "text" : "http:\/\/t.co\/QNaeEXkGcr",
  "id" : 416410565842452480,
  "in_reply_to_status_id" : 416409086008127488,
  "created_at" : "2013-12-27 03:29:50 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/416409086008127488\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NQaPFPhVSF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bcdh23XCAAA7Qvq.jpg",
      "id_str" : "416409085756440576",
      "id" : 416409085756440576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bcdh23XCAAA7Qvq.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NQaPFPhVSF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416407649962315776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.0572434804, -117.1884311178 ]
  },
  "id_str" : "416409086008127488",
  "in_reply_to_user_id" : 2185,
  "text" : "http:\/\/t.co\/NQaPFPhVSF",
  "id" : 416409086008127488,
  "in_reply_to_status_id" : 416407649962315776,
  "created_at" : "2013-12-27 03:23:57 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/416407649962315776\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/U35vMmPpvN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcdgjRtCIAALYl2.jpg",
      "id_str" : "416407649719033856",
      "id" : 416407649719033856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcdgjRtCIAALYl2.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/U35vMmPpvN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416405769295110144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.0572057199, -117.1884997656 ]
  },
  "id_str" : "416407649962315776",
  "in_reply_to_user_id" : 2185,
  "text" : "http:\/\/t.co\/U35vMmPpvN",
  "id" : 416407649962315776,
  "in_reply_to_status_id" : 416405769295110144,
  "created_at" : "2013-12-27 03:18:14 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/416405769295110144\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/7L6PllloYh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bcde1yPCUAAt1v0.jpg",
      "id_str" : "416405768665976832",
      "id" : 416405768665976832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bcde1yPCUAAt1v0.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7L6PllloYh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416403381671186432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.0572902514, -117.188449558 ]
  },
  "id_str" : "416405769295110144",
  "in_reply_to_user_id" : 2185,
  "text" : "http:\/\/t.co\/7L6PllloYh",
  "id" : 416405769295110144,
  "in_reply_to_status_id" : 416403381671186432,
  "created_at" : "2013-12-27 03:10:46 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 37, 47 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/Q7jR3LqREG",
      "expanded_url" : "http:\/\/4sq.com\/1cDcc21",
      "display_url" : "4sq.com\/1cDcc21"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.0572169667, -117.188408 ]
  },
  "id_str" : "416403381671186432",
  "text" : "At Mom's restaurant (@ Sushi Kimo w\/ @kellianne) [pic]: http:\/\/t.co\/Q7jR3LqREG",
  "id" : 416403381671186432,
  "created_at" : "2013-12-27 03:01:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    }, {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 10, 18 ],
      "id_str" : "14097392",
      "id" : 14097392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416237201169473536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6672731389, -117.7951942099 ]
  },
  "id_str" : "416237428861452291",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover @nireyal I'll add notes as I read and share when I'm done!",
  "id" : 416237428861452291,
  "in_reply_to_status_id" : 416237201169473536,
  "created_at" : "2013-12-26 16:01:51 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    }, {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 10, 18 ],
      "id_str" : "14097392",
      "id" : 14097392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416234669039190016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6671995419, -117.7951883772 ]
  },
  "id_str" : "416236298035138560",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover @nireyal Bought it! Looking forward to reading it.",
  "id" : 416236298035138560,
  "in_reply_to_status_id" : 416234669039190016,
  "created_at" : "2013-12-26 15:57:21 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aurelia Cotta",
      "screen_name" : "AureliaCotta",
      "indices" : [ 0, 13 ],
      "id_str" : "19055125",
      "id" : 19055125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416074212801925120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6672601036, -117.7952267222 ]
  },
  "id_str" : "416075880406872065",
  "in_reply_to_user_id" : 19055125,
  "text" : "@AureliaCotta I believe it. All of my memories of it working are probably from commercials.",
  "id" : 416075880406872065,
  "in_reply_to_status_id" : 416074212801925120,
  "created_at" : "2013-12-26 05:19:54 +0000",
  "in_reply_to_screen_name" : "AureliaCotta",
  "in_reply_to_user_id_str" : "19055125",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6672856777, -117.7952402232 ]
  },
  "id_str" : "416071566879756289",
  "text" : "Have slinkies gotten worse at going down stairs since I was a kid or have my expectations gone up?",
  "id" : 416071566879756289,
  "created_at" : "2013-12-26 05:02:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/416070586805129216\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/s3F44huRTv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcYt_oFCQAABdyV.jpg",
      "id_str" : "416070586691895296",
      "id" : 416070586691895296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcYt_oFCQAABdyV.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/s3F44huRTv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6672917317, -117.7952754587 ]
  },
  "id_str" : "416070586805129216",
  "text" : "8:36pm Getting repeatedly tackled by a 40 pound 3 year old and a 70 pound pit bull. Countdown to tears: 3.. 2.. 1.. http:\/\/t.co\/s3F44huRTv",
  "id" : 416070586805129216,
  "created_at" : "2013-12-26 04:58:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/416028784244977665\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/sUduvh7Xsg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcYH-ZPCAAA88bJ.jpg",
      "id_str" : "416028784085565440",
      "id" : 416028784085565440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcYH-ZPCAAA88bJ.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sUduvh7Xsg"
    } ],
    "hashtags" : [ {
      "text" : "achristmasstory",
      "indices" : [ 58, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6672756031, -117.7952473806 ]
  },
  "id_str" : "416028784244977665",
  "text" : "Kellianne and Niko get comfortable for another viewing of #achristmasstory http:\/\/t.co\/sUduvh7Xsg",
  "id" : 416028784244977665,
  "created_at" : "2013-12-26 02:12:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nostaligia",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415961699368583168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6672567751, -117.7952140927 ]
  },
  "id_str" : "415973051415547904",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc What happened to the days when we just complained about people taking photos of the band? #nostaligia ps congrats!",
  "id" : 415973051415547904,
  "in_reply_to_status_id" : 415961699368583168,
  "created_at" : "2013-12-25 22:31:18 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/LKfnPSPtea",
      "expanded_url" : "https:\/\/vine.co\/v\/h97iwTJDBUU",
      "display_url" : "vine.co\/v\/h97iwTJDBUU"
    } ]
  },
  "geo" : { },
  "id_str" : "415922011035414528",
  "text" : "Niko's 2nd favorite gift https:\/\/t.co\/LKfnPSPtea",
  "id" : 415922011035414528,
  "created_at" : "2013-12-25 19:08:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/ZWrTCNpbs5",
      "expanded_url" : "https:\/\/vine.co\/v\/h9WlXF6FmQ5",
      "display_url" : "vine.co\/v\/h9WlXF6FmQ5"
    } ]
  },
  "geo" : { },
  "id_str" : "415910454612226048",
  "text" : "Niko's favorite gift https:\/\/t.co\/ZWrTCNpbs5",
  "id" : 415910454612226048,
  "created_at" : "2013-12-25 18:22:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/415771149151117313\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/YRbIZ0sGE1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcUdqDVCQAAcDrG.jpg",
      "id_str" : "415771148886884352",
      "id" : 415771148886884352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcUdqDVCQAAcDrG.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/YRbIZ0sGE1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6672498286, -117.7951431089 ]
  },
  "id_str" : "415771149151117313",
  "text" : "Santa signature turquoise unicorn http:\/\/t.co\/YRbIZ0sGE1",
  "id" : 415771149151117313,
  "created_at" : "2013-12-25 09:09:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6672697121, -117.795246517 ]
  },
  "id_str" : "415764706649845760",
  "text" : "I think 3.5 might be the perfect age for Christmas. Close second is however old you are when you have a 3.5 year old.",
  "id" : 415764706649845760,
  "created_at" : "2013-12-25 08:43:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/415743088930193408\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/zt97Oo14g4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcUEIvICMAAu1Ib.jpg",
      "id_str" : "415743088737267712",
      "id" : 415743088737267712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcUEIvICMAAu1Ib.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zt97Oo14g4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6672861323, -117.7952632281 ]
  },
  "id_str" : "415743088930193408",
  "text" : "8:36pm Traditional reading of The Night Before Christmas in Ryan's special reader voice http:\/\/t.co\/zt97Oo14g4",
  "id" : 415743088930193408,
  "created_at" : "2013-12-25 07:17:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415660036283568128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6670800632, -117.7952420989 ]
  },
  "id_str" : "415671470363136000",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin My eventual (but too late) answer is that technology doesn't appear out of nowhere. It needs time to grow.",
  "id" : 415671470363136000,
  "in_reply_to_status_id" : 415660036283568128,
  "created_at" : "2013-12-25 02:32:55 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415640940758323200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.667302027, -117.7952280741 ]
  },
  "id_str" : "415641103312769024",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley We're listening to it at this very moment, thanks!",
  "id" : 415641103312769024,
  "in_reply_to_status_id" : 415640940758323200,
  "created_at" : "2013-12-25 00:32:15 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6671875511, -117.7951863595 ]
  },
  "id_str" : "415634317478359040",
  "text" : "First question from my right-leaning grandpa: \"So what do you think of that Obamacare website?\" Forgot to prep for this.",
  "id" : 415634317478359040,
  "created_at" : "2013-12-25 00:05:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 0, 7 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415533949666852864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6690104846, -117.7855602869 ]
  },
  "id_str" : "415561659550539776",
  "in_reply_to_user_id" : 15727738,
  "text" : "@cwhogg I totally agree and hope people start to take advantage of this!",
  "id" : 415561659550539776,
  "in_reply_to_status_id" : 415533949666852864,
  "created_at" : "2013-12-24 19:16:35 +0000",
  "in_reply_to_screen_name" : "cwhogg",
  "in_reply_to_user_id_str" : "15727738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prashant S",
      "screen_name" : "CoolAssPuppy",
      "indices" : [ 0, 13 ],
      "id_str" : "2881611",
      "id" : 2881611
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 56, 63 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/u6MOYoubMp",
      "expanded_url" : "http:\/\/dcurt.is\/the-best",
      "display_url" : "dcurt.is\/the-best"
    } ]
  },
  "in_reply_to_status_id_str" : "415395308713938944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6672374653, -117.7950913926 ]
  },
  "id_str" : "415533173770960896",
  "in_reply_to_user_id" : 2881611,
  "text" : "@CoolAssPuppy You should post the list of 200 things to @github and track changes over time! Also have you read http:\/\/t.co\/u6MOYoubMp",
  "id" : 415533173770960896,
  "in_reply_to_status_id" : 415395308713938944,
  "created_at" : "2013-12-24 17:23:23 +0000",
  "in_reply_to_screen_name" : "CoolAssPuppy",
  "in_reply_to_user_id_str" : "2881611",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Pepper",
      "screen_name" : "noahmp",
      "indices" : [ 13, 20 ],
      "id_str" : "20219699",
      "id" : 20219699
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/noahmp\/status\/415527715589349376\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/pennIdFAGg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcRAQXXIgAA0NOu.png",
      "id_str" : "415527715518054400",
      "id" : 415527715518054400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcRAQXXIgAA0NOu.png",
      "sizes" : [ {
        "h" : 210,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 822
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 822
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/pennIdFAGg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415527715589349376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6671312822, -117.795190256 ]
  },
  "id_str" : "415529220354211840",
  "in_reply_to_user_id" : 20219699,
  "text" : "Such doge RT @noahmp: 2013 year in review: http:\/\/t.co\/pennIdFAGg",
  "id" : 415529220354211840,
  "in_reply_to_status_id" : 415527715589349376,
  "created_at" : "2013-12-24 17:07:40 +0000",
  "in_reply_to_screen_name" : "noahmp",
  "in_reply_to_user_id_str" : "20219699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/415292468284751873\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/k5GHSbg8VJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcNqTKFCIAECsPj.jpg",
      "id_str" : "415292468003741697",
      "id" : 415292468003741697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcNqTKFCIAECsPj.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/k5GHSbg8VJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415289493826973696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.8878904265, -120.8001593315 ]
  },
  "id_str" : "415292468284751873",
  "in_reply_to_user_id" : 2185,
  "text" : "http:\/\/t.co\/k5GHSbg8VJ",
  "id" : 415292468284751873,
  "in_reply_to_status_id" : 415289493826973696,
  "created_at" : "2013-12-24 01:26:54 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lj4eva",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415290222659002368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.9815011975, -120.8992151545 ]
  },
  "id_str" : "415290566432145408",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Do you have one? What are the good ones? #lj4eva",
  "id" : 415290566432145408,
  "in_reply_to_status_id" : 415290222659002368,
  "created_at" : "2013-12-24 01:19:21 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415289948401451008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.9973137416, -120.9129412753 ]
  },
  "id_str" : "415290336701739009",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin We'll probably still be one the road. Are you going up or down?",
  "id" : 415290336701739009,
  "in_reply_to_status_id" : 415289948401451008,
  "created_at" : "2013-12-24 01:18:26 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/415289493826973696\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/v5h0Ru4muJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcNnmB1CcAAlzga.jpg",
      "id_str" : "415289493671800832",
      "id" : 415289493671800832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcNnmB1CcAAlzga.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/v5h0Ru4muJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415288069990780928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.0324608218, -120.9466284794 ]
  },
  "id_str" : "415289493826973696",
  "in_reply_to_user_id" : 2185,
  "text" : "http:\/\/t.co\/v5h0Ru4muJ",
  "id" : 415289493826973696,
  "in_reply_to_status_id" : 415288069990780928,
  "created_at" : "2013-12-24 01:15:05 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415267179622174720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.0646642195, -120.9777835944 ]
  },
  "id_str" : "415289121678962688",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin What time will you be flying over? Let's synchronize our watches and photo tweet it.",
  "id" : 415289121678962688,
  "in_reply_to_status_id" : 415267179622174720,
  "created_at" : "2013-12-24 01:13:36 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/415288069990780928\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/sxip8AZb7i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcNmTJkCYAAWIk3.jpg",
      "id_str" : "415288069818834944",
      "id" : 415288069818834944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcNmTJkCYAAWIk3.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sxip8AZb7i"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415283164462845953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.1082028002, -121.0176110455 ]
  },
  "id_str" : "415288069990780928",
  "in_reply_to_user_id" : 2185,
  "text" : "http:\/\/t.co\/sxip8AZb7i",
  "id" : 415288069990780928,
  "in_reply_to_status_id" : 415283164462845953,
  "created_at" : "2013-12-24 01:09:26 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/415283164462845953\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/KboWKc8JdO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcNh1nVCAAA3NCp.jpg",
      "id_str" : "415283164366372864",
      "id" : 415283164366372864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcNh1nVCAAA3NCp.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KboWKc8JdO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415277755882672128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.4125286239, -121.1488618423 ]
  },
  "id_str" : "415283164462845953",
  "in_reply_to_user_id" : 2185,
  "text" : "http:\/\/t.co\/KboWKc8JdO",
  "id" : 415283164462845953,
  "in_reply_to_status_id" : 415277755882672128,
  "created_at" : "2013-12-24 00:49:56 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/415277755882672128\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/4qWdSe1gRM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcNc6ySCIAAfYxM.jpg",
      "id_str" : "415277755647795200",
      "id" : 415277755647795200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcNc6ySCIAAfYxM.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4qWdSe1gRM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415272576693202944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6641037781, -121.4441685287 ]
  },
  "id_str" : "415277755882672128",
  "in_reply_to_user_id" : 2185,
  "text" : "http:\/\/t.co\/4qWdSe1gRM",
  "id" : 415277755882672128,
  "in_reply_to_status_id" : 415272576693202944,
  "created_at" : "2013-12-24 00:28:27 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Weil",
      "screen_name" : "kevinweil",
      "indices" : [ 0, 10 ],
      "id_str" : "3452911",
      "id" : 3452911
    }, {
      "name" : "Automatic ",
      "screen_name" : "automatic",
      "indices" : [ 11, 21 ],
      "id_str" : "618542623",
      "id" : 618542623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415273886029062145",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7435015235, -121.5505964869 ]
  },
  "id_str" : "415274402956062720",
  "in_reply_to_user_id" : 3452911,
  "text" : "@kevinweil @automatic It was tempting given that we have our bikes on a rack in back. The next 350 miles might've been a doozy though.",
  "id" : 415274402956062720,
  "in_reply_to_status_id" : 415273886029062145,
  "created_at" : "2013-12-24 00:15:07 +0000",
  "in_reply_to_screen_name" : "kevinweil",
  "in_reply_to_user_id_str" : "3452911",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 10, 20 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415271202673139712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7416355862, -121.5762937256 ]
  },
  "id_str" : "415273778914947073",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @ingopixel How can Napa not be on that list? \uD83C\uDF77\uD83C\uDF77\uD83C\uDF77\uD83C\uDF77\uD83C\uDF77\uD83C\uDF77",
  "id" : 415273778914947073,
  "in_reply_to_status_id" : 415271202673139712,
  "created_at" : "2013-12-24 00:12:38 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/415272576693202944\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/C1SKzOyI39",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcNYNU0CUAAT5lk.jpg",
      "id_str" : "415272576596725760",
      "id" : 415272576596725760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcNYNU0CUAAT5lk.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/C1SKzOyI39"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415256604414464000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7213183977, -121.6760289018 ]
  },
  "id_str" : "415272576693202944",
  "in_reply_to_user_id" : 2185,
  "text" : "Traffic cleared, Graceland playing, \"Jesus Saves\" crop circles on the hill. http:\/\/t.co\/C1SKzOyI39",
  "id" : 415272576693202944,
  "in_reply_to_status_id" : 415256604414464000,
  "created_at" : "2013-12-24 00:07:52 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415269573953601536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7039269885, -121.7354714675 ]
  },
  "id_str" : "415270632268382208",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Deal!",
  "id" : 415270632268382208,
  "in_reply_to_status_id" : 415269573953601536,
  "created_at" : "2013-12-24 00:00:08 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415260090564767744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6995253237, -121.7733075098 ]
  },
  "id_str" : "415260346316636160",
  "in_reply_to_user_id" : 2185,
  "text" : "@arainert Oh and apparently it will give you more info when the engine light goes on. And help you find where you parked. Magic things.",
  "id" : 415260346316636160,
  "in_reply_to_status_id" : 415260090564767744,
  "created_at" : "2013-12-23 23:19:16 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415259212005244928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6997702849, -121.7730832939 ]
  },
  "id_str" : "415260090564767744",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert I'm on day 2 but gas mileage is the most obviously useful. The beeps on hard breaks\/accels is pretty fun too.",
  "id" : 415260090564767744,
  "in_reply_to_status_id" : 415259212005244928,
  "created_at" : "2013-12-23 23:18:15 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415258773159436288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6977952151, -121.7731693761 ]
  },
  "id_str" : "415259095923302400",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Pretty good so far. Super easy to set up and now have access to info I've never had before.",
  "id" : 415259095923302400,
  "in_reply_to_status_id" : 415258773159436288,
  "created_at" : "2013-12-23 23:14:18 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Automatic ",
      "screen_name" : "automatic",
      "indices" : [ 99, 109 ],
      "id_str" : "618542623",
      "id" : 618542623
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/415256604414464000\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/J2jvSjJI13",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcNJrnQCAAA7a2X.jpg",
      "id_str" : "415256604267642880",
      "id" : 415256604267642880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcNJrnQCAAA7a2X.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/J2jvSjJI13"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415240850436657152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7011738653, -121.7462810842 ]
  },
  "id_str" : "415256604414464000",
  "in_reply_to_user_id" : 2185,
  "text" : "So far our road trip karma has been poor. 36 miles in 2 hours. Regrouping morale at In-N-Out. \/via @automatic http:\/\/t.co\/J2jvSjJI13",
  "id" : 415256604414464000,
  "in_reply_to_status_id" : 415240850436657152,
  "created_at" : "2013-12-23 23:04:24 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415254373753950208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7012344357, -121.7459286937 ]
  },
  "id_str" : "415255289483390976",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb My vote is that you should either move or start your own company.",
  "id" : 415255289483390976,
  "in_reply_to_status_id" : 415254373753950208,
  "created_at" : "2013-12-23 22:59:10 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Automatic ",
      "screen_name" : "automatic",
      "indices" : [ 1, 11 ],
      "id_str" : "618542623",
      "id" : 618542623
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 12, 22 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415243674847809536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7015181212, -121.768756807 ]
  },
  "id_str" : "415251462877233152",
  "in_reply_to_user_id" : 618542623,
  "text" : ".@automatic @kellianne Feature request: a way to say who's driving so we can compare stats and settle the \"who's a better driver\" question.",
  "id" : 415251462877233152,
  "in_reply_to_status_id" : 415243674847809536,
  "created_at" : "2013-12-23 22:43:58 +0000",
  "in_reply_to_screen_name" : "automatic",
  "in_reply_to_user_id_str" : "618542623",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415232436491268097",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7010640316, -121.7719116715 ]
  },
  "id_str" : "415250854359228417",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Twitter!",
  "id" : 415250854359228417,
  "in_reply_to_status_id" : 415232436491268097,
  "created_at" : "2013-12-23 22:41:33 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Muller",
      "screen_name" : "AmyGSFN",
      "indices" : [ 0, 8 ],
      "id_str" : "26305496",
      "id" : 26305496
    }, {
      "name" : "Automatic ",
      "screen_name" : "automatic",
      "indices" : [ 9, 19 ],
      "id_str" : "618542623",
      "id" : 618542623
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 20, 30 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415243818380718081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6997746854, -121.7832015922 ]
  },
  "id_str" : "415249540782911489",
  "in_reply_to_user_id" : 26305496,
  "text" : "@AmyGSFN @automatic @kellianne Awesome! Hi! Always love it when I find my friends are behind great new products.",
  "id" : 415249540782911489,
  "in_reply_to_status_id" : 415243818380718081,
  "created_at" : "2013-12-23 22:36:20 +0000",
  "in_reply_to_screen_name" : "AmyGSFN",
  "in_reply_to_user_id_str" : "26305496",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/415240850436657152\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/hbfL9sm37w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcM7WnCCcAEX0jU.jpg",
      "id_str" : "415240850268909569",
      "id" : 415240850268909569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcM7WnCCcAEX0jU.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/hbfL9sm37w"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415232946153328640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7009777818, -121.840829691 ]
  },
  "id_str" : "415240850436657152",
  "in_reply_to_user_id" : 2185,
  "text" : "http:\/\/t.co\/hbfL9sm37w",
  "id" : 415240850436657152,
  "in_reply_to_status_id" : 415232946153328640,
  "created_at" : "2013-12-23 22:01:48 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/415232946153328640\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/cj3S34cNfW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcM0KhTCAAEGGmO.jpg",
      "id_str" : "415232945989746689",
      "id" : 415232945989746689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcM0KhTCAAEGGmO.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cj3S34cNfW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7002378693, -122.0393366275 ]
  },
  "id_str" : "415232946153328640",
  "text" : "http:\/\/t.co\/cj3S34cNfW",
  "id" : 415232946153328640,
  "created_at" : "2013-12-23 21:30:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Automatic ",
      "screen_name" : "automatic",
      "indices" : [ 42, 52 ],
      "id_str" : "618542623",
      "id" : 618542623
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 70, 80 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.830844014, -122.2672947218 ]
  },
  "id_str" : "415228587566833666",
  "text" : "On the road south to Irvine. We installed @automatic and 5 minutes in @kellianne has already lost points for breaking too hard.",
  "id" : 415228587566833666,
  "created_at" : "2013-12-23 21:13:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "415028501092130816",
  "text" : "I\u2019ve never seen the internet so empty before.",
  "id" : 415028501092130816,
  "created_at" : "2013-12-23 07:58:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathryn Brunner",
      "screen_name" : "kathrynbrunner",
      "indices" : [ 0, 15 ],
      "id_str" : "193568360",
      "id" : 193568360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415002109718040576",
  "geo" : { },
  "id_str" : "415018598759800832",
  "in_reply_to_user_id" : 193568360,
  "text" : "@kathrynbrunner He\u2019s already passed me in skill on the drums. :)",
  "id" : 415018598759800832,
  "in_reply_to_status_id" : 415002109718040576,
  "created_at" : "2013-12-23 07:18:39 +0000",
  "in_reply_to_screen_name" : "kathrynbrunner",
  "in_reply_to_user_id_str" : "193568360",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415005437885710336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597129875, -122.2756250914 ]
  },
  "id_str" : "415009723537051648",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner Great goals.",
  "id" : 415009723537051648,
  "in_reply_to_status_id" : 415005437885710336,
  "created_at" : "2013-12-23 06:43:23 +0000",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/youtube-capture\/id576941441?mt=8&uo=4\" rel=\"nofollow\"\u003EYouTube Capture on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/8lRnaCr9DJ",
      "expanded_url" : "http:\/\/youtu.be\/cR6g0bnnZzs?ac",
      "display_url" : "youtu.be\/cR6g0bnnZzs?ac"
    } ]
  },
  "geo" : { },
  "id_str" : "414984637169938432",
  "text" : "Twinkle Twinkle Little Star on the drums http:\/\/t.co\/8lRnaCr9DJ",
  "id" : 414984637169938432,
  "created_at" : "2013-12-23 05:03:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/414979312433897472\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/rPvprdheyf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcJNfF3CcAAUZbP.jpg",
      "id_str" : "414979312215814144",
      "id" : 414979312215814144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcJNfF3CcAAUZbP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rPvprdheyf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596745758, -122.275363058 ]
  },
  "id_str" : "414979312433897472",
  "text" : "8:36pm Niko declares is the season for playing, since he forgot to buy us gifts http:\/\/t.co\/rPvprdheyf",
  "id" : 414979312433897472,
  "created_at" : "2013-12-23 04:42:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Roomann-Kurrik",
      "screen_name" : "kurrik",
      "indices" : [ 0, 7 ],
      "id_str" : "7588892",
      "id" : 7588892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414909319293853696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.870145978, -122.300964238 ]
  },
  "id_str" : "414910497910034432",
  "in_reply_to_user_id" : 7588892,
  "text" : "@kurrik I prefer my college days when I put up my tree around the new year. Much more economical.",
  "id" : 414910497910034432,
  "in_reply_to_status_id" : 414909319293853696,
  "created_at" : "2013-12-23 00:09:06 +0000",
  "in_reply_to_screen_name" : "kurrik",
  "in_reply_to_user_id_str" : "7588892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Musk",
      "screen_name" : "justinemusk",
      "indices" : [ 0, 12 ],
      "id_str" : "14388420",
      "id" : 14388420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414875145946148864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597265017, -122.275541341 ]
  },
  "id_str" : "414888896002916352",
  "in_reply_to_user_id" : 14388420,
  "text" : "@justinemusk Exactly. The pursuit isn't futile, there are just some really easy mistakes to make if you're not paying attention.",
  "id" : 414888896002916352,
  "in_reply_to_status_id" : 414875145946148864,
  "created_at" : "2013-12-22 22:43:15 +0000",
  "in_reply_to_screen_name" : "justinemusk",
  "in_reply_to_user_id_str" : "14388420",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Musk",
      "screen_name" : "justinemusk",
      "indices" : [ 0, 12 ],
      "id_str" : "14388420",
      "id" : 14388420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414871685565669376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7588176587, -122.2330863604 ]
  },
  "id_str" : "414872327591976960",
  "in_reply_to_user_id" : 14388420,
  "text" : "@justinemusk I don't necessarily agree. There's just a steep learning curve before strategies become effective.",
  "id" : 414872327591976960,
  "in_reply_to_status_id" : 414871685565669376,
  "created_at" : "2013-12-22 21:37:25 +0000",
  "in_reply_to_screen_name" : "justinemusk",
  "in_reply_to_user_id_str" : "14388420",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexis C. Madrigal",
      "screen_name" : "alexismadrigal",
      "indices" : [ 3, 18 ],
      "id_str" : "11107172",
      "id" : 11107172
    }, {
      "name" : "Farhad Manjoo",
      "screen_name" : "fmanjoo",
      "indices" : [ 20, 28 ],
      "id_str" : "2195241",
      "id" : 2195241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/NqxR5kaD9r",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2013\/12\/almost-human-the-surreal-cyborg-future-of-telemarketing\/282537\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "414837119001964544",
  "text" : "RT @alexismadrigal: @fmanjoo here's the more-detailed follow: http:\/\/t.co\/NqxR5kaD9r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Farhad Manjoo",
        "screen_name" : "fmanjoo",
        "indices" : [ 0, 8 ],
        "id_str" : "2195241",
        "id" : 2195241
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/NqxR5kaD9r",
        "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2013\/12\/almost-human-the-surreal-cyborg-future-of-telemarketing\/282537\/",
        "display_url" : "theatlantic.com\/technology\/arc\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "414804702841540608",
    "geo" : { },
    "id_str" : "414828309684310016",
    "in_reply_to_user_id" : 2195241,
    "text" : "@fmanjoo here's the more-detailed follow: http:\/\/t.co\/NqxR5kaD9r",
    "id" : 414828309684310016,
    "in_reply_to_status_id" : 414804702841540608,
    "created_at" : "2013-12-22 18:42:30 +0000",
    "in_reply_to_screen_name" : "fmanjoo",
    "in_reply_to_user_id_str" : "2195241",
    "user" : {
      "name" : "Alexis C. Madrigal",
      "screen_name" : "alexismadrigal",
      "protected" : false,
      "id_str" : "11107172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455914184069218304\/2tTlfGo5_normal.jpeg",
      "id" : 11107172,
      "verified" : true
    }
  },
  "id" : 414837119001964544,
  "created_at" : "2013-12-22 19:17:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farhad Manjoo",
      "screen_name" : "fmanjoo",
      "indices" : [ 0, 8 ],
      "id_str" : "2195241",
      "id" : 2195241
    }, {
      "name" : "Alexis C. Madrigal",
      "screen_name" : "alexismadrigal",
      "indices" : [ 9, 24 ],
      "id_str" : "11107172",
      "id" : 11107172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414804702841540608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596741148, -122.2754406744 ]
  },
  "id_str" : "414833672307503104",
  "in_reply_to_user_id" : 2195241,
  "text" : "@fmanjoo @alexismadrigal We're losing this war. Need to start our army of answering machine bots to defend us from these telemarketer bots.",
  "id" : 414833672307503104,
  "in_reply_to_status_id" : 414804702841540608,
  "created_at" : "2013-12-22 19:03:49 +0000",
  "in_reply_to_screen_name" : "fmanjoo",
  "in_reply_to_user_id_str" : "2195241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farhad Manjoo",
      "screen_name" : "fmanjoo",
      "indices" : [ 3, 11 ],
      "id_str" : "2195241",
      "id" : 2195241
    }, {
      "name" : "Alexis C. Madrigal",
      "screen_name" : "alexismadrigal",
      "indices" : [ 70, 85 ],
      "id_str" : "11107172",
      "id" : 11107172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/KZ0fIvJOwC",
      "expanded_url" : "http:\/\/fm4.fm\/J7dzcJ",
      "display_url" : "fm4.fm\/J7dzcJ"
    } ]
  },
  "geo" : { },
  "id_str" : "414833122832699393",
  "text" : "RT @fmanjoo: The Only Thing Weirder Than a Telemarketing Robot. great @alexismadrigal piece http:\/\/t.co\/KZ0fIvJOwC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alexis C. Madrigal",
        "screen_name" : "alexismadrigal",
        "indices" : [ 57, 72 ],
        "id_str" : "11107172",
        "id" : 11107172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/KZ0fIvJOwC",
        "expanded_url" : "http:\/\/fm4.fm\/J7dzcJ",
        "display_url" : "fm4.fm\/J7dzcJ"
      } ]
    },
    "geo" : { },
    "id_str" : "414804702841540608",
    "text" : "The Only Thing Weirder Than a Telemarketing Robot. great @alexismadrigal piece http:\/\/t.co\/KZ0fIvJOwC",
    "id" : 414804702841540608,
    "created_at" : "2013-12-22 17:08:42 +0000",
    "user" : {
      "name" : "Farhad Manjoo",
      "screen_name" : "fmanjoo",
      "protected" : false,
      "id_str" : "2195241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/424235863250173952\/0xeLHVmD_normal.jpeg",
      "id" : 2195241,
      "verified" : true
    }
  },
  "id" : 414833122832699393,
  "created_at" : "2013-12-22 19:01:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 0, 7 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 64, 73 ],
      "id_str" : "14417215",
      "id" : 14417215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/a8MI5km9vO",
      "expanded_url" : "http:\/\/producthunt.co",
      "display_url" : "producthunt.co"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596969892, -122.2755770683 ]
  },
  "id_str" : "414647821241819137",
  "in_reply_to_user_id" : 2185,
  "text" : "@buster: Sort of in love with http:\/\/t.co\/a8MI5km9vO. Nice work @rrhoover. Keep it simple!",
  "id" : 414647821241819137,
  "created_at" : "2013-12-22 06:45:19 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    }, {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 23, 29 ],
      "id_str" : "42559115",
      "id" : 42559115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414632239276621824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597376077, -122.2754491401 ]
  },
  "id_str" : "414643947776909312",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover I agree with @joshm on pretty much everything. When does the mobile app come out? :)",
  "id" : 414643947776909312,
  "in_reply_to_status_id" : 414632239276621824,
  "created_at" : "2013-12-22 06:29:55 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/fsVaoGn4Eh",
      "expanded_url" : "http:\/\/instagram.com\/p\/iNpgBEo0M3\/",
      "display_url" : "instagram.com\/p\/iNpgBEo0M3\/"
    } ]
  },
  "geo" : { },
  "id_str" : "414638228336312320",
  "text" : "Photo highlights from 2013 made with flipagram (cool app) http:\/\/t.co\/fsVaoGn4Eh",
  "id" : 414638228336312320,
  "created_at" : "2013-12-22 06:07:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597039967, -122.2755234427 ]
  },
  "id_str" : "414630655712952320",
  "text" : "New Snapchat review: \uD83D\uDC4D\uD83D\uDC4D on smart filters, \uD83D\uDC4E\uD83D\uDC4E\uD83D\uDC4E\uD83D\uDC4E\uD83D\uDC4E on replays.",
  "id" : 414630655712952320,
  "created_at" : "2013-12-22 05:37:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/414628334069227521\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/T2226eALaH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcEORdkCQAEal1T.jpg",
      "id_str" : "414628333851131905",
      "id" : 414628333851131905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcEORdkCQAEal1T.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/T2226eALaH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597048764, -122.2755420954 ]
  },
  "id_str" : "414628334069227521",
  "text" : "8:36pm Niko spent a couple minutes figuring out how this elf worked. He also told us that Santa's face is pretend. http:\/\/t.co\/T2226eALaH",
  "id" : 414628334069227521,
  "created_at" : "2013-12-22 05:27:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Hilton",
      "screen_name" : "granthilton38",
      "indices" : [ 8, 22 ],
      "id_str" : "624037415",
      "id" : 624037415
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 31, 38 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/granthilton38\/status\/414619114942918656\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/VxhFJQxsbd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcEF411CAAEYm2k.jpg",
      "id_str" : "414619114775117825",
      "id" : 414619114775117825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcEF411CAAEYm2k.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VxhFJQxsbd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414619114942918656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596982127, -122.2754297779 ]
  },
  "id_str" : "414624460503646208",
  "in_reply_to_user_id" : 624037415,
  "text" : "Woof RT @granthilton38: Selfie @buster http:\/\/t.co\/VxhFJQxsbd",
  "id" : 414624460503646208,
  "in_reply_to_status_id" : 414619114942918656,
  "created_at" : "2013-12-22 05:12:29 +0000",
  "in_reply_to_screen_name" : "granthilton38",
  "in_reply_to_user_id_str" : "624037415",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/Uy894OKINj",
      "expanded_url" : "https:\/\/vine.co\/v\/hEOLJUL2b7i",
      "display_url" : "vine.co\/v\/hEOLJUL2b7i"
    } ]
  },
  "geo" : { },
  "id_str" : "414613595524440064",
  "text" : "Christmas Tree Lane is pretty Christmassy https:\/\/t.co\/Uy894OKINj",
  "id" : 414613595524440064,
  "created_at" : "2013-12-22 04:29:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "indices" : [ 0, 12 ],
      "id_str" : "289534689",
      "id" : 289534689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414464889302691840",
  "geo" : { },
  "id_str" : "414465713839935488",
  "in_reply_to_user_id" : 289534689,
  "text" : "@seriouspony We should strive to understand how we can change ourselves. Changing *others* on the  other hand is much more complicated.",
  "id" : 414465713839935488,
  "in_reply_to_status_id" : 414464889302691840,
  "created_at" : "2013-12-21 18:41:41 +0000",
  "in_reply_to_screen_name" : "seriouspony",
  "in_reply_to_user_id_str" : "289534689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D. Keith Robinson",
      "screen_name" : "dkr",
      "indices" : [ 0, 4 ],
      "id_str" : "10877",
      "id" : 10877
    }, {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 5, 15 ],
      "id_str" : "4981271",
      "id" : 4981271
    }, {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 16, 30 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414444594340691968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859699931, -122.2755809036 ]
  },
  "id_str" : "414445419125415937",
  "in_reply_to_user_id" : 10877,
  "text" : "@dkr @sourjayne @buster_ebooks I'd be in! What's the hip cooks of the Bay Area? Extra points for kid-friendly.",
  "id" : 414445419125415937,
  "in_reply_to_status_id" : 414444594340691968,
  "created_at" : "2013-12-21 17:21:02 +0000",
  "in_reply_to_screen_name" : "dkr",
  "in_reply_to_user_id_str" : "10877",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hagel",
      "screen_name" : "jhagel",
      "indices" : [ 3, 10 ],
      "id_str" : "14076943",
      "id" : 14076943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/TMlgXvJsXH",
      "expanded_url" : "http:\/\/huff.to\/1gN5Qin",
      "display_url" : "huff.to\/1gN5Qin"
    } ]
  },
  "geo" : { },
  "id_str" : "414413752289615872",
  "text" : "RT @jhagel: Aging is about a communication breakdown within cells - it's all about flow. New compound discovered to enhance flow http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/TMlgXvJsXH",
        "expanded_url" : "http:\/\/huff.to\/1gN5Qin",
        "display_url" : "huff.to\/1gN5Qin"
      } ]
    },
    "geo" : { },
    "id_str" : "414405157351206913",
    "text" : "Aging is about a communication breakdown within cells - it's all about flow. New compound discovered to enhance flow http:\/\/t.co\/TMlgXvJsXH",
    "id" : 414405157351206913,
    "created_at" : "2013-12-21 14:41:03 +0000",
    "user" : {
      "name" : "John Hagel",
      "screen_name" : "jhagel",
      "protected" : false,
      "id_str" : "14076943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000843301492\/c0b254d79d675d95651989d948493e8d_normal.jpeg",
      "id" : 14076943,
      "verified" : false
    }
  },
  "id" : 414413752289615872,
  "created_at" : "2013-12-21 15:15:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carly Brooke",
      "screen_name" : "ftcreature",
      "indices" : [ 3, 14 ],
      "id_str" : "200405814",
      "id" : 200405814
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ftcreature\/status\/410832109562261504\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/NNhYpkKWXl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbORoHJIIAIvSS7.jpg",
      "id_str" : "410832109318971394",
      "id" : 410832109318971394,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbORoHJIIAIvSS7.jpg",
      "sizes" : [ {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/NNhYpkKWXl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414275898079064064",
  "text" : "RT @ftcreature: 'Scuse me... Your kitten printer is running out of toner. http:\/\/t.co\/NNhYpkKWXl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ftcreature\/status\/410832109562261504\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/NNhYpkKWXl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbORoHJIIAIvSS7.jpg",
        "id_str" : "410832109318971394",
        "id" : 410832109318971394,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbORoHJIIAIvSS7.jpg",
        "sizes" : [ {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/NNhYpkKWXl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410832109562261504",
    "text" : "'Scuse me... Your kitten printer is running out of toner. http:\/\/t.co\/NNhYpkKWXl",
    "id" : 410832109562261504,
    "created_at" : "2013-12-11 18:03:02 +0000",
    "user" : {
      "name" : "Carly Brooke",
      "screen_name" : "ftcreature",
      "protected" : false,
      "id_str" : "200405814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466249415997407233\/7i-3J8U9_normal.jpeg",
      "id" : 200405814,
      "verified" : false
    }
  },
  "id" : 414275898079064064,
  "created_at" : "2013-12-21 06:07:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravi Narasimhan",
      "screen_name" : "Ravi",
      "indices" : [ 0, 5 ],
      "id_str" : "20283354",
      "id" : 20283354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414270322632691713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859583718, -122.275568446 ]
  },
  "id_str" : "414271589706788864",
  "in_reply_to_user_id" : 20283354,
  "text" : "@Ravi The idea and applicability of FOMO is fascinating\/terrifying.",
  "id" : 414271589706788864,
  "in_reply_to_status_id" : 414270322632691713,
  "created_at" : "2013-12-21 05:50:18 +0000",
  "in_reply_to_screen_name" : "Ravi",
  "in_reply_to_user_id_str" : "20283354",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414270315099746304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596333787, -122.2754843441 ]
  },
  "id_str" : "414270586236329984",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel I was just thinking that this would make a good Black Mirror episode.",
  "id" : 414270586236329984,
  "in_reply_to_status_id" : 414270315099746304,
  "created_at" : "2013-12-21 05:46:19 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414269963419934720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859686059, -122.2754312028 ]
  },
  "id_str" : "414270130051248130",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Nope. Link please!",
  "id" : 414270130051248130,
  "in_reply_to_status_id" : 414269963419934720,
  "created_at" : "2013-12-21 05:44:30 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414269403618746368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596307195, -122.2755497052 ]
  },
  "id_str" : "414269823946739712",
  "in_reply_to_user_id" : 2185,
  "text" : "Then again what if reality is just a highly personalized stream of recommended and serendipitous information streaming from another service?",
  "id" : 414269823946739712,
  "in_reply_to_status_id" : 414269403618746368,
  "created_at" : "2013-12-21 05:43:17 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414268914323816448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597674795, -122.2756042602 ]
  },
  "id_str" : "414269403618746368",
  "in_reply_to_user_id" : 2185,
  "text" : "What if we eventually decide that the stream is a better signal than the world around us an we switch to rely more on that channel?",
  "id" : 414269403618746368,
  "in_reply_to_status_id" : 414268914323816448,
  "created_at" : "2013-12-21 05:41:37 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596919263, -122.2754548398 ]
  },
  "id_str" : "414268914323816448",
  "text" : "Saw a stat about Facebook saying that on average people have to read 1.5 posts\/min for 17 hrs\/day to stay up to date with their stream.",
  "id" : 414268914323816448,
  "created_at" : "2013-12-21 05:39:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hasjustinelandedyet",
      "indices" : [ 46, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/ETqSOo2u6J",
      "expanded_url" : "http:\/\/flic.kr\/p\/itWJvk",
      "display_url" : "flic.kr\/p\/itWJvk"
    } ]
  },
  "geo" : { },
  "id_str" : "414255225646878720",
  "text" : "8:36pm Ready for a week off. Trying to ignore #hasjustinelandedyet. http:\/\/t.co\/ETqSOo2u6J",
  "id" : 414255225646878720,
  "created_at" : "2013-12-21 04:45:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 23, 30 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/FNtURkESOn",
      "expanded_url" : "https:\/\/twitter.com\/isaach\/timelines\/414182918643142656",
      "display_url" : "twitter.com\/isaach\/timelin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "414195030576746496",
  "text" : "A holiday message from @isaach: https:\/\/t.co\/FNtURkESOn",
  "id" : 414195030576746496,
  "created_at" : "2013-12-21 00:46:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Zhuo",
      "screen_name" : "joulee",
      "indices" : [ 3, 10 ],
      "id_str" : "17611446",
      "id" : 17611446
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 31, 38 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/wma6c5BKCo",
      "expanded_url" : "https:\/\/medium.com\/the-year-of-the-looking-glass\/f1173d0bd181",
      "display_url" : "medium.com\/the-year-of-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "414135653857644544",
  "text" : "RT @joulee: Also a new post on @Medium -- why we did Origami, and what we think is cool about Quartz Composer as a tool - https:\/\/t.co\/wma6\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 19, 26 ],
        "id_str" : "571202103",
        "id" : 571202103
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/wma6c5BKCo",
        "expanded_url" : "https:\/\/medium.com\/the-year-of-the-looking-glass\/f1173d0bd181",
        "display_url" : "medium.com\/the-year-of-th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "414132870806908928",
    "text" : "Also a new post on @Medium -- why we did Origami, and what we think is cool about Quartz Composer as a tool - https:\/\/t.co\/wma6c5BKCo",
    "id" : 414132870806908928,
    "created_at" : "2013-12-20 20:39:05 +0000",
    "user" : {
      "name" : "Julie Zhuo",
      "screen_name" : "joulee",
      "protected" : false,
      "id_str" : "17611446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3081241504\/9f3d8cfd0a6895424b2e8182f5e6b133_normal.png",
      "id" : 17611446,
      "verified" : false
    }
  },
  "id" : 414135653857644544,
  "created_at" : "2013-12-20 20:50:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414062592512892929",
  "geo" : { },
  "id_str" : "414131135057117184",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler Yeah, bummer! So many people!",
  "id" : 414131135057117184,
  "in_reply_to_status_id" : 414062592512892929,
  "created_at" : "2013-12-20 20:32:11 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Crawford",
      "screen_name" : "britt",
      "indices" : [ 0, 6 ],
      "id_str" : "5362",
      "id" : 5362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414081174525333504",
  "geo" : { },
  "id_str" : "414114079897174016",
  "in_reply_to_user_id" : 5362,
  "text" : "@britt As far as I know, no children were murdered in the making of this party. But yes, lots of props were thrown into the ring.",
  "id" : 414114079897174016,
  "in_reply_to_status_id" : 414081174525333504,
  "created_at" : "2013-12-20 19:24:25 +0000",
  "in_reply_to_screen_name" : "britt",
  "in_reply_to_user_id_str" : "5362",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Co.Design",
      "screen_name" : "FastCoDesign",
      "indices" : [ 3, 16 ],
      "id_str" : "158865339",
      "id" : 158865339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/XRKDzVQFsj",
      "expanded_url" : "http:\/\/f-st.co\/MQnhSwp",
      "display_url" : "f-st.co\/MQnhSwp"
    } ]
  },
  "geo" : { },
  "id_str" : "414083118337753088",
  "text" : "RT @FastCoDesign: Why The Pull-To-Refresh Gesture Must Die http:\/\/t.co\/XRKDzVQFsj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/XRKDzVQFsj",
        "expanded_url" : "http:\/\/f-st.co\/MQnhSwp",
        "display_url" : "f-st.co\/MQnhSwp"
      } ]
    },
    "geo" : { },
    "id_str" : "414054211220156416",
    "text" : "Why The Pull-To-Refresh Gesture Must Die http:\/\/t.co\/XRKDzVQFsj",
    "id" : 414054211220156416,
    "created_at" : "2013-12-20 15:26:31 +0000",
    "user" : {
      "name" : "Co.Design",
      "screen_name" : "FastCoDesign",
      "protected" : false,
      "id_str" : "158865339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1782675147\/1214-co-design-twitter-logo_normal.gif",
      "id" : 158865339,
      "verified" : true
    }
  },
  "id" : 414083118337753088,
  "created_at" : "2013-12-20 17:21:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/413920952985321472\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/EJWfN8rWLY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb6K6d-IMAAn2SA.jpg",
      "id_str" : "413920952846921728",
      "id" : 413920952846921728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb6K6d-IMAAn2SA.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EJWfN8rWLY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413891641091829760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7790818268, -122.4198057507 ]
  },
  "id_str" : "413920952985321472",
  "in_reply_to_user_id" : 2185,
  "text" : "Caught by the Twitter paparazzi http:\/\/t.co\/EJWfN8rWLY",
  "id" : 413920952985321472,
  "in_reply_to_status_id" : 413891641091829760,
  "created_at" : "2013-12-20 06:37:00 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/413891641091829760\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/F6KxZKseKg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb5wQSmIQAAX2Cs.jpg",
      "id_str" : "413891640936644608",
      "id" : 413891640936644608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb5wQSmIQAAX2Cs.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/F6KxZKseKg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7788974346, -122.4200069863 ]
  },
  "id_str" : "413891641091829760",
  "text" : "8:36pm eating all of Twitter's food, drinking all of Twitter's drinks http:\/\/t.co\/F6KxZKseKg",
  "id" : 413891641091829760,
  "created_at" : "2013-12-20 04:40:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "City of SanFrancisco",
      "screen_name" : "sfgov",
      "indices" : [ 45, 51 ],
      "id_str" : "16318114",
      "id" : 16318114
    }, {
      "name" : "Kevin Lingerfelt",
      "screen_name" : "klingerf",
      "indices" : [ 55, 64 ],
      "id_str" : "16018433",
      "id" : 16018433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/OFdcnwTxjw",
      "expanded_url" : "http:\/\/4sq.com\/1i5MQfj",
      "display_url" : "4sq.com\/1i5MQfj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7793307328, -122.4192273617 ]
  },
  "id_str" : "413880203921072128",
  "text" : "Happy Twolidays (@ San Francisco City Hall - @sfgov w\/ @klingerf) http:\/\/t.co\/OFdcnwTxjw",
  "id" : 413880203921072128,
  "created_at" : "2013-12-20 03:55:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/413879447939743744\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/tFRT13XMv9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb5lKjaIIAAF-4A.jpg",
      "id_str" : "413879447742586880",
      "id" : 413879447742586880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb5lKjaIIAAF-4A.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tFRT13XMv9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413879447939743744",
  "text" : "That's a lot of Twitter blue. http:\/\/t.co\/tFRT13XMv9",
  "id" : 413879447939743744,
  "created_at" : "2013-12-20 03:52:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "indices" : [ 3, 8 ],
      "id_str" : "949521",
      "id" : 949521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/M3RAzrASb6",
      "expanded_url" : "http:\/\/reformgovernmentsurveillance.com",
      "display_url" : "reformgovernmentsurveillance.com"
    } ]
  },
  "geo" : { },
  "id_str" : "413779024901443584",
  "text" : "RT @stop: An open letter to Washington, from AOL, Apple, Facebook, Google, LinkedIn, Microsoft, Twitter, and Yahoo http:\/\/t.co\/M3RAzrASb6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/M3RAzrASb6",
        "expanded_url" : "http:\/\/reformgovernmentsurveillance.com",
        "display_url" : "reformgovernmentsurveillance.com"
      } ]
    },
    "geo" : { },
    "id_str" : "413738511963934720",
    "text" : "An open letter to Washington, from AOL, Apple, Facebook, Google, LinkedIn, Microsoft, Twitter, and Yahoo http:\/\/t.co\/M3RAzrASb6",
    "id" : 413738511963934720,
    "created_at" : "2013-12-19 18:32:02 +0000",
    "user" : {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "protected" : false,
      "id_str" : "949521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441691596375863296\/H7LzEpDT_normal.jpeg",
      "id" : 949521,
      "verified" : false
    }
  },
  "id" : 413779024901443584,
  "created_at" : "2013-12-19 21:13:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/GuSWaAj9Q9",
      "expanded_url" : "http:\/\/ben-evans.com\/benedictevans\/2013\/12\/18\/what-does-mobile-scale-mean",
      "display_url" : "ben-evans.com\/benedictevans\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7842773582, -122.4080615759 ]
  },
  "id_str" : "413717544281706496",
  "text" : "\"Smartphones liberate the internet from the browser in the same way the browser liberated it from the command line.\" http:\/\/t.co\/GuSWaAj9Q9",
  "id" : 413717544281706496,
  "created_at" : "2013-12-19 17:08:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nieman Lab",
      "screen_name" : "NiemanLab",
      "indices" : [ 3, 13 ],
      "id_str" : "15865878",
      "id" : 15865878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/Cr29E9CtgN",
      "expanded_url" : "http:\/\/nie.mn\/1jlq4lt",
      "display_url" : "nie.mn\/1jlq4lt"
    } ]
  },
  "geo" : { },
  "id_str" : "413703695851716608",
  "text" : "RT @NiemanLab: The future of news is\u2026Beyonce http:\/\/t.co\/Cr29E9CtgN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/Cr29E9CtgN",
        "expanded_url" : "http:\/\/nie.mn\/1jlq4lt",
        "display_url" : "nie.mn\/1jlq4lt"
      } ]
    },
    "geo" : { },
    "id_str" : "413672793738579968",
    "text" : "The future of news is\u2026Beyonce http:\/\/t.co\/Cr29E9CtgN",
    "id" : 413672793738579968,
    "created_at" : "2013-12-19 14:10:54 +0000",
    "user" : {
      "name" : "Nieman Lab",
      "screen_name" : "NiemanLab",
      "protected" : false,
      "id_str" : "15865878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/208769717\/TwitterNgood_normal.png",
      "id" : 15865878,
      "verified" : true
    }
  },
  "id" : 413703695851716608,
  "created_at" : "2013-12-19 16:13:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 86, 95 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/Fye9rIM6c3",
      "expanded_url" : "http:\/\/www.niemanlab.org\/2013\/12\/even-if-its-fake-its-real\/",
      "display_url" : "niemanlab.org\/2013\/12\/even-i\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596558674, -122.2756014033 ]
  },
  "id_str" : "413702916344532992",
  "text" : "Enjoy the gray area of uncertainty between truth and lies: http:\/\/t.co\/Fye9rIM6c3 \/by @mathowie",
  "id" : 413702916344532992,
  "created_at" : "2013-12-19 16:10:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nieman Lab",
      "screen_name" : "NiemanLab",
      "indices" : [ 36, 46 ],
      "id_str" : "15865878",
      "id" : 15865878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/LRm8zOhi5Y",
      "expanded_url" : "http:\/\/nie.mn\/1jlq58I",
      "display_url" : "nie.mn\/1jlq58I"
    } ]
  },
  "in_reply_to_status_id_str" : "413670674696536064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859625987, -122.2755843604 ]
  },
  "id_str" : "413701668547469313",
  "in_reply_to_user_id" : 15865878,
  "text" : "What Happens Next Will Amaze You RT @NiemanLab: Jason Kottke: \"The blog Is dead, long live the blog.\" http:\/\/t.co\/LRm8zOhi5Y",
  "id" : 413701668547469313,
  "in_reply_to_status_id" : 413670674696536064,
  "created_at" : "2013-12-19 16:05:38 +0000",
  "in_reply_to_screen_name" : "NiemanLab",
  "in_reply_to_user_id_str" : "15865878",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/esNF9m9xPh",
      "expanded_url" : "http:\/\/flic.kr\/p\/irqY3d",
      "display_url" : "flic.kr\/p\/irqY3d"
    } ]
  },
  "geo" : { },
  "id_str" : "413544915420057600",
  "text" : "8:36pm Required reading for PMs. http:\/\/t.co\/esNF9m9xPh",
  "id" : 413544915420057600,
  "created_at" : "2013-12-19 05:42:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill S.",
      "screen_name" : "outseide",
      "indices" : [ 0, 9 ],
      "id_str" : "143694663",
      "id" : 143694663
    }, {
      "name" : "J-Chouette",
      "screen_name" : "gardenowl",
      "indices" : [ 40, 50 ],
      "id_str" : "600562316",
      "id" : 600562316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413497981698990080",
  "geo" : { },
  "id_str" : "413498277024108544",
  "in_reply_to_user_id" : 2185,
  "text" : "@outseide Also a crazy coincidence that @gardenowl is following 2001 people.",
  "id" : 413498277024108544,
  "in_reply_to_status_id" : 413497981698990080,
  "created_at" : "2013-12-19 02:37:26 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill S.",
      "screen_name" : "outseide",
      "indices" : [ 21, 30 ],
      "id_str" : "143694663",
      "id" : 143694663
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 32, 39 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "J-Chouette",
      "screen_name" : "gardenowl",
      "indices" : [ 92, 102 ],
      "id_str" : "600562316",
      "id" : 600562316
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow2000",
      "indices" : [ 6, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413497981698990080",
  "text" : "Done. #follow2000 RT @outseide: @buster personally I totally enjoy every quality tweet from @gardenowl :D.",
  "id" : 413497981698990080,
  "created_at" : "2013-12-19 02:36:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 7, 18 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413218549188927488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8568892274, -122.2731322983 ]
  },
  "id_str" : "413494670757330944",
  "in_reply_to_user_id" : 142467448,
  "text" : ":'( RT @nikobenson: Don't say you have wrinkles because that means you are getting old and you will die and then you won't be with me.",
  "id" : 413494670757330944,
  "in_reply_to_status_id" : 413218549188927488,
  "created_at" : "2013-12-19 02:23:06 +0000",
  "in_reply_to_screen_name" : "nikobenson",
  "in_reply_to_user_id_str" : "142467448",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Molina",
      "screen_name" : "noradio",
      "indices" : [ 0, 8 ],
      "id_str" : "3191321",
      "id" : 3191321
    }, {
      "name" : "Patrick Ewing",
      "screen_name" : "hoverbird",
      "indices" : [ 9, 19 ],
      "id_str" : "792690",
      "id" : 792690
    }, {
      "name" : "Dana",
      "screen_name" : "DanaDanger",
      "indices" : [ 20, 31 ],
      "id_str" : "821958",
      "id" : 821958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413461200677003264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8424112603, -122.2702670042 ]
  },
  "id_str" : "413491824964038657",
  "in_reply_to_user_id" : 3191321,
  "text" : "@noradio @hoverbird @DanaDanger And the answer is?",
  "id" : 413491824964038657,
  "in_reply_to_status_id" : 413461200677003264,
  "created_at" : "2013-12-19 02:11:48 +0000",
  "in_reply_to_screen_name" : "noradio",
  "in_reply_to_user_id_str" : "3191321",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763008428, -122.4168044983 ]
  },
  "id_str" : "413436929124753408",
  "text" : "I'm following 1,999 people. Who should be number 2,000?",
  "id" : 413436929124753408,
  "created_at" : "2013-12-18 22:33:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 31, 38 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/rJZiu9KdsA",
      "expanded_url" : "http:\/\/4sq.com\/JISWo2",
      "display_url" : "4sq.com\/JISWo2"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7859626482, -122.4050672451 ]
  },
  "id_str" : "413415482461814784",
  "text" : "Learned about holacracies. (at @Medium) http:\/\/t.co\/rJZiu9KdsA",
  "id" : 413415482461814784,
  "created_at" : "2013-12-18 21:08:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413202881555075072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7863833453, -122.4050006447 ]
  },
  "id_str" : "413398644516089856",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs I'm outside the door on the 3rd floor.",
  "id" : 413398644516089856,
  "in_reply_to_status_id" : 413202881555075072,
  "created_at" : "2013-12-18 20:01:32 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Om Malik",
      "screen_name" : "om",
      "indices" : [ 83, 86 ],
      "id_str" : "989",
      "id" : 989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/2fRJxkZCmG",
      "expanded_url" : "http:\/\/gigaom.com\/2013\/12\/16\/in-12-years-of-blogging-the-more-things-change-the-more-they-stay-the-same\/",
      "display_url" : "gigaom.com\/2013\/12\/16\/in-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7935893941, -122.3961530646 ]
  },
  "id_str" : "413365925870440448",
  "text" : "Om knows blogging. \"If you don\u2019t have a point of view, then you\u2019ve got nothing.\" - @om http:\/\/t.co\/2fRJxkZCmG",
  "id" : 413365925870440448,
  "created_at" : "2013-12-18 17:51:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 3, 14 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413357245406015489",
  "text" : "RT @nikobenson: When there are cars going by, you can't hear me fart, so I don't have to say \"excuse me\" when that happens.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "413168828244185089",
    "text" : "When there are cars going by, you can't hear me fart, so I don't have to say \"excuse me\" when that happens.",
    "id" : 413168828244185089,
    "created_at" : "2013-12-18 04:48:19 +0000",
    "user" : {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "protected" : false,
      "id_str" : "142467448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000616213793\/9f77fe6693d877565cd97b6a2381c40c_normal.jpeg",
      "id" : 142467448,
      "verified" : false
    }
  },
  "id" : 413357245406015489,
  "created_at" : "2013-12-18 17:17:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413202881555075072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8594240826, -122.2735894473 ]
  },
  "id_str" : "413354160096940032",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs Yes! See you at noon!",
  "id" : 413354160096940032,
  "in_reply_to_status_id" : 413202881555075072,
  "created_at" : "2013-12-18 17:04:46 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Cho",
      "screen_name" : "mark_cho",
      "indices" : [ 40, 49 ],
      "id_str" : "391248959",
      "id" : 391248959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/TwHfFbqrcZ",
      "expanded_url" : "http:\/\/flic.kr\/p\/iq24s5",
      "display_url" : "flic.kr\/p\/iq24s5"
    } ]
  },
  "geo" : { },
  "id_str" : "413170584575827968",
  "text" : "8:36pm Celebrating our favorite intern, @mark_cho! http:\/\/t.co\/TwHfFbqrcZ",
  "id" : 413170584575827968,
  "created_at" : "2013-12-18 04:55:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 37, 40 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/Si4JEj4TQe",
      "expanded_url" : "http:\/\/flic.kr\/p\/ipZVWT",
      "display_url" : "flic.kr\/p\/ipZVWT"
    } ]
  },
  "geo" : { },
  "id_str" : "413161973019607040",
  "text" : "Twitter consumer PM team party where @sm takes a statistically significant majority of the prizes http:\/\/t.co\/Si4JEj4TQe",
  "id" : 413161973019607040,
  "created_at" : "2013-12-18 04:21:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Esteban Kozak",
      "screen_name" : "ekozak",
      "indices" : [ 3, 10 ],
      "id_str" : "12694962",
      "id" : 12694962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413154750436085760",
  "text" : "RT @ekozak: Tweet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.758585868, -122.420556223 ]
    },
    "id_str" : "413154676767748096",
    "text" : "Tweet",
    "id" : 413154676767748096,
    "created_at" : "2013-12-18 03:52:05 +0000",
    "user" : {
      "name" : "Esteban Kozak",
      "screen_name" : "ekozak",
      "protected" : false,
      "id_str" : "12694962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1188538593\/esteban_kozak_normal",
      "id" : 12694962,
      "verified" : false
    }
  },
  "id" : 413154750436085760,
  "created_at" : "2013-12-18 03:52:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravi Narasimhan",
      "screen_name" : "Ravi",
      "indices" : [ 0, 5 ],
      "id_str" : "20283354",
      "id" : 20283354
    }, {
      "name" : "Kevin Weil",
      "screen_name" : "kevinweil",
      "indices" : [ 6, 16 ],
      "id_str" : "3452911",
      "id" : 3452911
    }, {
      "name" : "Tootsie",
      "screen_name" : "OfficialTootsie",
      "indices" : [ 93, 109 ],
      "id_str" : "381171122",
      "id" : 381171122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413139661976903680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7585998524, -122.4205446665 ]
  },
  "id_str" : "413153485731790848",
  "in_reply_to_user_id" : 20283354,
  "text" : "@Ravi @kevinweil Actually that's my follow*ing* count, should I bestow the honors of 2000 to @OfficialTootsie?",
  "id" : 413153485731790848,
  "in_reply_to_status_id" : 413139661976903680,
  "created_at" : "2013-12-18 03:47:21 +0000",
  "in_reply_to_screen_name" : "Ravi",
  "in_reply_to_user_id_str" : "20283354",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 22, 29 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 52, 59 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/sippey\/status\/413134403389636608\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/CFC2aYPk6V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbu_jQXIMAAfIqv.jpg",
      "id_str" : "413134403242831872",
      "id" : 413134403242831872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbu_jQXIMAAfIqv.jpg",
      "sizes" : [ {
        "h" : 1023,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1023,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 599,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/CFC2aYPk6V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413134403389636608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7585868949, -122.4204637237 ]
  },
  "id_str" : "413137967419371521",
  "in_reply_to_user_id" : 4711,
  "text" : "The secret is out. RT @sippey: Behind the tweets of @buster http:\/\/t.co\/CFC2aYPk6V",
  "id" : 413137967419371521,
  "in_reply_to_status_id" : 413134403389636608,
  "created_at" : "2013-12-18 02:45:41 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 3, 11 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413119477509668864",
  "text" : "RT @dcurtis: Mega Millions is the new Bitcoin.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "413119282902347777",
    "text" : "Mega Millions is the new Bitcoin.",
    "id" : 413119282902347777,
    "created_at" : "2013-12-18 01:31:27 +0000",
    "user" : {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "protected" : false,
      "id_str" : "9395832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434842058189066240\/zadwXTSa_normal.png",
      "id" : 9395832,
      "verified" : false
    }
  },
  "id" : 413119477509668864,
  "created_at" : "2013-12-18 01:32:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413049744634560512",
  "geo" : { },
  "id_str" : "413050355698515968",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh I can't account for other peoples' senses of humor, I guess.",
  "id" : 413050355698515968,
  "in_reply_to_status_id" : 413049744634560512,
  "created_at" : "2013-12-17 20:57:33 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413049532084015104",
  "text" : "Updated my bio with some funny numbers.",
  "id" : 413049532084015104,
  "created_at" : "2013-12-17 20:54:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412843510337789952",
  "geo" : { },
  "id_str" : "412848140090232832",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Ha, agreed.",
  "id" : 412848140090232832,
  "in_reply_to_status_id" : 412843510337789952,
  "created_at" : "2013-12-17 07:34:01 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "bluishorange",
      "screen_name" : "bluishorange",
      "indices" : [ 10, 23 ],
      "id_str" : "807657",
      "id" : 807657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opml",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412829680388284416",
  "geo" : { },
  "id_str" : "412831768736059392",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @bluishorange I have a stellar bot that uses spyonit to track trackbacks on my favorite rss 2.0 feeds. #opml",
  "id" : 412831768736059392,
  "in_reply_to_status_id" : 412829680388284416,
  "created_at" : "2013-12-17 06:28:58 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 83, 93 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "3yoftw",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412825449551519744",
  "text" : "Tonight Niko asked me if Instagram photos go through the mail. And how they get on @kellianne\u2019s phone. And if the air carries them. #3yoftw",
  "id" : 412825449551519744,
  "created_at" : "2013-12-17 06:03:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bluishorange",
      "screen_name" : "bluishorange",
      "indices" : [ 0, 13 ],
      "id_str" : "807657",
      "id" : 807657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412823536437194752",
  "geo" : { },
  "id_str" : "412824556672282625",
  "in_reply_to_user_id" : 807657,
  "text" : "@bluishorange That's our generation's equivalent of having to walk to school in the snow, uphill both ways. And liking it.",
  "id" : 412824556672282625,
  "in_reply_to_status_id" : 412823536437194752,
  "created_at" : "2013-12-17 06:00:18 +0000",
  "in_reply_to_screen_name" : "bluishorange",
  "in_reply_to_user_id_str" : "807657",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412821144127807488",
  "text" : "I remember visiting websites every day by typing in URLs. They didn\u2019t have to email or push notify me or anything. It was crazy back then.",
  "id" : 412821144127807488,
  "created_at" : "2013-12-17 05:46:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/412806226561343489\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/T9jDKLEDGR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbqVE2ECQAAktfR.jpg",
      "id_str" : "412806226322276352",
      "id" : 412806226322276352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbqVE2ECQAAktfR.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/T9jDKLEDGR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597045546, -122.2757250651 ]
  },
  "id_str" : "412806226561343489",
  "text" : "8:36pm Making trains http:\/\/t.co\/T9jDKLEDGR",
  "id" : 412806226561343489,
  "created_at" : "2013-12-17 04:47:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Hoffman",
      "screen_name" : "L_Hoff",
      "indices" : [ 0, 7 ],
      "id_str" : "20035911",
      "id" : 20035911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412784256478224384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596804012, -122.2754520738 ]
  },
  "id_str" : "412793993915674625",
  "in_reply_to_user_id" : 20035911,
  "text" : "@L_Hoff What's a good example of an exception?",
  "id" : 412793993915674625,
  "in_reply_to_status_id" : 412784256478224384,
  "created_at" : "2013-12-17 03:58:52 +0000",
  "in_reply_to_screen_name" : "L_Hoff",
  "in_reply_to_user_id_str" : "20035911",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Gordon",
      "screen_name" : "onejgordon",
      "indices" : [ 0, 11 ],
      "id_str" : "14123972",
      "id" : 14123972
    }, {
      "name" : "David Deutsch",
      "screen_name" : "DavidDeutschOxf",
      "indices" : [ 12, 28 ],
      "id_str" : "841709695",
      "id" : 841709695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412776756928458752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596635955, -122.275442686 ]
  },
  "id_str" : "412793912630079488",
  "in_reply_to_user_id" : 14123972,
  "text" : "@onejgordon @DavidDeutschOxf What's an example?",
  "id" : 412793912630079488,
  "in_reply_to_status_id" : 412776756928458752,
  "created_at" : "2013-12-17 03:58:32 +0000",
  "in_reply_to_screen_name" : "onejgordon",
  "in_reply_to_user_id_str" : "14123972",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Deutsch",
      "screen_name" : "DavidDeutschOxf",
      "indices" : [ 56, 72 ],
      "id_str" : "841709695",
      "id" : 841709695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7844370576, -122.4078534849 ]
  },
  "id_str" : "412770444484173824",
  "text" : "T\/F \"All evils are caused by insufficient knowledge.\" - @DavidDeutschOxf in The Beginning of Infinity.",
  "id" : 412770444484173824,
  "created_at" : "2013-12-17 02:25:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 3, 11 ],
      "id_str" : "353195232",
      "id" : 353195232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantdiet",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/vwOU6vbPSd",
      "expanded_url" : "https:\/\/lift.do\/p\/quantified-diet",
      "display_url" : "lift.do\/p\/quantified-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412726758719229952",
  "text" : "RT @liftapp: Join the largest diet study ever attempted #quantdiet: https:\/\/t.co\/vwOU6vbPSd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quantdiet",
        "indices" : [ 43, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/vwOU6vbPSd",
        "expanded_url" : "https:\/\/lift.do\/p\/quantified-diet",
        "display_url" : "lift.do\/p\/quantified-d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "412726506008215554",
    "text" : "Join the largest diet study ever attempted #quantdiet: https:\/\/t.co\/vwOU6vbPSd",
    "id" : 412726506008215554,
    "created_at" : "2013-12-16 23:30:41 +0000",
    "user" : {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "protected" : false,
      "id_str" : "353195232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000475306297\/54db1dd768f872fc5934be30ae040de8_normal.png",
      "id" : 353195232,
      "verified" : false
    }
  },
  "id" : 412726758719229952,
  "created_at" : "2013-12-16 23:31:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason SurfrApp",
      "screen_name" : "iwearyourshirt",
      "indices" : [ 3, 18 ],
      "id_str" : "16431844",
      "id" : 16431844
    }, {
      "name" : "Surfr",
      "screen_name" : "surfrapp",
      "indices" : [ 72, 81 ],
      "id_str" : "928780692",
      "id" : 928780692
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/iwearyourshirt\/status\/412598553265971200\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/bI91dIUMk7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbnYMqfCEAAdMSJ.jpg",
      "id_str" : "412598552955588608",
      "id" : 412598552955588608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbnYMqfCEAAdMSJ.jpg",
      "sizes" : [ {
        "h" : 618,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 1085
      }, {
        "h" : 205,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/bI91dIUMk7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412605483099631617",
  "text" : "RT @iwearyourshirt: ANNOUNCING: My last name for 2014:\n\nJason SurfrApp\n\n@surfrapp chased all bidders away w\/ winning bid of $50,000!!! http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Surfr",
        "screen_name" : "surfrapp",
        "indices" : [ 52, 61 ],
        "id_str" : "928780692",
        "id" : 928780692
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/iwearyourshirt\/status\/412598553265971200\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/bI91dIUMk7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbnYMqfCEAAdMSJ.jpg",
        "id_str" : "412598552955588608",
        "id" : 412598552955588608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbnYMqfCEAAdMSJ.jpg",
        "sizes" : [ {
          "h" : 618,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 655,
          "resize" : "fit",
          "w" : 1085
        }, {
          "h" : 205,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/bI91dIUMk7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "412598553265971200",
    "text" : "ANNOUNCING: My last name for 2014:\n\nJason SurfrApp\n\n@surfrapp chased all bidders away w\/ winning bid of $50,000!!! http:\/\/t.co\/bI91dIUMk7",
    "id" : 412598553265971200,
    "created_at" : "2013-12-16 15:02:15 +0000",
    "user" : {
      "name" : "Jason SurfrApp",
      "screen_name" : "iwearyourshirt",
      "protected" : false,
      "id_str" : "16431844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000506340817\/58c8f10b4e0b72ec090c114b6f127607_normal.jpeg",
      "id" : 16431844,
      "verified" : true
    }
  },
  "id" : 412605483099631617,
  "created_at" : "2013-12-16 15:29:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/fizzFRF462",
      "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/the-amazon-primeinator",
      "display_url" : "mcsweeneys.net\/articles\/the-a\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596015378, -122.2757238526 ]
  },
  "id_str" : "412603709206851584",
  "text" : "\"You'll order these items after you learn Amazon Prime has attained self-awareness &amp; decided to slaughter humanity.\" http:\/\/t.co\/fizzFRF462",
  "id" : 412603709206851584,
  "created_at" : "2013-12-16 15:22:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JAMIE",
      "screen_name" : "jamster83",
      "indices" : [ 52, 62 ],
      "id_str" : "213401443",
      "id" : 213401443
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jamster83\/status\/412590968429621248\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Tq0aO9Nn19",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbnRTLoIYAA6YEO.jpg",
      "id_str" : "412590968349941760",
      "id" : 412590968349941760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbnRTLoIYAA6YEO.jpg",
      "sizes" : [ {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Tq0aO9Nn19"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412590968429621248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596682018, -122.2755868921 ]
  },
  "id_str" : "412601057533906944",
  "in_reply_to_user_id" : 213401443,
  "text" : "Good morning baby tortoises wearing raspberries. RT @jamster83: Two baby tortoises wearing raspberries. That is all. http:\/\/t.co\/Tq0aO9Nn19",
  "id" : 412601057533906944,
  "in_reply_to_status_id" : 412590968429621248,
  "created_at" : "2013-12-16 15:12:12 +0000",
  "in_reply_to_screen_name" : "jamster83",
  "in_reply_to_user_id_str" : "213401443",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    }, {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 5, 16 ],
      "id_str" : "765",
      "id" : 765
    }, {
      "name" : "Pocket",
      "screen_name" : "Pocket",
      "indices" : [ 17, 24 ],
      "id_str" : "27530178",
      "id" : 27530178
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/412471919888195584\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/co0UwB30my",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbllBojCUAEmRDQ.jpg",
      "id_str" : "412471919619756033",
      "id" : 412471919619756033,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbllBojCUAEmRDQ.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/co0UwB30my"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412469082655449088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597012721, -122.2755432689 ]
  },
  "id_str" : "412471919888195584",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg @seanbonner @Pocket Cool! Mine: http:\/\/t.co\/co0UwB30my",
  "id" : 412471919888195584,
  "in_reply_to_status_id" : 412469082655449088,
  "created_at" : "2013-12-16 06:39:03 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CardsAgainstHumanity",
      "screen_name" : "CAH",
      "indices" : [ 24, 28 ],
      "id_str" : "298503082",
      "id" : 298503082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/xrnD7S46qH",
      "expanded_url" : "http:\/\/clusterfuckgame.com\/",
      "display_url" : "clusterfuckgame.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859717994, -122.2755541654 ]
  },
  "id_str" : "412469116797079552",
  "text" : "Hilarious new game from @CAH and others: http:\/\/t.co\/xrnD7S46qH",
  "id" : 412469116797079552,
  "created_at" : "2013-12-16 06:27:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    }, {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 5, 16 ],
      "id_str" : "765",
      "id" : 765
    }, {
      "name" : "Pocket",
      "screen_name" : "Pocket",
      "indices" : [ 17, 24 ],
      "id_str" : "27530178",
      "id" : 27530178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412466506115457024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595745567, -122.2758425917 ]
  },
  "id_str" : "412467716847448064",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg @seanbonner @Pocket Is there a way to share you favorites list? Would be fun to compare.",
  "id" : 412467716847448064,
  "in_reply_to_status_id" : 412466506115457024,
  "created_at" : "2013-12-16 06:22:21 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    }, {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 12, 16 ],
      "id_str" : "937961",
      "id" : 937961
    }, {
      "name" : "Pocket",
      "screen_name" : "Pocket",
      "indices" : [ 17, 24 ],
      "id_str" : "27530178",
      "id" : 27530178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412465326211616768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596943139, -122.2758201029 ]
  },
  "id_str" : "412466107228753920",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner @msg @Pocket Yeah I dive in when I'm offline on BART or just tired of short attention span stuff. Still don't read a bunch.",
  "id" : 412466107228753920,
  "in_reply_to_status_id" : 412465326211616768,
  "created_at" : "2013-12-16 06:15:57 +0000",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    }, {
      "name" : "Pocket",
      "screen_name" : "Pocket",
      "indices" : [ 5, 12 ],
      "id_str" : "27530178",
      "id" : 27530178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412464317275987968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596181138, -122.2757704924 ]
  },
  "id_str" : "412464642355499008",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg @Pocket Ha. I do the same thing.",
  "id" : 412464642355499008,
  "in_reply_to_status_id" : 412464317275987968,
  "created_at" : "2013-12-16 06:10:08 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kontra",
      "screen_name" : "counternotions",
      "indices" : [ 8, 23 ],
      "id_str" : "19225408",
      "id" : 19225408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/lfMOZUNBS1",
      "expanded_url" : "http:\/\/tydligapp.com",
      "display_url" : "tydligapp.com"
    } ]
  },
  "in_reply_to_status_id_str" : "412359907896074240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859584699, -122.2758477256 ]
  },
  "id_str" : "412464354324250624",
  "in_reply_to_user_id" : 19225408,
  "text" : "Rad. RT @counternotions: Calculator reimagined for the mobile screen, wherein iOS aesthetics shine. http:\/\/t.co\/lfMOZUNBS1",
  "id" : 412464354324250624,
  "in_reply_to_status_id" : 412359907896074240,
  "created_at" : "2013-12-16 06:08:59 +0000",
  "in_reply_to_screen_name" : "counternotions",
  "in_reply_to_user_id_str" : "19225408",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/412449674344140800\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/MndEKzeYRn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BblQyyCCUAICbBN.jpg",
      "id_str" : "412449674235105282",
      "id" : 412449674235105282,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BblQyyCCUAICbBN.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/MndEKzeYRn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598264139, -122.27549457 ]
  },
  "id_str" : "412449674344140800",
  "text" : "8:36pm Just got back from the Christmas carousel in Tilden Park where Niko was not as nonplussed as he seems here http:\/\/t.co\/MndEKzeYRn",
  "id" : 412449674344140800,
  "created_at" : "2013-12-16 05:10:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412372797680136194",
  "geo" : { },
  "id_str" : "412375157852749825",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley Definitely don\u2019t read the article. It cannot be unread.",
  "id" : 412375157852749825,
  "in_reply_to_status_id" : 412372797680136194,
  "created_at" : "2013-12-16 00:14:33 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412359358052192256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596667387, -122.2756337096 ]
  },
  "id_str" : "412359547588579329",
  "in_reply_to_user_id" : 2185,
  "text" : "Crazy ants are crazy. I'd burn my house down and move far away immediately.",
  "id" : 412359547588579329,
  "in_reply_to_status_id" : 412359358052192256,
  "created_at" : "2013-12-15 23:12:32 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/HMXEWIm931",
      "expanded_url" : "http:\/\/mobile.nytimes.com\/2013\/12\/08\/magazine\/crazy-ants.html?_r=0",
      "display_url" : "mobile.nytimes.com\/2013\/12\/08\/mag\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596699422, -122.2756078412 ]
  },
  "id_str" : "412359358052192256",
  "text" : "\"One evening, his iron stopped working, then sparks shot from the appliance &amp; a tide of crazy ants came rushing out.\" http:\/\/t.co\/HMXEWIm931",
  "id" : 412359358052192256,
  "created_at" : "2013-12-15 23:11:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 0, 11 ],
      "id_str" : "784078",
      "id" : 784078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412220564817059840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596481036, -122.2757058758 ]
  },
  "id_str" : "412326320190681088",
  "in_reply_to_user_id" : 784078,
  "text" : "@alicetiara *Way* too scary. It's just constant slow motion claustrophobia.",
  "id" : 412326320190681088,
  "in_reply_to_status_id" : 412220564817059840,
  "created_at" : "2013-12-15 21:00:30 +0000",
  "in_reply_to_screen_name" : "alicetiara",
  "in_reply_to_user_id_str" : "784078",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/kzGH9cGdvI",
      "expanded_url" : "http:\/\/twitter.com\/settings",
      "display_url" : "twitter.com\/settings"
    } ]
  },
  "in_reply_to_status_id_str" : "412262724794474496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596181129, -122.2755998096 ]
  },
  "id_str" : "412263393890824192",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon I'd manually unfollow them and also review your authorized apps on http:\/\/t.co\/kzGH9cGdvI for apps you don't use anymore.",
  "id" : 412263393890824192,
  "in_reply_to_status_id" : 412262724794474496,
  "created_at" : "2013-12-15 16:50:27 +0000",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 8, 16 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 17, 20 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412260024560279552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597050021, -122.2754659039 ]
  },
  "id_str" : "412261843218862080",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon @twitter @rk Are they at the top of your following list? Do you think someone hacked your account or is it something else?",
  "id" : 412261843218862080,
  "in_reply_to_status_id" : 412260024560279552,
  "created_at" : "2013-12-15 16:44:17 +0000",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Burkeman",
      "screen_name" : "oliverburkeman",
      "indices" : [ 3, 18 ],
      "id_str" : "112037009",
      "id" : 112037009
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetedwithoutcomment",
      "indices" : [ 114, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Ay1gVXAfG0",
      "expanded_url" : "http:\/\/online.wsj.com\/news\/articles\/SB10001424052702304744304579250110157147496",
      "display_url" : "online.wsj.com\/news\/articles\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412258172674379776",
  "text" : "RT @oliverburkeman: Give Your Husband A Performance Review: Why limit year-end progress reports to the workplace? #tweetedwithoutcomment ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tweetedwithoutcomment",
        "indices" : [ 94, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Ay1gVXAfG0",
        "expanded_url" : "http:\/\/online.wsj.com\/news\/articles\/SB10001424052702304744304579250110157147496",
        "display_url" : "online.wsj.com\/news\/articles\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "412249582991835136",
    "text" : "Give Your Husband A Performance Review: Why limit year-end progress reports to the workplace? #tweetedwithoutcomment http:\/\/t.co\/Ay1gVXAfG0",
    "id" : 412249582991835136,
    "created_at" : "2013-12-15 15:55:34 +0000",
    "user" : {
      "name" : "Oliver Burkeman",
      "screen_name" : "oliverburkeman",
      "protected" : false,
      "id_str" : "112037009",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2827376109\/9d06750babb1a322ae32035928a47e43_normal.jpeg",
      "id" : 112037009,
      "verified" : false
    }
  },
  "id" : 412258172674379776,
  "created_at" : "2013-12-15 16:29:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412108095184072704",
  "geo" : { },
  "id_str" : "412111210390106112",
  "in_reply_to_user_id" : 2185,
  "text" : "The Walking Dead reminds me of the feeling I had when I took salvia. Which I will also never ever do again.",
  "id" : 412111210390106112,
  "in_reply_to_status_id" : 412108095184072704,
  "created_at" : "2013-12-15 06:45:43 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412108095184072704",
  "text" : "I watched the first episode of The Walking Dead last night and cannot stop thinking about how I will never ever watch that again.",
  "id" : 412108095184072704,
  "created_at" : "2013-12-15 06:33:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/412088111879839745\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/5Mfs34pUup",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbgH9EhCQAAoimo.jpg",
      "id_str" : "412088111670116352",
      "id" : 412088111670116352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbgH9EhCQAAoimo.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5Mfs34pUup"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859722019, -122.2756022947 ]
  },
  "id_str" : "412088111879839745",
  "text" : "8:36pm Letting Niko play in the dark since he's not tired enough to sleep yet. http:\/\/t.co\/5Mfs34pUup",
  "id" : 412088111879839745,
  "created_at" : "2013-12-15 05:13:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DanielleStrle",
      "screen_name" : "strle",
      "indices" : [ 0, 6 ],
      "id_str" : "49422284",
      "id" : 49422284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412040701028102144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596889418, -122.2756471768 ]
  },
  "id_str" : "412046886707527680",
  "in_reply_to_user_id" : 49422284,
  "text" : "@strle I was halfway through your tweet fearing that you'd say it was terrible. Happy to hear it's not!",
  "id" : 412046886707527680,
  "in_reply_to_status_id" : 412040701028102144,
  "created_at" : "2013-12-15 02:30:07 +0000",
  "in_reply_to_screen_name" : "strle",
  "in_reply_to_user_id_str" : "49422284",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowplaying",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/KvXNBlvizS",
      "expanded_url" : "https:\/\/vine.co\/v\/h2FX1Bz6Z7A",
      "display_url" : "vine.co\/v\/h2FX1Bz6Z7A"
    } ]
  },
  "geo" : { },
  "id_str" : "412039749390848000",
  "text" : "Getting into Dance Apocalyptic by Janelle Mon\u00E1e #nowplaying https:\/\/t.co\/KvXNBlvizS",
  "id" : 412039749390848000,
  "created_at" : "2013-12-15 02:01:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/412038235318009857\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/MqSqdde1Eg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbfal3BCEAAbt1b.jpg",
      "id_str" : "412038234885984256",
      "id" : 412038234885984256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbfal3BCEAAbt1b.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/MqSqdde1Eg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596765379, -122.2757405527 ]
  },
  "id_str" : "412038235318009857",
  "text" : "The traditional putting of a vortex to another dimension atop the tree http:\/\/t.co\/MqSqdde1Eg",
  "id" : 412038235318009857,
  "created_at" : "2013-12-15 01:55:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Winnie Lim",
      "screen_name" : "wynlim",
      "indices" : [ 3, 10 ],
      "id_str" : "7729652",
      "id" : 7729652
    }, {
      "name" : "Karen X. Cheng",
      "screen_name" : "karenxcheng",
      "indices" : [ 111, 123 ],
      "id_str" : "21829724",
      "id" : 21829724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/sEdhnEJjv7",
      "expanded_url" : "http:\/\/www.karenx.com\/blog\/i-am-selfish\/",
      "display_url" : "karenx.com\/blog\/i-am-self\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411919753360322560",
  "text" : "RT @wynlim: \"ripping your weaknesses open for everyone to see is where you can draw your greatest strength.\" \u2013 @karenxcheng http:\/\/t.co\/sEd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Karen X. Cheng",
        "screen_name" : "karenxcheng",
        "indices" : [ 99, 111 ],
        "id_str" : "21829724",
        "id" : 21829724
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/sEdhnEJjv7",
        "expanded_url" : "http:\/\/www.karenx.com\/blog\/i-am-selfish\/",
        "display_url" : "karenx.com\/blog\/i-am-self\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "411918243821916161",
    "text" : "\"ripping your weaknesses open for everyone to see is where you can draw your greatest strength.\" \u2013 @karenxcheng http:\/\/t.co\/sEdhnEJjv7",
    "id" : 411918243821916161,
    "created_at" : "2013-12-14 17:58:57 +0000",
    "user" : {
      "name" : "Winnie Lim",
      "screen_name" : "wynlim",
      "protected" : false,
      "id_str" : "7729652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/68373117\/Photo_138_normal.jpg",
      "id" : 7729652,
      "verified" : false
    }
  },
  "id" : 411919753360322560,
  "created_at" : "2013-12-14 18:04:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 1, 11 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411915553427554305",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596403335, -122.2755349296 ]
  },
  "id_str" : "411918723566432256",
  "in_reply_to_user_id" : 14110325,
  "text" : ".@jayholler Uber is the Mechanical Turk of self-driving cars.",
  "id" : 411918723566432256,
  "in_reply_to_status_id" : 411915553427554305,
  "created_at" : "2013-12-14 18:00:51 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rodolfo Carvajal",
      "screen_name" : "rocarvaj",
      "indices" : [ 0, 9 ],
      "id_str" : "10342752",
      "id" : 10342752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411908704552767488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859806465, -122.2755629664 ]
  },
  "id_str" : "411910823305420800",
  "in_reply_to_user_id" : 10342752,
  "text" : "@rocarvaj I'm glad it's useful! \uD83D\uDC13",
  "id" : 411910823305420800,
  "in_reply_to_status_id" : 411908704552767488,
  "created_at" : "2013-12-14 17:29:27 +0000",
  "in_reply_to_screen_name" : "rocarvaj",
  "in_reply_to_user_id_str" : "10342752",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411769029150253056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596357127, -122.2755063127 ]
  },
  "id_str" : "411770439027798016",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Self-driving jet packs?",
  "id" : 411770439027798016,
  "in_reply_to_status_id" : 411769029150253056,
  "created_at" : "2013-12-14 08:11:37 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411768513347350528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597127018, -122.2756809525 ]
  },
  "id_str" : "411768850682613760",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Will they hand deliver product placements that are relevant to our unspoken desires?",
  "id" : 411768850682613760,
  "in_reply_to_status_id" : 411768513347350528,
  "created_at" : "2013-12-14 08:05:18 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411749377841967104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595906205, -122.2755680567 ]
  },
  "id_str" : "411768147188805632",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey What do you think the bigger implications are?",
  "id" : 411768147188805632,
  "in_reply_to_status_id" : 411749377841967104,
  "created_at" : "2013-12-14 08:02:31 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Self Aware ROOMBA",
      "screen_name" : "SelfAwareROOMBA",
      "indices" : [ 112, 128 ],
      "id_str" : "620654544",
      "id" : 620654544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411739845321441280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596033686, -122.2756572832 ]
  },
  "id_str" : "411741051146096640",
  "in_reply_to_user_id" : 2185,
  "text" : "Google has acquired 8 robotics companies. I'm sort of excited about the return of non-appliancey robots. Sorry, @SelfAwareROOMBA.",
  "id" : 411741051146096640,
  "in_reply_to_status_id" : 411739845321441280,
  "created_at" : "2013-12-14 06:14:51 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/H4C3RlOS3F",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/12\/14\/technology\/google-adds-to-its-menagerie-of-robots.html",
      "display_url" : "nytimes.com\/2013\/12\/14\/tec\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596060252, -122.275622262 ]
  },
  "id_str" : "411739845321441280",
  "text" : "Amazon's drones vs Google's catbots http:\/\/t.co\/H4C3RlOS3F",
  "id" : 411739845321441280,
  "created_at" : "2013-12-14 06:10:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Inman",
      "screen_name" : "shauninman",
      "indices" : [ 3, 14 ],
      "id_str" : "12047992",
      "id" : 12047992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411724612670455808",
  "text" : "RT @shauninman: I totally recommend maintaining a list of people who have influenced or supported you and then typesetting that list every \u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "411720950556524544",
    "text" : "I totally recommend maintaining a list of people who have influenced or supported you and then typesetting that list every month or so.",
    "id" : 411720950556524544,
    "created_at" : "2013-12-14 04:54:58 +0000",
    "user" : {
      "name" : "Shaun Inman",
      "screen_name" : "shauninman",
      "protected" : false,
      "id_str" : "12047992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433068430871101440\/wUV1HiUR_normal.png",
      "id" : 12047992,
      "verified" : false
    }
  },
  "id" : 411724612670455808,
  "created_at" : "2013-12-14 05:09:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/D4wyV7StRx",
      "expanded_url" : "http:\/\/flic.kr\/p\/ij3CZs",
      "display_url" : "flic.kr\/p\/ij3CZs"
    } ]
  },
  "geo" : { },
  "id_str" : "411720056150970368",
  "text" : "8:36pm Pre-bed dance party http:\/\/t.co\/D4wyV7StRx",
  "id" : 411720056150970368,
  "created_at" : "2013-12-14 04:51:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magic Pics",
      "screen_name" : "magicpixx",
      "indices" : [ 0, 10 ],
      "id_str" : "2205976656",
      "id" : 2205976656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411694595891036160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598145955, -122.2753257585 ]
  },
  "id_str" : "411696109862387713",
  "in_reply_to_user_id" : 2205976656,
  "text" : "@magicpixx Are you getting kickbacks for these product recommendations? Hope so.",
  "id" : 411696109862387713,
  "in_reply_to_status_id" : 411694595891036160,
  "created_at" : "2013-12-14 03:16:16 +0000",
  "in_reply_to_screen_name" : "magicpixx",
  "in_reply_to_user_id_str" : "2205976656",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thinkcation",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8594476303, -122.2759712048 ]
  },
  "id_str" : "411694591784394752",
  "text" : "Thoughts must be pretty loud because it takes music in headphones at volume 9 if not 10 to drown them out. #thinkcation",
  "id" : 411694591784394752,
  "created_at" : "2013-12-14 03:10:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiffany Dohzen",
      "screen_name" : "tdohz",
      "indices" : [ 0, 6 ],
      "id_str" : "101424163",
      "id" : 101424163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411640420687290368",
  "geo" : { },
  "id_str" : "411643103338954752",
  "in_reply_to_user_id" : 101424163,
  "text" : "@tdohz Sad to see you go! You will be missed. Best of luck with your next thing.",
  "id" : 411643103338954752,
  "in_reply_to_status_id" : 411640420687290368,
  "created_at" : "2013-12-13 23:45:38 +0000",
  "in_reply_to_screen_name" : "tdohz",
  "in_reply_to_user_id_str" : "101424163",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/ACw2AePh8N",
      "expanded_url" : "http:\/\/paywithatweet.com",
      "display_url" : "paywithatweet.com"
    } ]
  },
  "in_reply_to_status_id_str" : "411635548525047808",
  "geo" : { },
  "id_str" : "411636751262703616",
  "in_reply_to_user_id" : 2185,
  "text" : "Ha, http:\/\/t.co\/ACw2AePh8N is pretty cool. Wish I had something to sell for a tweet.",
  "id" : 411636751262703616,
  "in_reply_to_status_id" : 411635548525047808,
  "created_at" : "2013-12-13 23:20:24 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.paywithatweet.com\" rel=\"nofollow\"\u003EPay with a Tweet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emiland De Cubber",
      "screen_name" : "EmilandDC",
      "indices" : [ 49, 59 ],
      "id_str" : "202540077",
      "id" : 202540077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/NasjN5LCum",
      "expanded_url" : "http:\/\/www.keynude.com",
      "display_url" : "keynude.com"
    } ]
  },
  "geo" : { },
  "id_str" : "411635548525047808",
  "text" : "Keynude is a better default theme for Keynote by @emilanddc. I have to pay with a tweet to download it. http:\/\/t.co\/NasjN5LCum",
  "id" : 411635548525047808,
  "created_at" : "2013-12-13 23:15:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renee DiResta",
      "screen_name" : "noUpside",
      "indices" : [ 0, 9 ],
      "id_str" : "24254084",
      "id" : 24254084
    }, {
      "name" : "Jason Kottke",
      "screen_name" : "jkottke",
      "indices" : [ 10, 18 ],
      "id_str" : "1305941",
      "id" : 1305941
    }, {
      "name" : "Fred Oliveira",
      "screen_name" : "f",
      "indices" : [ 19, 21 ],
      "id_str" : "5511",
      "id" : 5511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411612790114099201",
  "geo" : { },
  "id_str" : "411614096115499008",
  "in_reply_to_user_id" : 24254084,
  "text" : "@noupside @jkottke @f Even more reason for me to go ahead with my idea of making a children's book version of it.",
  "id" : 411614096115499008,
  "in_reply_to_status_id" : 411612790114099201,
  "created_at" : "2013-12-13 21:50:22 +0000",
  "in_reply_to_screen_name" : "noUpside",
  "in_reply_to_user_id_str" : "24254084",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Kottke",
      "screen_name" : "jkottke",
      "indices" : [ 0, 8 ],
      "id_str" : "1305941",
      "id" : 1305941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411600060401479681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7766151106, -122.4174929119 ]
  },
  "id_str" : "411611445273456640",
  "in_reply_to_user_id" : 1305941,
  "text" : "@jkottke Yeah, totally. I learned to love his grumpy curmudgeon style in a cartoon character kind of way, but it definitely distracts.",
  "id" : 411611445273456640,
  "in_reply_to_status_id" : 411600060401479681,
  "created_at" : "2013-12-13 21:39:50 +0000",
  "in_reply_to_screen_name" : "jkottke",
  "in_reply_to_user_id_str" : "1305941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Kottke",
      "screen_name" : "jkottke",
      "indices" : [ 0, 8 ],
      "id_str" : "1305941",
      "id" : 1305941
    }, {
      "name" : "Nassim N. Taleb",
      "screen_name" : "nntaleb",
      "indices" : [ 24, 32 ],
      "id_str" : "381289719",
      "id" : 381289719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411584651581333504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763764305, -122.4167403549 ]
  },
  "id_str" : "411591604390985728",
  "in_reply_to_user_id" : 1305941,
  "text" : "@jkottke Antifragile by @nntaleb by far. I've read it twice and still trying to wrap my head around all the implications.",
  "id" : 411591604390985728,
  "in_reply_to_status_id" : 411584651581333504,
  "created_at" : "2013-12-13 20:21:00 +0000",
  "in_reply_to_screen_name" : "jkottke",
  "in_reply_to_user_id_str" : "1305941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Kottke",
      "screen_name" : "jkottke",
      "indices" : [ 3, 11 ],
      "id_str" : "1305941",
      "id" : 1305941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411591604407775232",
  "text" : "RT @jkottke: Did you read anything this year that genuinely changed your thinking\/feelings about something significant? If so, what was it?",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "411584651581333504",
    "text" : "Did you read anything this year that genuinely changed your thinking\/feelings about something significant? If so, what was it?",
    "id" : 411584651581333504,
    "created_at" : "2013-12-13 19:53:22 +0000",
    "user" : {
      "name" : "Jason Kottke",
      "screen_name" : "jkottke",
      "protected" : false,
      "id_str" : "1305941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458684956550496256\/SAk9xbJk_normal.jpeg",
      "id" : 1305941,
      "verified" : true
    }
  },
  "id" : 411591604407775232,
  "created_at" : "2013-12-13 20:21:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Musuem of Modern Viz",
      "screen_name" : "momv",
      "indices" : [ 3, 8 ],
      "id_str" : "1330148732",
      "id" : 1330148732
    }, {
      "name" : "Guy Dickinson",
      "screen_name" : "gdickinson",
      "indices" : [ 33, 44 ],
      "id_str" : "9213492",
      "id" : 9213492
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/gdickinson\/status\/336912001727098883\/photo\/1",
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/cu3klYp1eY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKzzrjgCcAAL781.png",
      "id_str" : "336912001735487488",
      "id" : 336912001735487488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKzzrjgCcAAL781.png",
      "sizes" : [ {
        "h" : 178,
        "resize" : "fit",
        "w" : 617
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 98,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 617
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/cu3klYp1eY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411588533682323456",
  "text" : "RT @momv: this striking piece by @gdickinson, evoking \u010Capek's opus, whimsically challenges our fundamental notions of success http:\/\/t.co\/c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Guy Dickinson",
        "screen_name" : "gdickinson",
        "indices" : [ 23, 34 ],
        "id_str" : "9213492",
        "id" : 9213492
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/gdickinson\/status\/336912001727098883\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/cu3klYp1eY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BKzzrjgCcAAL781.png",
        "id_str" : "336912001735487488",
        "id" : 336912001735487488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKzzrjgCcAAL781.png",
        "sizes" : [ {
          "h" : 178,
          "resize" : "fit",
          "w" : 617
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 98,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 617
        }, {
          "h" : 173,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/cu3klYp1eY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "411576927883776001",
    "geo" : { },
    "id_str" : "411581330233651201",
    "in_reply_to_user_id" : 9213492,
    "text" : "this striking piece by @gdickinson, evoking \u010Capek's opus, whimsically challenges our fundamental notions of success http:\/\/t.co\/cu3klYp1eY",
    "id" : 411581330233651201,
    "in_reply_to_status_id" : 411576927883776001,
    "created_at" : "2013-12-13 19:40:10 +0000",
    "in_reply_to_screen_name" : "gdickinson",
    "in_reply_to_user_id_str" : "9213492",
    "user" : {
      "name" : "Musuem of Modern Viz",
      "screen_name" : "momv",
      "protected" : false,
      "id_str" : "1330148732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3481864202\/bbaa35835cf2cb540f7ba11c94cbd592_normal.png",
      "id" : 1330148732,
      "verified" : false
    }
  },
  "id" : 411588533682323456,
  "created_at" : "2013-12-13 20:08:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/isaach\/status\/411571860355022848\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/d7gJLConax",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbYybSECMAAfHYS.jpg",
      "id_str" : "411571860237594624",
      "id" : 411571860237594624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbYybSECMAAfHYS.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/d7gJLConax"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411578227740508160",
  "text" : "RT @isaach: omg siri http:\/\/t.co\/d7gJLConax",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/isaach\/status\/411571860355022848\/photo\/1",
        "indices" : [ 9, 31 ],
        "url" : "http:\/\/t.co\/d7gJLConax",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbYybSECMAAfHYS.jpg",
        "id_str" : "411571860237594624",
        "id" : 411571860237594624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbYybSECMAAfHYS.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/d7gJLConax"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "411571860355022848",
    "text" : "omg siri http:\/\/t.co\/d7gJLConax",
    "id" : 411571860355022848,
    "created_at" : "2013-12-13 19:02:32 +0000",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430605387117494272\/lmplHwca_normal.png",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 411578227740508160,
  "created_at" : "2013-12-13 19:27:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411541052110036992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8332458783, -122.2667566098 ]
  },
  "id_str" : "411541404578353152",
  "in_reply_to_user_id" : 2185,
  "text" : "I nominate the Undo Send button in Gmail.",
  "id" : 411541404578353152,
  "in_reply_to_status_id" : 411541052110036992,
  "created_at" : "2013-12-13 17:01:31 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8530956172, -122.2706507512 ]
  },
  "id_str" : "411541052110036992",
  "text" : "Has anything stuck as the greatest this since sliced bread? Should we refer to that thing instead of sliced bread going forward?",
  "id" : 411541052110036992,
  "created_at" : "2013-12-13 17:00:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron Hunter ",
      "screen_name" : "cameronhunter",
      "indices" : [ 0, 14 ],
      "id_str" : "6329782",
      "id" : 6329782
    }, {
      "name" : "Calum Leslie",
      "screen_name" : "zootm",
      "indices" : [ 15, 21 ],
      "id_str" : "5399132",
      "id" : 5399132
    }, {
      "name" : "Paul Richards",
      "screen_name" : "pauldoo",
      "indices" : [ 22, 30 ],
      "id_str" : "20677851",
      "id" : 20677851
    }, {
      "name" : "marksutherland",
      "screen_name" : "marksutherland",
      "indices" : [ 31, 46 ],
      "id_str" : "15083828",
      "id" : 15083828
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411536470902460416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8530956172, -122.2706507512 ]
  },
  "id_str" : "411540875022311424",
  "in_reply_to_user_id" : 6329782,
  "text" : "@cameronhunter @zootm @pauldoo @marksutherland Awesome! I plan on catching up on the last couple quarters this #hackweek.",
  "id" : 411540875022311424,
  "in_reply_to_status_id" : 411536470902460416,
  "created_at" : "2013-12-13 16:59:25 +0000",
  "in_reply_to_screen_name" : "cameronhunter",
  "in_reply_to_user_id_str" : "6329782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411362421211557888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7649952179, -122.4213179125 ]
  },
  "id_str" : "411385588424523776",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Meet halfway in Ashland, Oregon?",
  "id" : 411385588424523776,
  "in_reply_to_status_id" : 411362421211557888,
  "created_at" : "2013-12-13 06:42:22 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 3, 11 ],
      "id_str" : "291",
      "id" : 291
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/411361956700778496\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/aJMamAXPMZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbVzhR1CIAAAmau.jpg",
      "id_str" : "411361956532985856",
      "id" : 411361956532985856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbVzhR1CIAAAmau.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 769
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 769
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/aJMamAXPMZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7617687919, -122.4313892518 ]
  },
  "id_str" : "411361956700778496",
  "text" : "In @goldman's house http:\/\/t.co\/aJMamAXPMZ",
  "id" : 411361956700778496,
  "created_at" : "2013-12-13 05:08:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 8, 16 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Alta CA",
      "screen_name" : "AltaCAsf",
      "indices" : [ 22, 31 ],
      "id_str" : "1656134604",
      "id" : 1656134604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/Dg6ThxktUF",
      "expanded_url" : "http:\/\/4sq.com\/1bzJR6z",
      "display_url" : "4sq.com\/1bzJR6z"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776107, -122.418113 ]
  },
  "id_str" : "411338819108364288",
  "text" : "Where's @rsarver? (at @ALTACASf w\/ 6 others) http:\/\/t.co\/Dg6ThxktUF",
  "id" : 411338819108364288,
  "created_at" : "2013-12-13 03:36:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/fLbeylm6jF",
      "expanded_url" : "http:\/\/4sq.com\/JcZ72M",
      "display_url" : "4sq.com\/JcZ72M"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.772918, -122.415449 ]
  },
  "id_str" : "411326971478827008",
  "text" : "Who wants to get a drink later? (@ Una Pizza Napoletana) http:\/\/t.co\/fLbeylm6jF",
  "id" : 411326971478827008,
  "created_at" : "2013-12-13 02:49:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    }, {
      "name" : "horribleness factory",
      "screen_name" : "ashedryden",
      "indices" : [ 17, 28 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411276265803370496",
  "geo" : { },
  "id_str" : "411277400018657280",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall @ashedryden Definitely invite me if you organize a google hangout for this and I'll try my best to make it.",
  "id" : 411277400018657280,
  "in_reply_to_status_id" : 411276265803370496,
  "created_at" : "2013-12-12 23:32:27 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    }, {
      "name" : "horribleness factory",
      "screen_name" : "ashedryden",
      "indices" : [ 17, 28 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411274078918414336",
  "geo" : { },
  "id_str" : "411275334227480576",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall @ashedryden I would be happy to but I'm not the right person to talk to really. I'll forward this to someone who might be.",
  "id" : 411275334227480576,
  "in_reply_to_status_id" : 411274078918414336,
  "created_at" : "2013-12-12 23:24:15 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 3, 12 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "megan quinn",
      "screen_name" : "msquinn",
      "indices" : [ 32, 40 ],
      "id_str" : "15293504",
      "id" : 15293504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/pLZVkjccCY",
      "expanded_url" : "http:\/\/tmblr.co\/ZbBADt111MmtO",
      "display_url" : "tmblr.co\/ZbBADt111MmtO"
    } ]
  },
  "geo" : { },
  "id_str" : "411245970655956992",
  "text" : "RT @arainert: Great answer from @msquinn to \u201CWhat\u2019s most interesting to me about the future of technology?\" http:\/\/t.co\/pLZVkjccCY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "megan quinn",
        "screen_name" : "msquinn",
        "indices" : [ 18, 26 ],
        "id_str" : "15293504",
        "id" : 15293504
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/pLZVkjccCY",
        "expanded_url" : "http:\/\/tmblr.co\/ZbBADt111MmtO",
        "display_url" : "tmblr.co\/ZbBADt111MmtO"
      } ]
    },
    "geo" : { },
    "id_str" : "411244376095219712",
    "text" : "Great answer from @msquinn to \u201CWhat\u2019s most interesting to me about the future of technology?\" http:\/\/t.co\/pLZVkjccCY",
    "id" : 411244376095219712,
    "created_at" : "2013-12-12 21:21:14 +0000",
    "user" : {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "protected" : false,
      "id_str" : "7482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444089158274154496\/ZePPNQzQ_normal.jpeg",
      "id" : 7482,
      "verified" : false
    }
  },
  "id" : 411245970655956992,
  "created_at" : "2013-12-12 21:27:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Davies",
      "screen_name" : "pdavies",
      "indices" : [ 0, 8 ],
      "id_str" : "15049883",
      "id" : 15049883
    }, {
      "name" : "Jean Hsu",
      "screen_name" : "jyhsu",
      "indices" : [ 9, 15 ],
      "id_str" : "22193381",
      "id" : 22193381
    }, {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 16, 23 ],
      "id_str" : "1026",
      "id" : 1026
    }, {
      "name" : "Winnie Lim",
      "screen_name" : "wynlim",
      "indices" : [ 24, 31 ],
      "id_str" : "7729652",
      "id" : 7729652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411039021775593472",
  "geo" : { },
  "id_str" : "411242214925148160",
  "in_reply_to_user_id" : 15049883,
  "text" : "@pdavies @jyhsu @jfuchs @wynlim Pies on Weds it is. Can we throw them out the window?",
  "id" : 411242214925148160,
  "in_reply_to_status_id" : 411039021775593472,
  "created_at" : "2013-12-12 21:12:39 +0000",
  "in_reply_to_screen_name" : "pdavies",
  "in_reply_to_user_id_str" : "15049883",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Stamatiou",
      "screen_name" : "Stammy",
      "indices" : [ 3, 10 ],
      "id_str" : "624683",
      "id" : 624683
    }, {
      "name" : "Ben Sandofsky",
      "screen_name" : "sandofsky",
      "indices" : [ 108, 118 ],
      "id_str" : "699463",
      "id" : 699463
    }, {
      "name" : "Alex Gir\u00F3n",
      "screen_name" : "giron",
      "indices" : [ 119, 125 ],
      "id_str" : "6814192",
      "id" : 6814192
    }, {
      "name" : "Sung Hu Kim",
      "screen_name" : "sunghu",
      "indices" : [ 126, 133 ],
      "id_str" : "11407672",
      "id" : 11407672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/heAamuR85p",
      "expanded_url" : "https:\/\/blog.twitter.com\/2013\/new-features-for-twitter-for-mac",
      "display_url" : "blog.twitter.com\/2013\/new-featu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411235935196426240",
  "text" : "RT @Stammy: Just launched a Twitter for Mac update! https:\/\/t.co\/heAamuR85p Worked on this for a while with @sandofsky @giron @sunghu et al",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Sandofsky",
        "screen_name" : "sandofsky",
        "indices" : [ 96, 106 ],
        "id_str" : "699463",
        "id" : 699463
      }, {
        "name" : "Alex Gir\u00F3n",
        "screen_name" : "giron",
        "indices" : [ 107, 113 ],
        "id_str" : "6814192",
        "id" : 6814192
      }, {
        "name" : "Sung Hu Kim",
        "screen_name" : "sunghu",
        "indices" : [ 114, 121 ],
        "id_str" : "11407672",
        "id" : 11407672
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/heAamuR85p",
        "expanded_url" : "https:\/\/blog.twitter.com\/2013\/new-features-for-twitter-for-mac",
        "display_url" : "blog.twitter.com\/2013\/new-featu\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7762078, -122.4168402 ]
    },
    "id_str" : "411235466571022336",
    "text" : "Just launched a Twitter for Mac update! https:\/\/t.co\/heAamuR85p Worked on this for a while with @sandofsky @giron @sunghu et al",
    "id" : 411235466571022336,
    "created_at" : "2013-12-12 20:45:50 +0000",
    "user" : {
      "name" : "Paul Stamatiou",
      "screen_name" : "Stammy",
      "protected" : false,
      "id_str" : "624683",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1778867511\/Screen_Shot_2012-01-24_at_2.03.52_PM_normal.png",
      "id" : 624683,
      "verified" : false
    }
  },
  "id" : 411235935196426240,
  "created_at" : "2013-12-12 20:47:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 3, 12 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 14, 21 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 55, 64 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/eramirez\/status\/411227027597832192\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/uPs7enwRna",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbT4zYFCcAA77v9.png",
      "id_str" : "411227027518156800",
      "id" : 411227027518156800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbT4zYFCcAA77v9.png",
      "sizes" : [ {
        "h" : 329,
        "resize" : "fit",
        "w" : 214
      }, {
        "h" : 329,
        "resize" : "fit",
        "w" : 214
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 329,
        "resize" : "fit",
        "w" : 214
      }, {
        "h" : 329,
        "resize" : "fit",
        "w" : 214
      } ],
      "display_url" : "pic.twitter.com\/uPs7enwRna"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411235670011572225",
  "text" : "RT @eramirez: @buster  \u201CThe man who knew too much\u201D cc\/ @anildash http:\/\/t.co\/uPs7enwRna",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      }, {
        "name" : "Anil Dash",
        "screen_name" : "anildash",
        "indices" : [ 41, 50 ],
        "id_str" : "36823",
        "id" : 36823
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/eramirez\/status\/411227027597832192\/photo\/1",
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/uPs7enwRna",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbT4zYFCcAA77v9.png",
        "id_str" : "411227027518156800",
        "id" : 411227027518156800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbT4zYFCcAA77v9.png",
        "sizes" : [ {
          "h" : 329,
          "resize" : "fit",
          "w" : 214
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 214
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 214
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 214
        } ],
        "display_url" : "pic.twitter.com\/uPs7enwRna"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "411225228694409216",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.8858566312, -122.2555501965 ]
    },
    "id_str" : "411227027597832192",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster  \u201CThe man who knew too much\u201D cc\/ @anildash http:\/\/t.co\/uPs7enwRna",
    "id" : 411227027597832192,
    "in_reply_to_status_id" : 411225228694409216,
    "created_at" : "2013-12-12 20:12:18 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "protected" : false,
      "id_str" : "21135674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1777379809\/391870_10100894712944981_10004982_63155096_635581352_n_normal.jpg",
      "id" : 21135674,
      "verified" : false
    }
  },
  "id" : 411235670011572225,
  "created_at" : "2013-12-12 20:46:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 10, 19 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411224507056414720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763359236, -122.4168696971 ]
  },
  "id_str" : "411225228694409216",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @eramirez Yeah I know too much and couldn't speculate. Speculation is the fun part.",
  "id" : 411225228694409216,
  "in_reply_to_status_id" : 411224507056414720,
  "created_at" : "2013-12-12 20:05:09 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 8, 11 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/dpM72TfAnU",
      "expanded_url" : "https:\/\/twitter.com\/buster\/status\/411184259315924992",
      "display_url" : "twitter.com\/buster\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "411201434357469184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762713063, -122.4168438197 ]
  },
  "id_str" : "411203431387234304",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach @rk https:\/\/t.co\/dpM72TfAnU but seems like this is just a first step towards hiding open rates.",
  "id" : 411203431387234304,
  "in_reply_to_status_id" : 411201434357469184,
  "created_at" : "2013-12-12 18:38:32 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 87, 95 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762771927, -122.4168580734 ]
  },
  "id_str" : "411197516311306241",
  "text" : "\"I'll never skip an opportunity to 1-up my team's PM in front of the whole company.\" - @chanian continuing a disturbing trend",
  "id" : 411197516311306241,
  "created_at" : "2013-12-12 18:15:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MailChimp",
      "screen_name" : "MailChimp",
      "indices" : [ 27, 37 ],
      "id_str" : "14377870",
      "id" : 14377870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/LXxF8coaqM",
      "expanded_url" : "http:\/\/eepurl.com\/KDHin",
      "display_url" : "eepurl.com\/KDHin"
    } ]
  },
  "in_reply_to_status_id_str" : "411181845351395328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7894970948, -122.4039765922 ]
  },
  "id_str" : "411184259315924992",
  "in_reply_to_user_id" : 2185,
  "text" : "Or maybe not. According to @Mailchimp they still make 1 img request per recipient, so unique opens is still possible: http:\/\/t.co\/LXxF8coaqM",
  "id" : 411184259315924992,
  "in_reply_to_status_id" : 411181845351395328,
  "created_at" : "2013-12-12 17:22:21 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 7, 11 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411178742904393728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8077115119, -122.3057924678 ]
  },
  "id_str" : "411181845351395328",
  "in_reply_to_user_id" : 2185,
  "text" : "And as @msg pointed out, this may also effectively kill the ability for email campaigns to track open rates in Gmail.",
  "id" : 411181845351395328,
  "in_reply_to_status_id" : 411178742904393728,
  "created_at" : "2013-12-12 17:12:45 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    }, {
      "name" : "Gmail",
      "screen_name" : "gmail",
      "indices" : [ 5, 11 ],
      "id_str" : "38679388",
      "id" : 38679388
    }, {
      "name" : "MailChimp",
      "screen_name" : "MailChimp",
      "indices" : [ 12, 22 ],
      "id_str" : "14377870",
      "id" : 14377870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411181275412566016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8048002255, -122.2948426848 ]
  },
  "id_str" : "411181810148601856",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg @gmail @MailChimp Does Gmail support that? I would've guessed not.",
  "id" : 411181810148601856,
  "in_reply_to_status_id" : 411181275412566016,
  "created_at" : "2013-12-12 17:12:37 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    }, {
      "name" : "Gmail",
      "screen_name" : "gmail",
      "indices" : [ 5, 11 ],
      "id_str" : "38679388",
      "id" : 38679388
    }, {
      "name" : "MailChimp",
      "screen_name" : "MailChimp",
      "indices" : [ 12, 22 ],
      "id_str" : "14377870",
      "id" : 14377870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411179875349704704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8088849771, -122.2683946662 ]
  },
  "id_str" : "411180215201570816",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg @gmail @MailChimp It effectively kills that feature.",
  "id" : 411180215201570816,
  "in_reply_to_status_id" : 411179875349704704,
  "created_at" : "2013-12-12 17:06:17 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nein.",
      "screen_name" : "NeinQuarterly",
      "indices" : [ 3, 17 ],
      "id_str" : "458966079",
      "id" : 458966079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411179331591749632",
  "text" : "RT @NeinQuarterly: Social media dreams of the day that we're only strangers to ourselves.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "411173638780751872",
    "text" : "Social media dreams of the day that we're only strangers to ourselves.",
    "id" : 411173638780751872,
    "created_at" : "2013-12-12 16:40:09 +0000",
    "user" : {
      "name" : "Nein.",
      "screen_name" : "NeinQuarterly",
      "protected" : false,
      "id_str" : "458966079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000829092209\/ed4c25faaa25fbba40b11fabe8241a59_normal.jpeg",
      "id" : 458966079,
      "verified" : true
    }
  },
  "id" : 411179331591749632,
  "created_at" : "2013-12-12 17:02:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gmail",
      "screen_name" : "gmail",
      "indices" : [ 16, 22 ],
      "id_str" : "38679388",
      "id" : 38679388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/bF4AkJnIZU",
      "expanded_url" : "http:\/\/goo.gl\/m4ctPT",
      "display_url" : "goo.gl\/m4ctPT"
    } ]
  },
  "in_reply_to_status_id_str" : "411175368205139968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85366253, -122.2698617635 ]
  },
  "id_str" : "411178742904393728",
  "in_reply_to_user_id" : 38679388,
  "text" : "This is rad. RT @gmail: You\u2019ll never have to press that pesky \u201Cdisplay images below\u201D link in Gmail again: http:\/\/t.co\/bF4AkJnIZU",
  "id" : 411178742904393728,
  "in_reply_to_status_id" : 411175368205139968,
  "created_at" : "2013-12-12 17:00:26 +0000",
  "in_reply_to_screen_name" : "gmail",
  "in_reply_to_user_id_str" : "38679388",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 3, 6 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411177917134012416",
  "text" : "RT @sm: One of the hidden gems of our latest Twitter for iPhone update is the new account switcher. Most recent accounts on top for fast sw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "411177116189736960",
    "text" : "One of the hidden gems of our latest Twitter for iPhone update is the new account switcher. Most recent accounts on top for fast switching.",
    "id" : 411177116189736960,
    "created_at" : "2013-12-12 16:53:58 +0000",
    "user" : {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "protected" : false,
      "id_str" : "22273667",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464258309130694656\/qEKpCniG_normal.jpeg",
      "id" : 22273667,
      "verified" : false
    }
  },
  "id" : 411177917134012416,
  "created_at" : "2013-12-12 16:57:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411154762034212864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597488356, -122.2754705941 ]
  },
  "id_str" : "411157260056809472",
  "in_reply_to_user_id" : 2185,
  "text" : "Also, this is the first time you can reply to an Instagram photo with another photo.",
  "id" : 411157260056809472,
  "in_reply_to_status_id" : 411154762034212864,
  "created_at" : "2013-12-12 15:35:04 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596087979, -122.2755965344 ]
  },
  "id_str" : "411154762034212864",
  "text" : "I think Instagram Direct's ability to message up to 15 people, plus persistent groups, is valuable. It's a cooler Facebook Messages.",
  "id" : 411154762034212864,
  "created_at" : "2013-12-12 15:25:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/FmrvWuAZP6",
      "expanded_url" : "http:\/\/flic.kr\/p\/igwEyx",
      "display_url" : "flic.kr\/p\/igwEyx"
    } ]
  },
  "geo" : { },
  "id_str" : "410992269521850368",
  "text" : "8:36pm Walking home from Brasa's house http:\/\/t.co\/FmrvWuAZP6",
  "id" : 410992269521850368,
  "created_at" : "2013-12-12 04:39:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    }, {
      "name" : "Winnie Lim",
      "screen_name" : "wynlim",
      "indices" : [ 8, 15 ],
      "id_str" : "7729652",
      "id" : 7729652
    }, {
      "name" : "Jean Hsu",
      "screen_name" : "jyhsu",
      "indices" : [ 16, 22 ],
      "id_str" : "22193381",
      "id" : 22193381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410959341475213312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7798130603, -122.4137127767 ]
  },
  "id_str" : "410960216058916864",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs @wynlim @jyhsu Sadly, no. :) How about noon next Tue or Wed?",
  "id" : 410960216058916864,
  "in_reply_to_status_id" : 410959341475213312,
  "created_at" : "2013-12-12 02:32:05 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    }, {
      "name" : "Winnie Lim",
      "screen_name" : "wynlim",
      "indices" : [ 8, 15 ],
      "id_str" : "7729652",
      "id" : 7729652
    }, {
      "name" : "Jean Hsu",
      "screen_name" : "jyhsu",
      "indices" : [ 16, 22 ],
      "id_str" : "22193381",
      "id" : 22193381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410958295550025728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78017025, -122.41347473 ]
  },
  "id_str" : "410958816138641410",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs @wynlim @jyhsu I could come by at 1pm tomorrow. I even have something to show you.",
  "id" : 410958816138641410,
  "in_reply_to_status_id" : 410958295550025728,
  "created_at" : "2013-12-12 02:26:31 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.rdio.com\" rel=\"nofollow\"\u003ERdio\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rdio",
      "screen_name" : "Rdio",
      "indices" : [ 39, 44 ],
      "id_str" : "54205414",
      "id" : 54205414
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowPlaying",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/ML0w5QO83x",
      "expanded_url" : "http:\/\/rd.io\/x\/QFvDK3P8cQ\/",
      "display_url" : "rd.io\/x\/QFvDK3P8cQ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "410957351361855488",
  "text" : "#NowPlaying \"The Rip\" by Portishead on @Rdio: http:\/\/t.co\/ML0w5QO83x\n\nQuite rewarding to re-listen to after a few years.",
  "id" : 410957351361855488,
  "created_at" : "2013-12-12 02:20:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/410641520958529537\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/8aTp8DAU2n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbLkSZgCYAAGBvN.jpg",
      "id_str" : "410641520778174464",
      "id" : 410641520778174464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbLkSZgCYAAGBvN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8aTp8DAU2n"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85984083, -122.2753855845 ]
  },
  "id_str" : "410641520958529537",
  "text" : "8:36pm Exposing Niko to The B-52's http:\/\/t.co\/8aTp8DAU2n",
  "id" : 410641520958529537,
  "created_at" : "2013-12-11 05:25:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/uMw9KQhDQP",
      "expanded_url" : "https:\/\/vine.co\/v\/hQEavvJ1mDV",
      "display_url" : "vine.co\/v\/hQEavvJ1mDV"
    } ]
  },
  "geo" : { },
  "id_str" : "410629072407248896",
  "text" : "Niko learning to count beats https:\/\/t.co\/uMw9KQhDQP",
  "id" : 410629072407248896,
  "created_at" : "2013-12-11 04:36:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/JHbu8cb9ze",
      "expanded_url" : "https:\/\/blog.twitter.com\/2013\/photos-in-direct-messages-and-swipe-between-timelines",
      "display_url" : "blog.twitter.com\/2013\/photos-in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410531899539337216",
  "text" : "The return of DMs dun dun DUN. https:\/\/t.co\/JHbu8cb9ze",
  "id" : 410531899539337216,
  "created_at" : "2013-12-10 22:10:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8530486598, -122.2706049872 ]
  },
  "id_str" : "410447037901963265",
  "text" : "Love it when my subconscious books a middle-of-the-night intensive brainstorming session w\/ my brain. I was gonna to use that for sleeping.",
  "id" : 410447037901963265,
  "created_at" : "2013-12-10 16:32:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/sd8vtWpJ85",
      "expanded_url" : "http:\/\/flic.kr\/p\/idLjKx",
      "display_url" : "flic.kr\/p\/idLjKx"
    } ]
  },
  "geo" : { },
  "id_str" : "410276962264162304",
  "text" : "8:36pm It's gonna be another exciting night of reading and watching TV folks http:\/\/t.co\/sd8vtWpJ85",
  "id" : 410276962264162304,
  "created_at" : "2013-12-10 05:17:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh Laurie",
      "screen_name" : "hughlaurie",
      "indices" : [ 3, 14 ],
      "id_str" : "1660468830",
      "id" : 1660468830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410238672051527680",
  "text" : "RT @hughlaurie: Do you ever get the feeling you're not being watched?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410129651173191680",
    "text" : "Do you ever get the feeling you're not being watched?",
    "id" : 410129651173191680,
    "created_at" : "2013-12-09 19:31:43 +0000",
    "user" : {
      "name" : "Hugh Laurie",
      "screen_name" : "hughlaurie",
      "protected" : false,
      "id_str" : "1660468830",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000607017706\/cad02238d8ab28febfbdec2978c4a810_normal.jpeg",
      "id" : 1660468830,
      "verified" : true
    }
  },
  "id" : 410238672051527680,
  "created_at" : "2013-12-10 02:44:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/nwUwMOmj6p",
      "expanded_url" : "http:\/\/instagram.com\/p\/hsAka_OFQU\/",
      "display_url" : "instagram.com\/p\/hsAka_OFQU\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.860445, -122.289451 ]
  },
  "id_str" : "409906414782402560",
  "text" : "Truth about beans. http:\/\/t.co\/nwUwMOmj6p",
  "id" : 409906414782402560,
  "created_at" : "2013-12-09 04:44:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 38, 48 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Katie P",
      "screen_name" : "capitol_trouble",
      "indices" : [ 49, 65 ],
      "id_str" : "16063333",
      "id" : 16063333
    }, {
      "name" : "Jimmy James Hall",
      "screen_name" : "JimmyJameson",
      "indices" : [ 66, 79 ],
      "id_str" : "35141809",
      "id" : 35141809
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/409905104213385216\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/jTSAsMM2tS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbBGhTWCUAAkfFF.jpg",
      "id_str" : "409905104033042432",
      "id" : 409905104033042432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbBGhTWCUAAkfFF.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jTSAsMM2tS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8605763009, -122.289716229 ]
  },
  "id_str" : "409905104213385216",
  "text" : "8:36pm The dragon is in true form \/cc @kellianne @capitol_trouble @JimmyJameson http:\/\/t.co\/jTSAsMM2tS",
  "id" : 409905104213385216,
  "created_at" : "2013-12-09 04:39:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/409844803749175298\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/F7LOY4Q9s2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbAPrV5CYAAdYKa.jpg",
      "id_str" : "409844803375882240",
      "id" : 409844803375882240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbAPrV5CYAAdYKa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/F7LOY4Q9s2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597181617, -122.2755100765 ]
  },
  "id_str" : "409844803749175298",
  "text" : "Apparently it does snow in Berkeley http:\/\/t.co\/F7LOY4Q9s2",
  "id" : 409844803749175298,
  "created_at" : "2013-12-09 00:39:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/0IBDa2QuWG",
      "expanded_url" : "https:\/\/vine.co\/v\/hQqdZUhBDMZ",
      "display_url" : "vine.co\/v\/hQqdZUhBDMZ"
    } ]
  },
  "geo" : { },
  "id_str" : "409582370472607744",
  "text" : "Arcade Fire. https:\/\/t.co\/0IBDa2QuWG",
  "id" : 409582370472607744,
  "created_at" : "2013-12-08 07:17:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/oW1ZMaAiwr",
      "expanded_url" : "https:\/\/vine.co\/v\/hQqbIiLFV3h",
      "display_url" : "vine.co\/v\/hQqbIiLFV3h"
    } ]
  },
  "geo" : { },
  "id_str" : "409571195458433024",
  "text" : "Phoenix kills it. https:\/\/t.co\/oW1ZMaAiwr",
  "id" : 409571195458433024,
  "created_at" : "2013-12-08 06:32:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/u9ENs3BCGa",
      "expanded_url" : "https:\/\/vine.co\/v\/hQAYvt7iBET",
      "display_url" : "vine.co\/v\/hQAYvt7iBET"
    } ]
  },
  "geo" : { },
  "id_str" : "409560875528638464",
  "text" : "Phoenix. https:\/\/t.co\/u9ENs3BCGa",
  "id" : 409560875528638464,
  "created_at" : "2013-12-08 05:51:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/409543093407326208\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/z5k7AZSu6f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba79RgMCYAAsMpd.jpg",
      "id_str" : "409543093277319168",
      "id" : 409543093277319168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba79RgMCYAAsMpd.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/z5k7AZSu6f"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409540233428865024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7505826811, -122.2028077116 ]
  },
  "id_str" : "409543093407326208",
  "in_reply_to_user_id" : 2185,
  "text" : "8:36pm At \"Oracle Arena\". Lorde was great. \u2206, Phoenix, Arcade Fire up next. http:\/\/t.co\/z5k7AZSu6f",
  "id" : 409543093407326208,
  "in_reply_to_status_id" : 409540233428865024,
  "created_at" : "2013-12-08 04:40:57 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "timepoy",
      "indices" : [ 6, 14 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409531524141174784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7505101253, -122.2029806668 ]
  },
  "id_str" : "409540233428865024",
  "in_reply_to_user_id" : 2185,
  "text" : "Lorde #timepoy",
  "id" : 409540233428865024,
  "in_reply_to_status_id" : 409531524141174784,
  "created_at" : "2013-12-08 04:29:35 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/ZcakzevuKx",
      "expanded_url" : "https:\/\/vine.co\/v\/hQAAHujiWFE",
      "display_url" : "vine.co\/v\/hQAAHujiWFE"
    } ]
  },
  "geo" : { },
  "id_str" : "409536518886522880",
  "text" : "Royals. https:\/\/t.co\/ZcakzevuKx",
  "id" : 409536518886522880,
  "created_at" : "2013-12-08 04:14:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/3commvepmN",
      "expanded_url" : "https:\/\/vine.co\/v\/hQAzHpKm5bI",
      "display_url" : "vine.co\/v\/hQAzHpKm5bI"
    } ]
  },
  "geo" : { },
  "id_str" : "409531778756775936",
  "text" : "Lorde. https:\/\/t.co\/3commvepmN",
  "id" : 409531778756775936,
  "created_at" : "2013-12-08 03:55:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409529089121193985",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7504217792, -122.2029608608 ]
  },
  "id_str" : "409531524141174784",
  "in_reply_to_user_id" : 2185,
  "text" : "Oops, she just addressed Oakland as San Francisco. But then made up for it by saying this is the biggest venue she's ever played.",
  "id" : 409531524141174784,
  "in_reply_to_status_id" : 409529089121193985,
  "created_at" : "2013-12-08 03:54:58 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409528839031635970",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.750420764, -122.2029865483 ]
  },
  "id_str" : "409529089121193985",
  "in_reply_to_user_id" : 2185,
  "text" : "Better luck with your next job, sound guy.",
  "id" : 409529089121193985,
  "in_reply_to_status_id" : 409528839031635970,
  "created_at" : "2013-12-08 03:45:18 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7503600685, -122.2029485478 ]
  },
  "id_str" : "409528839031635970",
  "text" : "Lorde came on stage and sang for a minute before anyone told her that her mic wasn't on.",
  "id" : 409528839031635970,
  "created_at" : "2013-12-08 03:44:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 40, 50 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/NltQA17jNg",
      "expanded_url" : "https:\/\/vine.co\/v\/hQKp2g6nhwx",
      "display_url" : "vine.co\/v\/hQKp2g6nhwx"
    } ]
  },
  "in_reply_to_status_id_str" : "409517050768662528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7503848239, -122.2030013076 ]
  },
  "id_str" : "409523961739747328",
  "in_reply_to_user_id" : 7362142,
  "text" : "Rocking out in the well-lit bar area RT @kellianne: STADIUM ROCK!!!! https:\/\/t.co\/NltQA17jNg",
  "id" : 409523961739747328,
  "in_reply_to_status_id" : 409517050768662528,
  "created_at" : "2013-12-08 03:24:55 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409517100244295680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.750608401, -122.2023690194 ]
  },
  "id_str" : "409519775392337920",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler They were last night. We've got Lorde, Alt-J, Phoenix, and Arcade Fire. And lots of teenyboppers.",
  "id" : 409519775392337920,
  "in_reply_to_status_id" : 409517100244295680,
  "created_at" : "2013-12-08 03:08:17 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/cYCCNpFesq",
      "expanded_url" : "https:\/\/vine.co\/v\/hQmEOqz7B72",
      "display_url" : "vine.co\/v\/hQmEOqz7B72"
    } ]
  },
  "geo" : { },
  "id_str" : "409492271290392578",
  "text" : "Niko's preferred Xmas tree light settings https:\/\/t.co\/cYCCNpFesq",
  "id" : 409492271290392578,
  "created_at" : "2013-12-08 01:19:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 24, 34 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409438764503556097",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8613885897, -122.2980210713 ]
  },
  "id_str" : "409443132317528064",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie You just gave @kellianne a part time job idea.",
  "id" : 409443132317528064,
  "in_reply_to_status_id" : 409438764503556097,
  "created_at" : "2013-12-07 22:03:44 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/409427981421924352\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/xyQQsJ5g89",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba6UlGqCcAANbWs.jpg",
      "id_str" : "409427981300297728",
      "id" : 409427981300297728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba6UlGqCcAANbWs.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xyQQsJ5g89"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8708260274, -122.2775897105 ]
  },
  "id_str" : "409427981421924352",
  "text" : "Xmas tree attendant: \"I've seen a lot of things. This one takes the cake.\" http:\/\/t.co\/xyQQsJ5g89",
  "id" : 409427981421924352,
  "created_at" : "2013-12-07 21:03:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    }, {
      "name" : "Winnie Lim",
      "screen_name" : "wynlim",
      "indices" : [ 8, 15 ],
      "id_str" : "7729652",
      "id" : 7729652
    }, {
      "name" : "Jean Hsu",
      "screen_name" : "jyhsu",
      "indices" : [ 16, 22 ],
      "id_str" : "22193381",
      "id" : 22193381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409399203220037632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597277589, -122.2754351423 ]
  },
  "id_str" : "409409136158191617",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs @wynlim @jyhsu Maybe! Would 9:30 or 10 work?",
  "id" : 409409136158191617,
  "in_reply_to_status_id" : 409399203220037632,
  "created_at" : "2013-12-07 19:48:39 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Winnie Lim",
      "screen_name" : "wynlim",
      "indices" : [ 0, 7 ],
      "id_str" : "7729652",
      "id" : 7729652
    }, {
      "name" : "Jean Hsu",
      "screen_name" : "jyhsu",
      "indices" : [ 8, 14 ],
      "id_str" : "22193381",
      "id" : 22193381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409379617812668416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597190417, -122.2755959844 ]
  },
  "id_str" : "409388505517658112",
  "in_reply_to_user_id" : 7729652,
  "text" : "@wynlim @jyhsu I'd love to come up with an excuse to come visit Medium.",
  "id" : 409388505517658112,
  "in_reply_to_status_id" : 409379617812668416,
  "created_at" : "2013-12-07 18:26:40 +0000",
  "in_reply_to_screen_name" : "wynlim",
  "in_reply_to_user_id_str" : "7729652",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596957587, -122.275631719 ]
  },
  "id_str" : "409382931132465152",
  "text" : "Bastille, Lorde, \u2206, and Arcade Fire all together tonight is just too good to miss.",
  "id" : 409382931132465152,
  "created_at" : "2013-12-07 18:04:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jean Hsu",
      "screen_name" : "jyhsu",
      "indices" : [ 0, 6 ],
      "id_str" : "22193381",
      "id" : 22193381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409376906786521088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596730739, -122.2755876257 ]
  },
  "id_str" : "409380810035191808",
  "in_reply_to_user_id" : 22193381,
  "text" : "@jyhsu I've since seen the light regarding pie charts. Wish I had time to re-do the charts on this page... they're 3+ yrs old.",
  "id" : 409380810035191808,
  "in_reply_to_status_id" : 409376906786521088,
  "created_at" : "2013-12-07 17:56:05 +0000",
  "in_reply_to_screen_name" : "jyhsu",
  "in_reply_to_user_id_str" : "22193381",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jonronson",
      "screen_name" : "jonronson",
      "indices" : [ 3, 13 ],
      "id_str" : "18028249",
      "id" : 18028249
    }, {
      "name" : "SpaghettiOs",
      "screen_name" : "SpaghettiOs",
      "indices" : [ 72, 84 ],
      "id_str" : "1226598505",
      "id" : 1226598505
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PearlHarbor",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/RFYGJwmiDW",
      "expanded_url" : "http:\/\/twitter.com\/SpaghettiOs\/status\/409162874184298496\/photo\/1",
      "display_url" : "pic.twitter.com\/RFYGJwmiDW"
    } ]
  },
  "geo" : { },
  "id_str" : "409357447921274880",
  "text" : "RT @jonronson: Those who forget the pasta are condemned to reheat it RT @SpaghettiOs: remember #PearlHarbor with us. http:\/\/t.co\/RFYGJwmiDW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SpaghettiOs",
        "screen_name" : "SpaghettiOs",
        "indices" : [ 57, 69 ],
        "id_str" : "1226598505",
        "id" : 1226598505
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PearlHarbor",
        "indices" : [ 80, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/RFYGJwmiDW",
        "expanded_url" : "http:\/\/twitter.com\/SpaghettiOs\/status\/409162874184298496\/photo\/1",
        "display_url" : "pic.twitter.com\/RFYGJwmiDW"
      } ]
    },
    "geo" : { },
    "id_str" : "409343475428384768",
    "text" : "Those who forget the pasta are condemned to reheat it RT @SpaghettiOs: remember #PearlHarbor with us. http:\/\/t.co\/RFYGJwmiDW",
    "id" : 409343475428384768,
    "created_at" : "2013-12-07 15:27:44 +0000",
    "user" : {
      "name" : "jonronson",
      "screen_name" : "jonronson",
      "protected" : false,
      "id_str" : "18028249",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459838832033427456\/prmyhDM3_normal.jpeg",
      "id" : 18028249,
      "verified" : true
    }
  },
  "id" : 409357447921274880,
  "created_at" : "2013-12-07 16:23:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie P",
      "screen_name" : "capitol_trouble",
      "indices" : [ 27, 43 ],
      "id_str" : "16063333",
      "id" : 16063333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/fnvevFd1uE",
      "expanded_url" : "http:\/\/flic.kr\/p\/i8PRya",
      "display_url" : "flic.kr\/p\/i8PRya"
    } ]
  },
  "geo" : { },
  "id_str" : "409181071511945216",
  "text" : "8:36pm Eating dessert with @capitol_trouble  http:\/\/t.co\/fnvevFd1uE",
  "id" : 409181071511945216,
  "created_at" : "2013-12-07 04:42:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409147574193369089",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596625426, -122.275606275 ]
  },
  "id_str" : "409167196082802688",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Yay! I've often tried to retweet you only to be thwarted. Welcome to public Twitter!",
  "id" : 409167196082802688,
  "in_reply_to_status_id" : 409147574193369089,
  "created_at" : "2013-12-07 03:47:16 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Ei5T8Vlpqj",
      "expanded_url" : "http:\/\/youtu.be\/faQBrAQ87l4",
      "display_url" : "youtu.be\/faQBrAQ87l4"
    } ]
  },
  "geo" : { },
  "id_str" : "409136861571870720",
  "text" : "Re-reading about Hilbert's Infinite Hotel in The Beginning of Infinity. Here's the 60-second version: http:\/\/t.co\/Ei5T8Vlpqj",
  "id" : 409136861571870720,
  "created_at" : "2013-12-07 01:46:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magic Recs",
      "screen_name" : "MagicRecs",
      "indices" : [ 52, 62 ],
      "id_str" : "1270746139",
      "id" : 1270746139
    }, {
      "name" : "Stephen King",
      "screen_name" : "StephenKing",
      "indices" : [ 99, 111 ],
      "id_str" : "2233154425",
      "id" : 2233154425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409091834191683584",
  "text" : "We need a magic account that predicts what the next @magicrecs recommendation is going to be. i.e. @stephenking",
  "id" : 409091834191683584,
  "created_at" : "2013-12-06 22:47:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "Dana",
      "screen_name" : "DanaDanger",
      "indices" : [ 8, 19 ],
      "id_str" : "821958",
      "id" : 821958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409050124170448896",
  "geo" : { },
  "id_str" : "409050429008269312",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach @DanaDanger There are no open collections anymore.",
  "id" : 409050429008269312,
  "in_reply_to_status_id" : 409050124170448896,
  "created_at" : "2013-12-06 20:03:16 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "late36",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/gYaFzDGOZm",
      "expanded_url" : "http:\/\/flic.kr\/p\/i7zy6S",
      "display_url" : "flic.kr\/p\/i7zy6S"
    } ]
  },
  "geo" : { },
  "id_str" : "408846049609273344",
  "text" : "8:36pm Was putting Niko to sleep. Then email. Now beer and Nashville. #late36 http:\/\/t.co\/gYaFzDGOZm",
  "id" : 408846049609273344,
  "created_at" : "2013-12-06 06:31:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 33, 44 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408763971013865473",
  "geo" : { },
  "id_str" : "408764435990200320",
  "in_reply_to_user_id" : 142467448,
  "text" : "I know you are but what am I? RT @nikobenson: Mama: Your papa is a sweet man.\nMe: No, he is a SILLY man.",
  "id" : 408764435990200320,
  "in_reply_to_status_id" : 408763971013865473,
  "created_at" : "2013-12-06 01:06:50 +0000",
  "in_reply_to_screen_name" : "nikobenson",
  "in_reply_to_user_id_str" : "142467448",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/sx8v6IIcir",
      "expanded_url" : "https:\/\/twitter.com\/tomchatfield\/status\/408654417144324096",
      "display_url" : "twitter.com\/tomchatfield\/s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "408680631204192256",
  "geo" : { },
  "id_str" : "408681152665231360",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk We've run into a paradoxical set: https:\/\/t.co\/sx8v6IIcir",
  "id" : 408681152665231360,
  "in_reply_to_status_id" : 408680631204192256,
  "created_at" : "2013-12-05 19:35:54 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McAllister",
      "screen_name" : "ianmcall",
      "indices" : [ 0, 9 ],
      "id_str" : "2035631",
      "id" : 2035631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408670240306774016",
  "geo" : { },
  "id_str" : "408670522025582592",
  "in_reply_to_user_id" : 2035631,
  "text" : "@ianmcall nice try, but I believe that's still equal to \u221E.",
  "id" : 408670522025582592,
  "in_reply_to_status_id" : 408670240306774016,
  "created_at" : "2013-12-05 18:53:39 +0000",
  "in_reply_to_screen_name" : "ianmcall",
  "in_reply_to_user_id_str" : "2035631",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408657433733505025",
  "geo" : { },
  "id_str" : "408658227924971520",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates I think that's it.",
  "id" : 408658227924971520,
  "in_reply_to_status_id" : 408657433733505025,
  "created_at" : "2013-12-05 18:04:48 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "InfinityPlusOne",
      "screen_name" : "InfinityPlusOne",
      "indices" : [ 14, 30 ],
      "id_str" : "14753156",
      "id" : 14753156
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 32, 39 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408655370408562688",
  "geo" : { },
  "id_str" : "408657480835555328",
  "in_reply_to_user_id" : 14753156,
  "text" : "3rd place. RT @InfinityPlusOne: @buster so you're saying I don't count?",
  "id" : 408657480835555328,
  "in_reply_to_status_id" : 408655370408562688,
  "created_at" : "2013-12-05 18:01:50 +0000",
  "in_reply_to_screen_name" : "InfinityPlusOne",
  "in_reply_to_user_id_str" : "14753156",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Wild",
      "screen_name" : "dorkitude",
      "indices" : [ 0, 10 ],
      "id_str" : "12626542",
      "id" : 12626542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408654504213487616",
  "geo" : { },
  "id_str" : "408654688582508545",
  "in_reply_to_user_id" : 12626542,
  "text" : "@dorkitude That just looks cool.",
  "id" : 408654688582508545,
  "in_reply_to_status_id" : 408654504213487616,
  "created_at" : "2013-12-05 17:50:44 +0000",
  "in_reply_to_screen_name" : "dorkitude",
  "in_reply_to_user_id_str" : "12626542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Wild",
      "screen_name" : "dorkitude",
      "indices" : [ 3, 13 ],
      "id_str" : "12626542",
      "id" : 12626542
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 15, 22 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408654600061718529",
  "text" : "RT @dorkitude: @buster \u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "408650592743985152",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7531374013, -122.4112992549 ]
    },
    "id_str" : "408654504213487616",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster \u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E^\u221E",
    "id" : 408654504213487616,
    "in_reply_to_status_id" : 408650592743985152,
    "created_at" : "2013-12-05 17:50:00 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Kyle Wild",
      "screen_name" : "dorkitude",
      "protected" : false,
      "id_str" : "12626542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000845789371\/874bd513a8893528930ef6b37a037f26_normal.jpeg",
      "id" : 12626542,
      "verified" : false
    }
  },
  "id" : 408654600061718529,
  "created_at" : "2013-12-05 17:50:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Chatfield",
      "screen_name" : "TomChatfield",
      "indices" : [ 3, 16 ],
      "id_str" : "88707084",
      "id" : 88707084
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 18, 25 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408654536991993856",
  "text" : "RT @TomChatfield: @buster why, the number that exceeds every other number a tweet could conceivably mention (including this one: Russell wo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "408650592743985152",
    "geo" : { },
    "id_str" : "408654417144324096",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster why, the number that exceeds every other number a tweet could conceivably mention (including this one: Russell would be delighted).",
    "id" : 408654417144324096,
    "in_reply_to_status_id" : 408650592743985152,
    "created_at" : "2013-12-05 17:49:40 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Tom Chatfield",
      "screen_name" : "TomChatfield",
      "protected" : false,
      "id_str" : "88707084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455460662064340992\/m2KzvMGG_normal.jpeg",
      "id" : 88707084,
      "verified" : false
    }
  },
  "id" : 408654536991993856,
  "created_at" : "2013-12-05 17:50:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Wilkinson",
      "screen_name" : "timw",
      "indices" : [ 0, 5 ],
      "id_str" : "15054037",
      "id" : 15054037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408653917304537088",
  "geo" : { },
  "id_str" : "408654025769226240",
  "in_reply_to_user_id" : 15054037,
  "text" : "@timw yes",
  "id" : 408654025769226240,
  "in_reply_to_status_id" : 408653917304537088,
  "created_at" : "2013-12-05 17:48:06 +0000",
  "in_reply_to_screen_name" : "timw",
  "in_reply_to_user_id_str" : "15054037",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408652992556974081",
  "geo" : { },
  "id_str" : "408653486658580482",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger Can we host it at a Starbucks during December?",
  "id" : 408653486658580482,
  "in_reply_to_status_id" : 408652992556974081,
  "created_at" : "2013-12-05 17:45:58 +0000",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408650592743985152",
  "geo" : { },
  "id_str" : "408653294588817408",
  "in_reply_to_user_id" : 2185,
  "text" : "2nd prize: \u221E\n1st prize: biggest number less than \u221E that can fit into 140 characters.",
  "id" : 408653294588817408,
  "in_reply_to_status_id" : 408650592743985152,
  "created_at" : "2013-12-05 17:45:12 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7784900341, -122.4150653797 ]
  },
  "id_str" : "408650592743985152",
  "text" : "What's the largest number you can write in a tweet?",
  "id" : 408650592743985152,
  "created_at" : "2013-12-05 17:34:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7784883981, -122.414930855 ]
  },
  "id_str" : "408650459092496385",
  "text" : "My name is Buster and I'm emotionally dependent on eggnog lattes.",
  "id" : 408650459092496385,
  "created_at" : "2013-12-05 17:33:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baby Animals",
      "screen_name" : "BabyAnimalPics",
      "indices" : [ 46, 61 ],
      "id_str" : "1372975219",
      "id" : 1372975219
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BabyAnimalPics\/status\/408615561720233984\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/e94DgofSrd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BauxsDSIgAAPW_R.jpg",
      "id_str" : "408615561560883200",
      "id" : 408615561560883200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BauxsDSIgAAPW_R.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/e94DgofSrd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408615561720233984",
  "geo" : { },
  "id_str" : "408619516168396801",
  "in_reply_to_user_id" : 1372975219,
  "text" : "Good morning, cute baby fox out on a walk. RT @BabyAnimalPics: cute baby fox out on a walk http:\/\/t.co\/e94DgofSrd",
  "id" : 408619516168396801,
  "in_reply_to_status_id" : 408615561720233984,
  "created_at" : "2013-12-05 15:30:59 +0000",
  "in_reply_to_screen_name" : "BabyAnimalPics",
  "in_reply_to_user_id_str" : "1372975219",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 52, 62 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408455483234586624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596821781, -122.2755195089 ]
  },
  "id_str" : "408466199555473408",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm Yeah we keep hoping he starts to look more like @kellianne but so far not much luck.",
  "id" : 408466199555473408,
  "in_reply_to_status_id" : 408455483234586624,
  "created_at" : "2013-12-05 05:21:45 +0000",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/408455095387299840\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/TpxSGDIS4G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BasfvrvCAAAas4j.jpg",
      "id_str" : "408455095261462528",
      "id" : 408455095261462528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BasfvrvCAAAas4j.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/TpxSGDIS4G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596322053, -122.2756151018 ]
  },
  "id_str" : "408455095387299840",
  "text" : "8:36pm \"My eyes are smiling,\" says the slowest most easily distracted eater that there ever was. http:\/\/t.co\/TpxSGDIS4G",
  "id" : 408455095387299840,
  "created_at" : "2013-12-05 04:37:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "User Onboarding",
      "screen_name" : "UserOnboard",
      "indices" : [ 22, 34 ],
      "id_str" : "2197606969",
      "id" : 2197606969
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/UserOnboard\/status\/408372844876165120\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/0BrOrbwOue",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BarU8FMCcAAaVdI.png",
      "id_str" : "408372844880359424",
      "id" : 408372844880359424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BarU8FMCcAAaVdI.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1389,
        "resize" : "fit",
        "w" : 1866
      }, {
        "h" : 762,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/0BrOrbwOue"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408372844876165120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597271087, -122.2756183998 ]
  },
  "id_str" : "408452208699518976",
  "in_reply_to_user_id" : 2197606969,
  "text" : "Sort of love this: RT @UserOnboard: Never mix up features with benefits ever again... http:\/\/t.co\/0BrOrbwOue",
  "id" : 408452208699518976,
  "in_reply_to_status_id" : 408372844876165120,
  "created_at" : "2013-12-05 04:26:09 +0000",
  "in_reply_to_screen_name" : "UserOnboard",
  "in_reply_to_user_id_str" : "2197606969",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 17, 24 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/s2vvOvpITN",
      "expanded_url" : "https:\/\/medium.com\/buster-benson",
      "display_url" : "medium.com\/buster-benson"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596021559, -122.2756653116 ]
  },
  "id_str" : "408451252008132613",
  "text" : "Interesting that @Medium just added a way to follow collections. Where's Ashton? In the meantime, why not follow me: https:\/\/t.co\/s2vvOvpITN",
  "id" : 408451252008132613,
  "created_at" : "2013-12-05 04:22:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408410330910306305",
  "text" : "Self-selfie-taking whiteboards that group photo chat their scrawlings to all devices in proximity.",
  "id" : 408410330910306305,
  "created_at" : "2013-12-05 01:39:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "embraceboring",
      "indices" : [ 70, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/XFRCWNN8Ty",
      "expanded_url" : "http:\/\/flic.kr\/p\/i4R58o",
      "display_url" : "flic.kr\/p\/i4R58o"
    } ]
  },
  "geo" : { },
  "id_str" : "408117410441744384",
  "text" : "8:36pm Was reading Niko stories. Then dishes. Then email. Now a beer. #embraceboring http:\/\/t.co\/XFRCWNN8Ty",
  "id" : 408117410441744384,
  "created_at" : "2013-12-04 06:15:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/XkUUcdJOZa",
      "expanded_url" : "http:\/\/wayoftheduck.com\/diy-horse-ebooks",
      "display_url" : "wayoftheduck.com\/diy-horse-eboo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "408019428215779328",
  "geo" : { },
  "id_str" : "408102961521254400",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler It's just a funny side project bot I built a while ago: http:\/\/t.co\/XkUUcdJOZa",
  "id" : 408102961521254400,
  "in_reply_to_status_id" : 408019428215779328,
  "created_at" : "2013-12-04 05:18:22 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/407731349991075840\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/SjQkJQsGXP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaiNgKDCAAAl3tU.jpg",
      "id_str" : "407731349869428736",
      "id" : 407731349869428736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaiNgKDCAAAl3tU.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/SjQkJQsGXP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859528262, -122.2756077505 ]
  },
  "id_str" : "407731349991075840",
  "text" : "8:36pm Current status: peak hobo. http:\/\/t.co\/SjQkJQsGXP",
  "id" : 407731349991075840,
  "created_at" : "2013-12-03 04:41:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596245841, -122.2754688933 ]
  },
  "id_str" : "407709622619750400",
  "text" : "Niko wrote his letter to Santa today. Top of the list: a snow plow for his face. With a hole in it so he can see out of, he later qualified.",
  "id" : 407709622619750400,
  "created_at" : "2013-12-03 03:15:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 3, 8 ],
      "id_str" : "528",
      "id" : 528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/mZimkaFmjR",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Gender-neutral_pronoun",
      "display_url" : "en.m.wikipedia.org\/wiki\/Gender-ne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407665304823554048",
  "text" : "RT @buzz: Kickstarter to develop a catch-all third person singular pronoun for English. Maybe revive the Middle English \"Ou?\" http:\/\/t.co\/m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/mZimkaFmjR",
        "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Gender-neutral_pronoun",
        "display_url" : "en.m.wikipedia.org\/wiki\/Gender-ne\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "407663202714271744",
    "text" : "Kickstarter to develop a catch-all third person singular pronoun for English. Maybe revive the Middle English \"Ou?\" http:\/\/t.co\/mZimkaFmjR",
    "id" : 407663202714271744,
    "created_at" : "2013-12-03 00:10:56 +0000",
    "user" : {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "protected" : false,
      "id_str" : "528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000380729495\/f67b4c4cc29328c5fca63ef57936bcdb_normal.jpeg",
      "id" : 528,
      "verified" : false
    }
  },
  "id" : 407665304823554048,
  "created_at" : "2013-12-03 00:19:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan DePrizio",
      "screen_name" : "nemilar",
      "indices" : [ 0, 8 ],
      "id_str" : "14873146",
      "id" : 14873146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407623173497053184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7766587096, -122.4175806581 ]
  },
  "id_str" : "407630891679105024",
  "in_reply_to_user_id" : 14873146,
  "text" : "@nemilar I did! And thank you for the pointer.",
  "id" : 407630891679105024,
  "in_reply_to_status_id" : 407623173497053184,
  "created_at" : "2013-12-02 22:02:32 +0000",
  "in_reply_to_screen_name" : "nemilar",
  "in_reply_to_user_id_str" : "14873146",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RedCrossMA",
      "screen_name" : "RedCrossMA",
      "indices" : [ 0, 11 ],
      "id_str" : "370924278",
      "id" : 370924278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/FtR27QabCe",
      "expanded_url" : "http:\/\/twitter.com",
      "display_url" : "twitter.com"
    } ]
  },
  "in_reply_to_status_id_str" : "407616140756529153",
  "geo" : { },
  "id_str" : "407616278765912064",
  "in_reply_to_user_id" : 370924278,
  "text" : "@redcrossma Sure! Email me at buster at http:\/\/t.co\/FtR27QabCe.",
  "id" : 407616278765912064,
  "in_reply_to_status_id" : 407616140756529153,
  "created_at" : "2013-12-02 21:04:28 +0000",
  "in_reply_to_screen_name" : "RedCrossMA",
  "in_reply_to_user_id_str" : "370924278",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7765092516, -122.4174982848 ]
  },
  "id_str" : "407610933012230144",
  "text" : "When will I be able to buy a drone on Amazon. And will it deliver itself?",
  "id" : 407610933012230144,
  "created_at" : "2013-12-02 20:43:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thejetpacksweneverhad",
      "indices" : [ 39, 61 ]
    }, {
      "text" : "coulduseabettername",
      "indices" : [ 62, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596093309, -122.275696526 ]
  },
  "id_str" : "407537681518706688",
  "text" : "I'm waiting for Amazon Prime Air Uber. #thejetpacksweneverhad #coulduseabettername",
  "id" : 407537681518706688,
  "created_at" : "2013-12-02 15:52:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/UHQqLgN1Rz",
      "expanded_url" : "http:\/\/flic.kr\/p\/i1GmcJ",
      "display_url" : "flic.kr\/p\/i1GmcJ"
    } ]
  },
  "geo" : { },
  "id_str" : "407368792076193792",
  "text" : "8:36pm Scribe after after party (we started early) http:\/\/t.co\/UHQqLgN1Rz",
  "id" : 407368792076193792,
  "created_at" : "2013-12-02 04:41:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sundaypost",
      "indices" : [ 62, 73 ]
    }, {
      "text" : "cats",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/kxGrgj81cV",
      "expanded_url" : "https:\/\/medium.com\/building-products-people-love\/ac6364c5c63b",
      "display_url" : "medium.com\/building-produ\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595345692, -122.2757347203 ]
  },
  "id_str" : "407222378960150528",
  "text" : "How can you tell if something's true? https:\/\/t.co\/kxGrgj81cV #sundaypost #cats",
  "id" : 407222378960150528,
  "created_at" : "2013-12-01 18:59:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859425273, -122.275829818 ]
  },
  "id_str" : "407174389709303809",
  "text" : "Rabbit rabbit!",
  "id" : 407174389709303809,
  "created_at" : "2013-12-01 15:48:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]