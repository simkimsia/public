Grailbird.data.tweets_2014_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429489411370127361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597317233, -122.2755235587 ]
  },
  "id_str" : "429490216223518720",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Figured you'd know. Thanks!",
  "id" : 429490216223518720,
  "in_reply_to_status_id" : 429489411370127361,
  "created_at" : "2014-02-01 05:43:41 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429485988969062400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859714394, -122.2756657286 ]
  },
  "id_str" : "429489328465526784",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Better than Torchwood (the other option)?",
  "id" : 429489328465526784,
  "in_reply_to_status_id" : 429485988969062400,
  "created_at" : "2014-02-01 05:40:10 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/yPWDYmOlrV",
      "expanded_url" : "http:\/\/flic.kr\/p\/jE8Fxe",
      "display_url" : "flic.kr\/p\/jE8Fxe"
    } ]
  },
  "geo" : { },
  "id_str" : "429482733275213824",
  "text" : "8:36pm Waiting for Nashville to be over so we can start watching Sherlock. It's good, right? http:\/\/t.co\/yPWDYmOlrV",
  "id" : 429482733275213824,
  "created_at" : "2014-02-01 05:13:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Schneider",
      "screen_name" : "jeress",
      "indices" : [ 0, 7 ],
      "id_str" : "12816492",
      "id" : 12816492
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 8, 16 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429394004967313408",
  "geo" : { },
  "id_str" : "429398417672904704",
  "in_reply_to_user_id" : 12816492,
  "text" : "@jeress @nytimes Yup! Just the twitter:site one though. The twitter:domain tag is not required.",
  "id" : 429398417672904704,
  "in_reply_to_status_id" : 429394004967313408,
  "created_at" : "2014-01-31 23:38:55 +0000",
  "in_reply_to_screen_name" : "jeress",
  "in_reply_to_user_id_str" : "12816492",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Schneider",
      "screen_name" : "jeress",
      "indices" : [ 0, 7 ],
      "id_str" : "12816492",
      "id" : 12816492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429383646374408192",
  "geo" : { },
  "id_str" : "429392120277778432",
  "in_reply_to_user_id" : 12816492,
  "text" : "@jeress If you only implement the twitter:site meta tag without the rest of the Card metadata, you\u2019d still get some analytics.",
  "id" : 429392120277778432,
  "in_reply_to_status_id" : 429383646374408192,
  "created_at" : "2014-01-31 23:13:53 +0000",
  "in_reply_to_screen_name" : "jeress",
  "in_reply_to_user_id_str" : "12816492",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Sherman",
      "screen_name" : "toddsherman",
      "indices" : [ 0, 12 ],
      "id_str" : "10431862",
      "id" : 10431862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429341341412524032",
  "geo" : { },
  "id_str" : "429342069157396480",
  "in_reply_to_user_id" : 10431862,
  "text" : "@toddsherman We don't track that at the moment.",
  "id" : 429342069157396480,
  "in_reply_to_status_id" : 429341341412524032,
  "created_at" : "2014-01-31 19:55:00 +0000",
  "in_reply_to_screen_name" : "toddsherman",
  "in_reply_to_user_id_str" : "10431862",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erica Anderson",
      "screen_name" : "EricaAmerica",
      "indices" : [ 9, 22 ],
      "id_str" : "14124673",
      "id" : 14124673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429335242386583552",
  "geo" : { },
  "id_str" : "429335789126709250",
  "in_reply_to_user_id" : 2185,
  "text" : "Props to @EricaAmerica for her voice acting in the video.",
  "id" : 429335789126709250,
  "in_reply_to_status_id" : 429335242386583552,
  "created_at" : "2014-01-31 19:30:03 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/NCiiw0swJA",
      "expanded_url" : "http:\/\/analytics.twitter.com",
      "display_url" : "analytics.twitter.com"
    }, {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/7TGITCsMCw",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=EtJg3fy_mJU",
      "display_url" : "youtube.com\/watch?v=EtJg3f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429335242386583552",
  "text" : "Want to know what I've been working on at Twitter, but don't have access to http:\/\/t.co\/NCiiw0swJA? Watch this: https:\/\/t.co\/7TGITCsMCw",
  "id" : 429335242386583552,
  "created_at" : "2014-01-31 19:27:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarah jeong",
      "screen_name" : "sarahjeong",
      "indices" : [ 0, 11 ],
      "id_str" : "47509268",
      "id" : 47509268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429286980837707777",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859731447, -122.2753611301 ]
  },
  "id_str" : "429290383294472193",
  "in_reply_to_user_id" : 47509268,
  "text" : "@sarahjeong Ah got it. Yeah definitely things to improve. I'll pass the feedback on.",
  "id" : 429290383294472193,
  "in_reply_to_status_id" : 429286980837707777,
  "created_at" : "2014-01-31 16:29:37 +0000",
  "in_reply_to_screen_name" : "sarahjeong",
  "in_reply_to_user_id_str" : "47509268",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarah jeong",
      "screen_name" : "sarahjeong",
      "indices" : [ 0, 11 ],
      "id_str" : "47509268",
      "id" : 47509268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429285100086640641",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596623473, -122.2755843324 ]
  },
  "id_str" : "429286561377554433",
  "in_reply_to_user_id" : 47509268,
  "text" : "@sarahjeong Have you also used custom timelines? They allow you to drag tweets in from multiple columns and to share it.",
  "id" : 429286561377554433,
  "in_reply_to_status_id" : 429285100086640641,
  "created_at" : "2014-01-31 16:14:26 +0000",
  "in_reply_to_screen_name" : "sarahjeong",
  "in_reply_to_user_id_str" : "47509268",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarah jeong",
      "screen_name" : "sarahjeong",
      "indices" : [ 0, 11 ],
      "id_str" : "47509268",
      "id" : 47509268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429277762114048000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597821555, -122.2754548912 ]
  },
  "id_str" : "429284231789817856",
  "in_reply_to_user_id" : 47509268,
  "text" : "@sarahjeong Have you tried TweetDeck and the new custom timelines? I've used it to scoop up a group conversation a couple times.",
  "id" : 429284231789817856,
  "in_reply_to_status_id" : 429277762114048000,
  "created_at" : "2014-01-31 16:05:11 +0000",
  "in_reply_to_screen_name" : "sarahjeong",
  "in_reply_to_user_id_str" : "47509268",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429279918850338816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596831876, -122.2755374785 ]
  },
  "id_str" : "429281108694286337",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap Here to serve. :) Would love your feedback once stuff is working for you.",
  "id" : 429281108694286337,
  "in_reply_to_status_id" : 429279918850338816,
  "created_at" : "2014-01-31 15:52:46 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    }, {
      "name" : "Frank Chimero",
      "screen_name" : "fchimero",
      "indices" : [ 5, 14 ],
      "id_str" : "13212522",
      "id" : 13212522
    }, {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 15, 23 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/LFxhYjPpdS",
      "expanded_url" : "https:\/\/blog.twitter.com\/2014\/introducing-analytics-for-twitter-cards",
      "display_url" : "blog.twitter.com\/2014\/introduci\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "429279112516341761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596590469, -122.2754390827 ]
  },
  "id_str" : "429279776885321728",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap @fchimero @dcurtis https:\/\/t.co\/LFxhYjPpdS (In the case of Svbtle just need to make twitter:site meta tag the blog owner.)",
  "id" : 429279776885321728,
  "in_reply_to_status_id" : 429279112516341761,
  "created_at" : "2014-01-31 15:47:29 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    }, {
      "name" : "Frank Chimero",
      "screen_name" : "fchimero",
      "indices" : [ 5, 14 ],
      "id_str" : "13212522",
      "id" : 13212522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429277346726969344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596585663, -122.2756523174 ]
  },
  "id_str" : "429279006437801984",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap @fchimero If you implement Cards on your blog you can get all that and more (for free) with the analytics my team just launched. :)",
  "id" : 429279006437801984,
  "in_reply_to_status_id" : 429277346726969344,
  "created_at" : "2014-01-31 15:44:25 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Abrams",
      "screen_name" : "BostonAbrams",
      "indices" : [ 0, 13 ],
      "id_str" : "14499468",
      "id" : 14499468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429275225726148609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597862264, -122.2755268838 ]
  },
  "id_str" : "429277883383554048",
  "in_reply_to_user_id" : 14499468,
  "text" : "@BostonAbrams It only counts Twitter-owned apps, not 3rd party apps or even embeds yet.",
  "id" : 429277883383554048,
  "in_reply_to_status_id" : 429275225726148609,
  "created_at" : "2014-01-31 15:39:57 +0000",
  "in_reply_to_screen_name" : "BostonAbrams",
  "in_reply_to_user_id_str" : "14499468",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Abrams",
      "screen_name" : "BostonAbrams",
      "indices" : [ 0, 13 ],
      "id_str" : "14499468",
      "id" : 14499468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429234834427637760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597061762, -122.2758064655 ]
  },
  "id_str" : "429276497216405504",
  "in_reply_to_user_id" : 14499468,
  "text" : "@BostonAbrams This is definitely possible. I'll look into how much work it would be.",
  "id" : 429276497216405504,
  "in_reply_to_status_id" : 429234834427637760,
  "created_at" : "2014-01-31 15:34:27 +0000",
  "in_reply_to_screen_name" : "BostonAbrams",
  "in_reply_to_user_id_str" : "14499468",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Model View Culture",
      "screen_name" : "ModelViewMedia",
      "indices" : [ 48, 63 ],
      "id_str" : "2262399740",
      "id" : 2262399740
    }, {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 69, 85 ],
      "id_str" : "246531241",
      "id" : 246531241
    }, {
      "name" : "Shanley",
      "screen_name" : "shanley",
      "indices" : [ 86, 94 ],
      "id_str" : "50462250",
      "id" : 50462250
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/429116820700688384\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/UvE7TMzkGa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfSHeYcCYAAjO2u.jpg",
      "id_str" : "429116820532912128",
      "id" : 429116820532912128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfSHeYcCYAAjO2u.jpg",
      "sizes" : [ {
        "h" : 229,
        "resize" : "fit",
        "w" : 304
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 304
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 304
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 304
      } ],
      "display_url" : "pic.twitter.com\/UvE7TMzkGa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7913432375, -122.3927203549 ]
  },
  "id_str" : "429116820700688384",
  "text" : "8:36pm Watching something really great be born: @modelviewmedia! \/cc @ameliagreenhall @shanley http:\/\/t.co\/UvE7TMzkGa",
  "id" : 429116820700688384,
  "created_at" : "2014-01-31 04:59:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Model View Culture",
      "screen_name" : "ModelViewMedia",
      "indices" : [ 9, 24 ],
      "id_str" : "2262399740",
      "id" : 2262399740
    }, {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 44, 60 ],
      "id_str" : "246531241",
      "id" : 246531241
    }, {
      "name" : "New Relic",
      "screen_name" : "newrelic",
      "indices" : [ 66, 75 ],
      "id_str" : "15527007",
      "id" : 15527007
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 82, 92 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/k0WWutuLeb",
      "expanded_url" : "http:\/\/4sq.com\/1fnxyiQ",
      "display_url" : "4sq.com\/1fnxyiQ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7913053979, -122.3923538109 ]
  },
  "id_str" : "429084704382259200",
  "text" : "Here for @ModelViewMedia's launch party! Go @ameliagreenhall! (at @NewRelic HQ w\/ @kellianne) http:\/\/t.co\/k0WWutuLeb",
  "id" : 429084704382259200,
  "created_at" : "2014-01-31 02:52:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 0, 8 ],
      "id_str" : "5699",
      "id" : 5699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429078654606262272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7798876076, -122.4135901653 ]
  },
  "id_str" : "429078981166391297",
  "in_reply_to_user_id" : 5699,
  "text" : "@stewart You really ceased that.",
  "id" : 429078981166391297,
  "in_reply_to_status_id" : 429078654606262272,
  "created_at" : "2014-01-31 02:29:35 +0000",
  "in_reply_to_screen_name" : "stewart",
  "in_reply_to_user_id_str" : "5699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Abrams",
      "screen_name" : "BostonAbrams",
      "indices" : [ 3, 16 ],
      "id_str" : "14499468",
      "id" : 14499468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429078654438494208",
  "text" : "RT @BostonAbrams: I am so geeking out on the improved Twitter Analytics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429030709932478467",
    "text" : "I am so geeking out on the improved Twitter Analytics",
    "id" : 429030709932478467,
    "created_at" : "2014-01-30 23:17:46 +0000",
    "user" : {
      "name" : "Joel Abrams",
      "screen_name" : "BostonAbrams",
      "protected" : false,
      "id_str" : "14499468",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000674811114\/b7b124a25b01bab3107b64c62c14a821_normal.jpeg",
      "id" : 14499468,
      "verified" : true
    }
  },
  "id" : 429078654438494208,
  "created_at" : "2014-01-31 02:28:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 0, 8 ],
      "id_str" : "5699",
      "id" : 5699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429077662493978625",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7798876076, -122.4135901653 ]
  },
  "id_str" : "429078514671693824",
  "in_reply_to_user_id" : 5699,
  "text" : "@stewart You're the new top result. Ouch.",
  "id" : 429078514671693824,
  "in_reply_to_status_id" : 429077662493978625,
  "created_at" : "2014-01-31 02:27:44 +0000",
  "in_reply_to_screen_name" : "stewart",
  "in_reply_to_user_id_str" : "5699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Abrams",
      "screen_name" : "BostonAbrams",
      "indices" : [ 0, 13 ],
      "id_str" : "14499468",
      "id" : 14499468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429076026380279808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7800951753, -122.4135407332 ]
  },
  "id_str" : "429078030904856576",
  "in_reply_to_user_id" : 14499468,
  "text" : "@BostonAbrams Clicks only counts clicks to the URL, so separate from RT counts. And yes top Tweets\/Influencers do count clicks from RTs.",
  "id" : 429078030904856576,
  "in_reply_to_status_id" : 429076026380279808,
  "created_at" : "2014-01-31 02:25:49 +0000",
  "in_reply_to_screen_name" : "BostonAbrams",
  "in_reply_to_user_id_str" : "14499468",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Abrams",
      "screen_name" : "BostonAbrams",
      "indices" : [ 0, 13 ],
      "id_str" : "14499468",
      "id" : 14499468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429034468259536897",
  "geo" : { },
  "id_str" : "429074423123959808",
  "in_reply_to_user_id" : 14499468,
  "text" : "@BostonAbrams I\u2019d love to hear your thoughts. Which chart(s) are most useful for you?",
  "id" : 429074423123959808,
  "in_reply_to_status_id" : 429034468259536897,
  "created_at" : "2014-01-31 02:11:28 +0000",
  "in_reply_to_screen_name" : "BostonAbrams",
  "in_reply_to_user_id_str" : "14499468",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/2zICOGXEM6",
      "expanded_url" : "https:\/\/books.google.com\/ngrams\/graph?content=Are+you+game&year_start=1800&year_end=2000&corpus=15&smoothing=3&share=&direct_url=t1%3B%2CAre%20you%20game%3B%2Cc0",
      "display_url" : "books.google.com\/ngrams\/graph?c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "429071618556448768",
  "geo" : { },
  "id_str" : "429072882669342720",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame Not very helpful but wherever it came from it looks like it peaked in popularity in 1921: https:\/\/t.co\/2zICOGXEM6",
  "id" : 429072882669342720,
  "in_reply_to_status_id" : 429071618556448768,
  "created_at" : "2014-01-31 02:05:21 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uF8FF rosana hermann ",
      "screen_name" : "rosana",
      "indices" : [ 0, 7 ],
      "id_str" : "3948041",
      "id" : 3948041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429040125301882880",
  "geo" : { },
  "id_str" : "429040359348240384",
  "in_reply_to_user_id" : 3948041,
  "text" : "@rosana Okay, I'll look into it.",
  "id" : 429040359348240384,
  "in_reply_to_status_id" : 429040125301882880,
  "created_at" : "2014-01-30 23:56:07 +0000",
  "in_reply_to_screen_name" : "rosana",
  "in_reply_to_user_id_str" : "3948041",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uF8FF rosana hermann ",
      "screen_name" : "rosana",
      "indices" : [ 0, 7 ],
      "id_str" : "3948041",
      "id" : 3948041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/tN47umJIkP",
      "expanded_url" : "http:\/\/ads.twitter.com",
      "display_url" : "ads.twitter.com"
    } ]
  },
  "in_reply_to_status_id_str" : "429039237413875712",
  "geo" : { },
  "id_str" : "429039473779679232",
  "in_reply_to_user_id" : 3948041,
  "text" : "@rosana You're saying that there's no longer an Analytics drop down in the top nav on http:\/\/t.co\/tN47umJIkP? For which account? This one?",
  "id" : 429039473779679232,
  "in_reply_to_status_id" : 429039237413875712,
  "created_at" : "2014-01-30 23:52:36 +0000",
  "in_reply_to_screen_name" : "rosana",
  "in_reply_to_user_id_str" : "3948041",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard MacManus",
      "screen_name" : "ricmac",
      "indices" : [ 0, 7 ],
      "id_str" : "105895323",
      "id" : 105895323
    }, {
      "name" : "TweetDeck",
      "screen_name" : "TweetDeck",
      "indices" : [ 8, 18 ],
      "id_str" : "14803701",
      "id" : 14803701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429032227976916993",
  "geo" : { },
  "id_str" : "429032607284617216",
  "in_reply_to_user_id" : 105895323,
  "text" : "@ricmac @tweetdeck I don\u2019t know. :(",
  "id" : 429032607284617216,
  "in_reply_to_status_id" : 429032227976916993,
  "created_at" : "2014-01-30 23:25:19 +0000",
  "in_reply_to_screen_name" : "ricmac",
  "in_reply_to_user_id_str" : "105895323",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard MacManus",
      "screen_name" : "ricmac",
      "indices" : [ 0, 7 ],
      "id_str" : "105895323",
      "id" : 105895323
    }, {
      "name" : "TweetDeck",
      "screen_name" : "TweetDeck",
      "indices" : [ 8, 18 ],
      "id_str" : "14803701",
      "id" : 14803701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429031800082423809",
  "geo" : { },
  "id_str" : "429032006454767616",
  "in_reply_to_user_id" : 105895323,
  "text" : "@ricmac @tweetdeck Ah, yeah, I've seen that too. I was at least able to re-gain the columns that I had on this computer\u2026",
  "id" : 429032006454767616,
  "in_reply_to_status_id" : 429031800082423809,
  "created_at" : "2014-01-30 23:22:56 +0000",
  "in_reply_to_screen_name" : "ricmac",
  "in_reply_to_user_id_str" : "105895323",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard MacManus",
      "screen_name" : "ricmac",
      "indices" : [ 0, 7 ],
      "id_str" : "105895323",
      "id" : 105895323
    }, {
      "name" : "TweetDeck",
      "screen_name" : "TweetDeck",
      "indices" : [ 8, 18 ],
      "id_str" : "14803701",
      "id" : 14803701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429031303346782208",
  "geo" : { },
  "id_str" : "429031478115065857",
  "in_reply_to_user_id" : 105895323,
  "text" : "@ricmac @tweetdeck Did you use the email\/pass that you set up for TweetDeck? It's diff from your Twitter pass.",
  "id" : 429031478115065857,
  "in_reply_to_status_id" : 429031303346782208,
  "created_at" : "2014-01-30 23:20:50 +0000",
  "in_reply_to_screen_name" : "ricmac",
  "in_reply_to_user_id_str" : "105895323",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard MacManus",
      "screen_name" : "ricmac",
      "indices" : [ 0, 7 ],
      "id_str" : "105895323",
      "id" : 105895323
    }, {
      "name" : "TweetDeck",
      "screen_name" : "TweetDeck",
      "indices" : [ 8, 18 ],
      "id_str" : "14803701",
      "id" : 14803701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428984482012483585",
  "geo" : { },
  "id_str" : "429030166250008576",
  "in_reply_to_user_id" : 105895323,
  "text" : "@ricmac @tweetdeck I logged out and logged in with my email address and old password, and got my columns back.",
  "id" : 429030166250008576,
  "in_reply_to_status_id" : 428984482012483585,
  "created_at" : "2014-01-30 23:15:37 +0000",
  "in_reply_to_screen_name" : "ricmac",
  "in_reply_to_user_id_str" : "105895323",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mac Mahaffee",
      "screen_name" : "MMahaffee",
      "indices" : [ 0, 10 ],
      "id_str" : "322659625",
      "id" : 322659625
    }, {
      "name" : "Amy Baroch Labenski",
      "screen_name" : "TheAmyLab",
      "indices" : [ 11, 21 ],
      "id_str" : "14266010",
      "id" : 14266010
    }, {
      "name" : "Derry London",
      "screen_name" : "Derry_London",
      "indices" : [ 22, 35 ],
      "id_str" : "21658275",
      "id" : 21658275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428980920641519616",
  "geo" : { },
  "id_str" : "429025010691215360",
  "in_reply_to_user_id" : 322659625,
  "text" : "@MMahaffee @TheAmyLab @Derry_London This is a bug and will be resolved. Apologies for the trouble.",
  "id" : 429025010691215360,
  "in_reply_to_status_id" : 428980920641519616,
  "created_at" : "2014-01-30 22:55:08 +0000",
  "in_reply_to_screen_name" : "MMahaffee",
  "in_reply_to_user_id_str" : "322659625",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Zasada",
      "screen_name" : "kzasada",
      "indices" : [ 0, 8 ],
      "id_str" : "5652902",
      "id" : 5652902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429015792147914752",
  "geo" : { },
  "id_str" : "429016016383799296",
  "in_reply_to_user_id" : 5652902,
  "text" : "@kzasada No problem. Let me know if you have any questions or feedback about the analytics once it's set up.",
  "id" : 429016016383799296,
  "in_reply_to_status_id" : 429015792147914752,
  "created_at" : "2014-01-30 22:19:23 +0000",
  "in_reply_to_screen_name" : "kzasada",
  "in_reply_to_user_id_str" : "5652902",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Zasada",
      "screen_name" : "kzasada",
      "indices" : [ 0, 8 ],
      "id_str" : "5652902",
      "id" : 5652902
    }, {
      "name" : "Shapeways",
      "screen_name" : "shapeways",
      "indices" : [ 85, 95 ],
      "id_str" : "15536454",
      "id" : 15536454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/EeNSjSPtvU",
      "expanded_url" : "https:\/\/support.twitter.com\/groups\/58-advertising\/topics\/247-analytics\/articles\/20170934-twitter-card-analytics-dashboard",
      "display_url" : "support.twitter.com\/groups\/58-adve\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "429011162378682368",
  "geo" : { },
  "id_str" : "429014547983130624",
  "in_reply_to_user_id" : 5652902,
  "text" : "@kzasada You're missing one required tag: the twitter:site tag that links the URL to @shapeways. Learn more here: https:\/\/t.co\/EeNSjSPtvU",
  "id" : 429014547983130624,
  "in_reply_to_status_id" : 429011162378682368,
  "created_at" : "2014-01-30 22:13:33 +0000",
  "in_reply_to_screen_name" : "kzasada",
  "in_reply_to_user_id_str" : "5652902",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 10, 18 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "indices" : [ 19, 28 ],
      "id_str" : "9938952",
      "id" : 9938952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428977356037181441",
  "geo" : { },
  "id_str" : "428977585503358976",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @dreeves @mdbraber Exploration and learning require work but results are free. Right?",
  "id" : 428977585503358976,
  "in_reply_to_status_id" : 428977356037181441,
  "created_at" : "2014-01-30 19:46:41 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428963654298787840",
  "geo" : { },
  "id_str" : "428975526913404928",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver *brain explodes* and for that matter are you moving it up or down?",
  "id" : 428975526913404928,
  "in_reply_to_status_id" : 428963654298787840,
  "created_at" : "2014-01-30 19:38:30 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 8, 11 ],
      "id_str" : "15504330",
      "id" : 15504330
    }, {
      "name" : "Josh Elman",
      "screen_name" : "joshelman",
      "indices" : [ 12, 22 ],
      "id_str" : "1979921",
      "id" : 1979921
    }, {
      "name" : "Omid Ashtari",
      "screen_name" : "omid",
      "indices" : [ 23, 28 ],
      "id_str" : "114971521",
      "id" : 114971521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428969111407063040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763537189, -122.4172415895 ]
  },
  "id_str" : "428973812743294976",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach @wm @joshelman @omid *scrambles over to Tumblr to claim the blog*",
  "id" : 428973812743294976,
  "in_reply_to_status_id" : 428969111407063040,
  "created_at" : "2014-01-30 19:31:41 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/wd0ETqRnpw",
      "expanded_url" : "https:\/\/books.google.com\/ngrams\/graph?content=coming+down+the+pike%2Ccoming+down+the+pipe&year_start=1890&year_end=2008&corpus=15&smoothing=3&share=&direct_url=t1%3B%2Ccoming%20down%20the%20pike%3B%2Cc0%3B.t1%3B%2Ccoming%20down%20the%20pipe%3B%2Cc0",
      "display_url" : "books.google.com\/ngrams\/graph?c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428962288603656192",
  "text" : "I love using Google's ngram viewer to resolve usage of idioms that I don't understand: \"coming down the pike\/pipe\"? https:\/\/t.co\/wd0ETqRnpw",
  "id" : 428962288603656192,
  "created_at" : "2014-01-30 18:45:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 10, 18 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "indices" : [ 19, 28 ],
      "id_str" : "9938952",
      "id" : 9938952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428952580006244352",
  "geo" : { },
  "id_str" : "428953212087828480",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @dreeves @mdbraber Nothing very new, just the eternal battle for the entire health\/fitness market to lie in order to survive.",
  "id" : 428953212087828480,
  "in_reply_to_status_id" : 428952580006244352,
  "created_at" : "2014-01-30 18:09:49 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "indices" : [ 10, 19 ],
      "id_str" : "9938952",
      "id" : 9938952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428949259887448064",
  "geo" : { },
  "id_str" : "428950964381286400",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @mdbraber Exactly. I think it's actually great for media to call inaccurate marketing out. You should blog about this too.",
  "id" : 428950964381286400,
  "in_reply_to_status_id" : 428949259887448064,
  "created_at" : "2014-01-30 18:00:54 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "indices" : [ 10, 19 ],
      "id_str" : "9938952",
      "id" : 9938952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428947331044483072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762659884, -122.4168112074 ]
  },
  "id_str" : "428948945172066304",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @mdbraber You have to admit that these tracking tools do market themselves as magic pills a bit, right?",
  "id" : 428948945172066304,
  "in_reply_to_status_id" : 428947331044483072,
  "created_at" : "2014-01-30 17:52:52 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "news",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8449457356, -122.2706039855 ]
  },
  "id_str" : "428939812834263040",
  "text" : "Original point isn't catchy enough. Wrap it in provocative shell. People react violently to provocative shell, discard original point. #news",
  "id" : 428939812834263040,
  "created_at" : "2014-01-30 17:16:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "indices" : [ 50, 64 ],
      "id_str" : "1236101",
      "id" : 1236101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/CyHh7lekLg",
      "expanded_url" : "https:\/\/www.facebook.com\/labs",
      "display_url" : "facebook.com\/labs"
    } ]
  },
  "in_reply_to_status_id_str" : "428926305024106496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597046669, -122.275526143 ]
  },
  "id_str" : "428932460861091840",
  "in_reply_to_user_id" : 1236101,
  "text" : "This is way more interesting than Paper itself RT @BenedictEvans: Facebook Labs. Expect a steady flow of FB apps. https:\/\/t.co\/CyHh7lekLg",
  "id" : 428932460861091840,
  "in_reply_to_status_id" : 428926305024106496,
  "created_at" : "2014-01-30 16:47:22 +0000",
  "in_reply_to_screen_name" : "BenedictEvans",
  "in_reply_to_user_id_str" : "1236101",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/JKyCbXYeiX",
      "expanded_url" : "http:\/\/recode.net\/2014\/01\/30\/meet-paper-facebooks-answer-to-browsing-and-creating-mobile-media\/",
      "display_url" : "recode.net\/2014\/01\/30\/mee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428894280732516352",
  "text" : "Wow, Facebook's got a new app:  http:\/\/t.co\/JKyCbXYeiX",
  "id" : 428894280732516352,
  "created_at" : "2014-01-30 14:15:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 0, 5 ],
      "id_str" : "541",
      "id" : 541
    }, {
      "name" : "Liz Kuball",
      "screen_name" : "lizkuball",
      "indices" : [ 6, 16 ],
      "id_str" : "71949776",
      "id" : 71949776
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 25, 36 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428783075481243648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596718667, -122.2755071041 ]
  },
  "id_str" : "428795199888699392",
  "in_reply_to_user_id" : 541,
  "text" : "@lane @lizkuball You and @nikobenson need to become chat friends.",
  "id" : 428795199888699392,
  "in_reply_to_status_id" : 428783075481243648,
  "created_at" : "2014-01-30 07:41:56 +0000",
  "in_reply_to_screen_name" : "lane",
  "in_reply_to_user_id_str" : "541",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 0, 14 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428785305270120448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597225317, -122.2755569971 ]
  },
  "id_str" : "428787268799569921",
  "in_reply_to_user_id" : 2185,
  "text" : "@marcprecipice And we talked about you, your moving boxes in the rain, and how they need to move to the east bay.",
  "id" : 428787268799569921,
  "in_reply_to_status_id" : 428785305270120448,
  "created_at" : "2014-01-30 07:10:26 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 3, 16 ],
      "id_str" : "14095370",
      "id" : 14095370
    }, {
      "name" : "Dan Savage",
      "screen_name" : "fakedansavage",
      "indices" : [ 34, 48 ],
      "id_str" : "313091751",
      "id" : 313091751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/G7KTEPtOrK",
      "expanded_url" : "http:\/\/slog.thestranger.com\/slog\/archives\/2014\/01\/28\/to-queers-bitching-about-macklemore-and-ryan-lewis",
      "display_url" : "slog.thestranger.com\/slog\/archives\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428786788899901440",
  "text" : "RT @OffbeatAriel: Thanks for this @fakedansavage http:\/\/t.co\/G7KTEPtOrK Been trying to find a way to talk about the issue and failing. This\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dan Savage",
        "screen_name" : "fakedansavage",
        "indices" : [ 16, 30 ],
        "id_str" : "313091751",
        "id" : 313091751
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/G7KTEPtOrK",
        "expanded_url" : "http:\/\/slog.thestranger.com\/slog\/archives\/2014\/01\/28\/to-queers-bitching-about-macklemore-and-ryan-lewis",
        "display_url" : "slog.thestranger.com\/slog\/archives\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "428734669832482816",
    "text" : "Thanks for this @fakedansavage http:\/\/t.co\/G7KTEPtOrK Been trying to find a way to talk about the issue and failing. This nails it.",
    "id" : 428734669832482816,
    "created_at" : "2014-01-30 03:41:25 +0000",
    "user" : {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "protected" : false,
      "id_str" : "14095370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456272250744754177\/cdia5MOI_normal.jpeg",
      "id" : 14095370,
      "verified" : false
    }
  },
  "id" : 428786788899901440,
  "created_at" : "2014-01-30 07:08:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 30, 46 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Sarah Milstein",
      "screen_name" : "SarahM",
      "indices" : [ 51, 58 ],
      "id_str" : "57",
      "id" : 57
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/Ml4aVdSaca",
      "expanded_url" : "http:\/\/flic.kr\/p\/jBzoKp",
      "display_url" : "flic.kr\/p\/jBzoKp"
    } ]
  },
  "geo" : { },
  "id_str" : "428785305270120448",
  "text" : "8:36pm Visited by the amazing @tonystubblebine and @sarahm http:\/\/t.co\/Ml4aVdSaca",
  "id" : 428785305270120448,
  "created_at" : "2014-01-30 07:02:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eli Tucker",
      "screen_name" : "etucker",
      "indices" : [ 0, 8 ],
      "id_str" : "5559292",
      "id" : 5559292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428748004166627329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597282981, -122.2756448725 ]
  },
  "id_str" : "428784411333505024",
  "in_reply_to_user_id" : 5559292,
  "text" : "@etucker Hell no. :)",
  "id" : 428784411333505024,
  "in_reply_to_status_id" : 428748004166627329,
  "created_at" : "2014-01-30 06:59:04 +0000",
  "in_reply_to_screen_name" : "etucker",
  "in_reply_to_user_id_str" : "5559292",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 3, 9 ],
      "id_str" : "8285392",
      "id" : 8285392
    }, {
      "name" : "Dataminr",
      "screen_name" : "Dataminr",
      "indices" : [ 12, 21 ],
      "id_str" : "266717381",
      "id" : 266717381
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 24, 32 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/cy34F0f2y7",
      "expanded_url" : "http:\/\/www.usatoday.com\/story\/money\/business\/2014\/01\/29\/dataminr-for-news-launched\/5035717\/",
      "display_url" : "usatoday.com\/story\/money\/bu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428715969121239040",
  "text" : "RT @raffi: \u200B@Dataminr + @twitter = breaking news detection \u2192 \u201Calert re: \u2026 bin Laden's death 23 min before it was reported\u201D http:\/\/t.co\/cy34\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dataminr",
        "screen_name" : "Dataminr",
        "indices" : [ 1, 10 ],
        "id_str" : "266717381",
        "id" : 266717381
      }, {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 13, 21 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/cy34F0f2y7",
        "expanded_url" : "http:\/\/www.usatoday.com\/story\/money\/business\/2014\/01\/29\/dataminr-for-news-launched\/5035717\/",
        "display_url" : "usatoday.com\/story\/money\/bu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "428711777904230400",
    "text" : "\u200B@Dataminr + @twitter = breaking news detection \u2192 \u201Calert re: \u2026 bin Laden's death 23 min before it was reported\u201D http:\/\/t.co\/cy34F0f2y7",
    "id" : 428711777904230400,
    "created_at" : "2014-01-30 02:10:27 +0000",
    "user" : {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "protected" : false,
      "id_str" : "8285392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1270234259\/raffi-headshot-casual_normal.png",
      "id" : 8285392,
      "verified" : false
    }
  },
  "id" : 428715969121239040,
  "created_at" : "2014-01-30 02:27:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/M8imXaX75L",
      "expanded_url" : "http:\/\/www.economist.com\/blogs\/babbage\/2014\/01\/quantum-computing?utm_content=buffer8ca22&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "economist.com\/blogs\/babbage\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8019203293, -122.2858200689 ]
  },
  "id_str" : "428712419834077184",
  "text" : "So far quantum computers haven't proven to be consistently faster than regular computers. http:\/\/t.co\/M8imXaX75L",
  "id" : 428712419834077184,
  "created_at" : "2014-01-30 02:13:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BREAKING",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7785243909, -122.4148195703 ]
  },
  "id_str" : "428708028154511360",
  "text" : "#BREAKING Turns out suicidal murderer had been thinking murderous suicidal thoughts.",
  "id" : 428708028154511360,
  "created_at" : "2014-01-30 01:55:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca Searles",
      "screen_name" : "beccabigwords",
      "indices" : [ 0, 14 ],
      "id_str" : "73200912",
      "id" : 73200912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427910141003177984",
  "geo" : { },
  "id_str" : "428416983806115840",
  "in_reply_to_user_id" : 73200912,
  "text" : "@beccabigwords Let me know if you have any questions about it.",
  "id" : 428416983806115840,
  "in_reply_to_status_id" : 427910141003177984,
  "created_at" : "2014-01-29 06:39:03 +0000",
  "in_reply_to_screen_name" : "beccabigwords",
  "in_reply_to_user_id_str" : "73200912",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Underwood",
      "screen_name" : "aunder",
      "indices" : [ 0, 7 ],
      "id_str" : "4265731",
      "id" : 4265731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428402834787143680",
  "geo" : { },
  "id_str" : "428416637356613632",
  "in_reply_to_user_id" : 4265731,
  "text" : "@aunder don\u2019t have to tell me twi\u2026 zzzzzz.",
  "id" : 428416637356613632,
  "in_reply_to_status_id" : 428402834787143680,
  "created_at" : "2014-01-29 06:37:40 +0000",
  "in_reply_to_screen_name" : "aunder",
  "in_reply_to_user_id_str" : "4265731",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/vrdOWM9Yqo",
      "expanded_url" : "http:\/\/flic.kr\/p\/jA8qyT",
      "display_url" : "flic.kr\/p\/jA8qyT"
    } ]
  },
  "geo" : { },
  "id_str" : "428402455404359680",
  "text" : "8:36pm Was working on slides but now falling asleep http:\/\/t.co\/vrdOWM9Yqo",
  "id" : 428402455404359680,
  "created_at" : "2014-01-29 05:41:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/UIdz4KKpRX",
      "expanded_url" : "http:\/\/flic.kr\/p\/jyFoN7",
      "display_url" : "flic.kr\/p\/jyFoN7"
    } ]
  },
  "geo" : { },
  "id_str" : "428025210017939456",
  "text" : "8:36pm Working on some fun, but unphotogenic, scripts for my next work project. http:\/\/t.co\/UIdz4KKpRX",
  "id" : 428025210017939456,
  "created_at" : "2014-01-28 04:42:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Spiegel",
      "screen_name" : "evanspiegel",
      "indices" : [ 69, 81 ],
      "id_str" : "230287527",
      "id" : 230287527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427992760306524161",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7996633342, -122.2801036948 ]
  },
  "id_str" : "427995881221025792",
  "in_reply_to_user_id" : 2185,
  "text" : "\"When we start communicating through media we light up. It's fun.\" - @evanspiegel",
  "id" : 427995881221025792,
  "in_reply_to_status_id" : 427992760306524161,
  "created_at" : "2014-01-28 02:45:44 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427992150173679616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7844533967, -122.4078819106 ]
  },
  "id_str" : "427992760306524161",
  "in_reply_to_user_id" : 2185,
  "text" : "--&gt; \"With ephemerality, communication is done through photos rather than around them.\" &lt;--",
  "id" : 427992760306524161,
  "in_reply_to_status_id" : 427992150173679616,
  "created_at" : "2014-01-28 02:33:20 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427991233286250496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7798244158, -122.413616591 ]
  },
  "id_str" : "427992150173679616",
  "in_reply_to_user_id" : 2185,
  "text" : "\"The tension between experience for its own sake and experience we pursue just to put on Facebook is reaching its breaking point.\"",
  "id" : 427992150173679616,
  "in_reply_to_status_id" : 427991233286250496,
  "created_at" : "2014-01-28 02:30:54 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nathanjurgenson",
      "screen_name" : "nathanjurgenson",
      "indices" : [ 123, 139 ],
      "id_str" : "66025575",
      "id" : 66025575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427991233286250496",
  "text" : "Are you a digital dualist? \"Digital dualists believe that the digital world is 'virtual' and the physical world 'real.'\" - @nathanjurgenson",
  "id" : 427991233286250496,
  "created_at" : "2014-01-28 02:27:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7798423872, -122.4136108145 ]
  },
  "id_str" : "427989324408184832",
  "text" : "I sort of like Facebook's really wacky navigation between the main app and Messenger. Lots of hopping around but I end up where I wanna be.",
  "id" : 427989324408184832,
  "created_at" : "2014-01-28 02:19:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 3, 17 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427964975064166401",
  "text" : "RT @buster_ebooks: Not directly but here's a startup idea: zipcar for condiments",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/busterbenson.com\" rel=\"nofollow\"\u003EBuster eBooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427941376831922176",
    "text" : "Not directly but here's a startup idea: zipcar for condiments",
    "id" : 427941376831922176,
    "created_at" : "2014-01-27 23:09:09 +0000",
    "user" : {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "protected" : false,
      "id_str" : "1901375096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000503050571\/228ccabfeeb4e55bd8e172595babe02e_normal.jpeg",
      "id" : 1901375096,
      "verified" : false
    }
  },
  "id" : 427964975064166401,
  "created_at" : "2014-01-28 00:42:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hall",
      "screen_name" : "JamesHallPhoto",
      "indices" : [ 0, 15 ],
      "id_str" : "63792306",
      "id" : 63792306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427945344505114624",
  "geo" : { },
  "id_str" : "427946892182716416",
  "in_reply_to_user_id" : 63792306,
  "text" : "@jameshallphoto Hmmmmm\u2026 I think you'd find the Thinking Fast and Slow one more riveting, by a smidge.",
  "id" : 427946892182716416,
  "in_reply_to_status_id" : 427945344505114624,
  "created_at" : "2014-01-27 23:31:04 +0000",
  "in_reply_to_screen_name" : "JamesHallPhoto",
  "in_reply_to_user_id_str" : "63792306",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hall",
      "screen_name" : "JamesHallPhoto",
      "indices" : [ 0, 15 ],
      "id_str" : "63792306",
      "id" : 63792306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427895227806785536",
  "geo" : { },
  "id_str" : "427941688338677760",
  "in_reply_to_user_id" : 63792306,
  "text" : "@jameshallphoto I listened to them both on audiobook and thoroughly enjoyed them (probably more than if I had read the books).",
  "id" : 427941688338677760,
  "in_reply_to_status_id" : 427895227806785536,
  "created_at" : "2014-01-27 23:10:23 +0000",
  "in_reply_to_screen_name" : "JamesHallPhoto",
  "in_reply_to_user_id_str" : "63792306",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hall",
      "screen_name" : "JamesHallPhoto",
      "indices" : [ 0, 15 ],
      "id_str" : "63792306",
      "id" : 63792306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427895227806785536",
  "geo" : { },
  "id_str" : "427941577445498880",
  "in_reply_to_user_id" : 63792306,
  "text" : "@jameshallphoto I think you'd like both Thinking Fast and Slow and Antifragile. The topics are awesome and authors are characters.",
  "id" : 427941577445498880,
  "in_reply_to_status_id" : 427895227806785536,
  "created_at" : "2014-01-27 23:09:57 +0000",
  "in_reply_to_screen_name" : "JamesHallPhoto",
  "in_reply_to_user_id_str" : "63792306",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 0, 8 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427941087710162944",
  "geo" : { },
  "id_str" : "427941332741398529",
  "in_reply_to_user_id" : 958581,
  "text" : "@rdicker HOOOOOOOOOLY \u2026",
  "id" : 427941332741398529,
  "in_reply_to_status_id" : 427941087710162944,
  "created_at" : "2014-01-27 23:08:59 +0000",
  "in_reply_to_screen_name" : "rdicker",
  "in_reply_to_user_id_str" : "958581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 0, 8 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427934351183986688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762778003, -122.4174077405 ]
  },
  "id_str" : "427940419305893888",
  "in_reply_to_user_id" : 958581,
  "text" : "@rdicker Nice! How many years did you end up with at Amazon?",
  "id" : 427940419305893888,
  "in_reply_to_status_id" : 427934351183986688,
  "created_at" : "2014-01-27 23:05:21 +0000",
  "in_reply_to_screen_name" : "rdicker",
  "in_reply_to_user_id_str" : "958581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hall",
      "screen_name" : "JamesHallPhoto",
      "indices" : [ 0, 15 ],
      "id_str" : "63792306",
      "id" : 63792306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427891542301224960",
  "geo" : { },
  "id_str" : "427891746635132929",
  "in_reply_to_user_id" : 63792306,
  "text" : "@jameshallphoto Fiction or nonfiction? Serious or entertaining?",
  "id" : 427891746635132929,
  "in_reply_to_status_id" : 427891542301224960,
  "created_at" : "2014-01-27 19:51:56 +0000",
  "in_reply_to_screen_name" : "JamesHallPhoto",
  "in_reply_to_user_id_str" : "63792306",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 89, 93 ],
      "id_str" : "259",
      "id" : 259
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 98, 108 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/427695016635408384\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/Sxw1VUarcK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Be96WffCMAAAVkb.jpg",
      "id_str" : "427695016450863104",
      "id" : 427695016450863104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be96WffCMAAAVkb.jpg",
      "sizes" : [ {
        "h" : 702,
        "resize" : "fit",
        "w" : 935
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 935
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Sxw1VUarcK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427695016635408384",
  "text" : "8:36pm Was geeking out on the bike touring page of Kevin Kelly's Cool Tools catalog with @ian and @kellianne http:\/\/t.co\/Sxw1VUarcK",
  "id" : 427695016635408384,
  "created_at" : "2014-01-27 06:50:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427600841734774784",
  "geo" : { },
  "id_str" : "427615007258341377",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover Done!",
  "id" : 427615007258341377,
  "in_reply_to_status_id" : 427600841734774784,
  "created_at" : "2014-01-27 01:32:17 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Xft6OVBWQH",
      "expanded_url" : "http:\/\/freakngenius.com\/yak\/63CB",
      "display_url" : "freakngenius.com\/yak\/63CB"
    } ]
  },
  "geo" : { },
  "id_str" : "427600126954065920",
  "text" : "http:\/\/t.co\/Xft6OVBWQH just setting up my YAKiT",
  "id" : 427600126954065920,
  "created_at" : "2014-01-27 00:33:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/427529508623626240\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/nwx2E86A0n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Be7j0p3CcAAeoF5.jpg",
      "id_str" : "427529508376178688",
      "id" : 427529508376178688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be7j0p3CcAAeoF5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/nwx2E86A0n"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8805947584, -122.223016061 ]
  },
  "id_str" : "427529508623626240",
  "text" : "Niko hasn't been on the steam trains for a few months and claims that they used to be a lot bigger. http:\/\/t.co\/nwx2E86A0n",
  "id" : 427529508623626240,
  "created_at" : "2014-01-26 19:52:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taggart Matthiesen",
      "screen_name" : "taggart",
      "indices" : [ 0, 8 ],
      "id_str" : "34045232",
      "id" : 34045232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427519073363042304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8800379066, -122.2222852429 ]
  },
  "id_str" : "427525890277265408",
  "in_reply_to_user_id" : 34045232,
  "text" : "@taggart Send me info please!",
  "id" : 427525890277265408,
  "in_reply_to_status_id" : 427519073363042304,
  "created_at" : "2014-01-26 19:38:09 +0000",
  "in_reply_to_screen_name" : "taggart",
  "in_reply_to_user_id_str" : "34045232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelsey Falter",
      "screen_name" : "kfalter",
      "indices" : [ 0, 8 ],
      "id_str" : "253578873",
      "id" : 253578873
    }, {
      "name" : "Bianca L. St.Louis",
      "screen_name" : "beLaurie",
      "indices" : [ 9, 18 ],
      "id_str" : "92143477",
      "id" : 92143477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427509523608506368",
  "geo" : { },
  "id_str" : "427510635060924416",
  "in_reply_to_user_id" : 253578873,
  "text" : "@kfalter @beLaurie I like this idea.",
  "id" : 427510635060924416,
  "in_reply_to_status_id" : 427509523608506368,
  "created_at" : "2014-01-26 18:37:32 +0000",
  "in_reply_to_screen_name" : "kfalter",
  "in_reply_to_user_id_str" : "253578873",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427508344970948608",
  "text" : "Okay who can recommend me a good tax advisor in the Berkeley area?",
  "id" : 427508344970948608,
  "created_at" : "2014-01-26 18:28:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 3, 10 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Ethan Siegel",
      "screen_name" : "StartsWithABang",
      "indices" : [ 52, 68 ],
      "id_str" : "280811825",
      "id" : 280811825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/yf12IlYHNJ",
      "expanded_url" : "https:\/\/medium.com\/p\/9153a05bd0d5?utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
      "display_url" : "medium.com\/p\/9153a05bd0d5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427471675043495936",
  "text" : "RT @Medium: \u201CHow Many Planets  In The Universe?\u201D by @StartsWithABang https:\/\/t.co\/yf12IlYHNJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ethan Siegel",
        "screen_name" : "StartsWithABang",
        "indices" : [ 40, 56 ],
        "id_str" : "280811825",
        "id" : 280811825
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/yf12IlYHNJ",
        "expanded_url" : "https:\/\/medium.com\/p\/9153a05bd0d5?utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
        "display_url" : "medium.com\/p\/9153a05bd0d5\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "427313702413426688",
    "text" : "\u201CHow Many Planets  In The Universe?\u201D by @StartsWithABang https:\/\/t.co\/yf12IlYHNJ",
    "id" : 427313702413426688,
    "created_at" : "2014-01-26 05:35:00 +0000",
    "user" : {
      "name" : "Medium",
      "screen_name" : "Medium",
      "protected" : false,
      "id_str" : "571202103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2504297462\/wtbq3hoquj8no6t2ysz4_normal.jpeg",
      "id" : 571202103,
      "verified" : true
    }
  },
  "id" : 427471675043495936,
  "created_at" : "2014-01-26 16:02:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 3, 12 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/OeM7y80ksb",
      "expanded_url" : "http:\/\/metatalk.metafilter.com\/23105\/Can-You-Ace-This-One-Weird-Quiz-CLICK-HERE-to-Find-Out",
      "display_url" : "metatalk.metafilter.com\/23105\/Can-You-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427468626757554178",
  "text" : "RT @mathowie: \"They Told This Guy That He Couldn't Simply Walk Into Mordor. What He Did Next Will Inspire You.\" Upworthyized books: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/OeM7y80ksb",
        "expanded_url" : "http:\/\/metatalk.metafilter.com\/23105\/Can-You-Ace-This-One-Weird-Quiz-CLICK-HERE-to-Find-Out",
        "display_url" : "metatalk.metafilter.com\/23105\/Can-You-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "427460428587745281",
    "text" : "\"They Told This Guy That He Couldn't Simply Walk Into Mordor. What He Did Next Will Inspire You.\" Upworthyized books: http:\/\/t.co\/OeM7y80ksb",
    "id" : 427460428587745281,
    "created_at" : "2014-01-26 15:18:02 +0000",
    "user" : {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "protected" : false,
      "id_str" : "761975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463101305972465664\/xjD_-7Jl_normal.jpeg",
      "id" : 761975,
      "verified" : false
    }
  },
  "id" : 427468626757554178,
  "created_at" : "2014-01-26 15:50:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/427311188674744320\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/3gov01s4nT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Be4dQwqCYAAL8Ak.jpg",
      "id_str" : "427311188423106560",
      "id" : 427311188423106560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be4dQwqCYAAL8Ak.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3gov01s4nT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8572702881, -122.2752810309 ]
  },
  "id_str" : "427311188674744320",
  "text" : "8:36pm Fun neighbor times http:\/\/t.co\/3gov01s4nT",
  "id" : 427311188674744320,
  "created_at" : "2014-01-26 05:25:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 35, 44 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427225577167138817",
  "geo" : { },
  "id_str" : "427243677052698624",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine Not really. Maybe @eramirez does?",
  "id" : 427243677052698624,
  "in_reply_to_status_id" : 427225577167138817,
  "created_at" : "2014-01-26 00:56:45 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427222911984734208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597681692, -122.2755524393 ]
  },
  "id_str" : "427223286162800641",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel He really has a soft spot for the Ood. He understands that some of them were mean for a bit but that they then turned nice again.",
  "id" : 427223286162800641,
  "in_reply_to_status_id" : 427222911984734208,
  "created_at" : "2014-01-25 23:35:43 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427189521340305408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596510555, -122.27551771 ]
  },
  "id_str" : "427220943715303425",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine Do you plan on sharing the raw data once it's complete?",
  "id" : 427220943715303425,
  "in_reply_to_status_id" : 427189521340305408,
  "created_at" : "2014-01-25 23:26:25 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859765559, -122.2755988946 ]
  },
  "id_str" : "427220583588192256",
  "text" : "I mentioned taking an Uber to Niko. He thought it had something to do with the Ood from Doctor Who, but he also assured me they were nice.",
  "id" : 427220583588192256,
  "created_at" : "2014-01-25 23:24:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen",
      "screen_name" : "gln",
      "indices" : [ 0, 4 ],
      "id_str" : "4366051",
      "id" : 4366051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427133660207140864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597940155, -122.2753949025 ]
  },
  "id_str" : "427134735215644672",
  "in_reply_to_user_id" : 2185,
  "text" : "@gln That may have been the reporter misrepresenting a nerd. The fact that he really did want to find love proves to me he wasn't a creep.",
  "id" : 427134735215644672,
  "in_reply_to_status_id" : 427133660207140864,
  "created_at" : "2014-01-25 17:43:51 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen",
      "screen_name" : "gln",
      "indices" : [ 0, 4 ],
      "id_str" : "4366051",
      "id" : 4366051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427132818318045185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597196665, -122.275368103 ]
  },
  "id_str" : "427133660207140864",
  "in_reply_to_user_id" : 4366051,
  "text" : "@gln The creepiness mostly came from the idea of bucketing (bindering?) thousands of women into categories. Because that is creepy.",
  "id" : 427133660207140864,
  "in_reply_to_status_id" : 427132818318045185,
  "created_at" : "2014-01-25 17:39:35 +0000",
  "in_reply_to_screen_name" : "gln",
  "in_reply_to_user_id_str" : "4366051",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    }, {
      "name" : "Sebastian Motraghi",
      "screen_name" : "seb_m",
      "indices" : [ 8, 14 ],
      "id_str" : "14147974",
      "id" : 14147974
    }, {
      "name" : "Aaron Durand",
      "screen_name" : "everydaydude",
      "indices" : [ 15, 28 ],
      "id_str" : "14715999",
      "id" : 14715999
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 29, 35 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427124928333107200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596947147, -122.2755504067 ]
  },
  "id_str" : "427131271236423680",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez @seb_m @everydaydude @couch Awesome! Let me know when that happens!",
  "id" : 427131271236423680,
  "in_reply_to_status_id" : 427124928333107200,
  "created_at" : "2014-01-25 17:30:05 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/pFCzxs4bIg",
      "expanded_url" : "http:\/\/www.wired.com\/wiredscience\/2014\/01\/how-to-hack-okcupid\/",
      "display_url" : "wired.com\/wiredscience\/2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "427123571194740738",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597284295, -122.2754765489 ]
  },
  "id_str" : "427123990667067392",
  "in_reply_to_user_id" : 2185,
  "text" : "Also hadn't thought to make a bot, like this guy. http:\/\/t.co\/pFCzxs4bIg",
  "id" : 427123990667067392,
  "in_reply_to_status_id" : 427123571194740738,
  "created_at" : "2014-01-25 17:01:09 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597062044, -122.2755040975 ]
  },
  "id_str" : "427123571194740738",
  "text" : "Back in 2004 I went on about 50 first dates via various dating sites, and made 3 friends but found no love.",
  "id" : 427123571194740738,
  "created_at" : "2014-01-25 16:59:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nein.",
      "screen_name" : "NeinQuarterly",
      "indices" : [ 3, 17 ],
      "id_str" : "458966079",
      "id" : 458966079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427110997975773185",
  "text" : "RT @NeinQuarterly: Twitter's the best thing that ever happened to the missed subway stop.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427107243579158529",
    "text" : "Twitter's the best thing that ever happened to the missed subway stop.",
    "id" : 427107243579158529,
    "created_at" : "2014-01-25 15:54:36 +0000",
    "user" : {
      "name" : "Nein.",
      "screen_name" : "NeinQuarterly",
      "protected" : false,
      "id_str" : "458966079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000829092209\/ed4c25faaa25fbba40b11fabe8241a59_normal.jpeg",
      "id" : 458966079,
      "verified" : true
    }
  },
  "id" : 427110997975773185,
  "created_at" : "2014-01-25 16:09:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426827483057381376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597397665, -122.2755533814 ]
  },
  "id_str" : "427106754153832448",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez I'd love to join the lunch bus.",
  "id" : 427106754153832448,
  "in_reply_to_status_id" : 426827483057381376,
  "created_at" : "2014-01-25 15:52:40 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426965493598404609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596813465, -122.275468354 ]
  },
  "id_str" : "426965819734507520",
  "in_reply_to_user_id" : 2185,
  "text" : "...sleepiness.",
  "id" : 426965819734507520,
  "in_reply_to_status_id" : 426965493598404609,
  "created_at" : "2014-01-25 06:32:38 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/7HKZgB5HFG",
      "expanded_url" : "http:\/\/flic.kr\/p\/jtP19R",
      "display_url" : "flic.kr\/p\/jtP19R"
    } ]
  },
  "geo" : { },
  "id_str" : "426965493598404609",
  "text" : "8:36pm Strange how difficult it is to take a blurry iPhone picture to properly capture feeling of extreme... http:\/\/t.co\/7HKZgB5HFG",
  "id" : 426965493598404609,
  "created_at" : "2014-01-25 06:31:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    }, {
      "name" : "Jeff Currier",
      "screen_name" : "jeff_currier",
      "indices" : [ 12, 25 ],
      "id_str" : "626155328",
      "id" : 626155328
    }, {
      "name" : "Lisa Phillips",
      "screen_name" : "lisaphillips",
      "indices" : [ 26, 39 ],
      "id_str" : "733383",
      "id" : 733383
    }, {
      "name" : "Rob Benson",
      "screen_name" : "rgbenson",
      "indices" : [ 40, 49 ],
      "id_str" : "22888677",
      "id" : 22888677
    }, {
      "name" : "Twitter Seattle",
      "screen_name" : "TwitterSeattle",
      "indices" : [ 50, 65 ],
      "id_str" : "1228433617",
      "id" : 1228433617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426921352100986880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597648632, -122.2758051297 ]
  },
  "id_str" : "426926324372885504",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold @jeff_currier @lisaphillips @rgbenson @TwitterSeattle Looks amazing! Can't wait to visit.",
  "id" : 426926324372885504,
  "in_reply_to_status_id" : 426921352100986880,
  "created_at" : "2014-01-25 03:55:42 +0000",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Weil",
      "screen_name" : "kevinweil",
      "indices" : [ 0, 10 ],
      "id_str" : "3452911",
      "id" : 3452911
    }, {
      "name" : "Arne Roomann-Kurrik",
      "screen_name" : "kurrik",
      "indices" : [ 11, 18 ],
      "id_str" : "7588892",
      "id" : 7588892
    }, {
      "name" : "Twitter API",
      "screen_name" : "twitterapi",
      "indices" : [ 52, 63 ],
      "id_str" : "6253282",
      "id" : 6253282
    }, {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 65, 71 ],
      "id_str" : "586",
      "id" : 586
    }, {
      "name" : "John Herrman",
      "screen_name" : "jwherrman",
      "indices" : [ 73, 83 ],
      "id_str" : "27941766",
      "id" : 27941766
    }, {
      "name" : "Vivian",
      "screen_name" : "vivianschiller",
      "indices" : [ 89, 104 ],
      "id_str" : "2362027915",
      "id" : 2362027915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426921456027435010",
  "geo" : { },
  "id_str" : "426922425637294080",
  "in_reply_to_user_id" : 3452911,
  "text" : "@kevinweil @kurrik Well, you were 5th place, behind @twitterapi, @sacca, @jwherrman, and @VivianSchiller, in that order.",
  "id" : 426922425637294080,
  "in_reply_to_status_id" : 426921456027435010,
  "created_at" : "2014-01-25 03:40:12 +0000",
  "in_reply_to_screen_name" : "kevinweil",
  "in_reply_to_user_id_str" : "3452911",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Werner Vogels",
      "screen_name" : "Werner",
      "indices" : [ 3, 10 ],
      "id_str" : "113963",
      "id" : 113963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/aWht5Cu4nK",
      "expanded_url" : "http:\/\/wv.ly\/1hu54Ek",
      "display_url" : "wv.ly\/1hu54Ek"
    } ]
  },
  "geo" : { },
  "id_str" : "426910589118451712",
  "text" : "RT @Werner: Hawking's black hole paper: \"Information Preservation and Weather Forecasting for Black Holes\" http:\/\/t.co\/aWht5Cu4nK (pdf)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/aWht5Cu4nK",
        "expanded_url" : "http:\/\/wv.ly\/1hu54Ek",
        "display_url" : "wv.ly\/1hu54Ek"
      } ]
    },
    "geo" : { },
    "id_str" : "426902058827259904",
    "text" : "Hawking's black hole paper: \"Information Preservation and Weather Forecasting for Black Holes\" http:\/\/t.co\/aWht5Cu4nK (pdf)",
    "id" : 426902058827259904,
    "created_at" : "2014-01-25 02:19:16 +0000",
    "user" : {
      "name" : "Werner Vogels",
      "screen_name" : "Werner",
      "protected" : false,
      "id_str" : "113963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430747926944415745\/vIhN5-Qi_normal.jpeg",
      "id" : 113963,
      "verified" : false
    }
  },
  "id" : 426910589118451712,
  "created_at" : "2014-01-25 02:53:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 0, 3 ],
      "id_str" : "15504330",
      "id" : 15504330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trifecta",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426835420563771392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763161762, -122.4167700321 ]
  },
  "id_str" : "426836381243932673",
  "in_reply_to_user_id" : 15504330,
  "text" : "@wm Fave, retweet, and reply to eventually die a meaningless death, alone and afraid. #trifecta",
  "id" : 426836381243932673,
  "in_reply_to_status_id" : 426835420563771392,
  "created_at" : "2014-01-24 21:58:18 +0000",
  "in_reply_to_screen_name" : "wm",
  "in_reply_to_user_id_str" : "15504330",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 3, 6 ],
      "id_str" : "15504330",
      "id" : 15504330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426835656212357121",
  "text" : "RT @wm: Retweet to eventually die a meaningless death, alone and afraid. Fav to eventually die a meaningless death, alone and afraid.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "426835420563771392",
    "text" : "Retweet to eventually die a meaningless death, alone and afraid. Fav to eventually die a meaningless death, alone and afraid.",
    "id" : 426835420563771392,
    "created_at" : "2014-01-24 21:54:29 +0000",
    "user" : {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "protected" : false,
      "id_str" : "15504330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/414117800425172992\/IRIVqvZP_normal.jpeg",
      "id" : 15504330,
      "verified" : false
    }
  },
  "id" : 426835656212357121,
  "created_at" : "2014-01-24 21:55:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Bausch",
      "screen_name" : "pbausch",
      "indices" : [ 0, 8 ],
      "id_str" : "818992",
      "id" : 818992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426822353280966656",
  "geo" : { },
  "id_str" : "426823870671106048",
  "in_reply_to_user_id" : 818992,
  "text" : "@pbausch Thanks, Paul! I'm having a great time working on this stuff.",
  "id" : 426823870671106048,
  "in_reply_to_status_id" : 426822353280966656,
  "created_at" : "2014-01-24 21:08:35 +0000",
  "in_reply_to_screen_name" : "pbausch",
  "in_reply_to_user_id_str" : "818992",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 18, 27 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 29, 36 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/xrPof20f6I",
      "expanded_url" : "https:\/\/dev.twitter.com\/discussions\/25446",
      "display_url" : "dev.twitter.com\/discussions\/25\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "426797392571023360",
  "geo" : { },
  "id_str" : "426797641846910976",
  "in_reply_to_user_id" : 21678279,
  "text" : "Awesome! More! RT @agaricus: @buster I created a topic for requests for new analytics\/metrics...and added my own! https:\/\/t.co\/xrPof20f6I",
  "id" : 426797641846910976,
  "in_reply_to_status_id" : 426797392571023360,
  "created_at" : "2014-01-24 19:24:21 +0000",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/NCiiw0swJA",
      "expanded_url" : "http:\/\/analytics.twitter.com",
      "display_url" : "analytics.twitter.com"
    }, {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/HXtniCCABm",
      "expanded_url" : "https:\/\/dev.twitter.com\/discussions\/analytics",
      "display_url" : "dev.twitter.com\/discussions\/an\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426793118294241280",
  "text" : "We just opened up discussion forums for all things http:\/\/t.co\/NCiiw0swJA: spread the word and ask away: https:\/\/t.co\/HXtniCCABm",
  "id" : 426793118294241280,
  "created_at" : "2014-01-24 19:06:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andr\u00E9a lopez",
      "screen_name" : "bluechoochoo",
      "indices" : [ 0, 13 ],
      "id_str" : "420117089",
      "id" : 420117089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426791790591492096",
  "geo" : { },
  "id_str" : "426792233438687232",
  "in_reply_to_user_id" : 420117089,
  "text" : "@bluechoochoo You're very welcome!",
  "id" : 426792233438687232,
  "in_reply_to_status_id" : 426791790591492096,
  "created_at" : "2014-01-24 19:02:52 +0000",
  "in_reply_to_screen_name" : "bluechoochoo",
  "in_reply_to_user_id_str" : "420117089",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andr\u00E9a lopez",
      "screen_name" : "bluechoochoo",
      "indices" : [ 0, 13 ],
      "id_str" : "420117089",
      "id" : 420117089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426517985910472704",
  "geo" : { },
  "id_str" : "426791506897145856",
  "in_reply_to_user_id" : 420117089,
  "text" : "@bluechoochoo You'll need to edit the Tumblr template and change this tag: &lt;meta name=\"twitter:site\" content=\"[your twitter username]\" \/&gt;",
  "id" : 426791506897145856,
  "in_reply_to_status_id" : 426517985910472704,
  "created_at" : "2014-01-24 18:59:59 +0000",
  "in_reply_to_screen_name" : "bluechoochoo",
  "in_reply_to_user_id_str" : "420117089",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Roomann-Kurrik",
      "screen_name" : "kurrik",
      "indices" : [ 48, 55 ],
      "id_str" : "7588892",
      "id" : 7588892
    }, {
      "name" : "Kevin Weil",
      "screen_name" : "kevinweil",
      "indices" : [ 124, 134 ],
      "id_str" : "3452911",
      "id" : 3452911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426780531439570944",
  "geo" : { },
  "id_str" : "426781218521112576",
  "in_reply_to_user_id" : 2185,
  "text" : "The winner from our team for driving clicks was @kurrik (6th place) with his Bieber click bait tweet. Only one click behind @kevinweil.",
  "id" : 426781218521112576,
  "in_reply_to_status_id" : 426780531439570944,
  "created_at" : "2014-01-24 18:19:06 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426780531439570944",
  "text" : "We used the new Twitter Card analytics we launched yesterday to see who on the team drove the most clicks to our blog post announcement.",
  "id" : 426780531439570944,
  "created_at" : "2014-01-24 18:16:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426747666056241152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8302161744, -122.2665140902 ]
  },
  "id_str" : "426765400911532032",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april um no not really",
  "id" : 426765400911532032,
  "in_reply_to_status_id" : 426747666056241152,
  "created_at" : "2014-01-24 17:16:15 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vine",
      "screen_name" : "vineapp",
      "indices" : [ 3, 11 ],
      "id_str" : "586671909",
      "id" : 586671909
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VineBirthday",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/VudisSHKqA",
      "expanded_url" : "http:\/\/yearonvine.vine.co",
      "display_url" : "yearonvine.vine.co"
    } ]
  },
  "geo" : { },
  "id_str" : "426742581418938368",
  "text" : "RT @vineapp: Today is our first birthday! To celebrate, we\u2019re looking back at memorable moments from year one http:\/\/t.co\/VudisSHKqA #VineB\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VineBirthday",
        "indices" : [ 120, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/VudisSHKqA",
        "expanded_url" : "http:\/\/yearonvine.vine.co",
        "display_url" : "yearonvine.vine.co"
      } ]
    },
    "geo" : { },
    "id_str" : "426742349549404160",
    "text" : "Today is our first birthday! To celebrate, we\u2019re looking back at memorable moments from year one http:\/\/t.co\/VudisSHKqA #VineBirthday",
    "id" : 426742349549404160,
    "created_at" : "2014-01-24 15:44:39 +0000",
    "user" : {
      "name" : "Vine",
      "screen_name" : "vineapp",
      "protected" : false,
      "id_str" : "586671909",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3578238864\/50d7e05aa6fe5d477e48a63047e38ce7_normal.png",
      "id" : 586671909,
      "verified" : true
    }
  },
  "id" : 426742581418938368,
  "created_at" : "2014-01-24 15:45:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 23, 33 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/426583999746560000\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/HYa4h6PnsO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeuH4zJCEAEsJzU.jpg",
      "id_str" : "426583999587160065",
      "id" : 426583999587160065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeuH4zJCEAEsJzU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HYa4h6PnsO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8506985071, -122.2525461501 ]
  },
  "id_str" : "426583999746560000",
  "text" : "8:36pm Date night with @kellianne on launch day. Good times. http:\/\/t.co\/HYa4h6PnsO",
  "id" : 426583999746560000,
  "created_at" : "2014-01-24 05:15:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 11, 20 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426554461247373312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8074127389, -122.3040441704 ]
  },
  "id_str" : "426554971304099840",
  "in_reply_to_user_id" : 2185,
  "text" : "By the way @buzzfeed sent us that cookie because they were a charter partner during our prototype phase. I &lt;3 Buzzfeed.",
  "id" : 426554971304099840,
  "in_reply_to_status_id" : 426554461247373312,
  "created_at" : "2014-01-24 03:20:04 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/426554461247373312\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/l11cYPxCFU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BettBcBCAAAb5Qx.jpg",
      "id_str" : "426554461184458752",
      "id" : 426554461184458752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BettBcBCAAAb5Qx.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 730
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 730
      } ],
      "display_url" : "pic.twitter.com\/l11cYPxCFU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.792599704, -122.3974878318 ]
  },
  "id_str" : "426554461247373312",
  "text" : "I love my team and am proud of what we shipped today. Okay maybe I've had a couple drinks already. http:\/\/t.co\/l11cYPxCFU",
  "id" : 426554461247373312,
  "created_at" : "2014-01-24 03:18:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426542611411656705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7767104107, -122.4178264039 ]
  },
  "id_str" : "426544519929020417",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Gracias!",
  "id" : 426544519929020417,
  "in_reply_to_status_id" : 426542611411656705,
  "created_at" : "2014-01-24 02:38:33 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426541748190322689",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7767227471, -122.4178244578 ]
  },
  "id_str" : "426542506839257088",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Yup!",
  "id" : 426542506839257088,
  "in_reply_to_status_id" : 426541748190322689,
  "created_at" : "2014-01-24 02:30:33 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judd Legum",
      "screen_name" : "JuddLegum",
      "indices" : [ 0, 10 ],
      "id_str" : "15464697",
      "id" : 15464697
    }, {
      "name" : "ThinkProgress",
      "screen_name" : "thinkprogress",
      "indices" : [ 33, 47 ],
      "id_str" : "55355654",
      "id" : 55355654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426522592833310720",
  "geo" : { },
  "id_str" : "426527546503487488",
  "in_reply_to_user_id" : 15464697,
  "text" : "@juddlegum Yes! If you log in as @thinkprogress and click on your name in the top nav -&gt; Edit account access -&gt; add your personal account.",
  "id" : 426527546503487488,
  "in_reply_to_status_id" : 426522592833310720,
  "created_at" : "2014-01-24 01:31:06 +0000",
  "in_reply_to_screen_name" : "JuddLegum",
  "in_reply_to_user_id_str" : "15464697",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    }, {
      "name" : "Product Hunt",
      "screen_name" : "producthunt",
      "indices" : [ 10, 22 ],
      "id_str" : "2208027565",
      "id" : 2208027565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426511609314295808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769436835, -122.4173887758 ]
  },
  "id_str" : "426515480258441216",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover @producthunt Let me know if I can help with anything!",
  "id" : 426515480258441216,
  "in_reply_to_status_id" : 426511609314295808,
  "created_at" : "2014-01-24 00:43:09 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    }, {
      "name" : "Product Hunt",
      "screen_name" : "producthunt",
      "indices" : [ 46, 58 ],
      "id_str" : "2208027565",
      "id" : 2208027565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426434180625743872",
  "geo" : { },
  "id_str" : "426479411341164544",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover You should totally add cards to the @producthunt pages. :)",
  "id" : 426479411341164544,
  "in_reply_to_status_id" : 426434180625743872,
  "created_at" : "2014-01-23 22:19:49 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Lum",
      "screen_name" : "lum",
      "indices" : [ 0, 4 ],
      "id_str" : "9891382",
      "id" : 9891382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426463206274772994",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7768841037, -122.4173344805 ]
  },
  "id_str" : "426472363362775040",
  "in_reply_to_user_id" : 9891382,
  "text" : "@lum Thank you!",
  "id" : 426472363362775040,
  "in_reply_to_status_id" : 426463206274772994,
  "created_at" : "2014-01-23 21:51:49 +0000",
  "in_reply_to_screen_name" : "lum",
  "in_reply_to_user_id_str" : "9891382",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Beale",
      "screen_name" : "ScottBeale",
      "indices" : [ 0, 11 ],
      "id_str" : "14397792",
      "id" : 14397792
    }, {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 12, 18 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426429231195623424",
  "geo" : { },
  "id_str" : "426447855717322752",
  "in_reply_to_user_id" : 14397792,
  "text" : "@ScottBeale @sacca I'd love to hear feedback too, any time. DM or buster@twitter.com. :)",
  "id" : 426447855717322752,
  "in_reply_to_status_id" : 426429231195623424,
  "created_at" : "2014-01-23 20:14:26 +0000",
  "in_reply_to_screen_name" : "ScottBeale",
  "in_reply_to_user_id_str" : "14397792",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Arne Roomann-Kurrik",
      "screen_name" : "kurrik",
      "indices" : [ 9, 16 ],
      "id_str" : "7588892",
      "id" : 7588892
    }, {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 17, 25 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426441034906599424",
  "geo" : { },
  "id_str" : "426441558028582912",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver @kurrik @chanian Thank you! I gave you a shout-out in the internal announcement for all your help kicking this off.",
  "id" : 426441558028582912,
  "in_reply_to_status_id" : 426441034906599424,
  "created_at" : "2014-01-23 19:49:24 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Sears",
      "screen_name" : "WillSears",
      "indices" : [ 0, 10 ],
      "id_str" : "14499150",
      "id" : 14499150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426426470848688128",
  "geo" : { },
  "id_str" : "426426616013541376",
  "in_reply_to_user_id" : 14499150,
  "text" : "@willsears Yup. I'm the PM.",
  "id" : 426426616013541376,
  "in_reply_to_status_id" : 426426470848688128,
  "created_at" : "2014-01-23 18:50:02 +0000",
  "in_reply_to_screen_name" : "WillSears",
  "in_reply_to_user_id_str" : "14499150",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "myx",
      "screen_name" : "myx",
      "indices" : [ 0, 4 ],
      "id_str" : "2472991076",
      "id" : 2472991076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426424171552202752",
  "geo" : { },
  "id_str" : "426424520086257664",
  "in_reply_to_user_id" : 14648265,
  "text" : "@myx I calculated them myself. They're not automatically calculated anywhere that I currently know.",
  "id" : 426424520086257664,
  "in_reply_to_status_id" : 426424171552202752,
  "created_at" : "2014-01-23 18:41:42 +0000",
  "in_reply_to_screen_name" : "jublonet",
  "in_reply_to_user_id_str" : "14648265",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "coder school dropout",
      "screen_name" : "meat",
      "indices" : [ 3, 8 ],
      "id_str" : "21006515",
      "id" : 21006515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/9DVifl5DEs",
      "expanded_url" : "https:\/\/blog.twitter.com\/2014\/introducing-analytics-for-twitter-cards",
      "display_url" : "blog.twitter.com\/2014\/introduci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426423472743411712",
  "text" : "RT @meat: what our team built in just a few months will SHOCK you https:\/\/t.co\/9DVifl5DEs",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/9DVifl5DEs",
        "expanded_url" : "https:\/\/blog.twitter.com\/2014\/introducing-analytics-for-twitter-cards",
        "display_url" : "blog.twitter.com\/2014\/introduci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "426423149731655681",
    "text" : "what our team built in just a few months will SHOCK you https:\/\/t.co\/9DVifl5DEs",
    "id" : 426423149731655681,
    "created_at" : "2014-01-23 18:36:16 +0000",
    "user" : {
      "name" : "coder school dropout",
      "screen_name" : "meat",
      "protected" : false,
      "id_str" : "21006515",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459041142353723393\/Q53agq8a_normal.jpeg",
      "id" : 21006515,
      "verified" : false
    }
  },
  "id" : 426423472743411712,
  "created_at" : "2014-01-23 18:37:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter API",
      "screen_name" : "twitterapi",
      "indices" : [ 16, 27 ],
      "id_str" : "6253282",
      "id" : 6253282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/LFxhYjPpdS",
      "expanded_url" : "https:\/\/blog.twitter.com\/2014\/introducing-analytics-for-twitter-cards",
      "display_url" : "blog.twitter.com\/2014\/introduci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426419411348492288",
  "text" : "We launched! RT @twitterapi: Introducing analytics for Twitter Cards: https:\/\/t.co\/LFxhYjPpdS",
  "id" : 426419411348492288,
  "created_at" : "2014-01-23 18:21:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 10, 16 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426396682679767040",
  "geo" : { },
  "id_str" : "426397499301969922",
  "in_reply_to_user_id" : 761628,
  "text" : "@rickwebb @joshc Same reason Blockbuster and record companies should've started streaming earlier. And B&amp;N should've offered ebooks earlier.",
  "id" : 426397499301969922,
  "in_reply_to_status_id" : 426396682679767040,
  "created_at" : "2014-01-23 16:54:20 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 10, 16 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426395321812668416",
  "geo" : { },
  "id_str" : "426396209641570304",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @joshc Economically expedient isn\u2019t very objective. In this case it makes sense to sacrifice short term economics for long term.",
  "id" : 426396209641570304,
  "in_reply_to_status_id" : 426395321812668416,
  "created_at" : "2014-01-23 16:49:13 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 10, 16 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426389600207372288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7766152013, -122.4168061729 ]
  },
  "id_str" : "426395043012685824",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @joshc Totally. Me too. They'll have to pry it from my cold dead hands! I only bet against them because I care.",
  "id" : 426395043012685824,
  "in_reply_to_status_id" : 426389600207372288,
  "created_at" : "2014-01-23 16:44:34 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Queen Snow.",
      "screen_name" : "itsjessica_tho",
      "indices" : [ 3, 18 ],
      "id_str" : "598763975",
      "id" : 598763975
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/itsjessica_tho\/status\/426363358489505792\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/y18i47Ajnj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Beq_NypCIAAEEkP.jpg",
      "id_str" : "426363358393016320",
      "id" : 426363358393016320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Beq_NypCIAAEEkP.jpg",
      "sizes" : [ {
        "h" : 628,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/y18i47Ajnj"
    } ],
    "hashtags" : [ {
      "text" : "FreeBieber",
      "indices" : [ 51, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426389486969184257",
  "text" : "RT @itsjessica_tho: My babe in Jail .... NOOOOO \uD83D\uDE22\uD83D\uDE14 #FreeBieber http:\/\/t.co\/y18i47Ajnj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/itsjessica_tho\/status\/426363358489505792\/photo\/1",
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/y18i47Ajnj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Beq_NypCIAAEEkP.jpg",
        "id_str" : "426363358393016320",
        "id" : 426363358393016320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Beq_NypCIAAEEkP.jpg",
        "sizes" : [ {
          "h" : 628,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 589,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/y18i47Ajnj"
      } ],
      "hashtags" : [ {
        "text" : "FreeBieber",
        "indices" : [ 31, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "426363358489505792",
    "text" : "My babe in Jail .... NOOOOO \uD83D\uDE22\uD83D\uDE14 #FreeBieber http:\/\/t.co\/y18i47Ajnj",
    "id" : 426363358489505792,
    "created_at" : "2014-01-23 14:38:40 +0000",
    "user" : {
      "name" : "Queen Snow.",
      "screen_name" : "itsjessica_tho",
      "protected" : false,
      "id_str" : "598763975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/457636931397238784\/NhfL4X_3_normal.jpeg",
      "id" : 598763975,
      "verified" : false
    }
  },
  "id" : 426389486969184257,
  "created_at" : "2014-01-23 16:22:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 10, 16 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426368779535523840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596278186, -122.2755804839 ]
  },
  "id_str" : "426369601283174401",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @joshc I can't find reliable data on HBO rev. Quality is too fuzzy. This is ultimately a fight for subscribers and total TV time.",
  "id" : 426369601283174401,
  "in_reply_to_status_id" : 426368779535523840,
  "created_at" : "2014-01-23 15:03:29 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 120, 126 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426358777239982080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596781805, -122.275514952 ]
  },
  "id_str" : "426368413871509504",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb OK! How about a bet on Netflix vs HBO net global subscriber % change in 2014. Or who has more in 5 years? \/cc @joshc",
  "id" : 426368413871509504,
  "in_reply_to_status_id" : 426358777239982080,
  "created_at" : "2014-01-23 14:58:46 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MediaREDEF",
      "screen_name" : "MediaREDEF",
      "indices" : [ 3, 14 ],
      "id_str" : "24438551",
      "id" : 24438551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/6oa5XKDyGg",
      "expanded_url" : "http:\/\/bit.ly\/1eECijP",
      "display_url" : "bit.ly\/1eECijP"
    } ]
  },
  "geo" : { },
  "id_str" : "426366019183988736",
  "text" : "RT @MediaREDEF: Richard Sherman: \u201CThug\u201D is simply the \u201Caccepted way of calling somebody the N-word\u201D http:\/\/t.co\/6oa5XKDyGg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/6oa5XKDyGg",
        "expanded_url" : "http:\/\/bit.ly\/1eECijP",
        "display_url" : "bit.ly\/1eECijP"
      } ]
    },
    "geo" : { },
    "id_str" : "426363748430118912",
    "text" : "Richard Sherman: \u201CThug\u201D is simply the \u201Caccepted way of calling somebody the N-word\u201D http:\/\/t.co\/6oa5XKDyGg",
    "id" : 426363748430118912,
    "created_at" : "2014-01-23 14:40:13 +0000",
    "user" : {
      "name" : "MediaREDEF",
      "screen_name" : "MediaREDEF",
      "protected" : false,
      "id_str" : "24438551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000017516730\/1709a44517019eb6acf53ec99516f126_normal.png",
      "id" : 24438551,
      "verified" : false
    }
  },
  "id" : 426366019183988736,
  "created_at" : "2014-01-23 14:49:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 10, 18 ],
      "id_str" : "5699",
      "id" : 5699
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 19, 29 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426260700739403776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596479853, -122.2755970684 ]
  },
  "id_str" : "426263741240311808",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @stewart @tomcoates Move here and help!",
  "id" : 426263741240311808,
  "in_reply_to_status_id" : 426260700739403776,
  "created_at" : "2014-01-23 08:02:50 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 10, 18 ],
      "id_str" : "5699",
      "id" : 5699
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 19, 29 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426259316664827904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597376931, -122.2755337459 ]
  },
  "id_str" : "426260222521249792",
  "in_reply_to_user_id" : 2185,
  "text" : "@anildash @stewart @tomcoates Not sure why you picked on the west coast when you know more about the east coast. But, intentions were good.",
  "id" : 426260222521249792,
  "in_reply_to_status_id" : 426259316664827904,
  "created_at" : "2014-01-23 07:48:51 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 10, 18 ],
      "id_str" : "5699",
      "id" : 5699
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 19, 29 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426253032712830976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596684989, -122.275474202 ]
  },
  "id_str" : "426259316664827904",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @stewart @tomcoates Was this productive? I appreciate the provocative push, it always feels uncomfortable.",
  "id" : 426259316664827904,
  "in_reply_to_status_id" : 426253032712830976,
  "created_at" : "2014-01-23 07:45:15 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/426227377362845696\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/tBvBONaC12",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BepDipQCYAAi1tT.jpg",
      "id_str" : "426227377207664640",
      "id" : 426227377207664640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BepDipQCYAAi1tT.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tBvBONaC12"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596311575, -122.2756152694 ]
  },
  "id_str" : "426227377362845696",
  "text" : "8:36pm Thinking about friends who I care about and know are sad today http:\/\/t.co\/tBvBONaC12",
  "id" : 426227377362845696,
  "created_at" : "2014-01-23 05:38:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Pepper",
      "screen_name" : "noahmp",
      "indices" : [ 0, 7 ],
      "id_str" : "20219699",
      "id" : 20219699
    }, {
      "name" : "Taggart Matthiesen",
      "screen_name" : "taggart",
      "indices" : [ 8, 16 ],
      "id_str" : "34045232",
      "id" : 34045232
    }, {
      "name" : "Erez Lieberman Aiden",
      "screen_name" : "erezaterez",
      "indices" : [ 17, 28 ],
      "id_str" : "226041293",
      "id" : 226041293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426225043584974848",
  "geo" : { },
  "id_str" : "426225577486348289",
  "in_reply_to_user_id" : 20219699,
  "text" : "@noahmp @taggart @erezaterez It destroys signal and noise. I guess it makes sense, though.",
  "id" : 426225577486348289,
  "in_reply_to_status_id" : 426225043584974848,
  "created_at" : "2014-01-23 05:31:11 +0000",
  "in_reply_to_screen_name" : "noahmp",
  "in_reply_to_user_id_str" : "20219699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taggart Matthiesen",
      "screen_name" : "taggart",
      "indices" : [ 0, 8 ],
      "id_str" : "34045232",
      "id" : 34045232
    }, {
      "name" : "Erez Lieberman Aiden",
      "screen_name" : "erezaterez",
      "indices" : [ 50, 61 ],
      "id_str" : "226041293",
      "id" : 226041293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426223873248354304",
  "geo" : { },
  "id_str" : "426224480587767809",
  "in_reply_to_user_id" : 34045232,
  "text" : "@taggart You were at the talk today, right? Also, @erezaterez, why did you choose to preserve capitalization in n-grams?",
  "id" : 426224480587767809,
  "in_reply_to_status_id" : 426223873248354304,
  "created_at" : "2014-01-23 05:26:49 +0000",
  "in_reply_to_screen_name" : "taggart",
  "in_reply_to_user_id_str" : "34045232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 3, 18 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/1fgVM9OOaZ",
      "expanded_url" : "http:\/\/www.geekwire.com\/2014\/twitter-seattle-office\/",
      "display_url" : "geekwire.com\/2014\/twitter-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426220698663542785",
  "text" : "RT @mikeindustries: A look inside Twitter's new Seattle office: http:\/\/t.co\/1fgVM9OOaZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/1fgVM9OOaZ",
        "expanded_url" : "http:\/\/www.geekwire.com\/2014\/twitter-seattle-office\/",
        "display_url" : "geekwire.com\/2014\/twitter-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "426219392645345281",
    "text" : "A look inside Twitter's new Seattle office: http:\/\/t.co\/1fgVM9OOaZ",
    "id" : 426219392645345281,
    "created_at" : "2014-01-23 05:06:36 +0000",
    "user" : {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "protected" : false,
      "id_str" : "74523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430955581830995968\/sSqK3_b9_normal.jpeg",
      "id" : 74523,
      "verified" : false
    }
  },
  "id" : 426220698663542785,
  "created_at" : "2014-01-23 05:11:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taggart Matthiesen",
      "screen_name" : "taggart",
      "indices" : [ 0, 8 ],
      "id_str" : "34045232",
      "id" : 34045232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426218450818568193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596360887, -122.27549827 ]
  },
  "id_str" : "426220493868249088",
  "in_reply_to_user_id" : 34045232,
  "text" : "@taggart Which searches?",
  "id" : 426220493868249088,
  "in_reply_to_status_id" : 426218450818568193,
  "created_at" : "2014-01-23 05:10:59 +0000",
  "in_reply_to_screen_name" : "taggart",
  "in_reply_to_user_id_str" : "34045232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah, agirlandaboy",
      "screen_name" : "agirlandaboy",
      "indices" : [ 0, 13 ],
      "id_str" : "80895925",
      "id" : 80895925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426218102359998464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859716245, -122.2755289565 ]
  },
  "id_str" : "426219247027503104",
  "in_reply_to_user_id" : 80895925,
  "text" : "@agirlandaboy What's that?",
  "id" : 426219247027503104,
  "in_reply_to_status_id" : 426218102359998464,
  "created_at" : "2014-01-23 05:06:01 +0000",
  "in_reply_to_screen_name" : "agirlandaboy",
  "in_reply_to_user_id_str" : "80895925",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596693763, -122.2755787999 ]
  },
  "id_str" : "426210767860285443",
  "text" : "What are the just-right-hyped startups right now?",
  "id" : 426210767860285443,
  "created_at" : "2014-01-23 04:32:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    }, {
      "name" : "Lisa Phillips",
      "screen_name" : "lisaphillips",
      "indices" : [ 14, 27 ],
      "id_str" : "733383",
      "id" : 733383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426148098369269760",
  "geo" : { },
  "id_str" : "426148728727015424",
  "in_reply_to_user_id" : 14095370,
  "text" : "@offbeatariel @lisaphillips It *does* look pretty cozy\u2026 but is the coffee any good?",
  "id" : 426148728727015424,
  "in_reply_to_status_id" : 426148098369269760,
  "created_at" : "2014-01-23 00:25:49 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Bruchez",
      "screen_name" : "ebruchez",
      "indices" : [ 0, 9 ],
      "id_str" : "6087842",
      "id" : 6087842
    }, {
      "name" : "Derek Sivers",
      "screen_name" : "sivers",
      "indices" : [ 10, 17 ],
      "id_str" : "2206131",
      "id" : 2206131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426139029348704256",
  "geo" : { },
  "id_str" : "426139291698204672",
  "in_reply_to_user_id" : 6087842,
  "text" : "@ebruchez @sivers Test it and find your answer. Studies often find averages when circumstances lead to wild variability.",
  "id" : 426139291698204672,
  "in_reply_to_status_id" : 426139029348704256,
  "created_at" : "2014-01-22 23:48:19 +0000",
  "in_reply_to_screen_name" : "ebruchez",
  "in_reply_to_user_id_str" : "6087842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Bruchez",
      "screen_name" : "ebruchez",
      "indices" : [ 0, 9 ],
      "id_str" : "6087842",
      "id" : 6087842
    }, {
      "name" : "Derek Sivers",
      "screen_name" : "sivers",
      "indices" : [ 10, 17 ],
      "id_str" : "2206131",
      "id" : 2206131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426135141446991872",
  "geo" : { },
  "id_str" : "426135262934994944",
  "in_reply_to_user_id" : 2185,
  "text" : "@ebruchez @sivers \u2026 and coming back next month to see if it worked or not. If talking works, keep doing it. If not, try something else.",
  "id" : 426135262934994944,
  "in_reply_to_status_id" : 426135141446991872,
  "created_at" : "2014-01-22 23:32:18 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Bruchez",
      "screen_name" : "ebruchez",
      "indices" : [ 0, 9 ],
      "id_str" : "6087842",
      "id" : 6087842
    }, {
      "name" : "Derek Sivers",
      "screen_name" : "sivers",
      "indices" : [ 10, 17 ],
      "id_str" : "2206131",
      "id" : 2206131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426134086105579520",
  "geo" : { },
  "id_str" : "426135141446991872",
  "in_reply_to_user_id" : 6087842,
  "text" : "@ebruchez @sivers I like that article but I think everyone's different. Rabbit rabbit has no dogma, it's about trying something...",
  "id" : 426135141446991872,
  "in_reply_to_status_id" : 426134086105579520,
  "created_at" : "2014-01-22 23:31:49 +0000",
  "in_reply_to_screen_name" : "ebruchez",
  "in_reply_to_user_id_str" : "6087842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426100129444020224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769312342, -122.4172537572 ]
  },
  "id_str" : "426112917361016832",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach How about just telling us which ones are yours?",
  "id" : 426112917361016832,
  "in_reply_to_status_id" : 426100129444020224,
  "created_at" : "2014-01-22 22:03:30 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Watkins",
      "screen_name" : "olivia",
      "indices" : [ 0, 7 ],
      "id_str" : "25216995",
      "id" : 25216995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426048000972972033",
  "geo" : { },
  "id_str" : "426048864940879872",
  "in_reply_to_user_id" : 25216995,
  "text" : "@olivia The post-adolescent condition! Now that I know my diagnosis I already feel much better.",
  "id" : 426048864940879872,
  "in_reply_to_status_id" : 426048000972972033,
  "created_at" : "2014-01-22 17:48:59 +0000",
  "in_reply_to_screen_name" : "olivia",
  "in_reply_to_user_id_str" : "25216995",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Seibel",
      "screen_name" : "peterseibel",
      "indices" : [ 27, 39 ],
      "id_str" : "40684667",
      "id" : 40684667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/887l1BF4ZW",
      "expanded_url" : "http:\/\/pocket.co\/syRYA",
      "display_url" : "pocket.co\/syRYA"
    } ]
  },
  "geo" : { },
  "id_str" : "426038030756216832",
  "text" : "I love this post about how @peterseibel's Royal Society of Twitter for Improving Coding Knowledge came to be http:\/\/t.co\/887l1BF4ZW",
  "id" : 426038030756216832,
  "created_at" : "2014-01-22 17:05:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596800513, -122.2755059714 ]
  },
  "id_str" : "425904562319282176",
  "text" : "A way to buy a Segway with bitcoin by looking at a QR code with your Google Glass.",
  "id" : 425904562319282176,
  "created_at" : "2014-01-22 08:15:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    }, {
      "name" : "Reyner Crosby",
      "screen_name" : "reyner",
      "indices" : [ 4, 11 ],
      "id_str" : "18236000",
      "id" : 18236000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425877418063052800",
  "geo" : { },
  "id_str" : "425883780620886016",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm @reyner Time to do like the Japanese do and start a kisei-aka (\u898F\u5236\u57A2).",
  "id" : 425883780620886016,
  "in_reply_to_status_id" : 425877418063052800,
  "created_at" : "2014-01-22 06:53:00 +0000",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/425860658400202753\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/BP2VGAiZZp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bej2AyeCUAE9Q54.jpg",
      "id_str" : "425860658194698241",
      "id" : 425860658194698241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bej2AyeCUAE9Q54.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/BP2VGAiZZp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597201733, -122.2754920555 ]
  },
  "id_str" : "425860658400202753",
  "text" : "8:36pm Niko and the techicolor pajama combos http:\/\/t.co\/BP2VGAiZZp",
  "id" : 425860658400202753,
  "created_at" : "2014-01-22 05:21:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "indices" : [ 7, 12 ],
      "id_str" : "10221",
      "id" : 10221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/XrwyMhxgz4",
      "expanded_url" : "http:\/\/techcrunch.com\/2014\/01\/21\/nesting-twitter\/?ncid=twittersocialshare",
      "display_url" : "techcrunch.com\/2014\/01\/21\/nes\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "425819330085785600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8007886885, -122.2824497895 ]
  },
  "id_str" : "425821267858452481",
  "in_reply_to_user_id" : 10221,
  "text" : "Ha! RT @drew: See Twitter\u2019s Founders As Nesting Dolls By The Creator Of Fail Whale http:\/\/t.co\/XrwyMhxgz4",
  "id" : 425821267858452481,
  "in_reply_to_status_id" : 425819330085785600,
  "created_at" : "2014-01-22 02:44:36 +0000",
  "in_reply_to_screen_name" : "drew",
  "in_reply_to_user_id_str" : "10221",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ramesh Haridas",
      "screen_name" : "rameshharidas",
      "indices" : [ 0, 14 ],
      "id_str" : "11039752",
      "id" : 11039752
    }, {
      "name" : "BookVibe",
      "screen_name" : "BookVibe",
      "indices" : [ 15, 24 ],
      "id_str" : "1300072272",
      "id" : 1300072272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425719320799244288",
  "geo" : { },
  "id_str" : "425719531814674432",
  "in_reply_to_user_id" : 11039752,
  "text" : "@rameshharidas @bookvibe Awesome stuff! I'll dig in and learn more.",
  "id" : 425719531814674432,
  "in_reply_to_status_id" : 425719320799244288,
  "created_at" : "2014-01-21 20:00:20 +0000",
  "in_reply_to_screen_name" : "rameshharidas",
  "in_reply_to_user_id_str" : "11039752",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ramesh Haridas",
      "screen_name" : "rameshharidas",
      "indices" : [ 0, 14 ],
      "id_str" : "11039752",
      "id" : 11039752
    }, {
      "name" : "BookVibe",
      "screen_name" : "BookVibe",
      "indices" : [ 15, 24 ],
      "id_str" : "1300072272",
      "id" : 1300072272
    }, {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 25, 39 ],
      "id_str" : "820661",
      "id" : 820661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425717291972431872",
  "geo" : { },
  "id_str" : "425717655341776896",
  "in_reply_to_user_id" : 11039752,
  "text" : "@rameshharidas @bookvibe @daveschappell That's pretty awesome. You built this? Nice book-title parsing!",
  "id" : 425717655341776896,
  "in_reply_to_status_id" : 425717291972431872,
  "created_at" : "2014-01-21 19:52:53 +0000",
  "in_reply_to_screen_name" : "rameshharidas",
  "in_reply_to_user_id_str" : "11039752",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/VgKDbd8f2W",
      "expanded_url" : "http:\/\/flic.kr\/p\/jo1WmT",
      "display_url" : "flic.kr\/p\/jo1WmT"
    } ]
  },
  "geo" : { },
  "id_str" : "425491458658164736",
  "text" : "8:36pm Niko's favorite part of the day was playing with Aly, her book \"Pinkalicious\" probably had something to do... http:\/\/t.co\/VgKDbd8f2W",
  "id" : 425491458658164736,
  "created_at" : "2014-01-21 04:54:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Seibel",
      "screen_name" : "peterseibel",
      "indices" : [ 3, 15 ],
      "id_str" : "40684667",
      "id" : 40684667
    }, {
      "name" : "Andreas E-Fuchs",
      "screen_name" : "antifuchs",
      "indices" : [ 84, 94 ],
      "id_str" : "5695112",
      "id" : 5695112
    }, {
      "name" : "Danielle Sucher",
      "screen_name" : "DanielleSucher",
      "indices" : [ 95, 110 ],
      "id_str" : "19393655",
      "id" : 19393655
    }, {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 111, 125 ],
      "id_str" : "226976689",
      "id" : 226976689
    }, {
      "name" : "Kelsey Gilmore-Innis",
      "screen_name" : "kelseyinnis",
      "indices" : [ 126, 138 ],
      "id_str" : "435236587",
      "id" : 435236587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/dkWhVsnvVX",
      "expanded_url" : "http:\/\/www.gigamonkeys.com\/code-reading\/",
      "display_url" : "gigamonkeys.com\/code-reading\/"
    } ]
  },
  "geo" : { },
  "id_str" : "425383995111505920",
  "text" : "RT @peterseibel: My experience with code reading groups: http:\/\/t.co\/dkWhVsnvVX \/cc @antifuchs @DanielleSucher @marcprecipice @kelseyinnis",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andreas E-Fuchs",
        "screen_name" : "antifuchs",
        "indices" : [ 67, 77 ],
        "id_str" : "5695112",
        "id" : 5695112
      }, {
        "name" : "Danielle Sucher",
        "screen_name" : "DanielleSucher",
        "indices" : [ 78, 93 ],
        "id_str" : "19393655",
        "id" : 19393655
      }, {
        "name" : "Marc Hedlund",
        "screen_name" : "marcprecipice",
        "indices" : [ 94, 108 ],
        "id_str" : "226976689",
        "id" : 226976689
      }, {
        "name" : "Kelsey Gilmore-Innis",
        "screen_name" : "kelseyinnis",
        "indices" : [ 109, 121 ],
        "id_str" : "435236587",
        "id" : 435236587
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/dkWhVsnvVX",
        "expanded_url" : "http:\/\/www.gigamonkeys.com\/code-reading\/",
        "display_url" : "gigamonkeys.com\/code-reading\/"
      } ]
    },
    "in_reply_to_status_id_str" : "416830613702705152",
    "geo" : { },
    "id_str" : "425358577193078784",
    "in_reply_to_user_id" : 5695112,
    "text" : "My experience with code reading groups: http:\/\/t.co\/dkWhVsnvVX \/cc @antifuchs @DanielleSucher @marcprecipice @kelseyinnis",
    "id" : 425358577193078784,
    "in_reply_to_status_id" : 416830613702705152,
    "created_at" : "2014-01-20 20:06:02 +0000",
    "in_reply_to_screen_name" : "antifuchs",
    "in_reply_to_user_id_str" : "5695112",
    "user" : {
      "name" : "Peter Seibel",
      "screen_name" : "peterseibel",
      "protected" : false,
      "id_str" : "40684667",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1779551456\/peterseibel.original-1326849488_normal.jpg",
      "id" : 40684667,
      "verified" : false
    }
  },
  "id" : 425383995111505920,
  "created_at" : "2014-01-20 21:47:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Capo",
      "screen_name" : "TomCapo57",
      "indices" : [ 0, 10 ],
      "id_str" : "1455678638",
      "id" : 1455678638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425312486376501248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597127648, -122.2755564572 ]
  },
  "id_str" : "425313531760615424",
  "in_reply_to_user_id" : 1455678638,
  "text" : "@TomCapo57 It's better than HBO Go, and people are moving to online streaming services. Net effect: Netflix is growing, HBO is shrinking.",
  "id" : 425313531760615424,
  "in_reply_to_status_id" : 425312486376501248,
  "created_at" : "2014-01-20 17:07:02 +0000",
  "in_reply_to_screen_name" : "TomCapo57",
  "in_reply_to_user_id_str" : "1455678638",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fambai",
      "screen_name" : "fambai",
      "indices" : [ 0, 7 ],
      "id_str" : "12476332",
      "id" : 12476332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425308053505073154",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595685779, -122.275433151 ]
  },
  "id_str" : "425310616174080001",
  "in_reply_to_user_id" : 12476332,
  "text" : "@fambai Go Boss Jess!",
  "id" : 425310616174080001,
  "in_reply_to_status_id" : 425308053505073154,
  "created_at" : "2014-01-20 16:55:27 +0000",
  "in_reply_to_screen_name" : "fambai",
  "in_reply_to_user_id_str" : "12476332",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/ZXPC2ZLcpa",
      "expanded_url" : "http:\/\/gigaom.com\/2014\/01\/20\/game-of-what-tv-viewers-ditch-hbo-as-they-flock-to-netflix\/",
      "display_url" : "gigaom.com\/2014\/01\/20\/gam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425310389241253888",
  "text" : "Netflix, Hulu, and Amazon Instant are gonna eat HBO's lunch. HBO has time to change, but will they? http:\/\/t.co\/ZXPC2ZLcpa",
  "id" : 425310389241253888,
  "created_at" : "2014-01-20 16:54:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fambai",
      "screen_name" : "fambai",
      "indices" : [ 0, 7 ],
      "id_str" : "12476332",
      "id" : 12476332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425253586860511233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596949398, -122.2754171118 ]
  },
  "id_str" : "425305461663883264",
  "in_reply_to_user_id" : 12476332,
  "text" : "@fambai Congrats! What's your new position? How will your work change?",
  "id" : 425305461663883264,
  "in_reply_to_status_id" : 425253586860511233,
  "created_at" : "2014-01-20 16:34:58 +0000",
  "in_reply_to_screen_name" : "fambai",
  "in_reply_to_user_id_str" : "12476332",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/wOdXpxBnx7",
      "expanded_url" : "http:\/\/flic.kr\/p\/jmq3GL",
      "display_url" : "flic.kr\/p\/jmq3GL"
    } ]
  },
  "geo" : { },
  "id_str" : "425143438099890176",
  "text" : "8:36pm Was on a dude date to watch a princess movie (Frozen). Niko's favorite part was the after movie short. http:\/\/t.co\/wOdXpxBnx7",
  "id" : 425143438099890176,
  "created_at" : "2014-01-20 05:51:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoHawks",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425098778312323072",
  "text" : "#GoHawks!",
  "id" : 425098778312323072,
  "created_at" : "2014-01-20 02:53:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 0, 11 ],
      "id_str" : "1586501",
      "id" : 1586501
    }, {
      "name" : "susan wu",
      "screen_name" : "sw",
      "indices" : [ 12, 15 ],
      "id_str" : "893211",
      "id" : 893211
    }, {
      "name" : "Brad Stone",
      "screen_name" : "BradStone",
      "indices" : [ 16, 26 ],
      "id_str" : "15827269",
      "id" : 15827269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425062457468407809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595739091, -122.2755805279 ]
  },
  "id_str" : "425062974487683073",
  "in_reply_to_user_id" : 1586501,
  "text" : "@nickbilton @sw @BradStone I've read both and liked them! I was just saying I wished the podcast went into more comparison between cos.",
  "id" : 425062974487683073,
  "in_reply_to_status_id" : 425062457468407809,
  "created_at" : "2014-01-20 00:31:25 +0000",
  "in_reply_to_screen_name" : "nickbilton",
  "in_reply_to_user_id_str" : "1586501",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "susan wu",
      "screen_name" : "sw",
      "indices" : [ 0, 3 ],
      "id_str" : "893211",
      "id" : 893211
    }, {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 74, 85 ],
      "id_str" : "1586501",
      "id" : 1586501
    }, {
      "name" : "Brad Stone",
      "screen_name" : "BradStone",
      "indices" : [ 90, 100 ],
      "id_str" : "15827269",
      "id" : 15827269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425052580914282496",
  "geo" : { },
  "id_str" : "425054882433728512",
  "in_reply_to_user_id" : 893211,
  "text" : "@sw I'm too much of an insider and couldn't write objectively. Was hoping @nickbilton and @bradstone would dive in more.",
  "id" : 425054882433728512,
  "in_reply_to_status_id" : 425052580914282496,
  "created_at" : "2014-01-19 23:59:15 +0000",
  "in_reply_to_screen_name" : "sw",
  "in_reply_to_user_id_str" : "893211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Waldman",
      "screen_name" : "arielwaldman",
      "indices" : [ 3, 16 ],
      "id_str" : "814304",
      "id" : 814304
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/arielwaldman\/status\/425047396838420480\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/p9JQ2HCzh9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeYSWv3CMAAB6Dn.jpg",
      "id_str" : "425047396846809088",
      "id" : 425047396846809088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeYSWv3CMAAB6Dn.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1012,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1518,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 573,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1518,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/p9JQ2HCzh9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425048057873317888",
  "text" : "RT @arielwaldman: Cute. Driving distance records on the Moon and Mars! The record to beat is 37km! (as of May 2013) http:\/\/t.co\/p9JQ2HCzh9",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/arielwaldman\/status\/425047396838420480\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/p9JQ2HCzh9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BeYSWv3CMAAB6Dn.jpg",
        "id_str" : "425047396846809088",
        "id" : 425047396846809088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeYSWv3CMAAB6Dn.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1012,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1518,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 573,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1518,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/p9JQ2HCzh9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "425047396838420480",
    "text" : "Cute. Driving distance records on the Moon and Mars! The record to beat is 37km! (as of May 2013) http:\/\/t.co\/p9JQ2HCzh9",
    "id" : 425047396838420480,
    "created_at" : "2014-01-19 23:29:31 +0000",
    "user" : {
      "name" : "Ariel Waldman",
      "screen_name" : "arielwaldman",
      "protected" : false,
      "id_str" : "814304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2530407461\/xujyyx9bdf3wi65o5a60_normal.jpeg",
      "id" : 814304,
      "verified" : false
    }
  },
  "id" : 425048057873317888,
  "created_at" : "2014-01-19 23:32:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425039705546031104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596129679, -122.2755829975 ]
  },
  "id_str" : "425047199194427392",
  "in_reply_to_user_id" : 2185,
  "text" : "It was okay. Not enough about Twitter and Amazon. Having worked at both places I think there's a lot more that can be compared between them.",
  "id" : 425047199194427392,
  "in_reply_to_status_id" : 425039705546031104,
  "created_at" : "2014-01-19 23:28:43 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 20, 28 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 49, 60 ],
      "id_str" : "1586501",
      "id" : 1586501
    }, {
      "name" : "Brad Stone",
      "screen_name" : "BradStone",
      "indices" : [ 65, 75 ],
      "id_str" : "15827269",
      "id" : 15827269
    }, {
      "name" : "jason",
      "screen_name" : "Jason",
      "indices" : [ 79, 85 ],
      "id_str" : "3840",
      "id" : 3840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/33LdrAdBR4",
      "expanded_url" : "http:\/\/www.swell.am\/s\/zq-IH4vU8_1wygO1tnyadg",
      "display_url" : "swell.am\/s\/zq-IH4vU8_1w\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "424983869956177920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8594182564, -122.2755398466 ]
  },
  "id_str" : "425039705546031104",
  "in_reply_to_user_id" : 795649,
  "text" : "Listening now... RT @rsarver: Great interview of @nickbilton and @BradStone by @Jason. Twitter, Amazon and more. http:\/\/t.co\/33LdrAdBR4",
  "id" : 425039705546031104,
  "in_reply_to_status_id" : 424983869956177920,
  "created_at" : "2014-01-19 22:58:57 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason W",
      "screen_name" : "J2XL",
      "indices" : [ 0, 5 ],
      "id_str" : "1593141",
      "id" : 1593141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424972963096453120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598386249, -122.2755985712 ]
  },
  "id_str" : "424974745491107842",
  "in_reply_to_user_id" : 1593141,
  "text" : "@J2XL Yes!!!!!!!!!",
  "id" : 424974745491107842,
  "in_reply_to_status_id" : 424972963096453120,
  "created_at" : "2014-01-19 18:40:49 +0000",
  "in_reply_to_screen_name" : "J2XL",
  "in_reply_to_user_id_str" : "1593141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 0, 9 ],
      "id_str" : "2391",
      "id" : 2391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424970517892698112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8594843202, -122.2755322838 ]
  },
  "id_str" : "424971529873403904",
  "in_reply_to_user_id" : 2185,
  "text" : "@mulegirl You're right to question people who co-opt QS and sell it as an app\/service. They aren't trying to learn they're trying to sell.",
  "id" : 424971529873403904,
  "in_reply_to_status_id" : 424970517892698112,
  "created_at" : "2014-01-19 18:28:02 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 0, 9 ],
      "id_str" : "2391",
      "id" : 2391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424969833298399232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597088997, -122.2755434365 ]
  },
  "id_str" : "424970517892698112",
  "in_reply_to_user_id" : 2391,
  "text" : "@mulegirl Right. Good QS and good user research are about learning, creating hypotheses, (in-)validating, repeat. Not changing people.",
  "id" : 424970517892698112,
  "in_reply_to_status_id" : 424969833298399232,
  "created_at" : "2014-01-19 18:24:01 +0000",
  "in_reply_to_screen_name" : "mulegirl",
  "in_reply_to_user_id_str" : "2391",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 0, 9 ],
      "id_str" : "2391",
      "id" : 2391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424968671862071296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596029092, -122.2755055036 ]
  },
  "id_str" : "424969642587598848",
  "in_reply_to_user_id" : 2391,
  "text" : "@mulegirl Yes. I see parallels to user research. Bad QS is the same as bad user research. Asking wrong questions, reaching wrong \"answers\".",
  "id" : 424969642587598848,
  "in_reply_to_status_id" : 424968671862071296,
  "created_at" : "2014-01-19 18:20:33 +0000",
  "in_reply_to_screen_name" : "mulegirl",
  "in_reply_to_user_id_str" : "2391",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 0, 9 ],
      "id_str" : "2391",
      "id" : 2391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424967895324454912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597112466, -122.2754277663 ]
  },
  "id_str" : "424968797968023552",
  "in_reply_to_user_id" : 2391,
  "text" : "@mulegirl I'm highly skeptical of the same stuff... just trying to say that the quantified self movement isn't about changing yourself.",
  "id" : 424968797968023552,
  "in_reply_to_status_id" : 424967895324454912,
  "created_at" : "2014-01-19 18:17:11 +0000",
  "in_reply_to_screen_name" : "mulegirl",
  "in_reply_to_user_id_str" : "2391",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 0, 9 ],
      "id_str" : "2391",
      "id" : 2391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424963318629937152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596556119, -122.2756082313 ]
  },
  "id_str" : "424967434685014016",
  "in_reply_to_user_id" : 2391,
  "text" : "@mulegirl You're mixing up the actual quantified self movement with how reporters talk about it. Because humans is most real focus.",
  "id" : 424967434685014016,
  "in_reply_to_status_id" : 424963318629937152,
  "created_at" : "2014-01-19 18:11:46 +0000",
  "in_reply_to_screen_name" : "mulegirl",
  "in_reply_to_user_id_str" : "2391",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424958276561022976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596348977, -122.2755040494 ]
  },
  "id_str" : "424966420384845824",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap No.",
  "id" : 424966420384845824,
  "in_reply_to_status_id" : 424958276561022976,
  "created_at" : "2014-01-19 18:07:44 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424792398187614210",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596957647, -122.2754982398 ]
  },
  "id_str" : "424797487090503681",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach Sent with only one eye open, about to pass out.",
  "id" : 424797487090503681,
  "in_reply_to_status_id" : 424792398187614210,
  "created_at" : "2014-01-19 06:56:27 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424794018640166912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596234462, -122.2755495553 ]
  },
  "id_str" : "424794163725352960",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm no way",
  "id" : 424794163725352960,
  "in_reply_to_status_id" : 424794018640166912,
  "created_at" : "2014-01-19 06:43:15 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424770113728815104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8594428691, -122.2754821887 ]
  },
  "id_str" : "424793838255734784",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Not sure but I like where you're going with this.",
  "id" : 424793838255734784,
  "in_reply_to_status_id" : 424770113728815104,
  "created_at" : "2014-01-19 06:41:57 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giraffes",
      "indices" : [ 17, 26 ]
    }, {
      "text" : "diving",
      "indices" : [ 27, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/3ThEWXkeom",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=CFeCJx2WKa4&sns=tw",
      "display_url" : "youtube.com\/watch?v=CFeCJx\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596881964, -122.2755342164 ]
  },
  "id_str" : "424791353428410368",
  "text" : "Just watch this. #giraffes #diving http:\/\/t.co\/3ThEWXkeom",
  "id" : 424791353428410368,
  "created_at" : "2014-01-19 06:32:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/ArvJsAHqa0",
      "expanded_url" : "http:\/\/flic.kr\/p\/jjvFLr",
      "display_url" : "flic.kr\/p\/jjvFLr"
    } ]
  },
  "geo" : { },
  "id_str" : "424762690431905792",
  "text" : "8:36pm Kellianne showing the kids her foot scar, they are fascinated http:\/\/t.co\/ArvJsAHqa0",
  "id" : 424762690431905792,
  "created_at" : "2014-01-19 04:38:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kris",
      "screen_name" : "kris",
      "indices" : [ 0, 5 ],
      "id_str" : "115734106",
      "id" : 115734106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424664097519439872",
  "geo" : { },
  "id_str" : "424720230196072448",
  "in_reply_to_user_id" : 115734106,
  "text" : "@kris well the boots are the most expensive part of the whole outfit.",
  "id" : 424720230196072448,
  "in_reply_to_status_id" : 424664097519439872,
  "created_at" : "2014-01-19 01:49:28 +0000",
  "in_reply_to_screen_name" : "kris",
  "in_reply_to_user_id_str" : "115734106",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enjoy today",
      "screen_name" : "all_about_today",
      "indices" : [ 3, 19 ],
      "id_str" : "1450080632",
      "id" : 1450080632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424705026959753216",
  "text" : "RT @all_about_today: What I've learned from twitter is that if I tell a joke to 1,300 people, at least 2 will laugh.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370186884699279360",
    "text" : "What I've learned from twitter is that if I tell a joke to 1,300 people, at least 2 will laugh.",
    "id" : 370186884699279360,
    "created_at" : "2013-08-21 14:13:25 +0000",
    "user" : {
      "name" : "enjoy today",
      "screen_name" : "all_about_today",
      "protected" : false,
      "id_str" : "1450080632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455778176120020992\/evhYLgQU_normal.jpeg",
      "id" : 1450080632,
      "verified" : false
    }
  },
  "id" : 424705026959753216,
  "created_at" : "2014-01-19 00:49:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/424662203870892032\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/jVTShRnNlE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeS0BjgCEAAC8Sz.jpg",
      "id_str" : "424662203682131968",
      "id" : 424662203682131968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeS0BjgCEAAC8Sz.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/jVTShRnNlE"
    } ],
    "hashtags" : [ {
      "text" : "berkeley",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595876554, -122.2754485534 ]
  },
  "id_str" : "424662203870892032",
  "text" : "#berkeley http:\/\/t.co\/jVTShRnNlE",
  "id" : 424662203870892032,
  "created_at" : "2014-01-18 21:58:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "indices" : [ 0, 12 ],
      "id_str" : "289534689",
      "id" : 289534689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424645494833303552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.854454693, -122.2834572587 ]
  },
  "id_str" : "424645845825241088",
  "in_reply_to_user_id" : 289534689,
  "text" : "@seriouspony how about kindle + books by the foot?",
  "id" : 424645845825241088,
  "in_reply_to_status_id" : 424645494833303552,
  "created_at" : "2014-01-18 20:53:53 +0000",
  "in_reply_to_screen_name" : "seriouspony",
  "in_reply_to_user_id_str" : "289534689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Explore",
      "screen_name" : "Explorer",
      "indices" : [ 4, 13 ],
      "id_str" : "498328279",
      "id" : 498328279
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/424644926429597696\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/Ig0bNI3eR1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeSkT4MCYAAX3eJ.jpg",
      "id_str" : "424644926287011840",
      "id" : 424644926287011840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeSkT4MCYAAX3eJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 516
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 516
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 516
      } ],
      "display_url" : "pic.twitter.com\/Ig0bNI3eR1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8547064386, -122.2835320197 ]
  },
  "id_str" : "424644926429597696",
  "text" : "Via @Explorer: http:\/\/t.co\/Ig0bNI3eR1",
  "id" : 424644926429597696,
  "created_at" : "2014-01-18 20:50:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424640887931416576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8545119256, -122.2834661556 ]
  },
  "id_str" : "424644077863194624",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Software is eating the publishing world from all sides of the sandwich.",
  "id" : 424644077863194624,
  "in_reply_to_status_id" : 424640887931416576,
  "created_at" : "2014-01-18 20:46:52 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/r2AQsm2x4k",
      "expanded_url" : "http:\/\/m.theatlantic.com\/technology\/print\/2014\/01\/-em-the-new-york-times-em-most-popular-story-of-2013-was-not-an-article\/283167\/",
      "display_url" : "m.theatlantic.com\/technology\/pri\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8545960038, -122.2833750667 ]
  },
  "id_str" : "424641470935494656",
  "text" : "The New York Times' most popular story of 2013 wasn't an article http:\/\/t.co\/r2AQsm2x4k",
  "id" : 424641470935494656,
  "created_at" : "2014-01-18 20:36:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8543957429, -122.2834610645 ]
  },
  "id_str" : "424639159718793216",
  "text" : "Saying that you're happy without mentioning something exclusive that caused it is probably the least cool thing you could do on Twitter.",
  "id" : 424639159718793216,
  "created_at" : "2014-01-18 20:27:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hyped up aka popular",
      "screen_name" : "iano",
      "indices" : [ 0, 5 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424636932061421568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8545594652, -122.2835307413 ]
  },
  "id_str" : "424637694061211648",
  "in_reply_to_user_id" : 14409856,
  "text" : "@iano yup, hashtag nailedit",
  "id" : 424637694061211648,
  "in_reply_to_status_id" : 424636932061421568,
  "created_at" : "2014-01-18 20:21:30 +0000",
  "in_reply_to_screen_name" : "iano",
  "in_reply_to_user_id_str" : "14409856",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424629547254833152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8545751053, -122.2834454414 ]
  },
  "id_str" : "424637369128460290",
  "in_reply_to_user_id" : 2185,
  "text" : "AKA How likely are you to recommend our life to your friends &amp; colleagues? AKA net promoter score for your life AKA happiness as a service.",
  "id" : 424637369128460290,
  "in_reply_to_status_id" : 424629547254833152,
  "created_at" : "2014-01-18 20:20:12 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424633626806849536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8545547138, -122.2835901436 ]
  },
  "id_str" : "424634949409333250",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel 8 is awesome!",
  "id" : 424634949409333250,
  "in_reply_to_status_id" : 424633626806849536,
  "created_at" : "2014-01-18 20:10:35 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424632251561676800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8545041941, -122.2834652391 ]
  },
  "id_str" : "424634618801688576",
  "in_reply_to_user_id" : 2185,
  "text" : "Sunny days, iced coffee, and bike rides definitely help. (Enter ominous music as state-wide drought crisis creeps onto the screen.)",
  "id" : 424634618801688576,
  "in_reply_to_status_id" : 424632251561676800,
  "created_at" : "2014-01-18 20:09:17 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424629547254833152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8565824079, -122.2835057416 ]
  },
  "id_str" : "424632251561676800",
  "in_reply_to_user_id" : 2185,
  "text" : "I think I'm at a 9. If my knee wasn't acting weird I might be a 10. Personal life, work, family, etc is all good at the same time.",
  "id" : 424632251561676800,
  "in_reply_to_status_id" : 424629547254833152,
  "created_at" : "2014-01-18 19:59:52 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424629713433153536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8568660241, -122.2838806181 ]
  },
  "id_str" : "424631279124901888",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne What do you think it'll be in 3 weeks?",
  "id" : 424631279124901888,
  "in_reply_to_status_id" : 424629713433153536,
  "created_at" : "2014-01-18 19:56:00 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424629222292725760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8569610412, -122.2841761117 ]
  },
  "id_str" : "424630971770486785",
  "in_reply_to_user_id" : 2185,
  "text" : "@ingopixel Maybe the response is a version of FOMO. If someone can't access\/understand a group's fun, insecurity makes them say it's dumb.",
  "id" : 424630971770486785,
  "in_reply_to_status_id" : 424629222292725760,
  "created_at" : "2014-01-18 19:54:47 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8588079708, -122.2826513742 ]
  },
  "id_str" : "424629547254833152",
  "text" : "On a scale of 1-10, how good is your life right now? And what would make the score higher?",
  "id" : 424629547254833152,
  "created_at" : "2014-01-18 19:49:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424607293053755392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598293574, -122.2826427992 ]
  },
  "id_str" : "424629222292725760",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Yeah I've definitely tried to avoid ruining other people's fun even when it's not my fun. Fun is not a scarce resource. :)",
  "id" : 424629222292725760,
  "in_reply_to_status_id" : 424607293053755392,
  "created_at" : "2014-01-18 19:47:50 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/9t35iJSzag",
      "expanded_url" : "http:\/\/nyti.ms\/1mblke0",
      "display_url" : "nyti.ms\/1mblke0"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596126313, -122.2755906086 ]
  },
  "id_str" : "424598285551038464",
  "text" : "Water reality check time! \"Severe Drought Grows Worse in California\" http:\/\/t.co\/9t35iJSzag",
  "id" : 424598285551038464,
  "created_at" : "2014-01-18 17:44:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/frontback.me\" rel=\"nofollow\"\u003EFrontback\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "frontback",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/9tZXwB4W1Q",
      "expanded_url" : "http:\/\/frontback.me\/p\/vZBXC127",
      "display_url" : "frontback.me\/p\/vZBXC127"
    } ]
  },
  "geo" : { },
  "id_str" : "424400387916197888",
  "text" : "8:36pm Teaching Niko Go Fish, jungle rules http:\/\/t.co\/9tZXwB4W1Q #frontback",
  "id" : 424400387916197888,
  "created_at" : "2014-01-18 04:38:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/424392688637460481\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/rk6wtqW6wK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeO-5jCCEAA-6Yo.jpg",
      "id_str" : "424392685768544256",
      "id" : 424392685768544256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeO-5jCCEAA-6Yo.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/rk6wtqW6wK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597444808, -122.2755133455 ]
  },
  "id_str" : "424392688637460481",
  "text" : "Emergency penguin on a bicycle http:\/\/t.co\/rk6wtqW6wK",
  "id" : 424392688637460481,
  "created_at" : "2014-01-18 04:07:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424274794020745217",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey I\u2019ve learned a ton from you and am bummed to see you go. Hope to work with you again someday!",
  "id" : 424274794020745217,
  "created_at" : "2014-01-17 20:19:28 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena Price",
      "screen_name" : "helena",
      "indices" : [ 0, 7 ],
      "id_str" : "19699682",
      "id" : 19699682
    }, {
      "name" : "Jessica Zollman",
      "screen_name" : "jayzombie",
      "indices" : [ 8, 18 ],
      "id_str" : "14973634",
      "id" : 14973634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424090944862826496",
  "geo" : { },
  "id_str" : "424091497097469952",
  "in_reply_to_user_id" : 19699682,
  "text" : "@helena @jayzombie Let us know how that works out.",
  "id" : 424091497097469952,
  "in_reply_to_status_id" : 424090944862826496,
  "created_at" : "2014-01-17 08:11:06 +0000",
  "in_reply_to_screen_name" : "helena",
  "in_reply_to_user_id_str" : "19699682",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 11, 22 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mustnotgetsickmustnotgetsick",
      "indices" : [ 101, 130 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424046553888608257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596528875, -122.2754709996 ]
  },
  "id_str" : "424046994013691904",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne @nikobenson Uh no maybe the swine flu is already scrambling my animal recognition skills. #mustnotgetsickmustnotgetsick",
  "id" : 424046994013691904,
  "in_reply_to_status_id" : 424046553888608257,
  "created_at" : "2014-01-17 05:14:16 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/424045227251208192\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/jzlHe2xJad",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeKC4ypCAAAkbjn.jpg",
      "id_str" : "424045227104403456",
      "id" : 424045227104403456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeKC4ypCAAAkbjn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jzlHe2xJad"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596811586, -122.2754824068 ]
  },
  "id_str" : "424045227251208192",
  "text" : "8:36pm Blue cow, blue cow on the dresser, will I get swine flu like the rest of them? http:\/\/t.co\/jzlHe2xJad",
  "id" : 424045227251208192,
  "created_at" : "2014-01-17 05:07:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hailey Bergman",
      "screen_name" : "haileybergmann",
      "indices" : [ 0, 15 ],
      "id_str" : "777037808",
      "id" : 777037808
    }, {
      "name" : "\u26A1 W O O F \u26A1",
      "screen_name" : "WOOF",
      "indices" : [ 21, 26 ],
      "id_str" : "594115828",
      "id" : 594115828
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woof",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424020008021553152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598342669, -122.2754008503 ]
  },
  "id_str" : "424027031064420352",
  "in_reply_to_user_id" : 777037808,
  "text" : "@haileybergmann Woof @woof! #woof",
  "id" : 424027031064420352,
  "in_reply_to_status_id" : 424020008021553152,
  "created_at" : "2014-01-17 03:54:56 +0000",
  "in_reply_to_screen_name" : "haileybergmann",
  "in_reply_to_user_id_str" : "777037808",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Model View Culture",
      "screen_name" : "ModelViewMedia",
      "indices" : [ 26, 41 ],
      "id_str" : "2262399740",
      "id" : 2262399740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/aqrhRUl7pF",
      "expanded_url" : "http:\/\/www.fastcompany.com\/3024929\/innovation-agents\/model-view-culture-a-new-tech-publication-the-internet-actually-needs",
      "display_url" : "fastcompany.com\/3024929\/innova\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "423868869208309760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8312210807, -122.2666790209 ]
  },
  "id_str" : "423870399139434496",
  "in_reply_to_user_id" : 2262399740,
  "text" : "So excited about this! RT @ModelViewMedia: Exclusive interview on tech media, not taking VC, and what our name means http:\/\/t.co\/aqrhRUl7pF",
  "id" : 423870399139434496,
  "in_reply_to_status_id" : 423868869208309760,
  "created_at" : "2014-01-16 17:32:32 +0000",
  "in_reply_to_screen_name" : "ModelViewMedia",
  "in_reply_to_user_id_str" : "2262399740",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shanley",
      "screen_name" : "shanley",
      "indices" : [ 113, 121 ],
      "id_str" : "50462250",
      "id" : 50462250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/XhA5CNIDVE",
      "expanded_url" : "http:\/\/modelviewculture.com\/pieces\/tech-workers-political-speech-and-economic-threat",
      "display_url" : "modelviewculture.com\/pieces\/tech-wo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8509838266, -122.26974422 ]
  },
  "id_str" : "423864658978557952",
  "text" : "Super interesting read about how our personal and corporate identities are intertwined http:\/\/t.co\/XhA5CNIDVE by @shanley",
  "id" : 423864658978557952,
  "created_at" : "2014-01-16 17:09:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423560570508693504",
  "geo" : { },
  "id_str" : "423560675139407872",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap I don't make the rules.",
  "id" : 423560675139407872,
  "in_reply_to_status_id" : 423560570508693504,
  "created_at" : "2014-01-15 21:01:48 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423560247115268096",
  "geo" : { },
  "id_str" : "423560455261388800",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap That's totally a subtweet. Sorta.",
  "id" : 423560455261388800,
  "in_reply_to_status_id" : 423560247115268096,
  "created_at" : "2014-01-15 21:00:56 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Murray",
      "screen_name" : "BiIIMurray",
      "indices" : [ 3, 14 ],
      "id_str" : "1132994426",
      "id" : 1132994426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423555274427727873",
  "text" : "RT @BiIIMurray: Whatever you do, always give 100%. Unless you're donating blood.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421789389795393536",
    "text" : "Whatever you do, always give 100%. Unless you're donating blood.",
    "id" : 421789389795393536,
    "created_at" : "2014-01-10 23:43:21 +0000",
    "user" : {
      "name" : "Bill Murray",
      "screen_name" : "BiIIMurray",
      "protected" : false,
      "id_str" : "1132994426",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3240741454\/9080e76653a80e43ae2058432bc76806_normal.jpeg",
      "id" : 1132994426,
      "verified" : false
    }
  },
  "id" : 423555274427727873,
  "created_at" : "2014-01-15 20:40:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nick barr",
      "screen_name" : "nsbarr",
      "indices" : [ 0, 7 ],
      "id_str" : "16062625",
      "id" : 16062625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423509407549227008",
  "geo" : { },
  "id_str" : "423509747120091136",
  "in_reply_to_user_id" : 16062625,
  "text" : "@nsbarr On November 16th you'll have exactly 51 years of life expectancy left. Enjoy!",
  "id" : 423509747120091136,
  "in_reply_to_status_id" : 423509407549227008,
  "created_at" : "2014-01-15 17:39:26 +0000",
  "in_reply_to_screen_name" : "nsbarr",
  "in_reply_to_user_id_str" : "16062625",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/R4dDoMo7PJ",
      "expanded_url" : "http:\/\/wayoftheduck.com\/deathday",
      "display_url" : "wayoftheduck.com\/deathday"
    } ]
  },
  "geo" : { },
  "id_str" : "423507651981344768",
  "text" : "According to my deathday script, today is my 43rd deathday (meaning I have exactly 43 years of life expectancy left). http:\/\/t.co\/R4dDoMo7PJ",
  "id" : 423507651981344768,
  "created_at" : "2014-01-15 17:31:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron Marlow",
      "screen_name" : "cameronmarlow",
      "indices" : [ 0, 14 ],
      "id_str" : "5491",
      "id" : 5491
    }, {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 15, 24 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423464282244673536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762817319, -122.4167993797 ]
  },
  "id_str" : "423504637061107712",
  "in_reply_to_user_id" : 5491,
  "text" : "@cameronmarlow @mathowie Woah I missed this news too! Let's hang out!",
  "id" : 423504637061107712,
  "in_reply_to_status_id" : 423464282244673536,
  "created_at" : "2014-01-15 17:19:08 +0000",
  "in_reply_to_screen_name" : "cameronmarlow",
  "in_reply_to_user_id_str" : "5491",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "indices" : [ 17, 28 ],
      "id_str" : "135316691",
      "id" : 135316691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/0Wcjm5Klzl",
      "expanded_url" : "http:\/\/buff.ly\/1dOIGSe",
      "display_url" : "buff.ly\/1dOIGSe"
    } ]
  },
  "in_reply_to_status_id_str" : "423451269085552640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7771857939, -122.41692423 ]
  },
  "id_str" : "423503422763982848",
  "in_reply_to_user_id" : 135316691,
  "text" : "A great read: RT @JadAbumrad: \"Own your attention, it\u2019s all you really have.\"  Lovely manifesto from Jonathan Harris http:\/\/t.co\/0Wcjm5Klzl",
  "id" : 423503422763982848,
  "in_reply_to_status_id" : 423451269085552640,
  "created_at" : "2014-01-15 17:14:18 +0000",
  "in_reply_to_screen_name" : "JadAbumrad",
  "in_reply_to_user_id_str" : "135316691",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Biz Stone",
      "screen_name" : "biz",
      "indices" : [ 3, 7 ],
      "id_str" : "13",
      "id" : 13
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/4tR9DqmXnC",
      "expanded_url" : "http:\/\/blog.jelly.co\/post\/73361755796\/jelly-one-week-in",
      "display_url" : "blog.jelly.co\/post\/733617557\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423349682555727874",
  "text" : "RT @biz: Jelly, One Week In http:\/\/t.co\/4tR9DqmXnC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/4tR9DqmXnC",
        "expanded_url" : "http:\/\/blog.jelly.co\/post\/73361755796\/jelly-one-week-in",
        "display_url" : "blog.jelly.co\/post\/733617557\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "423267319075196928",
    "text" : "Jelly, One Week In http:\/\/t.co\/4tR9DqmXnC",
    "id" : 423267319075196928,
    "created_at" : "2014-01-15 01:36:07 +0000",
    "user" : {
      "name" : "Biz Stone",
      "screen_name" : "biz",
      "protected" : false,
      "id_str" : "13",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3459395559\/19cde4b0eb9bfaecc5713ab835fe9f6b_normal.jpeg",
      "id" : 13,
      "verified" : true
    }
  },
  "id" : 423349682555727874,
  "created_at" : "2014-01-15 07:03:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/ksTIYv3goF",
      "expanded_url" : "http:\/\/flic.kr\/p\/jdNHbp",
      "display_url" : "flic.kr\/p\/jdNHbp"
    } ]
  },
  "geo" : { },
  "id_str" : "423336136153780224",
  "text" : "8:36pm I deserve ice cream. http:\/\/t.co\/ksTIYv3goF",
  "id" : 423336136153780224,
  "created_at" : "2014-01-15 06:09:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravi Narasimhan",
      "screen_name" : "Ravi",
      "indices" : [ 0, 5 ],
      "id_str" : "20283354",
      "id" : 20283354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423297506902937600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596622451, -122.2755721337 ]
  },
  "id_str" : "423298694696288256",
  "in_reply_to_user_id" : 20283354,
  "text" : "@Ravi And yet, like a dream, the documents are always juust out of reach.",
  "id" : 423298694696288256,
  "in_reply_to_status_id" : 423297506902937600,
  "created_at" : "2014-01-15 03:40:47 +0000",
  "in_reply_to_screen_name" : "Ravi",
  "in_reply_to_user_id_str" : "20283354",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lifeofapm",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8532660411, -122.2705870316 ]
  },
  "id_str" : "423290960278085634",
  "text" : "Imagine a world where everywhere you go documents are floating around. #lifeofapm",
  "id" : 423290960278085634,
  "created_at" : "2014-01-15 03:10:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelsey Falter",
      "screen_name" : "kfalter",
      "indices" : [ 0, 8 ],
      "id_str" : "253578873",
      "id" : 253578873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423255624642621440",
  "geo" : { },
  "id_str" : "423257073330053120",
  "in_reply_to_user_id" : 253578873,
  "text" : "@kfalter Yes!",
  "id" : 423257073330053120,
  "in_reply_to_status_id" : 423255624642621440,
  "created_at" : "2014-01-15 00:55:24 +0000",
  "in_reply_to_screen_name" : "kfalter",
  "in_reply_to_user_id_str" : "253578873",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/Y7DNK1rN8a",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/charliewarzel\/scientists-built-a-computer-program-to-ruthlessly-torture-ro",
      "display_url" : "buzzfeed.com\/charliewarzel\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423235035697672192",
  "text" : "\"And a cruel game begins to emerge\u2026\" http:\/\/t.co\/Y7DNK1rN8a",
  "id" : 423235035697672192,
  "created_at" : "2014-01-14 23:27:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/423233675837190144\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/0beko4fJkr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd-gyR0CQAAZ5oM.png",
      "id_str" : "423233675631673344",
      "id" : 423233675631673344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd-gyR0CQAAZ5oM.png",
      "sizes" : [ {
        "h" : 349,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 657
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 657
      }, {
        "h" : 616,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/0beko4fJkr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423233675837190144",
  "text" : "I finally got it. http:\/\/t.co\/0beko4fJkr",
  "id" : 423233675837190144,
  "created_at" : "2014-01-14 23:22:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chavi",
      "screen_name" : "ChavaRisa",
      "indices" : [ 0, 10 ],
      "id_str" : "19054503",
      "id" : 19054503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423204155595829248",
  "geo" : { },
  "id_str" : "423224165810708480",
  "in_reply_to_user_id" : 19054503,
  "text" : "@chavarisa To make it tweet regularly, you need to set up a cron job. Know what those are? Let me know if you have questions about them.",
  "id" : 423224165810708480,
  "in_reply_to_status_id" : 423204155595829248,
  "created_at" : "2014-01-14 22:44:38 +0000",
  "in_reply_to_screen_name" : "ChavaRisa",
  "in_reply_to_user_id_str" : "19054503",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chavi",
      "screen_name" : "ChavaRisa",
      "indices" : [ 0, 10 ],
      "id_str" : "19054503",
      "id" : 19054503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423200595256692736",
  "geo" : { },
  "id_str" : "423202643079467008",
  "in_reply_to_user_id" : 19054503,
  "text" : "@chavarisa That's awesome! Now prepare for some hilariousness not to mention confusion from friends who get mentioned. :)",
  "id" : 423202643079467008,
  "in_reply_to_status_id" : 423200595256692736,
  "created_at" : "2014-01-14 21:19:07 +0000",
  "in_reply_to_screen_name" : "ChavaRisa",
  "in_reply_to_user_id_str" : "19054503",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 52, 58 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/qJNuvaG59f",
      "expanded_url" : "http:\/\/wrd.cm\/1j4UiIl",
      "display_url" : "wrd.cm\/1j4UiIl"
    } ]
  },
  "in_reply_to_status_id_str" : "422993767386189824",
  "geo" : { },
  "id_str" : "422996535350018048",
  "in_reply_to_user_id" : 1344951,
  "text" : "Hyperbole eats its own tail, gets lots of clicks RT @WIRED: Why the PC's death might also mean the web's demise http:\/\/t.co\/qJNuvaG59f",
  "id" : 422996535350018048,
  "in_reply_to_status_id" : 422993767386189824,
  "created_at" : "2014-01-14 07:40:07 +0000",
  "in_reply_to_screen_name" : "WIRED",
  "in_reply_to_user_id_str" : "1344951",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mina Doroud",
      "screen_name" : "MMiiina",
      "indices" : [ 0, 8 ],
      "id_str" : "44690011",
      "id" : 44690011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422986777532444674",
  "geo" : { },
  "id_str" : "422986946277699584",
  "in_reply_to_user_id" : 44690011,
  "text" : "@mmiiina Exactly. The % chance that each of your followers will fave or RT each of your tweets.",
  "id" : 422986946277699584,
  "in_reply_to_status_id" : 422986777532444674,
  "created_at" : "2014-01-14 07:02:01 +0000",
  "in_reply_to_screen_name" : "MMiiina",
  "in_reply_to_user_id_str" : "44690011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mina Doroud",
      "screen_name" : "MMiiina",
      "indices" : [ 0, 8 ],
      "id_str" : "44690011",
      "id" : 44690011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422986203936223232",
  "geo" : { },
  "id_str" : "422986464385720322",
  "in_reply_to_user_id" : 44690011,
  "text" : "@mmiiina It actually means, interest*ed* folks follow you. :)",
  "id" : 422986464385720322,
  "in_reply_to_status_id" : 422986203936223232,
  "created_at" : "2014-01-14 07:00:06 +0000",
  "in_reply_to_screen_name" : "MMiiina",
  "in_reply_to_user_id_str" : "44690011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mina Doroud",
      "screen_name" : "MMiiina",
      "indices" : [ 0, 8 ],
      "id_str" : "44690011",
      "id" : 44690011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422985377939353600",
  "geo" : { },
  "id_str" : "422985662552236032",
  "in_reply_to_user_id" : 44690011,
  "text" : "@mmiiina It's faves + RTs over your last 1000 tweets \/ 1000 \/ # followers. Yours is 0.08988401504981073%. Super high.",
  "id" : 422985662552236032,
  "in_reply_to_status_id" : 422985377939353600,
  "created_at" : "2014-01-14 06:56:55 +0000",
  "in_reply_to_screen_name" : "MMiiina",
  "in_reply_to_user_id_str" : "44690011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0CA0_\u0CA0",
      "screen_name" : "MikeIsaac",
      "indices" : [ 0, 10 ],
      "id_str" : "19040598",
      "id" : 19040598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422982606720733184",
  "geo" : { },
  "id_str" : "422985300336336896",
  "in_reply_to_user_id" : 2185,
  "text" : "@mikeisaac Yours is 0.03988277949496786%.",
  "id" : 422985300336336896,
  "in_reply_to_status_id" : 422982606720733184,
  "created_at" : "2014-01-14 06:55:28 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "indices" : [ 0, 12 ],
      "id_str" : "289534689",
      "id" : 289534689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422982606720733184",
  "geo" : { },
  "id_str" : "422985103292104704",
  "in_reply_to_user_id" : 2185,
  "text" : "@seriouspony Yours is 0.08146066091309493%. More than double mine.",
  "id" : 422985103292104704,
  "in_reply_to_status_id" : 422982606720733184,
  "created_at" : "2014-01-14 06:54:41 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 0, 4 ],
      "id_str" : "12720772",
      "id" : 12720772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422982606720733184",
  "geo" : { },
  "id_str" : "422984553582428160",
  "in_reply_to_user_id" : 2185,
  "text" : "@gwb Yours is 0.0461430557777%. Got me beat.",
  "id" : 422984553582428160,
  "in_reply_to_status_id" : 422982606720733184,
  "created_at" : "2014-01-14 06:52:30 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422982606720733184",
  "geo" : { },
  "id_str" : "422984388440121344",
  "in_reply_to_user_id" : 2185,
  "text" : "@mathowie Yours is 0.0292119579376%.",
  "id" : 422984388440121344,
  "in_reply_to_status_id" : 422982606720733184,
  "created_at" : "2014-01-14 06:51:51 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422982606720733184",
  "text" : "I just calculated the likelihood that each of my followers will fave or RT this tweet. It\u2019s 0.0315049852006%.",
  "id" : 422982606720733184,
  "created_at" : "2014-01-14 06:44:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422972959771217920",
  "geo" : { },
  "id_str" : "422978630751240192",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel They have an iPhone app, and integrate with many other iPhone apps too\u2026 YouTube, HBOGo, Hulu, etc. It\u2019s pretty impressive.",
  "id" : 422978630751240192,
  "in_reply_to_status_id" : 422972959771217920,
  "created_at" : "2014-01-14 06:28:58 +0000",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffy Drama",
      "screen_name" : "GeoffyDrama",
      "indices" : [ 0, 12 ],
      "id_str" : "1312118102",
      "id" : 1312118102
    }, {
      "name" : "Geoffrey Brown",
      "screen_name" : "gwb",
      "indices" : [ 61, 65 ],
      "id_str" : "12720772",
      "id" : 12720772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422953871208493056",
  "geo" : { },
  "id_str" : "422962893907185664",
  "in_reply_to_user_id" : 1312118102,
  "text" : "@GeoffyDrama Imagine what would happen if we unleashed it on @gwb\u2019s tweets.",
  "id" : 422962893907185664,
  "in_reply_to_status_id" : 422953871208493056,
  "created_at" : "2014-01-14 05:26:26 +0000",
  "in_reply_to_screen_name" : "GeoffyDrama",
  "in_reply_to_user_id_str" : "1312118102",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aronchick",
      "screen_name" : "aronchick",
      "indices" : [ 0, 10 ],
      "id_str" : "15024407",
      "id" : 15024407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422959735382343682",
  "geo" : { },
  "id_str" : "422962609877315584",
  "in_reply_to_user_id" : 15024407,
  "text" : "@aronchick I\u2019m not sure yet. Just installed it and immediately went to catch up on some HBO. :) Will let you know after this is over.",
  "id" : 422962609877315584,
  "in_reply_to_status_id" : 422959735382343682,
  "created_at" : "2014-01-14 05:25:19 +0000",
  "in_reply_to_screen_name" : "aronchick",
  "in_reply_to_user_id_str" : "15024407",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/iZBZPrdYkN",
      "expanded_url" : "http:\/\/flic.kr\/p\/jceGwZ",
      "display_url" : "flic.kr\/p\/jceGwZ"
    } ]
  },
  "geo" : { },
  "id_str" : "422957369413607424",
  "text" : "8:36pm Sort of blown away by Google Chromecast's ability to connect my TV, phone, and computer for $35. http:\/\/t.co\/iZBZPrdYkN",
  "id" : 422957369413607424,
  "created_at" : "2014-01-14 05:04:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Zumsteg",
      "screen_name" : "milhous",
      "indices" : [ 3, 11 ],
      "id_str" : "14300282",
      "id" : 14300282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422866643262242816",
  "text" : "RT @milhous: Google now controls both my thermostat and military robots with heat-seeking weapons.\n\nFine. I\u2019ll sign up for G+.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "422838326769373184",
    "text" : "Google now controls both my thermostat and military robots with heat-seeking weapons.\n\nFine. I\u2019ll sign up for G+.",
    "id" : 422838326769373184,
    "created_at" : "2014-01-13 21:11:27 +0000",
    "user" : {
      "name" : "Derek Zumsteg",
      "screen_name" : "milhous",
      "protected" : false,
      "id_str" : "14300282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461892319466106881\/x4DR7s3R_normal.jpeg",
      "id" : 14300282,
      "verified" : false
    }
  },
  "id" : 422866643262242816,
  "created_at" : "2014-01-13 23:03:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Re\/code",
      "screen_name" : "Recode",
      "indices" : [ 14, 21 ],
      "id_str" : "2244340904",
      "id" : 2244340904
    }, {
      "name" : "Liz Gannes",
      "screen_name" : "lizgannes",
      "indices" : [ 59, 69 ],
      "id_str" : "770729",
      "id" : 770729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/45K0XFTJol",
      "expanded_url" : "http:\/\/ift.tt\/KfA1Al",
      "display_url" : "ift.tt\/KfA1Al"
    } ]
  },
  "in_reply_to_status_id_str" : "422838173753155584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7765559072, -122.4170076579 ]
  },
  "id_str" : "422848650834759680",
  "in_reply_to_user_id" : 2244340904,
  "text" : "Wah wah :\/ RT @Recode: Google Acquires Nest for $3.2B \/ by @lizgannes \/ http:\/\/t.co\/45K0XFTJol",
  "id" : 422848650834759680,
  "in_reply_to_status_id" : 422838173753155584,
  "created_at" : "2014-01-13 21:52:29 +0000",
  "in_reply_to_screen_name" : "Recode",
  "in_reply_to_user_id_str" : "2244340904",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 25, 41 ],
      "id_str" : "246531241",
      "id" : 246531241
    }, {
      "name" : "Model View Culture",
      "screen_name" : "ModelViewMedia",
      "indices" : [ 46, 61 ],
      "id_str" : "2262399740",
      "id" : 2262399740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/xZeLU50n4m",
      "expanded_url" : "http:\/\/modelviewculture.com\/pieces\/founder-risk",
      "display_url" : "modelviewculture.com\/pieces\/founder\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422789303228309504",
  "text" : "Truth: \"Founder Risk\" by @ameliagreenhall and @ModelViewMedia http:\/\/t.co\/xZeLU50n4m",
  "id" : 422789303228309504,
  "created_at" : "2014-01-13 17:56:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Model View Culture",
      "screen_name" : "ModelViewMedia",
      "indices" : [ 3, 18 ],
      "id_str" : "2262399740",
      "id" : 2262399740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/vO9LHS57nr",
      "expanded_url" : "http:\/\/modelviewculture.com",
      "display_url" : "modelviewculture.com"
    } ]
  },
  "geo" : { },
  "id_str" : "422788627072950272",
  "text" : "RT @ModelViewMedia: Model View Culture is a new media platform covering technology, culture and diversity. First issue live online now - ht\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/vO9LHS57nr",
        "expanded_url" : "http:\/\/modelviewculture.com",
        "display_url" : "modelviewculture.com"
      } ]
    },
    "geo" : { },
    "id_str" : "422774668215328768",
    "text" : "Model View Culture is a new media platform covering technology, culture and diversity. First issue live online now - http:\/\/t.co\/vO9LHS57nr",
    "id" : 422774668215328768,
    "created_at" : "2014-01-13 16:58:30 +0000",
    "user" : {
      "name" : "Model View Culture",
      "screen_name" : "ModelViewMedia",
      "protected" : false,
      "id_str" : "2262399740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422754620759236608\/hz-QJ1e4_normal.png",
      "id" : 2262399740,
      "verified" : false
    }
  },
  "id" : 422788627072950272,
  "created_at" : "2014-01-13 17:53:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422777490201776128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7843820451, -122.4078617727 ]
  },
  "id_str" : "422780955783208960",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall Wow! Great name and great design! Will start reading...",
  "id" : 422780955783208960,
  "in_reply_to_status_id" : 422777490201776128,
  "created_at" : "2014-01-13 17:23:29 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deval Delivala",
      "screen_name" : "devalad",
      "indices" : [ 0, 8 ],
      "id_str" : "57700233",
      "id" : 57700233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422615649139965952",
  "geo" : { },
  "id_str" : "422620547806007296",
  "in_reply_to_user_id" : 57700233,
  "text" : "@devalad Thanks! I keep thinking about many of the things in that post... I'm glad you found it somewhat comprehensible. :)",
  "id" : 422620547806007296,
  "in_reply_to_status_id" : 422615649139965952,
  "created_at" : "2014-01-13 06:46:05 +0000",
  "in_reply_to_screen_name" : "devalad",
  "in_reply_to_user_id_str" : "57700233",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles N. Cox",
      "screen_name" : "agentcox",
      "indices" : [ 0, 9 ],
      "id_str" : "14290530",
      "id" : 14290530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422604234832347136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597803135, -122.275553411 ]
  },
  "id_str" : "422606103600328704",
  "in_reply_to_user_id" : 14290530,
  "text" : "@agentcox Looks like it. :(",
  "id" : 422606103600328704,
  "in_reply_to_status_id" : 422604234832347136,
  "created_at" : "2014-01-13 05:48:41 +0000",
  "in_reply_to_screen_name" : "agentcox",
  "in_reply_to_user_id_str" : "14290530",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/4ykR7fjRZg",
      "expanded_url" : "http:\/\/flic.kr\/p\/jazjkM",
      "display_url" : "flic.kr\/p\/jazjkM"
    } ]
  },
  "geo" : { },
  "id_str" : "422601224752746496",
  "text" : "8:36pm Checking out the space trek TED talks since I can't find Cosmos on Netflix http:\/\/t.co\/4ykR7fjRZg",
  "id" : 422601224752746496,
  "created_at" : "2014-01-13 05:29:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/eRgRuaOeJX",
      "expanded_url" : "https:\/\/vine.co\/v\/hLZILFmAqgb",
      "display_url" : "vine.co\/v\/hLZILFmAqgb"
    } ]
  },
  "geo" : { },
  "id_str" : "422480031932514305",
  "text" : "Jack and Jill's hill at Fairyland https:\/\/t.co\/eRgRuaOeJX",
  "id" : 422480031932514305,
  "created_at" : "2014-01-12 21:27:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422423202011168768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597524017, -122.2754327954 ]
  },
  "id_str" : "422429253750099968",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler I'm fine using cable if there's a super light-weight option. I only need a log in, not even a receiver.",
  "id" : 422429253750099968,
  "in_reply_to_status_id" : 422423202011168768,
  "created_at" : "2014-01-12 18:05:57 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422423859829035008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597419092, -122.2755326646 ]
  },
  "id_str" : "422429024833384449",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler I looked into them. I already have internet and Comcast doesn't support HBO Go on Roku. Jerks.",
  "id" : 422429024833384449,
  "in_reply_to_status_id" : 422423859829035008,
  "created_at" : "2014-01-12 18:05:02 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omid Ashtari",
      "screen_name" : "omid",
      "indices" : [ 0, 5 ],
      "id_str" : "114971521",
      "id" : 114971521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422231305233760257",
  "geo" : { },
  "id_str" : "422239387024252928",
  "in_reply_to_user_id" : 114971521,
  "text" : "@omid I don\u2019t see it.",
  "id" : 422239387024252928,
  "in_reply_to_status_id" : 422231305233760257,
  "created_at" : "2014-01-12 05:31:29 +0000",
  "in_reply_to_screen_name" : "omid",
  "in_reply_to_user_id_str" : "114971521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/422230365957132289\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/p2rYTFxBQ2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdwQR9WCcAAfEWN.jpg",
      "id_str" : "422230365776801792",
      "id" : 422230365776801792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdwQR9WCcAAfEWN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/p2rYTFxBQ2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597565735, -122.2757277954 ]
  },
  "id_str" : "422230365957132289",
  "text" : "8:36pm Finally not afraid of bubbles http:\/\/t.co\/p2rYTFxBQ2",
  "id" : 422230365957132289,
  "created_at" : "2014-01-12 04:55:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422222967523647488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596571414, -122.2755056341 ]
  },
  "id_str" : "422224557575909376",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Xfinity apparently doesn't support the Roku for some reason.",
  "id" : 422224557575909376,
  "in_reply_to_status_id" : 422222967523647488,
  "created_at" : "2014-01-12 04:32:33 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422211657603891201",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859620208, -122.2754861799 ]
  },
  "id_str" : "422218509477617664",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim I have a couple codes now but would like to pay for it if I can find a reasonable option.",
  "id" : 422218509477617664,
  "in_reply_to_status_id" : 422211657603891201,
  "created_at" : "2014-01-12 04:08:31 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422216268259676160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596607456, -122.2753416841 ]
  },
  "id_str" : "422218299762429952",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright I have! I may still end up stealing it but want to find the best way to not steal it so I can make a deliberate choice.",
  "id" : 422218299762429952,
  "in_reply_to_status_id" : 422216268259676160,
  "created_at" : "2014-01-12 04:07:41 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422210043597946880",
  "geo" : { },
  "id_str" : "422210594817589248",
  "in_reply_to_user_id" : 2185,
  "text" : "So far I\u2019ve found the AT&amp;T U-Verse Basic TV option ($19\/mo) + HBO ($16\/mo) + $199 installation.",
  "id" : 422210594817589248,
  "in_reply_to_status_id" : 422210043597946880,
  "created_at" : "2014-01-12 03:37:04 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422210043597946880",
  "text" : "Question: for someone that doesn\u2019t have cable but wants to pay for HBO Go, what\u2019s the cheapest legal option available?",
  "id" : 422210043597946880,
  "created_at" : "2014-01-12 03:34:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 0, 3 ],
      "id_str" : "15504330",
      "id" : 15504330
    }, {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 4, 18 ],
      "id_str" : "226976689",
      "id" : 226976689
    }, {
      "name" : "Camille Fournier",
      "screen_name" : "skamille",
      "indices" : [ 19, 28 ],
      "id_str" : "24257941",
      "id" : 24257941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422166067679477760",
  "geo" : { },
  "id_str" : "422166944221900801",
  "in_reply_to_user_id" : 15504330,
  "text" : "@wm @marcprecipice @skamille I liked all the details about working on a submarine. More dry but more useful for me was The Fifth Discipline.",
  "id" : 422166944221900801,
  "in_reply_to_status_id" : 422166067679477760,
  "created_at" : "2014-01-12 00:43:37 +0000",
  "in_reply_to_screen_name" : "wm",
  "in_reply_to_user_id_str" : "15504330",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422144554452537344",
  "geo" : { },
  "id_str" : "422144820891496448",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover I wrote a script to update that every week or two with people I've talked to and who talk back. Just testing the timeline quality.",
  "id" : 422144820891496448,
  "in_reply_to_status_id" : 422144554452537344,
  "created_at" : "2014-01-11 23:15:43 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 3, 15 ],
      "id_str" : "195863654",
      "id" : 195863654
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 17, 24 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422111276681023488",
  "text" : "RT @marihuertas: @buster Without looking at Twitter, I wrote a list of everyone I really *wanted* to follow. It numbered ~100. I haven't en\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "422106076691972096",
    "geo" : { },
    "id_str" : "422108517911117824",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster Without looking at Twitter, I wrote a list of everyone I really *wanted* to follow. It numbered ~100. I haven't enacted change yet.",
    "id" : 422108517911117824,
    "in_reply_to_status_id" : 422106076691972096,
    "created_at" : "2014-01-11 20:51:27 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "protected" : false,
      "id_str" : "195863654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000420864707\/b827233ecd1cd9452628cff95555c284_normal.jpeg",
      "id" : 195863654,
      "verified" : false
    }
  },
  "id" : 422111276681023488,
  "created_at" : "2014-01-11 21:02:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 0, 12 ],
      "id_str" : "195863654",
      "id" : 195863654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422108517911117824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596941894, -122.2754537502 ]
  },
  "id_str" : "422111134028951553",
  "in_reply_to_user_id" : 195863654,
  "text" : "@marihuertas That's a great idea.",
  "id" : 422111134028951553,
  "in_reply_to_status_id" : 422108517911117824,
  "created_at" : "2014-01-11 21:01:51 +0000",
  "in_reply_to_screen_name" : "marihuertas",
  "in_reply_to_user_id_str" : "195863654",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/xXDN1FLy3u",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/charliewarzel\/why-you-should-rebuild-your-twitter-feed-from-scratch",
      "display_url" : "buzzfeed.com\/charliewarzel\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597094445, -122.2754625512 ]
  },
  "id_str" : "422106076691972096",
  "text" : "Why you should consider nuking and rebuilding your Twitter feed. I'm tempted. http:\/\/t.co\/xXDN1FLy3u",
  "id" : 422106076691972096,
  "created_at" : "2014-01-11 20:41:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen M. Murray",
      "screen_name" : "allenmmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "22118364",
      "id" : 22118364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422091119237685248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597932635, -122.2754014471 ]
  },
  "id_str" : "422091600727011329",
  "in_reply_to_user_id" : 22118364,
  "text" : "@allenmmurray The iPhone app has a (relatively new) way to filter search results by people you know. Look for the icon in the search box.",
  "id" : 422091600727011329,
  "in_reply_to_status_id" : 422091119237685248,
  "created_at" : "2014-01-11 19:44:14 +0000",
  "in_reply_to_screen_name" : "allenmmurray",
  "in_reply_to_user_id_str" : "22118364",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 8, 19 ],
      "id_str" : "14934401",
      "id" : 14934401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422086584721108992",
  "geo" : { },
  "id_str" : "422087329369440256",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach @jreichhold Cool. Do you think it\u2019s precise enough to draw somewhat detailed illustrations with \/ write notes?",
  "id" : 422087329369440256,
  "in_reply_to_status_id" : 422086584721108992,
  "created_at" : "2014-01-11 19:27:15 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FiftyThree",
      "screen_name" : "FiftyThree",
      "indices" : [ 29, 40 ],
      "id_str" : "492609310",
      "id" : 492609310
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "disappointed",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422082796241178624",
  "text" : "I got that Pencil thing from @fiftythree but find that the tip is pretty floppy and precise drawing is still difficult. #disappointed",
  "id" : 422082796241178624,
  "created_at" : "2014-01-11 19:09:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen M. Murray",
      "screen_name" : "allenmmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "22118364",
      "id" : 22118364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422076980645744640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597395431, -122.2755424263 ]
  },
  "id_str" : "422080743905296384",
  "in_reply_to_user_id" : 22118364,
  "text" : "@allenmmurray One of my favorite hidden uses of Twitter is searching for a URL or word from people I follow.",
  "id" : 422080743905296384,
  "in_reply_to_status_id" : 422076980645744640,
  "created_at" : "2014-01-11 19:01:05 +0000",
  "in_reply_to_screen_name" : "allenmmurray",
  "in_reply_to_user_id_str" : "22118364",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/FP24BP7brm",
      "expanded_url" : "http:\/\/flic.kr\/p\/j6Wi66",
      "display_url" : "flic.kr\/p\/j6Wi66"
    } ]
  },
  "geo" : { },
  "id_str" : "421868009310146560",
  "text" : "8:36pm Just setting up my TV and Roku. Hate these wires and remotes... suggestions? http:\/\/t.co\/FP24BP7brm",
  "id" : 421868009310146560,
  "created_at" : "2014-01-11 04:55:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8287676489, -122.2668902111 ]
  },
  "id_str" : "421837594377195521",
  "text" : "I could tell you about our #hackweek project at a bird company that was in the top 5, but I'd have to block you.",
  "id" : 421837594377195521,
  "created_at" : "2014-01-11 02:54:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mihow",
      "screen_name" : "mihow",
      "indices" : [ 51, 57 ],
      "id_str" : "764757",
      "id" : 764757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/fi5ZMzvo6y",
      "expanded_url" : "http:\/\/mihow.com\/articles\/2014\/01\/10\/adult-consequence\/",
      "display_url" : "mihow.com\/articles\/2014\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78017025, -122.41347473 ]
  },
  "id_str" : "421831821467201536",
  "text" : "Thought-provoking post about adult consequences by @mihow, give it a read! http:\/\/t.co\/fi5ZMzvo6y",
  "id" : 421831821467201536,
  "created_at" : "2014-01-11 02:31:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "indices" : [ 3, 8 ],
      "id_str" : "949521",
      "id" : 949521
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/stop\/status\/421772364678828032\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/Is4AKif1CC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdpvuyUCEAA7jLV.jpg",
      "id_str" : "421772364683022336",
      "id" : 421772364683022336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdpvuyUCEAA7jLV.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/Is4AKif1CC"
    } ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421777369049743360",
  "text" : "RT @stop: Demo day at Twitter shows off all the amazing work spawned during #hackweek. http:\/\/t.co\/Is4AKif1CC",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/stop\/status\/421772364678828032\/photo\/1",
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/Is4AKif1CC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdpvuyUCEAA7jLV.jpg",
        "id_str" : "421772364683022336",
        "id" : 421772364683022336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdpvuyUCEAA7jLV.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/Is4AKif1CC"
      } ],
      "hashtags" : [ {
        "text" : "hackweek",
        "indices" : [ 66, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421772364678828032",
    "text" : "Demo day at Twitter shows off all the amazing work spawned during #hackweek. http:\/\/t.co\/Is4AKif1CC",
    "id" : 421772364678828032,
    "created_at" : "2014-01-10 22:35:42 +0000",
    "user" : {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "protected" : false,
      "id_str" : "949521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441691596375863296\/H7LzEpDT_normal.jpeg",
      "id" : 949521,
      "verified" : false
    }
  },
  "id" : 421777369049743360,
  "created_at" : "2014-01-10 22:55:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421512505785974784",
  "geo" : { },
  "id_str" : "421531089065086976",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm Yeah, Paisan on San Pablo. It\u2019s one of our regulars. Good pizza and a family friendly closed patio area in back.",
  "id" : 421531089065086976,
  "in_reply_to_status_id" : 421512505785974784,
  "created_at" : "2014-01-10 06:36:57 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/421506490763968512\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/KKblh7f9M9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bdl964ACIAEkHXX.jpg",
      "id_str" : "421506490554261505",
      "id" : 421506490554261505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bdl964ACIAEkHXX.jpg",
      "sizes" : [ {
        "h" : 577,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com\/KKblh7f9M9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596546688, -122.2753909697 ]
  },
  "id_str" : "421506490763968512",
  "text" : "8:36pm Got my healing wife out of the house for dinner http:\/\/t.co\/KKblh7f9M9",
  "id" : 421506490763968512,
  "created_at" : "2014-01-10 04:59:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bailey Ash",
      "screen_name" : "bails",
      "indices" : [ 3, 9 ],
      "id_str" : "20565541",
      "id" : 20565541
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 42, 49 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Noah Pepper",
      "screen_name" : "noahmp",
      "indices" : [ 50, 57 ],
      "id_str" : "20219699",
      "id" : 20219699
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 32, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421413429870465025",
  "text" : "RT @bails: \"Bring your diapers\" #hackweek @buster @noahmp",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 31, 38 ],
        "id_str" : "2185",
        "id" : 2185
      }, {
        "name" : "Noah Pepper",
        "screen_name" : "noahmp",
        "indices" : [ 39, 46 ],
        "id_str" : "20219699",
        "id" : 20219699
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hackweek",
        "indices" : [ 21, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421413268607864832",
    "text" : "\"Bring your diapers\" #hackweek @buster @noahmp",
    "id" : 421413268607864832,
    "created_at" : "2014-01-09 22:48:47 +0000",
    "user" : {
      "name" : "Bailey Ash",
      "screen_name" : "bails",
      "protected" : false,
      "id_str" : "20565541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1321905834\/image_normal.jpg",
      "id" : 20565541,
      "verified" : false
    }
  },
  "id" : 421413429870465025,
  "created_at" : "2014-01-09 22:49:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "molly w steenson",
      "screen_name" : "maximolly",
      "indices" : [ 3, 13 ],
      "id_str" : "45463",
      "id" : 45463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/o3RMIiuE2M",
      "expanded_url" : "http:\/\/www.ozy.com\/flashback\/annie-hall-vs-anhedonia\/4658.article#.Us6roVXzDSk.twitter",
      "display_url" : "ozy.com\/flashback\/anni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421328668216934401",
  "text" : "RT @maximolly: \"Annie Hall\" was really a subplot in a different film. http:\/\/t.co\/o3RMIiuE2M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/o3RMIiuE2M",
        "expanded_url" : "http:\/\/www.ozy.com\/flashback\/annie-hall-vs-anhedonia\/4658.article#.Us6roVXzDSk.twitter",
        "display_url" : "ozy.com\/flashback\/anni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "421280770469023744",
    "text" : "\"Annie Hall\" was really a subplot in a different film. http:\/\/t.co\/o3RMIiuE2M",
    "id" : 421280770469023744,
    "created_at" : "2014-01-09 14:02:17 +0000",
    "user" : {
      "name" : "molly w steenson",
      "screen_name" : "maximolly",
      "protected" : false,
      "id_str" : "45463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2839516768\/67aee82d15e518d75b331f16d3911bcc_normal.jpeg",
      "id" : 45463,
      "verified" : false
    }
  },
  "id" : 421328668216934401,
  "created_at" : "2014-01-09 17:12:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/xnQgU9OvZb",
      "expanded_url" : "http:\/\/flic.kr\/p\/j44Y2z",
      "display_url" : "flic.kr\/p\/j44Y2z"
    } ]
  },
  "geo" : { },
  "id_str" : "421154733941080064",
  "text" : "8:36pm \"Come up with a plan or else I'm gonna get into bed and watch Doctor Who.\" http:\/\/t.co\/xnQgU9OvZb",
  "id" : 421154733941080064,
  "created_at" : "2014-01-09 05:41:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/421056464703078401\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/EfORNtotQa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bdfkn6HCEAE6GGv.png",
      "id_str" : "421056464447213569",
      "id" : 421056464447213569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bdfkn6HCEAE6GGv.png",
      "sizes" : [ {
        "h" : 645,
        "resize" : "fit",
        "w" : 653
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 593,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 645,
        "resize" : "fit",
        "w" : 653
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EfORNtotQa"
    } ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421056464703078401",
  "text" : "#hackweek http:\/\/t.co\/EfORNtotQa",
  "id" : 421056464703078401,
  "created_at" : "2014-01-08 23:10:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter NYC",
      "screen_name" : "TwitterNYC",
      "indices" : [ 69, 80 ],
      "id_str" : "495309159",
      "id" : 495309159
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vivian\/status\/420977380929183744\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/0SGH9eirzR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdecsoYCQAAdyaX.jpg",
      "id_str" : "420977380748836864",
      "id" : 420977380748836864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdecsoYCQAAdyaX.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/0SGH9eirzR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421019497701863424",
  "text" : "RT @VivianSchiller: The journalistic spirit is alive and well at the @TwitterNYC office.... http:\/\/t.co\/0SGH9eirzR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter NYC",
        "screen_name" : "TwitterNYC",
        "indices" : [ 49, 60 ],
        "id_str" : "495309159",
        "id" : 495309159
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vivian\/status\/420977380929183744\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/0SGH9eirzR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdecsoYCQAAdyaX.jpg",
        "id_str" : "420977380748836864",
        "id" : 420977380748836864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdecsoYCQAAdyaX.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/0SGH9eirzR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420977380929183744",
    "text" : "The journalistic spirit is alive and well at the @TwitterNYC office.... http:\/\/t.co\/0SGH9eirzR",
    "id" : 420977380929183744,
    "created_at" : "2014-01-08 17:56:43 +0000",
    "user" : {
      "name" : "Vivian Schiller",
      "screen_name" : "vivian",
      "protected" : false,
      "id_str" : "14454645",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/413309355585310720\/4VAiNX2x_normal.jpeg",
      "id" : 14454645,
      "verified" : false
    }
  },
  "id" : 421019497701863424,
  "created_at" : "2014-01-08 20:44:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/isaach\/status\/420970867720347648\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/DGAYWa0enn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdeWxgnCEAApRYD.png",
      "id_str" : "420970867493834752",
      "id" : 420970867493834752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdeWxgnCEAApRYD.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DGAYWa0enn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/cZL2uBFysJ",
      "expanded_url" : "http:\/\/www.businessinsider.com\/chen-guangbiaos-incredible-business-card-2014-1",
      "display_url" : "businessinsider.com\/chen-guangbiao\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420972418505506816",
  "text" : "RT @isaach: wow. \"The Incredible Business Card Of The Chinese Millionaire Who Wants To Buy The NYT\" http:\/\/t.co\/cZL2uBFysJ http:\/\/t.co\/DGAY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/isaach\/status\/420970867720347648\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/DGAYWa0enn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdeWxgnCEAApRYD.png",
        "id_str" : "420970867493834752",
        "id" : 420970867493834752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdeWxgnCEAApRYD.png",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DGAYWa0enn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/cZL2uBFysJ",
        "expanded_url" : "http:\/\/www.businessinsider.com\/chen-guangbiaos-incredible-business-card-2014-1",
        "display_url" : "businessinsider.com\/chen-guangbiao\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "420970867720347648",
    "text" : "wow. \"The Incredible Business Card Of The Chinese Millionaire Who Wants To Buy The NYT\" http:\/\/t.co\/cZL2uBFysJ http:\/\/t.co\/DGAYWa0enn",
    "id" : 420970867720347648,
    "created_at" : "2014-01-08 17:30:50 +0000",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430605387117494272\/lmplHwca_normal.png",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 420972418505506816,
  "created_at" : "2014-01-08 17:37:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420970867720347648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7844485179, -122.4077993678 ]
  },
  "id_str" : "420972384338714625",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach Wow I've been doing my business cards all wrong.",
  "id" : 420972384338714625,
  "in_reply_to_status_id" : 420970867720347648,
  "created_at" : "2014-01-08 17:36:52 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "megan gebhart",
      "screen_name" : "megangebhart",
      "indices" : [ 3, 16 ],
      "id_str" : "32966836",
      "id" : 32966836
    }, {
      "name" : "elle luna",
      "screen_name" : "elleluna",
      "indices" : [ 63, 72 ],
      "id_str" : "21107053",
      "id" : 21107053
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "52cups",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/nwKeUtIKpq",
      "expanded_url" : "http:\/\/www.52cups.com\/post\/72647863155\/cup5",
      "display_url" : "52cups.com\/post\/726478631\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420942166295199744",
  "text" : "RT @megangebhart: So excited for Cup 5 featuring the inspiring @elleluna and the quest to Find Your Must: http:\/\/t.co\/nwKeUtIKpq #52cups",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "elle luna",
        "screen_name" : "elleluna",
        "indices" : [ 45, 54 ],
        "id_str" : "21107053",
        "id" : 21107053
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "52cups",
        "indices" : [ 111, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/nwKeUtIKpq",
        "expanded_url" : "http:\/\/www.52cups.com\/post\/72647863155\/cup5",
        "display_url" : "52cups.com\/post\/726478631\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "420940442122076160",
    "text" : "So excited for Cup 5 featuring the inspiring @elleluna and the quest to Find Your Must: http:\/\/t.co\/nwKeUtIKpq #52cups",
    "id" : 420940442122076160,
    "created_at" : "2014-01-08 15:29:56 +0000",
    "user" : {
      "name" : "megan gebhart",
      "screen_name" : "megangebhart",
      "protected" : false,
      "id_str" : "32966836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2954262620\/74d96d552974676eb198edfd2b04ea76_normal.jpeg",
      "id" : 32966836,
      "verified" : false
    }
  },
  "id" : 420942166295199744,
  "created_at" : "2014-01-08 15:36:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/CawEKwoUYG",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?feature=youtube_gdata_player&v=0EyfEDKWscg&desktop_uri=%2Fwatch%3Fv%3D0EyfEDKWscg%26feature%3Dyoutube_gdata_player",
      "display_url" : "m.youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596218955, -122.2754571029 ]
  },
  "id_str" : "420817754480865280",
  "text" : "I'm going to have nightmares about ice tsunamis http:\/\/t.co\/CawEKwoUYG",
  "id" : 420817754480865280,
  "created_at" : "2014-01-08 07:22:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/S1cCNtyMZg",
      "expanded_url" : "http:\/\/flic.kr\/p\/j2uWGL",
      "display_url" : "flic.kr\/p\/j2uWGL"
    } ]
  },
  "geo" : { },
  "id_str" : "420778671075770368",
  "text" : "8:36pm \"I have to go to bed because it's 8:36.\" http:\/\/t.co\/S1cCNtyMZg",
  "id" : 420778671075770368,
  "created_at" : "2014-01-08 04:47:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 5, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78017025, -122.41347473 ]
  },
  "id_str" : "420743721374580736",
  "text" : "I \u2764\uFE0F #hackweek.",
  "id" : 420743721374580736,
  "created_at" : "2014-01-08 02:28:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Weil",
      "screen_name" : "kevinweil",
      "indices" : [ 0, 10 ],
      "id_str" : "3452911",
      "id" : 3452911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420461089034235904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8581906773, -122.2723375761 ]
  },
  "id_str" : "420465718224646144",
  "in_reply_to_user_id" : 3452911,
  "text" : "@kevinweil Just doing them every day will be better than worrying about how many. I'll add them up by month and try to beat previous month.",
  "id" : 420465718224646144,
  "in_reply_to_status_id" : 420461089034235904,
  "created_at" : "2014-01-07 08:03:33 +0000",
  "in_reply_to_screen_name" : "kevinweil",
  "in_reply_to_user_id_str" : "3452911",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/vdmKmTI3Lq",
      "expanded_url" : "http:\/\/everydayfortherestofmylife.com\/i-will\/do-pushups\/67",
      "display_url" : "everydayfortherestofmylife.com\/i-will\/do-push\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420456100563914752",
  "text" : "I want to do pushups every day for the rest of my life. http:\/\/t.co\/vdmKmTI3Lq",
  "id" : 420456100563914752,
  "created_at" : "2014-01-07 07:25:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/420426663688564737\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/E3idzxw6dZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdWn0qtCIAAi1fC.jpg",
      "id_str" : "420426663487217664",
      "id" : 420426663487217664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdWn0qtCIAAi1fC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/E3idzxw6dZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597206343, -122.2754105834 ]
  },
  "id_str" : "420426663688564737",
  "text" : "8:36pm Surgery-recovering wife, day 4: she made it downstairs edition http:\/\/t.co\/E3idzxw6dZ",
  "id" : 420426663688564737,
  "created_at" : "2014-01-07 05:28:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    }, {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 10, 21 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 22, 31 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420409157754179584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597518569, -122.2755301931 ]
  },
  "id_str" : "420419563688185859",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie @waxpancake @anildash QuizUp needs a \"replay game\" option where we can watch the game unfold as if it were happening in real time.",
  "id" : 420419563688185859,
  "in_reply_to_status_id" : 420409157754179584,
  "created_at" : "2014-01-07 05:00:09 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hyped up aka popular",
      "screen_name" : "iano",
      "indices" : [ 0, 5 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420405721780744192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596883221, -122.2754598689 ]
  },
  "id_str" : "420418634528223232",
  "in_reply_to_user_id" : 14409856,
  "text" : "@iano Something to do with magnets.",
  "id" : 420418634528223232,
  "in_reply_to_status_id" : 420405721780744192,
  "created_at" : "2014-01-07 04:56:28 +0000",
  "in_reply_to_screen_name" : "iano",
  "in_reply_to_user_id_str" : "14409856",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    }, {
      "name" : "A Fitter Twitter",
      "screen_name" : "FitterTwitter",
      "indices" : [ 4, 18 ],
      "id_str" : "1160842776",
      "id" : 1160842776
    }, {
      "name" : "DietBet",
      "screen_name" : "DietBet",
      "indices" : [ 60, 68 ],
      "id_str" : "185399301",
      "id" : 185399301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420401648846905344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597130487, -122.2754471285 ]
  },
  "id_str" : "420418418680934400",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm @FitterTwitter You should make it official and set up a @dietbet. If you do I'll join!",
  "id" : 420418418680934400,
  "in_reply_to_status_id" : 420401648846905344,
  "created_at" : "2014-01-07 04:55:36 +0000",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriemTeam",
      "screen_name" : "TriemTeam",
      "indices" : [ 0, 10 ],
      "id_str" : "24792603",
      "id" : 24792603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420366788447047680",
  "geo" : { },
  "id_str" : "420368743638659073",
  "in_reply_to_user_id" : 24792603,
  "text" : "@triemteam Yeah, probably. Mostly just saying I'm curious to know the answer myself.",
  "id" : 420368743638659073,
  "in_reply_to_status_id" : 420366788447047680,
  "created_at" : "2014-01-07 01:38:13 +0000",
  "in_reply_to_screen_name" : "TriemTeam",
  "in_reply_to_user_id_str" : "24792603",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriemTeam",
      "screen_name" : "TriemTeam",
      "indices" : [ 0, 10 ],
      "id_str" : "24792603",
      "id" : 24792603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420363050021961728",
  "geo" : { },
  "id_str" : "420366584083804160",
  "in_reply_to_user_id" : 24792603,
  "text" : "@triemteam I think this describes all parents of 3 year olds.",
  "id" : 420366584083804160,
  "in_reply_to_status_id" : 420363050021961728,
  "created_at" : "2014-01-07 01:29:38 +0000",
  "in_reply_to_screen_name" : "TriemTeam",
  "in_reply_to_user_id_str" : "24792603",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 0, 6 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420340982794575872",
  "geo" : { },
  "id_str" : "420342519235215360",
  "in_reply_to_user_id" : 631823,
  "text" : "@couch Hahahahah!",
  "id" : 420342519235215360,
  "in_reply_to_status_id" : 420340982794575872,
  "created_at" : "2014-01-06 23:54:00 +0000",
  "in_reply_to_screen_name" : "couch",
  "in_reply_to_user_id_str" : "631823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Rohling",
      "screen_name" : "kevinrohling",
      "indices" : [ 3, 16 ],
      "id_str" : "15679828",
      "id" : 15679828
    }, {
      "name" : "HandUp",
      "screen_name" : "HandUp",
      "indices" : [ 116, 123 ],
      "id_str" : "1529033432",
      "id" : 1529033432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/SKmARGCSw2",
      "expanded_url" : "https:\/\/handup.us\/",
      "display_url" : "handup.us"
    } ]
  },
  "geo" : { },
  "id_str" : "420114911239217153",
  "text" : "RT @kevinrohling: If you've ever passed a homeless person in SF and wondered \"how can I help?\" you should donate to @HandUp https:\/\/t.co\/SK\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HandUp",
        "screen_name" : "HandUp",
        "indices" : [ 98, 105 ],
        "id_str" : "1529033432",
        "id" : 1529033432
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/SKmARGCSw2",
        "expanded_url" : "https:\/\/handup.us\/",
        "display_url" : "handup.us"
      } ]
    },
    "geo" : { },
    "id_str" : "419964361562537984",
    "text" : "If you've ever passed a homeless person in SF and wondered \"how can I help?\" you should donate to @HandUp https:\/\/t.co\/SKmARGCSw2",
    "id" : 419964361562537984,
    "created_at" : "2014-01-05 22:51:21 +0000",
    "user" : {
      "name" : "Kevin Rohling",
      "screen_name" : "kevinrohling",
      "protected" : false,
      "id_str" : "15679828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000401905806\/29af516d6500dd623ca45867d02b1fa5_normal.jpeg",
      "id" : 15679828,
      "verified" : false
    }
  },
  "id" : 420114911239217153,
  "created_at" : "2014-01-06 08:49:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    }, {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 14, 25 ],
      "id_str" : "652193",
      "id" : 652193
    }, {
      "name" : "Chartbeat",
      "screen_name" : "Chartbeat",
      "indices" : [ 26, 36 ],
      "id_str" : "16916881",
      "id" : 16916881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420088514399588352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596112924, -122.2755101604 ]
  },
  "id_str" : "420114653297905664",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel @parislemon @Chartbeat That makes sense, I was addicted to that when I had a product site. Still love them.",
  "id" : 420114653297905664,
  "in_reply_to_status_id" : 420088514399588352,
  "created_at" : "2014-01-06 08:48:33 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 64, 75 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/H92Dprluhf",
      "expanded_url" : "http:\/\/parislemon.com\/post\/72415950189\/the-first-app-you-open-in-the-morning",
      "display_url" : "parislemon.com\/post\/724159501\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "420084262214197248",
  "geo" : { },
  "id_str" : "420085221971615745",
  "in_reply_to_user_id" : 652193,
  "text" : "At first I thought Twitter but it's actually my lock screen. RT @parislemon: The First App You Open In The Morning http:\/\/t.co\/H92Dprluhf",
  "id" : 420085221971615745,
  "in_reply_to_status_id" : 420084262214197248,
  "created_at" : "2014-01-06 06:51:36 +0000",
  "in_reply_to_screen_name" : "parislemon",
  "in_reply_to_user_id_str" : "652193",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/420054400405495809\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/QrZWxqqiJm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdRVQFwCcAAJCHa.jpg",
      "id_str" : "420054400162230272",
      "id" : 420054400162230272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdRVQFwCcAAJCHa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/QrZWxqqiJm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597557964, -122.2754944024 ]
  },
  "id_str" : "420054400405495809",
  "text" : "8:36pm Bath with bubbles and chocolate and pink bracelets http:\/\/t.co\/QrZWxqqiJm",
  "id" : 420054400405495809,
  "created_at" : "2014-01-06 04:49:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Explore",
      "screen_name" : "Explorer",
      "indices" : [ 3, 12 ],
      "id_str" : "498328279",
      "id" : 498328279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/avTEtabGIu",
      "expanded_url" : "http:\/\/j.mp\/1i8JpSC",
      "display_url" : "j.mp\/1i8JpSC"
    } ]
  },
  "geo" : { },
  "id_str" : "420036797544947714",
  "text" : "RT @Explorer: Where different emotions are felt in the body \u2013 amazing visualization http:\/\/t.co\/avTEtabGIu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/avTEtabGIu",
        "expanded_url" : "http:\/\/j.mp\/1i8JpSC",
        "display_url" : "j.mp\/1i8JpSC"
      } ]
    },
    "geo" : { },
    "id_str" : "420036515029610496",
    "text" : "Where different emotions are felt in the body \u2013 amazing visualization http:\/\/t.co\/avTEtabGIu",
    "id" : 420036515029610496,
    "created_at" : "2014-01-06 03:38:03 +0000",
    "user" : {
      "name" : "Explore",
      "screen_name" : "Explorer",
      "protected" : false,
      "id_str" : "498328279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2170469012\/twitter_avatar_r_normal.png",
      "id" : 498328279,
      "verified" : false
    }
  },
  "id" : 420036797544947714,
  "created_at" : "2014-01-06 03:39:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 7, 16 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420034574681251842",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597461991, -122.2755311151 ]
  },
  "id_str" : "420035917986803714",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc @RickWebb I have but the precise but inaccurate nature of calorie tracking makes my brain explode.",
  "id" : 420035917986803714,
  "in_reply_to_status_id" : 420034574681251842,
  "created_at" : "2014-01-06 03:35:41 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fuck Tony Womack",
      "screen_name" : "FuckTonyWomack",
      "indices" : [ 3, 18 ],
      "id_str" : "333007732",
      "id" : 333007732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/4muyzjrM3Q",
      "expanded_url" : "http:\/\/vine.co\/v\/hYJQOuijWU2",
      "display_url" : "vine.co\/v\/hYJQOuijWU2"
    } ]
  },
  "geo" : { },
  "id_str" : "420007196500307968",
  "text" : "RT @FuckTonyWomack: guys, shut it down. someone won vine: http:\/\/t.co\/4muyzjrM3Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/4muyzjrM3Q",
        "expanded_url" : "http:\/\/vine.co\/v\/hYJQOuijWU2",
        "display_url" : "vine.co\/v\/hYJQOuijWU2"
      } ]
    },
    "geo" : { },
    "id_str" : "419862433432236032",
    "text" : "guys, shut it down. someone won vine: http:\/\/t.co\/4muyzjrM3Q",
    "id" : 419862433432236032,
    "created_at" : "2014-01-05 16:06:19 +0000",
    "user" : {
      "name" : "Fuck Tony Womack",
      "screen_name" : "FuckTonyWomack",
      "protected" : false,
      "id_str" : "333007732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447283592901582848\/4ijJvaKc_normal.jpeg",
      "id" : 333007732,
      "verified" : false
    }
  },
  "id" : 420007196500307968,
  "created_at" : "2014-01-06 01:41:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420004077758861312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597197123, -122.2754600366 ]
  },
  "id_str" : "420005636240203776",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs What they ordered next will amaze you.",
  "id" : 420005636240203776,
  "in_reply_to_status_id" : 420004077758861312,
  "created_at" : "2014-01-06 01:35:21 +0000",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "DietBet",
      "screen_name" : "DietBet",
      "indices" : [ 10, 18 ],
      "id_str" : "185399301",
      "id" : 185399301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420004689464549376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597197123, -122.2754600366 ]
  },
  "id_str" : "420005302893682688",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @DietBet I've used it twice and like it when there's a small group to play with. Check it out and send me a link if you like it!",
  "id" : 420005302893682688,
  "in_reply_to_status_id" : 420004689464549376,
  "created_at" : "2014-01-06 01:34:02 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "DietBet",
      "screen_name" : "DietBet",
      "indices" : [ 61, 69 ],
      "id_str" : "185399301",
      "id" : 185399301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420001466120949760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597197123, -122.2754600366 ]
  },
  "id_str" : "420003672219586561",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Same bat time, same health month rules? Wanna play @dietbet?",
  "id" : 420003672219586561,
  "in_reply_to_status_id" : 420001466120949760,
  "created_at" : "2014-01-06 01:27:33 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419995720834232320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597197123, -122.2754600366 ]
  },
  "id_str" : "420003043204034560",
  "in_reply_to_user_id" : 2185,
  "text" : "Part of the problem is that a notification's \"welcomeness\" is difficult to deduce from the data. Using engagement as proxy gets us Upworthy.",
  "id" : 420003043204034560,
  "in_reply_to_status_id" : 419995720834232320,
  "created_at" : "2014-01-06 01:25:03 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Brumback",
      "screen_name" : "Boomer",
      "indices" : [ 0, 7 ],
      "id_str" : "30693",
      "id" : 30693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419999721105534976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596907528, -122.2755275109 ]
  },
  "id_str" : "420001808744857601",
  "in_reply_to_user_id" : 30693,
  "text" : "@Boomer Even with all that context it'll take some time to use it correctly, don't you think?",
  "id" : 420001808744857601,
  "in_reply_to_status_id" : 419999721105534976,
  "created_at" : "2014-01-06 01:20:09 +0000",
  "in_reply_to_screen_name" : "Boomer",
  "in_reply_to_user_id_str" : "30693",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prashant S",
      "screen_name" : "CoolAssPuppy",
      "indices" : [ 0, 13 ],
      "id_str" : "2881611",
      "id" : 2881611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419997580248879104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597255797, -122.2754756269 ]
  },
  "id_str" : "419998229803978752",
  "in_reply_to_user_id" : 2881611,
  "text" : "@CoolAssPuppy Cool! Would love to hear them.",
  "id" : 419998229803978752,
  "in_reply_to_status_id" : 419997580248879104,
  "created_at" : "2014-01-06 01:05:55 +0000",
  "in_reply_to_screen_name" : "CoolAssPuppy",
  "in_reply_to_user_id_str" : "2881611",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419992323770966016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597255797, -122.2754756269 ]
  },
  "id_str" : "419995720834232320",
  "in_reply_to_user_id" : 2185,
  "text" : "I do think the technology to *deliver* notifications to us is greatly outpacing our ability to generate *welcome* notifications.",
  "id" : 419995720834232320,
  "in_reply_to_status_id" : 419992323770966016,
  "created_at" : "2014-01-06 00:55:57 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kit",
      "indices" : [ 122, 126 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419987097894649856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597241966, -122.2754680832 ]
  },
  "id_str" : "419992323770966016",
  "in_reply_to_user_id" : 2185,
  "text" : "My guess: simpler, more focused, version of Foursquare passive recs and Google Now. Plus Siri-powered Uber app of course. #kit",
  "id" : 419992323770966016,
  "in_reply_to_status_id" : 419987097894649856,
  "created_at" : "2014-01-06 00:42:27 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419991157331222528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597241966, -122.2754680832 ]
  },
  "id_str" : "419991707912921088",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Your next startup should build the killer smartwatch app on the Foursquare API. :)",
  "id" : 419991707912921088,
  "in_reply_to_status_id" : 419991157331222528,
  "created_at" : "2014-01-06 00:40:00 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Jacobs",
      "screen_name" : "jjacobs22",
      "indices" : [ 0, 10 ],
      "id_str" : "14850356",
      "id" : 14850356
    }, {
      "name" : "Fareed Mosavat",
      "screen_name" : "far33d",
      "indices" : [ 11, 18 ],
      "id_str" : "1264641",
      "id" : 1264641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419990274748604416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597294353, -122.2754624673 ]
  },
  "id_str" : "419991056306814976",
  "in_reply_to_user_id" : 14850356,
  "text" : "@jjacobs22 @far33d Wristbands seem to me to have already explored the most obvious use cases but give me a hint if I'm missing something!",
  "id" : 419991056306814976,
  "in_reply_to_status_id" : 419990274748604416,
  "created_at" : "2014-01-06 00:37:25 +0000",
  "in_reply_to_screen_name" : "jjacobs22",
  "in_reply_to_user_id_str" : "14850356",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419989036909203456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597088578, -122.2754757946 ]
  },
  "id_str" : "419990229248770048",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Foursquare Radar and Google Now are top contenders in my mind. I think post-smartphone is going to be a thing relatively soon.",
  "id" : 419990229248770048,
  "in_reply_to_status_id" : 419989036909203456,
  "created_at" : "2014-01-06 00:34:08 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Tringas",
      "screen_name" : "tylertringas",
      "indices" : [ 0, 13 ],
      "id_str" : "33353061",
      "id" : 33353061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419988342898708480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597088578, -122.2754757946 ]
  },
  "id_str" : "419989699592060929",
  "in_reply_to_user_id" : 33353061,
  "text" : "@tylertringas For checking in our passive recommendations? The latter could be possible.",
  "id" : 419989699592060929,
  "in_reply_to_status_id" : 419988342898708480,
  "created_at" : "2014-01-06 00:32:02 +0000",
  "in_reply_to_screen_name" : "tylertringas",
  "in_reply_to_user_id_str" : "33353061",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419988837545172992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596936803, -122.2749337378 ]
  },
  "id_str" : "419989470398533633",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm Those are good but do we really feel that removed from the info already in our pockets?",
  "id" : 419989470398533633,
  "in_reply_to_status_id" : 419988837545172992,
  "created_at" : "2014-01-06 00:31:07 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fareed Mosavat",
      "screen_name" : "far33d",
      "indices" : [ 0, 7 ],
      "id_str" : "1264641",
      "id" : 1264641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419987263481589760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596936803, -122.2749337378 ]
  },
  "id_str" : "419989083872448512",
  "in_reply_to_user_id" : 1264641,
  "text" : "@far33d Could be, but activity tracking still needs to solve its user retention problem.",
  "id" : 419989083872448512,
  "in_reply_to_status_id" : 419987263481589760,
  "created_at" : "2014-01-06 00:29:35 +0000",
  "in_reply_to_screen_name" : "far33d",
  "in_reply_to_user_id_str" : "1264641",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "predictions",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596936803, -122.2749337378 ]
  },
  "id_str" : "419987097894649856",
  "text" : "What will the first killer app for smart watches be? Who will make it? Will it be an app ported from iPhone or something new? #predictions",
  "id" : 419987097894649856,
  "created_at" : "2014-01-06 00:21:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/YAKAv6vZfd",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1Evwgu369Jw",
      "display_url" : "youtube.com\/watch?v=1Evwgu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419965436088680448",
  "text" : "On empathy: \"The truth is, rarely can a response make something better \u2014 what makes something better is connection.\" http:\/\/t.co\/YAKAv6vZfd",
  "id" : 419965436088680448,
  "created_at" : "2014-01-05 22:55:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/wLY13EY998",
      "expanded_url" : "https:\/\/medium.com\/tech-talk\/d823af31f7c",
      "display_url" : "medium.com\/tech-talk\/d823\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419961720019251200",
  "text" : "LiveJournal is to web publishing\/blogs\/Twitter as Danger is to mobile computers\/iPhone\/Android. Long live Danger! https:\/\/t.co\/wLY13EY998",
  "id" : 419961720019251200,
  "created_at" : "2014-01-05 22:40:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocio",
      "screen_name" : "rokkzy",
      "indices" : [ 3, 10 ],
      "id_str" : "19153571",
      "id" : 19153571
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 12, 19 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Crystal Beasley",
      "screen_name" : "skinny",
      "indices" : [ 20, 27 ],
      "id_str" : "5749142",
      "id" : 5749142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "myNerdStory",
      "indices" : [ 28, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/xaRym8rGCQ",
      "expanded_url" : "http:\/\/skinnywhitegirl.com\/blog\/my-nerd-story\/1101\/",
      "display_url" : "skinnywhitegirl.com\/blog\/my-nerd-s\u2026"
    }, {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/5KWDL2Vjly",
      "expanded_url" : "http:\/\/roxi.io\/day\/2014\/01\/05",
      "display_url" : "roxi.io\/day\/2014\/01\/05"
    } ]
  },
  "geo" : { },
  "id_str" : "419929890423463936",
  "text" : "RT @rokkzy: @buster @skinny #myNerdStory http:\/\/t.co\/xaRym8rGCQ Great inspiration. http:\/\/t.co\/5KWDL2Vjly",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      }, {
        "name" : "Crystal Beasley",
        "screen_name" : "skinny",
        "indices" : [ 8, 15 ],
        "id_str" : "5749142",
        "id" : 5749142
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "myNerdStory",
        "indices" : [ 16, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/xaRym8rGCQ",
        "expanded_url" : "http:\/\/skinnywhitegirl.com\/blog\/my-nerd-story\/1101\/",
        "display_url" : "skinnywhitegirl.com\/blog\/my-nerd-s\u2026"
      }, {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/5KWDL2Vjly",
        "expanded_url" : "http:\/\/roxi.io\/day\/2014\/01\/05",
        "display_url" : "roxi.io\/day\/2014\/01\/05"
      } ]
    },
    "in_reply_to_status_id_str" : "419894017367605248",
    "geo" : { },
    "id_str" : "419924449714909184",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster @skinny #myNerdStory http:\/\/t.co\/xaRym8rGCQ Great inspiration. http:\/\/t.co\/5KWDL2Vjly",
    "id" : 419924449714909184,
    "in_reply_to_status_id" : 419894017367605248,
    "created_at" : "2014-01-05 20:12:45 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Rocio",
      "screen_name" : "rokkzy",
      "protected" : false,
      "id_str" : "19153571",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000708449963\/53cab0927bc83d8f56ef7a9b9091898d_normal.jpeg",
      "id" : 19153571,
      "verified" : false
    }
  },
  "id" : 419929890423463936,
  "created_at" : "2014-01-05 20:34:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419900966620512256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8601355804, -122.2802347039 ]
  },
  "id_str" : "419903920324886528",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel It's not their fault that there were no calls during the first 14 billion years of the universe. This is a giant anomaly.",
  "id" : 419903920324886528,
  "in_reply_to_status_id" : 419900966620512256,
  "created_at" : "2014-01-05 18:51:10 +0000",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419895916334575616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8614416619, -122.2804649138 ]
  },
  "id_str" : "419897200366215168",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel Maybe they're averaging it out across all time.",
  "id" : 419897200366215168,
  "in_reply_to_status_id" : 419895916334575616,
  "created_at" : "2014-01-05 18:24:28 +0000",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crystal Beasley",
      "screen_name" : "skinny",
      "indices" : [ 94, 101 ],
      "id_str" : "5749142",
      "id" : 5749142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mynerdstory",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/0NgrbsaM2L",
      "expanded_url" : "http:\/\/skinnywhitegirl.com\/blog\/my-nerd-story\/1101\/",
      "display_url" : "skinnywhitegirl.com\/blog\/my-nerd-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419894017367605248",
  "text" : "\"If you\u2019re a woman, write up your nerd origins and share it with the hashtag #mynerdstory.\" - @skinny Her story: http:\/\/t.co\/0NgrbsaM2L",
  "id" : 419894017367605248,
  "created_at" : "2014-01-05 18:11:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Geist",
      "screen_name" : "dalehgeist",
      "indices" : [ 0, 11 ],
      "id_str" : "281744819",
      "id" : 281744819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419882724279586816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596534534, -122.2756037024 ]
  },
  "id_str" : "419883283812347905",
  "in_reply_to_user_id" : 281744819,
  "text" : "@dalehgeist The current phase of tech might but I think it's quickly beginning to be more balanced with sensors, wearables, etc.",
  "id" : 419883283812347905,
  "in_reply_to_status_id" : 419882724279586816,
  "created_at" : "2014-01-05 17:29:10 +0000",
  "in_reply_to_screen_name" : "dalehgeist",
  "in_reply_to_user_id_str" : "281744819",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419876221887868928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597431397, -122.2754865234 ]
  },
  "id_str" : "419882457794494464",
  "in_reply_to_user_id" : 2185,
  "text" : "Oops that's actually a version of a quote by HL Mencken about the role of journalists. And he got it from Finley Peter Dunne RE newspapers.",
  "id" : 419882457794494464,
  "in_reply_to_status_id" : 419876221887868928,
  "created_at" : "2014-01-05 17:25:53 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/gQF7KySaqj",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Finley_Peter_Dunne",
      "display_url" : "en.m.wikipedia.org\/wiki\/Finley_Pe\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "419877699314659328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596979613, -122.2755180394 ]
  },
  "id_str" : "419881571470950400",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Actually looks like even he borrowed it from Finley Peter Dunne! http:\/\/t.co\/gQF7KySaqj",
  "id" : 419881571470950400,
  "in_reply_to_status_id" : 419877699314659328,
  "created_at" : "2014-01-05 17:22:22 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Elman",
      "screen_name" : "joshelman",
      "indices" : [ 0, 10 ],
      "id_str" : "1979921",
      "id" : 1979921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419878726537465856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597210534, -122.2754758784 ]
  },
  "id_str" : "419880272872480769",
  "in_reply_to_user_id" : 2185,
  "text" : "@joshelman On the other hand tech and phone can help facilitate quality time\/attention with self, people, interests.",
  "id" : 419880272872480769,
  "in_reply_to_status_id" : 419878726537465856,
  "created_at" : "2014-01-05 17:17:12 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419877699314659328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597156052, -122.275541844 ]
  },
  "id_str" : "419879182735130624",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Banksy totally stole that!",
  "id" : 419879182735130624,
  "in_reply_to_status_id" : 419877699314659328,
  "created_at" : "2014-01-05 17:12:52 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Elman",
      "screen_name" : "joshelman",
      "indices" : [ 0, 10 ],
      "id_str" : "1979921",
      "id" : 1979921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419479643331125248",
  "geo" : { },
  "id_str" : "419878726537465856",
  "in_reply_to_user_id" : 1979921,
  "text" : "@joshelman Great post! What do you think about attention as prereq for quality time w\/ self, people, interests? Can't have that w\/phone.",
  "id" : 419878726537465856,
  "in_reply_to_status_id" : 419479643331125248,
  "created_at" : "2014-01-05 17:11:04 +0000",
  "in_reply_to_screen_name" : "joshelman",
  "in_reply_to_user_id_str" : "1979921",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "banksy",
      "screen_name" : "banksyny",
      "indices" : [ 66, 75 ],
      "id_str" : "1924391640",
      "id" : 1924391640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859674953, -122.2756258306 ]
  },
  "id_str" : "419876221887868928",
  "text" : "\"Art should comfort the disturbed and disturb the comfortable.\" - @banksyny",
  "id" : 419876221887868928,
  "created_at" : "2014-01-05 17:01:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Wilson",
      "screen_name" : "fredwilson",
      "indices" : [ 3, 14 ],
      "id_str" : "1000591",
      "id" : 1000591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/jo42u51RrC",
      "expanded_url" : "http:\/\/www.avc.com\/a_vc\/2014\/01\/a-couple-trips-to-the-future.html",
      "display_url" : "avc.com\/a_vc\/2014\/01\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419875472395104256",
  "text" : "RT @fredwilson: A Couple Trips To The Future http:\/\/t.co\/jo42u51RrC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/jo42u51RrC",
        "expanded_url" : "http:\/\/www.avc.com\/a_vc\/2014\/01\/a-couple-trips-to-the-future.html",
        "display_url" : "avc.com\/a_vc\/2014\/01\/a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "419853678065905664",
    "text" : "A Couple Trips To The Future http:\/\/t.co\/jo42u51RrC",
    "id" : 419853678065905664,
    "created_at" : "2014-01-05 15:31:32 +0000",
    "user" : {
      "name" : "Fred Wilson",
      "screen_name" : "fredwilson",
      "protected" : false,
      "id_str" : "1000591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3580641456\/82c873940343750638b7caa04b4652fe_normal.jpeg",
      "id" : 1000591,
      "verified" : true
    }
  },
  "id" : 419875472395104256,
  "created_at" : "2014-01-05 16:58:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419743203852427264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859701356, -122.2755876092 ]
  },
  "id_str" : "419747970116890625",
  "in_reply_to_user_id" : 2185,
  "text" : "Where quality time is with yourself, with people you connect with, and with interests you connect with. And tech can help!",
  "id" : 419747970116890625,
  "in_reply_to_status_id" : 419743203852427264,
  "created_at" : "2014-01-05 08:31:29 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419741942319046656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597107437, -122.2754523252 ]
  },
  "id_str" : "419743203852427264",
  "in_reply_to_user_id" : 2185,
  "text" : "My hope: we start to adjust to this new world of constantly streaming information and become more proactive about making quality time.",
  "id" : 419743203852427264,
  "in_reply_to_status_id" : 419741942319046656,
  "created_at" : "2014-01-05 08:12:32 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 102, 113 ],
      "id_str" : "3452941",
      "id" : 3452941
    }, {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "indices" : [ 119, 130 ],
      "id_str" : "8070502",
      "id" : 8070502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/sezuzCwBdP",
      "expanded_url" : "http:\/\/blogs.seattletimes.com\/monica-guzman\/2014\/01\/04\/seattle-tech-leaders-share-their-hopes-for-2014\/",
      "display_url" : "blogs.seattletimes.com\/monica-guzman\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85978556, -122.2738051 ]
  },
  "id_str" : "419741942319046656",
  "text" : "What's your hope for tech in 2014? Seattle tech leaders share their hopes: http:\/\/t.co\/sezuzCwBdP \/by @moniguzman \/via @danshapiro",
  "id" : 419741942319046656,
  "created_at" : "2014-01-05 08:07:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 0, 7 ],
      "id_str" : "47",
      "id" : 47
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419665047712190464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85978556, -122.2738051 ]
  },
  "id_str" : "419739039520931840",
  "in_reply_to_user_id" : 47,
  "text" : "@kellan Super exciting! Congrats!",
  "id" : 419739039520931840,
  "in_reply_to_status_id" : 419665047712190464,
  "created_at" : "2014-01-05 07:56:00 +0000",
  "in_reply_to_screen_name" : "kellan",
  "in_reply_to_user_id_str" : "47",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419722856360984576",
  "geo" : { },
  "id_str" : "419723748363599872",
  "in_reply_to_user_id" : 123116307,
  "text" : "@lilhossler Friend me on roku if that's a thing!",
  "id" : 419723748363599872,
  "in_reply_to_status_id" : 419722856360984576,
  "created_at" : "2014-01-05 06:55:14 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiffany Dohzen",
      "screen_name" : "tdohz",
      "indices" : [ 0, 6 ],
      "id_str" : "101424163",
      "id" : 101424163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419694585518895105",
  "geo" : { },
  "id_str" : "419694733972099074",
  "in_reply_to_user_id" : 101424163,
  "text" : "@tdohz Yeah, I probably will. Google's good at shipping stuff\u2026 I'm sure it will start catching up pretty quickly.",
  "id" : 419694733972099074,
  "in_reply_to_status_id" : 419694585518895105,
  "created_at" : "2014-01-05 04:59:56 +0000",
  "in_reply_to_screen_name" : "tdohz",
  "in_reply_to_user_id_str" : "101424163",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiffany Dohzen",
      "screen_name" : "tdohz",
      "indices" : [ 0, 6 ],
      "id_str" : "101424163",
      "id" : 101424163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/FeBo6jdZzs",
      "expanded_url" : "http:\/\/blog.roku.com\/blog\/2013\/12\/17\/introducing-youtube-on-roku-3\/",
      "display_url" : "blog.roku.com\/blog\/2013\/12\/1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "419693420899094528",
  "geo" : { },
  "id_str" : "419693817088839682",
  "in_reply_to_user_id" : 101424163,
  "text" : "@tdohz Looks like they just added YouTube last month: http:\/\/t.co\/FeBo6jdZzs",
  "id" : 419693817088839682,
  "in_reply_to_status_id" : 419693420899094528,
  "created_at" : "2014-01-05 04:56:18 +0000",
  "in_reply_to_screen_name" : "tdohz",
  "in_reply_to_user_id_str" : "101424163",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/t5L5pMrFTf",
      "expanded_url" : "http:\/\/flic.kr\/p\/iVVVXf",
      "display_url" : "flic.kr\/p\/iVVVXf"
    } ]
  },
  "geo" : { },
  "id_str" : "419693353811607552",
  "text" : "8:36pm I think the Roku 3 won out after all. Thanks for the info, everyone. http:\/\/t.co\/t5L5pMrFTf",
  "id" : 419693353811607552,
  "created_at" : "2014-01-05 04:54:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Webster",
      "screen_name" : "webster",
      "indices" : [ 0, 8 ],
      "id_str" : "7632132",
      "id" : 7632132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419686164954484736",
  "geo" : { },
  "id_str" : "419686356592254976",
  "in_reply_to_user_id" : 7632132,
  "text" : "@webster What do you like better about it?",
  "id" : 419686356592254976,
  "in_reply_to_status_id" : 419686164954484736,
  "created_at" : "2014-01-05 04:26:39 +0000",
  "in_reply_to_screen_name" : "webster",
  "in_reply_to_user_id_str" : "7632132",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419685964500307969",
  "text" : "Does anyone like the Chromecast, Roku 3, or something else more than the Apple TV?",
  "id" : 419685964500307969,
  "created_at" : "2014-01-05 04:25:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 0, 6 ],
      "id_str" : "8285392",
      "id" : 8285392
    }, {
      "name" : "hyped up aka popular",
      "screen_name" : "iano",
      "indices" : [ 7, 12 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419685123357831168",
  "geo" : { },
  "id_str" : "419685702331162624",
  "in_reply_to_user_id" : 8285392,
  "text" : "@raffi @iano Yeah after researching a bit more I'm leaning towards Apple TV now too. Your rec probably put me over the edge.",
  "id" : 419685702331162624,
  "in_reply_to_status_id" : 419685123357831168,
  "created_at" : "2014-01-05 04:24:03 +0000",
  "in_reply_to_screen_name" : "raffi",
  "in_reply_to_user_id_str" : "8285392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    }, {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 8, 13 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419683539450216448",
  "geo" : { },
  "id_str" : "419683938219458560",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim @jfew Ah. Note that I haven't had a TV for a million years and have never used TiVo, Roku, Xbox, or any of those things\u2026",
  "id" : 419683938219458560,
  "in_reply_to_status_id" : 419683539450216448,
  "created_at" : "2014-01-05 04:17:02 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hyped up aka popular",
      "screen_name" : "iano",
      "indices" : [ 0, 5 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419682358884044800",
  "geo" : { },
  "id_str" : "419683176517087232",
  "in_reply_to_user_id" : 14409856,
  "text" : "@iano So if I already have an iMac in the room, it's not really going to do much that it couldn't do.",
  "id" : 419683176517087232,
  "in_reply_to_status_id" : 419682358884044800,
  "created_at" : "2014-01-05 04:14:01 +0000",
  "in_reply_to_screen_name" : "iano",
  "in_reply_to_user_id_str" : "14409856",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Trommetter",
      "screen_name" : "jasontromm",
      "indices" : [ 0, 11 ],
      "id_str" : "823748",
      "id" : 823748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419682449577095169",
  "geo" : { },
  "id_str" : "419682671908765696",
  "in_reply_to_user_id" : 823748,
  "text" : "@jasontromm Other than Netflix, Hulu, YouTube (which lots of TVs support by default) what are the best apps?",
  "id" : 419682671908765696,
  "in_reply_to_status_id" : 419682449577095169,
  "created_at" : "2014-01-05 04:12:00 +0000",
  "in_reply_to_screen_name" : "jasontromm",
  "in_reply_to_user_id_str" : "823748",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419682199277805570",
  "text" : "Is anyone using Chromecast? What's good\/bad about it?",
  "id" : 419682199277805570,
  "created_at" : "2014-01-05 04:10:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 0, 6 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419660141391142912",
  "in_reply_to_user_id" : 75079616,
  "text" : "@IFTTT I\u2019m messing around with your SMS to Google Spreadsheet recipe and rows only update every 2nd or 3rd try. Known issue?",
  "id" : 419660141391142912,
  "created_at" : "2014-01-05 02:42:29 +0000",
  "in_reply_to_screen_name" : "IFTTT",
  "in_reply_to_user_id_str" : "75079616",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/419598546770210817\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/UDQJ1YQ9Bq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdK2p7HCQAApZTP.jpg",
      "id_str" : "419598546656968704",
      "id" : 419598546656968704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdK2p7HCQAApZTP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/UDQJ1YQ9Bq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8276758808, -122.2868488975 ]
  },
  "id_str" : "419598546770210817",
  "text" : "Niko helps me buy a tv at Best Buy http:\/\/t.co\/UDQJ1YQ9Bq",
  "id" : 419598546770210817,
  "created_at" : "2014-01-04 22:37:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419547750414684160",
  "geo" : { },
  "id_str" : "419565165634273280",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Themes are silly on Tumblr. Everyone interacts via the dashboard anyway.",
  "id" : 419565165634273280,
  "in_reply_to_status_id" : 419547750414684160,
  "created_at" : "2014-01-04 20:25:05 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Serotta",
      "screen_name" : "beforesunrise",
      "indices" : [ 0, 14 ],
      "id_str" : "11696",
      "id" : 11696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419558384061657088",
  "geo" : { },
  "id_str" : "419558736445714433",
  "in_reply_to_user_id" : 11696,
  "text" : "@beforesunrise I can't find any 240hz options at the 40\" (or lower) screen size. Also needs to be slim and wall-mountable.",
  "id" : 419558736445714433,
  "in_reply_to_status_id" : 419558384061657088,
  "created_at" : "2014-01-04 19:59:32 +0000",
  "in_reply_to_screen_name" : "beforesunrise",
  "in_reply_to_user_id_str" : "11696",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Seitz",
      "screen_name" : "BillSeitz",
      "indices" : [ 0, 10 ],
      "id_str" : "1239971",
      "id" : 1239971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419556786778025984",
  "geo" : { },
  "id_str" : "419557581015621633",
  "in_reply_to_user_id" : 1239971,
  "text" : "@billseitz Totally. And you've been at that for a loong time. How many years and posts do you have now?",
  "id" : 419557581015621633,
  "in_reply_to_status_id" : 419556786778025984,
  "created_at" : "2014-01-04 19:54:56 +0000",
  "in_reply_to_screen_name" : "BillSeitz",
  "in_reply_to_user_id_str" : "1239971",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/jdJ3n4vOQi",
      "expanded_url" : "http:\/\/www.amazon.com\/Samsung-UN40F6300-40-Inch-1080p-120Hz\/dp\/B00BD8SXWA",
      "display_url" : "amazon.com\/Samsung-UN40F6\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "419545338957950976",
  "geo" : { },
  "id_str" : "419557216497041408",
  "in_reply_to_user_id" : 2185,
  "text" : "Unless someone objects, I'm going to go with this 40 inch slim Samsung. Unfortunately there's no un-\"smart\" version: http:\/\/t.co\/jdJ3n4vOQi",
  "id" : 419557216497041408,
  "in_reply_to_status_id" : 419545338957950976,
  "created_at" : "2014-01-04 19:53:30 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexa Andrzejewski",
      "screen_name" : "ladylexy",
      "indices" : [ 0, 9 ],
      "id_str" : "4523471",
      "id" : 4523471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/EnIkuEnQRP",
      "expanded_url" : "http:\/\/thewirecutter.com\/reviews\/the-best-500-tv\/",
      "display_url" : "thewirecutter.com\/reviews\/the-be\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "419546764287291392",
  "geo" : { },
  "id_str" : "419547121658769409",
  "in_reply_to_user_id" : 4523471,
  "text" : "@ladylexy Thanks! The one I'm looking at is also a Samsung\u2026 looks like they consistently get good reviews. http:\/\/t.co\/EnIkuEnQRP",
  "id" : 419547121658769409,
  "in_reply_to_status_id" : 419546764287291392,
  "created_at" : "2014-01-04 19:13:23 +0000",
  "in_reply_to_screen_name" : "ladylexy",
  "in_reply_to_user_id_str" : "4523471",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419545146456162304",
  "geo" : { },
  "id_str" : "419545468171845632",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc AWESOME. This is what I needed. Thanks.",
  "id" : 419545468171845632,
  "in_reply_to_status_id" : 419545146456162304,
  "created_at" : "2014-01-04 19:06:49 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419544866704478209",
  "geo" : { },
  "id_str" : "419545338957950976",
  "in_reply_to_user_id" : 2185,
  "text" : "Next question: are any makers better than the others? Toshiba, LG, VIZIO, Seiki, etc.",
  "id" : 419545338957950976,
  "in_reply_to_status_id" : 419544866704478209,
  "created_at" : "2014-01-04 19:06:18 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 49, 58 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Jeff Croft",
      "screen_name" : "jcroft",
      "indices" : [ 59, 66 ],
      "id_str" : "25993",
      "id" : 25993
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 67, 77 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419544582951817216",
  "geo" : { },
  "id_str" : "419544866704478209",
  "in_reply_to_user_id" : 7482,
  "text" : "That's what I figured\u2026 \"Smart TV\" sucks. Thanks, @arainert @jcroft @tomcoates",
  "id" : 419544866704478209,
  "in_reply_to_status_id" : 419544582951817216,
  "created_at" : "2014-01-04 19:04:25 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Hand",
      "screen_name" : "xBeast1Modex",
      "indices" : [ 0, 13 ],
      "id_str" : "418146433",
      "id" : 418146433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419544405326839808",
  "geo" : { },
  "id_str" : "419544601796419584",
  "in_reply_to_user_id" : 418146433,
  "text" : "@xbeast1modex Yeah, something like that.",
  "id" : 419544601796419584,
  "in_reply_to_status_id" : 419544405326839808,
  "created_at" : "2014-01-04 19:03:22 +0000",
  "in_reply_to_screen_name" : "xBeast1Modex",
  "in_reply_to_user_id_str" : "418146433",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419543578524659715",
  "geo" : { },
  "id_str" : "419544211780669440",
  "in_reply_to_user_id" : 2185,
  "text" : "What is all this about \"smart TV\"? Is it necessary if I will probably get an Xbox or Apple TV to go with it?",
  "id" : 419544211780669440,
  "in_reply_to_status_id" : 419543578524659715,
  "created_at" : "2014-01-04 19:01:49 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419543578524659715",
  "text" : "I want a new TV that can be mounted on a wall that's 39 inches wide (ideally on a swivel). Does anyone have any recommendations?",
  "id" : 419543578524659715,
  "created_at" : "2014-01-04 18:59:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sterling White",
      "screen_name" : "hey_sterling",
      "indices" : [ 0, 13 ],
      "id_str" : "150863291",
      "id" : 150863291
    }, {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 31, 42 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419538051715440640",
  "geo" : { },
  "id_str" : "419539539678330880",
  "in_reply_to_user_id" : 150863291,
  "text" : "@hey_sterling The 3rd thing of @robinsloan's that I consider \"stock\" is the idea of the Codex Vitae from his Mr Penumbra book.",
  "id" : 419539539678330880,
  "in_reply_to_status_id" : 419538051715440640,
  "created_at" : "2014-01-04 18:43:15 +0000",
  "in_reply_to_screen_name" : "hey_sterling",
  "in_reply_to_user_id_str" : "150863291",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/8t4dGplHgt",
      "expanded_url" : "https:\/\/github.com\/busterbenson\/public\/blob\/master\/Stock.md",
      "display_url" : "github.com\/busterbenson\/p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "419525342785593344",
  "geo" : { },
  "id_str" : "419538285665341440",
  "in_reply_to_user_id" : 2185,
  "text" : "Here's my first pass on writing I've done &amp; writing I've read that has remained interesting to me for a long time: https:\/\/t.co\/8t4dGplHgt",
  "id" : 419538285665341440,
  "in_reply_to_status_id" : 419525342785593344,
  "created_at" : "2014-01-04 18:38:16 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sterling White",
      "screen_name" : "hey_sterling",
      "indices" : [ 0, 13 ],
      "id_str" : "150863291",
      "id" : 150863291
    }, {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 14, 25 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/NM1YTpUsVa",
      "expanded_url" : "https:\/\/readtapestry.com\/s\/YuyuuzQO8\/",
      "display_url" : "readtapestry.com\/s\/YuyuuzQO8\/"
    } ]
  },
  "in_reply_to_status_id_str" : "419537227438235648",
  "geo" : { },
  "id_str" : "419537718368927744",
  "in_reply_to_user_id" : 150863291,
  "text" : "@hey_sterling @robinsloan If you like that you should also read his tap essay if you haven't already: https:\/\/t.co\/NM1YTpUsVa",
  "id" : 419537718368927744,
  "in_reply_to_status_id" : 419537227438235648,
  "created_at" : "2014-01-04 18:36:01 +0000",
  "in_reply_to_screen_name" : "hey_sterling",
  "in_reply_to_user_id_str" : "150863291",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "Spinchange",
      "indices" : [ 0, 11 ],
      "id_str" : "52866725",
      "id" : 52866725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419529391547248641",
  "geo" : { },
  "id_str" : "419529798445060096",
  "in_reply_to_user_id" : 52866725,
  "text" : "@spinchange Thanks, Chris! I'm surprised more people don't keep their long-term thoughts in Github where you can track changes. :)",
  "id" : 419529798445060096,
  "in_reply_to_status_id" : 419529391547248641,
  "created_at" : "2014-01-04 18:04:33 +0000",
  "in_reply_to_screen_name" : "Spinchange",
  "in_reply_to_user_id_str" : "52866725",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/frFwubDlXA",
      "expanded_url" : "https:\/\/github.com\/busterbenson\/public",
      "display_url" : "github.com\/busterbenson\/p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "419522562511482880",
  "geo" : { },
  "id_str" : "419525342785593344",
  "in_reply_to_user_id" : 2185,
  "text" : "My arrival at the idea of stock came through \"quality moments\". I'm gonna add a stock file to my public repository: https:\/\/t.co\/frFwubDlXA",
  "id" : 419525342785593344,
  "in_reply_to_status_id" : 419522562511482880,
  "created_at" : "2014-01-04 17:46:50 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419524243278139392",
  "geo" : { },
  "id_str" : "419524721604952064",
  "in_reply_to_user_id" : 14095370,
  "text" : "@offbeatariel Yes! I remember you mentioning that the back catalog was keeping the discontinued offbeat verticals alive. Stock!",
  "id" : 419524721604952064,
  "in_reply_to_status_id" : 419524243278139392,
  "created_at" : "2014-01-04 17:44:22 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419522351340855297",
  "geo" : { },
  "id_str" : "419522562511482880",
  "in_reply_to_user_id" : 2185,
  "text" : "\"The real magic trick is to put them both together. Sacrifice neither. It's the hybrid strategy.\"",
  "id" : 419522562511482880,
  "in_reply_to_status_id" : 419522351340855297,
  "created_at" : "2014-01-04 17:35:47 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419522111082749952",
  "geo" : { },
  "id_str" : "419522351340855297",
  "in_reply_to_user_id" : 2185,
  "text" : "\"I feel like flow is ascendant these days, for obvious reasons\u2014but we neglect stock at our own peril.\"",
  "id" : 419522351340855297,
  "in_reply_to_status_id" : 419522111082749952,
  "created_at" : "2014-01-04 17:34:57 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 112, 123 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/xW5aBY3Rgy",
      "expanded_url" : "http:\/\/snarkmarket.com\/2010\/4890",
      "display_url" : "snarkmarket.com\/2010\/4890"
    } ]
  },
  "geo" : { },
  "id_str" : "419522111082749952",
  "text" : "\"Flow is the feed. Stock is the durable stuff that's still interesting months later.\" http:\/\/t.co\/xW5aBY3Rgy by @robinsloan",
  "id" : 419522111082749952,
  "created_at" : "2014-01-04 17:34:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419316571354300416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597227124, -122.2753067503 ]
  },
  "id_str" : "419319251040604160",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley Such a great thing to watch these little guys start to figure things out and revel in their new skills!",
  "id" : 419319251040604160,
  "in_reply_to_status_id" : 419316571354300416,
  "created_at" : "2014-01-04 04:07:54 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 1, 11 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419284931156529152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8594974452, -122.2755313813 ]
  },
  "id_str" : "419287507662929920",
  "in_reply_to_user_id" : 7362142,
  "text" : ".@kellianne Today when we were watching a show about dinosaurs in the waiting room Niko asked if they lived before or after Doctor Who.",
  "id" : 419287507662929920,
  "in_reply_to_status_id" : 419284931156529152,
  "created_at" : "2014-01-04 02:01:46 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419271915123912704",
  "geo" : { },
  "id_str" : "419272177297272832",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne Live tweet your Doctor Who marathon!",
  "id" : 419272177297272832,
  "in_reply_to_status_id" : 419271915123912704,
  "created_at" : "2014-01-04 01:00:51 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/419265931945054209\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/XTj2sY0e0T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdGIJMFCMAEcP3o.jpg",
      "id_str" : "419265931764707329",
      "id" : 419265931764707329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdGIJMFCMAEcP3o.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XTj2sY0e0T"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595280744, -122.2755878531 ]
  },
  "id_str" : "419265931945054209",
  "text" : "Kellianne's toe has been successfully de-bone-spurred. http:\/\/t.co\/XTj2sY0e0T",
  "id" : 419265931945054209,
  "created_at" : "2014-01-04 00:36:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/jKgk3TNare",
      "expanded_url" : "http:\/\/blog.vine.co\/post\/72113442134\/vine-on-the-web",
      "display_url" : "blog.vine.co\/post\/721134421\u2026"
    }, {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/eyRCfWNlfS",
      "expanded_url" : "https:\/\/vine.co\/buster",
      "display_url" : "vine.co\/buster"
    } ]
  },
  "geo" : { },
  "id_str" : "419196586183258112",
  "text" : "Vine got a rad new website with profiles and TV mode! http:\/\/t.co\/jKgk3TNare (my profile: https:\/\/t.co\/eyRCfWNlfS)",
  "id" : 419196586183258112,
  "created_at" : "2014-01-03 20:00:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/Oo5wgLSQWC",
      "expanded_url" : "http:\/\/flic.kr\/p\/iS92KA",
      "display_url" : "flic.kr\/p\/iS92KA"
    } ]
  },
  "geo" : { },
  "id_str" : "419006317211435008",
  "text" : "8:36pm Took a long time for Niko to fall asleep since he doesn't like my singing as much as Kellianne's http:\/\/t.co\/Oo5wgLSQWC",
  "id" : 419006317211435008,
  "created_at" : "2014-01-03 07:24:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Morrill",
      "screen_name" : "DanielleMorrill",
      "indices" : [ 0, 16 ],
      "id_str" : "7017692",
      "id" : 7017692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418964941081559040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597930236, -122.2756476598 ]
  },
  "id_str" : "418965642469842944",
  "in_reply_to_user_id" : 7017692,
  "text" : "@DanielleMorrill Custom timeline creation is only integrated with TweetDeck at the moment, but they can be read anywhere.",
  "id" : 418965642469842944,
  "in_reply_to_status_id" : 418964941081559040,
  "created_at" : "2014-01-03 04:42:47 +0000",
  "in_reply_to_screen_name" : "DanielleMorrill",
  "in_reply_to_user_id_str" : "7017692",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Morrill",
      "screen_name" : "DanielleMorrill",
      "indices" : [ 0, 16 ],
      "id_str" : "7017692",
      "id" : 7017692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/sqhZ6naDDk",
      "expanded_url" : "https:\/\/dev.twitter.com\/blog\/introducing-custom-timelines",
      "display_url" : "dev.twitter.com\/blog\/introduci\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "418960675201761280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598175402, -122.2755868444 ]
  },
  "id_str" : "418964614156546049",
  "in_reply_to_user_id" : 7017692,
  "text" : "@DanielleMorrill Have you checked out custom timelines? Just launched recently: https:\/\/t.co\/sqhZ6naDDk",
  "id" : 418964614156546049,
  "in_reply_to_status_id" : 418960675201761280,
  "created_at" : "2014-01-03 04:38:42 +0000",
  "in_reply_to_screen_name" : "DanielleMorrill",
  "in_reply_to_user_id_str" : "7017692",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "indices" : [ 0, 13 ],
      "id_str" : "1186",
      "id" : 1186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418913886377480193",
  "geo" : { },
  "id_str" : "418914575434534913",
  "in_reply_to_user_id" : 1186,
  "text" : "@chrismessina Awesome.",
  "id" : 418914575434534913,
  "in_reply_to_status_id" : 418913886377480193,
  "created_at" : "2014-01-03 01:19:52 +0000",
  "in_reply_to_screen_name" : "chrismessina",
  "in_reply_to_user_id_str" : "1186",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 8, 17 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 18, 25 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418814774273511424",
  "geo" : { },
  "id_str" : "418816625123418112",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @arainert @Medium Yeah, it\u2019s a bit wacky, but I can see the convenience of it from the route perspective.",
  "id" : 418816625123418112,
  "in_reply_to_status_id" : 418814774273511424,
  "created_at" : "2014-01-02 18:50:39 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 10, 17 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/xV3cj74J6w",
      "expanded_url" : "http:\/\/medium.com\/@buster",
      "display_url" : "medium.com\/@buster"
    }, {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/s2vvOvpITN",
      "expanded_url" : "https:\/\/medium.com\/buster-benson",
      "display_url" : "medium.com\/buster-benson"
    } ]
  },
  "in_reply_to_status_id_str" : "418813341562568704",
  "geo" : { },
  "id_str" : "418813954245136384",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert @medium Do you mean this? http:\/\/t.co\/xV3cj74J6w? I also have a collection here: https:\/\/t.co\/s2vvOvpITN",
  "id" : 418813954245136384,
  "in_reply_to_status_id" : 418813341562568704,
  "created_at" : "2014-01-02 18:40:02 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 39, 47 ],
      "id_str" : "353195232",
      "id" : 353195232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantdiet",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/NGwuJjb0Na",
      "expanded_url" : "https:\/\/lift.do\/quantified-diet",
      "display_url" : "lift.do\/quantified-diet"
    } ]
  },
  "geo" : { },
  "id_str" : "418805644754313216",
  "text" : "I'm playing diet lotto in January with @liftapp's #quantdiet challenge. Got assigned Paleo. https:\/\/t.co\/NGwuJjb0Na",
  "id" : 418805644754313216,
  "created_at" : "2014-01-02 18:07:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Brewer",
      "screen_name" : "jbrewer",
      "indices" : [ 0, 8 ],
      "id_str" : "12555",
      "id" : 12555
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 9, 18 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/JghZ8d7hCO",
      "expanded_url" : "http:\/\/busterbenson.com",
      "display_url" : "busterbenson.com"
    } ]
  },
  "in_reply_to_status_id_str" : "418804276345856000",
  "geo" : { },
  "id_str" : "418804939846995969",
  "in_reply_to_user_id" : 2185,
  "text" : "@jbrewer @arainert I also archive everything on http:\/\/t.co\/JghZ8d7hCO via RSS so don't feel required to blog from only one place.",
  "id" : 418804939846995969,
  "in_reply_to_status_id" : 418804276345856000,
  "created_at" : "2014-01-02 18:04:13 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Brewer",
      "screen_name" : "jbrewer",
      "indices" : [ 0, 8 ],
      "id_str" : "12555",
      "id" : 12555
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 9, 18 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418803567391039488",
  "geo" : { },
  "id_str" : "418804276345856000",
  "in_reply_to_user_id" : 12555,
  "text" : "@jbrewer @arainert The writing environment is pleasant, they support collaborators, comments\/notes are handled well, and stats are fun.",
  "id" : 418804276345856000,
  "in_reply_to_status_id" : 418803567391039488,
  "created_at" : "2014-01-02 18:01:35 +0000",
  "in_reply_to_screen_name" : "jbrewer",
  "in_reply_to_user_id_str" : "12555",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 20, 27 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/tJIh6O3LhU",
      "expanded_url" : "http:\/\/wayoftheduck.com",
      "display_url" : "wayoftheduck.com"
    } ]
  },
  "in_reply_to_status_id_str" : "418790378490593280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7932019964, -122.3966586688 ]
  },
  "id_str" : "418798195297103872",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert I'm using @medium as my blog now... haven't posted to http:\/\/t.co\/tJIh6O3LhU for a while now.",
  "id" : 418798195297103872,
  "in_reply_to_status_id" : 418790378490593280,
  "created_at" : "2014-01-02 17:37:25 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/418619966993096704\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/oxZjU6ejMK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bc88pFLCcAAU0WB.jpg",
      "id_str" : "418619966829522944",
      "id" : 418619966829522944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bc88pFLCcAAU0WB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oxZjU6ejMK"
    } ],
    "hashtags" : [ {
      "text" : "sleepy",
      "indices" : [ 63, 70 ]
    }, {
      "text" : "newyearselfie",
      "indices" : [ 71, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595387305, -122.2756336056 ]
  },
  "id_str" : "418619966993096704",
  "text" : "8:36pm First day of the new year and have already missed a nap #sleepy #newyearselfie http:\/\/t.co\/oxZjU6ejMK",
  "id" : 418619966993096704,
  "created_at" : "2014-01-02 05:49:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418529659664334848",
  "text" : "I\u2019m gonna start 2014 with a good LiveJournal post.",
  "id" : 418529659664334848,
  "created_at" : "2014-01-01 23:50:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CA AcademyOfSciences",
      "screen_name" : "calacademy",
      "indices" : [ 45, 56 ],
      "id_str" : "16017753",
      "id" : 16017753
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 60, 70 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/UrspXUnWUe",
      "expanded_url" : "http:\/\/4sq.com\/1cIKZth",
      "display_url" : "4sq.com\/1cIKZth"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7697648824, -122.4663162231 ]
  },
  "id_str" : "418472882294247424",
  "text" : "Oh yeah. (@ California Academy of Sciences - @calacademy w\/ @kellianne) http:\/\/t.co\/UrspXUnWUe",
  "id" : 418472882294247424,
  "created_at" : "2014-01-01 20:04:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/BAVBmgnV5m",
      "expanded_url" : "http:\/\/instagram.com\/p\/iomnKhOFYV\/",
      "display_url" : "instagram.com\/p\/iomnKhOFYV\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859543, -122.275604 ]
  },
  "id_str" : "418439774928510976",
  "text" : "2014 awakes! http:\/\/t.co\/BAVBmgnV5m",
  "id" : 418439774928510976,
  "created_at" : "2014-01-01 17:53:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597552157, -122.275673127 ]
  },
  "id_str" : "418423106730876930",
  "text" : "Last night was funny. Happy new year, friends!",
  "id" : 418423106730876930,
  "created_at" : "2014-01-01 16:46:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "indices" : [ 12, 23 ],
      "id_str" : "135316691",
      "id" : 135316691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/PWQjb4I92r",
      "expanded_url" : "http:\/\/buff.ly\/1hUiZnM",
      "display_url" : "buff.ly\/1hUiZnM"
    } ]
  },
  "in_reply_to_status_id_str" : "418377854163095552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595593965, -122.2756080356 ]
  },
  "id_str" : "418422839763431424",
  "in_reply_to_user_id" : 135316691,
  "text" : "Sleep in RT @JadAbumrad: Today is 54 billionths of a second longer than yesterday. What to do with the extra time? http:\/\/t.co\/PWQjb4I92r",
  "id" : 418422839763431424,
  "in_reply_to_status_id" : 418377854163095552,
  "created_at" : "2014-01-01 16:45:53 +0000",
  "in_reply_to_screen_name" : "JadAbumrad",
  "in_reply_to_user_id_str" : "135316691",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596594883, -122.275499683 ]
  },
  "id_str" : "418422087728914432",
  "text" : "Rabbit rabbit!",
  "id" : 418422087728914432,
  "created_at" : "2014-01-01 16:42:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/418317887862870016\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Xhygk1TvKN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bc4p5wzCAAAAGQV.jpg",
      "id_str" : "418317887720259584",
      "id" : 418317887720259584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bc4p5wzCAAAAGQV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 457
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 457
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 457
      } ],
      "display_url" : "pic.twitter.com\/Xhygk1TvKN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418280992017612800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8679797426, -122.2842918803 ]
  },
  "id_str" : "418317887862870016",
  "in_reply_to_user_id" : 2185,
  "text" : "http:\/\/t.co\/Xhygk1TvKN",
  "id" : 418317887862870016,
  "in_reply_to_status_id" : 418280992017612800,
  "created_at" : "2014-01-01 09:48:51 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]