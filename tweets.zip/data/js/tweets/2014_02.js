Grailbird.data.tweets_2014_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439654135835533312",
  "geo" : { },
  "id_str" : "439656101026353152",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Exactly!",
  "id" : 439656101026353152,
  "in_reply_to_status_id" : 439654135835533312,
  "created_at" : "2014-03-01 06:59:17 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beau Gunderson",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 15, 24 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 25, 41 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 42, 51 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439641080657502208",
  "geo" : { },
  "id_str" : "439646357574279168",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @eramirez @tonystubblebine @agaricus Definitely!",
  "id" : 439646357574279168,
  "in_reply_to_status_id" : 439641080657502208,
  "created_at" : "2014-03-01 06:20:34 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/439641937935466496\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/Oq75xMF3XX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhnsA1iCIAA-3-L.jpg",
      "id_str" : "439641937759313920",
      "id" : 439641937759313920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhnsA1iCIAA-3-L.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Oq75xMF3XX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439641937935466496",
  "text" : "8:36pm Fun to see Hump in SF for the first time! http:\/\/t.co\/Oq75xMF3XX",
  "id" : 439641937935466496,
  "created_at" : "2014-03-01 06:03:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 60, 70 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/iAS4st1Gsp",
      "expanded_url" : "http:\/\/4sq.com\/1kiJAyS",
      "display_url" : "4sq.com\/1kiJAyS"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7646420068, -122.4224176335 ]
  },
  "id_str" : "439608383621328896",
  "text" : "Hump fest! (@ Roxie Cinema for Hump Tour with Dan Savage w\/ @kellianne) [pic]: http:\/\/t.co\/iAS4st1Gsp",
  "id" : 439608383621328896,
  "created_at" : "2014-03-01 03:49:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "agreetodisagree",
      "indices" : [ 13, 29 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439606535560634368",
  "geo" : { },
  "id_str" : "439607095202037761",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine #agreetodisagree",
  "id" : 439607095202037761,
  "in_reply_to_status_id" : 439606535560634368,
  "created_at" : "2014-03-01 03:44:33 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439588093931565056",
  "geo" : { },
  "id_str" : "439605986496503809",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine Huh. I think it would be fairly easy to model a neuron in a computer. Then just need 100,000,000,000 computers.",
  "id" : 439605986496503809,
  "in_reply_to_status_id" : 439588093931565056,
  "created_at" : "2014-03-01 03:40:09 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439585724174962688",
  "geo" : { },
  "id_str" : "439586530147835904",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine Which part of our brain is fundamentally more complex than a computer could be?",
  "id" : 439586530147835904,
  "in_reply_to_status_id" : 439585724174962688,
  "created_at" : "2014-03-01 02:22:50 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439548711379562497",
  "geo" : { },
  "id_str" : "439584947414659072",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I keep reading these tweets as if you are saying them.",
  "id" : 439584947414659072,
  "in_reply_to_status_id" : 439548711379562497,
  "created_at" : "2014-03-01 02:16:33 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439582490169466880",
  "geo" : { },
  "id_str" : "439584239235764224",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine How else would complex things have ever come about?",
  "id" : 439584239235764224,
  "in_reply_to_status_id" : 439582490169466880,
  "created_at" : "2014-03-01 02:13:44 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Lingerfelt",
      "screen_name" : "klingerf",
      "indices" : [ 0, 9 ],
      "id_str" : "16018433",
      "id" : 16018433
    }, {
      "name" : "N\u0308athan T\u0308aylor",
      "screen_name" : "dijkstracula",
      "indices" : [ 10, 23 ],
      "id_str" : "14216743",
      "id" : 14216743
    }, {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 24, 34 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439566677714272256",
  "geo" : { },
  "id_str" : "439581285392977921",
  "in_reply_to_user_id" : 16018433,
  "text" : "@klingerf @dijkstracula @jayholler I'm going! You should too!",
  "id" : 439581285392977921,
  "in_reply_to_status_id" : 439566677714272256,
  "created_at" : "2014-03-01 02:02:00 +0000",
  "in_reply_to_screen_name" : "klingerf",
  "in_reply_to_user_id_str" : "16018433",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439581240170000384",
  "text" : "A computer can become a word processor if it runs word processing software. It can become a brain if it runs brain software. Agree\/disagree?",
  "id" : 439581240170000384,
  "created_at" : "2014-03-01 02:01:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrej Gregov",
      "screen_name" : "agregov",
      "indices" : [ 0, 8 ],
      "id_str" : "752413",
      "id" : 752413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439576144384258048",
  "geo" : { },
  "id_str" : "439577069312151552",
  "in_reply_to_user_id" : 752413,
  "text" : "@agregov Wow, that's a lot of words. Having read Everything Store and In the Plex I feel like publishers would rather die than change.",
  "id" : 439577069312151552,
  "in_reply_to_status_id" : 439576144384258048,
  "created_at" : "2014-03-01 01:45:14 +0000",
  "in_reply_to_screen_name" : "agregov",
  "in_reply_to_user_id_str" : "752413",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrej Gregov",
      "screen_name" : "agregov",
      "indices" : [ 0, 8 ],
      "id_str" : "752413",
      "id" : 752413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439575355171430400",
  "geo" : { },
  "id_str" : "439575491268206593",
  "in_reply_to_user_id" : 752413,
  "text" : "@agregov Are you reading The Everything Store?",
  "id" : 439575491268206593,
  "in_reply_to_status_id" : 439575355171430400,
  "created_at" : "2014-03-01 01:38:58 +0000",
  "in_reply_to_screen_name" : "agregov",
  "in_reply_to_user_id_str" : "752413",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 10, 26 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 27, 34 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439560524435427328",
  "geo" : { },
  "id_str" : "439564079347138560",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @tonystubblebine @cwhogg Excellent!",
  "id" : 439564079347138560,
  "in_reply_to_status_id" : 439560524435427328,
  "created_at" : "2014-03-01 00:53:37 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 10, 26 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439554772941565952",
  "geo" : { },
  "id_str" : "439555348769165312",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @tonystubblebine I'll be there!",
  "id" : 439555348769165312,
  "in_reply_to_status_id" : 439554772941565952,
  "created_at" : "2014-03-01 00:18:56 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "nicole sheikh",
      "screen_name" : "nicolesheikh",
      "indices" : [ 10, 23 ],
      "id_str" : "90800956",
      "id" : 90800956
    }, {
      "name" : "cg",
      "screen_name" : "cg",
      "indices" : [ 24, 27 ],
      "id_str" : "750",
      "id" : 750
    }, {
      "name" : "Lena",
      "screen_name" : "lenazun",
      "indices" : [ 28, 36 ],
      "id_str" : "88717547",
      "id" : 88717547
    }, {
      "name" : "Asli Sayitoglu",
      "screen_name" : "unbirthdaytea",
      "indices" : [ 37, 51 ],
      "id_str" : "85054503",
      "id" : 85054503
    }, {
      "name" : "leftsider",
      "screen_name" : "Leftsider",
      "indices" : [ 52, 62 ],
      "id_str" : "3796",
      "id" : 3796
    }, {
      "name" : "Lindsay Schauer",
      "screen_name" : "SchauerTime",
      "indices" : [ 63, 75 ],
      "id_str" : "19169495",
      "id" : 19169495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439484983636676609",
  "geo" : { },
  "id_str" : "439485743275065344",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley @nicolesheikh @cg @lenazun @unbirthdaytea @leftsider @SchauerTime I can join at 12\u2026 tell me where you all end up sitting!",
  "id" : 439485743275065344,
  "in_reply_to_status_id" : 439484983636676609,
  "created_at" : "2014-02-28 19:42:21 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 57, 62 ],
      "id_str" : "418",
      "id" : 418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439468452110417920",
  "geo" : { },
  "id_str" : "439468807891865600",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert It's really great. You're in it, even! I think @dens must have been interviewed. Highlights the lost opportunity of Dodgeball. :)",
  "id" : 439468807891865600,
  "in_reply_to_status_id" : 439468452110417920,
  "created_at" : "2014-02-28 18:35:03 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Costa",
      "screen_name" : "jasoncosta",
      "indices" : [ 0, 11 ],
      "id_str" : "14927800",
      "id" : 14927800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439462769134301184",
  "geo" : { },
  "id_str" : "439468479528194048",
  "in_reply_to_user_id" : 14927800,
  "text" : "@jasoncosta Yeah, I loved learning about the various people and teams behind the projects.",
  "id" : 439468479528194048,
  "in_reply_to_status_id" : 439462769134301184,
  "created_at" : "2014-02-28 18:33:45 +0000",
  "in_reply_to_screen_name" : "jasoncosta",
  "in_reply_to_user_id_str" : "14927800",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439467985456336896",
  "geo" : { },
  "id_str" : "439468250217205760",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert I haven't read any of those\u2026 Dogfight might be interesting. I've seen the Pixar documentary and loved it. Which did you like best?",
  "id" : 439468250217205760,
  "in_reply_to_status_id" : 439467985456336896,
  "created_at" : "2014-02-28 18:32:50 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439462230522728448",
  "text" : "Finished In The Plex about Google, and I think it's my favorite of the tech co biographies (Hatched, Everything Store, Steve Jobs).",
  "id" : 439462230522728448,
  "created_at" : "2014-02-28 18:08:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teamarthurchu",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/mXNB3mtvvu",
      "expanded_url" : "https:\/\/www.readability.com\/articles\/edjvpj2n",
      "display_url" : "readability.com\/articles\/edjvp\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859688, -122.275444 ]
  },
  "id_str" : "439301652663656448",
  "text" : "#teamarthurchu https:\/\/t.co\/mXNB3mtvvu",
  "id" : 439301652663656448,
  "created_at" : "2014-02-28 07:30:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 3, 10 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/torrez\/status\/439246414359441408\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/jYBEw1mnYD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhiESVjCAAAOB7b.jpg",
      "id_str" : "439246414225211392",
      "id" : 439246414225211392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhiESVjCAAAOB7b.jpg",
      "sizes" : [ {
        "h" : 259,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/jYBEw1mnYD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/4uyoTV29Ej",
      "expanded_url" : "http:\/\/mcphee.com\/shop\/horse-head-squirrel-feeder.html",
      "display_url" : "mcphee.com\/shop\/horse-hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439267839036252160",
  "text" : "RT @torrez: Horse head squirrel feeder http:\/\/t.co\/4uyoTV29Ej http:\/\/t.co\/jYBEw1mnYD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/torrez\/status\/439246414359441408\/photo\/1",
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/jYBEw1mnYD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhiESVjCAAAOB7b.jpg",
        "id_str" : "439246414225211392",
        "id" : 439246414225211392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhiESVjCAAAOB7b.jpg",
        "sizes" : [ {
          "h" : 259,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 732,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 732,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/jYBEw1mnYD"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/4uyoTV29Ej",
        "expanded_url" : "http:\/\/mcphee.com\/shop\/horse-head-squirrel-feeder.html",
        "display_url" : "mcphee.com\/shop\/horse-hea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "439246414359441408",
    "text" : "Horse head squirrel feeder http:\/\/t.co\/4uyoTV29Ej http:\/\/t.co\/jYBEw1mnYD",
    "id" : 439246414359441408,
    "created_at" : "2014-02-28 03:51:20 +0000",
    "user" : {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "protected" : false,
      "id_str" : "11604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463439738167238656\/nhxNlsQL_normal.png",
      "id" : 11604,
      "verified" : false
    }
  },
  "id" : 439267839036252160,
  "created_at" : "2014-02-28 05:16:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/439259455792746496\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/rmFAn24zgQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhiQJbICEAAXxV7.jpg",
      "id_str" : "439259455243292672",
      "id" : 439259455243292672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhiQJbICEAAXxV7.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rmFAn24zgQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439259455792746496",
  "text" : "8:36pm Family pile http:\/\/t.co\/rmFAn24zgQ",
  "id" : 439259455792746496,
  "created_at" : "2014-02-28 04:43:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439213395926331392",
  "geo" : { },
  "id_str" : "439213524066107392",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert It's an avatar for our generation.",
  "id" : 439213524066107392,
  "in_reply_to_status_id" : 439213395926331392,
  "created_at" : "2014-02-28 01:40:38 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/439213119617789952\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/aGJBqIRFVU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhhmAUxCIAACpG3.jpg",
      "id_str" : "439213119429025792",
      "id" : 439213119429025792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhhmAUxCIAACpG3.jpg",
      "sizes" : [ {
        "h" : 586,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aGJBqIRFVU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439213119617789952",
  "text" : "http:\/\/t.co\/aGJBqIRFVU",
  "id" : 439213119617789952,
  "created_at" : "2014-02-28 01:39:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439136999724044288",
  "geo" : { },
  "id_str" : "439205549570129920",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Oooh, sounds interesting! If you want to bounce any ideas around or get feedback let me know! Good luck!",
  "id" : 439205549570129920,
  "in_reply_to_status_id" : 439136999724044288,
  "created_at" : "2014-02-28 01:08:57 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439191318267322368",
  "geo" : { },
  "id_str" : "439194601740451840",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne Well I'll have to watch it again anyway, right?",
  "id" : 439194601740451840,
  "in_reply_to_status_id" : 439191318267322368,
  "created_at" : "2014-02-28 00:25:27 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/34lEY7xiQf",
      "expanded_url" : "http:\/\/techcrunch.com\/2014\/02\/27\/netflix-fitbit-hack\/",
      "display_url" : "techcrunch.com\/2014\/02\/27\/net\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439181843854684160",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne This might help you with your problem: http:\/\/t.co\/34lEY7xiQf",
  "id" : 439181843854684160,
  "created_at" : "2014-02-27 23:34:45 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 107, 113 ],
      "id_str" : "42559115",
      "id" : 42559115
    }, {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 114, 128 ],
      "id_str" : "18749271",
      "id" : 18749271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439175857446191106",
  "geo" : { },
  "id_str" : "439176212850540544",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Branch! No idea if it'll be around in a year, but it's still here for now\u2026 and it's my fave. \/cc @joshm @libbybrittain",
  "id" : 439176212850540544,
  "in_reply_to_status_id" : 439175857446191106,
  "created_at" : "2014-02-27 23:12:23 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439159836761399296",
  "geo" : { },
  "id_str" : "439175631993974784",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez \"optionality\" is actually one of my favorite topics in the book.",
  "id" : 439175631993974784,
  "in_reply_to_status_id" : 439159836761399296,
  "created_at" : "2014-02-27 23:10:04 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439157301942161409",
  "geo" : { },
  "id_str" : "439157469726920704",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Maybe start a Facebook or Google group or branch or something to discuss as you read? So many options!",
  "id" : 439157469726920704,
  "in_reply_to_status_id" : 439157301942161409,
  "created_at" : "2014-02-27 21:57:54 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439154217345761280",
  "geo" : { },
  "id_str" : "439157146933280770",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Such a great book! Let\u2019s talk about it when you\u2019re done.",
  "id" : 439157146933280770,
  "in_reply_to_status_id" : 439154217345761280,
  "created_at" : "2014-02-27 21:56:37 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Chen",
      "screen_name" : "chenosaurus",
      "indices" : [ 0, 12 ],
      "id_str" : "15349546",
      "id" : 15349546
    }, {
      "name" : "Firebase",
      "screen_name" : "Firebase",
      "indices" : [ 39, 48 ],
      "id_str" : "447644824",
      "id" : 447644824
    }, {
      "name" : "Parse",
      "screen_name" : "ParseIt",
      "indices" : [ 72, 80 ],
      "id_str" : "319186866",
      "id" : 319186866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438913241016565760",
  "geo" : { },
  "id_str" : "438915143804542976",
  "in_reply_to_user_id" : 15349546,
  "text" : "@chenosaurus Ooh, totally forgot about @firebase. How is it better than @parseit?",
  "id" : 438915143804542976,
  "in_reply_to_status_id" : 438913241016565760,
  "created_at" : "2014-02-27 05:54:59 +0000",
  "in_reply_to_screen_name" : "chenosaurus",
  "in_reply_to_user_id_str" : "15349546",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hyped up aka popular",
      "screen_name" : "iano",
      "indices" : [ 0, 5 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438897498225401856",
  "geo" : { },
  "id_str" : "438910533865971712",
  "in_reply_to_user_id" : 14409856,
  "text" : "@iano What don\u2019t you like about it? I\u2019m just using it for prototyping stuff quickly\u2026 works pretty well for that.",
  "id" : 438910533865971712,
  "in_reply_to_status_id" : 438897498225401856,
  "created_at" : "2014-02-27 05:36:40 +0000",
  "in_reply_to_screen_name" : "iano",
  "in_reply_to_user_id_str" : "14409856",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/kGJlyXU0sU",
      "expanded_url" : "http:\/\/flic.kr\/p\/kvHWkF",
      "display_url" : "flic.kr\/p\/kvHWkF"
    } ]
  },
  "geo" : { },
  "id_str" : "438896579769274368",
  "text" : "8:36pm Learning about Parse and Express, it's pretty great at first glance. Who's used either? http:\/\/t.co\/kGJlyXU0sU",
  "id" : 438896579769274368,
  "created_at" : "2014-02-27 04:41:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 10, 26 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438843297063133184",
  "geo" : { },
  "id_str" : "438854208066822145",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @tonystubblebine Terrible name, though. Wow.",
  "id" : 438854208066822145,
  "in_reply_to_status_id" : 438843297063133184,
  "created_at" : "2014-02-27 01:52:51 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dane Sanders",
      "screen_name" : "danesanders",
      "indices" : [ 0, 12 ],
      "id_str" : "13333322",
      "id" : 13333322
    }, {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 13, 23 ],
      "id_str" : "10609",
      "id" : 10609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438826375928381440",
  "geo" : { },
  "id_str" : "438833708435398656",
  "in_reply_to_user_id" : 13333322,
  "text" : "@danesanders @superamit Great meeting you too! Excited to see what you're building.",
  "id" : 438833708435398656,
  "in_reply_to_status_id" : 438826375928381440,
  "created_at" : "2014-02-27 00:31:23 +0000",
  "in_reply_to_screen_name" : "danesanders",
  "in_reply_to_user_id_str" : "13333322",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam (SociallyGold)",
      "screen_name" : "Socially_Gold",
      "indices" : [ 0, 14 ],
      "id_str" : "19601202",
      "id" : 19601202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438803534448840704",
  "geo" : { },
  "id_str" : "438804091607580672",
  "in_reply_to_user_id" : 19601202,
  "text" : "@socially_gold It pulled from go:description before. Feel free to remove that tag and it will go back to previous text.",
  "id" : 438804091607580672,
  "in_reply_to_status_id" : 438803534448840704,
  "created_at" : "2014-02-26 22:33:42 +0000",
  "in_reply_to_screen_name" : "Socially_Gold",
  "in_reply_to_user_id_str" : "19601202",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam (SociallyGold)",
      "screen_name" : "Socially_Gold",
      "indices" : [ 0, 14 ],
      "id_str" : "19601202",
      "id" : 19601202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438803142571229186",
  "geo" : { },
  "id_str" : "438803326881132544",
  "in_reply_to_user_id" : 19601202,
  "text" : "@socially_gold You can put in whatever summary text you want in the twitter:description field.",
  "id" : 438803326881132544,
  "in_reply_to_status_id" : 438803142571229186,
  "created_at" : "2014-02-26 22:30:40 +0000",
  "in_reply_to_screen_name" : "Socially_Gold",
  "in_reply_to_user_id_str" : "19601202",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam (SociallyGold)",
      "screen_name" : "Socially_Gold",
      "indices" : [ 0, 14 ],
      "id_str" : "19601202",
      "id" : 19601202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438802242532298752",
  "geo" : { },
  "id_str" : "438802490134249472",
  "in_reply_to_user_id" : 19601202,
  "text" : "@socially_gold Perfect. When 2-10 Tweets point to URLs with those tags, we'll grant you access to analytics within a day.",
  "id" : 438802490134249472,
  "in_reply_to_status_id" : 438802242532298752,
  "created_at" : "2014-02-26 22:27:20 +0000",
  "in_reply_to_screen_name" : "Socially_Gold",
  "in_reply_to_user_id_str" : "19601202",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam (SociallyGold)",
      "screen_name" : "Socially_Gold",
      "indices" : [ 0, 14 ],
      "id_str" : "19601202",
      "id" : 19601202
    }, {
      "name" : "Adam (SociallyGold)",
      "screen_name" : "Socially_Gold",
      "indices" : [ 112, 126 ],
      "id_str" : "19601202",
      "id" : 19601202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438801056345374720",
  "geo" : { },
  "id_str" : "438801405944418304",
  "in_reply_to_user_id" : 19601202,
  "text" : "@socially_gold You need to update the content=\"\" values with your own info. Specifically, for twitter:site\u2026 put @socially_gold as value.",
  "id" : 438801405944418304,
  "in_reply_to_status_id" : 438801056345374720,
  "created_at" : "2014-02-26 22:23:02 +0000",
  "in_reply_to_screen_name" : "Socially_Gold",
  "in_reply_to_user_id_str" : "19601202",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam (SociallyGold)",
      "screen_name" : "Socially_Gold",
      "indices" : [ 0, 14 ],
      "id_str" : "19601202",
      "id" : 19601202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/A8JXhWlbI0",
      "expanded_url" : "https:\/\/support.twitter.com\/articles\/20170934-twitter-card-analytics-dashboard",
      "display_url" : "support.twitter.com\/articles\/20170\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "438798230340771840",
  "geo" : { },
  "id_str" : "438798510696042496",
  "in_reply_to_user_id" : 19601202,
  "text" : "@socially_gold Looks like you just need to add a twitter:site tag, attributing the URL to your Twitter acct. https:\/\/t.co\/A8JXhWlbI0",
  "id" : 438798510696042496,
  "in_reply_to_status_id" : 438798230340771840,
  "created_at" : "2014-02-26 22:11:32 +0000",
  "in_reply_to_screen_name" : "Socially_Gold",
  "in_reply_to_user_id_str" : "19601202",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam (SociallyGold)",
      "screen_name" : "Socially_Gold",
      "indices" : [ 0, 14 ],
      "id_str" : "19601202",
      "id" : 19601202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438797336622673920",
  "geo" : { },
  "id_str" : "438798010210725888",
  "in_reply_to_user_id" : 19601202,
  "text" : "@socially_gold Can you send me a link to a page with card markup and a tweet pointing to it? I'll take a look.",
  "id" : 438798010210725888,
  "in_reply_to_status_id" : 438797336622673920,
  "created_at" : "2014-02-26 22:09:32 +0000",
  "in_reply_to_screen_name" : "Socially_Gold",
  "in_reply_to_user_id_str" : "19601202",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camille Fournier",
      "screen_name" : "skamille",
      "indices" : [ 0, 9 ],
      "id_str" : "24257941",
      "id" : 24257941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438794291931254784",
  "geo" : { },
  "id_str" : "438794535817060352",
  "in_reply_to_user_id" : 24257941,
  "text" : "@skamille Lead by example?",
  "id" : 438794535817060352,
  "in_reply_to_status_id" : 438794291931254784,
  "created_at" : "2014-02-26 21:55:44 +0000",
  "in_reply_to_screen_name" : "skamille",
  "in_reply_to_user_id_str" : "24257941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 0, 12 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    }, {
      "name" : "Zenobase",
      "screen_name" : "zenobase",
      "indices" : [ 13, 22 ],
      "id_str" : "556162919",
      "id" : 556162919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438733434291507200",
  "geo" : { },
  "id_str" : "438794149462941696",
  "in_reply_to_user_id" : 2201640770,
  "text" : "@GetReporter @zenobase Is there any way to have the app re-export all of the reports to Dropbox when a field is changed?",
  "id" : 438794149462941696,
  "in_reply_to_status_id" : 438733434291507200,
  "created_at" : "2014-02-26 21:54:12 +0000",
  "in_reply_to_screen_name" : "GetReporter",
  "in_reply_to_user_id_str" : "2201640770",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Spaceship",
      "screen_name" : "bigspaceship",
      "indices" : [ 0, 13 ],
      "id_str" : "811303",
      "id" : 811303
    }, {
      "name" : "Tony Clement",
      "screen_name" : "TonyClement",
      "indices" : [ 14, 26 ],
      "id_str" : "16622206",
      "id" : 16622206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438768484865302529",
  "geo" : { },
  "id_str" : "438768876411572225",
  "in_reply_to_user_id" : 811303,
  "text" : "@bigspaceship @tonyclement You really found the subtleties and explained them well. Thanks, Tony! If I may ask - who is this meant for?",
  "id" : 438768876411572225,
  "in_reply_to_status_id" : 438768484865302529,
  "created_at" : "2014-02-26 20:13:46 +0000",
  "in_reply_to_screen_name" : "bigspaceship",
  "in_reply_to_user_id_str" : "811303",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Spaceship",
      "screen_name" : "bigspaceship",
      "indices" : [ 22, 35 ],
      "id_str" : "811303",
      "id" : 811303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/KLpoP2h5fN",
      "expanded_url" : "http:\/\/spcshp.it\/1a2",
      "display_url" : "spcshp.it\/1a2"
    } ]
  },
  "geo" : { },
  "id_str" : "438767585815826432",
  "text" : "Great explanation: RT @bigspaceship: With Twitter's new Card Analytics, the Internet of Data-ness got more awesome: http:\/\/t.co\/KLpoP2h5fN",
  "id" : 438767585815826432,
  "created_at" : "2014-02-26 20:08:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "indices" : [ 3, 8 ],
      "id_str" : "10221",
      "id" : 10221
    }, {
      "name" : "Kim-Mai Cutler",
      "screen_name" : "kimmaicutler",
      "indices" : [ 71, 84 ],
      "id_str" : "14367669",
      "id" : 14367669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/wCAV15uk0g",
      "expanded_url" : "https:\/\/www.crowdtilt.com\/campaigns\/the-great-techcrunch-flappy-bird-hunt\/",
      "display_url" : "crowdtilt.com\/campaigns\/the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438755037972418560",
  "text" : "RT @drew: this is absolutely genius. https:\/\/t.co\/wCAV15uk0g go get em @kimmaicutler",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kim-Mai Cutler",
        "screen_name" : "kimmaicutler",
        "indices" : [ 61, 74 ],
        "id_str" : "14367669",
        "id" : 14367669
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/wCAV15uk0g",
        "expanded_url" : "https:\/\/www.crowdtilt.com\/campaigns\/the-great-techcrunch-flappy-bird-hunt\/",
        "display_url" : "crowdtilt.com\/campaigns\/the-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "438754650880098304",
    "text" : "this is absolutely genius. https:\/\/t.co\/wCAV15uk0g go get em @kimmaicutler",
    "id" : 438754650880098304,
    "created_at" : "2014-02-26 19:17:15 +0000",
    "user" : {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "protected" : false,
      "id_str" : "10221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449363717671505920\/wKlfNnSY_normal.jpeg",
      "id" : 10221,
      "verified" : false
    }
  },
  "id" : 438755037972418560,
  "created_at" : "2014-02-26 19:18:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Pepper",
      "screen_name" : "noahmp",
      "indices" : [ 0, 7 ],
      "id_str" : "20219699",
      "id" : 20219699
    }, {
      "name" : "Cristina Cordova",
      "screen_name" : "cjc",
      "indices" : [ 8, 12 ],
      "id_str" : "26895943",
      "id" : 26895943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438734466639335424",
  "geo" : { },
  "id_str" : "438735455157116928",
  "in_reply_to_user_id" : 20219699,
  "text" : "@noahmp @cjc I'm going to send this link along with my requests for feedback on early drafts from now on. :)",
  "id" : 438735455157116928,
  "in_reply_to_status_id" : 438734466639335424,
  "created_at" : "2014-02-26 18:00:58 +0000",
  "in_reply_to_screen_name" : "noahmp",
  "in_reply_to_user_id_str" : "20219699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Teehan",
      "screen_name" : "gt",
      "indices" : [ 3, 6 ],
      "id_str" : "16655768",
      "id" : 16655768
    }, {
      "name" : "Kyra Aylsworth",
      "screen_name" : "kyrio",
      "indices" : [ 83, 89 ],
      "id_str" : "6388352",
      "id" : 6388352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/s6jt0xIigA",
      "expanded_url" : "http:\/\/s.tnlx.co\/1hlya9C",
      "display_url" : "s.tnlx.co\/1hlya9C"
    } ]
  },
  "geo" : { },
  "id_str" : "438699726272086016",
  "text" : "RT @gt: Zen and the art of insight generation. Good post from one of our planners, @kyrio.\n\nhttp:\/\/t.co\/s6jt0xIigA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kyra Aylsworth",
        "screen_name" : "kyrio",
        "indices" : [ 75, 81 ],
        "id_str" : "6388352",
        "id" : 6388352
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/s6jt0xIigA",
        "expanded_url" : "http:\/\/s.tnlx.co\/1hlya9C",
        "display_url" : "s.tnlx.co\/1hlya9C"
      } ]
    },
    "geo" : { },
    "id_str" : "438695981190635520",
    "text" : "Zen and the art of insight generation. Good post from one of our planners, @kyrio.\n\nhttp:\/\/t.co\/s6jt0xIigA",
    "id" : 438695981190635520,
    "created_at" : "2014-02-26 15:24:07 +0000",
    "user" : {
      "name" : "Geoff Teehan",
      "screen_name" : "gt",
      "protected" : false,
      "id_str" : "16655768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1260046647\/t-l_xmas-031_alt8bit_normal.jpg",
      "id" : 16655768,
      "verified" : false
    }
  },
  "id" : 438699726272086016,
  "created_at" : "2014-02-26 15:39:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 95, 100 ],
      "id_str" : "2067141",
      "id" : 2067141
    }, {
      "name" : "magali rodriguez",
      "screen_name" : "magggi",
      "indices" : [ 105, 112 ],
      "id_str" : "208216132",
      "id" : 208216132
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/438558784655339520\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/QrRhWFCPjP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhYS5AxCEAEfNI5.jpg",
      "id_str" : "438558784382701569",
      "id" : 438558784382701569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhYS5AxCEAEfNI5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/QrRhWFCPjP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438558784655339520",
  "text" : "8:36pm DJ Gweeble Gwobble after a super late (by 3yo standards) dinner with our new city mates @jfew and @magggi http:\/\/t.co\/QrRhWFCPjP",
  "id" : 438558784655339520,
  "created_at" : "2014-02-26 06:18:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438428718684332032",
  "geo" : { },
  "id_str" : "438491604257492992",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Yeah not the most bullet-proof models I admit.",
  "id" : 438491604257492992,
  "in_reply_to_status_id" : 438428718684332032,
  "created_at" : "2014-02-26 01:51:59 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 17, 24 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438480300541104128",
  "geo" : { },
  "id_str" : "438482156000522240",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine @Medium That means it's growing because I was 98 on the list last October with 15k views.",
  "id" : 438482156000522240,
  "in_reply_to_status_id" : 438480300541104128,
  "created_at" : "2014-02-26 01:14:27 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristin Carey",
      "screen_name" : "cristin_carey",
      "indices" : [ 0, 14 ],
      "id_str" : "15950030",
      "id" : 15950030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438443150986596352",
  "geo" : { },
  "id_str" : "438446423885889536",
  "in_reply_to_user_id" : 15950030,
  "text" : "@cristin_carey It was a bit rhetorical, I guess. But my instinct is that in most cases the data would soon be outdated.",
  "id" : 438446423885889536,
  "in_reply_to_status_id" : 438443150986596352,
  "created_at" : "2014-02-25 22:52:28 +0000",
  "in_reply_to_screen_name" : "cristin_carey",
  "in_reply_to_user_id_str" : "15950030",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Zack Shapiro",
      "screen_name" : "ZackShapiro",
      "indices" : [ 17, 29 ],
      "id_str" : "15999465",
      "id" : 15999465
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 30, 39 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 40, 52 ],
      "id_str" : "30801469",
      "id" : 30801469
    }, {
      "name" : "Connor Montgomery",
      "screen_name" : "connor",
      "indices" : [ 53, 60 ],
      "id_str" : "60404290",
      "id" : 60404290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438419922079608832",
  "geo" : { },
  "id_str" : "438444879702536192",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine @zackshapiro @eramirez @nickcrocker @connor Hall pass acquired! Weds 3\/5 @ PressClub 6ish.",
  "id" : 438444879702536192,
  "in_reply_to_status_id" : 438419922079608832,
  "created_at" : "2014-02-25 22:46:19 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438425239827910656",
  "text" : "I make mental models of my coworkers and friends with an accuracy at about the level of a 2 month haircut, give or take 2 weeks.",
  "id" : 438425239827910656,
  "created_at" : "2014-02-25 21:28:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438423949387378688",
  "text" : "What's more valuable: all the research and knowledge in the world (but no ability to learn new things) or a research team with no data yet.",
  "id" : 438423949387378688,
  "created_at" : "2014-02-25 21:23:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438391615153926144",
  "geo" : { },
  "id_str" : "438396846352760833",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk Bummed for us but stoked for you! Thanks for your part in convincing me to work here.",
  "id" : 438396846352760833,
  "in_reply_to_status_id" : 438391615153926144,
  "created_at" : "2014-02-25 19:35:27 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Ewing",
      "screen_name" : "hoverbird",
      "indices" : [ 3, 13 ],
      "id_str" : "792690",
      "id" : 792690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438342198879215616",
  "text" : "RT @hoverbird: Everybody thinks \"The Social Network\" is the best movie about forming a new startup, but they are wrong. The best movie is \"\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55703069324873728",
    "text" : "Everybody thinks \"The Social Network\" is the best movie about forming a new startup, but they are wrong. The best movie is \"Ghostbusters\".",
    "id" : 55703069324873728,
    "created_at" : "2011-04-06 18:47:01 +0000",
    "user" : {
      "name" : "Patrick Ewing",
      "screen_name" : "hoverbird",
      "protected" : false,
      "id_str" : "792690",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453590893774118912\/E00Ns3Dq_normal.png",
      "id" : 792690,
      "verified" : false
    }
  },
  "id" : 438342198879215616,
  "created_at" : "2014-02-25 15:58:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/ouJb6ZjLVF",
      "expanded_url" : "http:\/\/flic.kr\/p\/krSqrY",
      "display_url" : "flic.kr\/p\/krSqrY"
    } ]
  },
  "geo" : { },
  "id_str" : "438175071317008384",
  "text" : "8:36pm \"I'll only be able to sing the songs (to Frozen) if it's turned up really loud.\" http:\/\/t.co\/ouJb6ZjLVF",
  "id" : 438175071317008384,
  "created_at" : "2014-02-25 04:54:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 17, 31 ],
      "id_str" : "18749271",
      "id" : 18749271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438157964818411520",
  "geo" : { },
  "id_str" : "438170698263977984",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine @libbybrittain It was 31% in both Dec 2013 and Jan 2014 (starting with 613 and 918, respectively).",
  "id" : 438170698263977984,
  "in_reply_to_status_id" : 438157964818411520,
  "created_at" : "2014-02-25 04:36:49 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 0, 14 ],
      "id_str" : "18749271",
      "id" : 18749271
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 15, 31 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438143502531055616",
  "geo" : { },
  "id_str" : "438147873176162304",
  "in_reply_to_user_id" : 2185,
  "text" : "@libbybrittain @tonystubblebine See also: how many people tweeted about their sucky FlappyBird scores. Solidarity in admitted difficulty.",
  "id" : 438147873176162304,
  "in_reply_to_status_id" : 438143502531055616,
  "created_at" : "2014-02-25 03:06:08 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 0, 14 ],
      "id_str" : "18749271",
      "id" : 18749271
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 15, 31 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438141513152081920",
  "geo" : { },
  "id_str" : "438143502531055616",
  "in_reply_to_user_id" : 18749271,
  "text" : "@libbybrittain @tonystubblebine On 750words the monthly challenge has a daily \"% still in\" number. Makes people in and out feel better.",
  "id" : 438143502531055616,
  "in_reply_to_status_id" : 438141513152081920,
  "created_at" : "2014-02-25 02:48:45 +0000",
  "in_reply_to_screen_name" : "libbybrittain",
  "in_reply_to_user_id_str" : "18749271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "timoni west",
      "screen_name" : "timoni",
      "indices" : [ 0, 7 ],
      "id_str" : "12615",
      "id" : 12615
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 8, 24 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438138401045614592",
  "geo" : { },
  "id_str" : "438139135522402304",
  "in_reply_to_user_id" : 12615,
  "text" : "@timoni @tonystubblebine True. Especially when we've been told lies our whole lives. Who wants to be the Richard Dawkins of weight loss? :)",
  "id" : 438139135522402304,
  "in_reply_to_status_id" : 438138401045614592,
  "created_at" : "2014-02-25 02:31:24 +0000",
  "in_reply_to_screen_name" : "timoni",
  "in_reply_to_user_id_str" : "12615",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "timoni west",
      "screen_name" : "timoni",
      "indices" : [ 0, 7 ],
      "id_str" : "12615",
      "id" : 12615
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 8, 24 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438129837686132736",
  "geo" : { },
  "id_str" : "438131178105610240",
  "in_reply_to_user_id" : 12615,
  "text" : "@timoni @tonystubblebine Tony, you have a chance to be the honest salesman! Long term, we will stick with those we trust. *fistbump*",
  "id" : 438131178105610240,
  "in_reply_to_status_id" : 438129837686132736,
  "created_at" : "2014-02-25 01:59:47 +0000",
  "in_reply_to_screen_name" : "timoni",
  "in_reply_to_user_id_str" : "12615",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Zack Shapiro",
      "screen_name" : "ZackShapiro",
      "indices" : [ 10, 22 ],
      "id_str" : "15999465",
      "id" : 15999465
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 23, 39 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438111174672928768",
  "geo" : { },
  "id_str" : "438111452050640896",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @zackshapiro @tonystubblebine I could possibly do that\u2026 need to double-check.",
  "id" : 438111452050640896,
  "in_reply_to_status_id" : 438111174672928768,
  "created_at" : "2014-02-25 00:41:24 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Zack Shapiro",
      "screen_name" : "ZackShapiro",
      "indices" : [ 17, 29 ],
      "id_str" : "15999465",
      "id" : 15999465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438108611680555008",
  "geo" : { },
  "id_str" : "438108880271183872",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine @zackshapiro Always in for drinks.",
  "id" : 438108880271183872,
  "in_reply_to_status_id" : 438108611680555008,
  "created_at" : "2014-02-25 00:31:11 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Zack Shapiro",
      "screen_name" : "ZackShapiro",
      "indices" : [ 17, 29 ],
      "id_str" : "15999465",
      "id" : 15999465
    }, {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 30, 36 ],
      "id_str" : "42559115",
      "id" : 42559115
    }, {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 37, 51 ],
      "id_str" : "18749271",
      "id" : 18749271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438102006054416384",
  "geo" : { },
  "id_str" : "438103681209102336",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine @ZackShapiro @joshm @libbybrittain A funnel. Show likelihood of quitting each week, and avg weightless of remaining.",
  "id" : 438103681209102336,
  "in_reply_to_status_id" : 438102006054416384,
  "created_at" : "2014-02-25 00:10:31 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Zack Shapiro",
      "screen_name" : "ZackShapiro",
      "indices" : [ 17, 29 ],
      "id_str" : "15999465",
      "id" : 15999465
    }, {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 30, 36 ],
      "id_str" : "42559115",
      "id" : 42559115
    }, {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 37, 51 ],
      "id_str" : "18749271",
      "id" : 18749271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438102006054416384",
  "geo" : { },
  "id_str" : "438103037630889984",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine @ZackShapiro @joshm @libbybrittain Lie, obvs. Wait, you want a non-jerk answer? :)",
  "id" : 438103037630889984,
  "in_reply_to_status_id" : 438102006054416384,
  "created_at" : "2014-02-25 00:07:58 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Shapiro",
      "screen_name" : "ZackShapiro",
      "indices" : [ 0, 12 ],
      "id_str" : "15999465",
      "id" : 15999465
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 13, 29 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 30, 36 ],
      "id_str" : "42559115",
      "id" : 42559115
    }, {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 37, 51 ],
      "id_str" : "18749271",
      "id" : 18749271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438079107784388608",
  "geo" : { },
  "id_str" : "438101437227089920",
  "in_reply_to_user_id" : 15999465,
  "text" : "@ZackShapiro @tonystubblebine @joshm @libbybrittain Tony, what he's trying to say is that ONLY LYING WORKS. We aren't ready for the truth.",
  "id" : 438101437227089920,
  "in_reply_to_status_id" : 438079107784388608,
  "created_at" : "2014-02-25 00:01:36 +0000",
  "in_reply_to_screen_name" : "ZackShapiro",
  "in_reply_to_user_id_str" : "15999465",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 0, 8 ],
      "id_str" : "14097392",
      "id" : 14097392
    }, {
      "name" : "Evan Jacobs",
      "screen_name" : "evanjacobs",
      "indices" : [ 45, 56 ],
      "id_str" : "14803483",
      "id" : 14803483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/V01N0ya7wg",
      "expanded_url" : "http:\/\/authorgraph.com",
      "display_url" : "authorgraph.com"
    } ]
  },
  "in_reply_to_status_id_str" : "438036709192654848",
  "geo" : { },
  "id_str" : "438039911183052801",
  "in_reply_to_user_id" : 14097392,
  "text" : "@nireyal Check out http:\/\/t.co\/V01N0ya7wg by @evanjacobs",
  "id" : 438039911183052801,
  "in_reply_to_status_id" : 438036709192654848,
  "created_at" : "2014-02-24 19:57:07 +0000",
  "in_reply_to_screen_name" : "nireyal",
  "in_reply_to_user_id_str" : "14097392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "AdamSinger",
      "indices" : [ 0, 11 ],
      "id_str" : "14031032",
      "id" : 14031032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438017806131421185",
  "geo" : { },
  "id_str" : "438018289218768897",
  "in_reply_to_user_id" : 14031032,
  "text" : "@adamsinger We totally did! Didn't even realize Sina = Weibo for some reason\u2026 clearly my ability to pick hot stocks needs some improvement.",
  "id" : 438018289218768897,
  "in_reply_to_status_id" : 438017806131421185,
  "created_at" : "2014-02-24 18:31:12 +0000",
  "in_reply_to_screen_name" : "AdamSinger",
  "in_reply_to_user_id_str" : "14031032",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/jt7RzVYPYs",
      "expanded_url" : "http:\/\/www.hongkiat.com\/blog\/things-twitter-can-learn-from-sina-weibo\/",
      "display_url" : "hongkiat.com\/blog\/things-tw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438016305782718464",
  "text" : "8 Things Twitter Can Learn From Weibo (which is apparently going public soon): http:\/\/t.co\/jt7RzVYPYs",
  "id" : 438016305782718464,
  "created_at" : "2014-02-24 18:23:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Winnie Lim",
      "screen_name" : "wynlim",
      "indices" : [ 0, 7 ],
      "id_str" : "7729652",
      "id" : 7729652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437970416330489857",
  "geo" : { },
  "id_str" : "437977628662693888",
  "in_reply_to_user_id" : 7729652,
  "text" : "@wynlim I do the same thing, for the same reasons. Nicely said.",
  "id" : 437977628662693888,
  "in_reply_to_status_id" : 437970416330489857,
  "created_at" : "2014-02-24 15:49:38 +0000",
  "in_reply_to_screen_name" : "wynlim",
  "in_reply_to_user_id_str" : "7729652",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 16, 23 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "John Borthwick",
      "screen_name" : "Borthwick",
      "indices" : [ 104, 114 ],
      "id_str" : "4488",
      "id" : 4488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/juYq7YuzQV",
      "expanded_url" : "https:\/\/medium.com\/p\/4d07472265c7?utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
      "display_url" : "medium.com\/p\/4d07472265c7\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "437965389809451009",
  "geo" : { },
  "id_str" : "437975518982311937",
  "in_reply_to_user_id" : 571202103,
  "text" : "Fascinating: RT @Medium: \u201CWhat can 1000 home screens tell us about the way people use their phones.\u201D by @Borthwick https:\/\/t.co\/juYq7YuzQV",
  "id" : 437975518982311937,
  "in_reply_to_status_id" : 437965389809451009,
  "created_at" : "2014-02-24 15:41:15 +0000",
  "in_reply_to_screen_name" : "Medium",
  "in_reply_to_user_id_str" : "571202103",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437970210897661954",
  "geo" : { },
  "id_str" : "437970469807869953",
  "in_reply_to_user_id" : 2185,
  "text" : "\"Earthquake (magnitude 1). Someone locks their keys in their car.\"",
  "id" : 437970469807869953,
  "in_reply_to_status_id" : 437970210897661954,
  "created_at" : "2014-02-24 15:21:11 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437969876297084928",
  "geo" : { },
  "id_str" : "437970210897661954",
  "in_reply_to_user_id" : 2185,
  "text" : "\"50,000 plastic bottles are produced. Someone in Denver orders a pizza.\"",
  "id" : 437970210897661954,
  "in_reply_to_status_id" : 437969876297084928,
  "created_at" : "2014-02-24 15:20:10 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437969233469652992",
  "geo" : { },
  "id_str" : "437969876297084928",
  "in_reply_to_user_id" : 2185,
  "text" : "\"An airline flight take off. Someone breaks an iPhone screen.\"",
  "id" : 437969876297084928,
  "in_reply_to_status_id" : 437969233469652992,
  "created_at" : "2014-02-24 15:18:50 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/amZgqo7xyq",
      "expanded_url" : "http:\/\/xkcd.com\/1331\/",
      "display_url" : "xkcd.com\/1331\/"
    }, {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/MZxvbCRxlH",
      "expanded_url" : "http:\/\/notebooks.jsvine.com\/reverse-engineering-xkcd-frequency\/",
      "display_url" : "notebooks.jsvine.com\/reverse-engine\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437969233469652992",
  "text" : "Look at this: http:\/\/t.co\/amZgqo7xyq\n\nThen read this: http:\/\/t.co\/MZxvbCRxlH",
  "id" : 437969233469652992,
  "created_at" : "2014-02-24 15:16:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 0, 6 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 7, 20 ],
      "id_str" : "14471007",
      "id" : 14471007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437820665215733760",
  "geo" : { },
  "id_str" : "437820796090605569",
  "in_reply_to_user_id" : 631823,
  "text" : "@couch @dianakimball couch.bike is going to be my next startup\u2026 so the other one.",
  "id" : 437820796090605569,
  "in_reply_to_status_id" : 437820665215733760,
  "created_at" : "2014-02-24 05:26:26 +0000",
  "in_reply_to_screen_name" : "couch",
  "in_reply_to_user_id_str" : "631823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner \u24CB",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/437819990704521216\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/5KZZGExgVS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhNy9jMCEAACJFb.png",
      "id_str" : "437819990528364544",
      "id" : 437819990528364544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhNy9jMCEAACJFb.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 905
      }, {
        "h" : 113,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 905
      } ],
      "display_url" : "pic.twitter.com\/5KZZGExgVS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437819327547326464",
  "geo" : { },
  "id_str" : "437819990704521216",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner http:\/\/t.co\/5KZZGExgVS",
  "id" : 437819990704521216,
  "in_reply_to_status_id" : 437819327547326464,
  "created_at" : "2014-02-24 05:23:14 +0000",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 10, 20 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "poidh",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437816560401805312",
  "geo" : { },
  "id_str" : "437818028990820352",
  "in_reply_to_user_id" : 761628,
  "text" : "@rickwebb @kellianne #poidh",
  "id" : 437818028990820352,
  "in_reply_to_status_id" : 437816560401805312,
  "created_at" : "2014-02-24 05:15:27 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 10, 20 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437816560401805312",
  "geo" : { },
  "id_str" : "437816690772959232",
  "in_reply_to_user_id" : 761628,
  "text" : "@rickwebb @kellianne We were just talking about how we haven't seen you in toooooo loooooong.",
  "id" : 437816690772959232,
  "in_reply_to_status_id" : 437816560401805312,
  "created_at" : "2014-02-24 05:10:07 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/437816426187857920\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/zDCrttU6h3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhNvuETCQAA0982.jpg",
      "id_str" : "437816426003316736",
      "id" : 437816426003316736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhNvuETCQAA0982.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 730
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 730
      } ],
      "display_url" : "pic.twitter.com\/zDCrttU6h3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437816426187857920",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne I need a haircut. http:\/\/t.co\/zDCrttU6h3",
  "id" : 437816426187857920,
  "created_at" : "2014-02-24 05:09:04 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 0, 13 ],
      "id_str" : "14471007",
      "id" : 14471007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437814262833348608",
  "geo" : { },
  "id_str" : "437814644258775040",
  "in_reply_to_user_id" : 14471007,
  "text" : "@dianakimball Oh, bummer. :( Gotta be quick on the netz these days.",
  "id" : 437814644258775040,
  "in_reply_to_status_id" : 437814262833348608,
  "created_at" : "2014-02-24 05:02:00 +0000",
  "in_reply_to_screen_name" : "dianakimball",
  "in_reply_to_user_id_str" : "14471007",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 0, 13 ],
      "id_str" : "14471007",
      "id" : 14471007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437813331593023488",
  "geo" : { },
  "id_str" : "437813630155771904",
  "in_reply_to_user_id" : 14471007,
  "text" : "@dianakimball Could &amp; should. Actually I think .land could be pretty awesome for first names.",
  "id" : 437813630155771904,
  "in_reply_to_status_id" : 437813331593023488,
  "created_at" : "2014-02-24 04:57:58 +0000",
  "in_reply_to_screen_name" : "dianakimball",
  "in_reply_to_user_id_str" : "14471007",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/RDliaEGaAe",
      "expanded_url" : "http:\/\/parislemon.com\/post\/77616021628\/yeah-ive-got-that-on-my-list-so-im-okay",
      "display_url" : "parislemon.com\/post\/776160216\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "437812799251562497",
  "geo" : { },
  "id_str" : "437813251632422913",
  "in_reply_to_user_id" : 2185,
  "text" : "And more gems from Bill Gates in 1998 on the Internet: \"Yeah, I\u2019ve got that on my list, so I\u2019m okay.\" http:\/\/t.co\/RDliaEGaAe",
  "id" : 437813251632422913,
  "in_reply_to_status_id" : 437812799251562497,
  "created_at" : "2014-02-24 04:56:28 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437812799251562497",
  "text" : "\"As an act of leadership I had to create a sense of crisis &amp; we spent a couple mos throwing ideas\/email around &amp; we went on some retreats.\"",
  "id" : 437812799251562497,
  "created_at" : "2014-02-24 04:54:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/99FY1SuU2C",
      "expanded_url" : "http:\/\/iwantmyname.com",
      "display_url" : "iwantmyname.com"
    } ]
  },
  "geo" : { },
  "id_str" : "437811852391620608",
  "text" : "Stoked that buster.guru is available for  me to pick up on http:\/\/t.co\/99FY1SuU2C.",
  "id" : 437811852391620608,
  "created_at" : "2014-02-24 04:50:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mina Doroud",
      "screen_name" : "MMiiina",
      "indices" : [ 0, 8 ],
      "id_str" : "44690011",
      "id" : 44690011
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 9, 19 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437810647229681664",
  "geo" : { },
  "id_str" : "437810758307418112",
  "in_reply_to_user_id" : 44690011,
  "text" : "@mmiiina @kellianne Thanks! Going on 6 years now.",
  "id" : 437810758307418112,
  "in_reply_to_status_id" : 437810647229681664,
  "created_at" : "2014-02-24 04:46:33 +0000",
  "in_reply_to_screen_name" : "MMiiina",
  "in_reply_to_user_id_str" : "44690011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 15, 25 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/437810052137644032\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ajNqomPQJt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhNp7C_CAAAc37D.jpg",
      "id_str" : "437810051919511552",
      "id" : 437810051919511552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhNp7C_CAAAc37D.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/ajNqomPQJt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437810052137644032",
  "text" : "8:36pm Showing @kellianne how little someone needs to do before I unfollow\/block someone. Try me! http:\/\/t.co\/ajNqomPQJt",
  "id" : 437810052137644032,
  "created_at" : "2014-02-24 04:43:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mark pincus",
      "screen_name" : "markpinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13198",
      "id" : 13198
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/supercharts\/status\/437673011093573632\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/2GTapF4G3y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhLtSNYCQAA6ZJ0.png",
      "id_str" : "437673010892259328",
      "id" : 437673010892259328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhLtSNYCQAA6ZJ0.png",
      "sizes" : [ {
        "h" : 314,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 913
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 913
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2GTapF4G3y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437808619497598976",
  "text" : "RT @markpinc: The new risk board. Clearly late in the game. Down to two players unless someone flips the board. http:\/\/t.co\/2GTapF4G3y\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/supercharts\/status\/437673011093573632\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/2GTapF4G3y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhLtSNYCQAA6ZJ0.png",
        "id_str" : "437673010892259328",
        "id" : 437673010892259328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhLtSNYCQAA6ZJ0.png",
        "sizes" : [ {
          "h" : 314,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 913
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 913
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2GTapF4G3y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "437725473104068608",
    "text" : "The new risk board. Clearly late in the game. Down to two players unless someone flips the board. http:\/\/t.co\/2GTapF4G3y\u201D",
    "id" : 437725473104068608,
    "created_at" : "2014-02-23 23:07:39 +0000",
    "user" : {
      "name" : "mark pincus",
      "screen_name" : "markpinc",
      "protected" : false,
      "id_str" : "13198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757022081\/markpincus_normal.png",
      "id" : 13198,
      "verified" : true
    }
  },
  "id" : 437808619497598976,
  "created_at" : "2014-02-24 04:38:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marty Cagan",
      "screen_name" : "cagan",
      "indices" : [ 3, 9 ],
      "id_str" : "18847562",
      "id" : 18847562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/lud9Ldc7va",
      "expanded_url" : "http:\/\/www.svpg.com\/the-role-of-analytics\/",
      "display_url" : "svpg.com\/the-role-of-an\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437782781209235456",
  "text" : "RT @cagan: just posted on the role of analytics in strong product teams: http:\/\/t.co\/lud9Ldc7va",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/lud9Ldc7va",
        "expanded_url" : "http:\/\/www.svpg.com\/the-role-of-analytics\/",
        "display_url" : "svpg.com\/the-role-of-an\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "437778511302885376",
    "text" : "just posted on the role of analytics in strong product teams: http:\/\/t.co\/lud9Ldc7va",
    "id" : 437778511302885376,
    "created_at" : "2014-02-24 02:38:25 +0000",
    "user" : {
      "name" : "Marty Cagan",
      "screen_name" : "cagan",
      "protected" : false,
      "id_str" : "18847562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/70547440\/cagan_low_res_normal.jpg",
      "id" : 18847562,
      "verified" : false
    }
  },
  "id" : 437782781209235456,
  "created_at" : "2014-02-24 02:55:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/437749389906309120\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/0nLBWLvafi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhMywCSCYAAhoSS.jpg",
      "id_str" : "437749389612703744",
      "id" : 437749389612703744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhMywCSCYAAhoSS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0nLBWLvafi"
    } ],
    "hashtags" : [ {
      "text" : "california",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437749389906309120",
  "text" : "#california http:\/\/t.co\/0nLBWLvafi",
  "id" : 437749389906309120,
  "created_at" : "2014-02-24 00:42:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437691653243953152",
  "text" : "All newts are salamanders.",
  "id" : 437691653243953152,
  "created_at" : "2014-02-23 20:53:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/axyAc44r3R",
      "expanded_url" : "http:\/\/flic.kr\/p\/knghfT",
      "display_url" : "flic.kr\/p\/knghfT"
    } ]
  },
  "geo" : { },
  "id_str" : "437452746573504512",
  "text" : "8:36pm Niko finds a cat on the the bike ride home. \"Her fluff sparkles in the night.\" http:\/\/t.co\/axyAc44r3R",
  "id" : 437452746573504512,
  "created_at" : "2014-02-23 05:03:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    }, {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 11, 19 ],
      "id_str" : "9525212",
      "id" : 9525212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437444998087192576",
  "geo" : { },
  "id_str" : "437446335868833792",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel @dandean This is getting a beet out of hand.",
  "id" : 437446335868833792,
  "in_reply_to_status_id" : 437444998087192576,
  "created_at" : "2014-02-23 04:38:28 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437351337739554816",
  "geo" : { },
  "id_str" : "437351988880101376",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Can\u2019t beet it!",
  "id" : 437351988880101376,
  "in_reply_to_status_id" : 437351337739554816,
  "created_at" : "2014-02-22 22:23:34 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/QT2egpWZaJ",
      "expanded_url" : "http:\/\/www.ribbonfarm.com\/2012\/05\/09\/welcome-to-the-future-nauseous\/",
      "display_url" : "ribbonfarm.com\/2012\/05\/09\/wel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437334432018485248",
  "text" : "\u201CSomehow, the future always seems like something that is going to happen rather than something that is happening.\u201D http:\/\/t.co\/QT2egpWZaJ",
  "id" : 437334432018485248,
  "created_at" : "2014-02-22 21:13:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437305154774110208",
  "text" : "Yay taxes.",
  "id" : 437305154774110208,
  "created_at" : "2014-02-22 19:17:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437278038401613824",
  "geo" : { },
  "id_str" : "437278101777571840",
  "in_reply_to_user_id" : 2185,
  "text" : "Like this.",
  "id" : 437278101777571840,
  "in_reply_to_status_id" : 437278038401613824,
  "created_at" : "2014-02-22 17:29:58 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437278038401613824",
  "text" : "I've been noticing more people replying to their own tweets in order to share longer thoughts. I like it.",
  "id" : 437278038401613824,
  "created_at" : "2014-02-22 17:29:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 0, 6 ],
      "id_str" : "5469512",
      "id" : 5469512
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 7, 16 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437274803905372160",
  "geo" : { },
  "id_str" : "437275660201902080",
  "in_reply_to_user_id" : 5469512,
  "text" : "@micah @arainert What does the drop off curve look like? Are there distinct patterns? Do good comics create different behaviors than others?",
  "id" : 437275660201902080,
  "in_reply_to_status_id" : 437274803905372160,
  "created_at" : "2014-02-22 17:20:16 +0000",
  "in_reply_to_screen_name" : "micah",
  "in_reply_to_user_id_str" : "5469512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437251595148230656",
  "geo" : { },
  "id_str" : "437273226188566529",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert I did verify with someone on the team that they have this data. Unfortunately they are too afraid to share it. Aka: nobody reads.",
  "id" : 437273226188566529,
  "in_reply_to_status_id" : 437251595148230656,
  "created_at" : "2014-02-22 17:10:35 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437093212386103296",
  "geo" : { },
  "id_str" : "437093323602288640",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Cool, thanks. Have a nice walk.",
  "id" : 437093323602288640,
  "in_reply_to_status_id" : 437093212386103296,
  "created_at" : "2014-02-22 05:15:43 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437092868012793856",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Random question: Have you seen any QS people do cool things with EXIF data from photos?  What useful meaning is in there?",
  "id" : 437092868012793856,
  "created_at" : "2014-02-22 05:13:55 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 10, 22 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437091863804121088",
  "geo" : { },
  "id_str" : "437092151231397888",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @GetReporter Yeah, agreed. So nice to have an open channel for feedback, questions, etc.",
  "id" : 437092151231397888,
  "in_reply_to_status_id" : 437091863804121088,
  "created_at" : "2014-02-22 05:11:04 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 30, 42 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/p4dT9pSmSL",
      "expanded_url" : "http:\/\/flic.kr\/p\/kkjjrF",
      "display_url" : "flic.kr\/p\/kkjjrF"
    } ]
  },
  "geo" : { },
  "id_str" : "437091617280114688",
  "text" : "8:36pm Reading through all of @getreporter's replies since they talk a lot about future plans. Working on an... http:\/\/t.co\/p4dT9pSmSL",
  "id" : 437091617280114688,
  "created_at" : "2014-02-22 05:08:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 3, 14 ],
      "id_str" : "5971922",
      "id" : 5971922
    }, {
      "name" : "Pomplamoose",
      "screen_name" : "pomplamoose",
      "indices" : [ 17, 29 ],
      "id_str" : "20967403",
      "id" : 20967403
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BoingBoing\/status\/437055413956399104\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/LD1EQgrlRE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhC7lUnIMAE3aR9.png",
      "id_str" : "437055413717315585",
      "id" : 437055413717315585,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhC7lUnIMAE3aR9.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 838,
        "resize" : "fit",
        "w" : 1311
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LD1EQgrlRE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Q2Ydtiho6Z",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/02\/21\/pomplamooses-one-take-proje.html",
      "display_url" : "boingboing.net\/2014\/02\/21\/pom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437069675545903105",
  "text" : "RT @BoingBoing: .@pomplamoose's mashup of \"Happy\" and \"Get Lucky\" isn't just a great song -- it's a fantastic\u2026 http:\/\/t.co\/Q2Ydtiho6Z http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pomplamoose",
        "screen_name" : "pomplamoose",
        "indices" : [ 1, 13 ],
        "id_str" : "20967403",
        "id" : 20967403
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BoingBoing\/status\/437055413956399104\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/LD1EQgrlRE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhC7lUnIMAE3aR9.png",
        "id_str" : "437055413717315585",
        "id" : 437055413717315585,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhC7lUnIMAE3aR9.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 838,
          "resize" : "fit",
          "w" : 1311
        }, {
          "h" : 655,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LD1EQgrlRE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/Q2Ydtiho6Z",
        "expanded_url" : "http:\/\/boingboing.net\/2014\/02\/21\/pomplamooses-one-take-proje.html",
        "display_url" : "boingboing.net\/2014\/02\/21\/pom\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "437055413956399104",
    "text" : ".@pomplamoose's mashup of \"Happy\" and \"Get Lucky\" isn't just a great song -- it's a fantastic\u2026 http:\/\/t.co\/Q2Ydtiho6Z http:\/\/t.co\/LD1EQgrlRE",
    "id" : 437055413956399104,
    "created_at" : "2014-02-22 02:45:05 +0000",
    "user" : {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "protected" : false,
      "id_str" : "5971922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3096579761\/a3c23a9715fe1add47f17e2ae101f53f_normal.png",
      "id" : 5971922,
      "verified" : true
    }
  },
  "id" : 437069675545903105,
  "created_at" : "2014-02-22 03:41:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Marc Andreessen",
      "screen_name" : "pmarca",
      "indices" : [ 8, 15 ],
      "id_str" : "5943622",
      "id" : 5943622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/Tsmgc1mvb9",
      "expanded_url" : "http:\/\/compete.com",
      "display_url" : "compete.com"
    } ]
  },
  "in_reply_to_status_id_str" : "437013492424794112",
  "geo" : { },
  "id_str" : "437015764684378112",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @pmarca According to http:\/\/t.co\/Tsmgc1mvb9 which is often way off, it gets about 95M MAU in the US.",
  "id" : 437015764684378112,
  "in_reply_to_status_id" : 437013492424794112,
  "created_at" : "2014-02-22 00:07:32 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ReadWrite",
      "screen_name" : "RWW",
      "indices" : [ 21, 25 ],
      "id_str" : "4641021",
      "id" : 4641021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/RENbBmDfh2",
      "expanded_url" : "http:\/\/w.readwrite.com\/1daZ6ow",
      "display_url" : "w.readwrite.com\/1daZ6ow"
    } ]
  },
  "in_reply_to_status_id_str" : "436981405789081600",
  "geo" : { },
  "id_str" : "436982281186467840",
  "in_reply_to_user_id" : 4641021,
  "text" : "Interesting \u2014&gt; RT @RWW: Google's latest ambitious project aims to help mobile devices understand their environments http:\/\/t.co\/RENbBmDfh2",
  "id" : 436982281186467840,
  "in_reply_to_status_id" : 436981405789081600,
  "created_at" : "2014-02-21 21:54:29 +0000",
  "in_reply_to_screen_name" : "RWW",
  "in_reply_to_user_id_str" : "4641021",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Knauss",
      "screen_name" : "gknauss",
      "indices" : [ 108, 116 ],
      "id_str" : "3163591",
      "id" : 3163591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ixXX8fjit1",
      "expanded_url" : "http:\/\/www.eod.com\/blog\/2014\/02\/empathy-vacuum\/",
      "display_url" : "eod.com\/blog\/2014\/02\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436965295899430912",
  "text" : "\"3 essential tools that online life requires: a sense of humor, a sense of perspective and a thick skin.\" - @gknauss http:\/\/t.co\/ixXX8fjit1",
  "id" : 436965295899430912,
  "created_at" : "2014-02-21 20:46:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/7efkpq8ppP",
      "expanded_url" : "http:\/\/flic.kr\/p\/kiBQJJ",
      "display_url" : "flic.kr\/p\/kiBQJJ"
    } ]
  },
  "geo" : { },
  "id_str" : "436738970815594496",
  "text" : "8:36pm Dinner date at Wood Tavern http:\/\/t.co\/7efkpq8ppP",
  "id" : 436738970815594496,
  "created_at" : "2014-02-21 05:47:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Underwood",
      "screen_name" : "aunder",
      "indices" : [ 0, 7 ],
      "id_str" : "4265731",
      "id" : 4265731
    }, {
      "name" : "Zhanna Shamis",
      "screen_name" : "Zhanna",
      "indices" : [ 115, 122 ],
      "id_str" : "51573",
      "id" : 51573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436701570621648896",
  "geo" : { },
  "id_str" : "436702407599222784",
  "in_reply_to_user_id" : 4265731,
  "text" : "@aunder It's almost as good as asking to use someone's phone for a sec &amp; checking their notifications tab. Got @zhanna's secrets yesterday.",
  "id" : 436702407599222784,
  "in_reply_to_status_id" : 436701570621648896,
  "created_at" : "2014-02-21 03:22:22 +0000",
  "in_reply_to_screen_name" : "aunder",
  "in_reply_to_user_id_str" : "4265731",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436701422667563008",
  "text" : "I'm bummed I recently erased everyone's phone numbers from my phone and am probably missing all their Secrets. DM me your number please!",
  "id" : 436701422667563008,
  "created_at" : "2014-02-21 03:18:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436643166972678145",
  "geo" : { },
  "id_str" : "436643760710369280",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Would be happy to help! Though my tracking has always been a bit chaotic.",
  "id" : 436643760710369280,
  "in_reply_to_status_id" : 436643166972678145,
  "created_at" : "2014-02-20 23:29:19 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436641243859128320",
  "geo" : { },
  "id_str" : "436643056909950977",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Do it!",
  "id" : 436643056909950977,
  "in_reply_to_status_id" : 436641243859128320,
  "created_at" : "2014-02-20 23:26:31 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/SiyYZnjp3b",
      "expanded_url" : "https:\/\/medium.com\/p\/3f606bf985c6",
      "display_url" : "medium.com\/p\/3f606bf985c6"
    } ]
  },
  "geo" : { },
  "id_str" : "436642953021243392",
  "text" : "It was only 10 yrs ago when browsers added a search box. Mobile still lacks that ability to find stuff efficiently. https:\/\/t.co\/SiyYZnjp3b",
  "id" : 436642953021243392,
  "created_at" : "2014-02-20 23:26:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/436362706988179456\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/f1cuYPN6tc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bg5FkddCMAEWkcs.jpg",
      "id_str" : "436362706585530369",
      "id" : 436362706585530369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bg5FkddCMAEWkcs.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/f1cuYPN6tc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436362706988179456",
  "text" : "8:36pm Team dinner celebrating stuff http:\/\/t.co\/f1cuYPN6tc",
  "id" : 436362706988179456,
  "created_at" : "2014-02-20 04:52:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny",
      "screen_name" : "Danny73078462",
      "indices" : [ 0, 14 ],
      "id_str" : "1449918571",
      "id" : 1449918571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/ulDgUG04cy",
      "expanded_url" : "http:\/\/pic.twitter.com",
      "display_url" : "pic.twitter.com"
    } ]
  },
  "in_reply_to_status_id_str" : "436284068410306560",
  "geo" : { },
  "id_str" : "436287371139907584",
  "in_reply_to_user_id" : 1449918571,
  "text" : "@Danny73078462 No, only http:\/\/t.co\/ulDgUG04cy images are auto-expanded at the moment.",
  "id" : 436287371139907584,
  "in_reply_to_status_id" : 436284068410306560,
  "created_at" : "2014-02-19 23:53:09 +0000",
  "in_reply_to_screen_name" : "Danny73078462",
  "in_reply_to_user_id_str" : "1449918571",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436263367158685696",
  "text" : "$$$$$$$$$$$$$$$$",
  "id" : 436263367158685696,
  "created_at" : "2014-02-19 22:17:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "indices" : [ 0, 5 ],
      "id_str" : "10221",
      "id" : 10221
    }, {
      "name" : "Adam Singer",
      "screen_name" : "AdamSinger",
      "indices" : [ 6, 17 ],
      "id_str" : "14031032",
      "id" : 14031032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436193907672481792",
  "geo" : { },
  "id_str" : "436249547744899072",
  "in_reply_to_user_id" : 10221,
  "text" : "@drew @adamsinger I thought I was going to finally meet the infamous Drew. Maybe next time? Thanks for lunch, Adam!",
  "id" : 436249547744899072,
  "in_reply_to_status_id" : 436193907672481792,
  "created_at" : "2014-02-19 21:22:51 +0000",
  "in_reply_to_screen_name" : "drew",
  "in_reply_to_user_id_str" : "10221",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "AdamSinger",
      "indices" : [ 18, 29 ],
      "id_str" : "14031032",
      "id" : 14031032
    }, {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 34, 41 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/fyEcp6vQ0A",
      "expanded_url" : "http:\/\/4sq.com\/1kY5JlW",
      "display_url" : "4sq.com\/1kY5JlW"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7900399636, -122.3900663853 ]
  },
  "id_str" : "436225927874629632",
  "text" : "Meeting the other @adamsinger (at @Google San Francisco w\/ 12 others) http:\/\/t.co\/fyEcp6vQ0A",
  "id" : 436225927874629632,
  "created_at" : "2014-02-19 19:49:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436222421436080128",
  "geo" : { },
  "id_str" : "436222548359929856",
  "in_reply_to_user_id" : 2185,
  "text" : "I love Ray Kurzweil.",
  "id" : 436222548359929856,
  "in_reply_to_status_id" : 436222421436080128,
  "created_at" : "2014-02-19 19:35:34 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/sJAEKs4cCp",
      "expanded_url" : "http:\/\/jimidisu.com\/?p=6013",
      "display_url" : "jimidisu.com\/?p=6013"
    } ]
  },
  "geo" : { },
  "id_str" : "436222421436080128",
  "text" : "\u201CWe back up our computers but we don\u2019t back up the most important info we have: our memories, skills, &amp; personality.\u201D http:\/\/t.co\/sJAEKs4cCp",
  "id" : 436222421436080128,
  "created_at" : "2014-02-19 19:35:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436206983625322496",
  "geo" : { },
  "id_str" : "436207284058726400",
  "in_reply_to_user_id" : 761628,
  "text" : "@rickwebb Tech talent, absolutely. Their DNA is content. Netflix's DNA is tech.",
  "id" : 436207284058726400,
  "in_reply_to_status_id" : 436206983625322496,
  "created_at" : "2014-02-19 18:34:55 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436204259185803264",
  "geo" : { },
  "id_str" : "436206334988414976",
  "in_reply_to_user_id" : 761628,
  "text" : "@rickwebb Do you think their analytics are as sophisticated as Netflix's? Imprecise\/incomplete analytics can hurt more than help.",
  "id" : 436206334988414976,
  "in_reply_to_status_id" : 436204259185803264,
  "created_at" : "2014-02-19 18:31:09 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/qjYNI0XOoi",
      "expanded_url" : "http:\/\/wayoftheduck.com\/smarter-than-smart",
      "display_url" : "wayoftheduck.com\/smarter-than-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436205314161913857",
  "text" : "Smart Version 1: Know the answer to question X.\n\nSmart Version 2: Know how to find the answer to question X.\n\nhttp:\/\/t.co\/qjYNI0XOoi",
  "id" : 436205314161913857,
  "created_at" : "2014-02-19 18:27:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "AdamSinger",
      "indices" : [ 0, 11 ],
      "id_str" : "14031032",
      "id" : 14031032
    }, {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "indices" : [ 12, 17 ],
      "id_str" : "10221",
      "id" : 10221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436194605155889153",
  "geo" : { },
  "id_str" : "436197850221785088",
  "in_reply_to_user_id" : 14031032,
  "text" : "@adamsinger @drew Uh oh.",
  "id" : 436197850221785088,
  "in_reply_to_status_id" : 436194605155889153,
  "created_at" : "2014-02-19 17:57:26 +0000",
  "in_reply_to_screen_name" : "AdamSinger",
  "in_reply_to_user_id_str" : "14031032",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "AdamSinger",
      "indices" : [ 0, 11 ],
      "id_str" : "14031032",
      "id" : 14031032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436188658803015681",
  "geo" : { },
  "id_str" : "436193813187399680",
  "in_reply_to_user_id" : 14031032,
  "text" : "@adamsinger Me too!",
  "id" : 436193813187399680,
  "in_reply_to_status_id" : 436188658803015681,
  "created_at" : "2014-02-19 17:41:23 +0000",
  "in_reply_to_screen_name" : "AdamSinger",
  "in_reply_to_user_id_str" : "14031032",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 123, 132 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 133, 139 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/gnTxv20Mpo",
      "expanded_url" : "http:\/\/www.marketplace.org\/topics\/business\/what-happens-netflix-when-house-cards-goes-live?utm_content=buffer64e75&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "marketplace.org\/topics\/busines\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436163642833117184",
  "text" : "\"I think right now Netflix does have a competitive advantage over HBO because of the analytics\" http:\/\/t.co\/gnTxv20Mpo \/cc @RickWebb @joshc",
  "id" : 436163642833117184,
  "created_at" : "2014-02-19 15:41:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436158034406940672",
  "geo" : { },
  "id_str" : "436160655607881731",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker That seems like a great fit. Congrats!",
  "id" : 436160655607881731,
  "in_reply_to_status_id" : 436158034406940672,
  "created_at" : "2014-02-19 15:29:38 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/m88w2nrRx6",
      "expanded_url" : "http:\/\/flic.kr\/p\/keWYmH",
      "display_url" : "flic.kr\/p\/keWYmH"
    } ]
  },
  "geo" : { },
  "id_str" : "436021516208443392",
  "text" : "8:36pm Thinking about personas http:\/\/t.co\/m88w2nrRx6",
  "id" : 436021516208443392,
  "created_at" : "2014-02-19 06:16:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    }, {
      "name" : "Kevin Marks",
      "screen_name" : "kevinmarks",
      "indices" : [ 6, 17 ],
      "id_str" : "57203",
      "id" : 57203
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 18, 25 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435671297448628225",
  "geo" : { },
  "id_str" : "435671720830050304",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara @kevinmarks @isaach I have 100% control of nothing. Long live the internet.",
  "id" : 435671720830050304,
  "in_reply_to_status_id" : 435671297448628225,
  "created_at" : "2014-02-18 07:06:47 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/435669402931851264\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/wTfjm7kJBj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgvPA3UCEAA9Q3P.jpg",
      "id_str" : "435669402726305792",
      "id" : 435669402726305792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgvPA3UCEAA9Q3P.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wTfjm7kJBj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435669402931851264",
  "text" : "8:36pm The Face of Bus http:\/\/t.co\/wTfjm7kJBj",
  "id" : 435669402931851264,
  "created_at" : "2014-02-18 06:57:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    }, {
      "name" : "Kevin Marks",
      "screen_name" : "kevinmarks",
      "indices" : [ 6, 17 ],
      "id_str" : "57203",
      "id" : 57203
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 18, 25 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435655335164932097",
  "geo" : { },
  "id_str" : "435660107800535042",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara @kevinmarks @isaach I'm fine with that these days. Though I generally find I need to pick one URL to be the primary one.",
  "id" : 435660107800535042,
  "in_reply_to_status_id" : 435655335164932097,
  "created_at" : "2014-02-18 06:20:38 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435649619070971905",
  "geo" : { },
  "id_str" : "435650037314375680",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach I've actually been pro-Medium for a while now, but starting to come back to my own custom-domain blog. What about you?",
  "id" : 435650037314375680,
  "in_reply_to_status_id" : 435649619070971905,
  "created_at" : "2014-02-18 05:40:37 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/xV3cj74J6w",
      "expanded_url" : "http:\/\/medium.com\/@buster",
      "display_url" : "medium.com\/@buster"
    }, {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/tJIh6O3LhU",
      "expanded_url" : "http:\/\/wayoftheduck.com",
      "display_url" : "wayoftheduck.com"
    } ]
  },
  "geo" : { },
  "id_str" : "435648731971481600",
  "text" : "Wavering between posting on Medium (http:\/\/t.co\/xV3cj74J6w) and Svbtle (http:\/\/t.co\/tJIh6O3LhU). Different pros\/cons for each.",
  "id" : 435648731971481600,
  "created_at" : "2014-02-18 05:35:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wayoftheduck",
      "indices" : [ 70, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/qjYNI0XOoi",
      "expanded_url" : "http:\/\/wayoftheduck.com\/smarter-than-smart",
      "display_url" : "wayoftheduck.com\/smarter-than-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435645772793528321",
  "text" : "How to be smarter than smart, a new blog post: http:\/\/t.co\/qjYNI0XOoi #wayoftheduck",
  "id" : 435645772793528321,
  "created_at" : "2014-02-18 05:23:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yuki suda",
      "screen_name" : "yukisuda2",
      "indices" : [ 0, 10 ],
      "id_str" : "725767158",
      "id" : 725767158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435625029519147008",
  "geo" : { },
  "id_str" : "435625503169318912",
  "in_reply_to_user_id" : 725767158,
  "text" : "@yukisuda2 10 different tweets. They can all be from the same account pointing to the same URL. But the URL needs to have cards implemented.",
  "id" : 435625503169318912,
  "in_reply_to_status_id" : 435625029519147008,
  "created_at" : "2014-02-18 04:03:08 +0000",
  "in_reply_to_screen_name" : "yukisuda2",
  "in_reply_to_user_id_str" : "725767158",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yuki suda",
      "screen_name" : "yukisuda2",
      "indices" : [ 0, 10 ],
      "id_str" : "725767158",
      "id" : 725767158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435622693254086656",
  "geo" : { },
  "id_str" : "435623118321618944",
  "in_reply_to_user_id" : 725767158,
  "text" : "@yukisuda2 I only monitor the Analytics forum, so I missed that thread. It doesn't need to be 10 diff accounts\u2026 just unique tweets.",
  "id" : 435623118321618944,
  "in_reply_to_status_id" : 435622693254086656,
  "created_at" : "2014-02-18 03:53:39 +0000",
  "in_reply_to_screen_name" : "yukisuda2",
  "in_reply_to_user_id_str" : "725767158",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435612851290390528",
  "geo" : { },
  "id_str" : "435622903246094336",
  "in_reply_to_user_id" : 2185,
  "text" : "\"Innovation is the sum of (behavior) change across the whole system, not a thing which causes a change in how people behave.\"",
  "id" : 435622903246094336,
  "in_reply_to_status_id" : 435612851290390528,
  "created_at" : "2014-02-18 03:52:48 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "enjoy",
      "indices" : [ 127, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/jjAKrTCsKr",
      "expanded_url" : "http:\/\/wayoftheduck.com\/the-concept-of-a-person",
      "display_url" : "wayoftheduck.com\/the-concept-of\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435621927361605632",
  "text" : "A very disorganized and scattered exploration of the concept of a person, in blog form, by yours truly: http:\/\/t.co\/jjAKrTCsKr #enjoy",
  "id" : 435621927361605632,
  "created_at" : "2014-02-18 03:48:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yuki suda",
      "screen_name" : "yukisuda2",
      "indices" : [ 0, 10 ],
      "id_str" : "725767158",
      "id" : 725767158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435619822169124864",
  "geo" : { },
  "id_str" : "435620892320616448",
  "in_reply_to_user_id" : 725767158,
  "text" : "@yukisuda2 I only see 7 unique tweets. Try tweeting links to your site 5 more times (and verify they have cards attached).",
  "id" : 435620892320616448,
  "in_reply_to_status_id" : 435619822169124864,
  "created_at" : "2014-02-18 03:44:48 +0000",
  "in_reply_to_screen_name" : "yukisuda2",
  "in_reply_to_user_id_str" : "725767158",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yuki suda",
      "screen_name" : "yukisuda2",
      "indices" : [ 0, 10 ],
      "id_str" : "725767158",
      "id" : 725767158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/HXtniCCABm",
      "expanded_url" : "https:\/\/dev.twitter.com\/discussions\/analytics",
      "display_url" : "dev.twitter.com\/discussions\/an\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "435616354939322368",
  "geo" : { },
  "id_str" : "435616601421799424",
  "in_reply_to_user_id" : 725767158,
  "text" : "@yukisuda2 I'm happy to help but this is not the best way to get support. Try posting here: https:\/\/t.co\/HXtniCCABm",
  "id" : 435616601421799424,
  "in_reply_to_status_id" : 435616354939322368,
  "created_at" : "2014-02-18 03:27:45 +0000",
  "in_reply_to_screen_name" : "yukisuda2",
  "in_reply_to_user_id_str" : "725767158",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 99, 107 ],
      "id_str" : "5699",
      "id" : 5699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/Ye2LQkKzEl",
      "expanded_url" : "https:\/\/medium.com\/p\/4c59524d650d",
      "display_url" : "medium.com\/p\/4c59524d650d"
    } ]
  },
  "geo" : { },
  "id_str" : "435612851290390528",
  "text" : "\u201CThe best\u200A\u2014\u200Amaybe the only?\u200A\u2014\u200Areal, direct measure of \u201Cinnovation\u201D is change in human behaviour.\u201D \u2014@stewart https:\/\/t.co\/Ye2LQkKzEl",
  "id" : 435612851290390528,
  "created_at" : "2014-02-18 03:12:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435496797285265409",
  "geo" : { },
  "id_str" : "435497662607921153",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Maybe we should create a secret hashtag to let me know when you're trolling me for others benefit?",
  "id" : 435497662607921153,
  "in_reply_to_status_id" : 435496797285265409,
  "created_at" : "2014-02-17 19:35:08 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435495048809955328",
  "geo" : { },
  "id_str" : "435496440819761152",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez See wording of original tweet. I'm shocked that you'd take me for a quick and easy solution seller... ?",
  "id" : 435496440819761152,
  "in_reply_to_status_id" : 435495048809955328,
  "created_at" : "2014-02-17 19:30:17 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 10, 22 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435494741522644992",
  "geo" : { },
  "id_str" : "435494936809443328",
  "in_reply_to_user_id" : 2185,
  "text" : "@eramirez @GetReporter Searching for them is part of the joy and impact of exploration that I hope to encourage.",
  "id" : 435494936809443328,
  "in_reply_to_status_id" : 435494741522644992,
  "created_at" : "2014-02-17 19:24:18 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 10, 22 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435494455798284288",
  "geo" : { },
  "id_str" : "435494741522644992",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @GetReporter When human behavior is concerned I have never found it simple to find correlations.",
  "id" : 435494741522644992,
  "in_reply_to_status_id" : 435494455798284288,
  "created_at" : "2014-02-17 19:23:32 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 10, 22 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435493661900419073",
  "geo" : { },
  "id_str" : "435494091774627840",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @GetReporter Nah, we should just post all correlations willy nilly, and call them causations. :)",
  "id" : 435494091774627840,
  "in_reply_to_status_id" : 435493661900419073,
  "created_at" : "2014-02-17 19:20:57 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hall",
      "screen_name" : "JamesHallPhoto",
      "indices" : [ 0, 15 ],
      "id_str" : "63792306",
      "id" : 63792306
    }, {
      "name" : "Al Jazeera America ",
      "screen_name" : "ajam",
      "indices" : [ 16, 21 ],
      "id_str" : "1178700896",
      "id" : 1178700896
    }, {
      "name" : "Michael Okwu",
      "screen_name" : "MichaelOkwu",
      "indices" : [ 22, 34 ],
      "id_str" : "128894014",
      "id" : 128894014
    }, {
      "name" : "Blackbeard Films ",
      "screen_name" : "blackbeardfilms",
      "indices" : [ 35, 51 ],
      "id_str" : "2228761944",
      "id" : 2228761944
    }, {
      "name" : "Jason Motlagh",
      "screen_name" : "JasonMotlagh",
      "indices" : [ 52, 65 ],
      "id_str" : "1103441054",
      "id" : 1103441054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435476410975522816",
  "geo" : { },
  "id_str" : "435477014066126848",
  "in_reply_to_user_id" : 63792306,
  "text" : "@JamesHallPhoto @ajam @MichaelOkwu @blackbeardfilms @JasonMotlagh Awesome! Will it be available online anywhere?",
  "id" : 435477014066126848,
  "in_reply_to_status_id" : 435476410975522816,
  "created_at" : "2014-02-17 18:13:05 +0000",
  "in_reply_to_screen_name" : "JamesHallPhoto",
  "in_reply_to_user_id_str" : "63792306",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 0, 12 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435476515505971201",
  "in_reply_to_user_id" : 2201640770,
  "text" : "@GetReporter Any plans on helping people find correlations between answers eventually?",
  "id" : 435476515505971201,
  "created_at" : "2014-02-17 18:11:06 +0000",
  "in_reply_to_screen_name" : "GetReporter",
  "in_reply_to_user_id_str" : "2201640770",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 0, 12 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435446077979115520",
  "geo" : { },
  "id_str" : "435446502698131456",
  "in_reply_to_user_id" : 2201640770,
  "text" : "@GetReporter For example, I would love to track pushups in Reporter but don't want it to ask me every time.",
  "id" : 435446502698131456,
  "in_reply_to_status_id" : 435446077979115520,
  "created_at" : "2014-02-17 16:11:51 +0000",
  "in_reply_to_screen_name" : "GetReporter",
  "in_reply_to_user_id_str" : "2201640770",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 0, 12 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435444711851954176",
  "in_reply_to_user_id" : 2201640770,
  "text" : "@GetReporter Feature request: ability to store ad hoc questions that don't get asked at wake\/day\/sleep but can be answered when relevant.",
  "id" : 435444711851954176,
  "created_at" : "2014-02-17 16:04:44 +0000",
  "in_reply_to_screen_name" : "GetReporter",
  "in_reply_to_user_id_str" : "2201640770",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "First Round Capital",
      "screen_name" : "firstround",
      "indices" : [ 10, 21 ],
      "id_str" : "15307727",
      "id" : 15307727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435410802888421376",
  "geo" : { },
  "id_str" : "435443346056560640",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert @firstround I enjoyed that article. Do you know anyone that uses her leadership coaching?",
  "id" : 435443346056560640,
  "in_reply_to_status_id" : 435410802888421376,
  "created_at" : "2014-02-17 15:59:18 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "Simon Rogers",
      "screen_name" : "smfrogers",
      "indices" : [ 35, 45 ],
      "id_str" : "14420872",
      "id" : 14420872
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ET702",
      "indices" : [ 59, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/jRGRlPSOvo",
      "expanded_url" : "https:\/\/twitter.com\/smfrogers\/timelines\/435284121456107520",
      "display_url" : "twitter.com\/smfrogers\/time\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435311073650958336",
  "text" : "RT @isaach: a custom timeline from @smfrogers covering the #ET702 hijacking https:\/\/t.co\/jRGRlPSOvo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Simon Rogers",
        "screen_name" : "smfrogers",
        "indices" : [ 23, 33 ],
        "id_str" : "14420872",
        "id" : 14420872
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ET702",
        "indices" : [ 47, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/jRGRlPSOvo",
        "expanded_url" : "https:\/\/twitter.com\/smfrogers\/timelines\/435284121456107520",
        "display_url" : "twitter.com\/smfrogers\/time\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "435299039991435264",
    "text" : "a custom timeline from @smfrogers covering the #ET702 hijacking https:\/\/t.co\/jRGRlPSOvo",
    "id" : 435299039991435264,
    "created_at" : "2014-02-17 06:25:53 +0000",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430605387117494272\/lmplHwca_normal.png",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 435311073650958336,
  "created_at" : "2014-02-17 07:13:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 10, 17 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435293925067079680",
  "geo" : { },
  "id_str" : "435294817593987072",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @cwhogg Partially because it requires us to first prove lots of our overly-simplistic\/wishful thinking hypotheses wrong.",
  "id" : 435294817593987072,
  "in_reply_to_status_id" : 435293925067079680,
  "created_at" : "2014-02-17 06:09:06 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/zjzuTnsMv1",
      "expanded_url" : "http:\/\/flic.kr\/p\/kaRBQM",
      "display_url" : "flic.kr\/p\/kaRBQM"
    } ]
  },
  "geo" : { },
  "id_str" : "435293093487992832",
  "text" : "8:36pm House of Cards (and Laundry) http:\/\/t.co\/zjzuTnsMv1",
  "id" : 435293093487992832,
  "created_at" : "2014-02-17 06:02:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benny Wong",
      "screen_name" : "bdotdub",
      "indices" : [ 0, 8 ],
      "id_str" : "3032241",
      "id" : 3032241
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 9, 18 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435283420655386624",
  "geo" : { },
  "id_str" : "435292040637599744",
  "in_reply_to_user_id" : 3032241,
  "text" : "@bdotdub @eramirez The signals aren't that strong. If anything they help me understand the value of keeping options open.",
  "id" : 435292040637599744,
  "in_reply_to_status_id" : 435283420655386624,
  "created_at" : "2014-02-17 05:58:04 +0000",
  "in_reply_to_screen_name" : "bdotdub",
  "in_reply_to_user_id_str" : "3032241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Benny Wong",
      "screen_name" : "bdotdub",
      "indices" : [ 10, 18 ],
      "id_str" : "3032241",
      "id" : 3032241
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 102, 110 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435279144083922946",
  "geo" : { },
  "id_str" : "435280023046471680",
  "in_reply_to_user_id" : 2185,
  "text" : "@eramirez @bdotdub That said, biggest life change from QS to date came from finding a half-brother in @23andme data last week.",
  "id" : 435280023046471680,
  "in_reply_to_status_id" : 435279144083922946,
  "created_at" : "2014-02-17 05:10:19 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Benny Wong",
      "screen_name" : "bdotdub",
      "indices" : [ 10, 18 ],
      "id_str" : "3032241",
      "id" : 3032241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435276283077881856",
  "geo" : { },
  "id_str" : "435279144083922946",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @bdotdub Good ones. Basically only track as means for user research on self. Zero in on biggest questions, track strongest signal.",
  "id" : 435279144083922946,
  "in_reply_to_status_id" : 435276283077881856,
  "created_at" : "2014-02-17 05:06:49 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Benny Wong",
      "screen_name" : "bdotdub",
      "indices" : [ 10, 18 ],
      "id_str" : "3032241",
      "id" : 3032241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435275620801474560",
  "geo" : { },
  "id_str" : "435278519384297472",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @bdotdub I saw that too and almost copied but in the end words are better tokens for emotion than emoji.",
  "id" : 435278519384297472,
  "in_reply_to_status_id" : 435275620801474560,
  "created_at" : "2014-02-17 05:04:20 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benny Wong",
      "screen_name" : "bdotdub",
      "indices" : [ 0, 8 ],
      "id_str" : "3032241",
      "id" : 3032241
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 9, 18 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435274956201406466",
  "geo" : { },
  "id_str" : "435275312717262848",
  "in_reply_to_user_id" : 2185,
  "text" : "@bdotdub @eramirez I've settled on the life goal of increasing quality time with people and interests and this app perfectly supports that.",
  "id" : 435275312717262848,
  "in_reply_to_status_id" : 435274956201406466,
  "created_at" : "2014-02-17 04:51:36 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benny Wong",
      "screen_name" : "bdotdub",
      "indices" : [ 0, 8 ],
      "id_str" : "3032241",
      "id" : 3032241
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 9, 18 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/435274956201406466\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/P3mb8rlYJn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgpoRCeCQAEpF7Y.jpg",
      "id_str" : "435274955924586497",
      "id" : 435274955924586497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgpoRCeCQAEpF7Y.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/P3mb8rlYJn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435274001305567232",
  "geo" : { },
  "id_str" : "435274956201406466",
  "in_reply_to_user_id" : 3032241,
  "text" : "@bdotdub @eramirez Mine are about mapping daily objective experiences to a subjective binary \"is this quality time?\" http:\/\/t.co\/P3mb8rlYJn",
  "id" : 435274956201406466,
  "in_reply_to_status_id" : 435274001305567232,
  "created_at" : "2014-02-17 04:50:11 +0000",
  "in_reply_to_screen_name" : "bdotdub",
  "in_reply_to_user_id_str" : "3032241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435272680082657280",
  "geo" : { },
  "id_str" : "435273513415344128",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez It's rare for me to love a new QS app so much. That said, it's also tailored to my specific preferences\/interests.",
  "id" : 435273513415344128,
  "in_reply_to_status_id" : 435272680082657280,
  "created_at" : "2014-02-17 04:44:27 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 10, 22 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435272005890232321",
  "geo" : { },
  "id_str" : "435272484338679808",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @GetReporter I agree. Reporter just does a great job of both capturing and storing data in a friendly and flexible way.",
  "id" : 435272484338679808,
  "in_reply_to_status_id" : 435272005890232321,
  "created_at" : "2014-02-17 04:40:21 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 10, 22 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435270837126455296",
  "geo" : { },
  "id_str" : "435271275825463297",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @GetReporter Ha. Well a script takes less than 7 days to build! I'm still a huge fan of this app. It just needs a community.",
  "id" : 435271275825463297,
  "in_reply_to_status_id" : 435270837126455296,
  "created_at" : "2014-02-17 04:35:33 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 42, 54 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435268788812922880",
  "geo" : { },
  "id_str" : "435270679143792641",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Are there any scripts that pull @GetReporter data from Dropbox and do fun things with it yet? Might build one myself...",
  "id" : 435270679143792641,
  "in_reply_to_status_id" : 435268788812922880,
  "created_at" : "2014-02-17 04:33:11 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435268078763388928",
  "geo" : { },
  "id_str" : "435268445177802752",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh I've actually used this logic with Niko a couple times.",
  "id" : 435268445177802752,
  "in_reply_to_status_id" : 435268078763388928,
  "created_at" : "2014-02-17 04:24:18 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/434914150624411648\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/gqHg26bv3V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgkgHZLCAAE0oVK.jpg",
      "id_str" : "434914150406291457",
      "id" : 434914150406291457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgkgHZLCAAE0oVK.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gqHg26bv3V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434914150624411648",
  "text" : "8:36pm Bedtime stories with Jess http:\/\/t.co\/gqHg26bv3V",
  "id" : 434914150624411648,
  "created_at" : "2014-02-16 04:56:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/434863334450421760\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/0WWjM5MrML",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bgjx5gICAAA0kMU.jpg",
      "id_str" : "434863334219710464",
      "id" : 434863334219710464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bgjx5gICAAA0kMU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0WWjM5MrML"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434860664473935874",
  "geo" : { },
  "id_str" : "434863334450421760",
  "in_reply_to_user_id" : 2185,
  "text" : "Oops, swinging on the forbidden swing http:\/\/t.co\/0WWjM5MrML",
  "id" : 434863334450421760,
  "in_reply_to_status_id" : 434860664473935874,
  "created_at" : "2014-02-16 01:34:32 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/434860664473935874\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/VojL350q4d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgjveFwCUAElVyn.jpg",
      "id_str" : "434860664260022273",
      "id" : 434860664260022273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgjveFwCUAElVyn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/VojL350q4d"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434860664473935874",
  "text" : "Yes, this swing says \"please do not swing\" http:\/\/t.co\/VojL350q4d",
  "id" : 434860664473935874,
  "created_at" : "2014-02-16 01:23:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/s7K71CJNyo",
      "expanded_url" : "https:\/\/vine.co\/v\/M7UmtxPpQ6w",
      "display_url" : "vine.co\/v\/M7UmtxPpQ6w"
    } ]
  },
  "geo" : { },
  "id_str" : "434858788848676864",
  "text" : "Scribing it up https:\/\/t.co\/s7K71CJNyo",
  "id" : 434858788848676864,
  "created_at" : "2014-02-16 01:16:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fambai",
      "screen_name" : "fambai",
      "indices" : [ 4, 11 ],
      "id_str" : "12476332",
      "id" : 12476332
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/434847038241390592\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/MuJMav4ZvV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgjjE8GCUAADbvJ.jpg",
      "id_str" : "434847038031679488",
      "id" : 434847038031679488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgjjE8GCUAADbvJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/MuJMav4ZvV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434847038241390592",
  "text" : "Hey @fambai's in town! http:\/\/t.co\/MuJMav4ZvV",
  "id" : 434847038241390592,
  "created_at" : "2014-02-16 00:29:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 39, 49 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "fambai",
      "screen_name" : "fambai",
      "indices" : [ 50, 57 ],
      "id_str" : "12476332",
      "id" : 12476332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/87bjCSJqM1",
      "expanded_url" : "http:\/\/4sq.com\/1eCBjgA",
      "display_url" : "4sq.com\/1eCBjgA"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.2749120922, -122.4133971165 ]
  },
  "id_str" : "434834819319865344",
  "text" : "Wine pick-up party (@ Scribe Winery w\/ @kellianne @fambai) [pic]: http:\/\/t.co\/87bjCSJqM1",
  "id" : 434834819319865344,
  "created_at" : "2014-02-15 23:41:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434781858467819520",
  "text" : "RT @neiltyson: Without a space program that discovers, tracks &amp; deflects killer asteroids, our extinction is assured by one. Have a nice day",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "434776184446910464",
    "text" : "Without a space program that discovers, tracks &amp; deflects killer asteroids, our extinction is assured by one. Have a nice day",
    "id" : 434776184446910464,
    "created_at" : "2014-02-15 19:48:14 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 434781858467819520,
  "created_at" : "2014-02-15 20:10:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434743851937325056",
  "geo" : { },
  "id_str" : "434745466060673025",
  "in_reply_to_user_id" : 14095370,
  "text" : "@offbeatariel Just uploaded on to LJ.",
  "id" : 434745466060673025,
  "in_reply_to_status_id" : 434743851937325056,
  "created_at" : "2014-02-15 17:46:10 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434741221190160384",
  "geo" : { },
  "id_str" : "434743718864617472",
  "in_reply_to_user_id" : 14095370,
  "text" : "@offbeatariel Yeah it all came out of the blue! But pretty exciting to find out I have an older brother\u2026",
  "id" : 434743718864617472,
  "in_reply_to_status_id" : 434741221190160384,
  "created_at" : "2014-02-15 17:39:14 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434556908620369921",
  "geo" : { },
  "id_str" : "434738537426980864",
  "in_reply_to_user_id" : 2185,
  "text" : "Contact.",
  "id" : 434738537426980864,
  "in_reply_to_status_id" : 434556908620369921,
  "created_at" : "2014-02-15 17:18:39 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Bronstein",
      "screen_name" : "sbb",
      "indices" : [ 0, 4 ],
      "id_str" : "1149",
      "id" : 1149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434575759798054912",
  "geo" : { },
  "id_str" : "434586287387848704",
  "in_reply_to_user_id" : 1149,
  "text" : "@sbb Or in the present even.",
  "id" : 434586287387848704,
  "in_reply_to_status_id" : 434575759798054912,
  "created_at" : "2014-02-15 07:13:39 +0000",
  "in_reply_to_screen_name" : "sbb",
  "in_reply_to_user_id_str" : "1149",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay O'Leary",
      "screen_name" : "lindsayoleary",
      "indices" : [ 0, 14 ],
      "id_str" : "163966822",
      "id" : 163966822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434584624174751744",
  "geo" : { },
  "id_str" : "434585560376545280",
  "in_reply_to_user_id" : 163966822,
  "text" : "@lindsayoleary He's a funny guy. I feel bad for giving him such hell.",
  "id" : 434585560376545280,
  "in_reply_to_status_id" : 434584624174751744,
  "created_at" : "2014-02-15 07:10:46 +0000",
  "in_reply_to_screen_name" : "lindsayoleary",
  "in_reply_to_user_id_str" : "163966822",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434582583754502144",
  "geo" : { },
  "id_str" : "434585351630229504",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler I could've sworn you had an account at some time.",
  "id" : 434585351630229504,
  "in_reply_to_status_id" : 434582583754502144,
  "created_at" : "2014-02-15 07:09:56 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garry Tan",
      "screen_name" : "garrytan",
      "indices" : [ 0, 9 ],
      "id_str" : "11768582",
      "id" : 11768582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434580325893562368",
  "geo" : { },
  "id_str" : "434581187411996672",
  "in_reply_to_user_id" : 11768582,
  "text" : "@garrytan The internet is working!",
  "id" : 434581187411996672,
  "in_reply_to_status_id" : 434580325893562368,
  "created_at" : "2014-02-15 06:53:23 +0000",
  "in_reply_to_screen_name" : "garrytan",
  "in_reply_to_user_id_str" : "11768582",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay O'Leary",
      "screen_name" : "lindsayoleary",
      "indices" : [ 0, 14 ],
      "id_str" : "163966822",
      "id" : 163966822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/MBD5fBFJVl",
      "expanded_url" : "https:\/\/medium.com\/how-to-use-the-internet\/15e3d1ffc7dc",
      "display_url" : "medium.com\/how-to-use-the\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "434577484278145024",
  "geo" : { },
  "id_str" : "434578486682849280",
  "in_reply_to_user_id" : 163966822,
  "text" : "@lindsayoleary https:\/\/t.co\/MBD5fBFJVl And yeah funny how that works. We're equally friends and strangers on the interwebs.",
  "id" : 434578486682849280,
  "in_reply_to_status_id" : 434577484278145024,
  "created_at" : "2014-02-15 06:42:39 +0000",
  "in_reply_to_screen_name" : "lindsayoleary",
  "in_reply_to_user_id_str" : "163966822",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cayley",
      "screen_name" : "cayley",
      "indices" : [ 0, 7 ],
      "id_str" : "16867621",
      "id" : 16867621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434573146893459456",
  "geo" : { },
  "id_str" : "434577643002798081",
  "in_reply_to_user_id" : 16867621,
  "text" : "@cayley A pretty good one in the end.",
  "id" : 434577643002798081,
  "in_reply_to_status_id" : 434573146893459456,
  "created_at" : "2014-02-15 06:39:18 +0000",
  "in_reply_to_screen_name" : "cayley",
  "in_reply_to_user_id_str" : "16867621",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434575794992459776",
  "geo" : { },
  "id_str" : "434576132516487168",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright It identified a close relative that I share 24.7% of my genes with. Awkwardly, it identified him as my gramdfather, not brother.",
  "id" : 434576132516487168,
  "in_reply_to_status_id" : 434575794992459776,
  "created_at" : "2014-02-15 06:33:18 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434575045474537472",
  "geo" : { },
  "id_str" : "434575540729565184",
  "in_reply_to_user_id" : 2185,
  "text" : "WHAT?!",
  "id" : 434575540729565184,
  "in_reply_to_status_id" : 434575045474537472,
  "created_at" : "2014-02-15 06:30:57 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay O'Leary",
      "screen_name" : "lindsayoleary",
      "indices" : [ 0, 14 ],
      "id_str" : "163966822",
      "id" : 163966822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434575316124581888",
  "in_reply_to_user_id" : 163966822,
  "text" : "@lindsayoleary Did you see the recent interview with Andrew from Diaryland? Those were my peak trolling days.",
  "id" : 434575316124581888,
  "created_at" : "2014-02-15 06:30:04 +0000",
  "in_reply_to_screen_name" : "lindsayoleary",
  "in_reply_to_user_id_str" : "163966822",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434572606927151105",
  "geo" : { },
  "id_str" : "434575045474537472",
  "in_reply_to_user_id" : 2185,
  "text" : "What? Not Zoe!",
  "id" : 434575045474537472,
  "in_reply_to_status_id" : 434572606927151105,
  "created_at" : "2014-02-15 06:28:59 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434574546075545601",
  "geo" : { },
  "id_str" : "434574873403203584",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley Do it! It's the theme of the month.",
  "id" : 434574873403203584,
  "in_reply_to_status_id" : 434574546075545601,
  "created_at" : "2014-02-15 06:28:18 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434574238373015552",
  "geo" : { },
  "id_str" : "434574481902673921",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley Check LiveJournal for details. :)",
  "id" : 434574481902673921,
  "in_reply_to_status_id" : 434574238373015552,
  "created_at" : "2014-02-15 06:26:45 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434571228725002241",
  "geo" : { },
  "id_str" : "434572606927151105",
  "in_reply_to_user_id" : 2185,
  "text" : "I want ribs.",
  "id" : 434572606927151105,
  "in_reply_to_status_id" : 434571228725002241,
  "created_at" : "2014-02-15 06:19:18 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434570773609467905",
  "geo" : { },
  "id_str" : "434571228725002241",
  "in_reply_to_user_id" : 2185,
  "text" : "I like how text messaging is represented on screen. On Sherlock too.",
  "id" : 434571228725002241,
  "in_reply_to_status_id" : 434570773609467905,
  "created_at" : "2014-02-15 06:13:49 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434570773609467905",
  "text" : "So... House of Cards then.",
  "id" : 434570773609467905,
  "created_at" : "2014-02-15 06:12:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434569253035843584",
  "geo" : { },
  "id_str" : "434570408721805314",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Life before email sucked.",
  "id" : 434570408721805314,
  "in_reply_to_status_id" : 434569253035843584,
  "created_at" : "2014-02-15 06:10:34 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hamet Watt",
      "screen_name" : "hametwatt",
      "indices" : [ 0, 10 ],
      "id_str" : "27505295",
      "id" : 27505295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434568889477758976",
  "geo" : { },
  "id_str" : "434569176699510785",
  "in_reply_to_user_id" : 27505295,
  "text" : "@hametwatt We'll see if he replies before planning too far ahead. :)",
  "id" : 434569176699510785,
  "in_reply_to_status_id" : 434568889477758976,
  "created_at" : "2014-02-15 06:05:40 +0000",
  "in_reply_to_screen_name" : "hametwatt",
  "in_reply_to_user_id_str" : "27505295",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434568861317226496",
  "geo" : { },
  "id_str" : "434568993718820865",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey How did it turn out?",
  "id" : 434568993718820865,
  "in_reply_to_status_id" : 434568861317226496,
  "created_at" : "2014-02-15 06:04:56 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434565013852807168",
  "geo" : { },
  "id_str" : "434568149208289281",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler It is! A bit more detail on LJ is you haven't checked that recently.",
  "id" : 434568149208289281,
  "in_reply_to_status_id" : 434565013852807168,
  "created_at" : "2014-02-15 06:01:35 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 0, 9 ],
      "id_str" : "14986129",
      "id" : 14986129
    }, {
      "name" : "\u2622\u25E1\u2622",
      "screen_name" : "duncangraham",
      "indices" : [ 10, 23 ],
      "id_str" : "25958131",
      "id" : 25958131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434561647554732032",
  "geo" : { },
  "id_str" : "434561872696573952",
  "in_reply_to_user_id" : 14986129,
  "text" : "@irondavy @duncangraham Yeah, is it meet your long lost sibling month or something?",
  "id" : 434561872696573952,
  "in_reply_to_status_id" : 434561647554732032,
  "created_at" : "2014-02-15 05:36:38 +0000",
  "in_reply_to_screen_name" : "irondavy",
  "in_reply_to_user_id_str" : "14986129",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aurelia Cotta",
      "screen_name" : "AureliaCotta",
      "indices" : [ 0, 13 ],
      "id_str" : "19055125",
      "id" : 19055125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434560388068151296",
  "geo" : { },
  "id_str" : "434561488775176192",
  "in_reply_to_user_id" : 19055125,
  "text" : "@aureliacotta Yup!",
  "id" : 434561488775176192,
  "in_reply_to_status_id" : 434560388068151296,
  "created_at" : "2014-02-15 05:35:07 +0000",
  "in_reply_to_screen_name" : "AureliaCotta",
  "in_reply_to_user_id_str" : "19055125",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omid Ashtari",
      "screen_name" : "omid",
      "indices" : [ 0, 5 ],
      "id_str" : "114971521",
      "id" : 114971521
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 6, 14 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434558888487030784",
  "geo" : { },
  "id_str" : "434559521705295872",
  "in_reply_to_user_id" : 114971521,
  "text" : "@omid @23andme New relatives for everyone!",
  "id" : 434559521705295872,
  "in_reply_to_status_id" : 434558888487030784,
  "created_at" : "2014-02-15 05:27:18 +0000",
  "in_reply_to_screen_name" : "omid",
  "in_reply_to_user_id_str" : "114971521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 0, 6 ],
      "id_str" : "5469512",
      "id" : 5469512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434558260977217537",
  "geo" : { },
  "id_str" : "434558447757975553",
  "in_reply_to_user_id" : 5469512,
  "text" : "@micah It got over 100 &lt;3s, and positive comments\u2026 so\u2026 good? Good timing on the launch of that app for me. :)",
  "id" : 434558447757975553,
  "in_reply_to_status_id" : 434558260977217537,
  "created_at" : "2014-02-15 05:23:02 +0000",
  "in_reply_to_screen_name" : "micah",
  "in_reply_to_user_id_str" : "5469512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 0, 13 ],
      "id_str" : "1784841",
      "id" : 1784841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434557965954072576",
  "geo" : { },
  "id_str" : "434558221118746624",
  "in_reply_to_user_id" : 1784841,
  "text" : "@sawickipedia Nope. My father was 17\u2026 8 years before he met my mom.",
  "id" : 434558221118746624,
  "in_reply_to_status_id" : 434557965954072576,
  "created_at" : "2014-02-15 05:22:08 +0000",
  "in_reply_to_screen_name" : "sawickipedia",
  "in_reply_to_user_id_str" : "1784841",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omid Ashtari",
      "screen_name" : "omid",
      "indices" : [ 0, 5 ],
      "id_str" : "114971521",
      "id" : 114971521
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 6, 14 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434557384711626754",
  "geo" : { },
  "id_str" : "434557982513168384",
  "in_reply_to_user_id" : 114971521,
  "text" : "@omid @23andme That's exactly it. We share 24.7% of our genes. I have an older brother. Still processing\u2026",
  "id" : 434557982513168384,
  "in_reply_to_status_id" : 434557384711626754,
  "created_at" : "2014-02-15 05:21:11 +0000",
  "in_reply_to_screen_name" : "omid",
  "in_reply_to_user_id_str" : "114971521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 0, 13 ],
      "id_str" : "1784841",
      "id" : 1784841
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "speechless",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434557345062875136",
  "geo" : { },
  "id_str" : "434557778980397056",
  "in_reply_to_user_id" : 1784841,
  "text" : "@sawickipedia My father (our shared parent) passed away in 1993. I've talked to my mom and sister about it, though. #speechless",
  "id" : 434557778980397056,
  "in_reply_to_status_id" : 434557345062875136,
  "created_at" : "2014-02-15 05:20:22 +0000",
  "in_reply_to_screen_name" : "sawickipedia",
  "in_reply_to_user_id_str" : "1784841",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 0, 13 ],
      "id_str" : "1784841",
      "id" : 1784841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434557101088587776",
  "geo" : { },
  "id_str" : "434557186086154242",
  "in_reply_to_user_id" : 1784841,
  "text" : "@sawickipedia Yeah. Crazy, right?",
  "id" : 434557186086154242,
  "in_reply_to_status_id" : 434557101088587776,
  "created_at" : "2014-02-15 05:18:01 +0000",
  "in_reply_to_screen_name" : "sawickipedia",
  "in_reply_to_user_id_str" : "1784841",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 89, 97 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "holyshitballs",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434556908620369921",
  "text" : "I just sent an email to my half-brother that I just learned about thanks to the magic of @23andme. #holyshitballs",
  "id" : 434556908620369921,
  "created_at" : "2014-02-15 05:16:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daryn Nakhuda",
      "screen_name" : "daryn",
      "indices" : [ 0, 6 ],
      "id_str" : "804808",
      "id" : 804808
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "needaneditor",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434554087204347904",
  "geo" : { },
  "id_str" : "434554463726993408",
  "in_reply_to_user_id" : 804808,
  "text" : "@daryn My current draft is actually 114 words, and the first couple words are \"Through the magic of\u2026\" #needaneditor",
  "id" : 434554463726993408,
  "in_reply_to_status_id" : 434554087204347904,
  "created_at" : "2014-02-15 05:07:12 +0000",
  "in_reply_to_screen_name" : "daryn",
  "in_reply_to_user_id_str" : "804808",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 17, 27 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/434550454265999361\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/trA7Psq2xn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgfVVerCcAAZie1.jpg",
      "id_str" : "434550454052089856",
      "id" : 434550454052089856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgfVVerCcAAZie1.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/trA7Psq2xn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434550454265999361",
  "text" : "8:36pm For V-Day @kellianne is babysitting for our neighbors and I'm trying to write a very important 1-line email. http:\/\/t.co\/trA7Psq2xn",
  "id" : 434550454265999361,
  "created_at" : "2014-02-15 04:51:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jesuisjuba",
      "screen_name" : "jesuisjuba",
      "indices" : [ 0, 11 ],
      "id_str" : "47478936",
      "id" : 47478936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434548881582747648",
  "geo" : { },
  "id_str" : "434549043927056385",
  "in_reply_to_user_id" : 47478936,
  "text" : "@jesuisjuba I've come a long way from my early days. :)",
  "id" : 434549043927056385,
  "in_reply_to_status_id" : 434548881582747648,
  "created_at" : "2014-02-15 04:45:40 +0000",
  "in_reply_to_screen_name" : "jesuisjuba",
  "in_reply_to_user_id_str" : "47478936",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434548331449028608",
  "text" : "I don't troll people very often, but when I do I'm really nice about it.",
  "id" : 434548331449028608,
  "created_at" : "2014-02-15 04:42:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 9, 18 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 19, 28 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aaronc",
      "indices" : [ 29, 36 ],
      "id_str" : "9609062",
      "id" : 9609062
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 37, 44 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434531945993613313",
  "geo" : { },
  "id_str" : "434533856616525825",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves @agaricus @eramirez @aaronc @cwhogg Yes, I believe so. And now I feel like I've used up my tweet quota for the day.",
  "id" : 434533856616525825,
  "in_reply_to_status_id" : 434531945993613313,
  "created_at" : "2014-02-15 03:45:19 +0000",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 10, 18 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 19, 28 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aaronc",
      "indices" : [ 29, 36 ],
      "id_str" : "9609062",
      "id" : 9609062
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 37, 44 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434504120351739904",
  "geo" : { },
  "id_str" : "434508789740351488",
  "in_reply_to_user_id" : 2185,
  "text" : "@agaricus @dreeves @eramirez @aaronc @cwhogg final qualification: \"can learn\" but haven't yet learned.",
  "id" : 434508789740351488,
  "in_reply_to_status_id" : 434504120351739904,
  "created_at" : "2014-02-15 02:05:42 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 10, 18 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 19, 28 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aaronc",
      "indices" : [ 29, 36 ],
      "id_str" : "9609062",
      "id" : 9609062
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 37, 44 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434504120351739904",
  "geo" : { },
  "id_str" : "434504493774811136",
  "in_reply_to_user_id" : 2185,
  "text" : "@agaricus @dreeves @eramirez @aaronc @cwhogg Another qualification: I think we can change them in ourselves. No bet on changing others.",
  "id" : 434504493774811136,
  "in_reply_to_status_id" : 434504120351739904,
  "created_at" : "2014-02-15 01:48:38 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 10, 18 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 19, 28 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aaronc",
      "indices" : [ 29, 36 ],
      "id_str" : "9609062",
      "id" : 9609062
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 37, 44 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434503765148708864",
  "geo" : { },
  "id_str" : "434504120351739904",
  "in_reply_to_user_id" : 2185,
  "text" : "@agaricus @dreeves @eramirez @aaronc @cwhogg But as a set of things, which I think of as behavior, I believe we can learn to change them.",
  "id" : 434504120351739904,
  "in_reply_to_status_id" : 434503765148708864,
  "created_at" : "2014-02-15 01:47:09 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 10, 18 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 19, 28 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aaronc",
      "indices" : [ 29, 36 ],
      "id_str" : "9609062",
      "id" : 9609062
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 37, 44 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434503249282863104",
  "geo" : { },
  "id_str" : "434503765148708864",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus @dreeves @eramirez @aaronc @cwhogg There are lots of other things than learned responses to input in the universe.",
  "id" : 434503765148708864,
  "in_reply_to_status_id" : 434503249282863104,
  "created_at" : "2014-02-15 01:45:44 +0000",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 10, 18 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 19, 28 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aaronc",
      "indices" : [ 29, 36 ],
      "id_str" : "9609062",
      "id" : 9609062
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 37, 44 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434500776614846464",
  "geo" : { },
  "id_str" : "434502647446781952",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus @dreeves @eramirez @aaronc @cwhogg Definitely included. \"Learned\" could also be by evolution or subconscious processes.",
  "id" : 434502647446781952,
  "in_reply_to_status_id" : 434500776614846464,
  "created_at" : "2014-02-15 01:41:18 +0000",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 10, 18 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 19, 28 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aaronc",
      "indices" : [ 29, 36 ],
      "id_str" : "9609062",
      "id" : 9609062
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 37, 44 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434478491799539712",
  "geo" : { },
  "id_str" : "434481138703151105",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus @dreeves @eramirez @aaronc @cwhogg My def of behavior: our learned responses to thoughts, environment, circumstances, and people.",
  "id" : 434481138703151105,
  "in_reply_to_status_id" : 434478491799539712,
  "created_at" : "2014-02-15 00:15:50 +0000",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 9, 18 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aaronc",
      "indices" : [ 19, 26 ],
      "id_str" : "9609062",
      "id" : 9609062
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 27, 34 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 35, 44 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434476651666087936",
  "geo" : { },
  "id_str" : "434477134736674817",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves @eramirez @aaronc @cwhogg @agaricus Agreed. Greater than or equal to 1 answer. An answer cocktail would be entirely satisfactory.",
  "id" : 434477134736674817,
  "in_reply_to_status_id" : 434476651666087936,
  "created_at" : "2014-02-14 23:59:55 +0000",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 10, 18 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aaronc",
      "indices" : [ 19, 26 ],
      "id_str" : "9609062",
      "id" : 9609062
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 27, 34 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 35, 44 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434475527814922240",
  "geo" : { },
  "id_str" : "434476322224488448",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @dreeves @aaronc @cwhogg @agaricus I'll just continue to think (possibly alone) it's a really difficult, but not futile, problem.",
  "id" : 434476322224488448,
  "in_reply_to_status_id" : 434475527814922240,
  "created_at" : "2014-02-14 23:56:42 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kate matsudaira",
      "screen_name" : "katemats",
      "indices" : [ 3, 12 ],
      "id_str" : "17173207",
      "id" : 17173207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/YWeo0DYLlW",
      "expanded_url" : "http:\/\/tabcloseddidntread.com\/",
      "display_url" : "tabcloseddidntread.com"
    } ]
  },
  "geo" : { },
  "id_str" : "434474937084936192",
  "text" : "RT @katemats: Tab Closed; Didn't Read http:\/\/t.co\/YWeo0DYLlW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/YWeo0DYLlW",
        "expanded_url" : "http:\/\/tabcloseddidntread.com\/",
        "display_url" : "tabcloseddidntread.com"
      } ]
    },
    "geo" : { },
    "id_str" : "434474727219163137",
    "text" : "Tab Closed; Didn't Read http:\/\/t.co\/YWeo0DYLlW",
    "id" : 434474727219163137,
    "created_at" : "2014-02-14 23:50:21 +0000",
    "user" : {
      "name" : "kate matsudaira",
      "screen_name" : "katemats",
      "protected" : false,
      "id_str" : "17173207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1768986828\/image1327082013_normal.png",
      "id" : 17173207,
      "verified" : false
    }
  },
  "id" : 434474937084936192,
  "created_at" : "2014-02-14 23:51:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 9, 18 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aaronc",
      "indices" : [ 19, 26 ],
      "id_str" : "9609062",
      "id" : 9609062
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 27, 34 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434472777983070208",
  "geo" : { },
  "id_str" : "434474078158585856",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves @eramirez @aaronc @cwhogg Curious to hear more about this prediction too. What have you learned???",
  "id" : 434474078158585856,
  "in_reply_to_status_id" : 434472777983070208,
  "created_at" : "2014-02-14 23:47:47 +0000",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434454318457319425",
  "geo" : { },
  "id_str" : "434457783228846080",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Interesting! What is the kind-to-asshole ratio number in your experience?",
  "id" : 434457783228846080,
  "in_reply_to_status_id" : 434454318457319425,
  "created_at" : "2014-02-14 22:43:02 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434451621020319744",
  "geo" : { },
  "id_str" : "434451880790339584",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves Yes! When are you in SF next?",
  "id" : 434451880790339584,
  "in_reply_to_status_id" : 434451621020319744,
  "created_at" : "2014-02-14 22:19:34 +0000",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434450710264938496",
  "geo" : { },
  "id_str" : "434451425645449216",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Oh they're not too different than our QS kvetch sessions over beer\u2026 plus more about raising money\/choosing cofounders though.",
  "id" : 434451425645449216,
  "in_reply_to_status_id" : 434450710264938496,
  "created_at" : "2014-02-14 22:17:46 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Chou",
      "screen_name" : "garychou",
      "indices" : [ 0, 9 ],
      "id_str" : "29058287",
      "id" : 29058287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434450248845369344",
  "geo" : { },
  "id_str" : "434450428516782080",
  "in_reply_to_user_id" : 29058287,
  "text" : "@garychou I'm pretty sure most of them are going to go ahead and do it anyway, just like I did.",
  "id" : 434450428516782080,
  "in_reply_to_status_id" : 434450248845369344,
  "created_at" : "2014-02-14 22:13:48 +0000",
  "in_reply_to_screen_name" : "garychou",
  "in_reply_to_user_id_str" : "29058287",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434449592495509504",
  "text" : "I am really good at meeting excited and ambitious entrepreneurs in the health\/behavior change space and really bumming them out.",
  "id" : 434449592495509504,
  "created_at" : "2014-02-14 22:10:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yuki suda",
      "screen_name" : "yukisuda2",
      "indices" : [ 0, 10 ],
      "id_str" : "725767158",
      "id" : 725767158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434386260698750977",
  "geo" : { },
  "id_str" : "434391418941870081",
  "in_reply_to_user_id" : 725767158,
  "text" : "@yukisuda2 Looks like we are starting to see some data\u2026 you'll get access to the dashboard when more than 10 tweets link to your site.",
  "id" : 434391418941870081,
  "in_reply_to_status_id" : 434386260698750977,
  "created_at" : "2014-02-14 18:19:19 +0000",
  "in_reply_to_screen_name" : "yukisuda2",
  "in_reply_to_user_id_str" : "725767158",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yuki suda",
      "screen_name" : "yukisuda2",
      "indices" : [ 0, 10 ],
      "id_str" : "725767158",
      "id" : 725767158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/HXtniCCABm",
      "expanded_url" : "https:\/\/dev.twitter.com\/discussions\/analytics",
      "display_url" : "dev.twitter.com\/discussions\/an\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "434384802603487233",
  "geo" : { },
  "id_str" : "434385157873618944",
  "in_reply_to_user_id" : 725767158,
  "text" : "@yukisuda2 Happy to help. Can you post details of your problem here: https:\/\/t.co\/HXtniCCABm",
  "id" : 434385157873618944,
  "in_reply_to_status_id" : 434384802603487233,
  "created_at" : "2014-02-14 17:54:26 +0000",
  "in_reply_to_screen_name" : "yukisuda2",
  "in_reply_to_user_id_str" : "725767158",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    }, {
      "name" : "Ameet Ranadive",
      "screen_name" : "ameet",
      "indices" : [ 12, 18 ],
      "id_str" : "5510452",
      "id" : 5510452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434357975340154880",
  "geo" : { },
  "id_str" : "434360002145304576",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold @ameet I'd want to see unlocks\/hr as well. It'll never happen on iPhone but it probably already exists for Android somewhere.",
  "id" : 434360002145304576,
  "in_reply_to_status_id" : 434357975340154880,
  "created_at" : "2014-02-14 16:14:29 +0000",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ameet Ranadive",
      "screen_name" : "ameet",
      "indices" : [ 134, 140 ],
      "id_str" : "5510452",
      "id" : 5510452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/QhPQIHHYn8",
      "expanded_url" : "http:\/\/www.npr.org\/blogs\/alltechconsidered\/2013\/10\/09\/230867952\/new-numbers-back-up-our-obsession-with-phones",
      "display_url" : "npr.org\/blogs\/alltechc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596832165, -122.275594994 ]
  },
  "id_str" : "434356219914899456",
  "text" : "\"Users unlock their phones an average of 110 times a day, according to data from the app company Locket.\" http:\/\/t.co\/QhPQIHHYn8 \/via @ameet",
  "id" : 434356219914899456,
  "created_at" : "2014-02-14 15:59:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ario Jafarzadeh",
      "screen_name" : "ario",
      "indices" : [ 0, 5 ],
      "id_str" : "294",
      "id" : 294
    }, {
      "name" : "Noah Iliinsky",
      "screen_name" : "noahi",
      "indices" : [ 6, 12 ],
      "id_str" : "15399031",
      "id" : 15399031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434196517306372096",
  "geo" : { },
  "id_str" : "434197144329674752",
  "in_reply_to_user_id" : 294,
  "text" : "@ario @noahi I'm just suggesting that you spend more time thinking about this from different perspectives, flip roles, examine bias, etc.",
  "id" : 434197144329674752,
  "in_reply_to_status_id" : 434196517306372096,
  "created_at" : "2014-02-14 05:27:20 +0000",
  "in_reply_to_screen_name" : "ario",
  "in_reply_to_user_id_str" : "294",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434194572587966466",
  "geo" : { },
  "id_str" : "434196380924391424",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april You really sell it.",
  "id" : 434196380924391424,
  "in_reply_to_status_id" : 434194572587966466,
  "created_at" : "2014-02-14 05:24:18 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ario Jafarzadeh",
      "screen_name" : "ario",
      "indices" : [ 0, 5 ],
      "id_str" : "294",
      "id" : 294
    }, {
      "name" : "Noah Iliinsky",
      "screen_name" : "noahi",
      "indices" : [ 6, 12 ],
      "id_str" : "15399031",
      "id" : 15399031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434044350318661632",
  "geo" : { },
  "id_str" : "434195216359100416",
  "in_reply_to_user_id" : 294,
  "text" : "@ario @noahi Overcoming systemic bias is not easy... go slower. Look for things you agree with rather than disagree with.",
  "id" : 434195216359100416,
  "in_reply_to_status_id" : 434044350318661632,
  "created_at" : "2014-02-14 05:19:41 +0000",
  "in_reply_to_screen_name" : "ario",
  "in_reply_to_user_id_str" : "294",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434187677219315712",
  "text" : "Cute, my Roku knows valentine's Day is coming.",
  "id" : 434187677219315712,
  "created_at" : "2014-02-14 04:49:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katja",
      "screen_name" : "katjamrs",
      "indices" : [ 0, 9 ],
      "id_str" : "1105292796",
      "id" : 1105292796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434184030200676352",
  "geo" : { },
  "id_str" : "434184845187510272",
  "in_reply_to_user_id" : 1105292796,
  "text" : "@katjamrs How are you? We need to come visit you all again soon!",
  "id" : 434184845187510272,
  "in_reply_to_status_id" : 434184030200676352,
  "created_at" : "2014-02-14 04:38:28 +0000",
  "in_reply_to_screen_name" : "katjamrs",
  "in_reply_to_user_id_str" : "1105292796",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/HDBZNQaqGz",
      "expanded_url" : "http:\/\/flic.kr\/p\/k4Mrq4",
      "display_url" : "flic.kr\/p\/k4Mrq4"
    } ]
  },
  "geo" : { },
  "id_str" : "434184593550618624",
  "text" : "8:36pm Not really sick *and* tired, though http:\/\/t.co\/HDBZNQaqGz",
  "id" : 434184593550618624,
  "created_at" : "2014-02-14 04:37:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katja",
      "screen_name" : "katjamrs",
      "indices" : [ 0, 9 ],
      "id_str" : "1105292796",
      "id" : 1105292796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434183925984804864",
  "in_reply_to_user_id" : 1105292796,
  "text" : "@katjamrs Hi Katja!",
  "id" : 434183925984804864,
  "created_at" : "2014-02-14 04:34:49 +0000",
  "in_reply_to_screen_name" : "katjamrs",
  "in_reply_to_user_id_str" : "1105292796",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Editorially",
      "screen_name" : "GetEditorially",
      "indices" : [ 0, 15 ],
      "id_str" : "368540976",
      "id" : 368540976
    }, {
      "name" : "Todd Zaki Warfel",
      "screen_name" : "zakiwarfel",
      "indices" : [ 16, 27 ],
      "id_str" : "12298822",
      "id" : 12298822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434019165234806784",
  "geo" : { },
  "id_str" : "434183520303316992",
  "in_reply_to_user_id" : 368540976,
  "text" : "@GetEditorially @zakiwarfel Sad face.",
  "id" : 434183520303316992,
  "in_reply_to_status_id" : 434019165234806784,
  "created_at" : "2014-02-14 04:33:12 +0000",
  "in_reply_to_screen_name" : "GetEditorially",
  "in_reply_to_user_id_str" : "368540976",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Reich",
      "screen_name" : "ohheygreat",
      "indices" : [ 3, 14 ],
      "id_str" : "9670142",
      "id" : 9670142
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 16, 25 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ohheygreat\/status\/433750477633646592\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/sjKcUgFz8k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgT9wtqCcAEfAt7.jpg",
      "id_str" : "433750477465874433",
      "id" : 433750477465874433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgT9wtqCcAEfAt7.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/sjKcUgFz8k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434033001261850624",
  "text" : "RT @ohheygreat: @anildash http:\/\/t.co\/sjKcUgFz8k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anil Dash",
        "screen_name" : "anildash",
        "indices" : [ 0, 9 ],
        "id_str" : "36823",
        "id" : 36823
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ohheygreat\/status\/433750477633646592\/photo\/1",
        "indices" : [ 10, 32 ],
        "url" : "http:\/\/t.co\/sjKcUgFz8k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgT9wtqCcAEfAt7.jpg",
        "id_str" : "433750477465874433",
        "id" : 433750477465874433,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgT9wtqCcAEfAt7.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/sjKcUgFz8k"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "433746959456043009",
    "geo" : { },
    "id_str" : "433750477633646592",
    "in_reply_to_user_id" : 36823,
    "text" : "@anildash http:\/\/t.co\/sjKcUgFz8k",
    "id" : 433750477633646592,
    "in_reply_to_status_id" : 433746959456043009,
    "created_at" : "2014-02-12 23:52:27 +0000",
    "in_reply_to_screen_name" : "anildash",
    "in_reply_to_user_id_str" : "36823",
    "user" : {
      "name" : "Leah Reich",
      "screen_name" : "ohheygreat",
      "protected" : false,
      "id_str" : "9670142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461923328165298176\/wFNcIXOX_normal.jpeg",
      "id" : 9670142,
      "verified" : false
    }
  },
  "id" : 434033001261850624,
  "created_at" : "2014-02-13 18:35:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434016911823609857",
  "geo" : { },
  "id_str" : "434021319655424000",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm You're right, reading doesn't imply nearly the same level of consideration.",
  "id" : 434021319655424000,
  "in_reply_to_status_id" : 434016911823609857,
  "created_at" : "2014-02-13 17:48:40 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "John Shahidi",
      "screen_name" : "john",
      "indices" : [ 9, 14 ],
      "id_str" : "17151344",
      "id" : 17151344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434006665994567680",
  "geo" : { },
  "id_str" : "434006978143059969",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver @john Ah yeah. What about replies to tweets though? :)",
  "id" : 434006978143059969,
  "in_reply_to_status_id" : 434006665994567680,
  "created_at" : "2014-02-13 16:51:41 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "John Shahidi",
      "screen_name" : "john",
      "indices" : [ 9, 14 ],
      "id_str" : "17151344",
      "id" : 17151344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434005909954514944",
  "geo" : { },
  "id_str" : "434006537892163584",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver @john What was the context? Removing abusive replies or some other kind?",
  "id" : 434006537892163584,
  "in_reply_to_status_id" : 434005909954514944,
  "created_at" : "2014-02-13 16:49:56 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Appelwick",
      "screen_name" : "laurenwick",
      "indices" : [ 18, 29 ],
      "id_str" : "20096495",
      "id" : 20096495
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 71, 80 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/z8IvOg4Xcj",
      "expanded_url" : "https:\/\/medium.com\/p\/79403a7eade1",
      "display_url" : "medium.com\/p\/79403a7eade1"
    } ]
  },
  "in_reply_to_status_id_str" : "433999666980470784",
  "geo" : { },
  "id_str" : "434005834817761280",
  "in_reply_to_user_id" : 20096495,
  "text" : "Gonna try this RT @laurenwick: \u201CThe Year I Didn\u2019t Retweet Men\u201D -- This @anildash piece is worth your time. https:\/\/t.co\/z8IvOg4Xcj",
  "id" : 434005834817761280,
  "in_reply_to_status_id" : 433999666980470784,
  "created_at" : "2014-02-13 16:47:09 +0000",
  "in_reply_to_screen_name" : "laurenwick",
  "in_reply_to_user_id_str" : "20096495",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434003677100011521",
  "text" : "Okay the world is much more connected now but when do we get better communication skills? Which startup is going to disrupt listening?",
  "id" : 434003677100011521,
  "created_at" : "2014-02-13 16:38:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Bertolucci",
      "screen_name" : "jbertolucci",
      "indices" : [ 3, 15 ],
      "id_str" : "23230622",
      "id" : 23230622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434002184821157889",
  "text" : "RT @jbertolucci: What if Comcast and Time Warner Cable can't merge because they give each other a 4-hour window to sign the papers and neit\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433989852766273537",
    "text" : "What if Comcast and Time Warner Cable can't merge because they give each other a 4-hour window to sign the papers and neither side shows up?",
    "id" : 433989852766273537,
    "created_at" : "2014-02-13 15:43:38 +0000",
    "user" : {
      "name" : "Jeff Bertolucci",
      "screen_name" : "jbertolucci",
      "protected" : false,
      "id_str" : "23230622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3651386923\/3cde409cffe89305da639bd5957b535d_normal.png",
      "id" : 23230622,
      "verified" : false
    }
  },
  "id" : 434002184821157889,
  "created_at" : "2014-02-13 16:32:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/433823601490272256\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/jdZC3qZG10",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgVARFCCQAEe6vD.jpg",
      "id_str" : "433823601263788033",
      "id" : 433823601263788033,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgVARFCCQAEe6vD.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jdZC3qZG10"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433823601490272256",
  "text" : "8:36pm Playing Uno! http:\/\/t.co\/jdZC3qZG10",
  "id" : 433823601490272256,
  "created_at" : "2014-02-13 04:43:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thenewsecret",
      "indices" : [ 40, 53 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433789078190817280",
  "geo" : { },
  "id_str" : "433812691648380929",
  "in_reply_to_user_id" : 2185,
  "text" : "To learn more friend me on LiveJournal. #thenewsecret",
  "id" : 433812691648380929,
  "in_reply_to_status_id" : 433789078190817280,
  "created_at" : "2014-02-13 03:59:40 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "AdamSinger",
      "indices" : [ 0, 11 ],
      "id_str" : "14031032",
      "id" : 14031032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433790384364208128",
  "geo" : { },
  "id_str" : "433790860459642881",
  "in_reply_to_user_id" : 14031032,
  "text" : "@AdamSinger Me too! Working on it. My email is buster@twitter.com if you wanna share ideas.",
  "id" : 433790860459642881,
  "in_reply_to_status_id" : 433790384364208128,
  "created_at" : "2014-02-13 02:32:55 +0000",
  "in_reply_to_screen_name" : "AdamSinger",
  "in_reply_to_user_id_str" : "14031032",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Singleton",
      "screen_name" : "msingleton",
      "indices" : [ 0, 11 ],
      "id_str" : "1980271",
      "id" : 1980271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433789566202695680",
  "geo" : { },
  "id_str" : "433789688231374848",
  "in_reply_to_user_id" : 1980271,
  "text" : "@msingleton Ooh good idea. :)",
  "id" : 433789688231374848,
  "in_reply_to_status_id" : 433789566202695680,
  "created_at" : "2014-02-13 02:28:15 +0000",
  "in_reply_to_screen_name" : "msingleton",
  "in_reply_to_user_id_str" : "1980271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433789078190817280",
  "text" : "I just learned something crazy.",
  "id" : 433789078190817280,
  "created_at" : "2014-02-13 02:25:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    }, {
      "name" : "Andrew S",
      "screen_name" : "bn2b",
      "indices" : [ 24, 29 ],
      "id_str" : "16322212",
      "id" : 16322212
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "longlivediaryland",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433693830022328320",
  "geo" : { },
  "id_str" : "433699284983103489",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez Hm\u2026 I wonder if @bn2b remembers deleting my account for breaking the terms of service\u2026 #longlivediaryland",
  "id" : 433699284983103489,
  "in_reply_to_status_id" : 433693830022328320,
  "created_at" : "2014-02-12 20:29:01 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 36, 50 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433474580485640192",
  "geo" : { },
  "id_str" : "433688837370294273",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne Don\u2019t listen to anything @buster_ebooks says, he\u2019s deranged. Stop asking questions. I didn\u2019t eat the rabbit.",
  "id" : 433688837370294273,
  "in_reply_to_status_id" : 433474580485640192,
  "created_at" : "2014-02-12 19:47:31 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nassim N. Taleb",
      "screen_name" : "nntaleb",
      "indices" : [ 3, 11 ],
      "id_str" : "381289719",
      "id" : 381289719
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nntaleb\/status\/433606810478465024\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/iwvB8MCMGH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgR7GMeCUAE00vm.jpg",
      "id_str" : "433606810491047937",
      "id" : 433606810491047937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgR7GMeCUAE00vm.jpg",
      "sizes" : [ {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 201,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 201,
        "resize" : "fit",
        "w" : 360
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 201,
        "resize" : "fit",
        "w" : 360
      } ],
      "display_url" : "pic.twitter.com\/iwvB8MCMGH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433618077024931841",
  "text" : "RT @nntaleb: The simple graph shows how small probability of ruin eventually guarantees ruin. Risk is not renewable. http:\/\/t.co\/iwvB8MCMGH",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nntaleb\/status\/433606810478465024\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/iwvB8MCMGH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgR7GMeCUAE00vm.jpg",
        "id_str" : "433606810491047937",
        "id" : 433606810491047937,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgR7GMeCUAE00vm.jpg",
        "sizes" : [ {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 201,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 201,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 201,
          "resize" : "fit",
          "w" : 360
        } ],
        "display_url" : "pic.twitter.com\/iwvB8MCMGH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433606810478465024",
    "text" : "The simple graph shows how small probability of ruin eventually guarantees ruin. Risk is not renewable. http:\/\/t.co\/iwvB8MCMGH",
    "id" : 433606810478465024,
    "created_at" : "2014-02-12 14:21:34 +0000",
    "user" : {
      "name" : "Nassim N. Taleb",
      "screen_name" : "nntaleb",
      "protected" : false,
      "id_str" : "381289719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1810934906\/image001_normal.png",
      "id" : 381289719,
      "verified" : false
    }
  },
  "id" : 433618077024931841,
  "created_at" : "2014-02-12 15:06:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Bausch",
      "screen_name" : "pbausch",
      "indices" : [ 0, 8 ],
      "id_str" : "818992",
      "id" : 818992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433497635089952768",
  "geo" : { },
  "id_str" : "433498089886711808",
  "in_reply_to_user_id" : 818992,
  "text" : "@pbausch My prediction is that it'll come in super handy in Web 17.0, approximately 6 months from now.",
  "id" : 433498089886711808,
  "in_reply_to_status_id" : 433497635089952768,
  "created_at" : "2014-02-12 07:09:33 +0000",
  "in_reply_to_screen_name" : "pbausch",
  "in_reply_to_user_id_str" : "818992",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Bausch",
      "screen_name" : "pbausch",
      "indices" : [ 3, 11 ],
      "id_str" : "818992",
      "id" : 818992
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 13, 20 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/QKMnKna2td",
      "expanded_url" : "http:\/\/mophos.com",
      "display_url" : "mophos.com"
    } ]
  },
  "geo" : { },
  "id_str" : "433497776312180736",
  "text" : "RT @pbausch: @buster I still own http:\/\/t.co\/QKMnKna2td. I didn't ever do much with it but I have it just in case.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/QKMnKna2td",
        "expanded_url" : "http:\/\/mophos.com",
        "display_url" : "mophos.com"
      } ]
    },
    "in_reply_to_status_id_str" : "433473610674479104",
    "geo" : { },
    "id_str" : "433497635089952768",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster I still own http:\/\/t.co\/QKMnKna2td. I didn't ever do much with it but I have it just in case.",
    "id" : 433497635089952768,
    "in_reply_to_status_id" : 433473610674479104,
    "created_at" : "2014-02-12 07:07:44 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Paul Bausch",
      "screen_name" : "pbausch",
      "protected" : false,
      "id_str" : "818992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458702793948139520\/21BhtbWL_normal.jpeg",
      "id" : 818992,
      "verified" : false
    }
  },
  "id" : 433497776312180736,
  "created_at" : "2014-02-12 07:08:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/8Ioxx6znBj",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/erikbenson\/18358\/in\/datetaken\/",
      "display_url" : "flickr.com\/photos\/erikben\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "433459489086251008",
  "geo" : { },
  "id_str" : "433473610674479104",
  "in_reply_to_user_id" : 2185,
  "text" : "My first Flickr photo, 10 years ago, was a \u201Cmopho\u201D (yes that\u2019s what we called mobile photos, yes we were drunk): https:\/\/t.co\/8Ioxx6znBj",
  "id" : 433473610674479104,
  "in_reply_to_status_id" : 433459489086251008,
  "created_at" : "2014-02-12 05:32:17 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/3jpyZ3ZFD6",
      "expanded_url" : "https:\/\/twitter.com\/andrewhyde\/status\/433468070430928896",
      "display_url" : "twitter.com\/andrewhyde\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433469204855926784",
  "text" : "What they don't want you to click: https:\/\/t.co\/3jpyZ3ZFD6",
  "id" : 433469204855926784,
  "created_at" : "2014-02-12 05:14:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/X9nlLmZM8C",
      "expanded_url" : "http:\/\/flic.kr\/p\/k1aKac",
      "display_url" : "flic.kr\/p\/k1aKac"
    } ]
  },
  "geo" : { },
  "id_str" : "433468191265030144",
  "text" : "8:36pm Reading Niko his favorite book http:\/\/t.co\/X9nlLmZM8C",
  "id" : 433468191265030144,
  "created_at" : "2014-02-12 05:10:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433459625652809728",
  "geo" : { },
  "id_str" : "433462802678702080",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie I know that at least one of them was in San Jose\u2026 I remember car-pooling from SF.",
  "id" : 433462802678702080,
  "in_reply_to_status_id" : 433459625652809728,
  "created_at" : "2014-02-12 04:49:20 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 32, 40 ],
      "id_str" : "5699",
      "id" : 5699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433458233642995712",
  "geo" : { },
  "id_str" : "433459489086251008",
  "in_reply_to_user_id" : 2185,
  "text" : "I remember sheepishly informing @stewart of my name change. He never did file that restraining order.",
  "id" : 433459489086251008,
  "in_reply_to_status_id" : 433458233642995712,
  "created_at" : "2014-02-12 04:36:10 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433458233642995712",
  "geo" : { },
  "id_str" : "433459082750464000",
  "in_reply_to_user_id" : 2185,
  "text" : "I also blame Flickr for choosing the word \"favorite\" to represent liking something, thus resulting in a decade of fruitless debate.",
  "id" : 433459082750464000,
  "in_reply_to_status_id" : 433458233642995712,
  "created_at" : "2014-02-12 04:34:33 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433457346174394368",
  "geo" : { },
  "id_str" : "433458233642995712",
  "in_reply_to_user_id" : 2185,
  "text" : "I've copied many Flickr innovations over the years. I even legally changed my middle name to Butterfield for a few years. Ha.",
  "id" : 433458233642995712,
  "in_reply_to_status_id" : 433457346174394368,
  "created_at" : "2014-02-12 04:31:10 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/vVogKyv4JQ",
      "expanded_url" : "http:\/\/techland.time.com\/2014\/02\/10\/flickr-turns-10-the-rise-fall-and-revival-of-a-photo-sharing-community\/",
      "display_url" : "techland.time.com\/2014\/02\/10\/fli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433457346174394368",
  "text" : "I was at Etech when Flickr launched 10 years ago. So grateful for the many things it brought to the web. http:\/\/t.co\/vVogKyv4JQ",
  "id" : 433457346174394368,
  "created_at" : "2014-02-12 04:27:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 0, 14 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433123404346974208",
  "geo" : { },
  "id_str" : "433132987543085056",
  "in_reply_to_user_id" : 226976689,
  "text" : "@marcprecipice Barely started it but already hooked.",
  "id" : 433132987543085056,
  "in_reply_to_status_id" : 433123404346974208,
  "created_at" : "2014-02-11 06:58:46 +0000",
  "in_reply_to_screen_name" : "marcprecipice",
  "in_reply_to_user_id_str" : "226976689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/7WWS8A2afV",
      "expanded_url" : "http:\/\/flic.kr\/p\/jYcgVZ",
      "display_url" : "flic.kr\/p\/jYcgVZ"
    } ]
  },
  "geo" : { },
  "id_str" : "433100925746835456",
  "text" : "8:36pm Golden raisins are a popular bath dessert http:\/\/t.co\/7WWS8A2afV",
  "id" : 433100925746835456,
  "created_at" : "2014-02-11 04:51:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arya Asemanfar",
      "screen_name" : "a_a",
      "indices" : [ 3, 7 ],
      "id_str" : "14653230",
      "id" : 14653230
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 9, 16 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433080456972476416",
  "text" : "RT @a_a: @buster soon we'll have company autobiographies and they'll be even better!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "433065902209105920",
    "geo" : { },
    "id_str" : "433070643874000896",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster soon we'll have company autobiographies and they'll be even better!",
    "id" : 433070643874000896,
    "in_reply_to_status_id" : 433065902209105920,
    "created_at" : "2014-02-11 02:51:02 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Arya Asemanfar",
      "screen_name" : "a_a",
      "protected" : false,
      "id_str" : "14653230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1358814437\/54358_10100110405648051_6014086_52374896_509251_o_normal.jpeg",
      "id" : 14653230,
      "verified" : false
    }
  },
  "id" : 433080456972476416,
  "created_at" : "2014-02-11 03:30:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433065902209105920",
  "text" : "When did company biographies start trumping people biographies? Starting In The Plex now...",
  "id" : 433065902209105920,
  "created_at" : "2014-02-11 02:32:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433054068345282560",
  "geo" : { },
  "id_str" : "433055661354532864",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim I hear Berkeley's pretty nice. ps. CONGRATS!",
  "id" : 433055661354532864,
  "in_reply_to_status_id" : 433054068345282560,
  "created_at" : "2014-02-11 01:51:30 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433047979855859712",
  "geo" : { },
  "id_str" : "433055466772365312",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew Congrats! Do you know which city\/neighborhood you'll be moving to?",
  "id" : 433055466772365312,
  "in_reply_to_status_id" : 433047979855859712,
  "created_at" : "2014-02-11 01:50:43 +0000",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Jonathan Wegener",
      "screen_name" : "jwegener",
      "indices" : [ 10, 19 ],
      "id_str" : "3187821",
      "id" : 3187821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433021965167640577",
  "geo" : { },
  "id_str" : "433022127193591808",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @jwegener There are about 8,000 daily actives who write.",
  "id" : 433022127193591808,
  "in_reply_to_status_id" : 433021965167640577,
  "created_at" : "2014-02-10 23:38:14 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 8, 15 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/zMUCuBrk2s",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/emmyf\/buzzfeed-style-guide",
      "display_url" : "buzzfeed.com\/emmyf\/buzzfeed\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "432945497481834498",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7799909903, -122.4135890292 ]
  },
  "id_str" : "432951689033695232",
  "in_reply_to_user_id" : 4711,
  "text" : "fave RT @sippey: Your favorite thing for the next 5 minutes: BuzzFeed style guide and word list. http:\/\/t.co\/zMUCuBrk2s (\"OG (no periods)\")",
  "id" : 432951689033695232,
  "in_reply_to_status_id" : 432945497481834498,
  "created_at" : "2014-02-10 18:58:21 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 0, 14 ],
      "id_str" : "226976689",
      "id" : 226976689
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 15, 24 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432945360411959296",
  "geo" : { },
  "id_str" : "432949945042096128",
  "in_reply_to_user_id" : 226976689,
  "text" : "@marcprecipice @arainert Ooooh, good to know! Thanks!",
  "id" : 432949945042096128,
  "in_reply_to_status_id" : 432945360411959296,
  "created_at" : "2014-02-10 18:51:25 +0000",
  "in_reply_to_screen_name" : "marcprecipice",
  "in_reply_to_user_id_str" : "226976689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432845886939754496",
  "geo" : { },
  "id_str" : "432943636695638016",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Just Netflix. And now need a season 3 strategy...",
  "id" : 432943636695638016,
  "in_reply_to_status_id" : 432845886939754496,
  "created_at" : "2014-02-10 18:26:21 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7785680117, -122.4153058884 ]
  },
  "id_str" : "432937468006907904",
  "text" : "Gladwell's David &amp; Goliath was basically an entertaining footnote from Taleb's Antifragile told by a friendly happy person. Still liked it.",
  "id" : 432937468006907904,
  "created_at" : "2014-02-10 18:01:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colossal",
      "screen_name" : "Colossal",
      "indices" : [ 3, 12 ],
      "id_str" : "203063180",
      "id" : 203063180
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Colossal\/status\/432906630338854913\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2UrrbWCkbP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgH-SWMCQAARAj_.jpg",
      "id_str" : "432906630351437824",
      "id" : 432906630351437824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgH-SWMCQAARAj_.jpg",
      "sizes" : [ {
        "h" : 257,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 146,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/2UrrbWCkbP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/jAX1Hmrclz",
      "expanded_url" : "http:\/\/www.thisiscolossal.com\/2014\/02\/jotunvillur-code-cracked",
      "display_url" : "thisiscolossal.com\/2014\/02\/jotunv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432911863760703489",
  "text" : "RT @Colossal: A 900-year-old coded Viking message carved on a wood fragment was solved. It reads: \u201CKiss Me\u201D http:\/\/t.co\/jAX1Hmrclz http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Colossal\/status\/432906630338854913\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/2UrrbWCkbP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgH-SWMCQAARAj_.jpg",
        "id_str" : "432906630351437824",
        "id" : 432906630351437824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgH-SWMCQAARAj_.jpg",
        "sizes" : [ {
          "h" : 257,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 146,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/2UrrbWCkbP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/jAX1Hmrclz",
        "expanded_url" : "http:\/\/www.thisiscolossal.com\/2014\/02\/jotunvillur-code-cracked",
        "display_url" : "thisiscolossal.com\/2014\/02\/jotunv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "432906630338854913",
    "text" : "A 900-year-old coded Viking message carved on a wood fragment was solved. It reads: \u201CKiss Me\u201D http:\/\/t.co\/jAX1Hmrclz http:\/\/t.co\/2UrrbWCkbP",
    "id" : 432906630338854913,
    "created_at" : "2014-02-10 15:59:18 +0000",
    "user" : {
      "name" : "Colossal",
      "screen_name" : "Colossal",
      "protected" : false,
      "id_str" : "203063180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450852976337248256\/fOVTBYJu_normal.png",
      "id" : 203063180,
      "verified" : false
    }
  },
  "id" : 432911863760703489,
  "created_at" : "2014-02-10 16:20:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "indices" : [ 3, 17 ],
      "id_str" : "1236101",
      "id" : 1236101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/ak9wPu2n6k",
      "expanded_url" : "http:\/\/ben-evans.com\/benedictevans\/2014\/2\/10\/flappy-bird",
      "display_url" : "ben-evans.com\/benedictevans\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432904620998803456",
  "text" : "RT @BenedictEvans: The Google Trends chart for Flappy Bird is quite something. http:\/\/t.co\/ak9wPu2n6k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/ak9wPu2n6k",
        "expanded_url" : "http:\/\/ben-evans.com\/benedictevans\/2014\/2\/10\/flappy-bird",
        "display_url" : "ben-evans.com\/benedictevans\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "432785988964732928",
    "text" : "The Google Trends chart for Flappy Bird is quite something. http:\/\/t.co\/ak9wPu2n6k",
    "id" : 432785988964732928,
    "created_at" : "2014-02-10 07:59:55 +0000",
    "user" : {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "protected" : false,
      "id_str" : "1236101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454333621331976193\/AX-M-ESC_normal.jpeg",
      "id" : 1236101,
      "verified" : false
    }
  },
  "id" : 432904620998803456,
  "created_at" : "2014-02-10 15:51:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/as5h7Gq8uq",
      "expanded_url" : "http:\/\/flic.kr\/p\/jWdhMi",
      "display_url" : "flic.kr\/p\/jWdhMi"
    } ]
  },
  "geo" : { },
  "id_str" : "432756057283502080",
  "text" : "8:36pm Just wanna watch Shelock Holmes til there are none left http:\/\/t.co\/as5h7Gq8uq",
  "id" : 432756057283502080,
  "created_at" : "2014-02-10 06:00:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JeffKauflin",
      "screen_name" : "JeffKauflin",
      "indices" : [ 0, 12 ],
      "id_str" : "478230970",
      "id" : 478230970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/HeyfOzCvBZ",
      "expanded_url" : "https:\/\/dev.twitter.com\/discussions\/25410",
      "display_url" : "dev.twitter.com\/discussions\/25\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "432665902405148672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596939107, -122.2756503665 ]
  },
  "id_str" : "432668597924532224",
  "in_reply_to_user_id" : 478230970,
  "text" : "@JeffKauflin Can you leave your info and details on this thread: https:\/\/t.co\/HeyfOzCvBZ (I'll follow up there once we resolve this.)",
  "id" : 432668597924532224,
  "in_reply_to_status_id" : 432665902405148672,
  "created_at" : "2014-02-10 00:13:27 +0000",
  "in_reply_to_screen_name" : "JeffKauflin",
  "in_reply_to_user_id_str" : "478230970",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JeffKauflin",
      "screen_name" : "JeffKauflin",
      "indices" : [ 0, 12 ],
      "id_str" : "478230970",
      "id" : 478230970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432608340871757824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597176168, -122.2755370663 ]
  },
  "id_str" : "432664943041576960",
  "in_reply_to_user_id" : 478230970,
  "text" : "@JeffKauflin Are you saying you had access before but don't anymore? That shouldn't happen... can look into it.",
  "id" : 432664943041576960,
  "in_reply_to_status_id" : 432608340871757824,
  "created_at" : "2014-02-09 23:58:55 +0000",
  "in_reply_to_screen_name" : "JeffKauflin",
  "in_reply_to_user_id_str" : "478230970",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/432439157252554752\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/ZROxObL89V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgBVH0hCUAA3way.jpg",
      "id_str" : "432439157072220160",
      "id" : 432439157072220160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgBVH0hCUAA3way.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ZROxObL89V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597221431, -122.2754960788 ]
  },
  "id_str" : "432439157252554752",
  "text" : "Exercise with Gloria and Her Six Daughters http:\/\/t.co\/ZROxObL89V",
  "id" : 432439157252554752,
  "created_at" : "2014-02-09 09:01:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 42, 52 ],
      "id_str" : "16644937",
      "id" : 16644937
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 57, 67 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/432381641940426752\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/Jv0WgZopvv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgAgz_MCAAMBXWz.jpg",
      "id_str" : "432381641734881283",
      "id" : 432381641734881283,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgAgz_MCAAMBXWz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Jv0WgZopvv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8795408937, -122.2691760851 ]
  },
  "id_str" : "432381641940426752",
  "text" : "8:36pm Chez Panisse cafe dinner date with @the_april and @kellianne http:\/\/t.co\/Jv0WgZopvv",
  "id" : 432381641940426752,
  "created_at" : "2014-02-09 05:13:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432362686991441922",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597502155, -122.2756502042 ]
  },
  "id_str" : "432362827169288192",
  "in_reply_to_user_id" : 2185,
  "text" : "Then he asked, \"How am I supposed to get better at this?\"",
  "id" : 432362827169288192,
  "in_reply_to_status_id" : 432362686991441922,
  "created_at" : "2014-02-09 03:58:25 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597155116, -122.2755753334 ]
  },
  "id_str" : "432362686991441922",
  "text" : "Niko is stoked. He got a point on Flappy Bird.",
  "id" : 432362686991441922,
  "created_at" : "2014-02-09 03:57:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "anthony smith",
      "screen_name" : "anthny",
      "indices" : [ 0, 7 ],
      "id_str" : "33004679",
      "id" : 33004679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432325831994527744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597001186, -122.275740281 ]
  },
  "id_str" : "432326695727542273",
  "in_reply_to_user_id" : 33004679,
  "text" : "@anthny Of what? I admittedly haven't been following very closely.",
  "id" : 432326695727542273,
  "in_reply_to_status_id" : 432325831994527744,
  "created_at" : "2014-02-09 01:34:51 +0000",
  "in_reply_to_screen_name" : "anthny",
  "in_reply_to_user_id_str" : "33004679",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596737293, -122.2756116798 ]
  },
  "id_str" : "432325378057576448",
  "text" : "Flappy Bird clones... GO!",
  "id" : 432325378057576448,
  "created_at" : "2014-02-09 01:29:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/432284910116540416\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/x6lS77IyvP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf_I1dMCAAAhF4N.jpg",
      "id_str" : "432284909944569856",
      "id" : 432284909944569856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf_I1dMCAAAhF4N.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/x6lS77IyvP"
    } ],
    "hashtags" : [ {
      "text" : "albany",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "rainday",
      "indices" : [ 8, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.896433278, -122.3010122561 ]
  },
  "id_str" : "432284910116540416",
  "text" : "#albany #rainday http:\/\/t.co\/x6lS77IyvP",
  "id" : 432284910116540416,
  "created_at" : "2014-02-08 22:48:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/R6R9pNpqfN",
      "expanded_url" : "https:\/\/vine.co\/v\/MWZLpZnj0he",
      "display_url" : "vine.co\/v\/MWZLpZnj0he"
    } ]
  },
  "geo" : { },
  "id_str" : "432260428908212224",
  "text" : "Niko's first gutter ball https:\/\/t.co\/R6R9pNpqfN",
  "id" : 432260428908212224,
  "created_at" : "2014-02-08 21:11:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/Rbdw1FA72W",
      "expanded_url" : "https:\/\/vine.co\/v\/MWZYKLhtLvF",
      "display_url" : "vine.co\/v\/MWZYKLhtLvF"
    } ]
  },
  "geo" : { },
  "id_str" : "432258793309999104",
  "text" : "Wormy https:\/\/t.co\/Rbdw1FA72W",
  "id" : 432258793309999104,
  "created_at" : "2014-02-08 21:05:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/bMeG38dRAs",
      "expanded_url" : "https:\/\/vine.co\/v\/MWZmQqAgX5Z",
      "display_url" : "vine.co\/v\/MWZmQqAgX5Z"
    } ]
  },
  "geo" : { },
  "id_str" : "432233436812963840",
  "text" : "Puddle running https:\/\/t.co\/bMeG38dRAs",
  "id" : 432233436812963840,
  "created_at" : "2014-02-08 19:24:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McAllister",
      "screen_name" : "ianmcall",
      "indices" : [ 0, 9 ],
      "id_str" : "2035631",
      "id" : 2035631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/UANHFen3OY",
      "expanded_url" : "https:\/\/twitter.com\/buster\/status\/431480887146852352",
      "display_url" : "twitter.com\/buster\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "431992584466997248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597540781, -122.2755405867 ]
  },
  "id_str" : "431998190301110272",
  "in_reply_to_user_id" : 2035631,
  "text" : "@ianmcall I know, right? https:\/\/t.co\/UANHFen3OY",
  "id" : 431998190301110272,
  "in_reply_to_status_id" : 431992584466997248,
  "created_at" : "2014-02-08 03:49:29 +0000",
  "in_reply_to_screen_name" : "ianmcall",
  "in_reply_to_user_id_str" : "2035631",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Prevette",
      "screen_name" : "mikeprevette",
      "indices" : [ 0, 13 ],
      "id_str" : "1475531",
      "id" : 1475531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431887219218198528",
  "geo" : { },
  "id_str" : "431892309714546689",
  "in_reply_to_user_id" : 1475531,
  "text" : "@mikeprevette Cool! What did they say?",
  "id" : 431892309714546689,
  "in_reply_to_status_id" : 431887219218198528,
  "created_at" : "2014-02-07 20:48:45 +0000",
  "in_reply_to_screen_name" : "mikeprevette",
  "in_reply_to_user_id_str" : "1475531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wise Vehicle",
      "screen_name" : "wisevehicle",
      "indices" : [ 0, 12 ],
      "id_str" : "224400788",
      "id" : 224400788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431842037336248320",
  "geo" : { },
  "id_str" : "431842347198853120",
  "in_reply_to_user_id" : 224400788,
  "text" : "@wisevehicle Neat! In what context?",
  "id" : 431842347198853120,
  "in_reply_to_status_id" : 431842037336248320,
  "created_at" : "2014-02-07 17:30:13 +0000",
  "in_reply_to_screen_name" : "wisevehicle",
  "in_reply_to_user_id_str" : "224400788",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    }, {
      "name" : "Nicholas Felton",
      "screen_name" : "feltron",
      "indices" : [ 5, 13 ],
      "id_str" : "14892191",
      "id" : 14892191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431707086519427072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597277589, -122.2755359766 ]
  },
  "id_str" : "431708396757069824",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg @feltron I haven't yet. Going with the defaults for a few days and will customize next week.",
  "id" : 431708396757069824,
  "in_reply_to_status_id" : 431707086519427072,
  "created_at" : "2014-02-07 08:37:57 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AMC Theatres",
      "screen_name" : "AMCTheatres",
      "indices" : [ 27, 39 ],
      "id_str" : "40245758",
      "id" : 40245758
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 51, 61 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/1KSAxgjifi",
      "expanded_url" : "http:\/\/4sq.com\/1izJKh6",
      "display_url" : "4sq.com\/1izJKh6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8329715239, -122.2920584679 ]
  },
  "id_str" : "431659800846667776",
  "text" : "Her (@ AMC Bay Street 16 - @amctheatres for Her w\/ @kellianne) http:\/\/t.co\/1KSAxgjifi",
  "id" : 431659800846667776,
  "created_at" : "2014-02-07 05:24:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Underwood",
      "screen_name" : "aunder",
      "indices" : [ 0, 7 ],
      "id_str" : "4265731",
      "id" : 4265731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431652173538029568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8336414759, -122.2922206549 ]
  },
  "id_str" : "431652455231680512",
  "in_reply_to_user_id" : 4265731,
  "text" : "@aunder Get an HD antenna!",
  "id" : 431652455231680512,
  "in_reply_to_status_id" : 431652173538029568,
  "created_at" : "2014-02-07 04:55:39 +0000",
  "in_reply_to_screen_name" : "aunder",
  "in_reply_to_user_id_str" : "4265731",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 38, 48 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/431649795011141632\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/EQawty3AQY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf2HM5CCYAAvvS-.jpg",
      "id_str" : "431649794834980864",
      "id" : 431649794834980864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf2HM5CCYAAvvS-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EQawty3AQY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8336111261, -122.2921891764 ]
  },
  "id_str" : "431649795011141632",
  "text" : "8:36pm Burgers and beer before Her \/w @kellianne http:\/\/t.co\/EQawty3AQY",
  "id" : 431649795011141632,
  "created_at" : "2014-02-07 04:45:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "anthony smith",
      "screen_name" : "anthny",
      "indices" : [ 0, 7 ],
      "id_str" : "33004679",
      "id" : 33004679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431564213698297856",
  "geo" : { },
  "id_str" : "431565658422116352",
  "in_reply_to_user_id" : 33004679,
  "text" : "@anthny Busted. I've been rumored to moonlight as a red sail boat and a yellow ghost sometimes too.",
  "id" : 431565658422116352,
  "in_reply_to_status_id" : 431564213698297856,
  "created_at" : "2014-02-06 23:10:45 +0000",
  "in_reply_to_screen_name" : "anthny",
  "in_reply_to_user_id_str" : "33004679",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Roston",
      "screen_name" : "michaelroston",
      "indices" : [ 0, 14 ],
      "id_str" : "16194566",
      "id" : 16194566
    }, {
      "name" : "Brad Gerick",
      "screen_name" : "BradGerick",
      "indices" : [ 15, 26 ],
      "id_str" : "23390625",
      "id" : 23390625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/HXtniCCABm",
      "expanded_url" : "https:\/\/dev.twitter.com\/discussions\/analytics",
      "display_url" : "dev.twitter.com\/discussions\/an\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "431524863317385216",
  "geo" : { },
  "id_str" : "431545804080164864",
  "in_reply_to_user_id" : 16194566,
  "text" : "@michaelroston @BradGerick If you post a question with details and specific accounts to the forums I\u2019ll investigate: https:\/\/t.co\/HXtniCCABm",
  "id" : 431545804080164864,
  "in_reply_to_status_id" : 431524863317385216,
  "created_at" : "2014-02-06 21:51:52 +0000",
  "in_reply_to_screen_name" : "michaelroston",
  "in_reply_to_user_id_str" : "16194566",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/LFxhYjPpdS",
      "expanded_url" : "https:\/\/blog.twitter.com\/2014\/introducing-analytics-for-twitter-cards",
      "display_url" : "blog.twitter.com\/2014\/introduci\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "431516437371289601",
  "geo" : { },
  "id_str" : "431516579029733376",
  "in_reply_to_user_id" : 2185,
  "text" : "@offbeatariel And yes, I did work on Cards. And recently launched this, which you should totally use: https:\/\/t.co\/LFxhYjPpdS",
  "id" : 431516579029733376,
  "in_reply_to_status_id" : 431516437371289601,
  "created_at" : "2014-02-06 19:55:44 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431503603132416000",
  "geo" : { },
  "id_str" : "431516437371289601",
  "in_reply_to_user_id" : 14095370,
  "text" : "@offbeatariel Ha, I didn't write that copy but I hear that phrase all the time and have a similar reaction to it.",
  "id" : 431516437371289601,
  "in_reply_to_status_id" : 431503603132416000,
  "created_at" : "2014-02-06 19:55:10 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/431480887146852352\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/Miuz0mN6FA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfztlKUCMAAP3Mq.jpg",
      "id_str" : "431480887000051712",
      "id" : 431480887000051712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfztlKUCMAAP3Mq.jpg",
      "sizes" : [ {
        "h" : 727,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 727,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 727,
        "resize" : "fit",
        "w" : 499
      } ],
      "display_url" : "pic.twitter.com\/Miuz0mN6FA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762817156, -122.4167958319 ]
  },
  "id_str" : "431480887146852352",
  "text" : "Check out my profile in the New Yorker http:\/\/t.co\/Miuz0mN6FA",
  "id" : 431480887146852352,
  "created_at" : "2014-02-06 17:33:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 10, 22 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    }, {
      "name" : "Nicholas Felton",
      "screen_name" : "feltron",
      "indices" : [ 97, 105 ],
      "id_str" : "14892191",
      "id" : 14892191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431453952035799040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597201041, -122.2756041177 ]
  },
  "id_str" : "431455083344060416",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert @GetReporter Same here. I've daydreamed about building this app half a dozen times but @feltron did it right.",
  "id" : 431455083344060416,
  "in_reply_to_status_id" : 431453952035799040,
  "created_at" : "2014-02-06 15:51:22 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Felton",
      "screen_name" : "feltron",
      "indices" : [ 21, 29 ],
      "id_str" : "14892191",
      "id" : 14892191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/kJrMziu5Fz",
      "expanded_url" : "http:\/\/vrge.co\/1ayAb2s",
      "display_url" : "vrge.co\/1ayAb2s"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85971154, -122.2754738667 ]
  },
  "id_str" : "431452419021484032",
  "text" : "Sooooo excited about @feltron's new Reporter app. Taking a simple idea and doing it really well. Thanks, Nicholas! http:\/\/t.co\/kJrMziu5Fz",
  "id" : 431452419021484032,
  "created_at" : "2014-02-06 15:40:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 0, 11 ],
      "id_str" : "784078",
      "id" : 784078
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 12, 19 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431276160199057408",
  "geo" : { },
  "id_str" : "431318220318859265",
  "in_reply_to_user_id" : 784078,
  "text" : "@alicetiara @harryh it would be Harry but then you did the Twitter poll.",
  "id" : 431318220318859265,
  "in_reply_to_status_id" : 431276160199057408,
  "created_at" : "2014-02-06 06:47:31 +0000",
  "in_reply_to_screen_name" : "alicetiara",
  "in_reply_to_user_id_str" : "784078",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriemTeam",
      "screen_name" : "TriemTeam",
      "indices" : [ 0, 10 ],
      "id_str" : "24792603",
      "id" : 24792603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431259794956374016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8572460763, -122.2688212163 ]
  },
  "id_str" : "431263625320620032",
  "in_reply_to_user_id" : 24792603,
  "text" : "@TriemTeam From the latest Malcolm Gladwell book, David and Goliath.",
  "id" : 431263625320620032,
  "in_reply_to_status_id" : 431259794956374016,
  "created_at" : "2014-02-06 03:10:35 +0000",
  "in_reply_to_screen_name" : "TriemTeam",
  "in_reply_to_user_id_str" : "24792603",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8222157248, -122.2686703597 ]
  },
  "id_str" : "431259174950174720",
  "text" : "\"Gifted children tend to come from highly supportive family conditions. In contrast geniuses tend to come out of highly adverse situations.\"",
  "id" : 431259174950174720,
  "created_at" : "2014-02-06 02:52:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 17, 26 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431257270039478272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8109087842, -122.2697382996 ]
  },
  "id_str" : "431258262940704769",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine @eramirez Oh yeah duh. :)",
  "id" : 431258262940704769,
  "in_reply_to_status_id" : 431257270039478272,
  "created_at" : "2014-02-06 02:49:16 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 10, 26 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431247027305869312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8045008602, -122.2949490962 ]
  },
  "id_str" : "431256555900899328",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @tonystubblebine This is a stupid question but why does it have to be anonymous if it's already public?",
  "id" : 431256555900899328,
  "in_reply_to_status_id" : 431247027305869312,
  "created_at" : "2014-02-06 02:42:29 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melody Joy Kramer",
      "screen_name" : "mkramer",
      "indices" : [ 0, 8 ],
      "id_str" : "10232022",
      "id" : 10232022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431245582137835520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7798456563, -122.4136136454 ]
  },
  "id_str" : "431252238288179200",
  "in_reply_to_user_id" : 10232022,
  "text" : "@mkramer What would you want to use it for? Feel free to email if it doesn't fit in a tweet. Buster at Twitter",
  "id" : 431252238288179200,
  "in_reply_to_status_id" : 431245582137835520,
  "created_at" : "2014-02-06 02:25:20 +0000",
  "in_reply_to_screen_name" : "mkramer",
  "in_reply_to_user_id_str" : "10232022",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melody Joy Kramer",
      "screen_name" : "mkramer",
      "indices" : [ 0, 8 ],
      "id_str" : "10232022",
      "id" : 10232022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431245582137835520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763052678, -122.4173400571 ]
  },
  "id_str" : "431248461103919104",
  "in_reply_to_user_id" : 10232022,
  "text" : "@mkramer Not at the moment.",
  "id" : 431248461103919104,
  "in_reply_to_status_id" : 431245582137835520,
  "created_at" : "2014-02-06 02:10:19 +0000",
  "in_reply_to_screen_name" : "mkramer",
  "in_reply_to_user_id_str" : "10232022",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elyssa Toda",
      "screen_name" : "Elyssa",
      "indices" : [ 0, 7 ],
      "id_str" : "20193866",
      "id" : 20193866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431216570065371136",
  "geo" : { },
  "id_str" : "431217506322104320",
  "in_reply_to_user_id" : 20193866,
  "text" : "@elyssa That's amazing. Where did you get this quote from?",
  "id" : 431217506322104320,
  "in_reply_to_status_id" : 431216570065371136,
  "created_at" : "2014-02-06 00:07:19 +0000",
  "in_reply_to_screen_name" : "Elyssa",
  "in_reply_to_user_id_str" : "20193866",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaby Pe\u00F1a",
      "screen_name" : "gpena",
      "indices" : [ 3, 9 ],
      "id_str" : "133583134",
      "id" : 133583134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/0jqN2dygH7",
      "expanded_url" : "https:\/\/blog.twitter.com\/2014\/introducing-twitter-data-grants",
      "display_url" : "blog.twitter.com\/2014\/introduci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431210975748837376",
  "text" : "RT @gpena: Research institutions: submit a proposal for consideration to our Twitter Data Grants pilot program by March 15. https:\/\/t.co\/0j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/0jqN2dygH7",
        "expanded_url" : "https:\/\/blog.twitter.com\/2014\/introducing-twitter-data-grants",
        "display_url" : "blog.twitter.com\/2014\/introduci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "431210029954244609",
    "text" : "Research institutions: submit a proposal for consideration to our Twitter Data Grants pilot program by March 15. https:\/\/t.co\/0jqN2dygH7",
    "id" : 431210029954244609,
    "created_at" : "2014-02-05 23:37:37 +0000",
    "user" : {
      "name" : "Gaby Pe\u00F1a",
      "screen_name" : "gpena",
      "protected" : false,
      "id_str" : "133583134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442818523421618176\/bb149sfT_normal.jpeg",
      "id" : 133583134,
      "verified" : false
    }
  },
  "id" : 431210975748837376,
  "created_at" : "2014-02-05 23:41:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TwitterIR",
      "screen_name" : "TwitterIR",
      "indices" : [ 3, 13 ],
      "id_str" : "1603818258",
      "id" : 1603818258
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TwitterIR\/status\/431175668122935297\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/74Eva0gRqc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfvX_FJCUAAx-_w.png",
      "id_str" : "431175668055822336",
      "id" : 431175668055822336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfvX_FJCUAAx-_w.png",
      "sizes" : [ {
        "h" : 475,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/74Eva0gRqc"
    } ],
    "hashtags" : [ {
      "text" : "TWTRearnings",
      "indices" : [ 86, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431175787501191168",
  "text" : "RT @TwitterIR: Twitter Reach: Q4\u201913 avg Monthly Active Users 241 million, up 30% y\/y. #TWTRearnings http:\/\/t.co\/74Eva0gRqc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TwitterIR\/status\/431175668122935297\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/74Eva0gRqc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfvX_FJCUAAx-_w.png",
        "id_str" : "431175668055822336",
        "id" : 431175668055822336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfvX_FJCUAAx-_w.png",
        "sizes" : [ {
          "h" : 475,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 215,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/74Eva0gRqc"
      } ],
      "hashtags" : [ {
        "text" : "TWTRearnings",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431175668122935297",
    "text" : "Twitter Reach: Q4\u201913 avg Monthly Active Users 241 million, up 30% y\/y. #TWTRearnings http:\/\/t.co\/74Eva0gRqc",
    "id" : 431175668122935297,
    "created_at" : "2014-02-05 21:21:04 +0000",
    "user" : {
      "name" : "TwitterIR",
      "screen_name" : "TwitterIR",
      "protected" : false,
      "id_str" : "1603818258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438749467789914112\/fD89GawL_normal.png",
      "id" : 1603818258,
      "verified" : true
    }
  },
  "id" : 431175787501191168,
  "created_at" : "2014-02-05 21:21:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "Marc Andreessen",
      "screen_name" : "pmarca",
      "indices" : [ 37, 44 ],
      "id_str" : "5943622",
      "id" : 5943622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/Fc1xxtsSGj",
      "expanded_url" : "https:\/\/twitter.com\/isaach\/timelines\/431163532529246208",
      "display_url" : "twitter.com\/isaach\/timelin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431169432556036096",
  "text" : "RT @isaach: some smart thinking from @pmarca on the evolution of the news business https:\/\/t.co\/Fc1xxtsSGj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marc Andreessen",
        "screen_name" : "pmarca",
        "indices" : [ 25, 32 ],
        "id_str" : "5943622",
        "id" : 5943622
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/Fc1xxtsSGj",
        "expanded_url" : "https:\/\/twitter.com\/isaach\/timelines\/431163532529246208",
        "display_url" : "twitter.com\/isaach\/timelin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "431167700174258176",
    "text" : "some smart thinking from @pmarca on the evolution of the news business https:\/\/t.co\/Fc1xxtsSGj",
    "id" : 431167700174258176,
    "created_at" : "2014-02-05 20:49:25 +0000",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430605387117494272\/lmplHwca_normal.png",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 431169432556036096,
  "created_at" : "2014-02-05 20:56:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Harris",
      "screen_name" : "jjhnumber27",
      "indices" : [ 49, 61 ],
      "id_str" : "44913222",
      "id" : 44913222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/3C27YWpEIi",
      "expanded_url" : "http:\/\/number27.org\/27",
      "display_url" : "number27.org\/27"
    } ]
  },
  "in_reply_to_status_id_str" : "431158882820300800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7766953619, -122.4174639115 ]
  },
  "id_str" : "431163329348792320",
  "in_reply_to_user_id" : 44913222,
  "text" : "It's also the 1st number that comes after 26! RT @jjhnumber27: These are some of the reasons I love the number 27: http:\/\/t.co\/3C27YWpEIi",
  "id" : 431163329348792320,
  "in_reply_to_status_id" : 431158882820300800,
  "created_at" : "2014-02-05 20:32:03 +0000",
  "in_reply_to_screen_name" : "jjhnumber27",
  "in_reply_to_user_id_str" : "44913222",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MediaREDEF",
      "screen_name" : "MediaREDEF",
      "indices" : [ 19, 30 ],
      "id_str" : "24438551",
      "id" : 24438551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/DuyZ1O18KJ",
      "expanded_url" : "http:\/\/slate.me\/1lzHxYu",
      "display_url" : "slate.me\/1lzHxYu"
    } ]
  },
  "in_reply_to_status_id_str" : "430972844391280640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859705044, -122.275459366 ]
  },
  "id_str" : "430973968665681920",
  "in_reply_to_user_id" : 24438551,
  "text" : "So is WhatsApp. RT @MediaREDEF: \"Paper\" Is a Terrible Name if You're Trying to Brand the Future http:\/\/t.co\/DuyZ1O18KJ",
  "id" : 430973968665681920,
  "in_reply_to_status_id" : 430972844391280640,
  "created_at" : "2014-02-05 07:59:35 +0000",
  "in_reply_to_screen_name" : "MediaREDEF",
  "in_reply_to_user_id_str" : "24438551",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430940323398045696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597051278, -122.2755074782 ]
  },
  "id_str" : "430940921002078208",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Loved those too. Meaning to read In the Plex to round out the series too.",
  "id" : 430940921002078208,
  "in_reply_to_status_id" : 430940323398045696,
  "created_at" : "2014-02-05 05:48:16 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 3, 12 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Jackson Latka",
      "screen_name" : "jacksonlatka",
      "indices" : [ 53, 66 ],
      "id_str" : "10022442",
      "id" : 10022442
    }, {
      "name" : "Basecamp",
      "screen_name" : "37signals",
      "indices" : [ 88, 98 ],
      "id_str" : "11132462",
      "id" : 11132462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/CwAl6FgSG3",
      "expanded_url" : "https:\/\/37signals.com\/",
      "display_url" : "37signals.com"
    } ]
  },
  "geo" : { },
  "id_str" : "430940625127497728",
  "text" : "RT @arainert: Chalk one up for focus. Good stuff. RT @jacksonlatka: Wow, big changes at @37signals, I mean Basecamp: https:\/\/t.co\/CwAl6FgSG3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jackson Latka",
        "screen_name" : "jacksonlatka",
        "indices" : [ 39, 52 ],
        "id_str" : "10022442",
        "id" : 10022442
      }, {
        "name" : "Basecamp",
        "screen_name" : "37signals",
        "indices" : [ 74, 84 ],
        "id_str" : "11132462",
        "id" : 11132462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/CwAl6FgSG3",
        "expanded_url" : "https:\/\/37signals.com\/",
        "display_url" : "37signals.com"
      } ]
    },
    "in_reply_to_status_id_str" : "430936998132858880",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 40.9526405762, -73.7302943633 ]
    },
    "id_str" : "430938073485291521",
    "in_reply_to_user_id" : 10022442,
    "text" : "Chalk one up for focus. Good stuff. RT @jacksonlatka: Wow, big changes at @37signals, I mean Basecamp: https:\/\/t.co\/CwAl6FgSG3",
    "id" : 430938073485291521,
    "in_reply_to_status_id" : 430936998132858880,
    "created_at" : "2014-02-05 05:36:57 +0000",
    "in_reply_to_screen_name" : "jacksonlatka",
    "in_reply_to_user_id_str" : "10022442",
    "user" : {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "protected" : false,
      "id_str" : "7482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444089158274154496\/ZePPNQzQ_normal.jpeg",
      "id" : 7482,
      "verified" : false
    }
  },
  "id" : 430940625127497728,
  "created_at" : "2014-02-05 05:47:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430938281510174721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597223561, -122.2755901352 ]
  },
  "id_str" : "430939766373109761",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert I'm pretty predictable: Antifragile, Thinking Fast and Slow, and How to Create a Mind. You?",
  "id" : 430939766373109761,
  "in_reply_to_status_id" : 430938281510174721,
  "created_at" : "2014-02-05 05:43:41 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Simler",
      "screen_name" : "KevinSimler",
      "indices" : [ 0, 12 ],
      "id_str" : "267366403",
      "id" : 267366403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430925224591106048",
  "geo" : { },
  "id_str" : "430928319685468160",
  "in_reply_to_user_id" : 267366403,
  "text" : "@KevinSimler It ties together many of my favorite topics: mental models, the umwelt, and UX. Has this idea been explored anywhere else?",
  "id" : 430928319685468160,
  "in_reply_to_status_id" : 430925224591106048,
  "created_at" : "2014-02-05 04:58:12 +0000",
  "in_reply_to_screen_name" : "KevinSimler",
  "in_reply_to_user_id_str" : "267366403",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/430926094837886976\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/vVKAG2SqeB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bfr0__yCEAA-rxA.jpg",
      "id_str" : "430926094657523712",
      "id" : 430926094657523712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bfr0__yCEAA-rxA.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/vVKAG2SqeB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597230926, -122.2755859372 ]
  },
  "id_str" : "430926094837886976",
  "text" : "8:36pm Hello Sope. http:\/\/t.co\/vVKAG2SqeB",
  "id" : 430926094837886976,
  "created_at" : "2014-02-05 04:49:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Simler",
      "screen_name" : "KevinSimler",
      "indices" : [ 76, 88 ],
      "id_str" : "267366403",
      "id" : 267366403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/lZMnXm2Y5k",
      "expanded_url" : "http:\/\/kevinsimler.quora.com\/UX-and-the-Civilizing-Process",
      "display_url" : "kevinsimler.quora.com\/UX-and-the-Civ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430924050836103168",
  "text" : "\"The concept of a person is the most important interface ever developed.\u201D - @KevinSimler in this great essay: http:\/\/t.co\/lZMnXm2Y5k",
  "id" : 430924050836103168,
  "created_at" : "2014-02-05 04:41:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 0, 6 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 7, 16 ],
      "id_str" : "14986129",
      "id" : 14986129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430919047602266112",
  "geo" : { },
  "id_str" : "430923543392423936",
  "in_reply_to_user_id" : 631823,
  "text" : "@couch @irondavy I\u2019ve read that before but just loved reading it again. David, surprised it\u2019s not in your canon.",
  "id" : 430923543392423936,
  "in_reply_to_status_id" : 430919047602266112,
  "created_at" : "2014-02-05 04:39:13 +0000",
  "in_reply_to_screen_name" : "couch",
  "in_reply_to_user_id_str" : "631823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satya Nadella",
      "screen_name" : "satyanadella",
      "indices" : [ 20, 33 ],
      "id_str" : "20571756",
      "id" : 20571756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430890529472004096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7798267906, -122.4136411473 ]
  },
  "id_str" : "430890852567638017",
  "in_reply_to_user_id" : 20571756,
  "text" : "Smart man --&gt; RT @satyanadella: first commitment as CEO...i won't wait 4 years between tweets!",
  "id" : 430890852567638017,
  "in_reply_to_status_id" : 430890529472004096,
  "created_at" : "2014-02-05 02:29:19 +0000",
  "in_reply_to_screen_name" : "satyanadella",
  "in_reply_to_user_id_str" : "20571756",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/N1r3XKLtiY",
      "expanded_url" : "http:\/\/bit.ly\/1jReB9S",
      "display_url" : "bit.ly\/1jReB9S"
    } ]
  },
  "geo" : { },
  "id_str" : "430867125256073216",
  "text" : "\"Tech cos view movies, music, &amp; tv as INFORMATION. Directors, producers, musicians, etc view them as EXPERIENCES\" http:\/\/t.co\/N1r3XKLtiY",
  "id" : 430867125256073216,
  "created_at" : "2014-02-05 00:55:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Hossler",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    }, {
      "name" : "Secret",
      "screen_name" : "getsecret",
      "indices" : [ 26, 36 ],
      "id_str" : "2244765331",
      "id" : 2244765331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430807054366687232",
  "geo" : { },
  "id_str" : "430807188542480384",
  "in_reply_to_user_id" : 123116307,
  "text" : "@lilhossler Are you using @getsecret? Tons o' fun. :)",
  "id" : 430807188542480384,
  "in_reply_to_status_id" : 430807054366687232,
  "created_at" : "2014-02-04 20:56:52 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430803887050600448",
  "text" : "Someone loved my secret.",
  "id" : 430803887050600448,
  "created_at" : "2014-02-04 20:43:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eBay",
      "screen_name" : "eBay",
      "indices" : [ 97, 102 ],
      "id_str" : "19709040",
      "id" : 19709040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/puw2XqJQWl",
      "expanded_url" : "https:\/\/blog.twitter.com\/2014\/how-ebay-uses-cards-and-twitter-card-analytics",
      "display_url" : "blog.twitter.com\/2014\/how-ebay-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430779199494688768",
  "text" : "Still not sure what Twitter Cards are or whether or not they'd help your website\/app? Here's how @ebay uses them: https:\/\/t.co\/puw2XqJQWl",
  "id" : 430779199494688768,
  "created_at" : "2014-02-04 19:05:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "mattRaoul",
      "screen_name" : "mattRaoul",
      "indices" : [ 10, 20 ],
      "id_str" : "8863732",
      "id" : 8863732
    }, {
      "name" : "Ryan Tomorrow",
      "screen_name" : "ryantomorrow",
      "indices" : [ 21, 34 ],
      "id_str" : "14679007",
      "id" : 14679007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430744814729326592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763031883, -122.4167815166 ]
  },
  "id_str" : "430765092183875584",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @mattRaoul @ryantomorrow Roku's is also terrible by any comparison other than to other TV interfaces.",
  "id" : 430765092183875584,
  "in_reply_to_status_id" : 430744814729326592,
  "created_at" : "2014-02-04 18:09:35 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 10, 18 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Ted Rheingold",
      "screen_name" : "tedr",
      "indices" : [ 19, 24 ],
      "id_str" : "997",
      "id" : 997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430743122952585216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597016021, -122.2754542301 ]
  },
  "id_str" : "430744248959246336",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @djacobs @tedr Best part about it is that the card gives away the spoiler.",
  "id" : 430744248959246336,
  "in_reply_to_status_id" : 430743122952585216,
  "created_at" : "2014-02-04 16:46:46 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Zuckerberg",
      "screen_name" : "finkd",
      "indices" : [ 36, 42 ],
      "id_str" : "20749410",
      "id" : 20749410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/lHmRmLNMji",
      "expanded_url" : "https:\/\/www.facebook.com\/zuck\/posts\/10101250930776491",
      "display_url" : "facebook.com\/zuck\/posts\/101\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598024919, -122.275550158 ]
  },
  "id_str" : "430611813479104512",
  "text" : "Happy 10th birthday to Facebook and @finkd: https:\/\/t.co\/lHmRmLNMji",
  "id" : 430611813479104512,
  "created_at" : "2014-02-04 08:00:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mat honan",
      "screen_name" : "mat",
      "indices" : [ 0, 4 ],
      "id_str" : "11113",
      "id" : 11113
    }, {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 5, 16 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 17, 26 ],
      "id_str" : "761975",
      "id" : 761975
    }, {
      "name" : "Mike Kruzeniski",
      "screen_name" : "mkruz",
      "indices" : [ 27, 33 ],
      "id_str" : "6604912",
      "id" : 6604912
    }, {
      "name" : "Carolyn Penner",
      "screen_name" : "cpen",
      "indices" : [ 34, 39 ],
      "id_str" : "7694352",
      "id" : 7694352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430597016821829634",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596838419, -122.2756440051 ]
  },
  "id_str" : "430597422931120129",
  "in_reply_to_user_id" : 11113,
  "text" : "@mat @waxpancake @mathowie @mkruz @cpen If my score was an average of all games played it would be around 0.6.",
  "id" : 430597422931120129,
  "in_reply_to_status_id" : 430597016821829634,
  "created_at" : "2014-02-04 07:03:20 +0000",
  "in_reply_to_screen_name" : "mat",
  "in_reply_to_user_id_str" : "11113",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 0, 7 ],
      "id_str" : "1530531",
      "id" : 1530531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430595614334648320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596907042, -122.2756345625 ]
  },
  "id_str" : "430596252892270592",
  "in_reply_to_user_id" : 1530531,
  "text" : "@miradu Bon voyage!",
  "id" : 430596252892270592,
  "in_reply_to_status_id" : 430595614334648320,
  "created_at" : "2014-02-04 06:58:41 +0000",
  "in_reply_to_screen_name" : "miradu",
  "in_reply_to_user_id_str" : "1530531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430595473510916096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596891447, -122.2755162793 ]
  },
  "id_str" : "430596126786351104",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Beautiful!",
  "id" : 430596126786351104,
  "in_reply_to_status_id" : 430595473510916096,
  "created_at" : "2014-02-04 06:58:11 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Kruzeniski",
      "screen_name" : "mkruz",
      "indices" : [ 0, 6 ],
      "id_str" : "6604912",
      "id" : 6604912
    }, {
      "name" : "Carolyn Penner",
      "screen_name" : "cpen",
      "indices" : [ 7, 12 ],
      "id_str" : "7694352",
      "id" : 7694352
    }, {
      "name" : "mat honan",
      "screen_name" : "mat",
      "indices" : [ 13, 17 ],
      "id_str" : "11113",
      "id" : 11113
    }, {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 41, 52 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430590529525387264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597259398, -122.275556484 ]
  },
  "id_str" : "430592131892137984",
  "in_reply_to_user_id" : 6604912,
  "text" : "@mkruz @cpen @mat I'm afraid to ask what @waxpancake's high score is.",
  "id" : 430592131892137984,
  "in_reply_to_status_id" : 430590529525387264,
  "created_at" : "2014-02-04 06:42:18 +0000",
  "in_reply_to_screen_name" : "mkruz",
  "in_reply_to_user_id_str" : "6604912",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mat honan",
      "screen_name" : "mat",
      "indices" : [ 0, 4 ],
      "id_str" : "11113",
      "id" : 11113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430582181648293888",
  "geo" : { },
  "id_str" : "430585278982406144",
  "in_reply_to_user_id" : 11113,
  "text" : "@mat That\u2019s my high score after playing an embarrassing number of times.",
  "id" : 430585278982406144,
  "in_reply_to_status_id" : 430582181648293888,
  "created_at" : "2014-02-04 06:15:05 +0000",
  "in_reply_to_screen_name" : "mat",
  "in_reply_to_user_id_str" : "11113",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430573082734891009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597087705, -122.2753531857 ]
  },
  "id_str" : "430573448448864257",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Visit Berkeley!",
  "id" : 430573448448864257,
  "in_reply_to_status_id" : 430573082734891009,
  "created_at" : "2014-02-04 05:28:04 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 50, 57 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/iQKDmto68O",
      "expanded_url" : "http:\/\/flic.kr\/p\/jJRfqp",
      "display_url" : "flic.kr\/p\/jJRfqp"
    } ]
  },
  "geo" : { },
  "id_str" : "430561834123689984",
  "text" : "8:36pm Marla reading Niko's fave new book. Thanks @sharon! http:\/\/t.co\/iQKDmto68O",
  "id" : 430561834123689984,
  "created_at" : "2014-02-04 04:41:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Underwood",
      "screen_name" : "aunder",
      "indices" : [ 3, 10 ],
      "id_str" : "4265731",
      "id" : 4265731
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 17, 25 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/rnxoa8jMK1",
      "expanded_url" : "https:\/\/twitter.com\/jobs\/positions?jvi=osOcYfwa,Job",
      "display_url" : "twitter.com\/jobs\/positions\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430452462776897536",
  "text" : "RT @aunder: Love @twitter &amp; have experience in product management or marketing? We're hiring for our Ad products! https:\/\/t.co\/rnxoa8jMK1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 5, 13 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/rnxoa8jMK1",
        "expanded_url" : "https:\/\/twitter.com\/jobs\/positions?jvi=osOcYfwa,Job",
        "display_url" : "twitter.com\/jobs\/positions\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "430452311643537408",
    "text" : "Love @twitter &amp; have experience in product management or marketing? We're hiring for our Ad products! https:\/\/t.co\/rnxoa8jMK1",
    "id" : 430452311643537408,
    "created_at" : "2014-02-03 21:26:43 +0000",
    "user" : {
      "name" : "April Underwood",
      "screen_name" : "aunder",
      "protected" : false,
      "id_str" : "4265731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456677029643968513\/RMzTtk46_normal.jpeg",
      "id" : 4265731,
      "verified" : false
    }
  },
  "id" : 430452462776897536,
  "created_at" : "2014-02-03 21:27:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 37, 48 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/MzOHmMzS9N",
      "expanded_url" : "http:\/\/parislemon.com\/post\/75460673971\/simpler-games-simpler-times",
      "display_url" : "parislemon.com\/post\/754606739\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "430393162318610432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7933339182, -122.3964784026 ]
  },
  "id_str" : "430397998640533504",
  "in_reply_to_user_id" : 652193,
  "text" : "My high score on Flappy Bird is 5 RT @parislemon: Simpler Games, Simpler Times http:\/\/t.co\/MzOHmMzS9N",
  "id" : 430397998640533504,
  "in_reply_to_status_id" : 430393162318610432,
  "created_at" : "2014-02-03 17:50:53 +0000",
  "in_reply_to_screen_name" : "parislemon",
  "in_reply_to_user_id_str" : "652193",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Zhuo",
      "screen_name" : "joulee",
      "indices" : [ 3, 10 ],
      "id_str" : "17611446",
      "id" : 17611446
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/xYvtpqEguB",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/paper-stories-from-facebook\/id794163692",
      "display_url" : "itunes.apple.com\/us\/app\/paper-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430382091881033728",
  "text" : "RT @joulee: Facebook Paper, now live in the US App Store. Take it for a spin, I'd love to know what you think. https:\/\/t.co\/xYvtpqEguB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/xYvtpqEguB",
        "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/paper-stories-from-facebook\/id794163692",
        "display_url" : "itunes.apple.com\/us\/app\/paper-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "430381948519735297",
    "text" : "Facebook Paper, now live in the US App Store. Take it for a spin, I'd love to know what you think. https:\/\/t.co\/xYvtpqEguB",
    "id" : 430381948519735297,
    "created_at" : "2014-02-03 16:47:07 +0000",
    "user" : {
      "name" : "Julie Zhuo",
      "screen_name" : "joulee",
      "protected" : false,
      "id_str" : "17611446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3081241504\/9f3d8cfd0a6895424b2e8182f5e6b133_normal.png",
      "id" : 17611446,
      "verified" : false
    }
  },
  "id" : 430382091881033728,
  "created_at" : "2014-02-03 16:47:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/430202666610737152\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/VFTwlRnZFi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfhjC7uCIAAhAwf.jpg",
      "id_str" : "430202666455539712",
      "id" : 430202666455539712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfhjC7uCIAAhAwf.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/VFTwlRnZFi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596465542, -122.2754311689 ]
  },
  "id_str" : "430202666610737152",
  "text" : "8:36pm Continuing the post Super Bowl party with slinkies and jumping on the bed http:\/\/t.co\/VFTwlRnZFi",
  "id" : 430202666610737152,
  "created_at" : "2014-02-03 04:54:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/430151085135638528\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/YN6DWSS8pv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bfg0IfuCEAA3YCU.jpg",
      "id_str" : "430151084972052480",
      "id" : 430151084972052480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bfg0IfuCEAA3YCU.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/YN6DWSS8pv"
    } ],
    "hashtags" : [ {
      "text" : "sb48",
      "indices" : [ 44, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596636035, -122.2754969936 ]
  },
  "id_str" : "430151085135638528",
  "text" : "Our multigenerational friends and neighbors #sb48 party. http:\/\/t.co\/YN6DWSS8pv",
  "id" : 430151085135638528,
  "created_at" : "2014-02-03 01:29:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dick costolo",
      "screen_name" : "dickc",
      "indices" : [ 3, 9 ],
      "id_str" : "6385432",
      "id" : 6385432
    }, {
      "name" : "NYT 4th Down Bot",
      "screen_name" : "NYT4thDownBot",
      "indices" : [ 41, 55 ],
      "id_str" : "1977579223",
      "id" : 1977579223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430147165172670464",
  "text" : "RT @dickc: Super Bowl follow suggestion: @NYT4thDownBot  New York Times 4th down bot will tell you what it thinks team should do on any fou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NYT 4th Down Bot",
        "screen_name" : "NYT4thDownBot",
        "indices" : [ 30, 44 ],
        "id_str" : "1977579223",
        "id" : 1977579223
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "430125767867891712",
    "text" : "Super Bowl follow suggestion: @NYT4thDownBot  New York Times 4th down bot will tell you what it thinks team should do on any fourth down.",
    "id" : 430125767867891712,
    "created_at" : "2014-02-02 23:49:09 +0000",
    "user" : {
      "name" : "dick costolo",
      "screen_name" : "dickc",
      "protected" : false,
      "id_str" : "6385432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000652285709\/060bd6527bd63a4e3f241c954edd0e6f_normal.jpeg",
      "id" : 6385432,
      "verified" : false
    }
  },
  "id" : 430147165172670464,
  "created_at" : "2014-02-03 01:14:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gohawks",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430139023013593088",
  "text" : "22-0! Next stop 222-0? #gohawks!",
  "id" : 430139023013593088,
  "created_at" : "2014-02-03 00:41:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "hyped up aka popular",
      "screen_name" : "iano",
      "indices" : [ 10, 15 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430116895795453952",
  "geo" : { },
  "id_str" : "430122497556496384",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @iano A fave-spammer.",
  "id" : 430122497556496384,
  "in_reply_to_status_id" : 430116895795453952,
  "created_at" : "2014-02-02 23:36:09 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gohawks",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430122385144942592",
  "text" : "2-0 on the first play! #gohawks!",
  "id" : 430122385144942592,
  "created_at" : "2014-02-02 23:35:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "hyped up aka popular",
      "screen_name" : "iano",
      "indices" : [ 10, 15 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430113343194808320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859674765, -122.2754528188 ]
  },
  "id_str" : "430116784331427840",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @iano Weird. I'll look into it tomorrow.",
  "id" : 430116784331427840,
  "in_reply_to_status_id" : 430113343194808320,
  "created_at" : "2014-02-02 23:13:27 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "hyped up aka popular",
      "screen_name" : "iano",
      "indices" : [ 10, 15 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/LFxhYjPpdS",
      "expanded_url" : "https:\/\/blog.twitter.com\/2014\/introducing-analytics-for-twitter-cards",
      "display_url" : "blog.twitter.com\/2014\/introduci\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "430101535373410305",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596620436, -122.2755301578 ]
  },
  "id_str" : "430106131088678912",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @iano They're mostly auto-approved these days. Also, you'll get all kinds of free analytics now. Do it! https:\/\/t.co\/LFxhYjPpdS",
  "id" : 430106131088678912,
  "in_reply_to_status_id" : 430101535373410305,
  "created_at" : "2014-02-02 22:31:07 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430095562939981824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8572053795, -122.2673690774 ]
  },
  "id_str" : "430097131920044032",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Got it! Are we supposed to take pictures of the TV and post stuff?",
  "id" : 430097131920044032,
  "in_reply_to_status_id" : 430095562939981824,
  "created_at" : "2014-02-02 21:55:21 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ESPN",
      "screen_name" : "espn",
      "indices" : [ 3, 8 ],
      "id_str" : "2557521",
      "id" : 2557521
    }, {
      "name" : "Seattle Seahawks",
      "screen_name" : "Seahawks",
      "indices" : [ 40, 49 ],
      "id_str" : "23642374",
      "id" : 23642374
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/espn\/status\/430073812202176512\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/IvIBc0fwUf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bfft2m3CAAAaxEj.jpg",
      "id_str" : "430073811837255680",
      "id" : 430073811837255680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bfft2m3CAAAaxEj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IvIBc0fwUf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430080326400868352",
  "text" : "RT @espn: Retweet if you\u2019re picking the @Seahawks to win Super Bowl XLVIII. http:\/\/t.co\/IvIBc0fwUf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Seattle Seahawks",
        "screen_name" : "Seahawks",
        "indices" : [ 30, 39 ],
        "id_str" : "23642374",
        "id" : 23642374
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/espn\/status\/430073812202176512\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/IvIBc0fwUf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bfft2m3CAAAaxEj.jpg",
        "id_str" : "430073811837255680",
        "id" : 430073811837255680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bfft2m3CAAAaxEj.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/IvIBc0fwUf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "430073812202176512",
    "text" : "Retweet if you\u2019re picking the @Seahawks to win Super Bowl XLVIII. http:\/\/t.co\/IvIBc0fwUf",
    "id" : 430073812202176512,
    "created_at" : "2014-02-02 20:22:41 +0000",
    "user" : {
      "name" : "ESPN",
      "screen_name" : "espn",
      "protected" : false,
      "id_str" : "2557521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3600523804\/6614506a2597377173e5ec85fdde665d_normal.jpeg",
      "id" : 2557521,
      "verified" : true
    }
  },
  "id" : 430080326400868352,
  "created_at" : "2014-02-02 20:48:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SB48",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859668664, -122.2754237757 ]
  },
  "id_str" : "430078244184809472",
  "text" : "How much collective brain damage am I complicit in endorsing by watching the Super Bowl today? #SB48",
  "id" : 430078244184809472,
  "created_at" : "2014-02-02 20:40:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SB48",
      "indices" : [ 88, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595916545, -122.2754310332 ]
  },
  "id_str" : "430073263079710720",
  "text" : "I'm not used to watching regular TV. My appetite for pizza has gone up like 5x already. #SB48",
  "id" : 430073263079710720,
  "created_at" : "2014-02-02 20:20:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Torres",
      "screen_name" : "TorresChess",
      "indices" : [ 0, 12 ],
      "id_str" : "928501447",
      "id" : 928501447
    }, {
      "name" : "andy kiang",
      "screen_name" : "andyk",
      "indices" : [ 13, 19 ],
      "id_str" : "2069",
      "id" : 2069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430058649902256128",
  "geo" : { },
  "id_str" : "430063168740532224",
  "in_reply_to_user_id" : 928501447,
  "text" : "@TorresChess @andyk I agree that calling this \u201Cgame theory\u201D is silly. It\u2019s just a good strategy.",
  "id" : 430063168740532224,
  "in_reply_to_status_id" : 430058649902256128,
  "created_at" : "2014-02-02 19:40:24 +0000",
  "in_reply_to_screen_name" : "TorresChess",
  "in_reply_to_user_id_str" : "928501447",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andy kiang",
      "screen_name" : "andyk",
      "indices" : [ 17, 23 ],
      "id_str" : "2069",
      "id" : 2069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/H6e0M9hpvq",
      "expanded_url" : "http:\/\/www.businessinsider.com\/jeopardys-controversial-new-champion-is-using-game-theory-to-win-big-2014-2",
      "display_url" : "businessinsider.com\/jeopardys-cont\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "430033119563886592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8599827364, -122.2756699194 ]
  },
  "id_str" : "430050812405252096",
  "in_reply_to_user_id" : 2069,
  "text" : "Nice strategy RT @andyk: Jeopardy's Controversial New Champion Is Using Game Theory To Win Big http:\/\/t.co\/H6e0M9hpvq",
  "id" : 430050812405252096,
  "in_reply_to_status_id" : 430033119563886592,
  "created_at" : "2014-02-02 18:51:18 +0000",
  "in_reply_to_screen_name" : "andyk",
  "in_reply_to_user_id_str" : "2069",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430037916450975744",
  "text" : "\u201CWhat\u2019s happening? I don\u2019t like it.\u201D - Niko review of regular TV commercials",
  "id" : 430037916450975744,
  "created_at" : "2014-02-02 18:00:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Coleman",
      "screen_name" : "aaronc",
      "indices" : [ 0, 7 ],
      "id_str" : "9609062",
      "id" : 9609062
    }, {
      "name" : "geoffclapp",
      "screen_name" : "geoffclapp",
      "indices" : [ 8, 19 ],
      "id_str" : "12118392",
      "id" : 12118392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430030344486518784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596842044, -122.2755710363 ]
  },
  "id_str" : "430031356161056768",
  "in_reply_to_user_id" : 9609062,
  "text" : "@aaronc @geoffclapp Agree, but will probably settle for iCloud. I just want to use Siri to call a self-driving Uber with my watch.",
  "id" : 430031356161056768,
  "in_reply_to_status_id" : 430030344486518784,
  "created_at" : "2014-02-02 17:33:59 +0000",
  "in_reply_to_screen_name" : "aaronc",
  "in_reply_to_user_id_str" : "9609062",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Coleman",
      "screen_name" : "aaronc",
      "indices" : [ 0, 7 ],
      "id_str" : "9609062",
      "id" : 9609062
    }, {
      "name" : "geoffclapp",
      "screen_name" : "geoffclapp",
      "indices" : [ 8, 19 ],
      "id_str" : "12118392",
      "id" : 12118392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430029618603507713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596518558, -122.2755888699 ]
  },
  "id_str" : "430029898539741184",
  "in_reply_to_user_id" : 2185,
  "text" : "@aaronc @geoffclapp And I highly doubt Apple would even consider that. It's not their style at all.",
  "id" : 430029898539741184,
  "in_reply_to_status_id" : 430029618603507713,
  "created_at" : "2014-02-02 17:28:12 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Coleman",
      "screen_name" : "aaronc",
      "indices" : [ 0, 7 ],
      "id_str" : "9609062",
      "id" : 9609062
    }, {
      "name" : "geoffclapp",
      "screen_name" : "geoffclapp",
      "indices" : [ 8, 19 ],
      "id_str" : "12118392",
      "id" : 12118392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430029273932382209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597314616, -122.2755250853 ]
  },
  "id_str" : "430029618603507713",
  "in_reply_to_user_id" : 2185,
  "text" : "@aaronc @geoffclapp The desire for open health data APIs assumes that there's something truly innovative that can be built with it.",
  "id" : 430029618603507713,
  "in_reply_to_status_id" : 430029273932382209,
  "created_at" : "2014-02-02 17:27:05 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Coleman",
      "screen_name" : "aaronc",
      "indices" : [ 0, 7 ],
      "id_str" : "9609062",
      "id" : 9609062
    }, {
      "name" : "geoffclapp",
      "screen_name" : "geoffclapp",
      "indices" : [ 8, 19 ],
      "id_str" : "12118392",
      "id" : 12118392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430028006133071872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597257344, -122.275706303 ]
  },
  "id_str" : "430029273932382209",
  "in_reply_to_user_id" : 9609062,
  "text" : "@aaronc @geoffclapp I do hope they build something more innovative than activity data storage.",
  "id" : 430029273932382209,
  "in_reply_to_status_id" : 430028006133071872,
  "created_at" : "2014-02-02 17:25:43 +0000",
  "in_reply_to_screen_name" : "aaronc",
  "in_reply_to_user_id_str" : "9609062",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 8, 15 ],
      "id_str" : "23640904",
      "id" : 23640904
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justinvitedmyself",
      "indices" : [ 33, 51 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430025048506646528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597135506, -122.2754263513 ]
  },
  "id_str" : "430028037459959810",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey @emoore Count me in too! #justinvitedmyself",
  "id" : 430028037459959810,
  "in_reply_to_status_id" : 430025048506646528,
  "created_at" : "2014-02-02 17:20:48 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430021138714865664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596529363, -122.2755260815 ]
  },
  "id_str" : "430024014841397248",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver When it's your last refuge for quality time to yourself.",
  "id" : 430024014841397248,
  "in_reply_to_status_id" : 430021138714865664,
  "created_at" : "2014-02-02 17:04:49 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zak Taylor",
      "screen_name" : "zakattacktaylor",
      "indices" : [ 0, 16 ],
      "id_str" : "105174527",
      "id" : 105174527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430014749703540736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596941161, -122.2754779931 ]
  },
  "id_str" : "430017296363315200",
  "in_reply_to_user_id" : 105174527,
  "text" : "@zakattacktaylor I loved that phase. And the squeeking.",
  "id" : 430017296363315200,
  "in_reply_to_status_id" : 430014749703540736,
  "created_at" : "2014-02-02 16:38:07 +0000",
  "in_reply_to_screen_name" : "zakattacktaylor",
  "in_reply_to_user_id_str" : "105174527",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie McInnis",
      "screen_name" : "katielmcinnis",
      "indices" : [ 3, 17 ],
      "id_str" : "857430554",
      "id" : 857430554
    }, {
      "name" : "ThinkProgress",
      "screen_name" : "thinkprogress",
      "indices" : [ 41, 55 ],
      "id_str" : "55355654",
      "id" : 55355654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/osiIcodXef",
      "expanded_url" : "http:\/\/thkpr.gs\/1i8pinr",
      "display_url" : "thkpr.gs\/1i8pinr"
    } ]
  },
  "geo" : { },
  "id_str" : "430016921858109440",
  "text" : "RT @katielmcinnis: Finally an app I need @thinkprogress: New app allows you to call out sexist ads during the Super Bowl http:\/\/t.co\/osiIco\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ThinkProgress",
        "screen_name" : "thinkprogress",
        "indices" : [ 22, 36 ],
        "id_str" : "55355654",
        "id" : 55355654
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/osiIcodXef",
        "expanded_url" : "http:\/\/thkpr.gs\/1i8pinr",
        "display_url" : "thkpr.gs\/1i8pinr"
      } ]
    },
    "geo" : { },
    "id_str" : "430012422448246784",
    "text" : "Finally an app I need @thinkprogress: New app allows you to call out sexist ads during the Super Bowl http:\/\/t.co\/osiIcodXef",
    "id" : 430012422448246784,
    "created_at" : "2014-02-02 16:18:45 +0000",
    "user" : {
      "name" : "Katie McInnis",
      "screen_name" : "katielmcinnis",
      "protected" : false,
      "id_str" : "857430554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448892518009028608\/j4u5Bveq_normal.jpeg",
      "id" : 857430554,
      "verified" : false
    }
  },
  "id" : 430016921858109440,
  "created_at" : "2014-02-02 16:36:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "geoffclapp",
      "screen_name" : "geoffclapp",
      "indices" : [ 0, 11 ],
      "id_str" : "12118392",
      "id" : 12118392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430016157874016256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597327636, -122.2755240223 ]
  },
  "id_str" : "430016596233306113",
  "in_reply_to_user_id" : 12118392,
  "text" : "@geoffclapp Yeah. Seems like a \"we ran out of good ideas\" kind of move. Still excited about iWatch despite this though.",
  "id" : 430016596233306113,
  "in_reply_to_status_id" : 430016157874016256,
  "created_at" : "2014-02-02 16:35:20 +0000",
  "in_reply_to_screen_name" : "geoffclapp",
  "in_reply_to_user_id_str" : "12118392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Wilson",
      "screen_name" : "fredwilson",
      "indices" : [ 56, 67 ],
      "id_str" : "1000591",
      "id" : 1000591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "skeptical",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/AzPMmzdnVd",
      "expanded_url" : "http:\/\/www.avc.com\/a_vc\/2014\/02\/ios8-health-data-and-open-data.html",
      "display_url" : "avc.com\/a_vc\/2014\/02\/i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "430003840553734144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596787667, -122.27548996 ]
  },
  "id_str" : "430013994242297856",
  "in_reply_to_user_id" : 1000591,
  "text" : "Because Passbook has been such a success. #skeptical RT @fredwilson: iOS8, Health Data, and Open Data http:\/\/t.co\/AzPMmzdnVd",
  "id" : 430013994242297856,
  "in_reply_to_status_id" : 430003840553734144,
  "created_at" : "2014-02-02 16:25:00 +0000",
  "in_reply_to_screen_name" : "fredwilson",
  "in_reply_to_user_id_str" : "1000591",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/EH9eqwgS1U",
      "expanded_url" : "http:\/\/mobile.nytimes.com\/2014\/02\/01\/business\/media\/super-bowl-sideshows-starring-puppies-kittens-and-fish.html?_r=0&referrer=",
      "display_url" : "mobile.nytimes.com\/2014\/02\/01\/bus\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596703429, -122.2755204701 ]
  },
  "id_str" : "430013011286171648",
  "text" : "\"None of these pet games are a threat to the real Super Bowl...\" http:\/\/t.co\/EH9eqwgS1U",
  "id" : 430013011286171648,
  "created_at" : "2014-02-02 16:21:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596878873, -122.2755961949 ]
  },
  "id_str" : "429879772437438465",
  "text" : "\"I'd be lost without my blogger.\" - SH",
  "id" : 429879772437438465,
  "created_at" : "2014-02-02 07:31:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/vsGuYAe2vw",
      "expanded_url" : "http:\/\/flic.kr\/p\/jFGyJW",
      "display_url" : "flic.kr\/p\/jFGyJW"
    } ]
  },
  "geo" : { },
  "id_str" : "429853590841069568",
  "text" : "8:36pm Cleansing my mind with some Sherlock after singing along to way too much of the Frozen soundtrack with Niko http:\/\/t.co\/vsGuYAe2vw",
  "id" : 429853590841069568,
  "created_at" : "2014-02-02 05:47:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Secret",
      "screen_name" : "getsecret",
      "indices" : [ 85, 95 ],
      "id_str" : "2244765331",
      "id" : 2244765331
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 97, 104 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429835359925850112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597603366, -122.2755184896 ]
  },
  "id_str" : "429836448062529537",
  "in_reply_to_user_id" : 2244765331,
  "text" : "Ooh, and follow! The added context about where each post came from is also great. RT @getsecret: @buster and follow.",
  "id" : 429836448062529537,
  "in_reply_to_status_id" : 429835359925850112,
  "created_at" : "2014-02-02 04:39:29 +0000",
  "in_reply_to_screen_name" : "getsecret",
  "in_reply_to_user_id_str" : "2244765331",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Secret",
      "screen_name" : "getsecret",
      "indices" : [ 28, 38 ],
      "id_str" : "2244765331",
      "id" : 2244765331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596161699, -122.2756270948 ]
  },
  "id_str" : "429834729710702592",
  "text" : "The thing I like best about @getsecret is the way they've combined like and retweet into a single heart action. Works really well.",
  "id" : 429834729710702592,
  "created_at" : "2014-02-02 04:32:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Carroll",
      "screen_name" : "PeteCarroll",
      "indices" : [ 3, 15 ],
      "id_str" : "15876379",
      "id" : 15876379
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "12s",
      "indices" : [ 51, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429825044173565953",
  "text" : "RT @PeteCarroll: \"SEA!!!! HAWKS!!!!\" One more time #12s!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "12s",
        "indices" : [ 34, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429817756834598913",
    "text" : "\"SEA!!!! HAWKS!!!!\" One more time #12s!",
    "id" : 429817756834598913,
    "created_at" : "2014-02-02 03:25:13 +0000",
    "user" : {
      "name" : "Pete Carroll",
      "screen_name" : "PeteCarroll",
      "protected" : false,
      "id_str" : "15876379",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465902719199223808\/TXUDvJhJ_normal.jpeg",
      "id" : 15876379,
      "verified" : true
    }
  },
  "id" : 429825044173565953,
  "created_at" : "2014-02-02 03:54:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    }, {
      "name" : "Kyle Kesterson",
      "screen_name" : "kylekesterson",
      "indices" : [ 12, 26 ],
      "id_str" : "20256785",
      "id" : 20256785
    }, {
      "name" : "Spark Weekend",
      "screen_name" : "sparkweekend",
      "indices" : [ 27, 40 ],
      "id_str" : "2241719984",
      "id" : 2241719984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429745385544744960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597146409, -122.2756017724 ]
  },
  "id_str" : "429747610270699520",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman @kylekesterson @sparkweekend Thanks for the shout out! I'm still a Seattleite at heart and miss you all too!",
  "id" : 429747610270699520,
  "in_reply_to_status_id" : 429745385544744960,
  "created_at" : "2014-02-01 22:46:29 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429741196798201856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596247873, -122.2755643075 ]
  },
  "id_str" : "429743123674046464",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame Yeah. Exactly.",
  "id" : 429743123674046464,
  "in_reply_to_status_id" : 429741196798201856,
  "created_at" : "2014-02-01 22:28:39 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/EbAEnfxkva",
      "expanded_url" : "http:\/\/nyti.ms\/1fxzSEc",
      "display_url" : "nyti.ms\/1fxzSEc"
    } ]
  },
  "geo" : { },
  "id_str" : "429740166840737792",
  "text" : "What\u2019s your favorite Woody Allen movie? Before you answer, read this: \"An Open Letter From Dylan Farrow\" http:\/\/t.co\/EbAEnfxkva",
  "id" : 429740166840737792,
  "created_at" : "2014-02-01 22:16:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429716928320786432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597502311, -122.2757566248 ]
  },
  "id_str" : "429717548188172288",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb No software, but the TV scanned stuff. But the channel names were all confusing and I had 2-3 of each channel.",
  "id" : 429717548188172288,
  "in_reply_to_status_id" : 429716928320786432,
  "created_at" : "2014-02-01 20:47:01 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429712542982615040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597472661, -122.2756760181 ]
  },
  "id_str" : "429716383081840640",
  "in_reply_to_user_id" : 2185,
  "text" : "In which I realize I spent my morning making it possible to watch FOX in my living room.",
  "id" : 429716383081840640,
  "in_reply_to_status_id" : 429712542982615040,
  "created_at" : "2014-02-01 20:42:24 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prashant S",
      "screen_name" : "CoolAssPuppy",
      "indices" : [ 0, 13 ],
      "id_str" : "2881611",
      "id" : 2881611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429713066981224448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597303005, -122.2756895574 ]
  },
  "id_str" : "429715943711707136",
  "in_reply_to_user_id" : 2881611,
  "text" : "@CoolAssPuppy Awesome thanks!",
  "id" : 429715943711707136,
  "in_reply_to_status_id" : 429713066981224448,
  "created_at" : "2014-02-01 20:40:39 +0000",
  "in_reply_to_screen_name" : "CoolAssPuppy",
  "in_reply_to_user_id_str" : "2881611",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iamdumb",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596983341, -122.275522519 ]
  },
  "id_str" : "429712542982615040",
  "text" : "Just got an antenna for our TV so we can have a Super Bowl party. How do I find out what channel it's on? I don't have cable. #iamdumb",
  "id" : 429712542982615040,
  "created_at" : "2014-02-01 20:27:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Broderick",
      "screen_name" : "MichelleBee",
      "indices" : [ 0, 12 ],
      "id_str" : "1059951",
      "id" : 1059951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429696612495921152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8413359539, -122.2932422548 ]
  },
  "id_str" : "429700879646605313",
  "in_reply_to_user_id" : 1059951,
  "text" : "@MichelleBee I'm gonna get everyone hooked and then offer a pro service for other days of the month.",
  "id" : 429700879646605313,
  "in_reply_to_status_id" : 429696612495921152,
  "created_at" : "2014-02-01 19:40:47 +0000",
  "in_reply_to_screen_name" : "MichelleBee",
  "in_reply_to_user_id_str" : "1059951",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597063013, -122.2754887865 ]
  },
  "id_str" : "429637657010774016",
  "text" : "Rabbit rabbit!",
  "id" : 429637657010774016,
  "created_at" : "2014-02-01 15:29:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]