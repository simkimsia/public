Grailbird.data.tweets_2014_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/bvn5YS69Ef",
      "expanded_url" : "http:\/\/flic.kr\/p\/mDE9Sf",
      "display_url" : "flic.kr\/p\/mDE9Sf"
    } ]
  },
  "geo" : { },
  "id_str" : "450848939970138112",
  "text" : "8:36pm Sick. At least happy that there's an episode of Cosmos to catch up on. http:\/\/t.co\/bvn5YS69Ef",
  "id" : 450848939970138112,
  "created_at" : "2014-04-01 04:15:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 3, 12 ],
      "id_str" : "2391",
      "id" : 2391
    }, {
      "name" : "Jesse Taggert",
      "screen_name" : "jtag",
      "indices" : [ 123, 128 ],
      "id_str" : "17912169",
      "id" : 17912169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/0EW4pqNgFP",
      "expanded_url" : "http:\/\/pulptastic.com\/james-mollison-where-children-sleep\/",
      "display_url" : "pulptastic.com\/james-mollison\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "450670794113175553",
  "text" : "RT @mulegirl: Here is your morning perspective. Photos of children and where they sleep around the world. Take a look (via @jtag):\n\nhttp:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jesse Taggert",
        "screen_name" : "jtag",
        "indices" : [ 109, 114 ],
        "id_str" : "17912169",
        "id" : 17912169
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/0EW4pqNgFP",
        "expanded_url" : "http:\/\/pulptastic.com\/james-mollison-where-children-sleep\/",
        "display_url" : "pulptastic.com\/james-mollison\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "450670442836013056",
    "text" : "Here is your morning perspective. Photos of children and where they sleep around the world. Take a look (via @jtag):\n\nhttp:\/\/t.co\/0EW4pqNgFP",
    "id" : 450670442836013056,
    "created_at" : "2014-03-31 16:26:21 +0000",
    "user" : {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "protected" : false,
      "id_str" : "2391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464497053972692992\/4tT8tOM6_normal.png",
      "id" : 2391,
      "verified" : false
    }
  },
  "id" : 450670794113175553,
  "created_at" : "2014-03-31 16:27:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Loftesness",
      "screen_name" : "dloft",
      "indices" : [ 0, 6 ],
      "id_str" : "13839772",
      "id" : 13839772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450478979879673856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8599179862, -122.2755623796 ]
  },
  "id_str" : "450480654002581505",
  "in_reply_to_user_id" : 13839772,
  "text" : "@dloft I bet there were exactly 21 kids in that class.",
  "id" : 450480654002581505,
  "in_reply_to_status_id" : 450478979879673856,
  "created_at" : "2014-03-31 03:52:12 +0000",
  "in_reply_to_screen_name" : "dloft",
  "in_reply_to_user_id_str" : "13839772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/450478588282695680\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/ymZ8Jaza0w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkBr42dCYAAnEFT.jpg",
      "id_str" : "450478587171201024",
      "id" : 450478587171201024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkBr42dCYAAnEFT.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ymZ8Jaza0w"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597651011, -122.2758365936 ]
  },
  "id_str" : "450478588282695680",
  "text" : "8:36pm Singing Let It Go on our way home from dinner http:\/\/t.co\/ymZ8Jaza0w",
  "id" : 450478588282695680,
  "created_at" : "2014-03-31 03:43:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450163274948935681",
  "geo" : { },
  "id_str" : "450360984729710592",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror What's the most popular way to run a discourse site at the moment?",
  "id" : 450360984729710592,
  "in_reply_to_status_id" : 450163274948935681,
  "created_at" : "2014-03-30 19:56:40 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duncan Rawlinson",
      "screen_name" : "thelastminute",
      "indices" : [ 3, 17 ],
      "id_str" : "482433",
      "id" : 482433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/2Jn4OZ26za",
      "expanded_url" : "http:\/\/pocket.co\/s58qc",
      "display_url" : "pocket.co\/s58qc"
    } ]
  },
  "geo" : { },
  "id_str" : "450344974085677056",
  "text" : "RT @thelastminute: What is the Multiverse, and why do we think it exists?  http:\/\/t.co\/2Jn4OZ26za",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/2Jn4OZ26za",
        "expanded_url" : "http:\/\/pocket.co\/s58qc",
        "display_url" : "pocket.co\/s58qc"
      } ]
    },
    "geo" : { },
    "id_str" : "450234324814938112",
    "text" : "What is the Multiverse, and why do we think it exists?  http:\/\/t.co\/2Jn4OZ26za",
    "id" : 450234324814938112,
    "created_at" : "2014-03-30 11:33:22 +0000",
    "user" : {
      "name" : "Duncan Rawlinson",
      "screen_name" : "thelastminute",
      "protected" : false,
      "id_str" : "482433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000672858299\/746aeb9806650182161bb0017a054825_normal.png",
      "id" : 482433,
      "verified" : false
    }
  },
  "id" : 450344974085677056,
  "created_at" : "2014-03-30 18:53:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Schawel",
      "screen_name" : "DavidSchawel",
      "indices" : [ 26, 39 ],
      "id_str" : "182642157",
      "id" : 182642157
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DavidSchawel\/status\/450052248601890817\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/2MoucaWcg5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj7oIe4IMAA_82e.jpg",
      "id_str" : "450052245208707072",
      "id" : 450052245208707072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj7oIe4IMAA_82e.jpg",
      "sizes" : [ {
        "h" : 209,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 481
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 481
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 481
      } ],
      "display_url" : "pic.twitter.com\/2MoucaWcg5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450052248601890817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597710934, -122.2753839289 ]
  },
  "id_str" : "450162033002967040",
  "in_reply_to_user_id" : 182642157,
  "text" : "Richest get richest-er RT @DavidSchawel: The gain in wealth in recent times has been almost exclusively in the 0.1% http:\/\/t.co\/2MoucaWcg5",
  "id" : 450162033002967040,
  "in_reply_to_status_id" : 450052248601890817,
  "created_at" : "2014-03-30 06:46:06 +0000",
  "in_reply_to_screen_name" : "DavidSchawel",
  "in_reply_to_user_id_str" : "182642157",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/450118596878798848\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/2eLpJ4jnaV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj8kef9CEAAliml.jpg",
      "id_str" : "450118594152501248",
      "id" : 450118594152501248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj8kef9CEAAliml.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2eLpJ4jnaV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597134755, -122.2754988688 ]
  },
  "id_str" : "450118596878798848",
  "text" : "8:36pm Dinner at Mua with Brett and Lucy! http:\/\/t.co\/2eLpJ4jnaV",
  "id" : 450118596878798848,
  "created_at" : "2014-03-30 03:53:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/450059029524398080\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/kDThYzIHBf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj7uTN6CEAAsBRF.jpg",
      "id_str" : "450059026701619200",
      "id" : 450059026701619200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj7uTN6CEAAsBRF.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/kDThYzIHBf"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/450059029524398080\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/kDThYzIHBf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj7uS4bCUAA6hEA.jpg",
      "id_str" : "450059020934467584",
      "id" : 450059020934467584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj7uS4bCUAA6hEA.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/kDThYzIHBf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597684853, -122.2755730032 ]
  },
  "id_str" : "450059029524398080",
  "text" : "Niko's ready to party. http:\/\/t.co\/kDThYzIHBf",
  "id" : 450059029524398080,
  "created_at" : "2014-03-29 23:56:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 0, 6 ],
      "id_str" : "8285392",
      "id" : 8285392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449947371942973440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597185645, -122.2755856099 ]
  },
  "id_str" : "449947700759244800",
  "in_reply_to_user_id" : 8285392,
  "text" : "@raffi Awesome, thanks!",
  "id" : 449947700759244800,
  "in_reply_to_status_id" : 449947371942973440,
  "created_at" : "2014-03-29 16:34:26 +0000",
  "in_reply_to_screen_name" : "raffi",
  "in_reply_to_user_id_str" : "8285392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 0, 6 ],
      "id_str" : "8285392",
      "id" : 8285392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449939099118759936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596942313, -122.2755291873 ]
  },
  "id_str" : "449947001384222720",
  "in_reply_to_user_id" : 8285392,
  "text" : "@raffi I want to do that! Where did you go?",
  "id" : 449947001384222720,
  "in_reply_to_status_id" : 449939099118759936,
  "created_at" : "2014-03-29 16:31:39 +0000",
  "in_reply_to_screen_name" : "raffi",
  "in_reply_to_user_id_str" : "8285392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Golis",
      "screen_name" : "agolis",
      "indices" : [ 3, 10 ],
      "id_str" : "15084970",
      "id" : 15084970
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/agolis\/status\/449899151627923456\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/C5FJSWrDod",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj5c5LSIcAAuY0y.jpg",
      "id_str" : "449899150134767616",
      "id" : 449899150134767616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj5c5LSIcAAuY0y.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/C5FJSWrDod"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/isJEuhvoZ7",
      "expanded_url" : "http:\/\/nyti.ms\/1dn9hvZ",
      "display_url" : "nyti.ms\/1dn9hvZ"
    } ]
  },
  "geo" : { },
  "id_str" : "449944869243351040",
  "text" : "RT @agolis: Surely this is Wes Anderson's next film: http:\/\/t.co\/isJEuhvoZ7 http:\/\/t.co\/C5FJSWrDod",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/agolis\/status\/449899151627923456\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/C5FJSWrDod",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj5c5LSIcAAuY0y.jpg",
        "id_str" : "449899150134767616",
        "id" : 449899150134767616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj5c5LSIcAAuY0y.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/C5FJSWrDod"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/isJEuhvoZ7",
        "expanded_url" : "http:\/\/nyti.ms\/1dn9hvZ",
        "display_url" : "nyti.ms\/1dn9hvZ"
      } ]
    },
    "geo" : { },
    "id_str" : "449899151627923456",
    "text" : "Surely this is Wes Anderson's next film: http:\/\/t.co\/isJEuhvoZ7 http:\/\/t.co\/C5FJSWrDod",
    "id" : 449899151627923456,
    "created_at" : "2014-03-29 13:21:31 +0000",
    "user" : {
      "name" : "Andrew Golis",
      "screen_name" : "agolis",
      "protected" : false,
      "id_str" : "15084970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425380628838633472\/6ku-nN49_normal.jpeg",
      "id" : 15084970,
      "verified" : false
    }
  },
  "id" : 449944869243351040,
  "created_at" : "2014-03-29 16:23:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/voxdotcom\/status\/448921303966552066\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/3TLPscgOfm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjrjjBpIUAE0BmZ.jpg",
      "id_str" : "448921303752658945",
      "id" : 448921303752658945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjrjjBpIUAE0BmZ.jpg",
      "sizes" : [ {
        "h" : 614,
        "resize" : "fit",
        "w" : 1079
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 193,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3TLPscgOfm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/o5fQsXdQpT",
      "expanded_url" : "http:\/\/www.vox.com\/elizabeth-kolbert-mass-extinction\/",
      "display_url" : "vox.com\/elizabeth-kolb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449801343327158272",
  "text" : "RT @voxdotcom: The scary truth about mass extinction: http:\/\/t.co\/o5fQsXdQpT http:\/\/t.co\/3TLPscgOfm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/voxdotcom\/status\/448921303966552066\/photo\/1",
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/3TLPscgOfm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjrjjBpIUAE0BmZ.jpg",
        "id_str" : "448921303752658945",
        "id" : 448921303752658945,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjrjjBpIUAE0BmZ.jpg",
        "sizes" : [ {
          "h" : 614,
          "resize" : "fit",
          "w" : 1079
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 193,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/3TLPscgOfm"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/o5fQsXdQpT",
        "expanded_url" : "http:\/\/www.vox.com\/elizabeth-kolbert-mass-extinction\/",
        "display_url" : "vox.com\/elizabeth-kolb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "448921303966552066",
    "text" : "The scary truth about mass extinction: http:\/\/t.co\/o5fQsXdQpT http:\/\/t.co\/3TLPscgOfm",
    "id" : 448921303966552066,
    "created_at" : "2014-03-26 20:35:54 +0000",
    "user" : {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "protected" : false,
      "id_str" : "2347049341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442785905246347265\/v6W3UuIL_normal.jpeg",
      "id" : 2347049341,
      "verified" : true
    }
  },
  "id" : 449801343327158272,
  "created_at" : "2014-03-29 06:52:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FiveThirtyEight",
      "screen_name" : "FiveThirtyEight",
      "indices" : [ 81, 97 ],
      "id_str" : "2303751216",
      "id" : 2303751216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/H8ismuTTqX",
      "expanded_url" : "http:\/\/fivethirtyeight.com\/features\/reports-of-a-drop-in-childhood-obesity-are-overblown\/",
      "display_url" : "fivethirtyeight.com\/features\/repor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449792794119266304",
  "text" : "When news that attempts to clearly relate truth and facts is a novelty. So happy @FiveThirtyEight exists.  http:\/\/t.co\/H8ismuTTqX",
  "id" : 449792794119266304,
  "created_at" : "2014-03-29 06:18:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 0, 14 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449772069496946688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597399674, -122.2755007253 ]
  },
  "id_str" : "449772475329425408",
  "in_reply_to_user_id" : 226976689,
  "text" : "@marcprecipice That's all I got from my search too. Lol'd at 7 minutes in heaven.",
  "id" : 449772475329425408,
  "in_reply_to_status_id" : 449772069496946688,
  "created_at" : "2014-03-29 04:58:09 +0000",
  "in_reply_to_screen_name" : "marcprecipice",
  "in_reply_to_user_id_str" : "226976689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597445352, -122.2755088211 ]
  },
  "id_str" : "449770583375360001",
  "text" : "Who can help find a timeline of popular computer-beats-human events? Bonus points if it also has wins that are likely coming up soon.",
  "id" : 449770583375360001,
  "created_at" : "2014-03-29 04:50:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 124, 138 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/FheoV6lia2",
      "expanded_url" : "http:\/\/blog.printf.net\/articles\/2012\/02\/23\/computers-are-very-good-at-the-game-of-go\/",
      "display_url" : "blog.printf.net\/articles\/2012\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "449763397567905793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597000987, -122.2754110025 ]
  },
  "id_str" : "449767328339591169",
  "in_reply_to_user_id" : 2185,
  "text" : "A bit more about the evolution of stronger Go-playing computers, and why some are disappointed: http:\/\/t.co\/FheoV6lia2 \/via @marcprecipice",
  "id" : 449767328339591169,
  "in_reply_to_status_id" : 449763397567905793,
  "created_at" : "2014-03-29 04:37:42 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 0, 14 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449765165907468289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597567051, -122.2755394807 ]
  },
  "id_str" : "449766840516894720",
  "in_reply_to_user_id" : 226976689,
  "text" : "@marcprecipice Your prediction was correct!",
  "id" : 449766840516894720,
  "in_reply_to_status_id" : 449765165907468289,
  "created_at" : "2014-03-29 04:35:45 +0000",
  "in_reply_to_screen_name" : "marcprecipice",
  "in_reply_to_user_id_str" : "226976689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/449764030727467009\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/jpOkVOBVmW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj3iAI_CIAAVG9M.jpg",
      "id_str" : "449764029846659072",
      "id" : 449764029846659072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj3iAI_CIAAVG9M.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jpOkVOBVmW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597144395, -122.2754665209 ]
  },
  "id_str" : "449764030727467009",
  "text" : "8:36pm Niko's new bedroom lanterns are a hit http:\/\/t.co\/jpOkVOBVmW",
  "id" : 449764030727467009,
  "created_at" : "2014-03-29 04:24:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/4mnXfNFyP9",
      "expanded_url" : "http:\/\/m.newyorker.com\/online\/blogs\/elements\/2014\/03\/the-electronic-holy-war.html",
      "display_url" : "m.newyorker.com\/online\/blogs\/e\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "449759797449990144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597133013, -122.2755555975 ]
  },
  "id_str" : "449763397567905793",
  "in_reply_to_user_id" : 2185,
  "text" : "Excellent article about why, 17 years after computers surpassed humans in Chess, it still can't win at Go: http:\/\/t.co\/4mnXfNFyP9",
  "id" : 449763397567905793,
  "in_reply_to_status_id" : 449759797449990144,
  "created_at" : "2014-03-29 04:22:04 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449759312135471104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597319641, -122.2755133063 ]
  },
  "id_str" : "449759797449990144",
  "in_reply_to_user_id" : 2185,
  "text" : "\"When the average chess game is nearly over, the average game of Go still has 140 moves left, each adding a new universe of possibilities.\"",
  "id" : 449759797449990144,
  "in_reply_to_status_id" : 449759312135471104,
  "created_at" : "2014-03-29 04:07:46 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597500986, -122.2754011812 ]
  },
  "id_str" : "449759312135471104",
  "text" : "\"In chess it takes 15 moves for the number of possible game states to equal the number of stars in the universe. Go gets there in 10 moves.\"",
  "id" : 449759312135471104,
  "created_at" : "2014-03-29 04:05:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/AMkHekZwV7",
      "expanded_url" : "http:\/\/blog.gaiam.com\/quotes\/authors\/alan-watts\/52341",
      "display_url" : "blog.gaiam.com\/quotes\/authors\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.857558, -122.274358 ]
  },
  "id_str" : "449717884860657665",
  "text" : "\"We do not come into this world; we come out of it, as leaves from a tree. As the ocean waves, the universe peoples.\" http:\/\/t.co\/AMkHekZwV7",
  "id" : 449717884860657665,
  "created_at" : "2014-03-29 01:21:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Ramez Naam",
      "screen_name" : "ramez",
      "indices" : [ 10, 16 ],
      "id_str" : "6044272",
      "id" : 6044272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449656486705131520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7886961305, -122.4046230442 ]
  },
  "id_str" : "449709580860129281",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @ramez I'm listening to Nexus now too. Fun stuff!",
  "id" : 449709580860129281,
  "in_reply_to_status_id" : 449656486705131520,
  "created_at" : "2014-03-29 00:48:13 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449631980842278912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7847133486, -122.4075139885 ]
  },
  "id_str" : "449709164277669889",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Ha!",
  "id" : 449709164277669889,
  "in_reply_to_status_id" : 449631980842278912,
  "created_at" : "2014-03-29 00:46:34 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 3, 10 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "hyped up aka popular",
      "screen_name" : "iano",
      "indices" : [ 69, 74 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/IirkItpQtG",
      "expanded_url" : "http:\/\/stratechery.com\/2014\/face-future\/",
      "display_url" : "stratechery.com\/2014\/face-futu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449708882613399552",
  "text" : "RT @sippey: \"For most people, computers are a means, not an end.\" cc @iano http:\/\/t.co\/IirkItpQtG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "hyped up aka popular",
        "screen_name" : "iano",
        "indices" : [ 57, 62 ],
        "id_str" : "14409856",
        "id" : 14409856
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/IirkItpQtG",
        "expanded_url" : "http:\/\/stratechery.com\/2014\/face-future\/",
        "display_url" : "stratechery.com\/2014\/face-futu\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 40.745852049, -73.9882219934 ]
    },
    "id_str" : "449625911516999680",
    "text" : "\"For most people, computers are a means, not an end.\" cc @iano http:\/\/t.co\/IirkItpQtG",
    "id" : 449625911516999680,
    "created_at" : "2014-03-28 19:15:45 +0000",
    "user" : {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "protected" : false,
      "id_str" : "4711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461184996825243648\/6X8lZVyu_normal.jpeg",
      "id" : 4711,
      "verified" : false
    }
  },
  "id" : 449708882613399552,
  "created_at" : "2014-03-29 00:45:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leerom Segal",
      "screen_name" : "leeromsegal",
      "indices" : [ 40, 52 ],
      "id_str" : "68258537",
      "id" : 68258537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/xzha5an6QR",
      "expanded_url" : "http:\/\/www.amazon.com\/The-Decoded-Company-Talent-Customers\/dp\/1591847141",
      "display_url" : "amazon.com\/The-Decoded-Co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449635104323670016",
  "text" : "\"Email is the ultimate faster horse.\" - @leeromsegal at a Twitter tech talk about their book \"Decoded Company\" http:\/\/t.co\/xzha5an6QR",
  "id" : 449635104323670016,
  "created_at" : "2014-03-28 19:52:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Westerfeld",
      "screen_name" : "ScottWesterfeld",
      "indices" : [ 3, 19 ],
      "id_str" : "43822174",
      "id" : 43822174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449577972886822912",
  "text" : "RT @ScottWesterfeld: Plot idea: 97% of the world's scientists contrive an environmental crisis, but are exposed by a plucky band of billion\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "446805144781348865",
    "text" : "Plot idea: 97% of the world's scientists contrive an environmental crisis, but are exposed by a plucky band of billionaires &amp; oil companies.",
    "id" : 446805144781348865,
    "created_at" : "2014-03-21 00:27:02 +0000",
    "user" : {
      "name" : "Scott Westerfeld",
      "screen_name" : "ScottWesterfeld",
      "protected" : false,
      "id_str" : "43822174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2487095672\/oothp0xvkmltk3bs3wl2_normal.png",
      "id" : 43822174,
      "verified" : true
    }
  },
  "id" : 449577972886822912,
  "created_at" : "2014-03-28 16:05:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Zhuo",
      "screen_name" : "joulee",
      "indices" : [ 3, 10 ],
      "id_str" : "17611446",
      "id" : 17611446
    }, {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 26, 34 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/anN7a2YZ4S",
      "expanded_url" : "https:\/\/medium.com\/p\/ed75a0ee7641",
      "display_url" : "medium.com\/p\/ed75a0ee7641"
    } ]
  },
  "geo" : { },
  "id_str" : "449443782522437632",
  "text" : "RT @joulee: A response to @dcurtis on the recent Facebook desktop redesign: https:\/\/t.co\/anN7a2YZ4S",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "dustin curtis",
        "screen_name" : "dcurtis",
        "indices" : [ 14, 22 ],
        "id_str" : "9395832",
        "id" : 9395832
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/anN7a2YZ4S",
        "expanded_url" : "https:\/\/medium.com\/p\/ed75a0ee7641",
        "display_url" : "medium.com\/p\/ed75a0ee7641"
      } ]
    },
    "geo" : { },
    "id_str" : "449412704503996417",
    "text" : "A response to @dcurtis on the recent Facebook desktop redesign: https:\/\/t.co\/anN7a2YZ4S",
    "id" : 449412704503996417,
    "created_at" : "2014-03-28 05:08:33 +0000",
    "user" : {
      "name" : "Julie Zhuo",
      "screen_name" : "joulee",
      "protected" : false,
      "id_str" : "17611446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3081241504\/9f3d8cfd0a6895424b2e8182f5e6b133_normal.png",
      "id" : 17611446,
      "verified" : false
    }
  },
  "id" : 449443782522437632,
  "created_at" : "2014-03-28 07:12:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 3, 13 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449434174064062465",
  "text" : "RT @kellianne: Oh shi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "449433625600069632",
    "text" : "Oh shi",
    "id" : 449433625600069632,
    "created_at" : "2014-03-28 06:31:41 +0000",
    "user" : {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "protected" : false,
      "id_str" : "7362142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000797915192\/b8af15473eb3d267e28d19076048ab99_normal.jpeg",
      "id" : 7362142,
      "verified" : false
    }
  },
  "id" : 449434174064062465,
  "created_at" : "2014-03-28 06:33:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rohini Pandhi",
      "screen_name" : "rohinip",
      "indices" : [ 0, 8 ],
      "id_str" : "36443871",
      "id" : 36443871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449419584114659328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8798326871, -122.2689736291 ]
  },
  "id_str" : "449432668891918337",
  "in_reply_to_user_id" : 36443871,
  "text" : "@rohinip Great meeting you too! Sad I had to leave early...",
  "id" : 449432668891918337,
  "in_reply_to_status_id" : 449419584114659328,
  "created_at" : "2014-03-28 06:27:52 +0000",
  "in_reply_to_screen_name" : "rohinip",
  "in_reply_to_user_id_str" : "36443871",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zoe finkel",
      "screen_name" : "zoefinkel",
      "indices" : [ 0, 10 ],
      "id_str" : "14167938",
      "id" : 14167938
    }, {
      "name" : "Sarah Milstein",
      "screen_name" : "SarahM",
      "indices" : [ 11, 18 ],
      "id_str" : "57",
      "id" : 57
    }, {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 19, 33 ],
      "id_str" : "226976689",
      "id" : 226976689
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 34, 50 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "worldscollide",
      "indices" : [ 83, 97 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449413413517537280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8797905778, -122.2690587818 ]
  },
  "id_str" : "449432186123337728",
  "in_reply_to_user_id" : 14167938,
  "text" : "@zoefinkel @SarahM @marcprecipice @tonystubblebine What you know these people too? #worldscollide",
  "id" : 449432186123337728,
  "in_reply_to_status_id" : 449413413517537280,
  "created_at" : "2014-03-28 06:25:57 +0000",
  "in_reply_to_screen_name" : "zoefinkel",
  "in_reply_to_user_id_str" : "14167938",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gameover",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.871779427, -122.2676685547 ]
  },
  "id_str" : "449409577386119168",
  "text" : "FlappyUber: watching an Uber circle around you in futility for 10 minutes. 0 points. #gameover",
  "id" : 449409577386119168,
  "created_at" : "2014-03-28 04:56:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Milstein",
      "screen_name" : "SarahM",
      "indices" : [ 0, 7 ],
      "id_str" : "57",
      "id" : 57
    }, {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 8, 22 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449406403216547840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8702173901, -122.2678547192 ]
  },
  "id_str" : "449408840329490432",
  "in_reply_to_user_id" : 57,
  "text" : "@SarahM @marcprecipice not like you had anything else to think about. We should have an east bay potluck next time you're in town!",
  "id" : 449408840329490432,
  "in_reply_to_status_id" : 449406403216547840,
  "created_at" : "2014-03-28 04:53:11 +0000",
  "in_reply_to_screen_name" : "SarahM",
  "in_reply_to_user_id_str" : "57",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bianca L. St.Louis",
      "screen_name" : "beLaurie",
      "indices" : [ 0, 9 ],
      "id_str" : "92143477",
      "id" : 92143477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449407474668285952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8702035637, -122.2679285776 ]
  },
  "id_str" : "449408067906437121",
  "in_reply_to_user_id" : 92143477,
  "text" : "@beLaurie It was my pleasure! Great meeting you!",
  "id" : 449408067906437121,
  "in_reply_to_status_id" : 449407474668285952,
  "created_at" : "2014-03-28 04:50:07 +0000",
  "in_reply_to_screen_name" : "beLaurie",
  "in_reply_to_user_id_str" : "92143477",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 0, 14 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449397515037585408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78894951, -122.4020029399 ]
  },
  "id_str" : "449399853118803968",
  "in_reply_to_user_id" : 226976689,
  "text" : "@marcprecipice Wait, you were there?",
  "id" : 449399853118803968,
  "in_reply_to_status_id" : 449397515037585408,
  "created_at" : "2014-03-28 04:17:29 +0000",
  "in_reply_to_screen_name" : "marcprecipice",
  "in_reply_to_user_id_str" : "226976689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Milstein",
      "screen_name" : "SarahM",
      "indices" : [ 65, 72 ],
      "id_str" : "57",
      "id" : 57
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/MIA0iU9elV",
      "expanded_url" : "http:\/\/flic.kr\/p\/mvoUDK",
      "display_url" : "flic.kr\/p\/mvoUDK"
    } ]
  },
  "geo" : { },
  "id_str" : "449396673450901506",
  "text" : "8:36pm Walking to BART from a fun quick mentoring meetup. Thanks @sarahm! http:\/\/t.co\/MIA0iU9elV",
  "id" : 449396673450901506,
  "created_at" : "2014-03-28 04:04:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Svbtle",
      "screen_name" : "Svbtle",
      "indices" : [ 17, 24 ],
      "id_str" : "776098190",
      "id" : 776098190
    }, {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 89, 97 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dangerdanger",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/OnDMdiVqlV",
      "expanded_url" : "http:\/\/dcurt.is\/facebooks-predicament",
      "display_url" : "dcurt.is\/facebooks-pred\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "449308955563798528",
  "geo" : { },
  "id_str" : "449309810786189312",
  "in_reply_to_user_id" : 776098190,
  "text" : "#dangerdanger RT @Svbtle: Whatever goes up, that\u2019s what we do: http:\/\/t.co\/OnDMdiVqlV by @dcurtis",
  "id" : 449309810786189312,
  "in_reply_to_status_id" : 449308955563798528,
  "created_at" : "2014-03-27 22:19:41 +0000",
  "in_reply_to_screen_name" : "Svbtle",
  "in_reply_to_user_id_str" : "776098190",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 8, 16 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449185435496251392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595719394, -122.2755263374 ]
  },
  "id_str" : "449203121189687296",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @chanian Rebalancing more than once a year isn't necessarily a good thing. But overall, yeah, fees are low and worth the simplicity.",
  "id" : 449203121189687296,
  "in_reply_to_status_id" : 449185435496251392,
  "created_at" : "2014-03-27 15:15:44 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 0, 8 ],
      "id_str" : "22891211",
      "id" : 22891211
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 9, 16 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449082577026961408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596852938, -122.2755154453 ]
  },
  "id_str" : "449083069220134913",
  "in_reply_to_user_id" : 22891211,
  "text" : "@chanian @harryh Not convinced. it's easy to do all of those things with a few ETFs and an hour every 366 days.",
  "id" : 449083069220134913,
  "in_reply_to_status_id" : 449082577026961408,
  "created_at" : "2014-03-27 07:18:41 +0000",
  "in_reply_to_screen_name" : "chanian",
  "in_reply_to_user_id_str" : "22891211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438830341101735936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859718355, -122.2755736628 ]
  },
  "id_str" : "449081694058844161",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Was just researching this myself and think it's easier to just invest in market indexes. What convinced you?",
  "id" : 449081694058844161,
  "in_reply_to_status_id" : 438830341101735936,
  "created_at" : "2014-03-27 07:13:14 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/icJVBHrgwN",
      "expanded_url" : "https:\/\/blog.twitter.com\/2014\/photos-just-got-more-social",
      "display_url" : "blog.twitter.com\/2014\/photos-ju\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448923717716824064",
  "text" : "RT @twitter: Photos are getting more social. We're unveiling two new features: photo tagging &amp; adding up to 4 photos per Tweet: https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/icJVBHrgwN",
        "expanded_url" : "https:\/\/blog.twitter.com\/2014\/photos-just-got-more-social",
        "display_url" : "blog.twitter.com\/2014\/photos-ju\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "448921559172780032",
    "text" : "Photos are getting more social. We're unveiling two new features: photo tagging &amp; adding up to 4 photos per Tweet: https:\/\/t.co\/icJVBHrgwN",
    "id" : 448921559172780032,
    "created_at" : "2014-03-26 20:36:54 +0000",
    "user" : {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "protected" : false,
      "id_str" : "783214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2284174758\/v65oai7fxn47qv9nectx_normal.png",
      "id" : 783214,
      "verified" : true
    }
  },
  "id" : 448923717716824064,
  "created_at" : "2014-03-26 20:45:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Quintanilla",
      "screen_name" : "carlquintanilla",
      "indices" : [ 22, 38 ],
      "id_str" : "114782468",
      "id" : 114782468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448905409714470912",
  "geo" : { },
  "id_str" : "448905715105529856",
  "in_reply_to_user_id" : 114782468,
  "text" : "*crossing fingers* RT @carlquintanilla: $KING needs to close down 14.47% to be the worst IPO debut of the year.",
  "id" : 448905715105529856,
  "in_reply_to_status_id" : 448905409714470912,
  "created_at" : "2014-03-26 19:33:57 +0000",
  "in_reply_to_screen_name" : "carlquintanilla",
  "in_reply_to_user_id_str" : "114782468",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kieran Healy",
      "screen_name" : "kjhealy",
      "indices" : [ 3, 11 ],
      "id_str" : "782325",
      "id" : 782325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448797651140493312",
  "text" : "RT @kjhealy: Now: Google Glass. Next: Facebook Helmet. Soon: Amazon Kindle Bodysuit. Endgame: Jony Ive dips you in a vat of molten aluminiu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448586766514388992",
    "text" : "Now: Google Glass. Next: Facebook Helmet. Soon: Amazon Kindle Bodysuit. Endgame: Jony Ive dips you in a vat of molten aluminium.",
    "id" : 448586766514388992,
    "created_at" : "2014-03-25 22:26:34 +0000",
    "user" : {
      "name" : "Kieran Healy",
      "screen_name" : "kjhealy",
      "protected" : false,
      "id_str" : "782325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828863119\/69eb230d086dd9c7f2a25b2ee862926e_normal.jpeg",
      "id" : 782325,
      "verified" : false
    }
  },
  "id" : 448797651140493312,
  "created_at" : "2014-03-26 12:24:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/s8BzJB500O",
      "expanded_url" : "http:\/\/flic.kr\/p\/mrP9QK",
      "display_url" : "flic.kr\/p\/mrP9QK"
    } ]
  },
  "geo" : { },
  "id_str" : "448681871447425024",
  "text" : "8:36pm Everyone\\'s sick including the cat http:\/\/t.co\/s8BzJB500O",
  "id" : 448681871447425024,
  "created_at" : "2014-03-26 04:44:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 10, 19 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448622048776953856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.4284246182, -122.1767321417 ]
  },
  "id_str" : "448622326280515584",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @agaricus Take out the non-hashtagged part of the query. Longer term, set up an automated custom timeline. I'd be happy to help.",
  "id" : 448622326280515584,
  "in_reply_to_status_id" : 448622048776953856,
  "created_at" : "2014-03-26 00:47:52 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 39, 47 ],
      "id_str" : "14097392",
      "id" : 14097392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "habitsummit",
      "indices" : [ 18, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.4283836684, -122.1766819449 ]
  },
  "id_str" : "448622053965316096",
  "text" : "Enjoyed the first #habitsummit. Thanks @nireyal!",
  "id" : 448622053965316096,
  "created_at" : "2014-03-26 00:46:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 78, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448615336774860800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.4266827247, -122.1747420822 ]
  },
  "id_str" : "448620883326689280",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus It seems to be spamming without the hashtag. How do you consume the #quantifiedself stream?",
  "id" : 448620883326689280,
  "in_reply_to_status_id" : 448615336774860800,
  "created_at" : "2014-03-26 00:42:08 +0000",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Elman",
      "screen_name" : "joshelman",
      "indices" : [ 20, 30 ],
      "id_str" : "1979921",
      "id" : 1979921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "habitsummit",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448610627028656128",
  "text" : "Interesting hearing @joshelman\u2019s take on Twitter onboarding. I joined a year after he left. #habitsummit",
  "id" : 448610627028656128,
  "created_at" : "2014-03-26 00:01:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nora Rosendahl",
      "screen_name" : "NoraRosendahl",
      "indices" : [ 3, 17 ],
      "id_str" : "2220978836",
      "id" : 2220978836
    }, {
      "name" : "Julie Zhuo",
      "screen_name" : "joulee",
      "indices" : [ 88, 95 ],
      "id_str" : "17611446",
      "id" : 17611446
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "habitsummit",
      "indices" : [ 96, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448604378149052416",
  "text" : "RT @NoraRosendahl: 70-75% of Facebook investment is going to be in developing countries @joulee #habitsummit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Zhuo",
        "screen_name" : "joulee",
        "indices" : [ 69, 76 ],
        "id_str" : "17611446",
        "id" : 17611446
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "habitsummit",
        "indices" : [ 77, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448600747765014528",
    "text" : "70-75% of Facebook investment is going to be in developing countries @joulee #habitsummit",
    "id" : 448600747765014528,
    "created_at" : "2014-03-25 23:22:07 +0000",
    "user" : {
      "name" : "Nora Rosendahl",
      "screen_name" : "NoraRosendahl",
      "protected" : false,
      "id_str" : "2220978836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000845395067\/fe8be138de45ddb11cb35ba777dcaeaa_normal.jpeg",
      "id" : 2220978836,
      "verified" : false
    }
  },
  "id" : 448604378149052416,
  "created_at" : "2014-03-25 23:36:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448589346942111744",
  "geo" : { },
  "id_str" : "448595323129065472",
  "in_reply_to_user_id" : 2185,
  "text" : "That was amazing.",
  "id" : 448595323129065472,
  "in_reply_to_status_id" : 448589346942111744,
  "created_at" : "2014-03-25 23:00:34 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephdub",
      "screen_name" : "stephdub",
      "indices" : [ 0, 9 ],
      "id_str" : "14936359",
      "id" : 14936359
    }, {
      "name" : "Michael",
      "screen_name" : "michael",
      "indices" : [ 10, 18 ],
      "id_str" : "939",
      "id" : 939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448590366594174976",
  "geo" : { },
  "id_str" : "448593036025425920",
  "in_reply_to_user_id" : 14936359,
  "text" : "@stephdub @michael I don\u2019t! Hey, Michael!",
  "id" : 448593036025425920,
  "in_reply_to_status_id" : 448590366594174976,
  "created_at" : "2014-03-25 22:51:28 +0000",
  "in_reply_to_screen_name" : "stephdub",
  "in_reply_to_user_id_str" : "14936359",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John C Kim",
      "screen_name" : "jkimla",
      "indices" : [ 0, 7 ],
      "id_str" : "14267698",
      "id" : 14267698
    }, {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 8, 21 ],
      "id_str" : "5637652",
      "id" : 5637652
    }, {
      "name" : "Matthew Pearson",
      "screen_name" : "metmaven",
      "indices" : [ 22, 31 ],
      "id_str" : "28746074",
      "id" : 28746074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448589990918770688",
  "geo" : { },
  "id_str" : "448590417366233088",
  "in_reply_to_user_id" : 14267698,
  "text" : "@jkimla @codinghorror @MetMaven Loved how you apply this thinking to product, especially collapsing action and investment.",
  "id" : 448590417366233088,
  "in_reply_to_status_id" : 448589990918770688,
  "created_at" : "2014-03-25 22:41:04 +0000",
  "in_reply_to_screen_name" : "jkimla",
  "in_reply_to_user_id_str" : "14267698",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "habitsummit",
      "indices" : [ 86, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448589346942111744",
  "text" : "Okay, I\u2019m going to like this one too. \u201CThe Dark Side of Habit\u201D by Natasha Dow Sch\u00FCll. #habitsummit",
  "id" : 448589346942111744,
  "created_at" : "2014-03-25 22:36:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 50, 63 ],
      "id_str" : "5637652",
      "id" : 5637652
    }, {
      "name" : "John C Kim",
      "screen_name" : "jkimla",
      "indices" : [ 64, 71 ],
      "id_str" : "14267698",
      "id" : 14267698
    }, {
      "name" : "Matthew Pearson",
      "screen_name" : "metmaven",
      "indices" : [ 72, 81 ],
      "id_str" : "28746074",
      "id" : 28746074
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "habitsummit",
      "indices" : [ 110, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.4239447341, -122.1717465577 ]
  },
  "id_str" : "448586640697466880",
  "text" : "I'm biased to prefer speakers who build products (@codinghorror @jkimla @MetMaven) more than those who don't. #habitsummit",
  "id" : 448586640697466880,
  "created_at" : "2014-03-25 22:26:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chloe Fan",
      "screen_name" : "chloester",
      "indices" : [ 0, 10 ],
      "id_str" : "14275066",
      "id" : 14275066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448582329938608129",
  "geo" : { },
  "id_str" : "448582664174329856",
  "in_reply_to_user_id" : 14275066,
  "text" : "@chloester You too! Will definitely give MetroMile a try and let you know how it goes.",
  "id" : 448582664174329856,
  "in_reply_to_status_id" : 448582329938608129,
  "created_at" : "2014-03-25 22:10:16 +0000",
  "in_reply_to_screen_name" : "chloester",
  "in_reply_to_user_id_str" : "14275066",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "snore",
      "indices" : [ 107, 113 ]
    }, {
      "text" : "habitsummit",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448575025507872768",
  "text" : "A VC talking about \u201Cunicorn investing\u201D and how 99% monthly retention is better than 90% monthly retention. #snore #habitsummit",
  "id" : 448575025507872768,
  "created_at" : "2014-03-25 21:39:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Whitaker",
      "screen_name" : "OrthoNormalRuss",
      "indices" : [ 0, 16 ],
      "id_str" : "109889005",
      "id" : 109889005
    }, {
      "name" : "Daniel McCaffrey",
      "screen_name" : "demccaffrey",
      "indices" : [ 17, 29 ],
      "id_str" : "62322124",
      "id" : 62322124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448568299865915392",
  "geo" : { },
  "id_str" : "448569265172398080",
  "in_reply_to_user_id" : 109889005,
  "text" : "@OrthoNormalRuss @demccaffrey It was based on hands raised in response to a speaker question.",
  "id" : 448569265172398080,
  "in_reply_to_status_id" : 448568299865915392,
  "created_at" : "2014-03-25 21:17:01 +0000",
  "in_reply_to_screen_name" : "OrthoNormalRuss",
  "in_reply_to_user_id_str" : "109889005",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joost Plattel",
      "screen_name" : "jplattel",
      "indices" : [ 0, 9 ],
      "id_str" : "16376925",
      "id" : 16376925
    }, {
      "name" : "Daniel McCaffrey",
      "screen_name" : "demccaffrey",
      "indices" : [ 10, 22 ],
      "id_str" : "62322124",
      "id" : 62322124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448568551553916928",
  "geo" : { },
  "id_str" : "448568894471434240",
  "in_reply_to_user_id" : 16376925,
  "text" : "@jplattel @demccaffrey Probably higher at QS. But I bet the gadget graveyard at each of our desks is also much higher.",
  "id" : 448568894471434240,
  "in_reply_to_status_id" : 448568551553916928,
  "created_at" : "2014-03-25 21:15:33 +0000",
  "in_reply_to_screen_name" : "jplattel",
  "in_reply_to_user_id_str" : "16376925",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel McCaffrey",
      "screen_name" : "demccaffrey",
      "indices" : [ 102, 114 ],
      "id_str" : "62322124",
      "id" : 62322124
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "habitsummit",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448567929743745024",
  "text" : "\u201CI go to these wearable conferences around the country and only 10% of attendees are wearing them.\u201D - @demccaffrey at #habitsummit",
  "id" : 448567929743745024,
  "created_at" : "2014-03-25 21:11:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448532722382675968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.423825292, -122.1721888707 ]
  },
  "id_str" : "448536132817412096",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim I'm at a table inside one of the rooms with food. Come find me!",
  "id" : 448536132817412096,
  "in_reply_to_status_id" : 448532722382675968,
  "created_at" : "2014-03-25 19:05:22 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448532722382675968",
  "geo" : { },
  "id_str" : "448533690692272128",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim Yes, okay!",
  "id" : 448533690692272128,
  "in_reply_to_status_id" : 448532722382675968,
  "created_at" : "2014-03-25 18:55:39 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Chiu",
      "screen_name" : "alanchiu",
      "indices" : [ 3, 12 ],
      "id_str" : "17374599",
      "id" : 17374599
    }, {
      "name" : "Matthew Pearson",
      "screen_name" : "metmaven",
      "indices" : [ 45, 54 ],
      "id_str" : "28746074",
      "id" : 28746074
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/alanchiu\/status\/448525430316748801\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/vGgmReDcKX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bjl7gJeCMAAqJ-d.jpg",
      "id_str" : "448525430127996928",
      "id" : 448525430127996928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bjl7gJeCMAAqJ-d.jpg",
      "sizes" : [ {
        "h" : 335,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1009,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/vGgmReDcKX"
    } ],
    "hashtags" : [ {
      "text" : "habitsummit",
      "indices" : [ 55, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448530297307398144",
  "text" : "RT @alanchiu: Reward = payoff - expectations @MetMaven #habitsummit http:\/\/t.co\/vGgmReDcKX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew Pearson",
        "screen_name" : "metmaven",
        "indices" : [ 31, 40 ],
        "id_str" : "28746074",
        "id" : 28746074
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/alanchiu\/status\/448525430316748801\/photo\/1",
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/vGgmReDcKX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bjl7gJeCMAAqJ-d.jpg",
        "id_str" : "448525430127996928",
        "id" : 448525430127996928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bjl7gJeCMAAqJ-d.jpg",
        "sizes" : [ {
          "h" : 335,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1009,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1009,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/vGgmReDcKX"
      } ],
      "hashtags" : [ {
        "text" : "habitsummit",
        "indices" : [ 41, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.4237944465, -122.1718216595 ]
    },
    "id_str" : "448525430316748801",
    "text" : "Reward = payoff - expectations @MetMaven #habitsummit http:\/\/t.co\/vGgmReDcKX",
    "id" : 448525430316748801,
    "created_at" : "2014-03-25 18:22:50 +0000",
    "user" : {
      "name" : "Alan Chiu",
      "screen_name" : "alanchiu",
      "protected" : false,
      "id_str" : "17374599",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447060891469496320\/Mwssimsr_normal.jpeg",
      "id" : 17374599,
      "verified" : false
    }
  },
  "id" : 448530297307398144,
  "created_at" : "2014-03-25 18:42:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448527504676900864",
  "geo" : { },
  "id_str" : "448529790396420096",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim Are you here too? Hi!",
  "id" : 448529790396420096,
  "in_reply_to_status_id" : 448527504676900864,
  "created_at" : "2014-03-25 18:40:09 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara-Nicholle Nelson",
      "screen_name" : "taranicholle",
      "indices" : [ 95, 108 ],
      "id_str" : "15148625",
      "id" : 15148625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "habitsummit",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448529633537826817",
  "text" : "\u201CTransformational digital health consumers: people who have been both Paleo and vegetarian.\u201D - @taranicholle at #habitsummit",
  "id" : 448529633537826817,
  "created_at" : "2014-03-25 18:39:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448511110732197888",
  "geo" : { },
  "id_str" : "448528303494684672",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus Hm, unfortunately I don't. Which tweets are you referring to?",
  "id" : 448528303494684672,
  "in_reply_to_status_id" : 448511110732197888,
  "created_at" : "2014-03-25 18:34:15 +0000",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Pearson",
      "screen_name" : "metmaven",
      "indices" : [ 0, 9 ],
      "id_str" : "28746074",
      "id" : 28746074
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "habitsummit",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448506295012700160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.4239717657, -122.1718447098 ]
  },
  "id_str" : "448527487224389632",
  "in_reply_to_user_id" : 28746074,
  "text" : "@MetMaven Enjoyed your talk! Setting expectations is difficult to prioritize in a product but this makes its value very clear. #habitsummit",
  "id" : 448527487224389632,
  "in_reply_to_status_id" : 448506295012700160,
  "created_at" : "2014-03-25 18:31:00 +0000",
  "in_reply_to_screen_name" : "metmaven",
  "in_reply_to_user_id_str" : "28746074",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "indices" : [ 0, 14 ],
      "id_str" : "14289835",
      "id" : 14289835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "habitsummit",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.4240094843, -122.1717643273 ]
  },
  "id_str" : "448519455745015808",
  "in_reply_to_user_id" : 14289835,
  "text" : "@gretchenrubin Wonderful talk, thank you! That's coming from a Questioner with Rebel tendencies. :) #habitsummit",
  "id" : 448519455745015808,
  "created_at" : "2014-03-25 17:59:05 +0000",
  "in_reply_to_screen_name" : "gretchenrubin",
  "in_reply_to_user_id_str" : "14289835",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "indices" : [ 51, 65 ],
      "id_str" : "14289835",
      "id" : 14289835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "habitsummit",
      "indices" : [ 3, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.423987398, -122.1719005333 ]
  },
  "id_str" : "448511990000910336",
  "text" : "At #habitsummit today. So far, excited to see that @gretchenrubin seems skeptical about habit forming solutions too.",
  "id" : 448511990000910336,
  "created_at" : "2014-03-25 17:29:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mat Marquis",
      "screen_name" : "wilto",
      "indices" : [ 3, 9 ],
      "id_str" : "12602932",
      "id" : 12602932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448462413860306946",
  "text" : "RT @wilto: You are at work. There are emails to the North.\n&gt; answer email\nThree more appear.\n&gt; answer emails\nTwelve more appear.\n&gt; run\nYou \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "246268200982036481",
    "text" : "You are at work. There are emails to the North.\n&gt; answer email\nThree more appear.\n&gt; answer emails\nTwelve more appear.\n&gt; run\nYou cannot run.",
    "id" : 246268200982036481,
    "created_at" : "2012-09-13 15:24:49 +0000",
    "user" : {
      "name" : "Mat Marquis",
      "screen_name" : "wilto",
      "protected" : false,
      "id_str" : "12602932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000735074258\/280a4207a8cce4afc6ce7a18429a537c_normal.png",
      "id" : 12602932,
      "verified" : false
    }
  },
  "id" : 448462413860306946,
  "created_at" : "2014-03-25 14:12:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448426375029207040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859782349, -122.2754547774 ]
  },
  "id_str" : "448462193487384576",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine busterbenson@gmail.com",
  "id" : 448462193487384576,
  "in_reply_to_status_id" : 448426375029207040,
  "created_at" : "2014-03-25 14:11:33 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 69, 75 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/448314184485191680\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/wIm4cS8eTs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bji7YAFCEAE36A6.jpg",
      "id_str" : "448314183935725569",
      "id" : 448314183935725569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bji7YAFCEAE36A6.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wIm4cS8eTs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597448862, -122.275671601 ]
  },
  "id_str" : "448314184485191680",
  "text" : "8:36pm Niko never goes anywhere without his new compass, a gift from @joshc http:\/\/t.co\/wIm4cS8eTs",
  "id" : 448314184485191680,
  "created_at" : "2014-03-25 04:23:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 10, 22 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448225583798157312",
  "geo" : { },
  "id_str" : "448225678102507520",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @ginatrapani Congrats on the launch. Looks great!",
  "id" : 448225678102507520,
  "in_reply_to_status_id" : 448225583798157312,
  "created_at" : "2014-03-24 22:31:43 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThinkUp",
      "screen_name" : "thinkup",
      "indices" : [ 13, 21 ],
      "id_str" : "100127476",
      "id" : 100127476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/AuuQKAtc1R",
      "expanded_url" : "https:\/\/buster.thinkup.com",
      "display_url" : "buster.thinkup.com"
    } ]
  },
  "in_reply_to_status_id_str" : "448221040582197248",
  "geo" : { },
  "id_str" : "448222631112605696",
  "in_reply_to_user_id" : 2185,
  "text" : "Check out my @thinkup stats: https:\/\/t.co\/AuuQKAtc1R (PS. Very cool that you can make them public.)",
  "id" : 448222631112605696,
  "in_reply_to_status_id" : 448221040582197248,
  "created_at" : "2014-03-24 22:19:37 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThinkUp",
      "screen_name" : "thinkup",
      "indices" : [ 19, 27 ],
      "id_str" : "100127476",
      "id" : 100127476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/ni7OhI64gl",
      "expanded_url" : "http:\/\/blog.thinkup.com\/post\/80605166551\/welcome-everyone-to-thinkup",
      "display_url" : "blog.thinkup.com\/post\/806051665\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "448220038978600960",
  "geo" : { },
  "id_str" : "448221040582197248",
  "in_reply_to_user_id" : 100127476,
  "text" : "Check them out! RT @thinkup: Welcome, everyone, to ThinkUp. What the heck is ThinkUp? We've got answers: http:\/\/t.co\/ni7OhI64gl",
  "id" : 448221040582197248,
  "in_reply_to_status_id" : 448220038978600960,
  "created_at" : "2014-03-24 22:13:18 +0000",
  "in_reply_to_screen_name" : "thinkup",
  "in_reply_to_user_id_str" : "100127476",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen X. Cheng",
      "screen_name" : "karenxcheng",
      "indices" : [ 100, 112 ],
      "id_str" : "21829724",
      "id" : 21829724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/prQZwd2F9Y",
      "expanded_url" : "http:\/\/techcrunch.com\/2014\/03\/23\/layout-in-flipboard-for-web-and-windows\/",
      "display_url" : "techcrunch.com\/2014\/03\/23\/lay\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596988486, -122.275532497 ]
  },
  "id_str" : "447984267830648832",
  "text" : "I hadn't realized text+media layout strategy could be this interesting: http:\/\/t.co\/prQZwd2F9Y \/via @karenxcheng",
  "id" : 447984267830648832,
  "created_at" : "2014-03-24 06:32:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sterling White",
      "screen_name" : "hey_sterling",
      "indices" : [ 0, 13 ],
      "id_str" : "150863291",
      "id" : 150863291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447975641434947584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596728774, -122.2755487425 ]
  },
  "id_str" : "447980690055782400",
  "in_reply_to_user_id" : 150863291,
  "text" : "@hey_sterling Ha. I wonder what happened to all the apostrophes and dashes?",
  "id" : 447980690055782400,
  "in_reply_to_status_id" : 447975641434947584,
  "created_at" : "2014-03-24 06:18:14 +0000",
  "in_reply_to_screen_name" : "hey_sterling",
  "in_reply_to_user_id_str" : "150863291",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "Grant Faulkner",
      "screen_name" : "grantfaulkner",
      "indices" : [ 10, 24 ],
      "id_str" : "15443999",
      "id" : 15443999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447954264938143744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597296868, -122.2754226533 ]
  },
  "id_str" : "447964442110615552",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus @grantfaulkner Hi, Grant!",
  "id" : 447964442110615552,
  "in_reply_to_status_id" : 447954264938143744,
  "created_at" : "2014-03-24 05:13:40 +0000",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 3, 12 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/xuvq8cOlBk",
      "expanded_url" : "http:\/\/www.newrepublic.com\/article\/117088\/silicons-valleys-brutal-ageism?utm_content=4403329&utm_medium=social&utm_source=twitter",
      "display_url" : "newrepublic.com\/article\/117088\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "447963906749640705",
  "text" : "RT @mathowie: Pretty great article on ageism in Silicon Valley (I'm the unidentified 40-something crapping on Outbox): http:\/\/t.co\/xuvq8cOl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/xuvq8cOlBk",
        "expanded_url" : "http:\/\/www.newrepublic.com\/article\/117088\/silicons-valleys-brutal-ageism?utm_content=4403329&utm_medium=social&utm_source=twitter",
        "display_url" : "newrepublic.com\/article\/117088\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "447884368371912705",
    "text" : "Pretty great article on ageism in Silicon Valley (I'm the unidentified 40-something crapping on Outbox): http:\/\/t.co\/xuvq8cOlBk",
    "id" : 447884368371912705,
    "created_at" : "2014-03-23 23:55:29 +0000",
    "user" : {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "protected" : false,
      "id_str" : "761975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463101305972465664\/xjD_-7Jl_normal.jpeg",
      "id" : 761975,
      "verified" : false
    }
  },
  "id" : 447963906749640705,
  "created_at" : "2014-03-24 05:11:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/u4veVyraEM",
      "expanded_url" : "http:\/\/erikbenson.typepad.com\/mu\/2003\/11\/disaster_day_on.html",
      "display_url" : "erikbenson.typepad.com\/mu\/2003\/11\/dis\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "447948438638833666",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859686679, -122.2755461834 ]
  },
  "id_str" : "447949568445911040",
  "in_reply_to_user_id" : 2185,
  "text" : "Ha, found the first day's writing on my old TypePad: http:\/\/t.co\/u4veVyraEM",
  "id" : 447949568445911040,
  "in_reply_to_status_id" : 447948438638833666,
  "created_at" : "2014-03-24 04:14:34 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nanowrimo",
      "indices" : [ 10, 20 ]
    }, {
      "text" : "cosmos",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598129017, -122.2755930818 ]
  },
  "id_str" : "447948438638833666",
  "text" : "I wrote a #nanowrimo novel about the Oort Cloud a long time ago. It was called Disaster (evil star). #cosmos",
  "id" : 447948438638833666,
  "created_at" : "2014-03-24 04:10:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cosmos",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/5GhRLFpTKs",
      "expanded_url" : "http:\/\/flic.kr\/p\/mnExKz",
      "display_url" : "flic.kr\/p\/mnExKz"
    } ]
  },
  "geo" : { },
  "id_str" : "447947907980095488",
  "text" : "8:36pm Put Niko to bed quickly so I could catch #cosmos http:\/\/t.co\/5GhRLFpTKs",
  "id" : 447947907980095488,
  "created_at" : "2014-03-24 04:07:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ibrahim bashir",
      "screen_name" : "ibrahimbashir",
      "indices" : [ 0, 14 ],
      "id_str" : "19079210",
      "id" : 19079210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447915752176091136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8562833675, -122.2592734416 ]
  },
  "id_str" : "447932199841439746",
  "in_reply_to_user_id" : 19079210,
  "text" : "@ibrahimbashir That's pretty interesting! I'll take a closer look soon.",
  "id" : 447932199841439746,
  "in_reply_to_status_id" : 447915752176091136,
  "created_at" : "2014-03-24 03:05:33 +0000",
  "in_reply_to_screen_name" : "ibrahimbashir",
  "in_reply_to_user_id_str" : "19079210",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447902373441437696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666118, -122.2754929659 ]
  },
  "id_str" : "447904100340862977",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover Me!",
  "id" : 447904100340862977,
  "in_reply_to_status_id" : 447902373441437696,
  "created_at" : "2014-03-24 01:13:53 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    }, {
      "name" : "Renee DiResta",
      "screen_name" : "noUpside",
      "indices" : [ 13, 22 ],
      "id_str" : "24254084",
      "id" : 24254084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447866594149273600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597270465, -122.2754591984 ]
  },
  "id_str" : "447899709059768320",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine @noUpside Good article. He conceded my point then wrote it off by saying a partially irrational efficient market is boring.",
  "id" : 447899709059768320,
  "in_reply_to_status_id" : 447866594149273600,
  "created_at" : "2014-03-24 00:56:26 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/QT4FHzbVm6",
      "expanded_url" : "https:\/\/vine.co\/v\/MMt2JPJHhFH",
      "display_url" : "vine.co\/v\/MMt2JPJHhFH"
    } ]
  },
  "geo" : { },
  "id_str" : "447841790025269248",
  "text" : "Yoshimi battles the bowling pins https:\/\/t.co\/QT4FHzbVm6",
  "id" : 447841790025269248,
  "created_at" : "2014-03-23 21:06:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/WeGdztrONQ",
      "expanded_url" : "http:\/\/flic.kr\/p\/mk9UmP",
      "display_url" : "flic.kr\/p\/mk9UmP"
    } ]
  },
  "geo" : { },
  "id_str" : "447578244733485057",
  "text" : "8:36pm Walking to St Vincent http:\/\/t.co\/WeGdztrONQ",
  "id" : 447578244733485057,
  "created_at" : "2014-03-23 03:39:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas Wisser",
      "screen_name" : "jwisser",
      "indices" : [ 3, 11 ],
      "id_str" : "665833",
      "id" : 665833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/CN0WB3T6FM",
      "expanded_url" : "https:\/\/medium.com\/p\/8a36de59cf10",
      "display_url" : "medium.com\/p\/8a36de59cf10"
    } ]
  },
  "geo" : { },
  "id_str" : "447472611044237312",
  "text" : "RT @jwisser: On Paul Graham\u2019s view of how to fix a community:\n\nhttps:\/\/t.co\/CN0WB3T6FM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/CN0WB3T6FM",
        "expanded_url" : "https:\/\/medium.com\/p\/8a36de59cf10",
        "display_url" : "medium.com\/p\/8a36de59cf10"
      } ]
    },
    "geo" : { },
    "id_str" : "447406593596862464",
    "text" : "On Paul Graham\u2019s view of how to fix a community:\n\nhttps:\/\/t.co\/CN0WB3T6FM",
    "id" : 447406593596862464,
    "created_at" : "2014-03-22 16:16:58 +0000",
    "user" : {
      "name" : "Jonas Wisser",
      "screen_name" : "jwisser",
      "protected" : false,
      "id_str" : "665833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000416672906\/8570725c0bea7a515439fea84613e38e_normal.png",
      "id" : 665833,
      "verified" : false
    }
  },
  "id" : 447472611044237312,
  "created_at" : "2014-03-22 20:39:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 7, 17 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/447216564891172864\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/yNpfqsElsC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjTVGBMCQAAogtt.jpg",
      "id_str" : "447216562391367680",
      "id" : 447216562391367680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjTVGBMCQAAogtt.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/yNpfqsElsC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859751815, -122.2754916364 ]
  },
  "id_str" : "447216564891172864",
  "text" : "8:36pm @Kellianne's friends from raver days past reunion http:\/\/t.co\/yNpfqsElsC",
  "id" : 447216564891172864,
  "created_at" : "2014-03-22 03:41:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/447214397530710016\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/TQgf9NQlQH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjTTH83CEAA8oGC.jpg",
      "id_str" : "447214396566016000",
      "id" : 447214396566016000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjTTH83CEAA8oGC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/TQgf9NQlQH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596928153, -122.2754861972 ]
  },
  "id_str" : "447214397530710016",
  "text" : "Frozen fan club http:\/\/t.co\/TQgf9NQlQH",
  "id" : 447214397530710016,
  "created_at" : "2014-03-22 03:33:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 11, 20 ],
      "id_str" : "14417215",
      "id" : 14417215
    }, {
      "name" : "Patrick Moberg",
      "screen_name" : "patrickmoberg",
      "indices" : [ 29, 43 ],
      "id_str" : "4102571",
      "id" : 4102571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/F0lYFrtOfj",
      "expanded_url" : "http:\/\/bit.ly\/1gNt8zM",
      "display_url" : "bit.ly\/1gNt8zM"
    } ]
  },
  "in_reply_to_status_id_str" : "447131048657580032",
  "geo" : { },
  "id_str" : "447133515314782208",
  "in_reply_to_user_id" : 14417215,
  "text" : "Me too! RT @rrhoover: I love @patrickmoberg's illustrations - http:\/\/t.co\/F0lYFrtOfj",
  "id" : 447133515314782208,
  "in_reply_to_status_id" : 447131048657580032,
  "created_at" : "2014-03-21 22:11:52 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Siracusa",
      "screen_name" : "siracusa",
      "indices" : [ 0, 9 ],
      "id_str" : "636923",
      "id" : 636923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447076925929185281",
  "geo" : { },
  "id_str" : "447128926783959040",
  "in_reply_to_user_id" : 636923,
  "text" : "@siracusa If you\u2019ve got 3 or more Tweets to this page, wait 24 hours and let me know if you don\u2019t have access.",
  "id" : 447128926783959040,
  "in_reply_to_status_id" : 447076925929185281,
  "created_at" : "2014-03-21 21:53:38 +0000",
  "in_reply_to_screen_name" : "siracusa",
  "in_reply_to_user_id_str" : "636923",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447088189497307136",
  "geo" : { },
  "id_str" : "447088477885063168",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward Yeah. I have my IRAs with an advisor and do everything else on my own\u2026 still learning a ton though.",
  "id" : 447088477885063168,
  "in_reply_to_status_id" : 447088189497307136,
  "created_at" : "2014-03-21 19:12:54 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447085669450391553",
  "geo" : { },
  "id_str" : "447087976305029120",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward They look pretty good. Nice to see a flat fee rather than a percentage.",
  "id" : 447087976305029120,
  "in_reply_to_status_id" : 447085669450391553,
  "created_at" : "2014-03-21 19:10:54 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edwin Catmull",
      "screen_name" : "edcatmull",
      "indices" : [ 20, 30 ],
      "id_str" : "60644920",
      "id" : 60644920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/sagSzVd72W",
      "expanded_url" : "http:\/\/kottke.org\/14\/03\/creativity-inc",
      "display_url" : "kottke.org\/14\/03\/creativi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "447071318144319488",
  "text" : "Super excited about @edcatmull's new book: http:\/\/t.co\/sagSzVd72W",
  "id" : 447071318144319488,
  "created_at" : "2014-03-21 18:04:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Grosenbach",
      "screen_name" : "topfunky",
      "indices" : [ 0, 9 ],
      "id_str" : "10718",
      "id" : 10718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446895972283449344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596945073, -122.2755358455 ]
  },
  "id_str" : "446896447376465920",
  "in_reply_to_user_id" : 10718,
  "text" : "@topfunky Just joking around since people consider him to be so flawless. Much like we once regarded our buddy Mr. Armstrong!",
  "id" : 446896447376465920,
  "in_reply_to_status_id" : 446895972283449344,
  "created_at" : "2014-03-21 06:29:50 +0000",
  "in_reply_to_screen_name" : "topfunky",
  "in_reply_to_user_id_str" : "10718",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    }, {
      "name" : "FutureAdvisor",
      "screen_name" : "FutureAdvisor",
      "indices" : [ 77, 91 ],
      "id_str" : "141748686",
      "id" : 141748686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446878615137824768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596962113, -122.2754911309 ]
  },
  "id_str" : "446895538655342592",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright Totally, esp when you take into account fees and such. Do you use @FutureAdvisor?",
  "id" : 446895538655342592,
  "in_reply_to_status_id" : 446878615137824768,
  "created_at" : "2014-03-21 06:26:13 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Warren Buffett",
      "screen_name" : "WarrenBuffett",
      "indices" : [ 26, 40 ],
      "id_str" : "1364930179",
      "id" : 1364930179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596964106, -122.2755347193 ]
  },
  "id_str" : "446895052912984064",
  "text" : "What if we found out that @WarrenBuffett had been doping this whole time?",
  "id" : 446895052912984064,
  "created_at" : "2014-03-21 06:24:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    }, {
      "name" : "Renee DiResta",
      "screen_name" : "noUpside",
      "indices" : [ 13, 22 ],
      "id_str" : "24254084",
      "id" : 24254084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/F3HfE0Mo6Z",
      "expanded_url" : "http:\/\/www.bogleheads.org\/forum\/viewtopic.php?f=10&t=93751",
      "display_url" : "bogleheads.org\/forum\/viewtopi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "446854620410044416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596907314, -122.2755635483 ]
  },
  "id_str" : "446892386401009664",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine @noUpside And how have they done since 1984 as a whole? http:\/\/t.co\/F3HfE0Mo6Z",
  "id" : 446892386401009664,
  "in_reply_to_status_id" : 446854620410044416,
  "created_at" : "2014-03-21 06:13:42 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 3, 10 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/bnBajzOEy2",
      "expanded_url" : "http:\/\/pulse.me\/s\/WBmfW",
      "display_url" : "pulse.me\/s\/WBmfW"
    } ]
  },
  "geo" : { },
  "id_str" : "446890887713275904",
  "text" : "RT @cwhogg: RunKeeper CEO: Dedicated trackers are headed the way of the digital camera http:\/\/t.co\/bnBajzOEy2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.pulse.me\" rel=\"nofollow\"\u003EPulse News\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/bnBajzOEy2",
        "expanded_url" : "http:\/\/pulse.me\/s\/WBmfW",
        "display_url" : "pulse.me\/s\/WBmfW"
      } ]
    },
    "geo" : { },
    "id_str" : "446810396230303745",
    "text" : "RunKeeper CEO: Dedicated trackers are headed the way of the digital camera http:\/\/t.co\/bnBajzOEy2",
    "id" : 446810396230303745,
    "created_at" : "2014-03-21 00:47:54 +0000",
    "user" : {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "protected" : false,
      "id_str" : "15727738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416445309166682112\/uARs4O8y_normal.png",
      "id" : 15727738,
      "verified" : false
    }
  },
  "id" : 446890887713275904,
  "created_at" : "2014-03-21 06:07:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    }, {
      "name" : "Renee DiResta",
      "screen_name" : "noUpside",
      "indices" : [ 13, 22 ],
      "id_str" : "24254084",
      "id" : 24254084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446853779334627328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.848102646, -122.2719325965 ]
  },
  "id_str" : "446854164463640576",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine @noUpside Only if you have to sell during the crises, right? Unless the markets go to zero...",
  "id" : 446854164463640576,
  "in_reply_to_status_id" : 446853779334627328,
  "created_at" : "2014-03-21 03:41:49 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/fU5cPppunE",
      "expanded_url" : "http:\/\/flic.kr\/p\/mgky1F",
      "display_url" : "flic.kr\/p\/mgky1F"
    } ]
  },
  "geo" : { },
  "id_str" : "446853196187963392",
  "text" : "8:36pm Waiting outside Kellianne's yoga studio listening to Four Pillars of Investing. http:\/\/t.co\/fU5cPppunE",
  "id" : 446853196187963392,
  "created_at" : "2014-03-21 03:37:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renee DiResta",
      "screen_name" : "noUpside",
      "indices" : [ 0, 9 ],
      "id_str" : "24254084",
      "id" : 24254084
    }, {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 10, 22 ],
      "id_str" : "7413762",
      "id" : 7413762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446851540595539968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8482237808, -122.2717167084 ]
  },
  "id_str" : "446852623174336512",
  "in_reply_to_user_id" : 24254084,
  "text" : "@noUpside @davealevine Long story short I think that's the best thing to do too. With enough to play with so you can support good causes.",
  "id" : 446852623174336512,
  "in_reply_to_status_id" : 446851540595539968,
  "created_at" : "2014-03-21 03:35:42 +0000",
  "in_reply_to_screen_name" : "noUpside",
  "in_reply_to_user_id_str" : "24254084",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    }, {
      "name" : "Renee DiResta",
      "screen_name" : "noUpside",
      "indices" : [ 13, 22 ],
      "id_str" : "24254084",
      "id" : 24254084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446851395346792448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8480876843, -122.2718419881 ]
  },
  "id_str" : "446851803250827265",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine @noUpside That's a theory. And as long as \"sometimes\" is in there, not at odds with the EMH.",
  "id" : 446851803250827265,
  "in_reply_to_status_id" : 446851395346792448,
  "created_at" : "2014-03-21 03:32:26 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    }, {
      "name" : "Renee DiResta",
      "screen_name" : "noUpside",
      "indices" : [ 13, 22 ],
      "id_str" : "24254084",
      "id" : 24254084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446850292399996928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8480543206, -122.2717621804 ]
  },
  "id_str" : "446850469105643521",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine @noUpside So do you trust things that aren't theories? If so, what?",
  "id" : 446850469105643521,
  "in_reply_to_status_id" : 446850292399996928,
  "created_at" : "2014-03-21 03:27:08 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    }, {
      "name" : "Renee DiResta",
      "screen_name" : "noUpside",
      "indices" : [ 13, 22 ],
      "id_str" : "24254084",
      "id" : 24254084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446849961511387136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8482078439, -122.2717259323 ]
  },
  "id_str" : "446850190880669696",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine @noUpside Junk money is all we've got though, right?",
  "id" : 446850190880669696,
  "in_reply_to_status_id" : 446849961511387136,
  "created_at" : "2014-03-21 03:26:02 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Crawford",
      "screen_name" : "britt",
      "indices" : [ 0, 6 ],
      "id_str" : "5362",
      "id" : 5362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446849535667499008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8482246684, -122.271713848 ]
  },
  "id_str" : "446849909480640513",
  "in_reply_to_user_id" : 5362,
  "text" : "@britt Probably not. I'm not an economist.",
  "id" : 446849909480640513,
  "in_reply_to_status_id" : 446849535667499008,
  "created_at" : "2014-03-21 03:24:55 +0000",
  "in_reply_to_screen_name" : "britt",
  "in_reply_to_user_id_str" : "5362",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446837416779735040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8481822082, -122.271686868 ]
  },
  "id_str" : "446849137590288384",
  "in_reply_to_user_id" : 2185,
  "text" : "To me, the EMH just means that as an investor trying to beat market, you're playing against an opponent that's smarter than you. That's all.",
  "id" : 446849137590288384,
  "in_reply_to_status_id" : 446837416779735040,
  "created_at" : "2014-03-21 03:21:51 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    }, {
      "name" : "Renee DiResta",
      "screen_name" : "noUpside",
      "indices" : [ 13, 22 ],
      "id_str" : "24254084",
      "id" : 24254084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446846455266168832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8501675278, -122.2710619682 ]
  },
  "id_str" : "446847139671318528",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine @noUpside Again I think it just means *more* meaningfully and accurately than the next best option. There is no objective fact.",
  "id" : 446847139671318528,
  "in_reply_to_status_id" : 446846455266168832,
  "created_at" : "2014-03-21 03:13:54 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    }, {
      "name" : "Renee DiResta",
      "screen_name" : "noUpside",
      "indices" : [ 13, 22 ],
      "id_str" : "24254084",
      "id" : 24254084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446841878596431872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8526253114, -122.2705313937 ]
  },
  "id_str" : "446844984788938752",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine @noUpside I don't think EMT is about absolute efficiency. It's about the fact that it is more efficient than *you*.",
  "id" : 446844984788938752,
  "in_reply_to_status_id" : 446841878596431872,
  "created_at" : "2014-03-21 03:05:21 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446838700606226432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7935890514, -122.3961396292 ]
  },
  "id_str" : "446839478389198848",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine So how are you different from the market?",
  "id" : 446839478389198848,
  "in_reply_to_status_id" : 446838700606226432,
  "created_at" : "2014-03-21 02:43:28 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renee DiResta",
      "screen_name" : "noUpside",
      "indices" : [ 0, 9 ],
      "id_str" : "24254084",
      "id" : 24254084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446838019518386176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7823860413, -122.4056536368 ]
  },
  "id_str" : "446838448519786496",
  "in_reply_to_user_id" : 24254084,
  "text" : "@noUpside Why not the strong form?",
  "id" : 446838448519786496,
  "in_reply_to_status_id" : 446838019518386176,
  "created_at" : "2014-03-21 02:39:22 +0000",
  "in_reply_to_screen_name" : "noUpside",
  "in_reply_to_user_id_str" : "24254084",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Lawrence H. Summers",
      "screen_name" : "LHSummers",
      "indices" : [ 8, 18 ],
      "id_str" : "236526490",
      "id" : 236526490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446837649412616193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7788766546, -122.4145384051 ]
  },
  "id_str" : "446838166578688000",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @LHSummers Yes but how certain can you be that you're not one of them?",
  "id" : 446838166578688000,
  "in_reply_to_status_id" : 446837649412616193,
  "created_at" : "2014-03-21 02:38:15 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Pepper",
      "screen_name" : "noahmp",
      "indices" : [ 0, 7 ],
      "id_str" : "20219699",
      "id" : 20219699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446837355064737792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7796651676, -122.413933997 ]
  },
  "id_str" : "446837799358984192",
  "in_reply_to_user_id" : 20219699,
  "text" : "@noahmp All versions. Or, which do you believe in most?",
  "id" : 446837799358984192,
  "in_reply_to_status_id" : 446837355064737792,
  "created_at" : "2014-03-21 02:36:47 +0000",
  "in_reply_to_screen_name" : "noahmp",
  "in_reply_to_user_id_str" : "20219699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446837036675117056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.779817132, -122.4138132111 ]
  },
  "id_str" : "446837416779735040",
  "in_reply_to_user_id" : 2185,
  "text" : "If the market is always one step ahead of us, does that qualify the market as an AI? Could it pass the Turing Test?",
  "id" : 446837416779735040,
  "in_reply_to_status_id" : 446837036675117056,
  "created_at" : "2014-03-21 02:35:16 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/GfEaB7XNED",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Efficient-market_hypothesis",
      "display_url" : "en.m.wikipedia.org\/wiki\/Efficient\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.779817132, -122.4138132111 ]
  },
  "id_str" : "446837036675117056",
  "text" : "Do you believe in the Efficient Market Hypothesis? http:\/\/t.co\/GfEaB7XNED",
  "id" : 446837036675117056,
  "created_at" : "2014-03-21 02:33:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776059856, -122.4169308261 ]
  },
  "id_str" : "446833050018541568",
  "text" : "\"There are no great men. Only lucky chimpanzees.\" - William Bernstein",
  "id" : 446833050018541568,
  "created_at" : "2014-03-21 02:17:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 0, 6 ],
      "id_str" : "5469512",
      "id" : 5469512
    }, {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 7, 19 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/uRkyi9f02Y",
      "expanded_url" : "http:\/\/habitsummit.com",
      "display_url" : "habitsummit.com"
    } ]
  },
  "in_reply_to_status_id_str" : "446824390869540864",
  "geo" : { },
  "id_str" : "446827304736415744",
  "in_reply_to_user_id" : 5469512,
  "text" : "@micah @kylebragger My evening tickets are in short supply next week. Either of you going to http:\/\/t.co\/uRkyi9f02Y? Long shot.",
  "id" : 446827304736415744,
  "in_reply_to_status_id" : 446824390869540864,
  "created_at" : "2014-03-21 01:55:05 +0000",
  "in_reply_to_screen_name" : "micah",
  "in_reply_to_user_id_str" : "5469512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446822487230132224",
  "geo" : { },
  "id_str" : "446822599050264577",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger Wanna get a drink like right now? I have til 8:30 and am in SF.",
  "id" : 446822599050264577,
  "in_reply_to_status_id" : 446822487230132224,
  "created_at" : "2014-03-21 01:36:23 +0000",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446821568119717889",
  "text" : "Who's interested in babysitting Niko on Saturday night in Berkeley while we go to a St Vincent show? We have a sofa bed for you! DM me.",
  "id" : 446821568119717889,
  "created_at" : "2014-03-21 01:32:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Camille Fournier",
      "screen_name" : "skamille",
      "indices" : [ 8, 17 ],
      "id_str" : "24257941",
      "id" : 24257941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446812712039755776",
  "geo" : { },
  "id_str" : "446815822183276545",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @skamille I agree. The wife angle is just the simplest story, the actual terrible actions belong to coworkers and founders.",
  "id" : 446815822183276545,
  "in_reply_to_status_id" : 446812712039755776,
  "created_at" : "2014-03-21 01:09:28 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    }, {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "indices" : [ 10, 13 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446804059115094016",
  "geo" : { },
  "id_str" : "446805983046557697",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover @ev Yeah I'm fairly predictable on that front.",
  "id" : 446805983046557697,
  "in_reply_to_status_id" : 446804059115094016,
  "created_at" : "2014-03-21 00:30:22 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "indices" : [ 41, 44 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/WiosIwsfEN",
      "expanded_url" : "https:\/\/appsto.re\/us\/S_IxX.i",
      "display_url" : "appsto.re\/us\/S_IxX.i"
    } ]
  },
  "in_reply_to_status_id_str" : "446789424718675968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762158968, -122.4168693248 ]
  },
  "id_str" : "446803636635435008",
  "in_reply_to_user_id" : 20,
  "text" : "Looks great! Wish it had my stats. :) RT @ev: New for you: Medium for iPhone.  https:\/\/t.co\/WiosIwsfEN",
  "id" : 446803636635435008,
  "in_reply_to_status_id" : 446789424718675968,
  "created_at" : "2014-03-21 00:21:02 +0000",
  "in_reply_to_screen_name" : "ev",
  "in_reply_to_user_id_str" : "20",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K. A",
      "screen_name" : "thian_un",
      "indices" : [ 0, 9 ],
      "id_str" : "23004847",
      "id" : 23004847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446793408527339520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762610298, -122.4168093631 ]
  },
  "id_str" : "446794110528000000",
  "in_reply_to_user_id" : 23004847,
  "text" : "@thian_un Wow that's awesome. Thanks for the kind words.",
  "id" : 446794110528000000,
  "in_reply_to_status_id" : 446793408527339520,
  "created_at" : "2014-03-20 23:43:11 +0000",
  "in_reply_to_screen_name" : "thian_un",
  "in_reply_to_user_id_str" : "23004847",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Newton",
      "screen_name" : "CaseyNewton",
      "indices" : [ 0, 12 ],
      "id_str" : "69426451",
      "id" : 69426451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446700149981454336",
  "geo" : { },
  "id_str" : "446703599037325312",
  "in_reply_to_user_id" : 69426451,
  "text" : "@caseynewton I think I did.",
  "id" : 446703599037325312,
  "in_reply_to_status_id" : 446700149981454336,
  "created_at" : "2014-03-20 17:43:32 +0000",
  "in_reply_to_screen_name" : "CaseyNewton",
  "in_reply_to_user_id_str" : "69426451",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FirstTweet",
      "indices" : [ 11, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/lPqFaFw30J",
      "expanded_url" : "https:\/\/twitter.com\/buster\/statuses\/11195",
      "display_url" : "twitter.com\/buster\/statuse\u2026"
    }, {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/KF34096FQg",
      "expanded_url" : "http:\/\/first-tweets.com",
      "display_url" : "first-tweets.com"
    } ]
  },
  "geo" : { },
  "id_str" : "446699843667234816",
  "text" : "I found my #FirstTweet: https:\/\/t.co\/lPqFaFw30J. What was yours? http:\/\/t.co\/KF34096FQg",
  "id" : 446699843667234816,
  "created_at" : "2014-03-20 17:28:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "Kristine Pettit",
      "screen_name" : "MrsVonDoom",
      "indices" : [ 8, 19 ],
      "id_str" : "2236225363",
      "id" : 2236225363
    }, {
      "name" : "Colin Ellard",
      "screen_name" : "WhereAmINow",
      "indices" : [ 20, 32 ],
      "id_str" : "21803992",
      "id" : 21803992
    }, {
      "name" : "Matt Laroche",
      "screen_name" : "mlroach",
      "indices" : [ 33, 41 ],
      "id_str" : "14451152",
      "id" : 14451152
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 42, 50 ],
      "id_str" : "216453702",
      "id" : 216453702
    }, {
      "name" : "David Jones",
      "screen_name" : "d_jones",
      "indices" : [ 51, 59 ],
      "id_str" : "15236750",
      "id" : 15236750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446530442343088128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859717219, -122.2755387935 ]
  },
  "id_str" : "446578590801723392",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach @MrsVonDoom @WhereAmINow @mlroach @mybasis @d_jones Fair enough. I love exploring new data too, but the novelty will wear off quick.",
  "id" : 446578590801723392,
  "in_reply_to_status_id" : 446530442343088128,
  "created_at" : "2014-03-20 09:26:47 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "Kristine Pettit",
      "screen_name" : "MrsVonDoom",
      "indices" : [ 8, 19 ],
      "id_str" : "2236225363",
      "id" : 2236225363
    }, {
      "name" : "Colin Ellard",
      "screen_name" : "WhereAmINow",
      "indices" : [ 20, 32 ],
      "id_str" : "21803992",
      "id" : 21803992
    }, {
      "name" : "Matt Laroche",
      "screen_name" : "mlroach",
      "indices" : [ 33, 41 ],
      "id_str" : "14451152",
      "id" : 14451152
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 42, 50 ],
      "id_str" : "216453702",
      "id" : 216453702
    }, {
      "name" : "David Jones",
      "screen_name" : "d_jones",
      "indices" : [ 51, 59 ],
      "id_str" : "15236750",
      "id" : 15236750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446528523792961537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597083129, -122.2753953283 ]
  },
  "id_str" : "446529096743256064",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach @MrsVonDoom @WhereAmINow @mlroach @mybasis @d_jones Ha. So how will heartbeat visualizations be actionable for you?",
  "id" : 446529096743256064,
  "in_reply_to_status_id" : 446528523792961537,
  "created_at" : "2014-03-20 06:10:07 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "Kristine Pettit",
      "screen_name" : "MrsVonDoom",
      "indices" : [ 8, 19 ],
      "id_str" : "2236225363",
      "id" : 2236225363
    }, {
      "name" : "Colin Ellard",
      "screen_name" : "WhereAmINow",
      "indices" : [ 20, 32 ],
      "id_str" : "21803992",
      "id" : 21803992
    }, {
      "name" : "Matt Laroche",
      "screen_name" : "mlroach",
      "indices" : [ 33, 41 ],
      "id_str" : "14451152",
      "id" : 14451152
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 42, 50 ],
      "id_str" : "216453702",
      "id" : 216453702
    }, {
      "name" : "David Jones",
      "screen_name" : "d_jones",
      "indices" : [ 51, 59 ],
      "id_str" : "15236750",
      "id" : 15236750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/6p5sILsdSH",
      "expanded_url" : "https:\/\/medium.com\/buster-benson\/7da6f22b8e2c",
      "display_url" : "medium.com\/buster-benson\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "446524181622956032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597031508, -122.2755055201 ]
  },
  "id_str" : "446526817520734209",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach @MrsVonDoom @WhereAmINow @mlroach @mybasis @d_jones See https:\/\/t.co\/6p5sILsdSH for my take on self-tracking.",
  "id" : 446526817520734209,
  "in_reply_to_status_id" : 446524181622956032,
  "created_at" : "2014-03-20 06:01:04 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446517391569068033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597088268, -122.2755577325 ]
  },
  "id_str" : "446523502812610560",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach Why do you want to measure heart rate?",
  "id" : 446523502812610560,
  "in_reply_to_status_id" : 446517391569068033,
  "created_at" : "2014-03-20 05:47:53 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "Kristine Pettit",
      "screen_name" : "MrsVonDoom",
      "indices" : [ 8, 19 ],
      "id_str" : "2236225363",
      "id" : 2236225363
    }, {
      "name" : "Colin Ellard",
      "screen_name" : "WhereAmINow",
      "indices" : [ 20, 32 ],
      "id_str" : "21803992",
      "id" : 21803992
    }, {
      "name" : "Matt Laroche",
      "screen_name" : "mlroach",
      "indices" : [ 33, 41 ],
      "id_str" : "14451152",
      "id" : 14451152
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 46, 54 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446522301182275585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597160804, -122.2755613583 ]
  },
  "id_str" : "446523396914814976",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach @MrsVonDoom @WhereAmINow @mlroach The @mybasis watch is pretty great but they don't have Stava integration or even an API yet.",
  "id" : 446523396914814976,
  "in_reply_to_status_id" : 446522301182275585,
  "created_at" : "2014-03-20 05:47:28 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Chiachiere",
      "screen_name" : "fchi",
      "indices" : [ 0, 5 ],
      "id_str" : "14829144",
      "id" : 14829144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446503743370981377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8599127056, -122.2755830829 ]
  },
  "id_str" : "446508246052790273",
  "in_reply_to_user_id" : 14829144,
  "text" : "@fchi Have you read it? If so, curious to hear your opinions.",
  "id" : 446508246052790273,
  "in_reply_to_status_id" : 446503743370981377,
  "created_at" : "2014-03-20 04:47:16 +0000",
  "in_reply_to_screen_name" : "fchi",
  "in_reply_to_user_id_str" : "14829144",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8622383063, -122.2807423433 ]
  },
  "id_str" : "446497344968597504",
  "text" : "Niko's talking about a house he wants to buy with a garage and he has the hiccups and is asking what it means for a house to be for sale.",
  "id" : 446497344968597504,
  "created_at" : "2014-03-20 04:03:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 11, 21 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446493260316291072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8611694526, -122.2889939026 ]
  },
  "id_str" : "446496965795147778",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane @kellianne I'm in!",
  "id" : 446496965795147778,
  "in_reply_to_status_id" : 446493260316291072,
  "created_at" : "2014-03-20 04:02:26 +0000",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/446491796487409665\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/lZsbVMHIva",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjJB6_rCMAAUQzb.jpg",
      "id_str" : "446491794843250688",
      "id" : 446491794843250688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjJB6_rCMAAUQzb.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lZsbVMHIva"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8605427314, -122.2896129639 ]
  },
  "id_str" : "446491796487409665",
  "text" : "8:36pm Choosing desserts http:\/\/t.co\/lZsbVMHIva",
  "id" : 446491796487409665,
  "created_at" : "2014-03-20 03:41:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446459231785730048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596775716, -122.2755806146 ]
  },
  "id_str" : "446466312500695041",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I just need 3-5 other people you want to compare yourself with.",
  "id" : 446466312500695041,
  "in_reply_to_status_id" : 446459231785730048,
  "created_at" : "2014-03-20 02:00:38 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8535226779, -122.2705717107 ]
  },
  "id_str" : "446461778617434113",
  "text" : "Who's read Mary Meeker's USA Inc?",
  "id" : 446461778617434113,
  "created_at" : "2014-03-20 01:42:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446442045528608768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776674528, -122.4178410621 ]
  },
  "id_str" : "446443721270497280",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez And let me know if I can help. I also have a cool script to run on your account that might be fun.",
  "id" : 446443721270497280,
  "in_reply_to_status_id" : 446442045528608768,
  "created_at" : "2014-03-20 00:30:52 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446441795996893184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7766463826, -122.4178543679 ]
  },
  "id_str" : "446442021130338305",
  "in_reply_to_user_id" : 2185,
  "text" : "@eramirez Ah, wait, that stuff might not be in the csv. It's in the json though, I think.",
  "id" : 446442021130338305,
  "in_reply_to_status_id" : 446441795996893184,
  "created_at" : "2014-03-20 00:24:06 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446441188254830592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7767109217, -122.4178340589 ]
  },
  "id_str" : "446441795996893184",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Ha! Just count up favorite_count and retweet_count for each category and divide by num tweets in each category.",
  "id" : 446441795996893184,
  "in_reply_to_status_id" : 446441188254830592,
  "created_at" : "2014-03-20 00:23:13 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446440605527588864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7767136884, -122.4177857783 ]
  },
  "id_str" : "446440841423638528",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez It's not called guessified self. :)",
  "id" : 446440841423638528,
  "in_reply_to_status_id" : 446440605527588864,
  "created_at" : "2014-03-20 00:19:25 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446371704353214464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7767036002, -122.4178493399 ]
  },
  "id_str" : "446440285984546816",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Which kind get more faves, replies, and retweets?",
  "id" : 446440285984546816,
  "in_reply_to_status_id" : 446371704353214464,
  "created_at" : "2014-03-20 00:17:13 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelsey Falter",
      "screen_name" : "kfalter",
      "indices" : [ 0, 8 ],
      "id_str" : "253578873",
      "id" : 253578873
    }, {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 9, 13 ],
      "id_str" : "937961",
      "id" : 937961
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 111, 123 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446373924146663424",
  "geo" : { },
  "id_str" : "446374235967987712",
  "in_reply_to_user_id" : 253578873,
  "text" : "@kfalter @msg Ah, in that case\u2014totally on board! How much does it cost to hire a professional reader? Couldn't @kickstarter do this today?",
  "id" : 446374235967987712,
  "in_reply_to_status_id" : 446373924146663424,
  "created_at" : "2014-03-19 19:54:45 +0000",
  "in_reply_to_screen_name" : "kfalter",
  "in_reply_to_user_id_str" : "253578873",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    }, {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 5, 11 ],
      "id_str" : "5814",
      "id" : 5814
    }, {
      "name" : "Amy Muller",
      "screen_name" : "AmyGSFN",
      "indices" : [ 12, 20 ],
      "id_str" : "26305496",
      "id" : 26305496
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 21, 24 ],
      "id_str" : "19853",
      "id" : 19853
    }, {
      "name" : "eric Lin",
      "screen_name" : "ericlin",
      "indices" : [ 25, 33 ],
      "id_str" : "8291",
      "id" : 8291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446371157311115266",
  "geo" : { },
  "id_str" : "446373601336258560",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg @tempo @amygsfn @rk @ericlin That would be rad. But I doubt most people would be very good readers.",
  "id" : 446373601336258560,
  "in_reply_to_status_id" : 446371157311115266,
  "created_at" : "2014-03-19 19:52:14 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 0, 6 ],
      "id_str" : "5814",
      "id" : 5814
    }, {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 7, 11 ],
      "id_str" : "937961",
      "id" : 937961
    }, {
      "name" : "Amy Muller",
      "screen_name" : "AmyGSFN",
      "indices" : [ 12, 20 ],
      "id_str" : "26305496",
      "id" : 26305496
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 21, 24 ],
      "id_str" : "19853",
      "id" : 19853
    }, {
      "name" : "eric Lin",
      "screen_name" : "ericlin",
      "indices" : [ 25, 33 ],
      "id_str" : "8291",
      "id" : 8291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "weird",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446368132848832512",
  "geo" : { },
  "id_str" : "446369304993222656",
  "in_reply_to_user_id" : 5814,
  "text" : "@tempo @msg @amygsfn @rk @ericlin I started that but didn't finish it\u2026 I wish there was an audiobook version, I hear it gets very #weird!",
  "id" : 446369304993222656,
  "in_reply_to_status_id" : 446368132848832512,
  "created_at" : "2014-03-19 19:35:10 +0000",
  "in_reply_to_screen_name" : "tempo",
  "in_reply_to_user_id_str" : "5814",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Muller",
      "screen_name" : "AmyGSFN",
      "indices" : [ 0, 8 ],
      "id_str" : "26305496",
      "id" : 26305496
    }, {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 9, 15 ],
      "id_str" : "5814",
      "id" : 5814
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 16, 19 ],
      "id_str" : "19853",
      "id" : 19853
    }, {
      "name" : "eric Lin",
      "screen_name" : "ericlin",
      "indices" : [ 20, 28 ],
      "id_str" : "8291",
      "id" : 8291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446353161989533696",
  "geo" : { },
  "id_str" : "446356613465509888",
  "in_reply_to_user_id" : 26305496,
  "text" : "@amygsfn @tempo @rk @ericlin Yes!",
  "id" : 446356613465509888,
  "in_reply_to_status_id" : 446353161989533696,
  "created_at" : "2014-03-19 18:44:44 +0000",
  "in_reply_to_screen_name" : "AmyGSFN",
  "in_reply_to_user_id_str" : "26305496",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 0, 6 ],
      "id_str" : "5814",
      "id" : 5814
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 7, 10 ],
      "id_str" : "19853",
      "id" : 19853
    }, {
      "name" : "eric Lin",
      "screen_name" : "ericlin",
      "indices" : [ 11, 19 ],
      "id_str" : "8291",
      "id" : 8291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446327694939004928",
  "geo" : { },
  "id_str" : "446327835116859392",
  "in_reply_to_user_id" : 5814,
  "text" : "@tempo @rk @ericlin I was going to do something like \"It's gonna be weird\" but open to other suggestions. :)",
  "id" : 446327835116859392,
  "in_reply_to_status_id" : 446327694939004928,
  "created_at" : "2014-03-19 16:50:22 +0000",
  "in_reply_to_screen_name" : "tempo",
  "in_reply_to_user_id_str" : "5814",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 0, 6 ],
      "id_str" : "5814",
      "id" : 5814
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 7, 10 ],
      "id_str" : "19853",
      "id" : 19853
    }, {
      "name" : "eric Lin",
      "screen_name" : "ericlin",
      "indices" : [ 11, 19 ],
      "id_str" : "8291",
      "id" : 8291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446327408170246144",
  "geo" : { },
  "id_str" : "446327517683523584",
  "in_reply_to_user_id" : 5814,
  "text" : "@tempo @rk @ericlin Awesome! I'll create something on Facebook later today unless anyone has a better idea.",
  "id" : 446327517683523584,
  "in_reply_to_status_id" : 446327408170246144,
  "created_at" : "2014-03-19 16:49:07 +0000",
  "in_reply_to_screen_name" : "tempo",
  "in_reply_to_user_id_str" : "5814",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 0, 6 ],
      "id_str" : "5814",
      "id" : 5814
    }, {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 7, 14 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446170365786456065",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597169674, -122.275485244 ]
  },
  "id_str" : "446297049240047616",
  "in_reply_to_user_id" : 5814,
  "text" : "@tempo @berkun Exactly. We live in a part of the world where the normalcy field has integrated gay marriage. In other places it hasn't.",
  "id" : 446297049240047616,
  "in_reply_to_status_id" : 446170365786456065,
  "created_at" : "2014-03-19 14:48:03 +0000",
  "in_reply_to_screen_name" : "tempo",
  "in_reply_to_user_id_str" : "5814",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline wolven",
      "screen_name" : "jackiewolven",
      "indices" : [ 0, 13 ],
      "id_str" : "7413172",
      "id" : 7413172
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 14, 21 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446222915797659649",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597058971, -122.2755065653 ]
  },
  "id_str" : "446247703148638208",
  "in_reply_to_user_id" : 7413172,
  "text" : "@jackiewolven @Medium I miss naps.",
  "id" : 446247703148638208,
  "in_reply_to_status_id" : 446222915797659649,
  "created_at" : "2014-03-19 11:31:58 +0000",
  "in_reply_to_screen_name" : "jackiewolven",
  "in_reply_to_user_id_str" : "7413172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 0, 6 ],
      "id_str" : "5814",
      "id" : 5814
    }, {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 7, 14 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446164017493446657",
  "geo" : { },
  "id_str" : "446168560402841600",
  "in_reply_to_user_id" : 5814,
  "text" : "@tempo @berkun The manufactured normalcy field ensures that we don\u2019t have to deal with discontinuities.",
  "id" : 446168560402841600,
  "in_reply_to_status_id" : 446164017493446657,
  "created_at" : "2014-03-19 06:17:28 +0000",
  "in_reply_to_screen_name" : "tempo",
  "in_reply_to_user_id_str" : "5814",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Pepper",
      "screen_name" : "noahmp",
      "indices" : [ 0, 7 ],
      "id_str" : "20219699",
      "id" : 20219699
    }, {
      "name" : "Galen",
      "screen_name" : "gln",
      "indices" : [ 8, 12 ],
      "id_str" : "4366051",
      "id" : 4366051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446157356477341698",
  "geo" : { },
  "id_str" : "446158098080616448",
  "in_reply_to_user_id" : 2185,
  "text" : "@noahmp @gln Experimentation or process without a hypothesis is sort of futile unless you can test every single option available.",
  "id" : 446158098080616448,
  "in_reply_to_status_id" : 446157356477341698,
  "created_at" : "2014-03-19 05:35:54 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Pepper",
      "screen_name" : "noahmp",
      "indices" : [ 0, 7 ],
      "id_str" : "20219699",
      "id" : 20219699
    }, {
      "name" : "Galen",
      "screen_name" : "gln",
      "indices" : [ 8, 12 ],
      "id_str" : "4366051",
      "id" : 4366051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446157049357807616",
  "geo" : { },
  "id_str" : "446157356477341698",
  "in_reply_to_user_id" : 20219699,
  "text" : "@noahmp @gln An idea is a hypothesis. Feedback, user research, experimentation all test an instantiated idea. I agree they need each other.",
  "id" : 446157356477341698,
  "in_reply_to_status_id" : 446157049357807616,
  "created_at" : "2014-03-19 05:32:57 +0000",
  "in_reply_to_screen_name" : "noahmp",
  "in_reply_to_user_id_str" : "20219699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446146149313830912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597135094, -122.2756181502 ]
  },
  "id_str" : "446148863552790528",
  "in_reply_to_user_id" : 2185,
  "text" : "Bad ideas look like great ideas. But only very rarely do great ideas.",
  "id" : 446148863552790528,
  "in_reply_to_status_id" : 446146149313830912,
  "created_at" : "2014-03-19 04:59:12 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Oestlien",
      "screen_name" : "christianism",
      "indices" : [ 0, 13 ],
      "id_str" : "9295502",
      "id" : 9295502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446146353760976896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8570839605, -122.2729661411 ]
  },
  "id_str" : "446146788777402369",
  "in_reply_to_user_id" : 9295502,
  "text" : "@christianism And cross your fingers that it's not actually a bad idea.",
  "id" : 446146788777402369,
  "in_reply_to_status_id" : 446146353760976896,
  "created_at" : "2014-03-19 04:50:58 +0000",
  "in_reply_to_screen_name" : "christianism",
  "in_reply_to_user_id_str" : "9295502",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8561206179, -122.2719776489 ]
  },
  "id_str" : "446146149313830912",
  "text" : "Great ideas look like bad ideas. So do bad ideas.",
  "id" : 446146149313830912,
  "created_at" : "2014-03-19 04:48:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 0, 6 ],
      "id_str" : "5814",
      "id" : 5814
    }, {
      "name" : "Venkatesh Rao",
      "screen_name" : "vgr",
      "indices" : [ 7, 11 ],
      "id_str" : "8500962",
      "id" : 8500962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446143693578199041",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8392414071, -122.2696221993 ]
  },
  "id_str" : "446144149083811840",
  "in_reply_to_user_id" : 5814,
  "text" : "@tempo @vgr I've been thinking about it a lot since I read it a while ago.",
  "id" : 446144149083811840,
  "in_reply_to_status_id" : 446143693578199041,
  "created_at" : "2014-03-19 04:40:28 +0000",
  "in_reply_to_screen_name" : "tempo",
  "in_reply_to_user_id_str" : "5814",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 0, 6 ],
      "id_str" : "5814",
      "id" : 5814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446143045109424130",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8206395498, -122.2693714221 ]
  },
  "id_str" : "446143471888252928",
  "in_reply_to_user_id" : 5814,
  "text" : "@tempo We could also do a Discourse forum. I've been meaning to try them out. Facebook is pretty accommodating though.",
  "id" : 446143471888252928,
  "in_reply_to_status_id" : 446143045109424130,
  "created_at" : "2014-03-19 04:37:47 +0000",
  "in_reply_to_screen_name" : "tempo",
  "in_reply_to_user_id_str" : "5814",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 0, 6 ],
      "id_str" : "5814",
      "id" : 5814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446142159482126338",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8089970809, -122.2682132958 ]
  },
  "id_str" : "446142544573788160",
  "in_reply_to_user_id" : 5814,
  "text" : "@tempo Ooh exciting. I need to talk a lot of these things out. Do you prefer Google\/Facebook groups or some other option?",
  "id" : 446142544573788160,
  "in_reply_to_status_id" : 446142159482126338,
  "created_at" : "2014-03-19 04:34:06 +0000",
  "in_reply_to_screen_name" : "tempo",
  "in_reply_to_user_id_str" : "5814",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 0, 6 ],
      "id_str" : "5814",
      "id" : 5814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/QT2egpWZaJ",
      "expanded_url" : "http:\/\/www.ribbonfarm.com\/2012\/05\/09\/welcome-to-the-future-nauseous\/",
      "display_url" : "ribbonfarm.com\/2012\/05\/09\/wel\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "446140991347490816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8036571829, -122.2720335369 ]
  },
  "id_str" : "446142201701998592",
  "in_reply_to_user_id" : 2185,
  "text" : "@tempo Though I'm not sure if the future will *feel* weird. Have you read this about the manufactured normalcy field? http:\/\/t.co\/QT2egpWZaJ",
  "id" : 446142201701998592,
  "in_reply_to_status_id" : 446140991347490816,
  "created_at" : "2014-03-19 04:32:44 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 0, 6 ],
      "id_str" : "5814",
      "id" : 5814
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itisgonnabeweird",
      "indices" : [ 88, 105 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446137697891913728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7934343677, -122.3962959172 ]
  },
  "id_str" : "446140991347490816",
  "in_reply_to_user_id" : 5814,
  "text" : "@tempo Wanna start a group somewhere to have conversations about the weird near future? #itisgonnabeweird",
  "id" : 446140991347490816,
  "in_reply_to_status_id" : 446137697891913728,
  "created_at" : "2014-03-19 04:27:55 +0000",
  "in_reply_to_screen_name" : "tempo",
  "in_reply_to_user_id_str" : "5814",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Underwood",
      "screen_name" : "aunder",
      "indices" : [ 0, 7 ],
      "id_str" : "4265731",
      "id" : 4265731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446136626222096384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7890279155, -122.4019366621 ]
  },
  "id_str" : "446138410575462400",
  "in_reply_to_user_id" : 4265731,
  "text" : "@aunder Let he\/she who has not had soft serve throw the first pizza.",
  "id" : 446138410575462400,
  "in_reply_to_status_id" : 446136626222096384,
  "created_at" : "2014-03-19 04:17:40 +0000",
  "in_reply_to_screen_name" : "aunder",
  "in_reply_to_user_id_str" : "4265731",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Underwood",
      "screen_name" : "aunder",
      "indices" : [ 0, 7 ],
      "id_str" : "4265731",
      "id" : 4265731
    }, {
      "name" : "Bailey & Tyler",
      "screen_name" : "BTpartytime",
      "indices" : [ 8, 20 ],
      "id_str" : "2331296845",
      "id" : 2331296845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446135108366393344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7893106252, -122.4016395927 ]
  },
  "id_str" : "446136159928737792",
  "in_reply_to_user_id" : 4265731,
  "text" : "@aunder @BTpartytime No matter how you slice it, pizza always takes the pie. What?",
  "id" : 446136159928737792,
  "in_reply_to_status_id" : 446135108366393344,
  "created_at" : "2014-03-19 04:08:43 +0000",
  "in_reply_to_screen_name" : "aunder",
  "in_reply_to_user_id_str" : "4265731",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Underwood",
      "screen_name" : "aunder",
      "indices" : [ 0, 7 ],
      "id_str" : "4265731",
      "id" : 4265731
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tradeoffs",
      "indices" : [ 69, 79 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446134190388420608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7876803819, -122.4034351874 ]
  },
  "id_str" : "446134807253504000",
  "in_reply_to_user_id" : 4265731,
  "text" : "@aunder I heard they had soft serve, but probably not as much pizza. #tradeoffs",
  "id" : 446134807253504000,
  "in_reply_to_status_id" : 446134190388420608,
  "created_at" : "2014-03-19 04:03:21 +0000",
  "in_reply_to_screen_name" : "aunder",
  "in_reply_to_user_id_str" : "4265731",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/4weRw0uE7W",
      "expanded_url" : "http:\/\/flic.kr\/p\/mczLuT",
      "display_url" : "flic.kr\/p\/mczLuT"
    } ]
  },
  "geo" : { },
  "id_str" : "446133873408479232",
  "text" : "8:36pm Ads PM dinner, not pictured here http:\/\/t.co\/4weRw0uE7W",
  "id" : 446133873408479232,
  "created_at" : "2014-03-19 03:59:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Underwood",
      "screen_name" : "aunder",
      "indices" : [ 0, 7 ],
      "id_str" : "4265731",
      "id" : 4265731
    }, {
      "name" : "Chris Aniszczyk",
      "screen_name" : "cra",
      "indices" : [ 8, 12 ],
      "id_str" : "14602130",
      "id" : 14602130
    }, {
      "name" : "Zero Zero ",
      "screen_name" : "Zerozerosf",
      "indices" : [ 13, 24 ],
      "id_str" : "161909257",
      "id" : 161909257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446128296137203712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7874459042, -122.4034992356 ]
  },
  "id_str" : "446128642620272640",
  "in_reply_to_user_id" : 4265731,
  "text" : "@aunder @cra @Zerozerosf :(",
  "id" : 446128642620272640,
  "in_reply_to_status_id" : 446128296137203712,
  "created_at" : "2014-03-19 03:38:51 +0000",
  "in_reply_to_screen_name" : "aunder",
  "in_reply_to_user_id_str" : "4265731",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 10, 22 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stairsmakesyousweaty",
      "indices" : [ 108, 129 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446015784536387584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7789419826, -122.4144691748 ]
  },
  "id_str" : "446099211835019264",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @GetReporter I think you meant sweetness but am not sure since you do take the stairs everywhere. #stairsmakesyousweaty",
  "id" : 446099211835019264,
  "in_reply_to_status_id" : 446015784536387584,
  "created_at" : "2014-03-19 01:41:54 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 3, 12 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 23, 30 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 109, 121 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/mvrygvz5Ea",
      "expanded_url" : "https:\/\/medium.com\/buster-benson\/7da6f22b8e2c",
      "display_url" : "medium.com\/buster-benson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446097753064484864",
  "text" : "RT @eramirez: In which @buster and I have a conversation in the comments about his great post on how he uses @GetReporter: https:\/\/t.co\/mvr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 9, 16 ],
        "id_str" : "2185",
        "id" : 2185
      }, {
        "name" : "Reporter App",
        "screen_name" : "GetReporter",
        "indices" : [ 95, 107 ],
        "id_str" : "2201640770",
        "id" : 2201640770
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/mvrygvz5Ea",
        "expanded_url" : "https:\/\/medium.com\/buster-benson\/7da6f22b8e2c",
        "display_url" : "medium.com\/buster-benson\/\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 34.0623919329, -118.3463603009 ]
    },
    "id_str" : "446068934689554432",
    "text" : "In which @buster and I have a conversation in the comments about his great post on how he uses @GetReporter: https:\/\/t.co\/mvrygvz5Ea",
    "id" : 446068934689554432,
    "created_at" : "2014-03-18 23:41:36 +0000",
    "user" : {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "protected" : false,
      "id_str" : "21135674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1777379809\/391870_10100894712944981_10004982_63155096_635581352_n_normal.jpg",
      "id" : 21135674,
      "verified" : false
    }
  },
  "id" : 446097753064484864,
  "created_at" : "2014-03-19 01:36:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "savannahh",
      "screen_name" : "savmalkin",
      "indices" : [ 1, 11 ],
      "id_str" : "1528589617",
      "id" : 1528589617
    }, {
      "name" : "katie",
      "screen_name" : "katie_nicastro",
      "indices" : [ 65, 80 ],
      "id_str" : "1061703649",
      "id" : 1061703649
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 87, 94 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bust",
      "indices" : [ 81, 86 ]
    }, {
      "text" : "woof",
      "indices" : [ 104, 109 ]
    }, {
      "text" : "startingdietnow",
      "indices" : [ 110, 126 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446036742316261376",
  "geo" : { },
  "id_str" : "446037093878218752",
  "in_reply_to_user_id" : 1528589617,
  "text" : "\u201C@savmalkin: Happy 50th birthday to the fattest dog out there \uD83D\uDC36\uD83D\uDC17 @katie_nicastro #bust @buster\" Thanks! #woof #startingdietnow",
  "id" : 446037093878218752,
  "in_reply_to_status_id" : 446036742316261376,
  "created_at" : "2014-03-18 21:35:04 +0000",
  "in_reply_to_screen_name" : "savmalkin",
  "in_reply_to_user_id_str" : "1528589617",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446020953068146690",
  "geo" : { },
  "id_str" : "446021644545323009",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort Relocate to the bay area?",
  "id" : 446021644545323009,
  "in_reply_to_status_id" : 446020953068146690,
  "created_at" : "2014-03-18 20:33:41 +0000",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446011500763693056",
  "geo" : { },
  "id_str" : "446020317622718465",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort Hello! Are you around for a while?",
  "id" : 446020317622718465,
  "in_reply_to_status_id" : 446011500763693056,
  "created_at" : "2014-03-18 20:28:25 +0000",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minimal",
      "screen_name" : "useminimal",
      "indices" : [ 3, 14 ],
      "id_str" : "2200766898",
      "id" : 2200766898
    }, {
      "name" : "HandUp",
      "screen_name" : "HandUp",
      "indices" : [ 84, 91 ],
      "id_str" : "1529033432",
      "id" : 1529033432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/vWgsRmfPWs",
      "expanded_url" : "http:\/\/gominimal.com",
      "display_url" : "gominimal.com"
    } ]
  },
  "geo" : { },
  "id_str" : "445998653669273600",
  "text" : "RT @useminimal: When you donate your unused stuff through Minimal, we give money to @HandUp members. Schedule your fee pickup today http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HandUp",
        "screen_name" : "HandUp",
        "indices" : [ 68, 75 ],
        "id_str" : "1529033432",
        "id" : 1529033432
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/vWgsRmfPWs",
        "expanded_url" : "http:\/\/gominimal.com",
        "display_url" : "gominimal.com"
      } ]
    },
    "geo" : { },
    "id_str" : "445973174476238848",
    "text" : "When you donate your unused stuff through Minimal, we give money to @HandUp members. Schedule your fee pickup today http:\/\/t.co\/vWgsRmfPWs",
    "id" : 445973174476238848,
    "created_at" : "2014-03-18 17:21:05 +0000",
    "user" : {
      "name" : "Minimal",
      "screen_name" : "useminimal",
      "protected" : false,
      "id_str" : "2200766898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/424087883104784384\/foVhHWAt_normal.png",
      "id" : 2200766898,
      "verified" : false
    }
  },
  "id" : 445998653669273600,
  "created_at" : "2014-03-18 19:02:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanner Christensen",
      "screen_name" : "tannerc",
      "indices" : [ 0, 8 ],
      "id_str" : "9161482",
      "id" : 9161482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445989607201832962",
  "geo" : { },
  "id_str" : "445989813955854336",
  "in_reply_to_user_id" : 9161482,
  "text" : "@tannerc Thanks! I plan on sharing that soon.",
  "id" : 445989813955854336,
  "in_reply_to_status_id" : 445989607201832962,
  "created_at" : "2014-03-18 18:27:12 +0000",
  "in_reply_to_screen_name" : "tannerc",
  "in_reply_to_user_id_str" : "9161482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 0, 12 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445989629293240322",
  "in_reply_to_user_id" : 2201640770,
  "text" : "@GetReporter I\u2019m finding that the toughest part of using your app is designing the questions. Idea: allow people to import question packs.",
  "id" : 445989629293240322,
  "created_at" : "2014-03-18 18:26:28 +0000",
  "in_reply_to_screen_name" : "GetReporter",
  "in_reply_to_user_id_str" : "2201640770",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "timoni west",
      "screen_name" : "timoni",
      "indices" : [ 0, 7 ],
      "id_str" : "12615",
      "id" : 12615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445987332341391362",
  "geo" : { },
  "id_str" : "445987541586817024",
  "in_reply_to_user_id" : 12615,
  "text" : "@timoni I've tailored it to my specific interests, but hopefully it is useful to others. Choosing the right questions is the hardest part.",
  "id" : 445987541586817024,
  "in_reply_to_status_id" : 445987332341391362,
  "created_at" : "2014-03-18 18:18:10 +0000",
  "in_reply_to_screen_name" : "timoni",
  "in_reply_to_user_id_str" : "12615",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 13, 20 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "idareyou",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/0M4agVNhcP",
      "expanded_url" : "https:\/\/medium.com\/buster-benson\/7da6f22b8e2c",
      "display_url" : "medium.com\/buster-benson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445986777153945600",
  "text" : "According to @Medium, you have a 37% chance of finishing my 11 min read on how I track quality of life: https:\/\/t.co\/0M4agVNhcP #idareyou",
  "id" : 445986777153945600,
  "created_at" : "2014-03-18 18:15:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "indices" : [ 3, 11 ],
      "id_str" : "4030",
      "id" : 4030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/FhYtEuEVqH",
      "expanded_url" : "http:\/\/www.tricycle.com\/feature\/dismay-motherhood",
      "display_url" : "tricycle.com\/feature\/dismay\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445944981832757248",
  "text" : "RT @monstro: \u201CHaving children is not inherently spiritual. Rather, it creates entanglement &amp; the likelihood of intense suffering.\u201D http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/FhYtEuEVqH",
        "expanded_url" : "http:\/\/www.tricycle.com\/feature\/dismay-motherhood",
        "display_url" : "tricycle.com\/feature\/dismay\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7783318019, -122.4334383397 ]
    },
    "id_str" : "445943537289285633",
    "text" : "\u201CHaving children is not inherently spiritual. Rather, it creates entanglement &amp; the likelihood of intense suffering.\u201D http:\/\/t.co\/FhYtEuEVqH",
    "id" : 445943537289285633,
    "created_at" : "2014-03-18 15:23:19 +0000",
    "user" : {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "protected" : false,
      "id_str" : "4030",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1248189330\/Judith_s_40th_Birthday-248_normal.jpg",
      "id" : 4030,
      "verified" : false
    }
  },
  "id" : 445944981832757248,
  "created_at" : "2014-03-18 15:29:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    }, {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "indices" : [ 48, 58 ],
      "id_str" : "18622869",
      "id" : 18622869
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pressing",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/o5fQsXdQpT",
      "expanded_url" : "http:\/\/www.vox.com\/elizabeth-kolbert-mass-extinction\/",
      "display_url" : "vox.com\/elizabeth-kolb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445944088953487360",
  "text" : "RT @voxdotcom: In case you missed it yesterday, @EzraKlein talks mass extinction with Elizabeth Kolbert: http:\/\/t.co\/o5fQsXdQpT #pressing",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ezra Klein",
        "screen_name" : "ezraklein",
        "indices" : [ 33, 43 ],
        "id_str" : "18622869",
        "id" : 18622869
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pressing",
        "indices" : [ 113, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/o5fQsXdQpT",
        "expanded_url" : "http:\/\/www.vox.com\/elizabeth-kolbert-mass-extinction\/",
        "display_url" : "vox.com\/elizabeth-kolb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "445935584025264128",
    "text" : "In case you missed it yesterday, @EzraKlein talks mass extinction with Elizabeth Kolbert: http:\/\/t.co\/o5fQsXdQpT #pressing",
    "id" : 445935584025264128,
    "created_at" : "2014-03-18 14:51:42 +0000",
    "user" : {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "protected" : false,
      "id_str" : "2347049341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442785905246347265\/v6W3UuIL_normal.jpeg",
      "id" : 2347049341,
      "verified" : true
    }
  },
  "id" : 445944088953487360,
  "created_at" : "2014-03-18 15:25:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445926118739030017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597666091, -122.2753770557 ]
  },
  "id_str" : "445941785508864000",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april It's all about choosing the right questions.",
  "id" : 445941785508864000,
  "in_reply_to_status_id" : 445926118739030017,
  "created_at" : "2014-03-18 15:16:21 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Times Is On It",
      "screen_name" : "NYTOnIt",
      "indices" : [ 109, 117 ],
      "id_str" : "297556877",
      "id" : 297556877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/om6hXBqqC8",
      "expanded_url" : "http:\/\/well.blogs.nytimes.com\/2014\/03\/17\/study-questions-fat-and-heart-disease-link",
      "display_url" : "well.blogs.nytimes.com\/2014\/03\/17\/stu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445811322072997888",
  "text" : "\u201CI think future dietary guidelines will put more and more emphasis on real food.\" http:\/\/t.co\/om6hXBqqC8 \/cc @NYTOnIt",
  "id" : 445811322072997888,
  "created_at" : "2014-03-18 06:37:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 75, 87 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/6p5sILsdSH",
      "expanded_url" : "https:\/\/medium.com\/buster-benson\/7da6f22b8e2c",
      "display_url" : "medium.com\/buster-benson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445803688620068865",
  "text" : "Calling all self-tracking nerds: I wrote up a post detailing how I'm using @getreporter to track my life: https:\/\/t.co\/6p5sILsdSH",
  "id" : 445803688620068865,
  "created_at" : "2014-03-18 06:07:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445794231118884864",
  "geo" : { },
  "id_str" : "445795239647666177",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus I do admire his clarity of purpose on the topic.",
  "id" : 445795239647666177,
  "in_reply_to_status_id" : 445794231118884864,
  "created_at" : "2014-03-18 05:34:02 +0000",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 3, 17 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/tadxKMlNq5",
      "expanded_url" : "http:\/\/www.gofundme.com\/poetswithapodcast",
      "display_url" : "gofundme.com\/poetswithapodc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445779448852271104",
  "text" : "RT @carinnatarvin: Also, you should give these kids $5. http:\/\/t.co\/tadxKMlNq5",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/tadxKMlNq5",
        "expanded_url" : "http:\/\/www.gofundme.com\/poetswithapodcast",
        "display_url" : "gofundme.com\/poetswithapodc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "445766470522249216",
    "text" : "Also, you should give these kids $5. http:\/\/t.co\/tadxKMlNq5",
    "id" : 445766470522249216,
    "created_at" : "2014-03-18 03:39:43 +0000",
    "user" : {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "protected" : false,
      "id_str" : "20833838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/92508641\/P1020505_normal.JPG",
      "id" : 20833838,
      "verified" : false
    }
  },
  "id" : 445779448852271104,
  "created_at" : "2014-03-18 04:31:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 0, 14 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445778663770828800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597602796, -122.2755646395 ]
  },
  "id_str" : "445779344338608128",
  "in_reply_to_user_id" : 226976689,
  "text" : "@marcprecipice No because I'm a bad parent. You just upped Niko's game. Thanks.",
  "id" : 445779344338608128,
  "in_reply_to_status_id" : 445778663770828800,
  "created_at" : "2014-03-18 04:30:52 +0000",
  "in_reply_to_screen_name" : "marcprecipice",
  "in_reply_to_user_id_str" : "226976689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "anthony smith",
      "screen_name" : "anthny",
      "indices" : [ 0, 7 ],
      "id_str" : "33004679",
      "id" : 33004679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445778165365866496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597354227, -122.2755859391 ]
  },
  "id_str" : "445778946374639616",
  "in_reply_to_user_id" : 33004679,
  "text" : "@anthny Shit I must've gotten the late Feb pack instead of the early March pack. Rookie mistake. He's never going to get into a good school.",
  "id" : 445778946374639616,
  "in_reply_to_status_id" : 445778165365866496,
  "created_at" : "2014-03-18 04:29:17 +0000",
  "in_reply_to_screen_name" : "anthny",
  "in_reply_to_user_id_str" : "33004679",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WhatsApp Inc.",
      "screen_name" : "WhatsApp",
      "indices" : [ 3, 12 ],
      "id_str" : "40148479",
      "id" : 40148479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/atRCQApnK3",
      "expanded_url" : "http:\/\/blog.whatsapp.com\/?p=529",
      "display_url" : "blog.whatsapp.com\/?p=529"
    } ]
  },
  "geo" : { },
  "id_str" : "445778514399068160",
  "text" : "RT @WhatsApp: Setting the record straight: http:\/\/t.co\/atRCQApnK3",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/atRCQApnK3",
        "expanded_url" : "http:\/\/blog.whatsapp.com\/?p=529",
        "display_url" : "blog.whatsapp.com\/?p=529"
      } ]
    },
    "geo" : { },
    "id_str" : "445616564440551425",
    "text" : "Setting the record straight: http:\/\/t.co\/atRCQApnK3",
    "id" : 445616564440551425,
    "created_at" : "2014-03-17 17:44:02 +0000",
    "user" : {
      "name" : "WhatsApp Inc.",
      "screen_name" : "WhatsApp",
      "protected" : false,
      "id_str" : "40148479",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2489643154\/m1xhas10144zk8tfp6ad_normal.png",
      "id" : 40148479,
      "verified" : true
    }
  },
  "id" : 445778514399068160,
  "created_at" : "2014-03-18 04:27:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/445777976907415553\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Vnhc6NhuOB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi-4tOdCUAAOyJS.jpg",
      "id_str" : "445777975246475264",
      "id" : 445777975246475264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi-4tOdCUAAOyJS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Vnhc6NhuOB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596979194, -122.2755096575 ]
  },
  "id_str" : "445777976907415553",
  "text" : "8:36pm Getting a head start on grooming Niko for Berkeley kindergarten http:\/\/t.co\/Vnhc6NhuOB",
  "id" : 445777976907415553,
  "created_at" : "2014-03-18 04:25:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445766470522249216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597012302, -122.2754840088 ]
  },
  "id_str" : "445767393852133376",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Done!",
  "id" : 445767393852133376,
  "in_reply_to_status_id" : 445766470522249216,
  "created_at" : "2014-03-18 03:43:23 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Brown",
      "screen_name" : "brownthings",
      "indices" : [ 0, 12 ],
      "id_str" : "15360225",
      "id" : 15360225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445623619058548738",
  "geo" : { },
  "id_str" : "445664293892018177",
  "in_reply_to_user_id" : 15360225,
  "text" : "@brownthings Thanks! We're just happy to see Pinterest adopting Twitter Cards. :) Send any feedback\/thoughts to buster@twitter.com.",
  "id" : 445664293892018177,
  "in_reply_to_status_id" : 445623619058548738,
  "created_at" : "2014-03-17 20:53:42 +0000",
  "in_reply_to_screen_name" : "brownthings",
  "in_reply_to_user_id_str" : "15360225",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryce Roberts",
      "screen_name" : "bryce",
      "indices" : [ 0, 6 ],
      "id_str" : "6160742",
      "id" : 6160742
    }, {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 7, 15 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 16, 25 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 59, 71 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445611103272194048",
  "geo" : { },
  "id_str" : "445611576490344448",
  "in_reply_to_user_id" : 6160742,
  "text" : "@bryce @rsarver @arainert I mean for app data storage. See @getreporter for best-in-class example of data collection\/storage\/retrieval.",
  "id" : 445611576490344448,
  "in_reply_to_status_id" : 445611103272194048,
  "created_at" : "2014-03-17 17:24:13 +0000",
  "in_reply_to_screen_name" : "bryce",
  "in_reply_to_user_id_str" : "6160742",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Bryce Roberts",
      "screen_name" : "bryce",
      "indices" : [ 9, 15 ],
      "id_str" : "6160742",
      "id" : 6160742
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 16, 25 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445610874070265856",
  "geo" : { },
  "id_str" : "445611137904566273",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver @bryce @arainert But I doubt it will ever work from Android\u2026 these days that's a severe limitation.",
  "id" : 445611137904566273,
  "in_reply_to_status_id" : 445610874070265856,
  "created_at" : "2014-03-17 17:22:28 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/R9Ols8u4Sh",
      "expanded_url" : "http:\/\/fivethirtyeight.com\/",
      "display_url" : "fivethirtyeight.com"
    } ]
  },
  "geo" : { },
  "id_str" : "445610883142529024",
  "text" : "New favorite website: http:\/\/t.co\/R9Ols8u4Sh",
  "id" : 445610883142529024,
  "created_at" : "2014-03-17 17:21:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryce Roberts",
      "screen_name" : "bryce",
      "indices" : [ 0, 6 ],
      "id_str" : "6160742",
      "id" : 6160742
    }, {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 7, 15 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 16, 25 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445606340086358016",
  "geo" : { },
  "id_str" : "445610523229315073",
  "in_reply_to_user_id" : 6160742,
  "text" : "@bryce @rsarver @arainert I personally think Dropbox has a better chance of being THE collection device. Easier to write and read your data.",
  "id" : 445610523229315073,
  "in_reply_to_status_id" : 445606340086358016,
  "created_at" : "2014-03-17 17:20:02 +0000",
  "in_reply_to_screen_name" : "bryce",
  "in_reply_to_user_id_str" : "6160742",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8602847533, -122.2760584231 ]
  },
  "id_str" : "445583791126360065",
  "text" : "Hippo: the Highest Paid Person's Opinion.",
  "id" : 445583791126360065,
  "created_at" : "2014-03-17 15:33:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colossal",
      "screen_name" : "Colossal",
      "indices" : [ 3, 12 ],
      "id_str" : "203063180",
      "id" : 203063180
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Colossal\/status\/445568573524561920\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/zf7hXvhbJC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi76QcRCUAEFL6d.jpg",
      "id_str" : "445568573528756225",
      "id" : 445568573528756225,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi76QcRCUAEFL6d.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/zf7hXvhbJC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/zbwjYAfZkW",
      "expanded_url" : "http:\/\/www.thisiscolossal.com\/2014\/03\/the-hypnotic-animated-gifs-of-david-szakaly\/",
      "display_url" : "thisiscolossal.com\/2014\/03\/the-hy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445582096115847168",
  "text" : "RT @Colossal: Today we feature one of the most influential animated gif makers on the web: David Szakaly. http:\/\/t.co\/zbwjYAfZkW http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Colossal\/status\/445568573524561920\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/zf7hXvhbJC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi76QcRCUAEFL6d.jpg",
        "id_str" : "445568573528756225",
        "id" : 445568573528756225,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi76QcRCUAEFL6d.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/zf7hXvhbJC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/zbwjYAfZkW",
        "expanded_url" : "http:\/\/www.thisiscolossal.com\/2014\/03\/the-hypnotic-animated-gifs-of-david-szakaly\/",
        "display_url" : "thisiscolossal.com\/2014\/03\/the-hy\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "445568573524561920",
    "text" : "Today we feature one of the most influential animated gif makers on the web: David Szakaly. http:\/\/t.co\/zbwjYAfZkW http:\/\/t.co\/zf7hXvhbJC",
    "id" : 445568573524561920,
    "created_at" : "2014-03-17 14:33:20 +0000",
    "user" : {
      "name" : "Colossal",
      "screen_name" : "Colossal",
      "protected" : false,
      "id_str" : "203063180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450852976337248256\/fOVTBYJu_normal.png",
      "id" : 203063180,
      "verified" : false
    }
  },
  "id" : 445582096115847168,
  "created_at" : "2014-03-17 15:27:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Temple",
      "screen_name" : "jtemple",
      "indices" : [ 3, 11 ],
      "id_str" : "2261261",
      "id" : 2261261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/RGqToECihP",
      "expanded_url" : "http:\/\/9to5mac.com\/2014\/03\/17\/this-is-healthbook-apples-first-major-step-into-health-fitness-tracking\/",
      "display_url" : "9to5mac.com\/2014\/03\/17\/thi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445581785028513794",
  "text" : "RT @jtemple: This is Healthbook, Apple\u2019s major first step into health tracking http:\/\/t.co\/RGqToECihP",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/RGqToECihP",
        "expanded_url" : "http:\/\/9to5mac.com\/2014\/03\/17\/this-is-healthbook-apples-first-major-step-into-health-fitness-tracking\/",
        "display_url" : "9to5mac.com\/2014\/03\/17\/thi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "445572946413641728",
    "text" : "This is Healthbook, Apple\u2019s major first step into health tracking http:\/\/t.co\/RGqToECihP",
    "id" : 445572946413641728,
    "created_at" : "2014-03-17 14:50:43 +0000",
    "user" : {
      "name" : "James Temple",
      "screen_name" : "jtemple",
      "protected" : false,
      "id_str" : "2261261",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436997163206201344\/h5MZpLav_normal.jpeg",
      "id" : 2261261,
      "verified" : true
    }
  },
  "id" : 445581785028513794,
  "created_at" : "2014-03-17 15:25:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WatchingCosmos",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/qXtVLpmK3B",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Tardigrade",
      "display_url" : "en.m.wikipedia.org\/wiki\/Tardigrade"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596987576, -122.275541341 ]
  },
  "id_str" : "445422167866363904",
  "text" : "Tardigrades aka water bears aka moss piglets have survived all 5 major extinctions on our planet. http:\/\/t.co\/qXtVLpmK3B #WatchingCosmos",
  "id" : 445422167866363904,
  "created_at" : "2014-03-17 04:51:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WatchingCosmos",
      "indices" : [ 17, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596816166, -122.2755391618 ]
  },
  "id_str" : "445419522955046912",
  "text" : "Commercial break #WatchingCosmos",
  "id" : 445419522955046912,
  "created_at" : "2014-03-17 04:41:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WatchingCosmos",
      "indices" : [ 94, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8602710931, -122.2762517638 ]
  },
  "id_str" : "445418234682957824",
  "text" : "Creature's eye view during the evolution of the eye is sort of nauseating in its awesomeness. #WatchingCosmos",
  "id" : 445418234682957824,
  "created_at" : "2014-03-17 04:35:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/isaach\/status\/445366693007593472\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/sW2k8Gakzk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi5CpUxCYAA23q-.jpg",
      "id_str" : "445366690872713216",
      "id" : 445366690872713216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi5CpUxCYAA23q-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sW2k8Gakzk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445417449970622466",
  "text" : "RT @isaach: been trying all day to get my head around this http:\/\/t.co\/sW2k8Gakzk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/isaach\/status\/445366693007593472\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/sW2k8Gakzk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi5CpUxCYAA23q-.jpg",
        "id_str" : "445366690872713216",
        "id" : 445366690872713216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi5CpUxCYAA23q-.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/sW2k8Gakzk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.776680563, -122.4244650511 ]
    },
    "id_str" : "445366693007593472",
    "text" : "been trying all day to get my head around this http:\/\/t.co\/sW2k8Gakzk",
    "id" : 445366693007593472,
    "created_at" : "2014-03-17 01:11:08 +0000",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430605387117494272\/lmplHwca_normal.png",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 445417449970622466,
  "created_at" : "2014-03-17 04:32:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 3, 15 ],
      "id_str" : "930061",
      "id" : 930061
    }, {
      "name" : "Julie Ann Horvath",
      "screen_name" : "nrrrdcore",
      "indices" : [ 73, 83 ],
      "id_str" : "18496432",
      "id" : 18496432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445417312963657728",
  "text" : "RT @ginatrapani: While you're patting GH on the back, remember that what @nrrrdcore did was 10x more brave, rare &amp; surprising than how the \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Ann Horvath",
        "screen_name" : "nrrrdcore",
        "indices" : [ 56, 66 ],
        "id_str" : "18496432",
        "id" : 18496432
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "445414153306787840",
    "text" : "While you're patting GH on the back, remember that what @nrrrdcore did was 10x more brave, rare &amp; surprising than how the company responded.",
    "id" : 445414153306787840,
    "created_at" : "2014-03-17 04:19:44 +0000",
    "user" : {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "protected" : false,
      "id_str" : "930061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000094875503\/88ec3120528d2e75172814a05cc19243_normal.png",
      "id" : 930061,
      "verified" : true
    }
  },
  "id" : 445417312963657728,
  "created_at" : "2014-03-17 04:32:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 7, 17 ],
      "id_str" : "19725644",
      "id" : 19725644
    }, {
      "name" : "COSMOS",
      "screen_name" : "COSMOSonTV",
      "indices" : [ 18, 29 ],
      "id_str" : "351221537",
      "id" : 351221537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445416535134183424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859730832, -122.275514328 ]
  },
  "id_str" : "445417116670246913",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc @neiltyson @COSMOSonTV I wonder if humans became more wild and met halfway.",
  "id" : 445417116670246913,
  "in_reply_to_status_id" : 445416535134183424,
  "created_at" : "2014-03-17 04:31:30 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "timoni west",
      "screen_name" : "timoni",
      "indices" : [ 0, 7 ],
      "id_str" : "12615",
      "id" : 12615
    }, {
      "name" : "FOX",
      "screen_name" : "FOXTV",
      "indices" : [ 94, 100 ],
      "id_str" : "16537989",
      "id" : 16537989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445416096095830016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597186646, -122.2755069752 ]
  },
  "id_str" : "445416444356866048",
  "in_reply_to_user_id" : 12615,
  "text" : "@timoni They hint at it but don't explore it. Plenty to cover on regular natural selection on @FOXTV I'm assuming.",
  "id" : 445416444356866048,
  "in_reply_to_status_id" : 445416096095830016,
  "created_at" : "2014-03-17 04:28:50 +0000",
  "in_reply_to_screen_name" : "timoni",
  "in_reply_to_user_id_str" : "12615",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "watchingcosmos",
      "indices" : [ 75, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596816194, -122.2756005658 ]
  },
  "id_str" : "445414150076784640",
  "text" : "Has artificial selection surpassed natural selection as a force of nature? #watchingcosmos",
  "id" : 445414150076784640,
  "created_at" : "2014-03-17 04:19:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 55, 65 ],
      "id_str" : "19725644",
      "id" : 19725644
    }, {
      "name" : "COSMOS",
      "screen_name" : "COSMOSonTV",
      "indices" : [ 69, 80 ],
      "id_str" : "351221537",
      "id" : 351221537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595865948, -122.2755551003 ]
  },
  "id_str" : "445410711749926912",
  "text" : "Wolves became dogs via \"survival of the friendliest\" - @neiltyson on @COSMOSonTV",
  "id" : 445410711749926912,
  "created_at" : "2014-03-17 04:06:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "COSMOS",
      "screen_name" : "COSMOSonTV",
      "indices" : [ 43, 54 ],
      "id_str" : "351221537",
      "id" : 351221537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/QXaHiDLX9Y",
      "expanded_url" : "http:\/\/flic.kr\/p\/m8mpph",
      "display_url" : "flic.kr\/p\/m8mpph"
    } ]
  },
  "geo" : { },
  "id_str" : "445410265342156800",
  "text" : "8:36pm Writing a blog post and waiting for @COSMOSonTV to come on. http:\/\/t.co\/QXaHiDLX9Y",
  "id" : 445410265342156800,
  "created_at" : "2014-03-17 04:04:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 3, 10 ],
      "id_str" : "1530531",
      "id" : 1530531
    }, {
      "name" : "Julie Ann Horvath",
      "screen_name" : "nrrrdcore",
      "indices" : [ 38, 48 ],
      "id_str" : "18496432",
      "id" : 18496432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/4ueJ8wCfRk",
      "expanded_url" : "https:\/\/github.com\/blog\/1800-update-on-julie-horvath-s-departure",
      "display_url" : "github.com\/blog\/1800-upda\u2026"
    }, {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/rSiTXtrEWC",
      "expanded_url" : "http:\/\/techcrunch.com\/2014\/03\/15\/julie-ann-horvath-describes-sexism-and-intimidation-behind-her-github-exit\/",
      "display_url" : "techcrunch.com\/2014\/03\/15\/jul\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445404096938266624",
  "text" : "RT @miradu: Wow: Github's response to @nrrrdcore https:\/\/t.co\/4ueJ8wCfRk (her story: http:\/\/t.co\/rSiTXtrEWC )",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Ann Horvath",
        "screen_name" : "nrrrdcore",
        "indices" : [ 26, 36 ],
        "id_str" : "18496432",
        "id" : 18496432
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/4ueJ8wCfRk",
        "expanded_url" : "https:\/\/github.com\/blog\/1800-update-on-julie-horvath-s-departure",
        "display_url" : "github.com\/blog\/1800-upda\u2026"
      }, {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/rSiTXtrEWC",
        "expanded_url" : "http:\/\/techcrunch.com\/2014\/03\/15\/julie-ann-horvath-describes-sexism-and-intimidation-behind-her-github-exit\/",
        "display_url" : "techcrunch.com\/2014\/03\/15\/jul\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "445400297263734784",
    "text" : "Wow: Github's response to @nrrrdcore https:\/\/t.co\/4ueJ8wCfRk (her story: http:\/\/t.co\/rSiTXtrEWC )",
    "id" : 445400297263734784,
    "created_at" : "2014-03-17 03:24:40 +0000",
    "user" : {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "protected" : false,
      "id_str" : "1530531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455935284769599488\/RM_aphCO_normal.jpeg",
      "id" : 1530531,
      "verified" : false
    }
  },
  "id" : 445404096938266624,
  "created_at" : "2014-03-17 03:39:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Sagan",
      "screen_name" : "nicksagan",
      "indices" : [ 3, 13 ],
      "id_str" : "169961978",
      "id" : 169961978
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COSMOS",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445380249161715712",
  "text" : "RT @nicksagan: Love the replay of the original #COSMOS evolution animation sequence, and hearing Dad's voice there gives me chills.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "COSMOS",
        "indices" : [ 32, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "445379373382647808",
    "text" : "Love the replay of the original #COSMOS evolution animation sequence, and hearing Dad's voice there gives me chills.",
    "id" : 445379373382647808,
    "created_at" : "2014-03-17 02:01:32 +0000",
    "user" : {
      "name" : "Nick Sagan",
      "screen_name" : "nicksagan",
      "protected" : false,
      "id_str" : "169961978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1720868217\/orangemonarch_normal.png",
      "id" : 169961978,
      "verified" : false
    }
  },
  "id" : 445380249161715712,
  "created_at" : "2014-03-17 02:05:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Graham",
      "screen_name" : "paulg",
      "indices" : [ 3, 9 ],
      "id_str" : "183749519",
      "id" : 183749519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/C8GVo6TWlz",
      "expanded_url" : "http:\/\/nyti.ms\/1danXZU",
      "display_url" : "nyti.ms\/1danXZU"
    } ]
  },
  "geo" : { },
  "id_str" : "445229272978817025",
  "text" : "RT @paulg: Income Gap, Meet the Longevity Gap: http:\/\/t.co\/C8GVo6TWlz",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/C8GVo6TWlz",
        "expanded_url" : "http:\/\/nyti.ms\/1danXZU",
        "display_url" : "nyti.ms\/1danXZU"
      } ]
    },
    "geo" : { },
    "id_str" : "445223691996000258",
    "text" : "Income Gap, Meet the Longevity Gap: http:\/\/t.co\/C8GVo6TWlz",
    "id" : 445223691996000258,
    "created_at" : "2014-03-16 15:42:54 +0000",
    "user" : {
      "name" : "Paul Graham",
      "screen_name" : "paulg",
      "protected" : false,
      "id_str" : "183749519",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1824002576\/pg-railsconf_normal.jpg",
      "id" : 183749519,
      "verified" : true
    }
  },
  "id" : 445229272978817025,
  "created_at" : "2014-03-16 16:05:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AMC Theatres",
      "screen_name" : "AMCTheatres",
      "indices" : [ 27, 39 ],
      "id_str" : "40245758",
      "id" : 40245758
    }, {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 61, 65 ],
      "id_str" : "259",
      "id" : 259
    }, {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 66, 73 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 74, 84 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/toiQ2fkLPm",
      "expanded_url" : "http:\/\/4sq.com\/1d8BMI7",
      "display_url" : "4sq.com\/1d8BMI7"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8329715239, -122.2920584679 ]
  },
  "id_str" : "445063288830033920",
  "text" : "I'm at AMC Bay Street 16 - @amctheatres for Veronica Mars w\/ @ian @sharon @kellianne http:\/\/t.co\/toiQ2fkLPm",
  "id" : 445063288830033920,
  "created_at" : "2014-03-16 05:05:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/9GRHRVSFJG",
      "expanded_url" : "http:\/\/flic.kr\/p\/m5W2R6",
      "display_url" : "flic.kr\/p\/m5W2R6"
    } ]
  },
  "geo" : { },
  "id_str" : "445061695682408448",
  "text" : "8:36pm Mall drinking before Veronica Mars http:\/\/t.co\/9GRHRVSFJG",
  "id" : 445061695682408448,
  "created_at" : "2014-03-16 04:59:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 32, 39 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 40, 44 ],
      "id_str" : "259",
      "id" : 259
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 49, 59 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8336227825, -122.2922424508 ]
  },
  "id_str" : "445037545697464321",
  "text" : "Saturday night at the mall with @sharon @ian and @kellianne. It's hopping.",
  "id" : 445037545697464321,
  "created_at" : "2014-03-16 03:23:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444907590971957248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597381799, -122.2755277287 ]
  },
  "id_str" : "444907704591462400",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg I haven't. Is it online?",
  "id" : 444907704591462400,
  "in_reply_to_status_id" : 444907590971957248,
  "created_at" : "2014-03-15 18:47:17 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Drew Breunig",
      "screen_name" : "dbreunig",
      "indices" : [ 10, 19 ],
      "id_str" : "14208457",
      "id" : 14208457
    }, {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 20, 32 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444906892381282304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596689522, -122.2756411328 ]
  },
  "id_str" : "444907419982774272",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @dbreunig @GetReporter I will try! I'm working on a long \"how I use Reporter\" post this weekend. My fave app in years.",
  "id" : 444907419982774272,
  "in_reply_to_status_id" : 444906892381282304,
  "created_at" : "2014-03-15 18:46:09 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drew Breunig",
      "screen_name" : "dbreunig",
      "indices" : [ 0, 9 ],
      "id_str" : "14208457",
      "id" : 14208457
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 10, 19 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Jeff Sussna",
      "screen_name" : "jeffsussna",
      "indices" : [ 20, 31 ],
      "id_str" : "232291320",
      "id" : 232291320
    }, {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 58, 70 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444906104053456896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597835345, -122.2756362129 ]
  },
  "id_str" : "444906593302241280",
  "in_reply_to_user_id" : 14208457,
  "text" : "@dbreunig @eramirez @jeffsussna True, therefore I applaud @GetReporter for taking the higher road. \uD83D\uDC4F\uD83D\uDC4F\uD83D\uDC4D",
  "id" : 444906593302241280,
  "in_reply_to_status_id" : 444906104053456896,
  "created_at" : "2014-03-15 18:42:52 +0000",
  "in_reply_to_screen_name" : "dbreunig",
  "in_reply_to_user_id_str" : "14208457",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunlight Foundation",
      "screen_name" : "SunFoundation",
      "indices" : [ 0, 14 ],
      "id_str" : "5743162",
      "id" : 5743162
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 15, 24 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444888507664695296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597229149, -122.2754680144 ]
  },
  "id_str" : "444905453017767937",
  "in_reply_to_user_id" : 5743162,
  "text" : "@SunFoundation @eramirez That's cool. Thanks for building it!",
  "id" : 444905453017767937,
  "in_reply_to_status_id" : 444888507664695296,
  "created_at" : "2014-03-15 18:38:20 +0000",
  "in_reply_to_screen_name" : "SunFoundation",
  "in_reply_to_user_id_str" : "5743162",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Secret",
      "screen_name" : "getsecret",
      "indices" : [ 108, 118 ],
      "id_str" : "2244765331",
      "id" : 2244765331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597236474, -122.27558904 ]
  },
  "id_str" : "444905001198956545",
  "text" : "There's cultural pressure to not speak out against bad actors, and to not be publicly vulnerable. Therefore @getsecret has value.",
  "id" : 444905001198956545,
  "created_at" : "2014-03-15 18:36:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597365599, -122.275589537 ]
  },
  "id_str" : "444904319922364416",
  "text" : "What % of our identities can be summarized by the mutual friends we have in common?",
  "id" : 444904319922364416,
  "created_at" : "2014-03-15 18:33:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Mac",
      "screen_name" : "ShaneMac",
      "indices" : [ 3, 12 ],
      "id_str" : "44378228",
      "id" : 44378228
    }, {
      "name" : "Secret",
      "screen_name" : "getsecret",
      "indices" : [ 80, 90 ],
      "id_str" : "2244765331",
      "id" : 2244765331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/7UkJoKIxXq",
      "expanded_url" : "https:\/\/medium.com\/p\/4ffa1043a0ef",
      "display_url" : "medium.com\/p\/4ffa1043a0ef"
    } ]
  },
  "geo" : { },
  "id_str" : "444899453615349760",
  "text" : "RT @ShaneMac: After an experience this morning, I just posted a new story about @getsecret: \n\nSecret: A Safe Haven https:\/\/t.co\/7UkJoKIxXq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Secret",
        "screen_name" : "getsecret",
        "indices" : [ 66, 76 ],
        "id_str" : "2244765331",
        "id" : 2244765331
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/7UkJoKIxXq",
        "expanded_url" : "https:\/\/medium.com\/p\/4ffa1043a0ef",
        "display_url" : "medium.com\/p\/4ffa1043a0ef"
      } ]
    },
    "geo" : { },
    "id_str" : "444152172389728257",
    "text" : "After an experience this morning, I just posted a new story about @getsecret: \n\nSecret: A Safe Haven https:\/\/t.co\/7UkJoKIxXq",
    "id" : 444152172389728257,
    "created_at" : "2014-03-13 16:45:04 +0000",
    "user" : {
      "name" : "Shane Mac",
      "screen_name" : "ShaneMac",
      "protected" : false,
      "id_str" : "44378228",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000585600651\/df221d6b3b85ae9a85f196791aec0eed_normal.jpeg",
      "id" : 44378228,
      "verified" : false
    }
  },
  "id" : 444899453615349760,
  "created_at" : "2014-03-15 18:14:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Seifried",
      "screen_name" : "PhilippSeifried",
      "indices" : [ 3, 19 ],
      "id_str" : "282738598",
      "id" : 282738598
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PhilippSeifried\/status\/443830395147014144\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/9wRWrZYQX6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BijNZJOCUAAotJv.png",
      "id_str" : "443830395151208448",
      "id" : 443830395151208448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BijNZJOCUAAotJv.png",
      "sizes" : [ {
        "h" : 75,
        "resize" : "fit",
        "w" : 378
      }, {
        "h" : 75,
        "resize" : "fit",
        "w" : 378
      }, {
        "h" : 67,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 75,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 75,
        "resize" : "fit",
        "w" : 378
      } ],
      "display_url" : "pic.twitter.com\/9wRWrZYQX6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444898811559694338",
  "text" : "RT @PhilippSeifried: Whatever I was actually going to Google, it can wait. http:\/\/t.co\/9wRWrZYQX6",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PhilippSeifried\/status\/443830395147014144\/photo\/1",
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/9wRWrZYQX6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BijNZJOCUAAotJv.png",
        "id_str" : "443830395151208448",
        "id" : 443830395151208448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BijNZJOCUAAotJv.png",
        "sizes" : [ {
          "h" : 75,
          "resize" : "fit",
          "w" : 378
        }, {
          "h" : 75,
          "resize" : "fit",
          "w" : 378
        }, {
          "h" : 67,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 75,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 75,
          "resize" : "fit",
          "w" : 378
        } ],
        "display_url" : "pic.twitter.com\/9wRWrZYQX6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443830395147014144",
    "text" : "Whatever I was actually going to Google, it can wait. http:\/\/t.co\/9wRWrZYQX6",
    "id" : 443830395147014144,
    "created_at" : "2014-03-12 19:26:26 +0000",
    "user" : {
      "name" : "Philipp Seifried",
      "screen_name" : "PhilippSeifried",
      "protected" : false,
      "id_str" : "282738598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464860985895833600\/_9OLc46C_normal.jpeg",
      "id" : 282738598,
      "verified" : false
    }
  },
  "id" : 444898811559694338,
  "created_at" : "2014-03-15 18:11:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Moos",
      "screen_name" : "sjmoos",
      "indices" : [ 0, 7 ],
      "id_str" : "445878959",
      "id" : 445878959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444887908496211968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598051658, -122.2755312828 ]
  },
  "id_str" : "444898294615900160",
  "in_reply_to_user_id" : 445878959,
  "text" : "@sjmoos Cool. Sounds good to me!",
  "id" : 444898294615900160,
  "in_reply_to_status_id" : 444887908496211968,
  "created_at" : "2014-03-15 18:09:53 +0000",
  "in_reply_to_screen_name" : "sjmoos",
  "in_reply_to_user_id_str" : "445878959",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/444681540002263041\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/TiKolWNoy2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BivTgOICUAEXYix.jpg",
      "id_str" : "444681538727202817",
      "id" : 444681538727202817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BivTgOICUAEXYix.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/TiKolWNoy2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597965907, -122.2755599909 ]
  },
  "id_str" : "444681540002263041",
  "text" : "8:36pm Showing off his nails http:\/\/t.co\/TiKolWNoy2",
  "id" : 444681540002263041,
  "created_at" : "2014-03-15 03:48:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7801187669, -122.4135170305 ]
  },
  "id_str" : "444642476775596032",
  "text" : "v2: where ideas go to die \uD83D\uDC80",
  "id" : 444642476775596032,
  "created_at" : "2014-03-15 01:13:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Jones",
      "screen_name" : "bugmanjones",
      "indices" : [ 3, 15 ],
      "id_str" : "377985681",
      "id" : 377985681
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/bugmanjones\/status\/444129716476608512\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/xA18qbe76T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bindn7XIQAA9muS.jpg",
      "id_str" : "444129716292042752",
      "id" : 444129716292042752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bindn7XIQAA9muS.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 820
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 820
      } ],
      "display_url" : "pic.twitter.com\/xA18qbe76T"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444526989290921984",
  "text" : "RT @bugmanjones: Well, these are the bees' knees. http:\/\/t.co\/xA18qbe76T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/bugmanjones\/status\/444129716476608512\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/xA18qbe76T",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bindn7XIQAA9muS.jpg",
        "id_str" : "444129716292042752",
        "id" : 444129716292042752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bindn7XIQAA9muS.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 820
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 702,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 820
        } ],
        "display_url" : "pic.twitter.com\/xA18qbe76T"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "444129716476608512",
    "text" : "Well, these are the bees' knees. http:\/\/t.co\/xA18qbe76T",
    "id" : 444129716476608512,
    "created_at" : "2014-03-13 15:15:50 +0000",
    "user" : {
      "name" : "Richard Jones",
      "screen_name" : "bugmanjones",
      "protected" : false,
      "id_str" : "377985681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000678380664\/cc09e5d5a1b86e8361a72b12b25848d7_normal.jpeg",
      "id" : 377985681,
      "verified" : false
    }
  },
  "id" : 444526989290921984,
  "created_at" : "2014-03-14 17:34:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "indices" : [ 3, 6 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444503730197495810",
  "text" : "RT @ev: AdWord in my Gmail: \"Start your OWN Twitter - PHP Micro-Blogging Script less than $35 - Tons of Features - Ajax\" Damn, wish I'd kno\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927834416",
    "text" : "AdWord in my Gmail: \"Start your OWN Twitter - PHP Micro-Blogging Script less than $35 - Tons of Features - Ajax\" Damn, wish I'd known.",
    "id" : 927834416,
    "created_at" : "2008-09-19 22:40:21 +0000",
    "user" : {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "protected" : false,
      "id_str" : "20",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000541049107\/3b6dcbd9c0182688457f372b40483e50_normal.jpeg",
      "id" : 20,
      "verified" : true
    }
  },
  "id" : 444503730197495810,
  "created_at" : "2014-03-14 16:02:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/444321134251479042\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/oVPRXo8x43",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiqLtzICIAAoSkx.jpg",
      "id_str" : "444321132183691264",
      "id" : 444321132183691264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiqLtzICIAAoSkx.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/oVPRXo8x43"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8796858248, -122.2689364013 ]
  },
  "id_str" : "444321134251479042",
  "text" : "8:36pm Drinking with cousins! http:\/\/t.co\/oVPRXo8x43",
  "id" : 444321134251479042,
  "created_at" : "2014-03-14 03:56:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/444276885644521472\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/gaY47rjcRX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BipjeRoCMAAeLhW.jpg",
      "id_str" : "444276885027958784",
      "id" : 444276885027958784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BipjeRoCMAAeLhW.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gaY47rjcRX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597071814, -122.2754456197 ]
  },
  "id_str" : "444276885644521472",
  "text" : "Niko helping Johannes mow our yard http:\/\/t.co\/gaY47rjcRX",
  "id" : 444276885644521472,
  "created_at" : "2014-03-14 01:00:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8394958144, -122.2695855797 ]
  },
  "id_str" : "444271791544885249",
  "text" : "Computronium: the theoretical arrangement of matter that is the best possible form of computing device for that amount of matter.",
  "id" : 444271791544885249,
  "created_at" : "2014-03-14 00:40:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron Marlow",
      "screen_name" : "cameronmarlow",
      "indices" : [ 0, 14 ],
      "id_str" : "5491",
      "id" : 5491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444226010544734209",
  "geo" : { },
  "id_str" : "444238144766869504",
  "in_reply_to_user_id" : 5491,
  "text" : "@cameronmarlow Ha. The big data didn't work! Therefore big data sucks!",
  "id" : 444238144766869504,
  "in_reply_to_status_id" : 444226010544734209,
  "created_at" : "2014-03-13 22:26:41 +0000",
  "in_reply_to_screen_name" : "cameronmarlow",
  "in_reply_to_user_id_str" : "5491",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron Marlow",
      "screen_name" : "cameronmarlow",
      "indices" : [ 0, 14 ],
      "id_str" : "5491",
      "id" : 5491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776656204, -122.416828937 ]
  },
  "id_str" : "444224442747457536",
  "in_reply_to_user_id" : 5491,
  "text" : "@cameronmarlow I don't have a log in. What's the gist?",
  "id" : 444224442747457536,
  "created_at" : "2014-03-13 21:32:15 +0000",
  "in_reply_to_screen_name" : "cameronmarlow",
  "in_reply_to_user_id_str" : "5491",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kottke.org",
      "screen_name" : "kottke",
      "indices" : [ 0, 7 ],
      "id_str" : "14120215",
      "id" : 14120215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444198968377880576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769598599, -122.4158725295 ]
  },
  "id_str" : "444202016059838464",
  "in_reply_to_user_id" : 14120215,
  "text" : "@kottke Just bought the book. Looks really interesting.",
  "id" : 444202016059838464,
  "in_reply_to_status_id" : 444198968377880576,
  "created_at" : "2014-03-13 20:03:08 +0000",
  "in_reply_to_screen_name" : "kottke",
  "in_reply_to_user_id_str" : "14120215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444194948309467136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7765418571, -122.4172103574 ]
  },
  "id_str" : "444198989936599040",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon Booooooo. I'm sorry. :(",
  "id" : 444198989936599040,
  "in_reply_to_status_id" : 444194948309467136,
  "created_at" : "2014-03-13 19:51:06 +0000",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Farrell",
      "screen_name" : "mikefarrell",
      "indices" : [ 3, 15 ],
      "id_str" : "359524790",
      "id" : 359524790
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 17, 24 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444181289457831936",
  "text" : "RT @mikefarrell: @buster if you leave hydrogen alone long enough, it starts to think about itself.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "444177223268835328",
    "geo" : { },
    "id_str" : "444181230259425280",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster if you leave hydrogen alone long enough, it starts to think about itself.",
    "id" : 444181230259425280,
    "in_reply_to_status_id" : 444177223268835328,
    "created_at" : "2014-03-13 18:40:32 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Michael Farrell",
      "screen_name" : "mikefarrell",
      "protected" : false,
      "id_str" : "359524790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460113623025594371\/Bm640ZrH_normal.jpeg",
      "id" : 359524790,
      "verified" : false
    }
  },
  "id" : 444181289457831936,
  "created_at" : "2014-03-13 18:40:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Littauer",
      "screen_name" : "richlitt",
      "indices" : [ 13, 22 ],
      "id_str" : "118133101",
      "id" : 118133101
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 24, 31 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444177541973434368",
  "geo" : { },
  "id_str" : "444177770399023104",
  "in_reply_to_user_id" : 118133101,
  "text" : "Star stuff. \u201C@richlitt: @buster More truth: we're all descended from Helium.\u201D",
  "id" : 444177770399023104,
  "in_reply_to_status_id" : 444177541973434368,
  "created_at" : "2014-03-13 18:26:47 +0000",
  "in_reply_to_screen_name" : "richlitt",
  "in_reply_to_user_id_str" : "118133101",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444177223268835328",
  "text" : "Aren't we actually descended from rocks and water?",
  "id" : 444177223268835328,
  "created_at" : "2014-03-13 18:24:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "followme",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/IuN5vy9A9M",
      "expanded_url" : "http:\/\/techcrunch.com\/2014\/03\/13\/twitter-is-testing-out-adding-promoted-accounts-to-desktop-timelines\/",
      "display_url" : "techcrunch.com\/2014\/03\/13\/twi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "444167106997653505",
  "text" : "Just got TechCrunch-outed for running a promoted account campaign: http:\/\/t.co\/IuN5vy9A9M #followme",
  "id" : 444167106997653505,
  "created_at" : "2014-03-13 17:44:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    }, {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 15, 28 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "burningmouth",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444099658176950272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859700853, -122.2754701787 ]
  },
  "id_str" : "444137909440897024",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin @MeganWelling A good chef always partakes of his dish before serving his best customers. #burningmouth",
  "id" : 444137909440897024,
  "in_reply_to_status_id" : 444099658176950272,
  "created_at" : "2014-03-13 15:48:23 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597077304, -122.275536877 ]
  },
  "id_str" : "443999923076218880",
  "text" : "Shoes thrown at me tonight: 2\nShoes that hit me tonight: 1",
  "id" : 443999923076218880,
  "created_at" : "2014-03-13 06:40:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 76, 84 ],
      "id_str" : "14097392",
      "id" : 14097392
    }, {
      "name" : "Josh Elman",
      "screen_name" : "joshelman",
      "indices" : [ 85, 95 ],
      "id_str" : "1979921",
      "id" : 1979921
    }, {
      "name" : "Julie Zhuo",
      "screen_name" : "joulee",
      "indices" : [ 96, 103 ],
      "id_str" : "17611446",
      "id" : 17611446
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/uRkyi9f02Y",
      "expanded_url" : "http:\/\/habitsummit.com",
      "display_url" : "habitsummit.com"
    } ]
  },
  "geo" : { },
  "id_str" : "443971232409452544",
  "text" : "Decided I want to go to http:\/\/t.co\/uRkyi9f02Y on Mar 25th. Excited to meet @nireyal @joshelman @joulee amongst others. Anyone else going?",
  "id" : 443971232409452544,
  "created_at" : "2014-03-13 04:46:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    }, {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 15, 28 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443961006264295424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859679007, -122.2754860094 ]
  },
  "id_str" : "443969380452278272",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin @MeganWelling I remember the lilies being delicious there.",
  "id" : 443969380452278272,
  "in_reply_to_status_id" : 443961006264295424,
  "created_at" : "2014-03-13 04:38:43 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/EQSkkSVjyz",
      "expanded_url" : "http:\/\/flic.kr\/p\/kZjN1a",
      "display_url" : "flic.kr\/p\/kZjN1a"
    } ]
  },
  "geo" : { },
  "id_str" : "443968820051738624",
  "text" : "8:36pm My new favorite Niko book http:\/\/t.co\/EQSkkSVjyz",
  "id" : 443968820051738624,
  "created_at" : "2014-03-13 04:36:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Weinersmith",
      "screen_name" : "ZachWeiner",
      "indices" : [ 3, 14 ],
      "id_str" : "20745130",
      "id" : 20745130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443940907444744194",
  "text" : "RT @ZachWeiner: For sale. Baby shoes. Never worn. We thought the coloring was too gendered and we already had too many baby shoes.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443940499598999552",
    "text" : "For sale. Baby shoes. Never worn. We thought the coloring was too gendered and we already had too many baby shoes.",
    "id" : 443940499598999552,
    "created_at" : "2014-03-13 02:43:57 +0000",
    "user" : {
      "name" : "Zach Weinersmith",
      "screen_name" : "ZachWeiner",
      "protected" : false,
      "id_str" : "20745130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2634755453\/40ffdf8a114b08a13aecc6f2a3a17320_normal.png",
      "id" : 20745130,
      "verified" : true
    }
  },
  "id" : 443940907444744194,
  "created_at" : "2014-03-13 02:45:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 3, 15 ],
      "id_str" : "195863654",
      "id" : 195863654
    }, {
      "name" : "Tim Berners-Lee",
      "screen_name" : "timberners_lee",
      "indices" : [ 53, 68 ],
      "id_str" : "84351228",
      "id" : 84351228
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/marihuertas\/status\/443846867776856064\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/kNjjsYKdK9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BijcX-kCYAAEFNG.png",
      "id_str" : "443846867785244672",
      "id" : 443846867785244672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BijcX-kCYAAEFNG.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 63,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 879
      }, {
        "h" : 111,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 879
      } ],
      "display_url" : "pic.twitter.com\/kNjjsYKdK9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/TFCCxqAs3P",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/IAmA\/comments\/2091d4\/i_am_tim_bernerslee_i_invented_the_www_25_years\/",
      "display_url" : "reddit.com\/r\/IAmA\/comment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443896707189727232",
  "text" : "RT @marihuertas: Pretty sure that with this comment, @timberners_lee has invented + now *won* the internet. http:\/\/t.co\/TFCCxqAs3P http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tim Berners-Lee",
        "screen_name" : "timberners_lee",
        "indices" : [ 36, 51 ],
        "id_str" : "84351228",
        "id" : 84351228
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/marihuertas\/status\/443846867776856064\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/kNjjsYKdK9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BijcX-kCYAAEFNG.png",
        "id_str" : "443846867785244672",
        "id" : 443846867785244672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BijcX-kCYAAEFNG.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 63,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 162,
          "resize" : "fit",
          "w" : 879
        }, {
          "h" : 111,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 162,
          "resize" : "fit",
          "w" : 879
        } ],
        "display_url" : "pic.twitter.com\/kNjjsYKdK9"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/TFCCxqAs3P",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/IAmA\/comments\/2091d4\/i_am_tim_bernerslee_i_invented_the_www_25_years\/",
        "display_url" : "reddit.com\/r\/IAmA\/comment\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443846867776856064",
    "text" : "Pretty sure that with this comment, @timberners_lee has invented + now *won* the internet. http:\/\/t.co\/TFCCxqAs3P http:\/\/t.co\/kNjjsYKdK9",
    "id" : 443846867776856064,
    "created_at" : "2014-03-12 20:31:54 +0000",
    "user" : {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "protected" : false,
      "id_str" : "195863654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000420864707\/b827233ecd1cd9452628cff95555c284_normal.jpeg",
      "id" : 195863654,
      "verified" : false
    }
  },
  "id" : 443896707189727232,
  "created_at" : "2014-03-12 23:49:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Moore",
      "screen_name" : "Moore",
      "indices" : [ 3, 9 ],
      "id_str" : "9632752",
      "id" : 9632752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/wJuHnnG2iO",
      "expanded_url" : "http:\/\/jonathanmoore.com\/post\/35867424576\/you-just-have-to-do-something",
      "display_url" : "jonathanmoore.com\/post\/358674245\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443895518104522752",
  "text" : "RT @Moore: You Just Have To Do Something http:\/\/t.co\/wJuHnnG2iO 18 months ago for a moment I held my lifeless son in my arms, and the impac\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/wJuHnnG2iO",
        "expanded_url" : "http:\/\/jonathanmoore.com\/post\/35867424576\/you-just-have-to-do-something",
        "display_url" : "jonathanmoore.com\/post\/358674245\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443871815908093952",
    "text" : "You Just Have To Do Something http:\/\/t.co\/wJuHnnG2iO 18 months ago for a moment I held my lifeless son in my arms, and the impact shaped me.",
    "id" : 443871815908093952,
    "created_at" : "2014-03-12 22:11:02 +0000",
    "user" : {
      "name" : "Jonathan Moore",
      "screen_name" : "Moore",
      "protected" : false,
      "id_str" : "9632752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000772256358\/04055a7b0846eabcd009840c68983579_normal.png",
      "id" : 9632752,
      "verified" : false
    }
  },
  "id" : 443895518104522752,
  "created_at" : "2014-03-12 23:45:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Colon",
      "screen_name" : "djgeoffe",
      "indices" : [ 0, 9 ],
      "id_str" : "16529427",
      "id" : 16529427
    }, {
      "name" : "Adam Singer",
      "screen_name" : "AdamSinger",
      "indices" : [ 10, 21 ],
      "id_str" : "14031032",
      "id" : 14031032
    }, {
      "name" : "Blair Reeves",
      "screen_name" : "BlairReeves",
      "indices" : [ 22, 34 ],
      "id_str" : "599755262",
      "id" : 599755262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443879554759659520",
  "geo" : { },
  "id_str" : "443879894649278465",
  "in_reply_to_user_id" : 16529427,
  "text" : "@djgeoffe @AdamSinger @BlairReeves I\u2019d be in on that. :)",
  "id" : 443879894649278465,
  "in_reply_to_status_id" : 443879554759659520,
  "created_at" : "2014-03-12 22:43:08 +0000",
  "in_reply_to_screen_name" : "djgeoffe",
  "in_reply_to_user_id_str" : "16529427",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Rae Gjording",
      "screen_name" : "line_rae",
      "indices" : [ 0, 9 ],
      "id_str" : "2385874530",
      "id" : 2385874530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443873024253505537",
  "geo" : { },
  "id_str" : "443874518751145985",
  "in_reply_to_user_id" : 2385874530,
  "text" : "@line_rae Hello!",
  "id" : 443874518751145985,
  "in_reply_to_status_id" : 443873024253505537,
  "created_at" : "2014-03-12 22:21:46 +0000",
  "in_reply_to_screen_name" : "line_rae",
  "in_reply_to_user_id_str" : "2385874530",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beauty Crowd TV",
      "screen_name" : "beautycrowd",
      "indices" : [ 0, 12 ],
      "id_str" : "249069412",
      "id" : 249069412
    }, {
      "name" : "Princess Alison ",
      "screen_name" : "AliW33",
      "indices" : [ 13, 20 ],
      "id_str" : "419790477",
      "id" : 419790477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443836377499992064",
  "geo" : { },
  "id_str" : "443836628423827456",
  "in_reply_to_user_id" : 249069412,
  "text" : "@beautycrowd @aliw33 I bet you'd regret this decision after the fact.",
  "id" : 443836628423827456,
  "in_reply_to_status_id" : 443836377499992064,
  "created_at" : "2014-03-12 19:51:12 +0000",
  "in_reply_to_screen_name" : "beautycrowd",
  "in_reply_to_user_id_str" : "249069412",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dustin senos",
      "screen_name" : "dustin",
      "indices" : [ 1, 8 ],
      "id_str" : "5413",
      "id" : 5413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443569496330997761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762885693, -122.4173490195 ]
  },
  "id_str" : "443834316213067776",
  "in_reply_to_user_id" : 5413,
  "text" : "\"@dustin: this is a promoted tweet\" this is earned engagement",
  "id" : 443834316213067776,
  "in_reply_to_status_id" : 443569496330997761,
  "created_at" : "2014-03-12 19:42:01 +0000",
  "in_reply_to_screen_name" : "dustin",
  "in_reply_to_user_id_str" : "5413",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/rEN3zn18WA",
      "expanded_url" : "http:\/\/darkpatterns.org\/",
      "display_url" : "darkpatterns.org"
    } ]
  },
  "geo" : { },
  "id_str" : "443833532125687808",
  "text" : "RT @wilbanks: Dark patterns: design that tricks users into doing things they don\u2019t want to do. http:\/\/t.co\/rEN3zn18WA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/rEN3zn18WA",
        "expanded_url" : "http:\/\/darkpatterns.org\/",
        "display_url" : "darkpatterns.org"
      } ]
    },
    "geo" : { },
    "id_str" : "443821941095686144",
    "text" : "Dark patterns: design that tricks users into doing things they don\u2019t want to do. http:\/\/t.co\/rEN3zn18WA",
    "id" : 443821941095686144,
    "created_at" : "2014-03-12 18:52:51 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440966760770965504\/ddUkG7Y6_normal.jpeg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 443833532125687808,
  "created_at" : "2014-03-12 19:38:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 3, 17 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443821206538424320",
  "text" : "RT @buster_ebooks: Doubt at the end of an idea that backfires is proof that Obama conspired to make them look bad",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/busterbenson.com\" rel=\"nofollow\"\u003EBuster eBooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443810944011870208",
    "text" : "Doubt at the end of an idea that backfires is proof that Obama conspired to make them look bad",
    "id" : 443810944011870208,
    "created_at" : "2014-03-12 18:09:09 +0000",
    "user" : {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "protected" : false,
      "id_str" : "1901375096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000503050571\/228ccabfeeb4e55bd8e172595babe02e_normal.jpeg",
      "id" : 1901375096,
      "verified" : false
    }
  },
  "id" : 443821206538424320,
  "created_at" : "2014-03-12 18:49:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Hefferan",
      "screen_name" : "danhefferan",
      "indices" : [ 0, 12 ],
      "id_str" : "102861135",
      "id" : 102861135
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 43, 53 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443762170052878336",
  "geo" : { },
  "id_str" : "443787462897172480",
  "in_reply_to_user_id" : 102861135,
  "text" : "@danhefferan Nah, not really. But now that @kellianne is running support\/community, I figured having a Twitter presence made sense.",
  "id" : 443787462897172480,
  "in_reply_to_status_id" : 443762170052878336,
  "created_at" : "2014-03-12 16:35:50 +0000",
  "in_reply_to_screen_name" : "danhefferan",
  "in_reply_to_user_id_str" : "102861135",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "750 Words",
      "screen_name" : "750words",
      "indices" : [ 3, 12 ],
      "id_str" : "401833335",
      "id" : 401833335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443761881753206784",
  "text" : "RT @750words: Hello.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443647545131028480",
    "text" : "Hello.",
    "id" : 443647545131028480,
    "created_at" : "2014-03-12 07:19:51 +0000",
    "user" : {
      "name" : "750 Words",
      "screen_name" : "750words",
      "protected" : false,
      "id_str" : "401833335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443644067075723264\/QJc2IfUa_normal.png",
      "id" : 401833335,
      "verified" : false
    }
  },
  "id" : 443761881753206784,
  "created_at" : "2014-03-12 14:54:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/443597866611638273\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/AWJFNhvrjW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bif56A9CcAA7w3p.jpg",
      "id_str" : "443597863403024384",
      "id" : 443597863403024384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bif56A9CcAA7w3p.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/AWJFNhvrjW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596820082, -122.2756234941 ]
  },
  "id_str" : "443597866611638273",
  "text" : "8:36pm Niko's first shower http:\/\/t.co\/AWJFNhvrjW",
  "id" : 443597866611638273,
  "created_at" : "2014-03-12 04:02:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Data",
      "screen_name" : "TwitterData",
      "indices" : [ 3, 15 ],
      "id_str" : "1526228120",
      "id" : 1526228120
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TwitterData\/status\/443464228611960832\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/vM8abXjWlk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BieAXcFCMAAWAhx.png",
      "id_str" : "443464228481937408",
      "id" : 443464228481937408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BieAXcFCMAAWAhx.png",
      "sizes" : [ {
        "h" : 498,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 498,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 498,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vM8abXjWlk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/Ouh1SmhVhF",
      "expanded_url" : "https:\/\/blog.twitter.com\/2014\/what-fuels-a-tweets-engagement",
      "display_url" : "blog.twitter.com\/2014\/what-fuel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443466125557252096",
  "text" : "RT @TwitterData: What fuels a Tweet\u2019s engagement? New research for verified users shows boost for photos\nhttps:\/\/t.co\/Ouh1SmhVhF http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TwitterData\/status\/443464228611960832\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/vM8abXjWlk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BieAXcFCMAAWAhx.png",
        "id_str" : "443464228481937408",
        "id" : 443464228481937408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BieAXcFCMAAWAhx.png",
        "sizes" : [ {
          "h" : 498,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 498,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 498,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/vM8abXjWlk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/Ouh1SmhVhF",
        "expanded_url" : "https:\/\/blog.twitter.com\/2014\/what-fuels-a-tweets-engagement",
        "display_url" : "blog.twitter.com\/2014\/what-fuel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443464228611960832",
    "text" : "What fuels a Tweet\u2019s engagement? New research for verified users shows boost for photos\nhttps:\/\/t.co\/Ouh1SmhVhF http:\/\/t.co\/vM8abXjWlk",
    "id" : 443464228611960832,
    "created_at" : "2014-03-11 19:11:25 +0000",
    "user" : {
      "name" : "Twitter Data",
      "screen_name" : "TwitterData",
      "protected" : false,
      "id_str" : "1526228120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000079832947\/a1e83160378bce402803aefcfb07e167_normal.png",
      "id" : 1526228120,
      "verified" : true
    }
  },
  "id" : 443466125557252096,
  "created_at" : "2014-03-11 19:18:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Great Discontent",
      "screen_name" : "greatdiscontent",
      "indices" : [ 3, 19 ],
      "id_str" : "238676977",
      "id" : 238676977
    }, {
      "name" : "Nicholas Felton",
      "screen_name" : "feltron",
      "indices" : [ 127, 135 ],
      "id_str" : "14892191",
      "id" : 14892191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/DuDFN1zNAs",
      "expanded_url" : "http:\/\/thegreatdiscontent.com\/nicholas-felton",
      "display_url" : "thegreatdiscontent.com\/nicholas-felton"
    } ]
  },
  "geo" : { },
  "id_str" : "443402195656912898",
  "text" : "RT @greatdiscontent: \u201CI\u2019m trying to lift the veil on the size, power, humanity, humor, and narrative potential of our data\u2026\u201D\n\n\u2014@feltron: ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nicholas Felton",
        "screen_name" : "feltron",
        "indices" : [ 106, 114 ],
        "id_str" : "14892191",
        "id" : 14892191
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/DuDFN1zNAs",
        "expanded_url" : "http:\/\/thegreatdiscontent.com\/nicholas-felton",
        "display_url" : "thegreatdiscontent.com\/nicholas-felton"
      } ]
    },
    "geo" : { },
    "id_str" : "443385504781045760",
    "text" : "\u201CI\u2019m trying to lift the veil on the size, power, humanity, humor, and narrative potential of our data\u2026\u201D\n\n\u2014@feltron: http:\/\/t.co\/DuDFN1zNAs",
    "id" : 443385504781045760,
    "created_at" : "2014-03-11 13:58:36 +0000",
    "user" : {
      "name" : "The Great Discontent",
      "screen_name" : "greatdiscontent",
      "protected" : false,
      "id_str" : "238676977",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000651681920\/78e987868bc2e0df4b816bb4bfdd183d_normal.png",
      "id" : 238676977,
      "verified" : false
    }
  },
  "id" : 443402195656912898,
  "created_at" : "2014-03-11 15:04:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee LeFever",
      "screen_name" : "leelefever",
      "indices" : [ 3, 14 ],
      "id_str" : "12279",
      "id" : 12279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/NxeUsTJSPM",
      "expanded_url" : "http:\/\/vox.com",
      "display_url" : "vox.com"
    } ]
  },
  "geo" : { },
  "id_str" : "443259593313890304",
  "text" : "RT @leelefever: Love. \"Vox is a general interest news site for the 21st century. Its mission is simple: Explain the news.\" http:\/\/t.co\/NxeU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/NxeUsTJSPM",
        "expanded_url" : "http:\/\/vox.com",
        "display_url" : "vox.com"
      } ]
    },
    "geo" : { },
    "id_str" : "443196691861106688",
    "text" : "Love. \"Vox is a general interest news site for the 21st century. Its mission is simple: Explain the news.\" http:\/\/t.co\/NxeUsTJSPM",
    "id" : 443196691861106688,
    "created_at" : "2014-03-11 01:28:20 +0000",
    "user" : {
      "name" : "Lee LeFever",
      "screen_name" : "leelefever",
      "protected" : false,
      "id_str" : "12279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3249299655\/4fcc204542a282eae806ba6df7184463_normal.jpeg",
      "id" : 12279,
      "verified" : false
    }
  },
  "id" : 443259593313890304,
  "created_at" : "2014-03-11 05:38:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/443259496631001089\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/fhNUnc2gcE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BibGKcOCAAARoxq.jpg",
      "id_str" : "443259496018608128",
      "id" : 443259496018608128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BibGKcOCAAARoxq.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fhNUnc2gcE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597352959, -122.2756050587 ]
  },
  "id_str" : "443259496631001089",
  "text" : "8:36pm Cleaning up Niko's repurposed melodica case filled with all of his \"treasure\" that I tripped over and spilled. http:\/\/t.co\/fhNUnc2gcE",
  "id" : 443259496631001089,
  "created_at" : "2014-03-11 05:37:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FiveThirtyEight",
      "screen_name" : "FiveThirtyEight",
      "indices" : [ 3, 19 ],
      "id_str" : "2303751216",
      "id" : 2303751216
    }, {
      "name" : "Bill Simmons",
      "screen_name" : "BillSimmons",
      "indices" : [ 22, 34 ],
      "id_str" : "32765534",
      "id" : 32765534
    }, {
      "name" : "FiveThirtyEight",
      "screen_name" : "FiveThirtyEight",
      "indices" : [ 38, 54 ],
      "id_str" : "2303751216",
      "id" : 2303751216
    }, {
      "name" : "Re\/code",
      "screen_name" : "Recode",
      "indices" : [ 123, 130 ],
      "id_str" : "2244340904",
      "id" : 2244340904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/u8psQ5a48F",
      "expanded_url" : "http:\/\/on.recode.net\/1cQa56P",
      "display_url" : "on.recode.net\/1cQa56P"
    } ]
  },
  "geo" : { },
  "id_str" : "443257942192578560",
  "text" : "RT @FiveThirtyEight: .@BillSimmons on @FiveThirtyEight: \"I think it\u2019s not the site that some people think it is,\" he tells @Recode. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Simmons",
        "screen_name" : "BillSimmons",
        "indices" : [ 1, 13 ],
        "id_str" : "32765534",
        "id" : 32765534
      }, {
        "name" : "FiveThirtyEight",
        "screen_name" : "FiveThirtyEight",
        "indices" : [ 17, 33 ],
        "id_str" : "2303751216",
        "id" : 2303751216
      }, {
        "name" : "Re\/code",
        "screen_name" : "Recode",
        "indices" : [ 102, 109 ],
        "id_str" : "2244340904",
        "id" : 2244340904
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/u8psQ5a48F",
        "expanded_url" : "http:\/\/on.recode.net\/1cQa56P",
        "display_url" : "on.recode.net\/1cQa56P"
      } ]
    },
    "geo" : { },
    "id_str" : "443196528195534848",
    "text" : ".@BillSimmons on @FiveThirtyEight: \"I think it\u2019s not the site that some people think it is,\" he tells @Recode. http:\/\/t.co\/u8psQ5a48F",
    "id" : 443196528195534848,
    "created_at" : "2014-03-11 01:27:41 +0000",
    "user" : {
      "name" : "FiveThirtyEight",
      "screen_name" : "FiveThirtyEight",
      "protected" : false,
      "id_str" : "2303751216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442370574040301568\/j673s9Ue_normal.jpeg",
      "id" : 2303751216,
      "verified" : true
    }
  },
  "id" : 443257942192578560,
  "created_at" : "2014-03-11 05:31:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "geoffobvs",
      "screen_name" : "geoffobvs",
      "indices" : [ 0, 10 ],
      "id_str" : "63147001",
      "id" : 63147001
    }, {
      "name" : "Coursetalk",
      "screen_name" : "CourseTalk",
      "indices" : [ 11, 22 ],
      "id_str" : "737894706",
      "id" : 737894706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/iTG4vYU9ey",
      "expanded_url" : "http:\/\/analytics.twitter.com",
      "display_url" : "analytics.twitter.com"
    } ]
  },
  "in_reply_to_status_id_str" : "443078207714394112",
  "geo" : { },
  "id_str" : "443078761181749248",
  "in_reply_to_user_id" : 63147001,
  "text" : "@geoffobvs @coursetalk I'm not seeing your post. Which account is this for? Which account is logged in on http:\/\/t.co\/iTG4vYU9ey?",
  "id" : 443078761181749248,
  "in_reply_to_status_id" : 443078207714394112,
  "created_at" : "2014-03-10 17:39:43 +0000",
  "in_reply_to_screen_name" : "geoffobvs",
  "in_reply_to_user_id_str" : "63147001",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/voxdotcom\/status\/443017761086656512\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/dX6kTn3ZPp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiXqTncCUAAQwOp.png",
      "id_str" : "443017761090850816",
      "id" : 443017761090850816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiXqTncCUAAQwOp.png",
      "sizes" : [ {
        "h" : 934,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 981,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 981,
        "resize" : "fit",
        "w" : 630
      } ],
      "display_url" : "pic.twitter.com\/dX6kTn3ZPp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/GUQXWtKI7b",
      "expanded_url" : "http:\/\/www.motherjones.com\/environment\/2014\/02\/wheres-californias-water-going",
      "display_url" : "motherjones.com\/environment\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443035954316472320",
  "text" : "RT @voxdotcom: Where your food (including your vegetables!) comes from: http:\/\/t.co\/GUQXWtKI7b http:\/\/t.co\/dX6kTn3ZPp",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/voxdotcom\/status\/443017761086656512\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/dX6kTn3ZPp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiXqTncCUAAQwOp.png",
        "id_str" : "443017761090850816",
        "id" : 443017761090850816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiXqTncCUAAQwOp.png",
        "sizes" : [ {
          "h" : 934,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 981,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 981,
          "resize" : "fit",
          "w" : 630
        } ],
        "display_url" : "pic.twitter.com\/dX6kTn3ZPp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/GUQXWtKI7b",
        "expanded_url" : "http:\/\/www.motherjones.com\/environment\/2014\/02\/wheres-californias-water-going",
        "display_url" : "motherjones.com\/environment\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443017761086656512",
    "text" : "Where your food (including your vegetables!) comes from: http:\/\/t.co\/GUQXWtKI7b http:\/\/t.co\/dX6kTn3ZPp",
    "id" : 443017761086656512,
    "created_at" : "2014-03-10 13:37:19 +0000",
    "user" : {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "protected" : false,
      "id_str" : "2347049341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442785905246347265\/v6W3UuIL_normal.jpeg",
      "id" : 2347049341,
      "verified" : true
    }
  },
  "id" : 443035954316472320,
  "created_at" : "2014-03-10 14:49:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alex choi \u2744\uFE0F\u2615\uFE0F",
      "screen_name" : "xc",
      "indices" : [ 1, 4 ],
      "id_str" : "26233",
      "id" : 26233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442892193041117184",
  "geo" : { },
  "id_str" : "442894411341389824",
  "in_reply_to_user_id" : 26233,
  "text" : ".@xc Ah, yeah, makes sense that FOX News is the only one that's intentionally misinformed.",
  "id" : 442894411341389824,
  "in_reply_to_status_id" : 442892193041117184,
  "created_at" : "2014-03-10 05:27:10 +0000",
  "in_reply_to_screen_name" : "xc",
  "in_reply_to_user_id_str" : "26233",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee LeFever",
      "screen_name" : "leelefever",
      "indices" : [ 0, 11 ],
      "id_str" : "12279",
      "id" : 12279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "innovation",
      "indices" : [ 89, 100 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442888936424103936",
  "geo" : { },
  "id_str" : "442892985772941313",
  "in_reply_to_user_id" : 12279,
  "text" : "@leelefever I think it was a good idea to move to a cosmic year instead of a cosmic day. #innovation",
  "id" : 442892985772941313,
  "in_reply_to_status_id" : 442888936424103936,
  "created_at" : "2014-03-10 05:21:31 +0000",
  "in_reply_to_screen_name" : "leelefever",
  "in_reply_to_user_id_str" : "12279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McAllister",
      "screen_name" : "ianmcall",
      "indices" : [ 0, 9 ],
      "id_str" : "2035631",
      "id" : 2035631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442887249458245632",
  "geo" : { },
  "id_str" : "442892113844269057",
  "in_reply_to_user_id" : 2035631,
  "text" : "@ianmcall Interesting ideas but it would also significantly complicate the product.",
  "id" : 442892113844269057,
  "in_reply_to_status_id" : 442887249458245632,
  "created_at" : "2014-03-10 05:18:03 +0000",
  "in_reply_to_screen_name" : "ianmcall",
  "in_reply_to_user_id_str" : "2035631",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 3, 15 ],
      "id_str" : "30801469",
      "id" : 30801469
    }, {
      "name" : "GiveWell",
      "screen_name" : "GiveWell",
      "indices" : [ 31, 40 ],
      "id_str" : "34650660",
      "id" : 34650660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442890518507180032",
  "text" : "RT @nickcrocker: I love this - @GiveWell - analysis of the where your giving will generate the most return.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GiveWell",
        "screen_name" : "GiveWell",
        "indices" : [ 14, 23 ],
        "id_str" : "34650660",
        "id" : 34650660
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "442794132897939456",
    "text" : "I love this - @GiveWell - analysis of the where your giving will generate the most return.",
    "id" : 442794132897939456,
    "created_at" : "2014-03-09 22:48:42 +0000",
    "user" : {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "protected" : false,
      "id_str" : "30801469",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460845803498516480\/1m9QG5iU_normal.jpeg",
      "id" : 30801469,
      "verified" : false
    }
  },
  "id" : 442890518507180032,
  "created_at" : "2014-03-10 05:11:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cosmos",
      "indices" : [ 27, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442890056710107136",
  "text" : "Loved the first episode of #Cosmos but curious how depiction of the church + closed-mindedness got through FOX's fair and balanced filter.",
  "id" : 442890056710107136,
  "created_at" : "2014-03-10 05:09:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaby Pe\u00F1a",
      "screen_name" : "gpena",
      "indices" : [ 0, 6 ],
      "id_str" : "133583134",
      "id" : 133583134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442887465301323776",
  "geo" : { },
  "id_str" : "442888305604960256",
  "in_reply_to_user_id" : 133583134,
  "text" : "@gpena An amazing story. I saw Carl Sagan speak at UW once and even that left a lasting impression.",
  "id" : 442888305604960256,
  "in_reply_to_status_id" : 442887465301323776,
  "created_at" : "2014-03-10 05:02:55 +0000",
  "in_reply_to_screen_name" : "gpena",
  "in_reply_to_user_id_str" : "133583134",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cosmos",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442885779841232896",
  "text" : "Appreciating the numerous nods to the first #Cosmos.",
  "id" : 442885779841232896,
  "created_at" : "2014-03-10 04:52:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiffany Dohzen",
      "screen_name" : "tdohz",
      "indices" : [ 0, 6 ],
      "id_str" : "101424163",
      "id" : 101424163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442873407684632578",
  "geo" : { },
  "id_str" : "442876220590419969",
  "in_reply_to_user_id" : 101424163,
  "text" : "@tdohz Really? It looks a bit like one of those trackballs. Would've guessed him to design something closer to a magic trackpad.",
  "id" : 442876220590419969,
  "in_reply_to_status_id" : 442873407684632578,
  "created_at" : "2014-03-10 04:14:53 +0000",
  "in_reply_to_screen_name" : "tdohz",
  "in_reply_to_user_id_str" : "101424163",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cosmos",
      "indices" : [ 8, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442872754736332801",
  "text" : "Turn on #Cosmos now!",
  "id" : 442872754736332801,
  "created_at" : "2014-03-10 04:01:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 15, 31 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/442867770087067649\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/ugrycLqojP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiVh48FCAAEjKW1.jpg",
      "id_str" : "442867769193660417",
      "id" : 442867769193660417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiVh48FCAAEjKW1.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ugrycLqojP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442867770087067649",
  "text" : "8:36pm Thanks, @ameliagreenhall. http:\/\/t.co\/ugrycLqojP",
  "id" : 442867770087067649,
  "created_at" : "2014-03-10 03:41:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vishal Chandra",
      "screen_name" : "vishalchandra",
      "indices" : [ 0, 14 ],
      "id_str" : "22951943",
      "id" : 22951943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442622515547230208",
  "geo" : { },
  "id_str" : "442705033847504897",
  "in_reply_to_user_id" : 22951943,
  "text" : "@vishalchandra 5\/5, 4\/4, 3\/5",
  "id" : 442705033847504897,
  "in_reply_to_status_id" : 442622515547230208,
  "created_at" : "2014-03-09 16:54:39 +0000",
  "in_reply_to_screen_name" : "vishalchandra",
  "in_reply_to_user_id_str" : "22951943",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 3, 15 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/brainpicker\/status\/442702107863306242\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/BTVT3ZcL1h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiTLOLLCEAEc5Rf.jpg",
      "id_str" : "442702107766820865",
      "id" : 442702107766820865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiTLOLLCEAEc5Rf.jpg",
      "sizes" : [ {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/BTVT3ZcL1h"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Zi39tlSDWB",
      "expanded_url" : "http:\/\/j.mp\/O9plWj",
      "display_url" : "j.mp\/O9plWj"
    } ]
  },
  "geo" : { },
  "id_str" : "442702808047841280",
  "text" : "RT @brainpicker: Stewart Brand's reading list of 76 books to sustain and rebuild humanity http:\/\/t.co\/Zi39tlSDWB http:\/\/t.co\/BTVT3ZcL1h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/brainpicker\/status\/442702107863306242\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/BTVT3ZcL1h",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiTLOLLCEAEc5Rf.jpg",
        "id_str" : "442702107766820865",
        "id" : 442702107766820865,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiTLOLLCEAEc5Rf.jpg",
        "sizes" : [ {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/BTVT3ZcL1h"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/Zi39tlSDWB",
        "expanded_url" : "http:\/\/j.mp\/O9plWj",
        "display_url" : "j.mp\/O9plWj"
      } ]
    },
    "geo" : { },
    "id_str" : "442702107863306242",
    "text" : "Stewart Brand's reading list of 76 books to sustain and rebuild humanity http:\/\/t.co\/Zi39tlSDWB http:\/\/t.co\/BTVT3ZcL1h",
    "id" : 442702107863306242,
    "created_at" : "2014-03-09 16:43:02 +0000",
    "user" : {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "protected" : false,
      "id_str" : "9207632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/125575833\/twitter_normal.jpg",
      "id" : 9207632,
      "verified" : true
    }
  },
  "id" : 442702808047841280,
  "created_at" : "2014-03-09 16:45:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 17, 27 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442700097898299393",
  "text" : "Device-following @neiltyson in anticipation of tonight's premiere of Cosmos. So excited.",
  "id" : 442700097898299393,
  "created_at" : "2014-03-09 16:35:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dan cumberland",
      "screen_name" : "dancumberland",
      "indices" : [ 0, 14 ],
      "id_str" : "16189195",
      "id" : 16189195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442546906770599936",
  "geo" : { },
  "id_str" : "442587143903256576",
  "in_reply_to_user_id" : 16189195,
  "text" : "@dancumberland Thank you! I honestly had no idea others would find it so useful.",
  "id" : 442587143903256576,
  "in_reply_to_status_id" : 442546906770599936,
  "created_at" : "2014-03-09 09:06:12 +0000",
  "in_reply_to_screen_name" : "dancumberland",
  "in_reply_to_user_id_str" : "16189195",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/442544079730003968\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/WEK0PfBSsX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiQ7frxCIAAq73H.jpg",
      "id_str" : "442544078899519488",
      "id" : 442544078899519488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiQ7frxCIAAq73H.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/WEK0PfBSsX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442544079730003968",
  "text" : "8:36pm Dinner with Joi and new friends at Penrose! This is in the bathroom. http:\/\/t.co\/WEK0PfBSsX",
  "id" : 442544079730003968,
  "created_at" : "2014-03-09 06:15:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tina Thornes",
      "screen_name" : "TinaThornes",
      "indices" : [ 0, 12 ],
      "id_str" : "2379671588",
      "id" : 2379671588
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 13, 23 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442506062722109440",
  "geo" : { },
  "id_str" : "442506342570270720",
  "in_reply_to_user_id" : 2185,
  "text" : "@tinathornes @kellianne I'd also find as many friends\/family to follow too, it's similar to FB but people talk about different things.",
  "id" : 442506342570270720,
  "in_reply_to_status_id" : 442506062722109440,
  "created_at" : "2014-03-09 03:45:08 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tina Thornes",
      "screen_name" : "TinaThornes",
      "indices" : [ 0, 12 ],
      "id_str" : "2379671588",
      "id" : 2379671588
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 13, 23 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442502128264019969",
  "geo" : { },
  "id_str" : "442506062722109440",
  "in_reply_to_user_id" : 2379671588,
  "text" : "@tinathornes @kellianne One way to get started is to choose an area of interest and follow some people that represent that area of interest.",
  "id" : 442506062722109440,
  "in_reply_to_status_id" : 442502128264019969,
  "created_at" : "2014-03-09 03:44:01 +0000",
  "in_reply_to_screen_name" : "TinaThornes",
  "in_reply_to_user_id_str" : "2379671588",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Tina Thornes",
      "screen_name" : "TinaThornes",
      "indices" : [ 11, 23 ],
      "id_str" : "2379671588",
      "id" : 2379671588
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/442500735637270529\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/mNDz3uRGtc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiQUExkCMAA6akU.jpg",
      "id_str" : "442500735645659136",
      "id" : 442500735645659136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiQUExkCMAA6akU.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 819,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/mNDz3uRGtc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442498153544040449",
  "geo" : { },
  "id_str" : "442500735637270529",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne @TinaThornes Hi Tina! To help you get adjusted to this crazy new land, here\u2019s a picture of a cat. http:\/\/t.co\/mNDz3uRGtc",
  "id" : 442500735637270529,
  "in_reply_to_status_id" : 442498153544040449,
  "created_at" : "2014-03-09 03:22:51 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hanna",
      "screen_name" : "princessthot",
      "indices" : [ 17, 30 ],
      "id_str" : "25715564",
      "id" : 25715564
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/princessthot\/status\/442424307763785729\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/XFa9fD1Brr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiPOkFjCMAE8ooD.jpg",
      "id_str" : "442424307772174337",
      "id" : 442424307772174337,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiPOkFjCMAE8ooD.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XFa9fD1Brr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442493295025868800",
  "text" : "Tune in \u2014&gt; RT @princessthot: First 10k people to retweet get 1k each, fuck my dad and his manufacturing company. http:\/\/t.co\/XFa9fD1Brr",
  "id" : 442493295025868800,
  "created_at" : "2014-03-09 02:53:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 0, 5 ],
      "id_str" : "541",
      "id" : 541
    }, {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 6, 15 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 16, 26 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 27, 38 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442455998578442240",
  "geo" : { },
  "id_str" : "442464555738738688",
  "in_reply_to_user_id" : 541,
  "text" : "@lane @spangley @kellianne @nikobenson Come join us!",
  "id" : 442464555738738688,
  "in_reply_to_status_id" : 442455998578442240,
  "created_at" : "2014-03-09 00:59:05 +0000",
  "in_reply_to_screen_name" : "lane",
  "in_reply_to_user_id_str" : "541",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 10, 20 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lildude",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442439040617295872",
  "geo" : { },
  "id_str" : "442450102150369280",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley @kellianne It was great seeing the full Berman family! Hope #lildude got some sleep on the way home.",
  "id" : 442450102150369280,
  "in_reply_to_status_id" : 442439040617295872,
  "created_at" : "2014-03-09 00:01:39 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara M. Watson",
      "screen_name" : "smwat",
      "indices" : [ 0, 6 ],
      "id_str" : "20609587",
      "id" : 20609587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442436723600277504",
  "geo" : { },
  "id_str" : "442440761980620801",
  "in_reply_to_user_id" : 20609587,
  "text" : "@smwat That's awesome!",
  "id" : 442440761980620801,
  "in_reply_to_status_id" : 442436723600277504,
  "created_at" : "2014-03-08 23:24:32 +0000",
  "in_reply_to_screen_name" : "smwat",
  "in_reply_to_user_id_str" : "20609587",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Douglas",
      "screen_name" : "mikedouglas",
      "indices" : [ 0, 12 ],
      "id_str" : "713133",
      "id" : 713133
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442363470789349377",
  "geo" : { },
  "id_str" : "442363849228840960",
  "in_reply_to_user_id" : 713133,
  "text" : "@mikedouglas Ah, yes! I read this a while ago and completely forgot about it. This is exactly what I was looking for.",
  "id" : 442363849228840960,
  "in_reply_to_status_id" : 442363470789349377,
  "created_at" : "2014-03-08 18:18:55 +0000",
  "in_reply_to_screen_name" : "mikedouglas",
  "in_reply_to_user_id_str" : "713133",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 0, 11 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442361428205244416",
  "geo" : { },
  "id_str" : "442363388518092800",
  "in_reply_to_user_id" : 13919072,
  "text" : "@robinsloan Awesome! I will play around with this. I'm convinced that logarithms are closer to how the universe thinks of numbers.",
  "id" : 442363388518092800,
  "in_reply_to_status_id" : 442361428205244416,
  "created_at" : "2014-03-08 18:17:05 +0000",
  "in_reply_to_screen_name" : "robinsloan",
  "in_reply_to_user_id_str" : "13919072",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cole Reinke",
      "screen_name" : "colereinke",
      "indices" : [ 0, 11 ],
      "id_str" : "15886171",
      "id" : 15886171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442356945878413312",
  "geo" : { },
  "id_str" : "442357446162403329",
  "in_reply_to_user_id" : 15886171,
  "text" : "@colereinke As a cron.",
  "id" : 442357446162403329,
  "in_reply_to_status_id" : 442356945878413312,
  "created_at" : "2014-03-08 17:53:28 +0000",
  "in_reply_to_screen_name" : "colereinke",
  "in_reply_to_user_id_str" : "15886171",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "benji shine",
      "screen_name" : "bshine",
      "indices" : [ 0, 7 ],
      "id_str" : "7305682",
      "id" : 7305682
    }, {
      "name" : "Lindsay Schauer",
      "screen_name" : "SchauerTime",
      "indices" : [ 8, 20 ],
      "id_str" : "19169495",
      "id" : 19169495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442352936346079233",
  "geo" : { },
  "id_str" : "442356504197206016",
  "in_reply_to_user_id" : 7305682,
  "text" : "@bshine @SchauerTime I'll tell you for a dollar.",
  "id" : 442356504197206016,
  "in_reply_to_status_id" : 442352936346079233,
  "created_at" : "2014-03-08 17:49:43 +0000",
  "in_reply_to_screen_name" : "bshine",
  "in_reply_to_user_id_str" : "7305682",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Silverman",
      "screen_name" : "SarahKSilverman",
      "indices" : [ 3, 19 ],
      "id_str" : "30364057",
      "id" : 30364057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442353406703714304",
  "text" : "RT @SarahKSilverman: I feel bad for the world's smallest violinist.  Everyone thinks he's being sarcastic all the time",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.whosay.com\" rel=\"nofollow\"\u003EWhoSay\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "442346597964595200",
    "text" : "I feel bad for the world's smallest violinist.  Everyone thinks he's being sarcastic all the time",
    "id" : 442346597964595200,
    "created_at" : "2014-03-08 17:10:22 +0000",
    "user" : {
      "name" : "Sarah Silverman",
      "screen_name" : "SarahKSilverman",
      "protected" : false,
      "id_str" : "30364057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/418462796418789376\/4A1pDPgN_normal.jpeg",
      "id" : 30364057,
      "verified" : true
    }
  },
  "id" : 442353406703714304,
  "created_at" : "2014-03-08 17:37:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 0, 11 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442351813082112000",
  "geo" : { },
  "id_str" : "442352569508036608",
  "in_reply_to_user_id" : 2185,
  "text" : "@robinsloan 2\/2 for a rare condition, say a visitor in town, shouldn't forever  trump a common condition like date night that scores 11\/12.",
  "id" : 442352569508036608,
  "in_reply_to_status_id" : 442351813082112000,
  "created_at" : "2014-03-08 17:34:05 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 0, 11 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442349050931601408",
  "geo" : { },
  "id_str" : "442351813082112000",
  "in_reply_to_user_id" : 13919072,
  "text" : "@robinsloan Ha. I'm tracking conditions (place, time, activity, etc) and whether I'm experiencing quality time during those conditions.",
  "id" : 442351813082112000,
  "in_reply_to_status_id" : 442349050931601408,
  "created_at" : "2014-03-08 17:31:05 +0000",
  "in_reply_to_screen_name" : "robinsloan",
  "in_reply_to_user_id_str" : "13919072",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442345757958348800",
  "text" : "Is there a good established way to sort numbers in a way that 4\/5 comes before 3\/5 but 11\/12 comes before 4\/4 by giving weight to the denom?",
  "id" : 442345757958348800,
  "created_at" : "2014-03-08 17:07:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cole Reinke",
      "screen_name" : "colereinke",
      "indices" : [ 0, 11 ],
      "id_str" : "15886171",
      "id" : 15886171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442342781487681536",
  "geo" : { },
  "id_str" : "442342990967623682",
  "in_reply_to_user_id" : 15886171,
  "text" : "@colereinke Locally on my home iMac.",
  "id" : 442342990967623682,
  "in_reply_to_status_id" : 442342781487681536,
  "created_at" : "2014-03-08 16:56:02 +0000",
  "in_reply_to_screen_name" : "colereinke",
  "in_reply_to_user_id_str" : "15886171",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cole Reinke",
      "screen_name" : "colereinke",
      "indices" : [ 0, 11 ],
      "id_str" : "15886171",
      "id" : 15886171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/lbXUu4iqEx",
      "expanded_url" : "http:\/\/wayoftheduck.com\/diy-horse-ebooks",
      "display_url" : "wayoftheduck.com\/diy-horse-eboo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "442340689070653440",
  "geo" : { },
  "id_str" : "442341232304353280",
  "in_reply_to_user_id" : 15886171,
  "text" : "@colereinke I wrote up some instructions here: http:\/\/t.co\/lbXUu4iqEx",
  "id" : 442341232304353280,
  "in_reply_to_status_id" : 442340689070653440,
  "created_at" : "2014-03-08 16:49:02 +0000",
  "in_reply_to_screen_name" : "colereinke",
  "in_reply_to_user_id_str" : "15886171",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "indices" : [ 10, 23 ],
      "id_str" : "1186",
      "id" : 1186
    }, {
      "name" : "Secret",
      "screen_name" : "getsecret",
      "indices" : [ 24, 34 ],
      "id_str" : "2244765331",
      "id" : 2244765331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442080252136005632",
  "geo" : { },
  "id_str" : "442134594913984512",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert @chrismessina @getsecret do a Twitter search for \"near:austin,tx secret.ly\".",
  "id" : 442134594913984512,
  "in_reply_to_status_id" : 442080252136005632,
  "created_at" : "2014-03-08 03:07:56 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Reich",
      "screen_name" : "ohheygreat",
      "indices" : [ 3, 14 ],
      "id_str" : "9670142",
      "id" : 9670142
    }, {
      "name" : "Choire",
      "screen_name" : "Choire",
      "indices" : [ 87, 94 ],
      "id_str" : "8525402",
      "id" : 8525402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/wUFEZ3Rroh",
      "expanded_url" : "http:\/\/www.theawl.com\/2014\/03\/how-do-we-know-who-people-are",
      "display_url" : "theawl.com\/2014\/03\/how-do\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "442071368058679296",
  "text" : "RT @ohheygreat: \"I told him that his app was disgusting and a sign of the end times\" - @choire on identity and reputation. http:\/\/t.co\/wUFE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Choire",
        "screen_name" : "Choire",
        "indices" : [ 71, 78 ],
        "id_str" : "8525402",
        "id" : 8525402
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/wUFEZ3Rroh",
        "expanded_url" : "http:\/\/www.theawl.com\/2014\/03\/how-do-we-know-who-people-are",
        "display_url" : "theawl.com\/2014\/03\/how-do\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "442034416177524736",
    "text" : "\"I told him that his app was disgusting and a sign of the end times\" - @choire on identity and reputation. http:\/\/t.co\/wUFEZ3Rroh",
    "id" : 442034416177524736,
    "created_at" : "2014-03-07 20:29:52 +0000",
    "user" : {
      "name" : "Leah Reich",
      "screen_name" : "ohheygreat",
      "protected" : false,
      "id_str" : "9670142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461923328165298176\/wFNcIXOX_normal.jpeg",
      "id" : 9670142,
      "verified" : false
    }
  },
  "id" : 442071368058679296,
  "created_at" : "2014-03-07 22:56:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/OludF1mqFu",
      "expanded_url" : "http:\/\/flic.kr\/p\/kMm3ap",
      "display_url" : "flic.kr\/p\/kMm3ap"
    } ]
  },
  "geo" : { },
  "id_str" : "441820799734128640",
  "text" : "8:36pm Tea and House of Cards http:\/\/t.co\/OludF1mqFu",
  "id" : 441820799734128640,
  "created_at" : "2014-03-07 06:21:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mollie Vandor",
      "screen_name" : "mollie",
      "indices" : [ 0, 7 ],
      "id_str" : "17852401",
      "id" : 17852401
    }, {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 8, 15 ],
      "id_str" : "1530531",
      "id" : 1530531
    }, {
      "name" : "Sung Hu Kim",
      "screen_name" : "sunghu",
      "indices" : [ 16, 23 ],
      "id_str" : "11407672",
      "id" : 11407672
    }, {
      "name" : "Arundhati Singh",
      "screen_name" : "arundhati",
      "indices" : [ 24, 34 ],
      "id_str" : "130390598",
      "id" : 130390598
    }, {
      "name" : "Rafael Dahis",
      "screen_name" : "rafaeldahis",
      "indices" : [ 35, 47 ],
      "id_str" : "17442726",
      "id" : 17442726
    }, {
      "name" : "Austin Lin",
      "screen_name" : "austinlin",
      "indices" : [ 48, 58 ],
      "id_str" : "14349189",
      "id" : 14349189
    }, {
      "name" : "derek dukes",
      "screen_name" : "ddukes",
      "indices" : [ 59, 66 ],
      "id_str" : "978",
      "id" : 978
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "productsalonfistbump",
      "indices" : [ 88, 109 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441777540076544000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8295751615, -122.266863892 ]
  },
  "id_str" : "441779831936532481",
  "in_reply_to_user_id" : 17852401,
  "text" : "@mollie @miradu @sunghu @arundhati @rafaeldahis @austinlin @ddukes I feel the same way! #productsalonfistbump",
  "id" : 441779831936532481,
  "in_reply_to_status_id" : 441777540076544000,
  "created_at" : "2014-03-07 03:38:14 +0000",
  "in_reply_to_screen_name" : "mollie",
  "in_reply_to_user_id_str" : "17852401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FiveThirtyEight",
      "screen_name" : "FiveThirtyEight",
      "indices" : [ 3, 19 ],
      "id_str" : "2303751216",
      "id" : 2303751216
    }, {
      "name" : "FiveThirtyEight",
      "screen_name" : "FiveThirtyEight",
      "indices" : [ 46, 62 ],
      "id_str" : "2303751216",
      "id" : 2303751216
    }, {
      "name" : "SXSW",
      "screen_name" : "sxsw",
      "indices" : [ 126, 131 ],
      "id_str" : "784304",
      "id" : 784304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441731227263848448",
  "text" : "RT @FiveThirtyEight: This is the new home for @FiveThirtyEight on Twitter. We'll have a big announcement to make this weekend @sxsw.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FiveThirtyEight",
        "screen_name" : "FiveThirtyEight",
        "indices" : [ 25, 41 ],
        "id_str" : "2303751216",
        "id" : 2303751216
      }, {
        "name" : "SXSW",
        "screen_name" : "sxsw",
        "indices" : [ 105, 110 ],
        "id_str" : "784304",
        "id" : 784304
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "441728849731006464",
    "text" : "This is the new home for @FiveThirtyEight on Twitter. We'll have a big announcement to make this weekend @sxsw.",
    "id" : 441728849731006464,
    "created_at" : "2014-03-07 00:15:39 +0000",
    "user" : {
      "name" : "FiveThirtyEight",
      "screen_name" : "FiveThirtyEight",
      "protected" : false,
      "id_str" : "2303751216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442370574040301568\/j673s9Ue_normal.jpeg",
      "id" : 2303751216,
      "verified" : true
    }
  },
  "id" : 441731227263848448,
  "created_at" : "2014-03-07 00:25:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "butttweet",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441633970539601920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769789165, -122.4168558753 ]
  },
  "id_str" : "441634289818415104",
  "in_reply_to_user_id" : 2185,
  "text" : "#butttweet",
  "id" : 441634289818415104,
  "in_reply_to_status_id" : 441633970539601920,
  "created_at" : "2014-03-06 17:59:54 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763281103, -122.4165990104 ]
  },
  "id_str" : "441633970539601920",
  "text" : "E",
  "id" : 441633970539601920,
  "created_at" : "2014-03-06 17:58:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441632029499613184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762767777, -122.4167707545 ]
  },
  "id_str" : "441632337315381248",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus We missed you! Let's schedule the next one now since we know it takes a while to find a date.",
  "id" : 441632337315381248,
  "in_reply_to_status_id" : 441632029499613184,
  "created_at" : "2014-03-06 17:52:09 +0000",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Ebaugh",
      "screen_name" : "ke",
      "indices" : [ 0, 3 ],
      "id_str" : "22921523",
      "id" : 22921523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441626581564268544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7844540401, -122.4078486587 ]
  },
  "id_str" : "441628661653835776",
  "in_reply_to_user_id" : 22921523,
  "text" : "@ke Yeah. Wasn't sure if that was actually a term anyone uses. Guess not.",
  "id" : 441628661653835776,
  "in_reply_to_status_id" : 441626581564268544,
  "created_at" : "2014-03-06 17:37:32 +0000",
  "in_reply_to_screen_name" : "ke",
  "in_reply_to_user_id_str" : "22921523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah McGrath Goodman",
      "screen_name" : "truth_eater",
      "indices" : [ 29, 41 ],
      "id_str" : "116028519",
      "id" : 116028519
    }, {
      "name" : "Newsweek",
      "screen_name" : "Newsweek",
      "indices" : [ 82, 91 ],
      "id_str" : "2884771",
      "id" : 2884771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441585040502558720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.853832492, -122.2707386923 ]
  },
  "id_str" : "441622323569758208",
  "in_reply_to_user_id" : 116028519,
  "text" : "Device-follow for the day RT @truth_eater: For those who have questions for me or @Newsweek about the piece, I'll do my best to answer them.",
  "id" : 441622323569758208,
  "in_reply_to_status_id" : 441585040502558720,
  "created_at" : "2014-03-06 17:12:21 +0000",
  "in_reply_to_screen_name" : "truth_eater",
  "in_reply_to_user_id_str" : "116028519",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    }, {
      "name" : "Noah Pepper",
      "screen_name" : "noahmp",
      "indices" : [ 10, 17 ],
      "id_str" : "20219699",
      "id" : 20219699
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "punintended",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441606315236786176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596527097, -122.2757443039 ]
  },
  "id_str" : "441608713774702592",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover @noahmp I haven't. But seems wrong to copy them. The tech is simple but the idea is really novel. #punintended",
  "id" : 441608713774702592,
  "in_reply_to_status_id" : 441606315236786176,
  "created_at" : "2014-03-06 16:18:16 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Pepper",
      "screen_name" : "noahmp",
      "indices" : [ 131, 138 ],
      "id_str" : "20219699",
      "id" : 20219699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/6e6W5hZIwr",
      "expanded_url" : "http:\/\/elitedaily.com\/news\/technology\/this-insane-new-app-will-allow-you-to-read-novels-in-under-90-minutes\/",
      "display_url" : "elitedaily.com\/news\/technolog\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596821714, -122.275544055 ]
  },
  "id_str" : "441606036726636544",
  "text" : "Read at 500 words\/minute with an app that presents words in a new way. Demo actually seems believable. http:\/\/t.co\/6e6W5hZIwr \/via @noahmp",
  "id" : 441606036726636544,
  "created_at" : "2014-03-06 16:07:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfie",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/LS9PAqH9C6",
      "expanded_url" : "http:\/\/flic.kr\/p\/kKCW7P",
      "display_url" : "flic.kr\/p\/kKCW7P"
    } ]
  },
  "geo" : { },
  "id_str" : "441472229478760448",
  "text" : "8:36pm Missed my chance to take a picture of all the quantified self people I was drinking with. Oh well. #selfie http:\/\/t.co\/LS9PAqH9C6",
  "id" : 441472229478760448,
  "created_at" : "2014-03-06 07:15:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beau Gunderson",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Sina Khanifar",
      "screen_name" : "sinak",
      "indices" : [ 15, 21 ],
      "id_str" : "3573701",
      "id" : 3573701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441357984283643904",
  "geo" : { },
  "id_str" : "441359583013904384",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @sinak Woah this is interesting! Do you know if \"rs4994\" has to be an exact match or just a prefix match?",
  "id" : 441359583013904384,
  "in_reply_to_status_id" : 441357984283643904,
  "created_at" : "2014-03-05 23:48:19 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ioan Mitrea",
      "screen_name" : "awarenesss",
      "indices" : [ 0, 11 ],
      "id_str" : "18603224",
      "id" : 18603224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441349097706893312",
  "geo" : { },
  "id_str" : "441349181668470785",
  "in_reply_to_user_id" : 18603224,
  "text" : "@awarenesss Not that I'm aware of.",
  "id" : 441349181668470785,
  "in_reply_to_status_id" : 441349097706893312,
  "created_at" : "2014-03-05 23:06:59 +0000",
  "in_reply_to_screen_name" : "awarenesss",
  "in_reply_to_user_id_str" : "18603224",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ioan Mitrea",
      "screen_name" : "awarenesss",
      "indices" : [ 0, 11 ],
      "id_str" : "18603224",
      "id" : 18603224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441348369026277376",
  "geo" : { },
  "id_str" : "441348552816467969",
  "in_reply_to_user_id" : 18603224,
  "text" : "@awarenesss Ah. In that case, sure, charge for it! You still have to convince them to pay, and charging too much will reduce usage.",
  "id" : 441348552816467969,
  "in_reply_to_status_id" : 441348369026277376,
  "created_at" : "2014-03-05 23:04:29 +0000",
  "in_reply_to_screen_name" : "awarenesss",
  "in_reply_to_user_id_str" : "18603224",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ioan Mitrea",
      "screen_name" : "awarenesss",
      "indices" : [ 0, 11 ],
      "id_str" : "18603224",
      "id" : 18603224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441347245460295681",
  "geo" : { },
  "id_str" : "441347619147612160",
  "in_reply_to_user_id" : 18603224,
  "text" : "@awarenesss Depends on how easy you make it for them to cancel. Do you remind them? Auto-cancel?",
  "id" : 441347619147612160,
  "in_reply_to_status_id" : 441347245460295681,
  "created_at" : "2014-03-05 23:00:46 +0000",
  "in_reply_to_screen_name" : "awarenesss",
  "in_reply_to_user_id_str" : "18603224",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 10, 26 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Zack Shapiro",
      "screen_name" : "ZackShapiro",
      "indices" : [ 27, 39 ],
      "id_str" : "15999465",
      "id" : 15999465
    }, {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 40, 52 ],
      "id_str" : "30801469",
      "id" : 30801469
    }, {
      "name" : "Beau Gunderson",
      "screen_name" : "beaugunderson",
      "indices" : [ 53, 67 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 68, 75 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441339381953994752",
  "geo" : { },
  "id_str" : "441342493049626624",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @tonystubblebine @zackshapiro @nickcrocker @beaugunderson @cwhogg Me too!",
  "id" : 441342493049626624,
  "in_reply_to_status_id" : 441339381953994752,
  "created_at" : "2014-03-05 22:40:24 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 8, 12 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441314363857584128",
  "geo" : { },
  "id_str" : "441316516034658304",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon @ian Nexupuses.",
  "id" : 441316516034658304,
  "in_reply_to_status_id" : 441314363857584128,
  "created_at" : "2014-03-05 20:57:11 +0000",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 8, 12 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441313203625013248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763841472, -122.4174367748 ]
  },
  "id_str" : "441313506743164928",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon @ian Yeah it wouldn't work to have a shared secret iPhone. No iPads either?",
  "id" : 441313506743164928,
  "in_reply_to_status_id" : 441313203625013248,
  "created_at" : "2014-03-05 20:45:13 +0000",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441275690986381312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776338175, -122.4174049669 ]
  },
  "id_str" : "441313033847988224",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon Maybe one of them should be that you have a secret iPhone.",
  "id" : 441313033847988224,
  "in_reply_to_status_id" : 441275690986381312,
  "created_at" : "2014-03-05 20:43:21 +0000",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 0, 8 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441276051327426561",
  "geo" : { },
  "id_str" : "441276407650344960",
  "in_reply_to_user_id" : 22891211,
  "text" : "@chanian Do you own some? Planning to buy?",
  "id" : 441276407650344960,
  "in_reply_to_status_id" : 441276051327426561,
  "created_at" : "2014-03-05 18:17:48 +0000",
  "in_reply_to_screen_name" : "chanian",
  "in_reply_to_user_id_str" : "22891211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441239257697361920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596756235, -122.2754566838 ]
  },
  "id_str" : "441240787313905664",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Yeah not much of an online presence. I wonder who provided the details about him for the Twitter book... that was pretty bad.",
  "id" : 441240787313905664,
  "in_reply_to_status_id" : 441239257697361920,
  "created_at" : "2014-03-05 15:56:16 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441225254934175744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597303199, -122.2755557665 ]
  },
  "id_str" : "441238949416013825",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Have you met him?",
  "id" : 441238949416013825,
  "in_reply_to_status_id" : 441225254934175744,
  "created_at" : "2014-03-05 15:48:58 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 0, 7 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441102771605868544",
  "geo" : { },
  "id_str" : "441102952208416769",
  "in_reply_to_user_id" : 15727738,
  "text" : "@cwhogg So far not many takers. Might have to up the follower limit\u2026 or target in a different way. Feel free to borrow the idea!",
  "id" : 441102952208416769,
  "in_reply_to_status_id" : 441102771605868544,
  "created_at" : "2014-03-05 06:48:33 +0000",
  "in_reply_to_screen_name" : "cwhogg",
  "in_reply_to_user_id_str" : "15727738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill S.",
      "screen_name" : "outseide",
      "indices" : [ 0, 9 ],
      "id_str" : "143694663",
      "id" : 143694663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441100323147358209",
  "geo" : { },
  "id_str" : "441101108660826112",
  "in_reply_to_user_id" : 143694663,
  "text" : "@outseide Yeah, it's annoying because  it assumes your options, and your luck. It's a very blind form of advice to give.",
  "id" : 441101108660826112,
  "in_reply_to_status_id" : 441100323147358209,
  "created_at" : "2014-03-05 06:41:14 +0000",
  "in_reply_to_screen_name" : "outseide",
  "in_reply_to_user_id_str" : "143694663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441097245442584576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597090208, -122.2755536061 ]
  },
  "id_str" : "441098826196070400",
  "in_reply_to_user_id" : 2185,
  "text" : "Telling someone to never give up is equal to telling someone to give up *everything else*. Then, when left with nothing else, to die.",
  "id" : 441098826196070400,
  "in_reply_to_status_id" : 441097245442584576,
  "created_at" : "2014-03-05 06:32:10 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441096998658134016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596883165, -122.2755462587 ]
  },
  "id_str" : "441097245442584576",
  "in_reply_to_user_id" : 2185,
  "text" : "I remember someone telling me that that was also the key to a successful marriage. He divorced a few years later.",
  "id" : 441097245442584576,
  "in_reply_to_status_id" : 441096998658134016,
  "created_at" : "2014-03-05 06:25:53 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597139707, -122.2754792311 ]
  },
  "id_str" : "441096998658134016",
  "text" : "Apparently the key to being a great entrepreneur is to never give up. That's great for people with options left.",
  "id" : 441096998658134016,
  "created_at" : "2014-03-05 06:24:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597137193, -122.2754781415 ]
  },
  "id_str" : "441096495446499328",
  "text" : "I need a drone plan.",
  "id" : 441096495446499328,
  "created_at" : "2014-03-05 06:22:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 3, 12 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441076515816472576",
  "text" : "RT @arainert: \"When you're gonna eat shit, don't nibble.\" is one of the most concise, versatile and powerful pieces of life advice. I love \u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "441043129525743616",
    "text" : "\"When you're gonna eat shit, don't nibble.\" is one of the most concise, versatile and powerful pieces of life advice. I love it.",
    "id" : 441043129525743616,
    "created_at" : "2014-03-05 02:50:50 +0000",
    "user" : {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "protected" : false,
      "id_str" : "7482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444089158274154496\/ZePPNQzQ_normal.jpeg",
      "id" : 7482,
      "verified" : false
    }
  },
  "id" : 441076515816472576,
  "created_at" : "2014-03-05 05:03:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/iVNYappa3K",
      "expanded_url" : "http:\/\/flic.kr\/p\/kHD5Ck",
      "display_url" : "flic.kr\/p\/kHD5Ck"
    } ]
  },
  "geo" : { },
  "id_str" : "441070577647112192",
  "text" : "8:36pm Walking home from sushi http:\/\/t.co\/iVNYappa3K",
  "id" : 441070577647112192,
  "created_at" : "2014-03-05 04:39:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodguy",
      "indices" : [ 117, 125 ]
    }, {
      "text" : "badguy",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441037261337939968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7991791116, -122.2792703659 ]
  },
  "id_str" : "441043046528856064",
  "in_reply_to_user_id" : 2185,
  "text" : "Bill Campbell (CEO coach) makes his appearance in ch 2. Was also in In The Plex. And infamously in Hatching Twitter. #goodguy or #badguy?",
  "id" : 441043046528856064,
  "in_reply_to_status_id" : 441037261337939968,
  "created_at" : "2014-03-05 02:50:31 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441038260631269377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7824712454, -122.4055162187 ]
  },
  "id_str" : "441038692497358848",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine Agreed. A mind is just something brains do. Computers should be able to \"mind\" one day too.",
  "id" : 441038692497358848,
  "in_reply_to_status_id" : 441038260631269377,
  "created_at" : "2014-03-05 02:33:13 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441037579933462528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7801433876, -122.4134870764 ]
  },
  "id_str" : "441037835403927552",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine Cool! Was just thinking I should've argued the point further.",
  "id" : 441037835403927552,
  "in_reply_to_status_id" : 441037579933462528,
  "created_at" : "2014-03-05 02:29:48 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bhorowitz",
      "screen_name" : "bhorowitz",
      "indices" : [ 8, 18 ],
      "id_str" : "16242081",
      "id" : 16242081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.779840867, -122.4136261199 ]
  },
  "id_str" : "441037261337939968",
  "text" : "Reading @bhorowitz's new book \"The Hard Thing About Hard Things\" and liking it. Who else is in?",
  "id" : 441037261337939968,
  "created_at" : "2014-03-05 02:27:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen M. Murray",
      "screen_name" : "allenmmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "22118364",
      "id" : 22118364
    }, {
      "name" : "Orthy\u2122",
      "screen_name" : "adam_orth",
      "indices" : [ 14, 24 ],
      "id_str" : "31536491",
      "id" : 31536491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/yirNERtE1Q",
      "expanded_url" : "http:\/\/topsy.com",
      "display_url" : "topsy.com"
    } ]
  },
  "in_reply_to_status_id_str" : "440993166565470208",
  "geo" : { },
  "id_str" : "440998094390300672",
  "in_reply_to_user_id" : 22118364,
  "text" : "@allenmmurray @adam_orth http:\/\/t.co\/yirNERtE1Q is good for that and still working for a while",
  "id" : 440998094390300672,
  "in_reply_to_status_id" : 440993166565470208,
  "created_at" : "2014-03-04 23:51:53 +0000",
  "in_reply_to_screen_name" : "allenmmurray",
  "in_reply_to_user_id_str" : "22118364",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hoop with Cher",
      "screen_name" : "HoopwithCher",
      "indices" : [ 26, 39 ],
      "id_str" : "2361263148",
      "id" : 2361263148
    }, {
      "name" : "Hoop with Cher",
      "screen_name" : "HoopwithCher",
      "indices" : [ 49, 62 ],
      "id_str" : "2361263148",
      "id" : 2361263148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/9BhQlwCAen",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=hhBHwFYiaCc&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=hhBHwF\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "440954867415142400",
  "geo" : { },
  "id_str" : "440998018192388096",
  "in_reply_to_user_id" : 2361263148,
  "text" : "Now this is good -&gt; RT @HoopwithCher: What is @HoopwithCher All about? Watch and join in to make my dream a reality!  http:\/\/t.co\/9BhQlwCAen",
  "id" : 440998018192388096,
  "in_reply_to_status_id" : 440954867415142400,
  "created_at" : "2014-03-04 23:51:35 +0000",
  "in_reply_to_screen_name" : "HoopwithCher",
  "in_reply_to_user_id_str" : "2361263148",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440977963077484546",
  "geo" : { },
  "id_str" : "440987420163444736",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler I haven't seen it before. Thanks for the tip off. :)",
  "id" : 440987420163444736,
  "in_reply_to_status_id" : 440977963077484546,
  "created_at" : "2014-03-04 23:09:28 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ignite Oakland",
      "screen_name" : "IgniteOAK",
      "indices" : [ 0, 10 ],
      "id_str" : "2308672776",
      "id" : 2308672776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440955696742285313",
  "geo" : { },
  "id_str" : "440955834424516608",
  "in_reply_to_user_id" : 2308672776,
  "text" : "@IgniteOAK Hope it helps!",
  "id" : 440955834424516608,
  "in_reply_to_status_id" : 440955696742285313,
  "created_at" : "2014-03-04 21:03:58 +0000",
  "in_reply_to_screen_name" : "IgniteOAK",
  "in_reply_to_user_id_str" : "2308672776",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ignite Oakland",
      "screen_name" : "IgniteOAK",
      "indices" : [ 3, 13 ],
      "id_str" : "2308672776",
      "id" : 2308672776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/AZdJ65bLvS",
      "expanded_url" : "http:\/\/igniteoakland.com\/ignite-oakland-speaker-line-up",
      "display_url" : "igniteoakland.com\/ignite-oakland\u2026"
    }, {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/NTASvw3Dm1",
      "expanded_url" : "http:\/\/igniteoakland.com\/submit-a-talk",
      "display_url" : "igniteoakland.com\/submit-a-talk"
    } ]
  },
  "geo" : { },
  "id_str" : "440955510531956736",
  "text" : "RT @IgniteOAK: New speakers added: http:\/\/t.co\/AZdJ65bLvS Inspired? Sign-up to speak here: http:\/\/t.co\/NTASvw3Dm1",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/AZdJ65bLvS",
        "expanded_url" : "http:\/\/igniteoakland.com\/ignite-oakland-speaker-line-up",
        "display_url" : "igniteoakland.com\/ignite-oakland\u2026"
      }, {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/NTASvw3Dm1",
        "expanded_url" : "http:\/\/igniteoakland.com\/submit-a-talk",
        "display_url" : "igniteoakland.com\/submit-a-talk"
      } ]
    },
    "geo" : { },
    "id_str" : "440954676473638912",
    "text" : "New speakers added: http:\/\/t.co\/AZdJ65bLvS Inspired? Sign-up to speak here: http:\/\/t.co\/NTASvw3Dm1",
    "id" : 440954676473638912,
    "created_at" : "2014-03-04 20:59:22 +0000",
    "user" : {
      "name" : "Ignite Oakland",
      "screen_name" : "IgniteOAK",
      "protected" : false,
      "id_str" : "2308672776",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/426771049934376960\/pnChm_u7_normal.png",
      "id" : 2308672776,
      "verified" : false
    }
  },
  "id" : 440955510531956736,
  "created_at" : "2014-03-04 21:02:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440938910999650304",
  "geo" : { },
  "id_str" : "440939137458503681",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap Ha. True, if they have money there are better ways to get the word out. :)",
  "id" : 440939137458503681,
  "in_reply_to_status_id" : 440938910999650304,
  "created_at" : "2014-03-04 19:57:37 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "test",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440938748541693952",
  "text" : "If you have under 100 followers and have something you think deserves more attention, send me a link to a tweet that I can retweet. #test",
  "id" : 440938748541693952,
  "created_at" : "2014-03-04 19:56:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cody Brown",
      "screen_name" : "CodyBrown",
      "indices" : [ 54, 64 ],
      "id_str" : "10950722",
      "id" : 10950722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/CzxCox9C3B",
      "expanded_url" : "https:\/\/medium.com\/meta\/f774460d5a7d",
      "display_url" : "medium.com\/meta\/f774460d5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440931298908332032",
  "text" : "\"Twitter's root injustice\"\nhttps:\/\/t.co\/CzxCox9C3B by @CodyBrown makes a lot of good points.",
  "id" : 440931298908332032,
  "created_at" : "2014-03-04 19:26:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440926715532279808",
  "geo" : { },
  "id_str" : "440928134880571395",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel I'm going in optimistic. Something is better than nothing, right? And we can always re-watch the older series.",
  "id" : 440928134880571395,
  "in_reply_to_status_id" : 440926715532279808,
  "created_at" : "2014-03-04 19:13:54 +0000",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 0, 6 ],
      "id_str" : "5814",
      "id" : 5814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440876571365085184",
  "geo" : { },
  "id_str" : "440878461393985537",
  "in_reply_to_user_id" : 5814,
  "text" : "@tempo I watched the whole thing with Niko when he was a little baby and I loved it. Sad it disappeared from Netflix.",
  "id" : 440878461393985537,
  "in_reply_to_status_id" : 440876571365085184,
  "created_at" : "2014-03-04 15:56:30 +0000",
  "in_reply_to_screen_name" : "tempo",
  "in_reply_to_user_id_str" : "5814",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/pxY1qSClUd",
      "expanded_url" : "http:\/\/mobile.nytimes.com\/2014\/03\/04\/science\/space\/a-successor-to-sagan-reboots-cosmos.html",
      "display_url" : "mobile.nytimes.com\/2014\/03\/04\/sci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440870782512558081",
  "text" : "So excited about the new Cosmos! http:\/\/t.co\/pxY1qSClUd",
  "id" : 440870782512558081,
  "created_at" : "2014-03-04 15:26:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prashant S",
      "screen_name" : "CoolAssPuppy",
      "indices" : [ 0, 13 ],
      "id_str" : "2881611",
      "id" : 2881611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/LMB9dF7VYu",
      "expanded_url" : "http:\/\/github.com\/busterbenson",
      "display_url" : "github.com\/busterbenson"
    } ]
  },
  "in_reply_to_status_id_str" : "440728071260225536",
  "geo" : { },
  "id_str" : "440728346284941312",
  "in_reply_to_user_id" : 2881611,
  "text" : "@coolasspuppy Ooh, yes please. http:\/\/t.co\/LMB9dF7VYu",
  "id" : 440728346284941312,
  "in_reply_to_status_id" : 440728071260225536,
  "created_at" : "2014-03-04 06:00:00 +0000",
  "in_reply_to_screen_name" : "CoolAssPuppy",
  "in_reply_to_user_id_str" : "2881611",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prashant S",
      "screen_name" : "CoolAssPuppy",
      "indices" : [ 0, 13 ],
      "id_str" : "2881611",
      "id" : 2881611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440727640467447808",
  "geo" : { },
  "id_str" : "440727860794249216",
  "in_reply_to_user_id" : 2881611,
  "text" : "@coolasspuppy Okay, I'll make sure I'm not doing something super dumb and come by tomorrow with a question if I still have it. :)",
  "id" : 440727860794249216,
  "in_reply_to_status_id" : 440727640467447808,
  "created_at" : "2014-03-04 05:58:05 +0000",
  "in_reply_to_screen_name" : "CoolAssPuppy",
  "in_reply_to_user_id_str" : "2881611",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prashant S",
      "screen_name" : "CoolAssPuppy",
      "indices" : [ 0, 13 ],
      "id_str" : "2881611",
      "id" : 2881611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440727243652739072",
  "geo" : { },
  "id_str" : "440727423953281025",
  "in_reply_to_user_id" : 2881611,
  "text" : "@coolasspuppy I was googling for some answers and found some posts by you\u2026 do you have all the answers?",
  "id" : 440727423953281025,
  "in_reply_to_status_id" : 440727243652739072,
  "created_at" : "2014-03-04 05:56:20 +0000",
  "in_reply_to_screen_name" : "CoolAssPuppy",
  "in_reply_to_user_id_str" : "2881611",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/RKI3Puqzgj",
      "expanded_url" : "http:\/\/flic.kr\/p\/kFQUjG",
      "display_url" : "flic.kr\/p\/kFQUjG"
    } ]
  },
  "geo" : { },
  "id_str" : "440726059420774401",
  "text" : "8:36pm Debugging my quality of life parse app is making me want to kill myself http:\/\/t.co\/RKI3Puqzgj",
  "id" : 440726059420774401,
  "created_at" : "2014-03-04 05:50:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 3, 11 ],
      "id_str" : "22891211",
      "id" : 22891211
    }, {
      "name" : "Sterling White",
      "screen_name" : "hey_sterling",
      "indices" : [ 69, 82 ],
      "id_str" : "150863291",
      "id" : 150863291
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/chanian\/status\/440594734961000448\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/o27nRV9qgw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh1Ok7UCUAAWMEo.jpg",
      "id_str" : "440594734856163328",
      "id" : 440594734856163328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh1Ok7UCUAAWMEo.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/o27nRV9qgw"
    } ],
    "hashtags" : [ {
      "text" : "twitter",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440595071587459072",
  "text" : "RT @chanian: Hello from the Twitter Insights\/Analytics team! If only @hey_sterling's arm was longer. #twitter http:\/\/t.co\/o27nRV9qgw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sterling White",
        "screen_name" : "hey_sterling",
        "indices" : [ 56, 69 ],
        "id_str" : "150863291",
        "id" : 150863291
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/chanian\/status\/440594734961000448\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/o27nRV9qgw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh1Ok7UCUAAWMEo.jpg",
        "id_str" : "440594734856163328",
        "id" : 440594734856163328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh1Ok7UCUAAWMEo.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/o27nRV9qgw"
      } ],
      "hashtags" : [ {
        "text" : "twitter",
        "indices" : [ 88, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440594734961000448",
    "text" : "Hello from the Twitter Insights\/Analytics team! If only @hey_sterling's arm was longer. #twitter http:\/\/t.co\/o27nRV9qgw",
    "id" : 440594734961000448,
    "created_at" : "2014-03-03 21:09:05 +0000",
    "user" : {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "protected" : false,
      "id_str" : "22891211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2467844172\/image_normal.jpg",
      "id" : 22891211,
      "verified" : false
    }
  },
  "id" : 440595071587459072,
  "created_at" : "2014-03-03 21:10:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440582107761360897",
  "text" : "You know what's cool? A billion retweets.",
  "id" : 440582107761360897,
  "created_at" : "2014-03-03 20:18:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam (SociallyGold)",
      "screen_name" : "Socially_Gold",
      "indices" : [ 0, 14 ],
      "id_str" : "19601202",
      "id" : 19601202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440534770414399488",
  "geo" : { },
  "id_str" : "440551092204470274",
  "in_reply_to_user_id" : 19601202,
  "text" : "@Socially_Gold I\u2019m glad you like it! :) What are you finding to be most useful?",
  "id" : 440551092204470274,
  "in_reply_to_status_id" : 440534770414399488,
  "created_at" : "2014-03-03 18:15:40 +0000",
  "in_reply_to_screen_name" : "Socially_Gold",
  "in_reply_to_user_id_str" : "19601202",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Newton",
      "screen_name" : "CaseyNewton",
      "indices" : [ 3, 15 ],
      "id_str" : "69426451",
      "id" : 69426451
    }, {
      "name" : "The Verge",
      "screen_name" : "verge",
      "indices" : [ 71, 77 ],
      "id_str" : "275686563",
      "id" : 275686563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/EOQM2S8DGQ",
      "expanded_url" : "http:\/\/vrge.co\/MIuWSo",
      "display_url" : "vrge.co\/MIuWSo"
    } ]
  },
  "geo" : { },
  "id_str" : "440523842440540161",
  "text" : "RT @CaseyNewton: Our best defense against Google robots has arrived RT @verge: Scientists can now control flies' brains with lasers http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Verge",
        "screen_name" : "verge",
        "indices" : [ 54, 60 ],
        "id_str" : "275686563",
        "id" : 275686563
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/EOQM2S8DGQ",
        "expanded_url" : "http:\/\/vrge.co\/MIuWSo",
        "display_url" : "vrge.co\/MIuWSo"
      } ]
    },
    "geo" : { },
    "id_str" : "440518282458562560",
    "text" : "Our best defense against Google robots has arrived RT @verge: Scientists can now control flies' brains with lasers http:\/\/t.co\/EOQM2S8DGQ",
    "id" : 440518282458562560,
    "created_at" : "2014-03-03 16:05:17 +0000",
    "user" : {
      "name" : "Casey Newton",
      "screen_name" : "CaseyNewton",
      "protected" : false,
      "id_str" : "69426451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436537652339175424\/LmaHLwLo_normal.jpeg",
      "id" : 69426451,
      "verified" : false
    }
  },
  "id" : 440523842440540161,
  "created_at" : "2014-03-03 16:27:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oscars",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/pAHnekDLUA",
      "expanded_url" : "http:\/\/flic.kr\/p\/kDJkwa",
      "display_url" : "flic.kr\/p\/kDJkwa"
    } ]
  },
  "geo" : { },
  "id_str" : "440360875657297920",
  "text" : "8:36pm Missed the end of the #oscars to wash faces and brush teeths http:\/\/t.co\/pAHnekDLUA",
  "id" : 440360875657297920,
  "created_at" : "2014-03-03 05:39:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Johnston",
      "screen_name" : "ajohnston12",
      "indices" : [ 3, 15 ],
      "id_str" : "23963789",
      "id" : 23963789
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/clasehit\/status\/440331020068749312\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/eLU1eWHsQW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhxeusoIUAA7iff.jpg",
      "id_str" : "440331019921936384",
      "id" : 440331019921936384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhxeusoIUAA7iff.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/eLU1eWHsQW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440333663608532992",
  "text" : "RT @ajohnston12: I. Cannot. Breathe. https:\/\/t.co\/eLU1eWHsQW",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/clasehit\/status\/440331020068749312\/photo\/1",
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/eLU1eWHsQW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhxeusoIUAA7iff.jpg",
        "id_str" : "440331019921936384",
        "id" : 440331019921936384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhxeusoIUAA7iff.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/eLU1eWHsQW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440332005582991360",
    "text" : "I. Cannot. Breathe. https:\/\/t.co\/eLU1eWHsQW",
    "id" : 440332005582991360,
    "created_at" : "2014-03-03 03:45:05 +0000",
    "user" : {
      "name" : "Abby Johnston",
      "screen_name" : "ajohnston12",
      "protected" : false,
      "id_str" : "23963789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454272860760969216\/N60X0KD0_normal.jpeg",
      "id" : 23963789,
      "verified" : false
    }
  },
  "id" : 440333663608532992,
  "created_at" : "2014-03-03 03:51:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 0, 3 ],
      "id_str" : "15504330",
      "id" : 15504330
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 4, 15 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440329808925704192",
  "geo" : { },
  "id_str" : "440330036642861056",
  "in_reply_to_user_id" : 15504330,
  "text" : "@wm @nikobenson I don't even need to click that one.",
  "id" : 440330036642861056,
  "in_reply_to_status_id" : 440329808925704192,
  "created_at" : "2014-03-03 03:37:16 +0000",
  "in_reply_to_screen_name" : "wm",
  "in_reply_to_user_id_str" : "15504330",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440327879478370305",
  "geo" : { },
  "id_str" : "440328937244491777",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie I'm a sucker for a selfie.",
  "id" : 440328937244491777,
  "in_reply_to_status_id" : 440327879478370305,
  "created_at" : "2014-03-03 03:32:54 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 3, 14 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oscars",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440327839762903042",
  "text" : "RT @nikobenson: How do you touch a heart? #oscars",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oscars",
        "indices" : [ 26, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440327764202487808",
    "text" : "How do you touch a heart? #oscars",
    "id" : 440327764202487808,
    "created_at" : "2014-03-03 03:28:14 +0000",
    "user" : {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "protected" : false,
      "id_str" : "142467448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000616213793\/9f77fe6693d877565cd97b6a2381c40c_normal.jpeg",
      "id" : 142467448,
      "verified" : false
    }
  },
  "id" : 440327839762903042,
  "created_at" : "2014-03-03 03:28:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440323546049298432",
  "geo" : { },
  "id_str" : "440326966965972993",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie Hi",
  "id" : 440326966965972993,
  "in_reply_to_status_id" : 440323546049298432,
  "created_at" : "2014-03-03 03:25:04 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen DeGeneres",
      "screen_name" : "TheEllenShow",
      "indices" : [ 3, 16 ],
      "id_str" : "15846407",
      "id" : 15846407
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheEllenShow\/status\/440322224407314432\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/C9U5NOtGap",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhxWutnCEAAtEQ6.jpg",
      "id_str" : "440322224092745728",
      "id" : 440322224092745728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhxWutnCEAAtEQ6.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/C9U5NOtGap"
    } ],
    "hashtags" : [ {
      "text" : "oscars",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440322303721611265",
  "text" : "RT @TheEllenShow: If only Bradley's arm was longer. Best photo ever. #oscars http:\/\/t.co\/C9U5NOtGap",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheEllenShow\/status\/440322224407314432\/photo\/1",
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/C9U5NOtGap",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhxWutnCEAAtEQ6.jpg",
        "id_str" : "440322224092745728",
        "id" : 440322224092745728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhxWutnCEAAtEQ6.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/C9U5NOtGap"
      } ],
      "hashtags" : [ {
        "text" : "oscars",
        "indices" : [ 51, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440322224407314432",
    "text" : "If only Bradley's arm was longer. Best photo ever. #oscars http:\/\/t.co\/C9U5NOtGap",
    "id" : 440322224407314432,
    "created_at" : "2014-03-03 03:06:13 +0000",
    "user" : {
      "name" : "Ellen DeGeneres",
      "screen_name" : "TheEllenShow",
      "protected" : false,
      "id_str" : "15846407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464848898305949697\/aBzDtrGt_normal.jpeg",
      "id" : 15846407,
      "verified" : true
    }
  },
  "id" : 440322303721611265,
  "created_at" : "2014-03-03 03:06:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/440225473000267776\/photo\/1",
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/Bj5gPKdidL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhv-u_8CIAAIF5D.jpg",
      "id_str" : "440225471989424128",
      "id" : 440225471989424128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhv-u_8CIAAIF5D.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Bj5gPKdidL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440225473000267776",
  "text" : "About to see Amaluna! http:\/\/t.co\/Bj5gPKdidL",
  "id" : 440225473000267776,
  "created_at" : "2014-03-02 20:41:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/440191233223192576\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/gDP94vN4Nk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhvfmBjCYAA2ECX.jpg",
      "id_str" : "440191232942170112",
      "id" : 440191232942170112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhvfmBjCYAA2ECX.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gDP94vN4Nk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440191233223192576",
  "text" : "\"You have to wear a hoodie and get under the umbrella!\" Niko is excited for rain. http:\/\/t.co\/gDP94vN4Nk",
  "id" : 440191233223192576,
  "created_at" : "2014-03-02 18:25:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Saint-Andre",
      "screen_name" : "stpeter",
      "indices" : [ 0, 8 ],
      "id_str" : "11395",
      "id" : 11395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439962097988816896",
  "geo" : { },
  "id_str" : "440007408429969408",
  "in_reply_to_user_id" : 11395,
  "text" : "@stpeter That's awesome.",
  "id" : 440007408429969408,
  "in_reply_to_status_id" : 439962097988816896,
  "created_at" : "2014-03-02 06:15:15 +0000",
  "in_reply_to_screen_name" : "stpeter",
  "in_reply_to_user_id_str" : "11395",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439998294341611520",
  "text" : "Percent of the time that your allotted attention runs out before the URL has finished loading.",
  "id" : 439998294341611520,
  "created_at" : "2014-03-02 05:39:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439988736764309504",
  "text" : "The parents of the girls in Frozen were the real antagonists.",
  "id" : 439988736764309504,
  "created_at" : "2014-03-02 05:01:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/439987897551171586\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/eUReaWJKaV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhsmqVLCYAAcgxd.jpg",
      "id_str" : "439987897278554112",
      "id" : 439987897278554112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhsmqVLCYAAcgxd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/eUReaWJKaV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439987897551171586",
  "text" : "8:36pm Night rider http:\/\/t.co\/eUReaWJKaV",
  "id" : 439987897551171586,
  "created_at" : "2014-03-02 04:57:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439950313093484545",
  "geo" : { },
  "id_str" : "439987257777192960",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach Back in my day vesting happened yearly. And hills were always uphill.",
  "id" : 439987257777192960,
  "in_reply_to_status_id" : 439950313093484545,
  "created_at" : "2014-03-02 04:55:11 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Cook",
      "screen_name" : "tim_cook",
      "indices" : [ 5, 14 ],
      "id_str" : "1636590253",
      "id" : 1636590253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/AKZvqFuD5E",
      "expanded_url" : "http:\/\/www.macobserver.com\/tmo\/article\/tim-cook-soundly-rejects-politics-of-the-ncppr-suggests-group-sell-apples-s",
      "display_url" : "macobserver.com\/tmo\/article\/ti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439825131133616128",
  "text" : "Team @tim_cook http:\/\/t.co\/AKZvqFuD5E",
  "id" : 439825131133616128,
  "created_at" : "2014-03-01 18:10:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439801446754578432",
  "text" : "Rabbit rabbit!",
  "id" : 439801446754578432,
  "created_at" : "2014-03-01 16:36:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]