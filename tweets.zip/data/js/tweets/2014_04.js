Grailbird.data.tweets_2014_04 = 
 [ {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hyoomans",
      "screen_name" : "Hyoomans",
      "indices" : [ 89, 98 ],
      "id_str" : "2471899068",
      "id" : 2471899068
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweekend",
      "indices" : [ 60, 72 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461748320013012992",
  "geo" : { },
  "id_str" : "461750076646227969",
  "in_reply_to_user_id" : 2185,
  "text" : "If for some strange reason you want to follow along with my #hackweekend project, follow @Hyoomans.",
  "id" : 461750076646227969,
  "in_reply_to_status_id" : 461748320013012992,
  "created_at" : "2014-05-01 06:12:51 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461748881408012290",
  "geo" : { },
  "id_str" : "461749333612711936",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs Will you be around this weekend? I'd love to bounce a few ideas around.",
  "id" : 461749333612711936,
  "in_reply_to_status_id" : 461748881408012290,
  "created_at" : "2014-05-01 06:09:54 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461746846637891584",
  "geo" : { },
  "id_str" : "461748320013012992",
  "in_reply_to_user_id" : 2185,
  "text" : "I'm going to write a web-based multiplayer game based on spatial iterated prisoner's dilemma that I've had in my head forever. Of course.",
  "id" : 461748320013012992,
  "in_reply_to_status_id" : 461746846637891584,
  "created_at" : "2014-05-01 06:05:53 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "poorlifechoices",
      "indices" : [ 122, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461746846637891584",
  "text" : "Wife and child are headed out of town tomorrow for 5 days before I join. I'm going to use my rare solitude to write code. #poorlifechoices",
  "id" : 461746846637891584,
  "created_at" : "2014-05-01 06:00:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 0, 8 ],
      "id_str" : "22891211",
      "id" : 22891211
    }, {
      "name" : "David Chen",
      "screen_name" : "chenosaurus",
      "indices" : [ 9, 21 ],
      "id_str" : "15349546",
      "id" : 15349546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461704415749996544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596265475, -122.2754421831 ]
  },
  "id_str" : "461704795082874880",
  "in_reply_to_user_id" : 22891211,
  "text" : "@chanian @chenosaurus Turns out we're the squatters we were fearing all along.",
  "id" : 461704795082874880,
  "in_reply_to_status_id" : 461704415749996544,
  "created_at" : "2014-05-01 03:12:55 +0000",
  "in_reply_to_screen_name" : "chanian",
  "in_reply_to_user_id_str" : "22891211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "damnsquatters",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596366896, -122.275470514 ]
  },
  "id_str" : "461702212888961024",
  "text" : "Was bummed that a domain I wanted to buy was already taken. Looked it up on whois and found it was registered to me. #damnsquatters",
  "id" : 461702212888961024,
  "created_at" : "2014-05-01 03:02:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beau Gunderson",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461590070722838529",
  "geo" : { },
  "id_str" : "461590844034654209",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson Squirrel squirrel squirrel squirrel squirrel squirrel squirrel squirrel squirrel squirrel squirrel squirrel squirrel squirrel",
  "id" : 461590844034654209,
  "in_reply_to_status_id" : 461590070722838529,
  "created_at" : "2014-04-30 19:40:07 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461577863938842624",
  "text" : "Every time you say some word isn't a word, it becomes more of a word.",
  "id" : 461577863938842624,
  "created_at" : "2014-04-30 18:48:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "AdamSinger",
      "indices" : [ 0, 11 ],
      "id_str" : "14031032",
      "id" : 14031032
    }, {
      "name" : "Justin Cutroni",
      "screen_name" : "justincutroni",
      "indices" : [ 12, 26 ],
      "id_str" : "7681972",
      "id" : 7681972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461573111662383104",
  "geo" : { },
  "id_str" : "461573292969578496",
  "in_reply_to_user_id" : 14031032,
  "text" : "@adamsinger @justincutroni I'd possibly be up for that. Let me know when that happens!",
  "id" : 461573292969578496,
  "in_reply_to_status_id" : 461573111662383104,
  "created_at" : "2014-04-30 18:30:23 +0000",
  "in_reply_to_screen_name" : "AdamSinger",
  "in_reply_to_user_id_str" : "14031032",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461572765594570752",
  "text" : "How are you today, tweeterheads? Personally, I'm excited for lunch.",
  "id" : 461572765594570752,
  "created_at" : "2014-04-30 18:28:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Haggerty",
      "screen_name" : "bhaggs",
      "indices" : [ 0, 7 ],
      "id_str" : "1692881",
      "id" : 1692881
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 8, 18 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461352402013016064",
  "geo" : { },
  "id_str" : "461547308006395904",
  "in_reply_to_user_id" : 1692881,
  "text" : "@bhaggs @kellianne Weekly! We have a standing date night on Thurs, but switched it around this week due to having visitors.",
  "id" : 461547308006395904,
  "in_reply_to_status_id" : 461352402013016064,
  "created_at" : "2014-04-30 16:47:08 +0000",
  "in_reply_to_screen_name" : "bhaggs",
  "in_reply_to_user_id_str" : "1692881",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edwin Catmull",
      "screen_name" : "edcatmull",
      "indices" : [ 105, 115 ],
      "id_str" : "60644920",
      "id" : 60644920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8532556321, -122.2707083958 ]
  },
  "id_str" : "461536043959734273",
  "text" : "\"We aren't aware that the majority of what we think we see is actually our brain filling in the gaps.\" - @edcatmull",
  "id" : 461536043959734273,
  "created_at" : "2014-04-30 16:02:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "indices" : [ 3, 16 ],
      "id_str" : "35943",
      "id" : 35943
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 18, 25 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 117, 124 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/zwBnKoZMV0",
      "expanded_url" : "http:\/\/bzfd.it\/1rOxBKc",
      "display_url" : "bzfd.it\/1rOxBKc"
    } ]
  },
  "geo" : { },
  "id_str" : "461524236721336320",
  "text" : "RT @karenmcgrane: @buster Imma let you finish but this defense of Katy Perry repeated listening is the best thing by @ftrain this week: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      }, {
        "name" : "Paul Ford",
        "screen_name" : "ftrain",
        "indices" : [ 99, 106 ],
        "id_str" : "6981492",
        "id" : 6981492
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/zwBnKoZMV0",
        "expanded_url" : "http:\/\/bzfd.it\/1rOxBKc",
        "display_url" : "bzfd.it\/1rOxBKc"
      } ]
    },
    "in_reply_to_status_id_str" : "461515205814398976",
    "geo" : { },
    "id_str" : "461516712710770688",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster Imma let you finish but this defense of Katy Perry repeated listening is the best thing by @ftrain this week: http:\/\/t.co\/zwBnKoZMV0",
    "id" : 461516712710770688,
    "in_reply_to_status_id" : 461515205814398976,
    "created_at" : "2014-04-30 14:45:33 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "protected" : false,
      "id_str" : "35943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419909047421517824\/93mwja9K_normal.jpeg",
      "id" : 35943,
      "verified" : false
    }
  },
  "id" : 461524236721336320,
  "created_at" : "2014-04-30 15:15:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 33, 40 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/Qzx6KxfJ7W",
      "expanded_url" : "https:\/\/medium.com\/message\/705b87339971",
      "display_url" : "medium.com\/message\/705b87\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596735252, -122.2754106827 ]
  },
  "id_str" : "461515205814398976",
  "text" : "Five great works of software, by @ftrain. Required retweeting. https:\/\/t.co\/Qzx6KxfJ7W",
  "id" : 461515205814398976,
  "created_at" : "2014-04-30 14:39:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 35, 45 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/461351843189112832\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/xCibGVmKe2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmcNDfXCUAEAQHa.jpg",
      "id_str" : "461351840437653505",
      "id" : 461351840437653505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmcNDfXCUAEAQHa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xCibGVmKe2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8260892537, -122.2532761564 ]
  },
  "id_str" : "461351843189112832",
  "text" : "8:36pm Date night with the lovely  @kellianne at Homestead http:\/\/t.co\/xCibGVmKe2",
  "id" : 461351843189112832,
  "created_at" : "2014-04-30 03:50:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 3, 17 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461284275694739456",
  "text" : "RT @buster_ebooks: Retweet this: WHY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/busterbenson.com\" rel=\"nofollow\"\u003EBuster eBooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461265958883962880",
    "text" : "Retweet this: WHY",
    "id" : 461265958883962880,
    "created_at" : "2014-04-29 22:09:09 +0000",
    "user" : {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "protected" : false,
      "id_str" : "1901375096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000503050571\/228ccabfeeb4e55bd8e172595babe02e_normal.jpeg",
      "id" : 1901375096,
      "verified" : false
    }
  },
  "id" : 461284275694739456,
  "created_at" : "2014-04-29 23:21:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Valentine",
      "screen_name" : "JMCvalentine",
      "indices" : [ 0, 13 ],
      "id_str" : "68715343",
      "id" : 68715343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461188511216205824",
  "geo" : { },
  "id_str" : "461220114483130368",
  "in_reply_to_user_id" : 68715343,
  "text" : "@JMCvalentine Yes!",
  "id" : 461220114483130368,
  "in_reply_to_status_id" : 461188511216205824,
  "created_at" : "2014-04-29 19:06:59 +0000",
  "in_reply_to_screen_name" : "JMCvalentine",
  "in_reply_to_user_id_str" : "68715343",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pratik",
      "screen_name" : "pratiktandel",
      "indices" : [ 3, 16 ],
      "id_str" : "259246576",
      "id" : 259246576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461014355924897792",
  "text" : "RT @pratiktandel: p50 salary $50k\np99 salary $300k\np999 salary $1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461013304630980608",
    "text" : "p50 salary $50k\np99 salary $300k\np999 salary $1",
    "id" : 461013304630980608,
    "created_at" : "2014-04-29 05:25:11 +0000",
    "user" : {
      "name" : "Pratik",
      "screen_name" : "pratiktandel",
      "protected" : false,
      "id_str" : "259246576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3450652130\/67aded1cec04556ad045e817be4a670b_normal.jpeg",
      "id" : 259246576,
      "verified" : false
    }
  },
  "id" : 461014355924897792,
  "created_at" : "2014-04-29 05:29:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    }, {
      "name" : "Edwin Catmull",
      "screen_name" : "edcatmull",
      "indices" : [ 5, 15 ],
      "id_str" : "60644920",
      "id" : 60644920
    }, {
      "name" : "Charles Forman",
      "screen_name" : "charlesforman",
      "indices" : [ 16, 30 ],
      "id_str" : "5807992",
      "id" : 5807992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460958525997326336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8021836311, -122.2836242055 ]
  },
  "id_str" : "460959258381529088",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg @edcatmull @charlesforman The next 4 chapters are even better than the first 4.",
  "id" : 460959258381529088,
  "in_reply_to_status_id" : 460958525997326336,
  "created_at" : "2014-04-29 01:50:26 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edwin Catmull",
      "screen_name" : "edcatmull",
      "indices" : [ 106, 116 ],
      "id_str" : "60644920",
      "id" : 60644920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8089536868, -122.3175813598 ]
  },
  "id_str" : "460958239044014081",
  "text" : "\"If you don't try to uncover what is unseen and understand its nature, you will be unprepared to lead.\" - @edcatmull",
  "id" : 460958239044014081,
  "created_at" : "2014-04-29 01:46:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Mikulla",
      "screen_name" : "mattmikulla",
      "indices" : [ 0, 12 ],
      "id_str" : "24005949",
      "id" : 24005949
    }, {
      "name" : "Joel Abrams",
      "screen_name" : "BostonAbrams",
      "indices" : [ 13, 26 ],
      "id_str" : "14499468",
      "id" : 14499468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460904337128964097",
  "geo" : { },
  "id_str" : "460909972809736192",
  "in_reply_to_user_id" : 24005949,
  "text" : "@mattmikulla @BostonAbrams We're looking into it. Sorry for the trouble.",
  "id" : 460909972809736192,
  "in_reply_to_status_id" : 460904337128964097,
  "created_at" : "2014-04-28 22:34:35 +0000",
  "in_reply_to_screen_name" : "mattmikulla",
  "in_reply_to_user_id_str" : "24005949",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Nentrup",
      "screen_name" : "ericnentrup",
      "indices" : [ 0, 12 ],
      "id_str" : "1974921",
      "id" : 1974921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460595494558113792",
  "geo" : { },
  "id_str" : "460823671800475648",
  "in_reply_to_user_id" : 1974921,
  "text" : "@ericnentrup That's kind of you to say! Writing out \/ maintaining my beliefs publicly is enormously rewarding - everyone should do it!",
  "id" : 460823671800475648,
  "in_reply_to_status_id" : 460595494558113792,
  "created_at" : "2014-04-28 16:51:39 +0000",
  "in_reply_to_screen_name" : "ericnentrup",
  "in_reply_to_user_id_str" : "1974921",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460253878538092545",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596334625, -122.2755213921 ]
  },
  "id_str" : "460256730476072960",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm And yet even then they are born their own people.",
  "id" : 460256730476072960,
  "in_reply_to_status_id" : 460253878538092545,
  "created_at" : "2014-04-27 03:18:50 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460247659031584769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597113304, -122.2754534987 ]
  },
  "id_str" : "460251315088551936",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh And not duplicates.",
  "id" : 460251315088551936,
  "in_reply_to_status_id" : 460247659031584769,
  "created_at" : "2014-04-27 02:57:19 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 1, 8 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460231855770718208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597254362, -122.2755455578 ]
  },
  "id_str" : "460247341623033856",
  "in_reply_to_user_id" : 4558,
  "text" : ".@harryh Well there are 32.7M Wikipedia pages total, which is 1 Wikipedia page for every 3,241 people who have lived.",
  "id" : 460247341623033856,
  "in_reply_to_status_id" : 460231855770718208,
  "created_at" : "2014-04-27 02:41:31 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460240377946320896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859663424, -122.2755349617 ]
  },
  "id_str" : "460244531800051713",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb On a Google search results page, naturally. I didn't go very deep though, the number could be way off.",
  "id" : 460244531800051713,
  "in_reply_to_status_id" : 460240377946320896,
  "created_at" : "2014-04-27 02:30:21 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 15, 24 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "asa",
      "screen_name" : "asa",
      "indices" : [ 25, 29 ],
      "id_str" : "407",
      "id" : 407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460235213851750400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859727989, -122.2755653855 ]
  },
  "id_str" : "460244031604158465",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin @RickWebb @asa Just resolve it with a simple \"off with his head!\"",
  "id" : 460244031604158465,
  "in_reply_to_status_id" : 460235213851750400,
  "created_at" : "2014-04-27 02:28:22 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460232081474596864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597082631, -122.2755334954 ]
  },
  "id_str" : "460243744772476928",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Not to mention all the generations before our great grandparents.",
  "id" : 460243744772476928,
  "in_reply_to_status_id" : 460232081474596864,
  "created_at" : "2014-04-27 02:27:14 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "susan wu",
      "screen_name" : "sw",
      "indices" : [ 3, 6 ],
      "id_str" : "893211",
      "id" : 893211
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 8, 15 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460229702456594432",
  "text" : "RT @sw: @buster legacies include religion, art, intellectual advances, invention, literature, political movements. Very little business.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "460224280089731072",
    "geo" : { },
    "id_str" : "460227443333152768",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster legacies include religion, art, intellectual advances, invention, literature, political movements. Very little business.",
    "id" : 460227443333152768,
    "in_reply_to_status_id" : 460224280089731072,
    "created_at" : "2014-04-27 01:22:27 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "susan wu",
      "screen_name" : "sw",
      "protected" : false,
      "id_str" : "893211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1167478537\/photo_43__normal.JPG",
      "id" : 893211,
      "verified" : false
    }
  },
  "id" : 460229702456594432,
  "created_at" : "2014-04-27 01:31:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596190457, -122.2755290196 ]
  },
  "id_str" : "460224280089731072",
  "text" : "Of the ~106B people that've lived on Earth, what % have produced legacies that still exist? What % of those are positive and intentional?",
  "id" : 460224280089731072,
  "created_at" : "2014-04-27 01:09:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Empirical",
      "screen_name" : "JEmpirical",
      "indices" : [ 0, 11 ],
      "id_str" : "2287643384",
      "id" : 2287643384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460219741437587458",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8603180064, -122.276596632 ]
  },
  "id_str" : "460220267101306881",
  "in_reply_to_user_id" : 2287643384,
  "text" : "@JEmpirical The first version of it took less than a week.",
  "id" : 460220267101306881,
  "in_reply_to_status_id" : 460219741437587458,
  "created_at" : "2014-04-27 00:53:56 +0000",
  "in_reply_to_screen_name" : "JEmpirical",
  "in_reply_to_user_id_str" : "2287643384",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/PjwqC7EOpX",
      "expanded_url" : "http:\/\/www.wired.com\/2014\/04\/quantum-theory-flow-time\/",
      "display_url" : "wired.com\/2014\/04\/quantu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859698548, -122.2755715159 ]
  },
  "id_str" : "460217428106944512",
  "text" : "\u201CThe universe is in a pure state, but parts of it, entangled with the rest of the universe, are in mixtures.\u201D http:\/\/t.co\/PjwqC7EOpX",
  "id" : 460217428106944512,
  "created_at" : "2014-04-27 00:42:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Empirical",
      "screen_name" : "JEmpirical",
      "indices" : [ 0, 11 ],
      "id_str" : "2287643384",
      "id" : 2287643384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460204718929633280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859713384, -122.275510328 ]
  },
  "id_str" : "460212021342912512",
  "in_reply_to_user_id" : 2287643384,
  "text" : "@JEmpirical Thanks! That site is all written in Ruby and JQuery.",
  "id" : 460212021342912512,
  "in_reply_to_status_id" : 460204718929633280,
  "created_at" : "2014-04-27 00:21:10 +0000",
  "in_reply_to_screen_name" : "JEmpirical",
  "in_reply_to_user_id_str" : "2287643384",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline wolven",
      "screen_name" : "jackiewolven",
      "indices" : [ 0, 13 ],
      "id_str" : "7413172",
      "id" : 7413172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460200288490500097",
  "geo" : { },
  "id_str" : "460201231248420864",
  "in_reply_to_user_id" : 7413172,
  "text" : "@jackiewolven Yeah, I should move that one up.",
  "id" : 460201231248420864,
  "in_reply_to_status_id" : 460200288490500097,
  "created_at" : "2014-04-26 23:38:18 +0000",
  "in_reply_to_screen_name" : "jackiewolven",
  "in_reply_to_user_id_str" : "7413172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/Dre8sDasEG",
      "expanded_url" : "https:\/\/github.com\/busterbenson\/public\/commit\/64d8847665ae605587adf7973a1c5542303f4175#diff-76aa5d46fa1e82b8a6dc5d28f7558bb5",
      "display_url" : "github.com\/busterbenson\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "460197549266059265",
  "text" : "Updated my Beliefs file, added section on the purpose of life, and other minor edits: https:\/\/t.co\/Dre8sDasEG",
  "id" : 460197549266059265,
  "created_at" : "2014-04-26 23:23:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zeitgeist",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/b57ptOKhWL",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Systems_thinking",
      "display_url" : "en.wikipedia.org\/wiki\/Systems_t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "460195768867893248",
  "text" : "The idea of systems thinking (http:\/\/t.co\/b57ptOKhWL) keeps popping up. In Creativity Inc, Antifragile, and The Fifth Discipline. #zeitgeist",
  "id" : 460195768867893248,
  "created_at" : "2014-04-26 23:16:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 13, 20 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/460192292637122560\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/t2y2XVCS04",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmLuc7NCIAE_IlV.jpg",
      "id_str" : "460192292641316865",
      "id" : 460192292641316865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmLuc7NCIAE_IlV.jpg",
      "sizes" : [ {
        "h" : 1031,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 171,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/t2y2XVCS04"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/JqLVeiBaBp",
      "expanded_url" : "https:\/\/medium.com\/@buster",
      "display_url" : "medium.com\/@buster"
    } ]
  },
  "geo" : { },
  "id_str" : "460192292637122560",
  "text" : "Just noticed @Medium now lets you see your number of followers (but you can't see others'): https:\/\/t.co\/JqLVeiBaBp http:\/\/t.co\/t2y2XVCS04",
  "id" : 460192292637122560,
  "created_at" : "2014-04-26 23:02:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    }, {
      "name" : "asa",
      "screen_name" : "asa",
      "indices" : [ 15, 19 ],
      "id_str" : "407",
      "id" : 407
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 20, 29 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460183786567643136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596729123, -122.2756500848 ]
  },
  "id_str" : "460186738015498240",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin @asa @RickWebb I'd vote you president of the commune. Tarvin 2016!",
  "id" : 460186738015498240,
  "in_reply_to_status_id" : 460183786567643136,
  "created_at" : "2014-04-26 22:40:42 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "susan wu",
      "screen_name" : "sw",
      "indices" : [ 0, 3 ],
      "id_str" : "893211",
      "id" : 893211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460158011118346240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8907121788, -122.2924616628 ]
  },
  "id_str" : "460160422612459522",
  "in_reply_to_user_id" : 893211,
  "text" : "@sw Wise words.",
  "id" : 460160422612459522,
  "in_reply_to_status_id" : 460158011118346240,
  "created_at" : "2014-04-26 20:56:08 +0000",
  "in_reply_to_screen_name" : "sw",
  "in_reply_to_user_id_str" : "893211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460116939570831361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595620188, -122.2756627312 ]
  },
  "id_str" : "460119182378418176",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Yeah that's pretty disappointing. Are there any pro-Snowden presidential candidates out there, though?",
  "id" : 460119182378418176,
  "in_reply_to_status_id" : 460116939570831361,
  "created_at" : "2014-04-26 18:12:16 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/459900937469829120\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/u7ipofn6tv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmHldwqCQAEHH1e.jpg",
      "id_str" : "459900936408678401",
      "id" : 459900936408678401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmHldwqCQAEHH1e.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/u7ipofn6tv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7750072955, -122.4308907801 ]
  },
  "id_str" : "459900937469829120",
  "text" : "8:36pm Birthday girl action shot http:\/\/t.co\/u7ipofn6tv",
  "id" : 459900937469829120,
  "created_at" : "2014-04-26 03:45:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/yEXHcgPRDt",
      "expanded_url" : "https:\/\/vine.co\/v\/Mv7TTDHnx5W",
      "display_url" : "vine.co\/v\/Mv7TTDHnx5W"
    } ]
  },
  "geo" : { },
  "id_str" : "459900793274265600",
  "text" : "Kellianne skating backwards https:\/\/t.co\/yEXHcgPRDt",
  "id" : 459900793274265600,
  "created_at" : "2014-04-26 03:44:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 25, 38 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/mWh1rIXbod",
      "expanded_url" : "http:\/\/kottke.org\/14\/04\/boyhood",
      "display_url" : "kottke.org\/14\/04\/boyhood"
    } ]
  },
  "in_reply_to_status_id_str" : "459860876992856064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7770829169, -122.4214232786 ]
  },
  "id_str" : "459889822685868032",
  "in_reply_to_user_id" : 14095370,
  "text" : "Amazing. Also biased. RT @OffbeatAriel: Wut. This movie concept is blowing my fucking mind right now: http:\/\/t.co\/mWh1rIXbod",
  "id" : 459889822685868032,
  "in_reply_to_status_id" : 459860876992856064,
  "created_at" : "2014-04-26 03:00:52 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7771254521, -122.4214857242 ]
  },
  "id_str" : "459889297584168960",
  "text" : "Going roller skating at a place without a bar.",
  "id" : 459889297584168960,
  "created_at" : "2014-04-26 02:58:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Dupee",
      "screen_name" : "andrewdupee",
      "indices" : [ 0, 12 ],
      "id_str" : "57729639",
      "id" : 57729639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/cucAoNWt8o",
      "expanded_url" : "https:\/\/medium.com\/editors-picks\/b98574b7212d\/",
      "display_url" : "medium.com\/editors-picks\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "459866547331563520",
  "geo" : { },
  "id_str" : "459867416063782912",
  "in_reply_to_user_id" : 57729639,
  "text" : "@andrewdupee Well I don't know then. You're entitled to your opinion. I believe their story and intentions here: https:\/\/t.co\/cucAoNWt8o",
  "id" : 459867416063782912,
  "in_reply_to_status_id" : 459866547331563520,
  "created_at" : "2014-04-26 01:31:50 +0000",
  "in_reply_to_screen_name" : "andrewdupee",
  "in_reply_to_user_id_str" : "57729639",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Dupee",
      "screen_name" : "andrewdupee",
      "indices" : [ 0, 12 ],
      "id_str" : "57729639",
      "id" : 57729639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459865236569608192",
  "geo" : { },
  "id_str" : "459865910807785473",
  "in_reply_to_user_id" : 57729639,
  "text" : "@andrewdupee Tell me you can imagine what it was like to be separated at the finish line during last year's bombing.",
  "id" : 459865910807785473,
  "in_reply_to_status_id" : 459865236569608192,
  "created_at" : "2014-04-26 01:25:51 +0000",
  "in_reply_to_screen_name" : "andrewdupee",
  "in_reply_to_user_id_str" : "57729639",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 0, 5 ],
      "id_str" : "418",
      "id" : 418
    }, {
      "name" : "Chelsa Crowley",
      "screen_name" : "chelsa",
      "indices" : [ 14, 21 ],
      "id_str" : "17904400",
      "id" : 17904400
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teamcrowley",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459829710525329408",
  "geo" : { },
  "id_str" : "459851446268067840",
  "in_reply_to_user_id" : 418,
  "text" : "@dens You and @chelsa added much more to the Boston Marathon than you took away, and I believe you did it in the right spirit. #teamcrowley",
  "id" : 459851446268067840,
  "in_reply_to_status_id" : 459829710525329408,
  "created_at" : "2014-04-26 00:28:23 +0000",
  "in_reply_to_screen_name" : "dens",
  "in_reply_to_user_id_str" : "418",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    }, {
      "name" : "ustwogames",
      "screen_name" : "ustwogames",
      "indices" : [ 60, 71 ],
      "id_str" : "899902687",
      "id" : 899902687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459829424335388672",
  "geo" : { },
  "id_str" : "459829804934909952",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm That's where I did all my Monument Valley playing too. @ustwogames, perhaps you should look into doing some BART-vertising.",
  "id" : 459829804934909952,
  "in_reply_to_status_id" : 459829424335388672,
  "created_at" : "2014-04-25 23:02:23 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/7Vi20hWvdC",
      "expanded_url" : "https:\/\/flic.kr\/p\/nkswqF",
      "display_url" : "flic.kr\/p\/nkswqF"
    } ]
  },
  "geo" : { },
  "id_str" : "459575781723996161",
  "text" : "8:36pm Drinking tea, system updating, working on slides, trying not to get sick again, failing https:\/\/t.co\/7Vi20hWvdC",
  "id" : 459575781723996161,
  "created_at" : "2014-04-25 06:12:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8584554872, -122.2757988675 ]
  },
  "id_str" : "459508209892331520",
  "text" : "Chapter 5 in Creativity, Inc on candor (vs honesty) and Pixar's brain trust problem-solving group is a must read for product people.",
  "id" : 459508209892331520,
  "created_at" : "2014-04-25 01:44:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459418758088359936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7765924809, -122.4174406333 ]
  },
  "id_str" : "459419087810985984",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne The 3 bottles should last you the week, I hope!",
  "id" : 459419087810985984,
  "in_reply_to_status_id" : 459418758088359936,
  "created_at" : "2014-04-24 19:50:20 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Lewis",
      "screen_name" : "lovedbylisa",
      "indices" : [ 0, 12 ],
      "id_str" : "18736984",
      "id" : 18736984
    }, {
      "name" : "megan gebhart",
      "screen_name" : "megangebhart",
      "indices" : [ 13, 26 ],
      "id_str" : "32966836",
      "id" : 32966836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459398898248085505",
  "geo" : { },
  "id_str" : "459403352376623104",
  "in_reply_to_user_id" : 18736984,
  "text" : "@lovedbylisa @megangebhart I'm glad it struck a chord! Honestly, I still have to remind myself about this idea all the time.",
  "id" : 459403352376623104,
  "in_reply_to_status_id" : 459398898248085505,
  "created_at" : "2014-04-24 18:47:49 +0000",
  "in_reply_to_screen_name" : "lovedbylisa",
  "in_reply_to_user_id_str" : "18736984",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Acompli",
      "screen_name" : "acompli",
      "indices" : [ 9, 17 ],
      "id_str" : "1390635710",
      "id" : 1390635710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459354683568435200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596428329, -122.2755154254 ]
  },
  "id_str" : "459361888229277697",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver @acompli Tried it out but froze up several times and can't figure out how to mark an email as unread. Will try again after updates.",
  "id" : 459361888229277697,
  "in_reply_to_status_id" : 459354683568435200,
  "created_at" : "2014-04-24 16:03:03 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 14, 25 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859629145, -122.2754909854 ]
  },
  "id_str" : "459222873815523328",
  "text" : "In other news @nikobenson's new piggy bank has officially triggered his external motivations. His first job ever: set the table for 3 cents.",
  "id" : 459222873815523328,
  "created_at" : "2014-04-24 06:50:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/S0CcWzCNK6",
      "expanded_url" : "https:\/\/twitter.com\/buster\/status\/326752667307216896",
      "display_url" : "twitter.com\/buster\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "459221682532532224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596746019, -122.2754387024 ]
  },
  "id_str" : "459221909515689987",
  "in_reply_to_user_id" : 2185,
  "text" : "Still true: https:\/\/t.co\/S0CcWzCNK6",
  "id" : 459221909515689987,
  "in_reply_to_status_id" : 459221682532532224,
  "created_at" : "2014-04-24 06:46:49 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596124072, -122.2755271721 ]
  },
  "id_str" : "459221682532532224",
  "text" : "Just realized it's my 1-year anniversary of transitioning to a PM role at Twitter. The stuff we work on is just getting better and better.",
  "id" : 459221682532532224,
  "created_at" : "2014-04-24 06:45:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "Alex Payne",
      "screen_name" : "al3x",
      "indices" : [ 21, 26 ],
      "id_str" : "18713",
      "id" : 18713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/kDn3ZXmrvR",
      "expanded_url" : "https:\/\/al3x.net\/2014\/04\/23\/mob.html",
      "display_url" : "al3x.net\/2014\/04\/23\/mob\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459205172095238144",
  "text" : "RT @isaach: in which @al3x is eloquent and enviably smart, as usual: \"Mob Rule\" https:\/\/t.co\/kDn3ZXmrvR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alex Payne",
        "screen_name" : "al3x",
        "indices" : [ 9, 14 ],
        "id_str" : "18713",
        "id" : 18713
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/kDn3ZXmrvR",
        "expanded_url" : "https:\/\/al3x.net\/2014\/04\/23\/mob.html",
        "display_url" : "al3x.net\/2014\/04\/23\/mob\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "459195288473706496",
    "text" : "in which @al3x is eloquent and enviably smart, as usual: \"Mob Rule\" https:\/\/t.co\/kDn3ZXmrvR",
    "id" : 459195288473706496,
    "created_at" : "2014-04-24 05:01:02 +0000",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430605387117494272\/lmplHwca_normal.png",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 459205172095238144,
  "created_at" : "2014-04-24 05:40:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Ludf4IsAs0",
      "expanded_url" : "https:\/\/flic.kr\/p\/nj6p76",
      "display_url" : "flic.kr\/p\/nj6p76"
    } ]
  },
  "geo" : { },
  "id_str" : "459203566469931008",
  "text" : "8:36pm Was drinking whiskey and finishing up Monument Valley. It all made me strangely anxious. https:\/\/t.co\/Ludf4IsAs0",
  "id" : 459203566469931008,
  "created_at" : "2014-04-24 05:33:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Byttow",
      "screen_name" : "davidbyttow",
      "indices" : [ 3, 15 ],
      "id_str" : "19436496",
      "id" : 19436496
    }, {
      "name" : "Secret",
      "screen_name" : "getsecret",
      "indices" : [ 68, 78 ],
      "id_str" : "2244765331",
      "id" : 2244765331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/NcEt06LmYh",
      "expanded_url" : "https:\/\/www.secret.ly\/p\/hwlnusxobymxvkgjohzrgmwvnm",
      "display_url" : "secret.ly\/p\/hwlnusxobymx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459167080411975680",
  "text" : "RT @davidbyttow: Most amazing thread ever. \"Icons. Check in.\" \u2013 via @getsecret https:\/\/t.co\/NcEt06LmYh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Secret",
        "screen_name" : "getsecret",
        "indices" : [ 51, 61 ],
        "id_str" : "2244765331",
        "id" : 2244765331
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/NcEt06LmYh",
        "expanded_url" : "https:\/\/www.secret.ly\/p\/hwlnusxobymxvkgjohzrgmwvnm",
        "display_url" : "secret.ly\/p\/hwlnusxobymx\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "459163001967214592",
    "text" : "Most amazing thread ever. \"Icons. Check in.\" \u2013 via @getsecret https:\/\/t.co\/NcEt06LmYh",
    "id" : 459163001967214592,
    "created_at" : "2014-04-24 02:52:45 +0000",
    "user" : {
      "name" : "David Byttow",
      "screen_name" : "davidbyttow",
      "protected" : false,
      "id_str" : "19436496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460878180996218880\/yHFQxKaZ_normal.jpeg",
      "id" : 19436496,
      "verified" : false
    }
  },
  "id" : 459167080411975680,
  "created_at" : "2014-04-24 03:08:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farhad Manjoo",
      "screen_name" : "fmanjoo",
      "indices" : [ 3, 11 ],
      "id_str" : "2195241",
      "id" : 2195241
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 93, 101 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ybvsl4defi",
      "expanded_url" : "http:\/\/nyti.ms\/1npV44S",
      "display_url" : "nyti.ms\/1npV44S"
    } ]
  },
  "geo" : { },
  "id_str" : "459121703159750657",
  "text" : "RT @fmanjoo: iPhone hearing aids are so amazing even normal-hearing folks will want them. My @nytimes piece on our bionic future. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 80, 88 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/ybvsl4defi",
        "expanded_url" : "http:\/\/nyti.ms\/1npV44S",
        "display_url" : "nyti.ms\/1npV44S"
      } ]
    },
    "geo" : { },
    "id_str" : "459118898844303360",
    "text" : "iPhone hearing aids are so amazing even normal-hearing folks will want them. My @nytimes piece on our bionic future. http:\/\/t.co\/ybvsl4defi",
    "id" : 459118898844303360,
    "created_at" : "2014-04-23 23:57:30 +0000",
    "user" : {
      "name" : "Farhad Manjoo",
      "screen_name" : "fmanjoo",
      "protected" : false,
      "id_str" : "2195241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/424235863250173952\/0xeLHVmD_normal.jpeg",
      "id" : 2195241,
      "verified" : true
    }
  },
  "id" : 459121703159750657,
  "created_at" : "2014-04-24 00:08:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Chang",
      "screen_name" : "emilychangtv",
      "indices" : [ 3, 16 ],
      "id_str" : "74130577",
      "id" : 74130577
    }, {
      "name" : "Jonathan Stull",
      "screen_name" : "jonstull",
      "indices" : [ 76, 85 ],
      "id_str" : "31591642",
      "id" : 31591642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/slh0voiRjd",
      "expanded_url" : "http:\/\/ow.ly\/w5Q74",
      "display_url" : "ow.ly\/w5Q74"
    } ]
  },
  "geo" : { },
  "id_str" : "459092041218027520",
  "text" : "RT @emilychangtv: How having a child changes you, according to the data via @jonstull http:\/\/t.co\/slh0voiRjd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootSuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Stull",
        "screen_name" : "jonstull",
        "indices" : [ 58, 67 ],
        "id_str" : "31591642",
        "id" : 31591642
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/slh0voiRjd",
        "expanded_url" : "http:\/\/ow.ly\/w5Q74",
        "display_url" : "ow.ly\/w5Q74"
      } ]
    },
    "geo" : { },
    "id_str" : "459088079585038337",
    "text" : "How having a child changes you, according to the data via @jonstull http:\/\/t.co\/slh0voiRjd",
    "id" : 459088079585038337,
    "created_at" : "2014-04-23 21:55:02 +0000",
    "user" : {
      "name" : "Emily Chang",
      "screen_name" : "emilychangtv",
      "protected" : false,
      "id_str" : "74130577",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1153501347\/emily-chang_normal.jpg",
      "id" : 74130577,
      "verified" : true
    }
  },
  "id" : 459092041218027520,
  "created_at" : "2014-04-23 22:10:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Sherman",
      "screen_name" : "toddsherman",
      "indices" : [ 0, 12 ],
      "id_str" : "10431862",
      "id" : 10431862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458985863767015425",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763283272, -122.4167277563 ]
  },
  "id_str" : "458987723873722369",
  "in_reply_to_user_id" : 10431862,
  "text" : "@toddsherman I haven't, I'll check it out. This is from Creativity, Inc.",
  "id" : 458987723873722369,
  "in_reply_to_status_id" : 458985863767015425,
  "created_at" : "2014-04-23 15:16:15 +0000",
  "in_reply_to_screen_name" : "toddsherman",
  "in_reply_to_user_id_str" : "10431862",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edwin Catmull",
      "screen_name" : "edcatmull",
      "indices" : [ 100, 110 ],
      "id_str" : "60644920",
      "id" : 60644920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458984484893761536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.782883109, -122.4045434672 ]
  },
  "id_str" : "458985400124448768",
  "in_reply_to_user_id" : 2185,
  "text" : "\"Find, develop, and support good people and they will in turn find, develop, and own good ideas.\" - @edcatmull",
  "id" : 458985400124448768,
  "in_reply_to_status_id" : 458984484893761536,
  "created_at" : "2014-04-23 15:07:01 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8088488245, -122.3176137835 ]
  },
  "id_str" : "458984484893761536",
  "text" : "\"Too many of us think of ideas as being singular, as if they float in the ether fully formed, independent of the ppl who wrestle with them.\"",
  "id" : 458984484893761536,
  "created_at" : "2014-04-23 15:03:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458980083001462784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8283288296, -122.2656586119 ]
  },
  "id_str" : "458980351331663872",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Yeah, that makes more sense.",
  "id" : 458980351331663872,
  "in_reply_to_status_id" : 458980083001462784,
  "created_at" : "2014-04-23 14:46:57 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458979512752279552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8484729459, -122.2712604974 ]
  },
  "id_str" : "458979843409850369",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert No.",
  "id" : 458979843409850369,
  "in_reply_to_status_id" : 458979512752279552,
  "created_at" : "2014-04-23 14:44:56 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    }, {
      "name" : "Anne Elizabeth Moore",
      "screen_name" : "superanne",
      "indices" : [ 8, 18 ],
      "id_str" : "16055954",
      "id" : 16055954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458977534332252160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8501980084, -122.2697521629 ]
  },
  "id_str" : "458979814884405248",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim @superanne \"I would give my life to save the brand.\" \"I would kill a man.\" \"I have a brand tattoo.\"",
  "id" : 458979814884405248,
  "in_reply_to_status_id" : 458977534332252160,
  "created_at" : "2014-04-23 14:44:49 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458978526885330944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8534225173, -122.270571109 ]
  },
  "id_str" : "458978957325381632",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert All of them have the same content issues. My only workable solution is to keep them all and hope 1 has the show\/movie I want.",
  "id" : 458978957325381632,
  "in_reply_to_status_id" : 458978526885330944,
  "created_at" : "2014-04-23 14:41:25 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458977965863612416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8534430438, -122.2706705621 ]
  },
  "id_str" : "458978289688641536",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert That's true if and only if you and others actually do cancel. What's your best alternative?",
  "id" : 458978289688641536,
  "in_reply_to_status_id" : 458977965863612416,
  "created_at" : "2014-04-23 14:38:46 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458973456227647488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8532866505, -122.2707185125 ]
  },
  "id_str" : "458977538316849153",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert But there is no straight-forward path. Everyone is trying to maintain exclusive rights to the best content.",
  "id" : 458977538316849153,
  "in_reply_to_status_id" : 458973456227647488,
  "created_at" : "2014-04-23 14:35:47 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458964610209808385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596852208, -122.2754577735 ]
  },
  "id_str" : "458969882239848448",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert True but that's how you dismantle an entrenched industry. Pick away from the bottom til the top can't hold.",
  "id" : 458969882239848448,
  "in_reply_to_status_id" : 458964610209808385,
  "created_at" : "2014-04-23 14:05:21 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458963823488401408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596789939, -122.2755012345 ]
  },
  "id_str" : "458966969182474242",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler Because Apple would take 30%, right?",
  "id" : 458966969182474242,
  "in_reply_to_status_id" : 458963823488401408,
  "created_at" : "2014-04-23 13:53:47 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458850574893469696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596921605, -122.2754508064 ]
  },
  "id_str" : "458852305287143424",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Such a good documentary!",
  "id" : 458852305287143424,
  "in_reply_to_status_id" : 458850574893469696,
  "created_at" : "2014-04-23 06:18:09 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 7, 14 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 16, 20 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/458818885492305920\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/oqgDKEnDlo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl4NWCYCQAA7EVs.jpg",
      "id_str" : "458818884284334080",
      "id" : 458818884284334080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl4NWCYCQAA7EVs.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/oqgDKEnDlo"
    } ],
    "hashtags" : [ {
      "text" : "burgers",
      "indices" : [ 28, 36 ]
    }, {
      "text" : "beer",
      "indices" : [ 38, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597073071, -122.2754654848 ]
  },
  "id_str" : "458818885492305920",
  "text" : "8:36pm @Sharon, @Ian, Sean, #burgers, #beer http:\/\/t.co\/oqgDKEnDlo",
  "id" : 458818885492305920,
  "created_at" : "2014-04-23 04:05:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Costa",
      "screen_name" : "jasoncosta",
      "indices" : [ 0, 11 ],
      "id_str" : "14927800",
      "id" : 14927800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458787797038424064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.850495847, -122.2785833013 ]
  },
  "id_str" : "458789619161501696",
  "in_reply_to_user_id" : 14927800,
  "text" : "@jasoncosta Yes! Loved that too! It's extra good to hear it all in Ed's words too. The Steve Jobs stuff especially.",
  "id" : 458789619161501696,
  "in_reply_to_status_id" : 458787797038424064,
  "created_at" : "2014-04-23 02:09:03 +0000",
  "in_reply_to_screen_name" : "jasoncosta",
  "in_reply_to_user_id_str" : "14927800",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edwin Catmull",
      "screen_name" : "edcatmull",
      "indices" : [ 14, 24 ],
      "id_str" : "60644920",
      "id" : 60644920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8504938376, -122.2784309523 ]
  },
  "id_str" : "458785873597718528",
  "text" : "So far loving @edcatmull's book. Pixar should make a film about its own history... plenty of plot twists and wacky characters.",
  "id" : 458785873597718528,
  "created_at" : "2014-04-23 01:54:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    }, {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 14, 24 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458767610448859136",
  "geo" : { },
  "id_str" : "458768165023907840",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel @helenjane Or really just \u201Cmissed opportunities earlier in life, thus mis-projecting frustrations\/insecurities guys\u201D?",
  "id" : 458768165023907840,
  "in_reply_to_status_id" : 458767610448859136,
  "created_at" : "2014-04-23 00:43:48 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 0, 4 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458766019322863616",
  "geo" : { },
  "id_str" : "458767602286743552",
  "in_reply_to_user_id" : 259,
  "text" : "@ian It\u2019s like an iWatch for your bedside table? Disrupting clocks? I think magnets are involved.",
  "id" : 458767602286743552,
  "in_reply_to_status_id" : 458766019322863616,
  "created_at" : "2014-04-23 00:41:34 +0000",
  "in_reply_to_screen_name" : "ian",
  "in_reply_to_user_id_str" : "259",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458735713802911744",
  "geo" : { },
  "id_str" : "458735998407430144",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie Next time you should also  include the O-&lt;\u2014&lt;",
  "id" : 458735998407430144,
  "in_reply_to_status_id" : 458735713802911744,
  "created_at" : "2014-04-22 22:35:59 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/fSO1fqTA1H",
      "expanded_url" : "https:\/\/twitter.com\/mathowie\/status\/458732705530650624",
      "display_url" : "twitter.com\/mathowie\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "458735354703409153",
  "geo" : { },
  "id_str" : "458735468666839040",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie Yeah. Actually the top link works a bit better for the big picture: https:\/\/t.co\/fSO1fqTA1H",
  "id" : 458735468666839040,
  "in_reply_to_status_id" : 458735354703409153,
  "created_at" : "2014-04-22 22:33:53 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/L6eKIZ3YF0",
      "expanded_url" : "https:\/\/twitter.com\/mathowie\/status\/458734303136841728",
      "display_url" : "twitter.com\/mathowie\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "458735063312498689",
  "text" : "Move over Flappy Bird: https:\/\/t.co\/L6eKIZ3YF0",
  "id" : 458735063312498689,
  "created_at" : "2014-04-22 22:32:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravi Narasimhan",
      "screen_name" : "Ravi",
      "indices" : [ 0, 5 ],
      "id_str" : "20283354",
      "id" : 20283354
    }, {
      "name" : "Liz Ferrall-Nunge",
      "screen_name" : "enunge",
      "indices" : [ 6, 13 ],
      "id_str" : "29906864",
      "id" : 29906864
    }, {
      "name" : "Achievements",
      "screen_name" : "AchievementBird",
      "indices" : [ 88, 104 ],
      "id_str" : "1634177714",
      "id" : 1634177714
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458717320269938689",
  "geo" : { },
  "id_str" : "458717546821079040",
  "in_reply_to_user_id" : 20283354,
  "text" : "@Ravi @enunge It has been my best engagement all week! I'm expecting a good report from @achievementbird later this afternoon. :)",
  "id" : 458717546821079040,
  "in_reply_to_status_id" : 458717320269938689,
  "created_at" : "2014-04-22 21:22:40 +0000",
  "in_reply_to_screen_name" : "Ravi",
  "in_reply_to_user_id_str" : "20283354",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravi Narasimhan",
      "screen_name" : "Ravi",
      "indices" : [ 0, 5 ],
      "id_str" : "20283354",
      "id" : 20283354
    }, {
      "name" : "Liz Ferrall-Nunge",
      "screen_name" : "enunge",
      "indices" : [ 6, 13 ],
      "id_str" : "29906864",
      "id" : 29906864
    }, {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 14, 18 ],
      "id_str" : "14616067",
      "id" : 14616067
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 19, 25 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boycottme",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458715682327109632",
  "geo" : { },
  "id_str" : "458716564234063872",
  "in_reply_to_user_id" : 20283354,
  "text" : "@Ravi @enunge @ltm @couch The best part about this thread is that it's not even about faves received, but rather faves given. #boycottme",
  "id" : 458716564234063872,
  "in_reply_to_status_id" : 458715682327109632,
  "created_at" : "2014-04-22 21:18:46 +0000",
  "in_reply_to_screen_name" : "Ravi",
  "in_reply_to_user_id_str" : "20283354",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Ferrall-Nunge",
      "screen_name" : "enunge",
      "indices" : [ 0, 7 ],
      "id_str" : "29906864",
      "id" : 29906864
    }, {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 8, 12 ],
      "id_str" : "14616067",
      "id" : 14616067
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 13, 19 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458712859032420352",
  "geo" : { },
  "id_str" : "458713964013056000",
  "in_reply_to_user_id" : 29906864,
  "text" : "@enunge @ltm @couch Shoot, does that mean I lose my place in line to get some user research in 2015?",
  "id" : 458713964013056000,
  "in_reply_to_status_id" : 458712859032420352,
  "created_at" : "2014-04-22 21:08:26 +0000",
  "in_reply_to_screen_name" : "enunge",
  "in_reply_to_user_id_str" : "29906864",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alessandro Vernet",
      "screen_name" : "avernet",
      "indices" : [ 0, 8 ],
      "id_str" : "5664742",
      "id" : 5664742
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 12, 18 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458711017397055490",
  "geo" : { },
  "id_str" : "458712613728583680",
  "in_reply_to_user_id" : 5664742,
  "text" : "@avernet By @couch\u2019s holy decree.",
  "id" : 458712613728583680,
  "in_reply_to_status_id" : 458711017397055490,
  "created_at" : "2014-04-22 21:03:04 +0000",
  "in_reply_to_screen_name" : "avernet",
  "in_reply_to_user_id_str" : "5664742",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Ferrall-Nunge",
      "screen_name" : "enunge",
      "indices" : [ 0, 7 ],
      "id_str" : "29906864",
      "id" : 29906864
    }, {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 8, 12 ],
      "id_str" : "14616067",
      "id" : 14616067
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 13, 19 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458710180339781632",
  "geo" : { },
  "id_str" : "458712321385172993",
  "in_reply_to_user_id" : 29906864,
  "text" : "@enunge @ltm @couch Faves do not lie.",
  "id" : 458712321385172993,
  "in_reply_to_status_id" : 458710180339781632,
  "created_at" : "2014-04-22 21:01:54 +0000",
  "in_reply_to_screen_name" : "enunge",
  "in_reply_to_user_id_str" : "29906864",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 5, 11 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "raisethefavebar",
      "indices" : [ 59, 75 ]
    }, {
      "text" : "andspellfavewithane",
      "indices" : [ 76, 96 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458708984413683712",
  "geo" : { },
  "id_str" : "458709644303552513",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm @couch I only fave people who tweet better than I do. #raisethefavebar #andspellfavewithane",
  "id" : 458709644303552513,
  "in_reply_to_status_id" : 458708984413683712,
  "created_at" : "2014-04-22 20:51:16 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 65, 71 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458708830168170496",
  "text" : "According to my new web profile, my faves\/tweets ratio is 11:20. @couch says I need to get it closer to 1:1. Start tweeting better, friends.",
  "id" : 458708830168170496,
  "created_at" : "2014-04-22 20:48:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 0, 7 ],
      "id_str" : "47",
      "id" : 47
    }, {
      "name" : "Marc Andreessen",
      "screen_name" : "pmarca",
      "indices" : [ 8, 15 ],
      "id_str" : "5943622",
      "id" : 5943622
    }, {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 16, 27 ],
      "id_str" : "14620776",
      "id" : 14620776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458702166551560193",
  "geo" : { },
  "id_str" : "458702832003080193",
  "in_reply_to_user_id" : 47,
  "text" : "@kellan @pmarca @ellenchisa Yeah, losing all sorts of respect for people I used to respect this week.",
  "id" : 458702832003080193,
  "in_reply_to_status_id" : 458702166551560193,
  "created_at" : "2014-04-22 20:24:12 +0000",
  "in_reply_to_screen_name" : "kellan",
  "in_reply_to_user_id_str" : "47",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Y3VOV0XvRo",
      "expanded_url" : "https:\/\/blog.twitter.com\/2014\/your-new-web-profile-is-here",
      "display_url" : "blog.twitter.com\/2014\/your-new-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "458691379170783232",
  "text" : "RT @twitter: New web profiles are now available for everyone. Update yours today with a pinned Tweet or a new header image. https:\/\/t.co\/Y3\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/Y3VOV0XvRo",
        "expanded_url" : "https:\/\/blog.twitter.com\/2014\/your-new-web-profile-is-here",
        "display_url" : "blog.twitter.com\/2014\/your-new-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "458681331288121346",
    "text" : "New web profiles are now available for everyone. Update yours today with a pinned Tweet or a new header image. https:\/\/t.co\/Y3VOV0XvRo",
    "id" : 458681331288121346,
    "created_at" : "2014-04-22 18:58:45 +0000",
    "user" : {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "protected" : false,
      "id_str" : "783214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2284174758\/v65oai7fxn47qv9nectx_normal.png",
      "id" : 783214,
      "verified" : true
    }
  },
  "id" : 458691379170783232,
  "created_at" : "2014-04-22 19:38:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "indices" : [ 3, 15 ],
      "id_str" : "1532061",
      "id" : 1532061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458681373771853824",
  "text" : "RT @kevin2kelly: For most things in life (business, travel, and love), it is better to have more time than more money.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "458666573541441537",
    "text" : "For most things in life (business, travel, and love), it is better to have more time than more money.",
    "id" : 458666573541441537,
    "created_at" : "2014-04-22 18:00:07 +0000",
    "user" : {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "protected" : false,
      "id_str" : "1532061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/65000713\/KKlaughsm_normal.jpg",
      "id" : 1532061,
      "verified" : false
    }
  },
  "id" : 458681373771853824,
  "created_at" : "2014-04-22 18:58:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458663542565396480",
  "geo" : { },
  "id_str" : "458664165843144704",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright I tend to give the side that is has been pressured by society to remain silent the benefit of the doubt.",
  "id" : 458664165843144704,
  "in_reply_to_status_id" : 458663542565396480,
  "created_at" : "2014-04-22 17:50:33 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458663091820306433",
  "geo" : { },
  "id_str" : "458663816898035712",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright I'm sure it's not black and white. In my exp you don't have to be Evil to discriminate and misuse power. It can sneak up on you.",
  "id" : 458663816898035712,
  "in_reply_to_status_id" : 458663091820306433,
  "created_at" : "2014-04-22 17:49:10 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458625378748071937",
  "geo" : { },
  "id_str" : "458660482355048451",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright I don't, and have limited information just like everyone else. But to me, the vague \"mistakes\" and resignation speak volumes.",
  "id" : 458660482355048451,
  "in_reply_to_status_id" : 458625378748071937,
  "created_at" : "2014-04-22 17:35:55 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458440659754446848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596511707, -122.275583525 ]
  },
  "id_str" : "458502467819278336",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine If failure isn't disastrous then it's merely iteration\/experimentation. Fast iteration &gt; fast failure.",
  "id" : 458502467819278336,
  "in_reply_to_status_id" : 458440659754446848,
  "created_at" : "2014-04-22 07:08:01 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Ann Horvath",
      "screen_name" : "nrrrdcore",
      "indices" : [ 8, 18 ],
      "id_str" : "18496432",
      "id" : 18496432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596709716, -122.2755014432 ]
  },
  "id_str" : "458501551359680512",
  "text" : "On team @nrrrdcore.",
  "id" : 458501551359680512,
  "created_at" : "2014-04-22 07:04:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/458449754125385729\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/8NyXEbae1X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bly9nyLCUAA6ThE.jpg",
      "id_str" : "458449753265557504",
      "id" : 458449753265557504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bly9nyLCUAA6ThE.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 769
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 769
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/8NyXEbae1X"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596718223, -122.2755401688 ]
  },
  "id_str" : "458449754125385729",
  "text" : "8:36pm Niko's toes http:\/\/t.co\/8NyXEbae1X",
  "id" : 458449754125385729,
  "created_at" : "2014-04-22 03:38:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 0, 6 ],
      "id_str" : "42559115",
      "id" : 42559115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458433001383534592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596912041, -122.275538656 ]
  },
  "id_str" : "458433724023984128",
  "in_reply_to_user_id" : 42559115,
  "text" : "@joshm I'm drawing a complete blank. Everything feels rather predictable lately.",
  "id" : 458433724023984128,
  "in_reply_to_status_id" : 458433001383534592,
  "created_at" : "2014-04-22 02:34:51 +0000",
  "in_reply_to_screen_name" : "joshm",
  "in_reply_to_user_id_str" : "42559115",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kay Vreeland",
      "screen_name" : "cay_anchor",
      "indices" : [ 0, 11 ],
      "id_str" : "16275525",
      "id" : 16275525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458260266799489027",
  "geo" : { },
  "id_str" : "458312317042561024",
  "in_reply_to_user_id" : 16275525,
  "text" : "@cay_anchor It\u2019s most likely a bug. If anything urgent comes up before we fix it let her know and she\u2019ll make sure your streak isn\u2019t broken.",
  "id" : 458312317042561024,
  "in_reply_to_status_id" : 458260266799489027,
  "created_at" : "2014-04-21 18:32:26 +0000",
  "in_reply_to_screen_name" : "cay_anchor",
  "in_reply_to_user_id_str" : "16275525",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kay Vreeland",
      "screen_name" : "cay_anchor",
      "indices" : [ 0, 11 ],
      "id_str" : "16275525",
      "id" : 16275525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458255534534062081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859670301, -122.2754478828 ]
  },
  "id_str" : "458256211406626816",
  "in_reply_to_user_id" : 16275525,
  "text" : "@cay_anchor It must be a bug. Have you written in to support about it?",
  "id" : 458256211406626816,
  "in_reply_to_status_id" : 458255534534062081,
  "created_at" : "2014-04-21 14:49:29 +0000",
  "in_reply_to_screen_name" : "cay_anchor",
  "in_reply_to_user_id_str" : "16275525",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/458101982230622208\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/VFrzbLPRv9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BluBUyzCEAEiYso.jpg",
      "id_str" : "458101981341421569",
      "id" : 458101981341421569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BluBUyzCEAEiYso.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/VFrzbLPRv9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596289524, -122.2756146941 ]
  },
  "id_str" : "458101982230622208",
  "text" : "8:36pm Death and life of Niko's favorite Easter bunny piggy bank http:\/\/t.co\/VFrzbLPRv9",
  "id" : 458101982230622208,
  "created_at" : "2014-04-21 04:36:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458061021123723264",
  "geo" : { },
  "id_str" : "458064950326333440",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver Best of luck! \uD83C\uDFC3\uD83D\uDC4F\uD83D\uDC4F\uD83D\uDC4F",
  "id" : 458064950326333440,
  "in_reply_to_status_id" : 458061021123723264,
  "created_at" : "2014-04-21 02:09:29 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/458024186410061824\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/qw99IU0PlG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bls6jX7CAAAiCcr.jpg",
      "id_str" : "458024166499680256",
      "id" : 458024166499680256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bls6jX7CAAAiCcr.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qw99IU0PlG"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/458024186410061824\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/qw99IU0PlG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bls6kfJCAAAss33.jpg",
      "id_str" : "458024185617317888",
      "id" : 458024185617317888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bls6kfJCAAAss33.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qw99IU0PlG"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/458024186410061824\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/qw99IU0PlG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bls6jmOCAAAa1I8.jpg",
      "id_str" : "458024170337468416",
      "id" : 458024170337468416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bls6jmOCAAAa1I8.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qw99IU0PlG"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/458024186410061824\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/qw99IU0PlG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bls6haNCAAAW5x8.jpg",
      "id_str" : "458024132752310272",
      "id" : 458024132752310272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bls6haNCAAAW5x8.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qw99IU0PlG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859750893, -122.2755973322 ]
  },
  "id_str" : "458024186410061824",
  "text" : "4 happy things http:\/\/t.co\/qw99IU0PlG",
  "id" : 458024186410061824,
  "created_at" : "2014-04-20 23:27:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/457936009720631296\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/0ghxbLZZm7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlrqX6kCYAA-c4L.jpg",
      "id_str" : "457936008709824512",
      "id" : 457936008709824512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlrqX6kCYAA-c4L.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0ghxbLZZm7"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/457936009720631296\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/0ghxbLZZm7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlrqXtVCUAAI2wz.jpg",
      "id_str" : "457936005157244928",
      "id" : 457936005157244928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlrqXtVCUAAI2wz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0ghxbLZZm7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8561785602, -122.2756480795 ]
  },
  "id_str" : "457936009720631296",
  "text" : "Roller skate test drive http:\/\/t.co\/0ghxbLZZm7",
  "id" : 457936009720631296,
  "created_at" : "2014-04-20 17:37:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/457892602243592192\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/JE0GDics8f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlrC5NlCQAAm0rr.jpg",
      "id_str" : "457892600284856320",
      "id" : 457892600284856320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlrC5NlCQAAm0rr.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/JE0GDics8f"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597126296, -122.2754648143 ]
  },
  "id_str" : "457892602243592192",
  "text" : "Wisdom from \uD83D\uDC07 http:\/\/t.co\/JE0GDics8f",
  "id" : 457892602243592192,
  "created_at" : "2014-04-20 14:44:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kottke.org",
      "screen_name" : "kottke",
      "indices" : [ 3, 10 ],
      "id_str" : "14120215",
      "id" : 14120215
    }, {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "indices" : [ 24, 38 ],
      "id_str" : "204832963",
      "id" : 204832963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/Z0xmD08E1i",
      "expanded_url" : "http:\/\/kottke.org\/14\/04\/the-new-ten-commandments",
      "display_url" : "kottke.org\/14\/04\/the-new-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "457889548505079809",
  "text" : "RT @kottke: Courtesy of @TheTweetOfGod, a list of the new Ten Commandments http:\/\/t.co\/Z0xmD08E1i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/kottke.org\" rel=\"nofollow\"\u003Ekottke tweeter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "God",
        "screen_name" : "TheTweetOfGod",
        "indices" : [ 12, 26 ],
        "id_str" : "204832963",
        "id" : 204832963
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/Z0xmD08E1i",
        "expanded_url" : "http:\/\/kottke.org\/14\/04\/the-new-ten-commandments",
        "display_url" : "kottke.org\/14\/04\/the-new-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "457884145515917313",
    "text" : "Courtesy of @TheTweetOfGod, a list of the new Ten Commandments http:\/\/t.co\/Z0xmD08E1i",
    "id" : 457884145515917313,
    "created_at" : "2014-04-20 14:11:02 +0000",
    "user" : {
      "name" : "kottke.org",
      "screen_name" : "kottke",
      "protected" : false,
      "id_str" : "14120215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421227828\/apple-touch-icon_normal.png",
      "id" : 14120215,
      "verified" : false
    }
  },
  "id" : 457889548505079809,
  "created_at" : "2014-04-20 14:32:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Harford",
      "screen_name" : "TimHarford",
      "indices" : [ 3, 14 ],
      "id_str" : "32493647",
      "id" : 32493647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/lHuv8E5beq",
      "expanded_url" : "http:\/\/dlvr.it\/5Rdc9y",
      "display_url" : "dlvr.it\/5Rdc9y"
    } ]
  },
  "geo" : { },
  "id_str" : "457887464263147520",
  "text" : "RT @TimHarford: Octagon utopias http:\/\/t.co\/lHuv8E5beq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/lHuv8E5beq",
        "expanded_url" : "http:\/\/dlvr.it\/5Rdc9y",
        "display_url" : "dlvr.it\/5Rdc9y"
      } ]
    },
    "geo" : { },
    "id_str" : "457790919719141376",
    "text" : "Octagon utopias http:\/\/t.co\/lHuv8E5beq",
    "id" : 457790919719141376,
    "created_at" : "2014-04-20 08:00:35 +0000",
    "user" : {
      "name" : "Tim Harford",
      "screen_name" : "TimHarford",
      "protected" : false,
      "id_str" : "32493647",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1338890256\/Harford_Cropped_normal.JPG",
      "id" : 32493647,
      "verified" : true
    }
  },
  "id" : 457887464263147520,
  "created_at" : "2014-04-20 14:24:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Hanna",
      "screen_name" : "kathleenhanna",
      "indices" : [ 108, 122 ],
      "id_str" : "257199215",
      "id" : 257199215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457783581746532353",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597011412, -122.2754900278 ]
  },
  "id_str" : "457786756843044864",
  "in_reply_to_user_id" : 2185,
  "text" : "\"I feel like there's always a suspicion around a woman's truth. A suspicion that you're... exaggerating.\" - @kathleenhanna",
  "id" : 457786756843044864,
  "in_reply_to_status_id" : 457783581746532353,
  "created_at" : "2014-04-20 07:44:02 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Hanna",
      "screen_name" : "kathleenhanna",
      "indices" : [ 12, 26 ],
      "id_str" : "257199215",
      "id" : 257199215
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "punksinger",
      "indices" : [ 27, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597110777, -122.2755213379 ]
  },
  "id_str" : "457783581746532353",
  "text" : "FWIW I love @kathleenhanna #punksinger",
  "id" : 457783581746532353,
  "created_at" : "2014-04-20 07:31:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tamy Emma Pepin",
      "screen_name" : "TamyEmmaPepin",
      "indices" : [ 3, 17 ],
      "id_str" : "20615786",
      "id" : 20615786
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TamyEmmaPepin\/status\/456154804096466944\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/MMx1SgoISW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlSWYKVCAAALq2_.jpg",
      "id_str" : "456154804104855552",
      "id" : 456154804104855552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlSWYKVCAAALq2_.jpg",
      "sizes" : [ {
        "h" : 1364,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 818,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1364,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/MMx1SgoISW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457757221669974018",
  "text" : "RT @TamyEmmaPepin: This New Yorker cover of people reading books at the airport is so 2006. Crazy how fast things change http:\/\/t.co\/MMx1Sg\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TamyEmmaPepin\/status\/456154804096466944\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/MMx1SgoISW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BlSWYKVCAAALq2_.jpg",
        "id_str" : "456154804104855552",
        "id" : 456154804104855552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlSWYKVCAAALq2_.jpg",
        "sizes" : [ {
          "h" : 1364,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 818,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1364,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/MMx1SgoISW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "456154804096466944",
    "text" : "This New Yorker cover of people reading books at the airport is so 2006. Crazy how fast things change http:\/\/t.co\/MMx1SgoISW",
    "id" : 456154804096466944,
    "created_at" : "2014-04-15 19:39:15 +0000",
    "user" : {
      "name" : "Tamy Emma Pepin",
      "screen_name" : "TamyEmmaPepin",
      "protected" : false,
      "id_str" : "20615786",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448824626118799361\/HOw4XCcJ_normal.jpeg",
      "id" : 20615786,
      "verified" : false
    }
  },
  "id" : 457757221669974018,
  "created_at" : "2014-04-20 05:46:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/457725934301216768\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/QMsezp0oNo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlorT5ZCUAEnLby.jpg",
      "id_str" : "457725932954865665",
      "id" : 457725932954865665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlorT5ZCUAEnLby.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/QMsezp0oNo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596726559, -122.2755874141 ]
  },
  "id_str" : "457725934301216768",
  "text" : "8:36pm Niko's Easter Eve pajama situation http:\/\/t.co\/QMsezp0oNo",
  "id" : 457725934301216768,
  "created_at" : "2014-04-20 03:42:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457698973973635072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597180046, -122.2755199696 ]
  },
  "id_str" : "457715725335941120",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew I'd be into that. I read them like candy.",
  "id" : 457715725335941120,
  "in_reply_to_status_id" : 457698973973635072,
  "created_at" : "2014-04-20 03:01:47 +0000",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457715328361844736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596133879, -122.2757099849 ]
  },
  "id_str" : "457715605454323712",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover It is a lot of money. Do you think he\/she is flexible? If so, make your best offer that you're willing to pay.",
  "id" : 457715605454323712,
  "in_reply_to_status_id" : 457715328361844736,
  "created_at" : "2014-04-20 03:01:18 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/jFqcJojfdY",
      "expanded_url" : "https:\/\/vine.co\/v\/M1FDnrrpTQq",
      "display_url" : "vine.co\/v\/M1FDnrrpTQq"
    } ]
  },
  "geo" : { },
  "id_str" : "457638739083558912",
  "text" : "Niko crashes some other kids birthday party https:\/\/t.co\/jFqcJojfdY",
  "id" : 457638739083558912,
  "created_at" : "2014-04-19 21:55:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffery Bennett",
      "screen_name" : "meandmybadself",
      "indices" : [ 0, 15 ],
      "id_str" : "1797691",
      "id" : 1797691
    }, {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 16, 25 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457573335002382337",
  "geo" : { },
  "id_str" : "457578992804315138",
  "in_reply_to_user_id" : 1797691,
  "text" : "@meandmybadself @mathowie I\u2019m interested in it as much for the history and voice as the advice. But will definitely check those 2 books too!",
  "id" : 457578992804315138,
  "in_reply_to_status_id" : 457573335002382337,
  "created_at" : "2014-04-19 17:58:27 +0000",
  "in_reply_to_screen_name" : "meandmybadself",
  "in_reply_to_user_id_str" : "1797691",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    }, {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "indices" : [ 10, 13 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457553666136735744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597745408, -122.2755194536 ]
  },
  "id_str" : "457556927996628992",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie @ev Great! I plan on doing the audiobook too. 45 minute walk+BART commute each day gets me through lots of books.",
  "id" : 457556927996628992,
  "in_reply_to_status_id" : 457553666136735744,
  "created_at" : "2014-04-19 16:30:47 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597296804, -122.2755801001 ]
  },
  "id_str" : "457550720774852610",
  "text" : "Is Ed Catmull's book Creativity Inc worth reading?",
  "id" : 457550720774852610,
  "created_at" : "2014-04-19 16:06:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dane Sanders",
      "screen_name" : "danesanders",
      "indices" : [ 21, 33 ],
      "id_str" : "13333322",
      "id" : 13333322
    }, {
      "name" : "750 Words",
      "screen_name" : "750words",
      "indices" : [ 40, 49 ],
      "id_str" : "401833335",
      "id" : 401833335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/H26z1NIZKg",
      "expanded_url" : "http:\/\/fasttrackcreative.com\/using-problems-build-business-episode-015\/",
      "display_url" : "fasttrackcreative.com\/using-problems\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859676686, -122.2755627813 ]
  },
  "id_str" : "457544081166462976",
  "text" : "I did a podcast with @danesanders about @750words and other stuff. Check it out! http:\/\/t.co\/H26z1NIZKg",
  "id" : 457544081166462976,
  "created_at" : "2014-04-19 15:39:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 3, 14 ],
      "id_str" : "784078",
      "id" : 784078
    }, {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 53, 58 ],
      "id_str" : "418",
      "id" : 418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/mTAgr1YefO",
      "expanded_url" : "https:\/\/medium.com\/p\/b98574b7212d",
      "display_url" : "medium.com\/p\/b98574b7212d"
    } ]
  },
  "geo" : { },
  "id_str" : "457366266047496192",
  "text" : "RT @alicetiara: Fantastic and very moving essay from @dens about running Boston which made me tear up https:\/\/t.co\/mTAgr1YefO",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dennis Crowley",
        "screen_name" : "dens",
        "indices" : [ 37, 42 ],
        "id_str" : "418",
        "id" : 418
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/mTAgr1YefO",
        "expanded_url" : "https:\/\/medium.com\/p\/b98574b7212d",
        "display_url" : "medium.com\/p\/b98574b7212d"
      } ]
    },
    "geo" : { },
    "id_str" : "457328506012434432",
    "text" : "Fantastic and very moving essay from @dens about running Boston which made me tear up https:\/\/t.co\/mTAgr1YefO",
    "id" : 457328506012434432,
    "created_at" : "2014-04-19 01:23:07 +0000",
    "user" : {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "protected" : false,
      "id_str" : "784078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/271273236\/me_laughing_cropped_normal.jpg",
      "id" : 784078,
      "verified" : false
    }
  },
  "id" : 457366266047496192,
  "created_at" : "2014-04-19 03:53:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Underwood",
      "screen_name" : "aunder",
      "indices" : [ 0, 7 ],
      "id_str" : "4265731",
      "id" : 4265731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457343629904711681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596736887, -122.2755118392 ]
  },
  "id_str" : "457363681358004225",
  "in_reply_to_user_id" : 4265731,
  "text" : "@aunder Happy early birthday, twitterversary, and vacation!",
  "id" : 457363681358004225,
  "in_reply_to_status_id" : 457343629904711681,
  "created_at" : "2014-04-19 03:42:53 +0000",
  "in_reply_to_screen_name" : "aunder",
  "in_reply_to_user_id_str" : "4265731",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457322214249885697",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596500587, -122.2754120083 ]
  },
  "id_str" : "457363196836200448",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb And it still seems like magic.",
  "id" : 457363196836200448,
  "in_reply_to_status_id" : 457322214249885697,
  "created_at" : "2014-04-19 03:40:58 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 3, 17 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 65, 72 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457362234071453696",
  "text" : "RT @buster_ebooks: Startup idea: nanobots that live on long past @buster",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/busterbenson.com\" rel=\"nofollow\"\u003EBuster eBooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 46, 53 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "457355190840999936",
    "text" : "Startup idea: nanobots that live on long past @buster",
    "id" : 457355190840999936,
    "created_at" : "2014-04-19 03:09:09 +0000",
    "user" : {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "protected" : false,
      "id_str" : "1901375096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000503050571\/228ccabfeeb4e55bd8e172595babe02e_normal.jpeg",
      "id" : 1901375096,
      "verified" : false
    }
  },
  "id" : 457362234071453696,
  "created_at" : "2014-04-19 03:37:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/457351186908073984\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/r1iCHwSeQh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BljWewLCcAAqBdq.jpg",
      "id_str" : "457351185993723904",
      "id" : 457351185993723904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BljWewLCcAAqBdq.jpg",
      "sizes" : [ {
        "h" : 959,
        "resize" : "fit",
        "w" : 959
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 959,
        "resize" : "fit",
        "w" : 959
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/r1iCHwSeQh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859761538, -122.2754632217 ]
  },
  "id_str" : "457351186908073984",
  "text" : "The Blue Devils http:\/\/t.co\/r1iCHwSeQh",
  "id" : 457351186908073984,
  "created_at" : "2014-04-19 02:53:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 96, 107 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/ptrQRPwacM",
      "expanded_url" : "http:\/\/parislemon.com\/post\/83149079864\/nike-killing-off-fuelband-exiting-hardware-as-apple",
      "display_url" : "parislemon.com\/post\/831490798\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "457323918118752256",
  "text" : "Nike's killing the Fuel Band? And news was scooped on Secret? Woah. http:\/\/t.co\/ptrQRPwacM \/via @parislemon",
  "id" : 457323918118752256,
  "created_at" : "2014-04-19 01:04:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/0jb2tNwVil",
      "expanded_url" : "http:\/\/flic.kr\/p\/naV5GD",
      "display_url" : "flic.kr\/p\/naV5GD"
    } ]
  },
  "geo" : { },
  "id_str" : "457013909162315776",
  "text" : "8:36pm Waiting for Kellianne and Sean for some dessert http:\/\/t.co\/0jb2tNwVil",
  "id" : 457013909162315776,
  "created_at" : "2014-04-18 04:33:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    }, {
      "name" : "Sammy Shahidi",
      "screen_name" : "sammy",
      "indices" : [ 10, 16 ],
      "id_str" : "21636767",
      "id" : 21636767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456992126727757825",
  "geo" : { },
  "id_str" : "456992252024205312",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover @sammy It really is.",
  "id" : 456992252024205312,
  "in_reply_to_status_id" : 456992126727757825,
  "created_at" : "2014-04-18 03:06:58 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sammy Shahidi",
      "screen_name" : "sammy",
      "indices" : [ 0, 6 ],
      "id_str" : "21636767",
      "id" : 21636767
    }, {
      "name" : "Shots",
      "screen_name" : "shots",
      "indices" : [ 48, 54 ],
      "id_str" : "140195719",
      "id" : 140195719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456917948209192960",
  "geo" : { },
  "id_str" : "456991986726084609",
  "in_reply_to_user_id" : 21636767,
  "text" : "@sammy Same! Really enjoyed learning more about @shots too... talk more soon!",
  "id" : 456991986726084609,
  "in_reply_to_status_id" : 456917948209192960,
  "created_at" : "2014-04-18 03:05:54 +0000",
  "in_reply_to_screen_name" : "sammy",
  "in_reply_to_user_id_str" : "21636767",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/2zxFVQOUP2",
      "expanded_url" : "https:\/\/about.twitter.com\/careers\/positions?jvi=oyYzYfwN,Job",
      "display_url" : "about.twitter.com\/careers\/positi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "456870380322299904",
  "text" : "Want to work together as my ads counterpart at Twitter? This is a great position if you like data and analytics: https:\/\/t.co\/2zxFVQOUP2",
  "id" : 456870380322299904,
  "created_at" : "2014-04-17 19:02:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david f. mendes",
      "screen_name" : "davidfmendes",
      "indices" : [ 0, 13 ],
      "id_str" : "6548802",
      "id" : 6548802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456842283980447744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762856723, -122.4167812213 ]
  },
  "id_str" : "456847668182925312",
  "in_reply_to_user_id" : 6548802,
  "text" : "@davidfmendes Hm, try buster@750words.com instead.",
  "id" : 456847668182925312,
  "in_reply_to_status_id" : 456842283980447744,
  "created_at" : "2014-04-17 17:32:26 +0000",
  "in_reply_to_screen_name" : "davidfmendes",
  "in_reply_to_user_id_str" : "6548802",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456839140429283328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7708199481, -122.4177175296 ]
  },
  "id_str" : "456840067680464896",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh I agree. I think tax preparers are making too much money though. Bots should take over and do them faster and cheaper, right?",
  "id" : 456840067680464896,
  "in_reply_to_status_id" : 456839140429283328,
  "created_at" : "2014-04-17 17:02:14 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762754971, -122.4167763187 ]
  },
  "id_str" : "456838904889372672",
  "text" : "What is more complex: the stock market or the tax code? Can we just have high frequency traders to do our taxes too?",
  "id" : 456838904889372672,
  "created_at" : "2014-04-17 16:57:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david f. mendes",
      "screen_name" : "davidfmendes",
      "indices" : [ 0, 13 ],
      "id_str" : "6548802",
      "id" : 6548802
    }, {
      "name" : "750 Words",
      "screen_name" : "750words",
      "indices" : [ 68, 77 ],
      "id_str" : "401833335",
      "id" : 401833335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456837206011691008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762568567, -122.4168743127 ]
  },
  "id_str" : "456837580055519232",
  "in_reply_to_user_id" : 6548802,
  "text" : "@davidfmendes Sure thing! Best way to contact us is to email support@750words.com",
  "id" : 456837580055519232,
  "in_reply_to_status_id" : 456837206011691008,
  "created_at" : "2014-04-17 16:52:21 +0000",
  "in_reply_to_screen_name" : "davidfmendes",
  "in_reply_to_user_id_str" : "6548802",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456815002650173440",
  "geo" : { },
  "id_str" : "456830648792002560",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright Wait, you're right. Sorry, was on my phone. Yeah, I agree it's confusing\u2026 could be an artifact of their data sources.",
  "id" : 456830648792002560,
  "in_reply_to_status_id" : 456815002650173440,
  "created_at" : "2014-04-17 16:24:48 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456807166557814784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8593721986, -122.275233809 ]
  },
  "id_str" : "456810830781095936",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright The former masks relative change in balance of causes, which is important to the \"how\".",
  "id" : 456810830781095936,
  "in_reply_to_status_id" : 456807166557814784,
  "created_at" : "2014-04-17 15:06:03 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/3ac46BTdht",
      "expanded_url" : "http:\/\/www.bloomberg.com\/dataview\/2014-04-17\/how-americans-die.html",
      "display_url" : "bloomberg.com\/dataview\/2014-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8605239659, -122.2756340499 ]
  },
  "id_str" : "456805360657907712",
  "text" : "I wish more stories presented data like this. Really great. \"How Americans Die\" http:\/\/t.co\/3ac46BTdht",
  "id" : 456805360657907712,
  "created_at" : "2014-04-17 14:44:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelton Lynn",
      "screen_name" : "keltonlynn",
      "indices" : [ 3, 14 ],
      "id_str" : "27674040",
      "id" : 27674040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/L4aDOhfpEc",
      "expanded_url" : "https:\/\/blog.twitter.com\/2014\/a-new-way-to-promote-mobile-apps-to-1-billion-devices-both-on-and-off-twitter",
      "display_url" : "blog.twitter.com\/2014\/a-new-way\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "456795591129833473",
  "text" : "RT @keltonlynn: A new way to promote mobile apps to 1 billion devices, both on and off-Twitter https:\/\/t.co\/L4aDOhfpEc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/L4aDOhfpEc",
        "expanded_url" : "https:\/\/blog.twitter.com\/2014\/a-new-way-to-promote-mobile-apps-to-1-billion-devices-both-on-and-off-twitter",
        "display_url" : "blog.twitter.com\/2014\/a-new-way\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "456780345178726400",
    "text" : "A new way to promote mobile apps to 1 billion devices, both on and off-Twitter https:\/\/t.co\/L4aDOhfpEc",
    "id" : 456780345178726400,
    "created_at" : "2014-04-17 13:04:55 +0000",
    "user" : {
      "name" : "Kelton Lynn",
      "screen_name" : "keltonlynn",
      "protected" : false,
      "id_str" : "27674040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3513249404\/93b48ae5438afc48a28b1ca9ad0a67c8_normal.jpeg",
      "id" : 27674040,
      "verified" : false
    }
  },
  "id" : 456795591129833473,
  "created_at" : "2014-04-17 14:05:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 41, 51 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cosmos",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/VtInnrTluq",
      "expanded_url" : "http:\/\/flic.kr\/p\/n9WMSd",
      "display_url" : "flic.kr\/p\/n9WMSd"
    } ]
  },
  "geo" : { },
  "id_str" : "456666004446138369",
  "text" : "8:36pm \"It's history science cartoon!\" - @kellianne #cosmos http:\/\/t.co\/VtInnrTluq",
  "id" : 456666004446138369,
  "created_at" : "2014-04-17 05:30:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rands",
      "screen_name" : "rands",
      "indices" : [ 34, 40 ],
      "id_str" : "30923",
      "id" : 30923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/TqMjGcqh83",
      "expanded_url" : "http:\/\/blog.codinghorror.com\/three-things\/",
      "display_url" : "blog.codinghorror.com\/three-things\/"
    } ]
  },
  "in_reply_to_status_id_str" : "456503007224397827",
  "geo" : { },
  "id_str" : "456503640157458432",
  "in_reply_to_user_id" : 30923,
  "text" : "Yes! Death to to-do list apps! RT @rands: What three things do you need to do today? http:\/\/t.co\/TqMjGcqh83",
  "id" : 456503640157458432,
  "in_reply_to_status_id" : 456503007224397827,
  "created_at" : "2014-04-16 18:45:23 +0000",
  "in_reply_to_screen_name" : "rands",
  "in_reply_to_user_id_str" : "30923",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah craig",
      "screen_name" : "micahcraig",
      "indices" : [ 0, 11 ],
      "id_str" : "6462772",
      "id" : 6462772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456434560650080257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596969582, -122.2753648252 ]
  },
  "id_str" : "456435021088190466",
  "in_reply_to_user_id" : 6462772,
  "text" : "@micahcraig \uD83D\uDE1C\uD83D\uDC4D",
  "id" : 456435021088190466,
  "in_reply_to_status_id" : 456434560650080257,
  "created_at" : "2014-04-16 14:12:43 +0000",
  "in_reply_to_screen_name" : "micahcraig",
  "in_reply_to_user_id_str" : "6462772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Morrill",
      "screen_name" : "DanielleMorrill",
      "indices" : [ 0, 16 ],
      "id_str" : "7017692",
      "id" : 7017692
    }, {
      "name" : "Marc Andreessen",
      "screen_name" : "pmarca",
      "indices" : [ 17, 24 ],
      "id_str" : "5943622",
      "id" : 5943622
    }, {
      "name" : "Carl Caum",
      "screen_name" : "ccaum",
      "indices" : [ 25, 31 ],
      "id_str" : "17928553",
      "id" : 17928553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456429929232465920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597198262, -122.2754713102 ]
  },
  "id_str" : "456434345356439552",
  "in_reply_to_user_id" : 7017692,
  "text" : "@DanielleMorrill @pmarca @ccaum In The Plex covers that period pretty well. Great book if you haven't read it.",
  "id" : 456434345356439552,
  "in_reply_to_status_id" : 456429929232465920,
  "created_at" : "2014-04-16 14:10:02 +0000",
  "in_reply_to_screen_name" : "DanielleMorrill",
  "in_reply_to_user_id_str" : "7017692",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah craig",
      "screen_name" : "micahcraig",
      "indices" : [ 0, 11 ],
      "id_str" : "6462772",
      "id" : 6462772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456433786947788800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596797907, -122.2753884729 ]
  },
  "id_str" : "456434124580872192",
  "in_reply_to_user_id" : 2185,
  "text" : "@micahcraig These are people who are used to winning all the time. This is their first taste of losing.",
  "id" : 456434124580872192,
  "in_reply_to_status_id" : 456433786947788800,
  "created_at" : "2014-04-16 14:09:10 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah craig",
      "screen_name" : "micahcraig",
      "indices" : [ 0, 11 ],
      "id_str" : "6462772",
      "id" : 6462772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456433092107186176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597066785, -122.2754077335 ]
  },
  "id_str" : "456433786947788800",
  "in_reply_to_user_id" : 6462772,
  "text" : "@micahcraig True, in a sense. The disruptive nature of HFT is in the way it beats big institutions to some money and changes their workflow.",
  "id" : 456433786947788800,
  "in_reply_to_status_id" : 456433092107186176,
  "created_at" : "2014-04-16 14:07:49 +0000",
  "in_reply_to_screen_name" : "micahcraig",
  "in_reply_to_user_id_str" : "6462772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah craig",
      "screen_name" : "micahcraig",
      "indices" : [ 0, 11 ],
      "id_str" : "6462772",
      "id" : 6462772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456431101448187905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596883612, -122.2754059062 ]
  },
  "id_str" : "456431837355577344",
  "in_reply_to_user_id" : 6462772,
  "text" : "@micahcraig It's latency + algorithms + hardware. And access to collocation is governed by how much money you're willing to spend.",
  "id" : 456431837355577344,
  "in_reply_to_status_id" : 456431101448187905,
  "created_at" : "2014-04-16 14:00:04 +0000",
  "in_reply_to_screen_name" : "micahcraig",
  "in_reply_to_user_id_str" : "6462772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "indices" : [ 3, 13 ],
      "id_str" : "18622869",
      "id" : 18622869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/v1Fe3l7s8C",
      "expanded_url" : "http:\/\/bit.ly\/1m7jLCK",
      "display_url" : "bit.ly\/1m7jLCK"
    } ]
  },
  "geo" : { },
  "id_str" : "456430248498716672",
  "text" : "RT @ezraklein: \"normcore is not about disappearing into a crowd, it's about standing out from...designer wear.\" http:\/\/t.co\/v1Fe3l7s8C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/v1Fe3l7s8C",
        "expanded_url" : "http:\/\/bit.ly\/1m7jLCK",
        "display_url" : "bit.ly\/1m7jLCK"
      } ]
    },
    "geo" : { },
    "id_str" : "456410785422393345",
    "text" : "\"normcore is not about disappearing into a crowd, it's about standing out from...designer wear.\" http:\/\/t.co\/v1Fe3l7s8C",
    "id" : 456410785422393345,
    "created_at" : "2014-04-16 12:36:25 +0000",
    "user" : {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "protected" : false,
      "id_str" : "18622869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430528937022595072\/ivuRfUNj_normal.jpeg",
      "id" : 18622869,
      "verified" : true
    }
  },
  "id" : 456430248498716672,
  "created_at" : "2014-04-16 13:53:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lewis",
      "screen_name" : "plewis67",
      "indices" : [ 0, 9 ],
      "id_str" : "251583860",
      "id" : 251583860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456428388350046209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859646118, -122.2753710616 ]
  },
  "id_str" : "456429208961445889",
  "in_reply_to_user_id" : 251583860,
  "text" : "@plewis67 True. There are certainly some crimes involved in blatantly cheating customers. I just don't think front-running is one of them.",
  "id" : 456429208961445889,
  "in_reply_to_status_id" : 456428388350046209,
  "created_at" : "2014-04-16 13:49:38 +0000",
  "in_reply_to_screen_name" : "plewis67",
  "in_reply_to_user_id_str" : "251583860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lewis",
      "screen_name" : "plewis67",
      "indices" : [ 0, 9 ],
      "id_str" : "251583860",
      "id" : 251583860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456426317018185729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597243204, -122.2754292968 ]
  },
  "id_str" : "456427263651622914",
  "in_reply_to_user_id" : 2185,
  "text" : "@plewis67 To me it reads \"We're used to making more money. If we get paid less we might stop doing this civic duty &amp; retire to our yachts.\"",
  "id" : 456427263651622914,
  "in_reply_to_status_id" : 456426317018185729,
  "created_at" : "2014-04-16 13:41:54 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lewis",
      "screen_name" : "plewis67",
      "indices" : [ 0, 9 ],
      "id_str" : "251583860",
      "id" : 251583860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456425032487419905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597168047, -122.275448525 ]
  },
  "id_str" : "456426317018185729",
  "in_reply_to_user_id" : 251583860,
  "text" : "@plewis67 I read that but wasn't persuaded. \"Reducing incentive to find information\" seems wrong. Obviously incentive is high for HFT.",
  "id" : 456426317018185729,
  "in_reply_to_status_id" : 456425032487419905,
  "created_at" : "2014-04-16 13:38:08 +0000",
  "in_reply_to_screen_name" : "plewis67",
  "in_reply_to_user_id_str" : "251583860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah craig",
      "screen_name" : "micahcraig",
      "indices" : [ 0, 11 ],
      "id_str" : "6462772",
      "id" : 6462772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456394509677363201",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859696243, -122.2753067316 ]
  },
  "id_str" : "456425553319301120",
  "in_reply_to_user_id" : 6462772,
  "text" : "@micahcraig True but they are both races for computing power. Is it unfair for slower computers to mine less bitcoin?",
  "id" : 456425553319301120,
  "in_reply_to_status_id" : 456394509677363201,
  "created_at" : "2014-04-16 13:35:06 +0000",
  "in_reply_to_screen_name" : "micahcraig",
  "in_reply_to_user_id_str" : "6462772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Bruchez",
      "screen_name" : "ebruchez",
      "indices" : [ 0, 9 ],
      "id_str" : "6087842",
      "id" : 6087842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456313149629542400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596619175, -122.2754870257 ]
  },
  "id_str" : "456323627718168576",
  "in_reply_to_user_id" : 6087842,
  "text" : "@ebruchez Do read up and let me know what you come to.",
  "id" : 456323627718168576,
  "in_reply_to_status_id" : 456313149629542400,
  "created_at" : "2014-04-16 06:50:05 +0000",
  "in_reply_to_screen_name" : "ebruchez",
  "in_reply_to_user_id_str" : "6087842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Bruchez",
      "screen_name" : "ebruchez",
      "indices" : [ 0, 9 ],
      "id_str" : "6087842",
      "id" : 6087842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456311658453811201",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597026971, -122.2755276785 ]
  },
  "id_str" : "456312163414446081",
  "in_reply_to_user_id" : 6087842,
  "text" : "@ebruchez There are some! Lower fees, smaller spread, everyone gets NBBO prices, more liquidity, to name a few.",
  "id" : 456312163414446081,
  "in_reply_to_status_id" : 456311658453811201,
  "created_at" : "2014-04-16 06:04:32 +0000",
  "in_reply_to_screen_name" : "ebruchez",
  "in_reply_to_user_id_str" : "6087842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 0, 12 ],
      "id_str" : "7413762",
      "id" : 7413762
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 13, 20 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456292250956201985",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8067346888, -122.2703125686 ]
  },
  "id_str" : "456293320998678528",
  "in_reply_to_user_id" : 7413762,
  "text" : "@davealevine @harryh Front-run is also a misleading term. Do I front-run you if my internet connection is faster as we tweet?",
  "id" : 456293320998678528,
  "in_reply_to_status_id" : 456292250956201985,
  "created_at" : "2014-04-16 04:49:39 +0000",
  "in_reply_to_screen_name" : "davealevine",
  "in_reply_to_user_id_str" : "7413762",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "David Aron Levine",
      "screen_name" : "davealevine",
      "indices" : [ 8, 20 ],
      "id_str" : "7413762",
      "id" : 7413762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456289902112833536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8067325446, -122.2703125476 ]
  },
  "id_str" : "456291245703172096",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @davealevine Calling them \"old people\" is disingenuous. The real \"victims\" of HFT are the biggest, evilest, banks in the world.",
  "id" : 456291245703172096,
  "in_reply_to_status_id" : 456289902112833536,
  "created_at" : "2014-04-16 04:41:25 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/W43WDBRHCT",
      "expanded_url" : "http:\/\/flic.kr\/p\/na5Y6T",
      "display_url" : "flic.kr\/p\/na5Y6T"
    } ]
  },
  "geo" : { },
  "id_str" : "456275525451788288",
  "text" : "8:36pm Listening to an audiobook in a loud bar while friends are at Fox watching The Knife http:\/\/t.co\/W43WDBRHCT",
  "id" : 456275525451788288,
  "created_at" : "2014-04-16 03:38:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Butcher",
      "screen_name" : "tiz9000",
      "indices" : [ 0, 8 ],
      "id_str" : "93763839",
      "id" : 93763839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456256236292292608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8139933117, -122.2645951308 ]
  },
  "id_str" : "456256519474933760",
  "in_reply_to_user_id" : 2185,
  "text" : "@tiz9000 An easy way around it is to set limit orders and only buy from 1 exchange at a time. Also, small orders are not worth their time.",
  "id" : 456256519474933760,
  "in_reply_to_status_id" : 456256236292292608,
  "created_at" : "2014-04-16 02:23:25 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Butcher",
      "screen_name" : "tiz9000",
      "indices" : [ 0, 8 ],
      "id_str" : "93763839",
      "id" : 93763839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456248628781129728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8141058144, -122.2643503268 ]
  },
  "id_str" : "456256236292292608",
  "in_reply_to_user_id" : 93763839,
  "text" : "@tiz9000 You must work with different banks if you're getting transparent fees. Most HFT trades don't affect consumers like us.",
  "id" : 456256236292292608,
  "in_reply_to_status_id" : 456248628781129728,
  "created_at" : "2014-04-16 02:22:18 +0000",
  "in_reply_to_screen_name" : "tiz9000",
  "in_reply_to_user_id_str" : "93763839",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456235029983555585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8141101043, -122.2644423742 ]
  },
  "id_str" : "456235644071587840",
  "in_reply_to_user_id" : 2185,
  "text" : "HFT doesn't rig the market any more than bitcoin miners rig the bitcoin market. Work = reward. Arms race will drive profits to equilibrium.",
  "id" : 456235644071587840,
  "in_reply_to_status_id" : 456235029983555585,
  "created_at" : "2014-04-16 01:00:28 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456234506811215872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8141374828, -122.2644782885 ]
  },
  "id_str" : "456235029983555585",
  "in_reply_to_user_id" : 2185,
  "text" : "The tiny tax is *nothing* compared to the trading fees, fund fees, advisor fees, etc that have been in place forever.",
  "id" : 456235029983555585,
  "in_reply_to_status_id" : 456234506811215872,
  "created_at" : "2014-04-16 00:58:02 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8141101318, -122.2644423601 ]
  },
  "id_str" : "456234506811215872",
  "text" : "I've been obsessed with HFT lately. Reading Flash Boys now but still not buying the arguments against. Yes, it disrupts big orders--adapt!",
  "id" : 456234506811215872,
  "created_at" : "2014-04-16 00:55:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8142251727, -122.2644456291 ]
  },
  "id_str" : "456233408436256768",
  "text" : "An interesting perspective on high frequency trading: it reduces profits for everyone to flow money into building fiber optic networks.",
  "id" : 456233408436256768,
  "created_at" : "2014-04-16 00:51:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 9, 19 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456117247237300224",
  "geo" : { },
  "id_str" : "456118270198693888",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean @kellianne I take no responsibility for the thoughts or actions of my ebooks account. But I will take credit for the funny things.",
  "id" : 456118270198693888,
  "in_reply_to_status_id" : 456117247237300224,
  "created_at" : "2014-04-15 17:14:04 +0000",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Graf",
      "screen_name" : "danielgraf",
      "indices" : [ 0, 11 ],
      "id_str" : "24328692",
      "id" : 24328692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456117316300730369",
  "geo" : { },
  "id_str" : "456117926832009216",
  "in_reply_to_user_id" : 24328692,
  "text" : "@danielgraf Excited to have you here as well. Welcome!",
  "id" : 456117926832009216,
  "in_reply_to_status_id" : 456117316300730369,
  "created_at" : "2014-04-15 17:12:42 +0000",
  "in_reply_to_screen_name" : "danielgraf",
  "in_reply_to_user_id_str" : "24328692",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/NLKbu81kTq",
      "expanded_url" : "http:\/\/vox.com\/e\/5380615",
      "display_url" : "vox.com\/e\/5380615"
    } ]
  },
  "geo" : { },
  "id_str" : "456091009634414592",
  "text" : "RT @voxdotcom: High-frequency trading doesn't impact normal people: http:\/\/t.co\/NLKbu81kTq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.sbnation.com\" rel=\"nofollow\"\u003ESB Nation\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/NLKbu81kTq",
        "expanded_url" : "http:\/\/vox.com\/e\/5380615",
        "display_url" : "vox.com\/e\/5380615"
      } ]
    },
    "geo" : { },
    "id_str" : "456084703603212288",
    "text" : "High-frequency trading doesn't impact normal people: http:\/\/t.co\/NLKbu81kTq",
    "id" : 456084703603212288,
    "created_at" : "2014-04-15 15:00:41 +0000",
    "user" : {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "protected" : false,
      "id_str" : "2347049341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442785905246347265\/v6W3UuIL_normal.jpeg",
      "id" : 2347049341,
      "verified" : true
    }
  },
  "id" : 456091009634414592,
  "created_at" : "2014-04-15 15:25:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter API",
      "screen_name" : "twitterapi",
      "indices" : [ 12, 23 ],
      "id_str" : "6253282",
      "id" : 6253282
    }, {
      "name" : "Gnip, Inc.",
      "screen_name" : "Gnip",
      "indices" : [ 51, 56 ],
      "id_str" : "16958875",
      "id" : 16958875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/pIXKZa8udm",
      "expanded_url" : "https:\/\/blog.twitter.com\/2014\/twitter-welcomes-gnip-to-the-flock",
      "display_url" : "blog.twitter.com\/2014\/twitter-w\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "456056890774941697",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597388302, -122.2755601184 ]
  },
  "id_str" : "456087817773252609",
  "in_reply_to_user_id" : 6253282,
  "text" : "Awesome! RT @twitterapi: We have agreed to acquire @gnip, welcome to the flock! https:\/\/t.co\/pIXKZa8udm",
  "id" : 456087817773252609,
  "in_reply_to_status_id" : 456056890774941697,
  "created_at" : "2014-04-15 15:13:04 +0000",
  "in_reply_to_screen_name" : "twitterapi",
  "in_reply_to_user_id_str" : "6253282",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 3, 14 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456081149433888770",
  "text" : "RT @nikobenson: We will die in a long long time when our days are done.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.8597353864, -122.2755504267 ]
    },
    "id_str" : "455947834953433088",
    "text" : "We will die in a long long time when our days are done.",
    "id" : 455947834953433088,
    "created_at" : "2014-04-15 05:56:49 +0000",
    "user" : {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "protected" : false,
      "id_str" : "142467448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000616213793\/9f77fe6693d877565cd97b6a2381c40c_normal.jpeg",
      "id" : 142467448,
      "verified" : false
    }
  },
  "id" : 456081149433888770,
  "created_at" : "2014-04-15 14:46:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ameet Ranadive",
      "screen_name" : "ameet",
      "indices" : [ 0, 6 ],
      "id_str" : "5510452",
      "id" : 5510452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455950145503232000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596718936, -122.275515441 ]
  },
  "id_str" : "455962722035720192",
  "in_reply_to_user_id" : 5510452,
  "text" : "@ameet Yeah. I think we need a new stove.",
  "id" : 455962722035720192,
  "in_reply_to_status_id" : 455950145503232000,
  "created_at" : "2014-04-15 06:55:58 +0000",
  "in_reply_to_screen_name" : "ameet",
  "in_reply_to_user_id_str" : "5510452",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596516932, -122.2755780538 ]
  },
  "id_str" : "455946460333215744",
  "text" : "Just saw our stove on Mad Men.",
  "id" : 455946460333215744,
  "created_at" : "2014-04-15 05:51:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455929283928932352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596804012, -122.2755375692 ]
  },
  "id_str" : "455929973010743296",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun I wish there was an audiobook version!",
  "id" : 455929973010743296,
  "in_reply_to_status_id" : 455929283928932352,
  "created_at" : "2014-04-15 04:45:50 +0000",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455927262265614336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596942104, -122.2755494737 ]
  },
  "id_str" : "455927703472852992",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun Ooh, thanks. Was just in the mood for something like this.",
  "id" : 455927703472852992,
  "in_reply_to_status_id" : 455927262265614336,
  "created_at" : "2014-04-15 04:36:49 +0000",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/455916693542301696\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/Dhp6IkhWTj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlO90P4CAAAKDsU.jpg",
      "id_str" : "455916692606943232",
      "id" : 455916692606943232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlO90P4CAAAKDsU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Dhp6IkhWTj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597425686, -122.275597851 ]
  },
  "id_str" : "455916693542301696",
  "text" : "8:36pm Finished the alphabet train puzzle http:\/\/t.co\/Dhp6IkhWTj",
  "id" : 455916693542301696,
  "created_at" : "2014-04-15 03:53:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Grubb",
      "screen_name" : "TeddyG",
      "indices" : [ 0, 7 ],
      "id_str" : "676063",
      "id" : 676063
    }, {
      "name" : "Briana Tomkinson",
      "screen_name" : "breebop",
      "indices" : [ 8, 16 ],
      "id_str" : "15758414",
      "id" : 15758414
    }, {
      "name" : "Will Tomkinson",
      "screen_name" : "BoomTownBill",
      "indices" : [ 17, 30 ],
      "id_str" : "200533128",
      "id" : 200533128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455737374077497344",
  "geo" : { },
  "id_str" : "455764892155260928",
  "in_reply_to_user_id" : 676063,
  "text" : "@TeddyG @breebop @BoomTownBill I do stretch\/strength training a bit, but could do more. Are you able to run without pain?",
  "id" : 455764892155260928,
  "in_reply_to_status_id" : 455737374077497344,
  "created_at" : "2014-04-14 17:49:52 +0000",
  "in_reply_to_screen_name" : "TeddyG",
  "in_reply_to_user_id_str" : "676063",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Briana Tomkinson",
      "screen_name" : "breebop",
      "indices" : [ 0, 8 ],
      "id_str" : "15758414",
      "id" : 15758414
    }, {
      "name" : "Will Tomkinson",
      "screen_name" : "BoomTownBill",
      "indices" : [ 9, 22 ],
      "id_str" : "200533128",
      "id" : 200533128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455577145872355329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597859294, -122.275518207 ]
  },
  "id_str" : "455589014037200896",
  "in_reply_to_user_id" : 15758414,
  "text" : "@breebop @BoomTownBill Did anything end up helping?",
  "id" : 455589014037200896,
  "in_reply_to_status_id" : 455577145872355329,
  "created_at" : "2014-04-14 06:11:00 +0000",
  "in_reply_to_screen_name" : "breebop",
  "in_reply_to_user_id_str" : "15758414",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/455550829852762112\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/xGycoxMiPv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlJxEIZCYAAaUgP.jpg",
      "id_str" : "455550828103753728",
      "id" : 455550828103753728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlJxEIZCYAAaUgP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xGycoxMiPv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596670321, -122.2756700871 ]
  },
  "id_str" : "455550829852762112",
  "text" : "I'm so tired of my stupid knee. 1 bad hill shouldn't still be a problem 1.5yrs later. Gonna force next guy to X-ray. http:\/\/t.co\/xGycoxMiPv",
  "id" : 455550829852762112,
  "created_at" : "2014-04-14 03:39:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cosmos",
      "indices" : [ 37, 44 ]
    }, {
      "text" : "GameOfThrones",
      "indices" : [ 48, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455514953412141056",
  "text" : "RT @neiltyson: Decisions,.Decisions. #Cosmos vs #GameOfThrones. Hmm. I think I'll watch the Universe and DVR those \"Middle-Earth Sopranos\u201D.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cosmos",
        "indices" : [ 22, 29 ]
      }, {
        "text" : "GameOfThrones",
        "indices" : [ 33, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "455508269469925378",
    "text" : "Decisions,.Decisions. #Cosmos vs #GameOfThrones. Hmm. I think I'll watch the Universe and DVR those \"Middle-Earth Sopranos\u201D.",
    "id" : 455508269469925378,
    "created_at" : "2014-04-14 00:50:09 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 455514953412141056,
  "created_at" : "2014-04-14 01:16:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie",
      "screen_name" : "leslie_montelon",
      "indices" : [ 0, 16 ],
      "id_str" : "1217153329",
      "id" : 1217153329
    }, {
      "name" : "JEEBS\u2122 ",
      "screen_name" : "ArturoMacias05",
      "indices" : [ 17, 32 ],
      "id_str" : "989999107",
      "id" : 989999107
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woof",
      "indices" : [ 37, 42 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455484961194119168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596880707, -122.2755342441 ]
  },
  "id_str" : "455486436825772032",
  "in_reply_to_user_id" : 1217153329,
  "text" : "@leslie_montelon @ArturoMacias05 \uD83D\uDC36\uD83D\uDC36\uD83D\uDC36 #woof",
  "id" : 455486436825772032,
  "in_reply_to_status_id" : 455484961194119168,
  "created_at" : "2014-04-13 23:23:23 +0000",
  "in_reply_to_screen_name" : "leslie_montelon",
  "in_reply_to_user_id_str" : "1217153329",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JEEBS\u2122 ",
      "screen_name" : "ArturoMacias05",
      "indices" : [ 0, 15 ],
      "id_str" : "989999107",
      "id" : 989999107
    }, {
      "name" : "Leslie",
      "screen_name" : "leslie_montelon",
      "indices" : [ 16, 32 ],
      "id_str" : "1217153329",
      "id" : 1217153329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455481393045180416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597068635, -122.2756129641 ]
  },
  "id_str" : "455484797893091330",
  "in_reply_to_user_id" : 989999107,
  "text" : "@ArturoMacias05 @leslie_montelon I think you've got the wrong guy. \uD83D\uDE15",
  "id" : 455484797893091330,
  "in_reply_to_status_id" : 455481393045180416,
  "created_at" : "2014-04-13 23:16:52 +0000",
  "in_reply_to_screen_name" : "ArturoMacias05",
  "in_reply_to_user_id_str" : "989999107",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/455460708419764224\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/djevWDKY2N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlIfGa6CUAA-LsO.jpg",
      "id_str" : "455460707480260608",
      "id" : 455460707480260608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlIfGa6CUAA-LsO.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/djevWDKY2N"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/455460708419764224\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/djevWDKY2N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlIfEhkCUAIslJq.jpg",
      "id_str" : "455460674907295746",
      "id" : 455460674907295746,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlIfEhkCUAIslJq.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/djevWDKY2N"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859706427, -122.2755014432 ]
  },
  "id_str" : "455460708419764224",
  "text" : "Mt Diablo http:\/\/t.co\/djevWDKY2N",
  "id" : 455460708419764224,
  "created_at" : "2014-04-13 21:41:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/455458884711227392\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/rnCvSBDLLV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlIdcROCQAA8eBb.jpg",
      "id_str" : "455458883813654528",
      "id" : 455458883813654528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlIdcROCQAA8eBb.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rnCvSBDLLV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859706427, -122.2755257507 ]
  },
  "id_str" : "455458884711227392",
  "text" : "Respite from the hard life. http:\/\/t.co\/rnCvSBDLLV",
  "id" : 455458884711227392,
  "created_at" : "2014-04-13 21:33:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/83xZpv6Qun",
      "expanded_url" : "https:\/\/medium.com\/p\/946ee85dc231",
      "display_url" : "medium.com\/p\/946ee85dc231"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597208995, -122.2756348674 ]
  },
  "id_str" : "455019559871709185",
  "text" : "How to write your obituary in 5 minutes or less https:\/\/t.co\/83xZpv6Qun",
  "id" : 455019559871709185,
  "created_at" : "2014-04-12 16:28:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 117, 126 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/fY66KcN3ir",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/regajha\/how-privileged-are-you?s=mobile",
      "display_url" : "buzzfeed.com\/regajha\/how-pr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454862780068151297",
  "text" : "A worthwhile quiz. I live with 60 out of 100 points of privilege. How Privileged Are You? http:\/\/t.co\/fY66KcN3ir via @buzzfeed",
  "id" : 454862780068151297,
  "created_at" : "2014-04-12 06:05:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 16, 24 ],
      "id_str" : "5699",
      "id" : 5699
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 25, 32 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454857755426168832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597680018, -122.275575959 ]
  },
  "id_str" : "454858694631505921",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries @stewart @sippey Agreed. Also, Her's decision to move video to shirt pocket + audio in ear seems less threatening, somehow.",
  "id" : 454858694631505921,
  "in_reply_to_status_id" : 454857755426168832,
  "created_at" : "2014-04-12 05:48:58 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 16, 24 ],
      "id_str" : "5699",
      "id" : 5699
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 25, 32 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454856409104908288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597292529, -122.2755616357 ]
  },
  "id_str" : "454857076640976896",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries @stewart @sippey Good sci-fi is speculative fiction: accelerate today's problems by projecting them onto exaggerated tech.",
  "id" : 454857076640976896,
  "in_reply_to_status_id" : 454856409104908288,
  "created_at" : "2014-04-12 05:42:32 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 0, 8 ],
      "id_str" : "5699",
      "id" : 5699
    }, {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 9, 24 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 25, 32 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Ramez Naam",
      "screen_name" : "ramez",
      "indices" : [ 91, 97 ],
      "id_str" : "6044272",
      "id" : 6044272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454855146770411521",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597185411, -122.2755957976 ]
  },
  "id_str" : "454855374718238720",
  "in_reply_to_user_id" : 5699,
  "text" : "@stewart @mikeindustries @sippey I totally have, it's awesome. Also just finished Nexus by @ramez, equally thought-provoking.",
  "id" : 454855374718238720,
  "in_reply_to_status_id" : 454855146770411521,
  "created_at" : "2014-04-12 05:35:46 +0000",
  "in_reply_to_screen_name" : "stewart",
  "in_reply_to_user_id_str" : "5699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omid Ashtari",
      "screen_name" : "omid",
      "indices" : [ 0, 5 ],
      "id_str" : "114971521",
      "id" : 114971521
    }, {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 6, 21 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 22, 29 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454854617004642304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597550116, -122.2756174854 ]
  },
  "id_str" : "454854995880325120",
  "in_reply_to_user_id" : 114971521,
  "text" : "@omid @mikeindustries @sippey I think something complex like that will have to happen, or else the tech will be culturally rejected.",
  "id" : 454854995880325120,
  "in_reply_to_status_id" : 454854617004642304,
  "created_at" : "2014-04-12 05:34:16 +0000",
  "in_reply_to_screen_name" : "omid",
  "in_reply_to_user_id_str" : "114971521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 16, 23 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454854293636395008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596580634, -122.2754628026 ]
  },
  "id_str" : "454854582691045376",
  "in_reply_to_user_id" : 2185,
  "text" : "@mikeindustries @sippey That said, we already use visual field to store non-visual data (ie looking up when trying to remember something).",
  "id" : 454854582691045376,
  "in_reply_to_status_id" : 454854293636395008,
  "created_at" : "2014-04-12 05:32:38 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 16, 23 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454853465060044801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596928483, -122.2754804046 ]
  },
  "id_str" : "454854293636395008",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries @sippey Even if the technology physically disappears the social implications remain (I'm ignoring you while recording you).",
  "id" : 454854293636395008,
  "in_reply_to_status_id" : 454853465060044801,
  "created_at" : "2014-04-12 05:31:29 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454852087206014976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597456401, -122.2755962864 ]
  },
  "id_str" : "454852894701801472",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey Yeah it's just plain rude. Any idea how we'll ever make augmented vision socially acceptable? Or will it never happen?",
  "id" : 454852894701801472,
  "in_reply_to_status_id" : 454852087206014976,
  "created_at" : "2014-04-12 05:25:55 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454847794251984896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596923934, -122.275544053 ]
  },
  "id_str" : "454850174532079616",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey I agree, but think the aggressive camera is the real problem. Passive screen on its own would be much less an issue... just awkward.",
  "id" : 454850174532079616,
  "in_reply_to_status_id" : 454847794251984896,
  "created_at" : "2014-04-12 05:15:06 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/454831731355303938\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/TSh00ePiRc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk_jDIBCUAAQ7Ae.jpg",
      "id_str" : "454831730218651648",
      "id" : 454831730218651648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk_jDIBCUAAQ7Ae.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/TSh00ePiRc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.878669779, -122.2951086682 ]
  },
  "id_str" : "454831731355303938",
  "text" : "8:36pm Giant asparagus http:\/\/t.co\/TSh00ePiRc",
  "id" : 454831731355303938,
  "created_at" : "2014-04-12 04:01:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    }, {
      "name" : "elle luna",
      "screen_name" : "elleluna",
      "indices" : [ 5, 14 ],
      "id_str" : "21107053",
      "id" : 21107053
    }, {
      "name" : "Roz Savage",
      "screen_name" : "rozsavage",
      "indices" : [ 15, 25 ],
      "id_str" : "14120576",
      "id" : 14120576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454751315365617664",
  "geo" : { },
  "id_str" : "454751627765751808",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg @elleluna @rozsavage If you do, I'll write it for you.",
  "id" : 454751627765751808,
  "in_reply_to_status_id" : 454751315365617664,
  "created_at" : "2014-04-11 22:43:31 +0000",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "elle luna",
      "screen_name" : "elleluna",
      "indices" : [ 12, 21 ],
      "id_str" : "21107053",
      "id" : 21107053
    }, {
      "name" : "Roz Savage",
      "screen_name" : "rozsavage",
      "indices" : [ 26, 36 ],
      "id_str" : "14120576",
      "id" : 14120576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/dHRmp0n2Km",
      "expanded_url" : "https:\/\/medium.com\/buster-benson\/946ee85dc231",
      "display_url" : "medium.com\/buster-benson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454743699159674880",
  "text" : "Inspired by @elleluna and @rozsavage \u2014I put together a quick \"How to write your obituary\" guide: https:\/\/t.co\/dHRmp0n2Km",
  "id" : 454743699159674880,
  "created_at" : "2014-04-11 22:12:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Davidson",
      "screen_name" : "tdavidson",
      "indices" : [ 0, 10 ],
      "id_str" : "8466962",
      "id" : 8466962
    }, {
      "name" : "Shitty Watercolour",
      "screen_name" : "SWatercolour",
      "indices" : [ 28, 41 ],
      "id_str" : "554510636",
      "id" : 554510636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454734494361460736",
  "geo" : { },
  "id_str" : "454735514747142145",
  "in_reply_to_user_id" : 8466962,
  "text" : "@tdavidson Me too! That and @SWatercolour both.",
  "id" : 454735514747142145,
  "in_reply_to_status_id" : 454734494361460736,
  "created_at" : "2014-04-11 21:39:29 +0000",
  "in_reply_to_screen_name" : "tdavidson",
  "in_reply_to_user_id_str" : "8466962",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "elle luna",
      "screen_name" : "elleluna",
      "indices" : [ 114, 123 ],
      "id_str" : "21107053",
      "id" : 21107053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/gtMarDdOId",
      "expanded_url" : "https:\/\/medium.com\/editors-picks\/90c75eb7c5b0",
      "display_url" : "medium.com\/editors-picks\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454733049956036609",
  "text" : "Close your browsers put your phone into airplane mode turn off the TV &amp; stereo &amp; read this great piece by @elleluna https:\/\/t.co\/gtMarDdOId",
  "id" : 454733049956036609,
  "created_at" : "2014-04-11 21:29:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454726846320369664",
  "geo" : { },
  "id_str" : "454727321279143936",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake Doesn't really surprise me\u2014you seem to know all the awesome people. :)",
  "id" : 454727321279143936,
  "in_reply_to_status_id" : 454726846320369664,
  "created_at" : "2014-04-11 21:06:56 +0000",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/XsJHSy12NI",
      "expanded_url" : "http:\/\/www.rozsavage.com\/contents\/rozs-story\/",
      "display_url" : "rozsavage.com\/contents\/rozs-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "454725566814384128",
  "geo" : { },
  "id_str" : "454726097972654080",
  "in_reply_to_user_id" : 2185,
  "text" : "Roz Savage, the first woman to row solo across three oceans: http:\/\/t.co\/XsJHSy12NI",
  "id" : 454726097972654080,
  "in_reply_to_status_id" : 454725566814384128,
  "created_at" : "2014-04-11 21:02:04 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454725258386235392",
  "geo" : { },
  "id_str" : "454725566814384128",
  "in_reply_to_user_id" : 2185,
  "text" : "\"The 2nd version was the obituary I was heading for\u2014a conventional, ordinary life\u2014pleasant but within the safe confines of normality.\"",
  "id" : 454725566814384128,
  "in_reply_to_status_id" : 454725258386235392,
  "created_at" : "2014-04-11 20:59:58 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454724991594921984",
  "geo" : { },
  "id_str" : "454725258386235392",
  "in_reply_to_user_id" : 2185,
  "text" : "\"One day I sat down and wrote two versions of my obituary. The first was the one that I wanted to have.\"",
  "id" : 454725258386235392,
  "in_reply_to_status_id" : 454724991594921984,
  "created_at" : "2014-04-11 20:58:44 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454724991594921984",
  "text" : "\"I felt I was getting a few things figured out, but I needed a project. And so I decided to row the Atlantic.\"",
  "id" : 454724991594921984,
  "created_at" : "2014-04-11 20:57:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shitty Watercolour",
      "screen_name" : "SWatercolour",
      "indices" : [ 3, 16 ],
      "id_str" : "554510636",
      "id" : 554510636
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SWatercolour\/status\/454411115192004608\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/2VAf2Wahhg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk5kgG9CMAAuIGl.jpg",
      "id_str" : "454411115196198912",
      "id" : 454411115196198912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk5kgG9CMAAuIGl.jpg",
      "sizes" : [ {
        "h" : 513,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 651,
        "resize" : "fit",
        "w" : 1299
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/2VAf2Wahhg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454646563059400704",
  "text" : "RT @SWatercolour: twitter executive team sloth'd http:\/\/t.co\/2VAf2Wahhg",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SWatercolour\/status\/454411115192004608\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/2VAf2Wahhg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk5kgG9CMAAuIGl.jpg",
        "id_str" : "454411115196198912",
        "id" : 454411115196198912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk5kgG9CMAAuIGl.jpg",
        "sizes" : [ {
          "h" : 513,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 651,
          "resize" : "fit",
          "w" : 1299
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 301,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/2VAf2Wahhg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "454411115192004608",
    "text" : "twitter executive team sloth'd http:\/\/t.co\/2VAf2Wahhg",
    "id" : 454411115192004608,
    "created_at" : "2014-04-11 00:10:27 +0000",
    "user" : {
      "name" : "Shitty Watercolour",
      "screen_name" : "SWatercolour",
      "protected" : false,
      "id_str" : "554510636",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412726169151107072\/de8b-Jrt_normal.png",
      "id" : 554510636,
      "verified" : false
    }
  },
  "id" : 454646563059400704,
  "created_at" : "2014-04-11 15:46:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/454503454728130560\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/kSIjyERMEP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk64e8FCEAA5vHV.jpg",
      "id_str" : "454503454073819136",
      "id" : 454503454073819136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk64e8FCEAA5vHV.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kSIjyERMEP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8505928907, -122.25242993 ]
  },
  "id_str" : "454503454728130560",
  "text" : "8:36pm Date night at Wood Tavern http:\/\/t.co\/kSIjyERMEP",
  "id" : 454503454728130560,
  "created_at" : "2014-04-11 06:17:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shitty Watercolour",
      "screen_name" : "SWatercolour",
      "indices" : [ 0, 13 ],
      "id_str" : "554510636",
      "id" : 554510636
    }, {
      "name" : "Gaby Pe\u00F1a",
      "screen_name" : "gpena",
      "indices" : [ 14, 20 ],
      "id_str" : "133583134",
      "id" : 133583134
    }, {
      "name" : "Vivek Bhagwat",
      "screen_name" : "vivekb",
      "indices" : [ 21, 28 ],
      "id_str" : "9609272",
      "id" : 9609272
    }, {
      "name" : "Tony Stilling",
      "screen_name" : "tony2x",
      "indices" : [ 29, 36 ],
      "id_str" : "15482837",
      "id" : 15482837
    }, {
      "name" : "Ran Enrico Magen ",
      "screen_name" : "rmgn",
      "indices" : [ 37, 42 ],
      "id_str" : "14824759",
      "id" : 14824759
    }, {
      "name" : "Yann Ramin",
      "screen_name" : "theatrus",
      "indices" : [ 43, 52 ],
      "id_str" : "6192062",
      "id" : 6192062
    }, {
      "name" : "Chris Aniszczyk",
      "screen_name" : "cra",
      "indices" : [ 53, 57 ],
      "id_str" : "14602130",
      "id" : 14602130
    }, {
      "name" : "Ralph Holzmann;",
      "screen_name" : "rlph",
      "indices" : [ 58, 63 ],
      "id_str" : "14192671",
      "id" : 14192671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454370019817062401",
  "geo" : { },
  "id_str" : "454370644503707648",
  "in_reply_to_user_id" : 554510636,
  "text" : "@swatercolour @gpena @vivekb @tony2x @rmgn @theatrus @cra @rlph Woohoo! Do you have a tip cup somewhere? :)",
  "id" : 454370644503707648,
  "in_reply_to_status_id" : 454370019817062401,
  "created_at" : "2014-04-10 21:29:38 +0000",
  "in_reply_to_screen_name" : "SWatercolour",
  "in_reply_to_user_id_str" : "554510636",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 0, 3 ],
      "id_str" : "15504330",
      "id" : 15504330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454316325297336321",
  "geo" : { },
  "id_str" : "454361961770147840",
  "in_reply_to_user_id" : 15504330,
  "text" : "@wm Funny cause that's exactly how I feel about working at Twitter after doing startups and Amazon. :)",
  "id" : 454361961770147840,
  "in_reply_to_status_id" : 454316325297336321,
  "created_at" : "2014-04-10 20:55:07 +0000",
  "in_reply_to_screen_name" : "wm",
  "in_reply_to_user_id_str" : "15504330",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shitty Watercolour",
      "screen_name" : "SWatercolour",
      "indices" : [ 3, 16 ],
      "id_str" : "554510636",
      "id" : 554510636
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SWatercolour\/status\/454285097735172097\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/hVLCwD3fFz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk3x47XCMAEH22L.jpg",
      "id_str" : "454285097743560705",
      "id" : 454285097743560705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk3x47XCMAEH22L.jpg",
      "sizes" : [ {
        "h" : 1093,
        "resize" : "fit",
        "w" : 963
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1093,
        "resize" : "fit",
        "w" : 963
      } ],
      "display_url" : "pic.twitter.com\/hVLCwD3fFz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454360269540442112",
  "text" : "RT @SWatercolour: The Elemelons http:\/\/t.co\/hVLCwD3fFz",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SWatercolour\/status\/454285097735172097\/photo\/1",
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/hVLCwD3fFz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk3x47XCMAEH22L.jpg",
        "id_str" : "454285097743560705",
        "id" : 454285097743560705,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk3x47XCMAEH22L.jpg",
        "sizes" : [ {
          "h" : 1093,
          "resize" : "fit",
          "w" : 963
        }, {
          "h" : 386,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1093,
          "resize" : "fit",
          "w" : 963
        } ],
        "display_url" : "pic.twitter.com\/hVLCwD3fFz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "454285097735172097",
    "text" : "The Elemelons http:\/\/t.co\/hVLCwD3fFz",
    "id" : 454285097735172097,
    "created_at" : "2014-04-10 15:49:42 +0000",
    "user" : {
      "name" : "Shitty Watercolour",
      "screen_name" : "SWatercolour",
      "protected" : false,
      "id_str" : "554510636",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412726169151107072\/de8b-Jrt_normal.png",
      "id" : 554510636,
      "verified" : false
    }
  },
  "id" : 454360269540442112,
  "created_at" : "2014-04-10 20:48:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shitty Watercolour",
      "screen_name" : "SWatercolour",
      "indices" : [ 0, 13 ],
      "id_str" : "554510636",
      "id" : 554510636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454355583823388672",
  "in_reply_to_user_id" : 554510636,
  "text" : "@SWatercolour How do I get in line?",
  "id" : 454355583823388672,
  "created_at" : "2014-04-10 20:29:47 +0000",
  "in_reply_to_screen_name" : "SWatercolour",
  "in_reply_to_user_id_str" : "554510636",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454288557524258816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8537635013, -122.2706675809 ]
  },
  "id_str" : "454292483027910656",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I think it's safe to say that time has told.",
  "id" : 454292483027910656,
  "in_reply_to_status_id" : 454288557524258816,
  "created_at" : "2014-04-10 16:19:02 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kay Vreeland",
      "screen_name" : "cay_anchor",
      "indices" : [ 0, 11 ],
      "id_str" : "16275525",
      "id" : 16275525
    }, {
      "name" : "750 Words",
      "screen_name" : "750words",
      "indices" : [ 12, 21 ],
      "id_str" : "401833335",
      "id" : 401833335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454270075705364480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596875258, -122.2754835059 ]
  },
  "id_str" : "454270399807627264",
  "in_reply_to_user_id" : 16275525,
  "text" : "@cay_anchor @750words The credit card info went through PayPal, not 750.",
  "id" : 454270399807627264,
  "in_reply_to_status_id" : 454270075705364480,
  "created_at" : "2014-04-10 14:51:17 +0000",
  "in_reply_to_screen_name" : "cay_anchor",
  "in_reply_to_user_id_str" : "16275525",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kay Vreeland",
      "screen_name" : "cay_anchor",
      "indices" : [ 0, 11 ],
      "id_str" : "16275525",
      "id" : 16275525
    }, {
      "name" : "750 Words",
      "screen_name" : "750words",
      "indices" : [ 12, 21 ],
      "id_str" : "401833335",
      "id" : 401833335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454268357265465345",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596696724, -122.2754276824 ]
  },
  "id_str" : "454269075414192128",
  "in_reply_to_user_id" : 16275525,
  "text" : "@cay_anchor @750words I believe it is. Will be trying to fix it by this weekend.",
  "id" : 454269075414192128,
  "in_reply_to_status_id" : 454268357265465345,
  "created_at" : "2014-04-10 14:46:02 +0000",
  "in_reply_to_screen_name" : "cay_anchor",
  "in_reply_to_user_id_str" : "16275525",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 3, 14 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454124829344419840",
  "text" : "RT @nikobenson: If you're an engineer it means you drive trains, right?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.8597102827, -122.2753991001 ]
    },
    "id_str" : "454124721676636162",
    "text" : "If you're an engineer it means you drive trains, right?",
    "id" : 454124721676636162,
    "created_at" : "2014-04-10 05:12:25 +0000",
    "user" : {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "protected" : false,
      "id_str" : "142467448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000616213793\/9f77fe6693d877565cd97b6a2381c40c_normal.jpeg",
      "id" : 142467448,
      "verified" : false
    }
  },
  "id" : 454124829344419840,
  "created_at" : "2014-04-10 05:12:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/Rju17j1mXD",
      "expanded_url" : "http:\/\/vox.com\/e\/5361641",
      "display_url" : "vox.com\/e\/5361641"
    } ]
  },
  "geo" : { },
  "id_str" : "454124395397521408",
  "text" : "RT @voxdotcom: John Boehner was completely wrong about Obamacare http:\/\/t.co\/Rju17j1mXD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/Rju17j1mXD",
        "expanded_url" : "http:\/\/vox.com\/e\/5361641",
        "display_url" : "vox.com\/e\/5361641"
      } ]
    },
    "geo" : { },
    "id_str" : "454122605331505152",
    "text" : "John Boehner was completely wrong about Obamacare http:\/\/t.co\/Rju17j1mXD",
    "id" : 454122605331505152,
    "created_at" : "2014-04-10 05:04:00 +0000",
    "user" : {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "protected" : false,
      "id_str" : "2347049341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442785905246347265\/v6W3UuIL_normal.jpeg",
      "id" : 2347049341,
      "verified" : true
    }
  },
  "id" : 454124395397521408,
  "created_at" : "2014-04-10 05:11:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 3, 9 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "David Bellona",
      "screen_name" : "davidbellona",
      "indices" : [ 79, 92 ],
      "id_str" : "237472727",
      "id" : 237472727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/8pLNVP200f",
      "expanded_url" : "http:\/\/www.wired.com\/2014\/04\/the-design-process-behind-twitters-revamped-profiles\/",
      "display_url" : "wired.com\/2014\/04\/the-de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454100379928522753",
  "text" : "RT @couch: Curious about some of the thinking around the new Twitter profiles? @davidbellona provides some insight with WIRED: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Bellona",
        "screen_name" : "davidbellona",
        "indices" : [ 68, 81 ],
        "id_str" : "237472727",
        "id" : 237472727
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/8pLNVP200f",
        "expanded_url" : "http:\/\/www.wired.com\/2014\/04\/the-design-process-behind-twitters-revamped-profiles\/",
        "display_url" : "wired.com\/2014\/04\/the-de\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7765139295, -122.4164679896 ]
    },
    "id_str" : "454097039798710272",
    "text" : "Curious about some of the thinking around the new Twitter profiles? @davidbellona provides some insight with WIRED: http:\/\/t.co\/8pLNVP200f",
    "id" : 454097039798710272,
    "created_at" : "2014-04-10 03:22:25 +0000",
    "user" : {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "protected" : false,
      "id_str" : "631823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428249544136994817\/fYWQCTd__normal.jpeg",
      "id" : 631823,
      "verified" : false
    }
  },
  "id" : 454100379928522753,
  "created_at" : "2014-04-10 03:35:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 14, 21 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 26, 37 ],
      "id_str" : "784078",
      "id" : 784078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/zitvmclMCZ",
      "expanded_url" : "http:\/\/i.instagram.com\/p\/mlxaAVsaw5\/",
      "display_url" : "i.instagram.com\/p\/mlxaAVsaw5\/"
    } ]
  },
  "geo" : { },
  "id_str" : "454084005093076993",
  "text" : "A likeness of @harryh and @alicetiara in lite brite. http:\/\/t.co\/zitvmclMCZ",
  "id" : 454084005093076993,
  "created_at" : "2014-04-10 02:30:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/voxdotcom\/status\/454071772447391744\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/5bKwFaxSgU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk0v3wWCMAA5cdy.png",
      "id_str" : "454071772350918656",
      "id" : 454071772350918656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk0v3wWCMAA5cdy.png",
      "sizes" : [ {
        "h" : 221,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 389,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 1231
      }, {
        "h" : 665,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5bKwFaxSgU"
    } ],
    "hashtags" : [ {
      "text" : "GameOfThrones",
      "indices" : [ 43, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/HZGvQIBz6B",
      "expanded_url" : "http:\/\/bit.ly\/1oNtEaF",
      "display_url" : "bit.ly\/1oNtEaF"
    } ]
  },
  "geo" : { },
  "id_str" : "454071986646315008",
  "text" : "RT @voxdotcom: Getting your baby name from #GameOfThrones? More \"Khaleesi\"s were born in 2012 than \"Betsy\"s: http:\/\/t.co\/HZGvQIBz6B http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/voxdotcom\/status\/454071772447391744\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/5bKwFaxSgU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk0v3wWCMAA5cdy.png",
        "id_str" : "454071772350918656",
        "id" : 454071772350918656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk0v3wWCMAA5cdy.png",
        "sizes" : [ {
          "h" : 221,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1231
        }, {
          "h" : 665,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/5bKwFaxSgU"
      } ],
      "hashtags" : [ {
        "text" : "GameOfThrones",
        "indices" : [ 28, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/HZGvQIBz6B",
        "expanded_url" : "http:\/\/bit.ly\/1oNtEaF",
        "display_url" : "bit.ly\/1oNtEaF"
      } ]
    },
    "geo" : { },
    "id_str" : "454071772447391744",
    "text" : "Getting your baby name from #GameOfThrones? More \"Khaleesi\"s were born in 2012 than \"Betsy\"s: http:\/\/t.co\/HZGvQIBz6B http:\/\/t.co\/5bKwFaxSgU",
    "id" : 454071772447391744,
    "created_at" : "2014-04-10 01:42:01 +0000",
    "user" : {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "protected" : false,
      "id_str" : "2347049341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442785905246347265\/v6W3UuIL_normal.jpeg",
      "id" : 2347049341,
      "verified" : true
    }
  },
  "id" : 454071986646315008,
  "created_at" : "2014-04-10 01:42:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Urban",
      "screen_name" : "allisonurban",
      "indices" : [ 0, 13 ],
      "id_str" : "15741355",
      "id" : 15741355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454065291329167361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7892367989, -122.4042629869 ]
  },
  "id_str" : "454070159343239168",
  "in_reply_to_user_id" : 15741355,
  "text" : "@allisonurban Facebook, Flickr, and Google+ all have free auto-backup options for photos via mobile.",
  "id" : 454070159343239168,
  "in_reply_to_status_id" : 454065291329167361,
  "created_at" : "2014-04-10 01:35:36 +0000",
  "in_reply_to_screen_name" : "allisonurban",
  "in_reply_to_user_id_str" : "15741355",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454062886826934272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7765816534, -122.4180127111 ]
  },
  "id_str" : "454064646433939456",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez \uD83D\uDCA6\uD83D\uDCA6\uD83D\uDCA6\uD83D\uDC1F\uD83D\uDCA6\uD83D\uDCA6\uD83D\uDCA6",
  "id" : 454064646433939456,
  "in_reply_to_status_id" : 454062886826934272,
  "created_at" : "2014-04-10 01:13:42 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7767270365, -122.4178609859 ]
  },
  "id_str" : "454063737234669568",
  "text" : "The problem with the new Dropbox photo app thing is that it's free\/cheaper to auto-backup my photos with a bunch of other services.",
  "id" : 454063737234669568,
  "created_at" : "2014-04-10 01:10:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7767196019, -122.4178729964 ]
  },
  "id_str" : "454061143007313920",
  "text" : "Just go with the stream.",
  "id" : 454061143007313920,
  "created_at" : "2014-04-10 00:59:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/vUs9xYkbz6",
      "expanded_url" : "http:\/\/www.brainpickings.org\/index.php\/2013\/06\/07\/annie-dillard-the-writing-life-1\/?utm_content=bufferc457f&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "brainpickings.org\/index.php\/2013\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7767035435, -122.4178968536 ]
  },
  "id_str" : "454057745180680192",
  "text" : "\"How we spend our days is, of course, how we spend our lives.\" But the sample \"perfect routines\" sound dreadful. http:\/\/t.co\/vUs9xYkbz6",
  "id" : 454057745180680192,
  "created_at" : "2014-04-10 00:46:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Flanigan",
      "screen_name" : "colinflanigan",
      "indices" : [ 0, 14 ],
      "id_str" : "127729400",
      "id" : 127729400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454005997779288064",
  "geo" : { },
  "id_str" : "454007768878313472",
  "in_reply_to_user_id" : 127729400,
  "text" : "@colinflanigan Thank you! Nicely done. Grapefruit juice in an Old Fashioned is indeed quite a travesty that no half-apology would remedy.",
  "id" : 454007768878313472,
  "in_reply_to_status_id" : 454005997779288064,
  "created_at" : "2014-04-09 21:27:41 +0000",
  "in_reply_to_screen_name" : "colinflanigan",
  "in_reply_to_user_id_str" : "127729400",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/UYglRMnoR1",
      "expanded_url" : "https:\/\/static.pinboard.in\/webstock_2014.htm",
      "display_url" : "static.pinboard.in\/webstock_2014.\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "453942638496866304",
  "geo" : { },
  "id_str" : "453943535494889472",
  "in_reply_to_user_id" : 2185,
  "text" : "Great manifesto\/rant\/history lesson from Maciej Ceg\u0142owski: https:\/\/t.co\/UYglRMnoR1",
  "id" : 453943535494889472,
  "in_reply_to_status_id" : 453942638496866304,
  "created_at" : "2014-04-09 17:12:27 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453942638496866304",
  "text" : "\"We put so much care into making the Internet resilient from technical failures, but no effort to make it resilient to political failure.\"",
  "id" : 453942638496866304,
  "created_at" : "2014-04-09 17:08:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SiliconValleyHBO",
      "indices" : [ 20, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596579377, -122.2755447776 ]
  },
  "id_str" : "453770495985319936",
  "text" : "That just happened. #SiliconValleyHBO",
  "id" : 453770495985319936,
  "created_at" : "2014-04-09 05:44:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mira Crisp",
      "screen_name" : "misscrisp",
      "indices" : [ 0, 10 ],
      "id_str" : "16228258",
      "id" : 16228258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453748282729054208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859673992, -122.2754923053 ]
  },
  "id_str" : "453749713271926785",
  "in_reply_to_user_id" : 16228258,
  "text" : "@misscrisp We can dream of a world with endorsements like that, can't we?",
  "id" : 453749713271926785,
  "in_reply_to_status_id" : 453748282729054208,
  "created_at" : "2014-04-09 04:22:16 +0000",
  "in_reply_to_screen_name" : "misscrisp",
  "in_reply_to_user_id_str" : "16228258",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/453747381549273088\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/zmrdgA75RK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkwI1j-CcAA_Euz.jpg",
      "id_str" : "453747378739113984",
      "id" : 453747378739113984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkwI1j-CcAA_Euz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zmrdgA75RK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597929758, -122.2754178394 ]
  },
  "id_str" : "453747381549273088",
  "text" : "8:36pm Waiting to watch Silicon Valley http:\/\/t.co\/zmrdgA75RK",
  "id" : 453747381549273088,
  "created_at" : "2014-04-09 04:13:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cyd Highwind",
      "screen_name" : "cydling",
      "indices" : [ 0, 8 ],
      "id_str" : "132398182",
      "id" : 132398182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453726893020155905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596973326, -122.2754633055 ]
  },
  "id_str" : "453733790477590530",
  "in_reply_to_user_id" : 132398182,
  "text" : "@cydling Thanks.",
  "id" : 453733790477590530,
  "in_reply_to_status_id" : 453726893020155905,
  "created_at" : "2014-04-09 03:19:00 +0000",
  "in_reply_to_screen_name" : "cydling",
  "in_reply_to_user_id_str" : "132398182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 0, 7 ],
      "id_str" : "23640904",
      "id" : 23640904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453647802103394305",
  "geo" : { },
  "id_str" : "453648539441049602",
  "in_reply_to_user_id" : 23640904,
  "text" : "@emoore Ha, I definitely felt like that last week.",
  "id" : 453648539441049602,
  "in_reply_to_status_id" : 453647802103394305,
  "created_at" : "2014-04-08 21:40:14 +0000",
  "in_reply_to_screen_name" : "emoore",
  "in_reply_to_user_id_str" : "23640904",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 0, 7 ],
      "id_str" : "23640904",
      "id" : 23640904
    }, {
      "name" : "Brilliant Ads",
      "screen_name" : "Brilliant_Ads",
      "indices" : [ 8, 22 ],
      "id_str" : "564686965",
      "id" : 564686965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453645502425231360",
  "geo" : { },
  "id_str" : "453647531583340545",
  "in_reply_to_user_id" : 23640904,
  "text" : "@emoore @brilliant_ads Ouch.",
  "id" : 453647531583340545,
  "in_reply_to_status_id" : 453645502425231360,
  "created_at" : "2014-04-08 21:36:14 +0000",
  "in_reply_to_screen_name" : "emoore",
  "in_reply_to_user_id_str" : "23640904",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "timoni west",
      "screen_name" : "timoni",
      "indices" : [ 0, 7 ],
      "id_str" : "12615",
      "id" : 12615
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 8, 17 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/7a8sPweWMP",
      "expanded_url" : "http:\/\/habitlabs.tumblr.com\/axioms",
      "display_url" : "habitlabs.tumblr.com\/axioms"
    } ]
  },
  "in_reply_to_status_id_str" : "453566090745249793",
  "geo" : { },
  "id_str" : "453577385007263744",
  "in_reply_to_user_id" : 12615,
  "text" : "@timoni @arainert Here's a version of the one we had for Habit Labs: http:\/\/t.co\/7a8sPweWMP",
  "id" : 453577385007263744,
  "in_reply_to_status_id" : 453566090745249793,
  "created_at" : "2014-04-08 16:57:30 +0000",
  "in_reply_to_screen_name" : "timoni",
  "in_reply_to_user_id_str" : "12615",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453564676345847809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7761812103, -122.4169006727 ]
  },
  "id_str" : "453565174666895360",
  "in_reply_to_user_id" : 2185,
  "text" : "@arainert However, if I were to do it again I would have each employee maintain their own version. Companies don't have values, people do.",
  "id" : 453565174666895360,
  "in_reply_to_status_id" : 453564676345847809,
  "created_at" : "2014-04-08 16:08:59 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453562466773893121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7761417861, -122.4174110034 ]
  },
  "id_str" : "453564676345847809",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert I did this with Habit Labs (we had an axioms document on GitHub that each new employee would edit, sign, and commit).",
  "id" : 453564676345847809,
  "in_reply_to_status_id" : 453562466773893121,
  "created_at" : "2014-04-08 16:07:00 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "indices" : [ 3, 15 ],
      "id_str" : "1532061",
      "id" : 1532061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/HRSSP9ynkV",
      "expanded_url" : "http:\/\/cdn.ly.tl\/publications\/text-based-captcha-strengths-and-weaknesses.pdf",
      "display_url" : "cdn.ly.tl\/publications\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453418997975760896",
  "text" : "RT @kevin2kelly: Captchas are over as Turing tests. Soon machines will unscramble words that humans can't read. We'll say, of course! http:\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/HRSSP9ynkV",
        "expanded_url" : "http:\/\/cdn.ly.tl\/publications\/text-based-captcha-strengths-and-weaknesses.pdf",
        "display_url" : "cdn.ly.tl\/publications\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "453297943408148480",
    "text" : "Captchas are over as Turing tests. Soon machines will unscramble words that humans can't read. We'll say, of course! http:\/\/t.co\/HRSSP9ynkV",
    "id" : 453297943408148480,
    "created_at" : "2014-04-07 22:27:06 +0000",
    "user" : {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "protected" : false,
      "id_str" : "1532061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/65000713\/KKlaughsm_normal.jpg",
      "id" : 1532061,
      "verified" : false
    }
  },
  "id" : 453418997975760896,
  "created_at" : "2014-04-08 06:28:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 30, 40 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cosmos",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597324438, -122.2756701512 ]
  },
  "id_str" : "453412848064929792",
  "text" : "\"What *is* light anyway???\" - @neiltyson in #cosmos. And for that matter... fucking magnets, how do they work?",
  "id" : 453412848064929792,
  "created_at" : "2014-04-08 06:03:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cosmos",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/QcZ23iBs0p",
      "expanded_url" : "http:\/\/flic.kr\/p\/mTwwVf",
      "display_url" : "flic.kr\/p\/mTwwVf"
    } ]
  },
  "geo" : { },
  "id_str" : "453404831429177345",
  "text" : "8:36pm Catching up on #Cosmos. http:\/\/t.co\/QcZ23iBs0p",
  "id" : 453404831429177345,
  "created_at" : "2014-04-08 05:31:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rosania",
      "screen_name" : "ptr",
      "indices" : [ 12, 16 ],
      "id_str" : "15007480",
      "id" : 15007480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/LMxZaYKH8S",
      "expanded_url" : "http:\/\/techcrunch.com\/2014\/04\/07\/uberrush\/",
      "display_url" : "techcrunch.com\/2014\/04\/07\/ube\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453331032356315136",
  "text" : "Amazing. RT @ptr: Uber is testing courier service in NYC. The beginnings of Uber as a platform. This is huge. http:\/\/t.co\/LMxZaYKH8S",
  "id" : 453331032356315136,
  "created_at" : "2014-04-08 00:38:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blogpostplaceholder",
      "indices" : [ 38, 58 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453263532583579648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763519844, -122.4173606733 ]
  },
  "id_str" : "453277387694673921",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash I have opinions about this! #blogpostplaceholder",
  "id" : 453277387694673921,
  "in_reply_to_status_id" : 453263532583579648,
  "created_at" : "2014-04-07 21:05:25 +0000",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dixon",
      "screen_name" : "cdixon",
      "indices" : [ 78, 85 ],
      "id_str" : "2529971",
      "id" : 2529971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/0OWF7rq1fm",
      "expanded_url" : "http:\/\/www.cdixon.org\/2014\/04\/07\/the-decline-of-the-mobile-web\/",
      "display_url" : "cdixon.org\/2014\/04\/07\/the\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "453244752088289280",
  "geo" : { },
  "id_str" : "453257435516370944",
  "in_reply_to_user_id" : 2529971,
  "text" : "Watching this trend over last few years, I had my money on HTML5. Oh well. RT @cdixon: The decline of the mobile web http:\/\/t.co\/0OWF7rq1fm",
  "id" : 453257435516370944,
  "in_reply_to_status_id" : 453244752088289280,
  "created_at" : "2014-04-07 19:46:08 +0000",
  "in_reply_to_screen_name" : "cdixon",
  "in_reply_to_user_id_str" : "2529971",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453233449063546880",
  "geo" : { },
  "id_str" : "453241131581460480",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie I haven't, but I just listened to it. I don't really buy it though\u2014fake followers get deleted pretty quickly these days.",
  "id" : 453241131581460480,
  "in_reply_to_status_id" : 453233449063546880,
  "created_at" : "2014-04-07 18:41:21 +0000",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "megan hunt",
      "screen_name" : "lasertron",
      "indices" : [ 0, 10 ],
      "id_str" : "17915737",
      "id" : 17915737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453223335950688256",
  "geo" : { },
  "id_str" : "453224296492445696",
  "in_reply_to_user_id" : 17915737,
  "text" : "@lasertron *bows*",
  "id" : 453224296492445696,
  "in_reply_to_status_id" : 453223335950688256,
  "created_at" : "2014-04-07 17:34:27 +0000",
  "in_reply_to_screen_name" : "lasertron",
  "in_reply_to_user_id_str" : "17915737",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453222950301212672",
  "text" : "Pro tip: tweet every day.",
  "id" : 453222950301212672,
  "created_at" : "2014-04-07 17:29:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Schweers",
      "screen_name" : "cyberfox",
      "indices" : [ 0, 9 ],
      "id_str" : "1173821",
      "id" : 1173821
    }, {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 10, 20 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453201958019420160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764417325, -122.4164131378 ]
  },
  "id_str" : "453213572764401664",
  "in_reply_to_user_id" : 1173821,
  "text" : "@cyberfox @webwright I agree but he at least admitted that the article itself could be a form of identity-protection.",
  "id" : 453213572764401664,
  "in_reply_to_status_id" : 453201958019420160,
  "created_at" : "2014-04-07 16:51:50 +0000",
  "in_reply_to_screen_name" : "cyberfox",
  "in_reply_to_user_id_str" : "1173821",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cover",
      "screen_name" : "coverscreen",
      "indices" : [ 21, 33 ],
      "id_str" : "1653968712",
      "id" : 1653968712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/71MMjRgp2G",
      "expanded_url" : "http:\/\/blog.coverscreen.com\/post\/81998756366\/cover-is-joining-twitter",
      "display_url" : "blog.coverscreen.com\/post\/819987563\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "453199952580075520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8224216681, -122.2687272729 ]
  },
  "id_str" : "453205272945651712",
  "in_reply_to_user_id" : 1653968712,
  "text" : "This is exciting. RT @coverscreen: Cover is joining Twitter! Excited for the future of Android and what\u2019s to come. http:\/\/t.co\/71MMjRgp2G",
  "id" : 453205272945651712,
  "in_reply_to_status_id" : 453199952580075520,
  "created_at" : "2014-04-07 16:18:51 +0000",
  "in_reply_to_screen_name" : "coverscreen",
  "in_reply_to_user_id_str" : "1653968712",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drew Breunig",
      "screen_name" : "dbreunig",
      "indices" : [ 0, 9 ],
      "id_str" : "14208457",
      "id" : 14208457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453171276392448000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597129894, -122.275554303 ]
  },
  "id_str" : "453190961615499264",
  "in_reply_to_user_id" : 14208457,
  "text" : "@dbreunig Agreed.",
  "id" : 453190961615499264,
  "in_reply_to_status_id" : 453171276392448000,
  "created_at" : "2014-04-07 15:21:59 +0000",
  "in_reply_to_screen_name" : "dbreunig",
  "in_reply_to_user_id_str" : "14208457",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "indices" : [ 74, 84 ],
      "id_str" : "18622869",
      "id" : 18622869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453175838515552256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597454022, -122.2755211751 ]
  },
  "id_str" : "453179291258212352",
  "in_reply_to_user_id" : 2185,
  "text" : "\"How can I know that this article isn\u2019t a form of identity protection?\" - @ezraklein",
  "id" : 453179291258212352,
  "in_reply_to_status_id" : 453175838515552256,
  "created_at" : "2014-04-07 14:35:37 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/5135fdrW6f",
      "expanded_url" : "http:\/\/www.vox.com\/2014\/4\/6\/5556462\/brain-dead-how-politics-makes-us-stupid",
      "display_url" : "vox.com\/2014\/4\/6\/55564\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597363726, -122.2754921948 ]
  },
  "id_str" : "453175838515552256",
  "text" : "\"Kahan\u2019s research tells us we can\u2019t trust our own reason. How do we reason our way out of that?\" http:\/\/t.co\/5135fdrW6f",
  "id" : 453175838515552256,
  "created_at" : "2014-04-07 14:21:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaurav Gupta",
      "screen_name" : "unsymmetric",
      "indices" : [ 0, 12 ],
      "id_str" : "16554166",
      "id" : 16554166
    }, {
      "name" : "Circa",
      "screen_name" : "Circa",
      "indices" : [ 43, 49 ],
      "id_str" : "441389311",
      "id" : 441389311
    }, {
      "name" : "Prismatic",
      "screen_name" : "Prismatic",
      "indices" : [ 54, 64 ],
      "id_str" : "229709694",
      "id" : 229709694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453029836814946304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596311994, -122.2756658961 ]
  },
  "id_str" : "453030248376848385",
  "in_reply_to_user_id" : 16554166,
  "text" : "@unsymmetric I've got that one too. :) And @Circa and @Prismatic.",
  "id" : 453030248376848385,
  "in_reply_to_status_id" : 453029836814946304,
  "created_at" : "2014-04-07 04:43:22 +0000",
  "in_reply_to_screen_name" : "unsymmetric",
  "in_reply_to_user_id_str" : "16554166",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Now",
      "screen_name" : "NYTNow",
      "indices" : [ 9, 16 ],
      "id_str" : "1872590082",
      "id" : 1872590082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/t6I4WH49UD",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2014\/04\/-em-the-new-york-times-em-s-new-app-tries-to-one-up-facebook\/360029\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597111211, -122.2756680216 ]
  },
  "id_str" : "453028628008153088",
  "text" : "This new @NYTNow app is pretty brilliant. So much new news tech to be excited about recently. http:\/\/t.co\/t6I4WH49UD",
  "id" : 453028628008153088,
  "created_at" : "2014-04-07 04:36:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ThwLpzkk6G",
      "expanded_url" : "http:\/\/www.smh.com.au\/technology\/sci-tech\/you-might-be-seeing-this-on-a-15second-delay-study-20140406-zqrfp.html",
      "display_url" : "smh.com.au\/technology\/sci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453026540419182593",
  "text" : "\"What you're seeing now isn't a fresh snapshot of the world but rather an avg of what you've seen in the past 15secs\" http:\/\/t.co\/ThwLpzkk6G",
  "id" : 453026540419182593,
  "created_at" : "2014-04-07 04:28:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 3, 17 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453021904278794241",
  "text" : "RT @buster_ebooks: Locavore side project while watching two audience members make out with that implementation\u2026 or want to meditate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/busterbenson.com\" rel=\"nofollow\"\u003EBuster eBooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "453021640989745152",
    "text" : "Locavore side project while watching two audience members make out with that implementation\u2026 or want to meditate",
    "id" : 453021640989745152,
    "created_at" : "2014-04-07 04:09:10 +0000",
    "user" : {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "protected" : false,
      "id_str" : "1901375096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000503050571\/228ccabfeeb4e55bd8e172595babe02e_normal.jpeg",
      "id" : 1901375096,
      "verified" : false
    }
  },
  "id" : 453021904278794241,
  "created_at" : "2014-04-07 04:10:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/453016079183257601\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/jswXLCGPHX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BklvuQ2CYAAq5ae.jpg",
      "id_str" : "453016078113726464",
      "id" : 453016078113726464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BklvuQ2CYAAq5ae.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jswXLCGPHX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597297956, -122.2755185504 ]
  },
  "id_str" : "453016079183257601",
  "text" : "8:36pm Bought a new tent and practicing with some house camping. Bet you can't find Niko. http:\/\/t.co\/jswXLCGPHX",
  "id" : 453016079183257601,
  "created_at" : "2014-04-07 03:47:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "subtweetalltheconversationsatonce",
      "indices" : [ 84, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597158641, -122.2755235434 ]
  },
  "id_str" : "453012528159666177",
  "text" : "Human history is one long pros and cons debate about the value of pattern matching. #subtweetalltheconversationsatonce",
  "id" : 453012528159666177,
  "created_at" : "2014-04-07 03:32:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 16, 19 ],
      "id_str" : "22273667",
      "id" : 22273667
    }, {
      "name" : "Matt Khoury",
      "screen_name" : "mkhoury",
      "indices" : [ 20, 28 ],
      "id_str" : "16301098",
      "id" : 16301098
    }, {
      "name" : "Trevor O'Brien",
      "screen_name" : "tmobrien",
      "indices" : [ 29, 38 ],
      "id_str" : "22573142",
      "id" : 22573142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453000130254237696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596750787, -122.275427431 ]
  },
  "id_str" : "453008720742469634",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries @sm @mkhoury @tmobrien There's an exception to every pattern match. A great PM make a pos impact using everything they have.",
  "id" : 453008720742469634,
  "in_reply_to_status_id" : 453000130254237696,
  "created_at" : "2014-04-07 03:17:50 +0000",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    }, {
      "name" : "Discourse",
      "screen_name" : "discourse",
      "indices" : [ 14, 24 ],
      "id_str" : "1187955571",
      "id" : 1187955571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452944029336862721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597504739, -122.2753759661 ]
  },
  "id_str" : "452972668300431360",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel @discourse I am setting up one for a side project. Looks pretty amazing.",
  "id" : 452972668300431360,
  "in_reply_to_status_id" : 452944029336862721,
  "created_at" : "2014-04-07 00:54:34 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452940774879924224",
  "text" : "Why don\u2019t Google docs (or any docs really) have tabs? Spreadsheets do, browsers do, documents should too, right?",
  "id" : 452940774879924224,
  "created_at" : "2014-04-06 22:47:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cognitive Lode",
      "screen_name" : "cogLode",
      "indices" : [ 98, 106 ],
      "id_str" : "2383547119",
      "id" : 2383547119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/OTMKf1wEJl",
      "expanded_url" : "http:\/\/coglode.com",
      "display_url" : "coglode.com"
    } ]
  },
  "geo" : { },
  "id_str" : "452928614640517120",
  "text" : "LazyWeb: Invent a game that we play by collecting evidence of cognitive biases. Start simple with @coglode\u2019s list: http:\/\/t.co\/OTMKf1wEJl",
  "id" : 452928614640517120,
  "created_at" : "2014-04-06 21:59:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452891224983076864",
  "text" : "The time it takes to catch up on all the stuff neglected during vacation divided by the total time spent on vacation.",
  "id" : 452891224983076864,
  "created_at" : "2014-04-06 19:30:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Weisenthal",
      "screen_name" : "TheStalwart",
      "indices" : [ 0, 12 ],
      "id_str" : "14096763",
      "id" : 14096763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452834691562086400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597130003, -122.2755945824 ]
  },
  "id_str" : "452836132867162112",
  "in_reply_to_user_id" : 14096763,
  "text" : "@TheStalwart The data looks way more dramatic than it is because the y-axis isn't anchored at 0.",
  "id" : 452836132867162112,
  "in_reply_to_status_id" : 452834691562086400,
  "created_at" : "2014-04-06 15:52:02 +0000",
  "in_reply_to_screen_name" : "TheStalwart",
  "in_reply_to_user_id_str" : "14096763",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henry Blodget",
      "screen_name" : "hblodget",
      "indices" : [ 21, 30 ],
      "id_str" : "6730222",
      "id" : 6730222
    }, {
      "name" : "Joseph Weisenthal",
      "screen_name" : "TheStalwart",
      "indices" : [ 35, 47 ],
      "id_str" : "14096763",
      "id" : 14096763
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheStalwart\/status\/452805661340876802\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/sDHu4CNOzy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkiwWYlCMAA_Dxf.png",
      "id_str" : "452805661152129024",
      "id" : 452805661152129024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkiwWYlCMAA_Dxf.png",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 670
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 670
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sDHu4CNOzy"
    } ],
    "hashtags" : [ {
      "text" : "misleadingcharts",
      "indices" : [ 0, 17 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452806061427527680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596812419, -122.2756895309 ]
  },
  "id_str" : "452834409113067520",
  "in_reply_to_user_id" : 6730222,
  "text" : "#misleadingcharts RT @hblodget: RT @TheStalwart: % of population that's older than 55. http:\/\/t.co\/sDHu4CNOzy",
  "id" : 452834409113067520,
  "in_reply_to_status_id" : 452806061427527680,
  "created_at" : "2014-04-06 15:45:11 +0000",
  "in_reply_to_screen_name" : "hblodget",
  "in_reply_to_user_id_str" : "6730222",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/452711468723474432\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/w2vPMxyroe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkharpWCcAA9ZUA.jpg",
      "id_str" : "452711468429897728",
      "id" : 452711468429897728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkharpWCcAA9ZUA.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/w2vPMxyroe"
    } ],
    "hashtags" : [ {
      "text" : "monumentvalleygame",
      "indices" : [ 45, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/qt7uPCDoCo",
      "expanded_url" : "http:\/\/bit.ly\/mvgame",
      "display_url" : "bit.ly\/mvgame"
    } ]
  },
  "geo" : { },
  "id_str" : "452711468723474432",
  "text" : "The ghost just called me a thieving princess #monumentvalleygame http:\/\/t.co\/qt7uPCDoCo http:\/\/t.co\/w2vPMxyroe",
  "id" : 452711468723474432,
  "created_at" : "2014-04-06 07:36:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452613893731258368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597368533, -122.2756000144 ]
  },
  "id_str" : "452708714202423297",
  "in_reply_to_user_id" : 2185,
  "text" : "^^ &amp; enjoying. Wow.",
  "id" : 452708714202423297,
  "in_reply_to_status_id" : 452613893731258368,
  "created_at" : "2014-04-06 07:25:43 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alex choi \u2744\uFE0F\u2615\uFE0F",
      "screen_name" : "xc",
      "indices" : [ 0, 3 ],
      "id_str" : "26233",
      "id" : 26233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452680917056626688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85967818, -122.2754566 ]
  },
  "id_str" : "452681270221230080",
  "in_reply_to_user_id" : 26233,
  "text" : "@xc So far just bumbling around. Got a couple tips on how to survive the first night.",
  "id" : 452681270221230080,
  "in_reply_to_status_id" : 452680917056626688,
  "created_at" : "2014-04-06 05:36:39 +0000",
  "in_reply_to_screen_name" : "xc",
  "in_reply_to_user_id_str" : "26233",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "indices" : [ 3, 17 ],
      "id_str" : "1236101",
      "id" : 1236101
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BenedictEvans\/status\/452184288323047426\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/VJjGKCjfw5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkZ7NtqCMAAs2cP.jpg",
      "id_str" : "452184288121729024",
      "id" : 452184288121729024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkZ7NtqCMAAs2cP.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 852
      } ],
      "display_url" : "pic.twitter.com\/VJjGKCjfw5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452664988700643328",
  "text" : "RT @BenedictEvans: Apps versus Weight Watchers http:\/\/t.co\/VJjGKCjfw5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BenedictEvans\/status\/452184288323047426\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/VJjGKCjfw5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkZ7NtqCMAAs2cP.jpg",
        "id_str" : "452184288121729024",
        "id" : 452184288121729024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkZ7NtqCMAAs2cP.jpg",
        "sizes" : [ {
          "h" : 1136,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 852
        } ],
        "display_url" : "pic.twitter.com\/VJjGKCjfw5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "452184288323047426",
    "text" : "Apps versus Weight Watchers http:\/\/t.co\/VJjGKCjfw5",
    "id" : 452184288323047426,
    "created_at" : "2014-04-04 20:41:50 +0000",
    "user" : {
      "name" : "Benedict Evans",
      "screen_name" : "BenedictEvans",
      "protected" : false,
      "id_str" : "1236101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454333621331976193\/AX-M-ESC_normal.jpeg",
      "id" : 1236101,
      "verified" : false
    }
  },
  "id" : 452664988700643328,
  "created_at" : "2014-04-06 04:31:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596282658, -122.2754858528 ]
  },
  "id_str" : "452658519171280896",
  "text" : "First lesson I've learned from finally playing Minecraft is how quickly one goes from punching grass to building palaces in one's honor.",
  "id" : 452658519171280896,
  "created_at" : "2014-04-06 04:06:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/axzveMvwOb",
      "expanded_url" : "http:\/\/flic.kr\/p\/mNUHBk",
      "display_url" : "flic.kr\/p\/mNUHBk"
    } ]
  },
  "geo" : { },
  "id_str" : "452654682377555968",
  "text" : "8:36pm Still a newbie at the fine craft of mining. Who's a pro with tips? http:\/\/t.co\/axzveMvwOb",
  "id" : 452654682377555968,
  "created_at" : "2014-04-06 03:51:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 18, 29 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/waxpancake\/status\/452586776582844416\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/VnaEIKmx8q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkfpRnJCcAEE6Do.png",
      "id_str" : "452586776347963393",
      "id" : 452586776347963393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkfpRnJCcAEE6Do.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VnaEIKmx8q"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/1yc9mXrREm",
      "expanded_url" : "http:\/\/www.monumentvalleygame.com",
      "display_url" : "monumentvalleygame.com"
    } ]
  },
  "in_reply_to_status_id_str" : "452586776582844416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597160862, -122.2755207791 ]
  },
  "id_str" : "452613893731258368",
  "in_reply_to_user_id" : 13461,
  "text" : "Downloading... RT @waxpancake: Monument Valley is so good. Go buy it right now. http:\/\/t.co\/1yc9mXrREm http:\/\/t.co\/VnaEIKmx8q",
  "id" : 452613893731258368,
  "in_reply_to_status_id" : 452586776582844416,
  "created_at" : "2014-04-06 01:08:56 +0000",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "DietBet",
      "screen_name" : "DietBet",
      "indices" : [ 11, 19 ],
      "id_str" : "185399301",
      "id" : 185399301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452604104162828288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596284753, -122.2755113338 ]
  },
  "id_str" : "452613036017074176",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne @DietBet Yeah lame move DietBet. I lost my money fair and square but Kellianne actually submitted a winning weigh in in time.",
  "id" : 452613036017074176,
  "in_reply_to_status_id" : 452604104162828288,
  "created_at" : "2014-04-06 01:05:31 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452554035355070464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597653099, -122.2755043769 ]
  },
  "id_str" : "452585817429385216",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim I just might! Just learning it myself and can't even figure out how to make torches.",
  "id" : 452585817429385216,
  "in_reply_to_status_id" : 452554035355070464,
  "created_at" : "2014-04-05 23:17:22 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Weil",
      "screen_name" : "kevinweil",
      "indices" : [ 0, 10 ],
      "id_str" : "3452911",
      "id" : 3452911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452540085024473088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596938279, -122.2756620788 ]
  },
  "id_str" : "452546143088439296",
  "in_reply_to_user_id" : 3452911,
  "text" : "@kevinweil That's amazing. \uD83D\uDC4F\uD83D\uDC4F\uD83D\uDC4F",
  "id" : 452546143088439296,
  "in_reply_to_status_id" : 452540085024473088,
  "created_at" : "2014-04-05 20:39:43 +0000",
  "in_reply_to_screen_name" : "kevinweil",
  "in_reply_to_user_id_str" : "3452911",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8616646491, -122.2806134821 ]
  },
  "id_str" : "452534128324255744",
  "text" : "Niko's first question upon waking up was about how the Sun was made. Then he said he was ready to learn Minecraft. Best parenting day yet!",
  "id" : 452534128324255744,
  "created_at" : "2014-04-05 19:51:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 8, 16 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452366857690185728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597700457, -122.2755533272 ]
  },
  "id_str" : "452483325970489345",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey @dreeves I definitely will, there's a pretty good chance I'm completely backwards here.",
  "id" : 452483325970489345,
  "in_reply_to_status_id" : 452366857690185728,
  "created_at" : "2014-04-05 16:30:06 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beeminder",
      "screen_name" : "bmndr",
      "indices" : [ 0, 6 ],
      "id_str" : "121250669",
      "id" : 121250669
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 7, 15 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452341516824887296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597410024, -122.2753862758 ]
  },
  "id_str" : "452342645994430464",
  "in_reply_to_user_id" : 121250669,
  "text" : "@bmndr @dreeves I guess I just don't buy it (ba dum). Need to learn more to see if my hunch moves.",
  "id" : 452342645994430464,
  "in_reply_to_status_id" : 452341516824887296,
  "created_at" : "2014-04-05 07:11:05 +0000",
  "in_reply_to_screen_name" : "bmndr",
  "in_reply_to_user_id_str" : "121250669",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felix Salmon",
      "screen_name" : "felixsalmon",
      "indices" : [ 3, 15 ],
      "id_str" : "16399949",
      "id" : 16399949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/H5kmFf9SK5",
      "expanded_url" : "http:\/\/reut.rs\/1kxPgS6",
      "display_url" : "reut.rs\/1kxPgS6"
    } ]
  },
  "geo" : { },
  "id_str" : "452341194656202752",
  "text" : "RT @felixsalmon: Stop adding up the wealth of the poor http:\/\/t.co\/H5kmFf9SK5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/H5kmFf9SK5",
        "expanded_url" : "http:\/\/reut.rs\/1kxPgS6",
        "display_url" : "reut.rs\/1kxPgS6"
      } ]
    },
    "geo" : { },
    "id_str" : "452218828475219968",
    "text" : "Stop adding up the wealth of the poor http:\/\/t.co\/H5kmFf9SK5",
    "id" : 452218828475219968,
    "created_at" : "2014-04-04 22:59:05 +0000",
    "user" : {
      "name" : "Felix Salmon",
      "screen_name" : "felixsalmon",
      "protected" : false,
      "id_str" : "16399949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453561742920929280\/Seu5dsPA_normal.jpeg",
      "id" : 16399949,
      "verified" : true
    }
  },
  "id" : 452341194656202752,
  "created_at" : "2014-04-05 07:05:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452336094307024896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597005353, -122.2753969409 ]
  },
  "id_str" : "452336612597198849",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves I have no idea. I just buy market index funds and companies I plan on holding for a very long time.",
  "id" : 452336612597198849,
  "in_reply_to_status_id" : 452336094307024896,
  "created_at" : "2014-04-05 06:47:07 +0000",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452334745209171968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8600175313, -122.2750217939 ]
  },
  "id_str" : "452335146503393280",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves I don't think that's true. Maybe for large orders... and you can a always set a limit.",
  "id" : 452335146503393280,
  "in_reply_to_status_id" : 452334745209171968,
  "created_at" : "2014-04-05 06:41:17 +0000",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452333106519736320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596844526, -122.2754370934 ]
  },
  "id_str" : "452334637709135872",
  "in_reply_to_user_id" : 2185,
  "text" : "@dreeves Lastly, most small orders never get seen by HFT. They work large orders from banks\/institutions\/etc who rake money in by boatload.",
  "id" : 452334637709135872,
  "in_reply_to_status_id" : 452333106519736320,
  "created_at" : "2014-04-05 06:39:16 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452332578041643008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596420316, -122.2754939991 ]
  },
  "id_str" : "452333106519736320",
  "in_reply_to_user_id" : 2185,
  "text" : "@dreeves Also, with electronic ordering and increased liquidity, fees have gone way down. That seems to indicate fewer agent involved.",
  "id" : 452333106519736320,
  "in_reply_to_status_id" : 452332578041643008,
  "created_at" : "2014-04-05 06:33:11 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452331810408521728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596760007, -122.2754444462 ]
  },
  "id_str" : "452332578041643008",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves Not true. 1) Limit orders let you control the price you want to pay. 2) There've always been lots of people between me and cashier.",
  "id" : 452332578041643008,
  "in_reply_to_status_id" : 452331810408521728,
  "created_at" : "2014-04-05 06:31:05 +0000",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596452458, -122.2754820372 ]
  },
  "id_str" : "452326374942842880",
  "text" : "What if the global stock market becomes sentient &amp; chooses to announce its arrival w\/ a global crash that sucks up all our money in 1 move?",
  "id" : 452326374942842880,
  "created_at" : "2014-04-05 06:06:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiffany Dohzen",
      "screen_name" : "tdohz",
      "indices" : [ 0, 6 ],
      "id_str" : "101424163",
      "id" : 101424163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452320046845394944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596124659, -122.2753628065 ]
  },
  "id_str" : "452320399368257537",
  "in_reply_to_user_id" : 101424163,
  "text" : "@tdohz I've only read reviews of it, which is why I professed to knowing absolutely nothing. Seems like a field where nobody is trustworthy.",
  "id" : 452320399368257537,
  "in_reply_to_status_id" : 452320046845394944,
  "created_at" : "2014-04-05 05:42:41 +0000",
  "in_reply_to_screen_name" : "tdohz",
  "in_reply_to_user_id_str" : "101424163",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452313114805952512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595560544, -122.2755015687 ]
  },
  "id_str" : "452315884858511360",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Classic brainwasher move.",
  "id" : 452315884858511360,
  "in_reply_to_status_id" : 452313114805952512,
  "created_at" : "2014-04-05 05:24:45 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McCabe",
      "screen_name" : "Patrick7m",
      "indices" : [ 0, 10 ],
      "id_str" : "279881947",
      "id" : 279881947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452315246976565248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595759045, -122.2755939937 ]
  },
  "id_str" : "452315722538942465",
  "in_reply_to_user_id" : 279881947,
  "text" : "@Patrick7m That was done by people not algorithms. That's an ongoing risk either way.",
  "id" : 452315722538942465,
  "in_reply_to_status_id" : 452315246976565248,
  "created_at" : "2014-04-05 05:24:06 +0000",
  "in_reply_to_screen_name" : "Patrick7m",
  "in_reply_to_user_id_str" : "279881947",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy Jacobson",
      "screen_name" : "jimmyjacobson",
      "indices" : [ 3, 17 ],
      "id_str" : "17545050",
      "id" : 17545050
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 19, 26 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452315194673213440",
  "text" : "RT @jimmyjacobson: @buster I wonder if I can apply HFT principles to this 10-12 youth soccer lineup I'm working on for tomorrow. Subs every\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "452313710317424641",
    "geo" : { },
    "id_str" : "452314412594896896",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster I wonder if I can apply HFT principles to this 10-12 youth soccer lineup I'm working on for tomorrow. Subs every 30 seconds.",
    "id" : 452314412594896896,
    "in_reply_to_status_id" : 452313710317424641,
    "created_at" : "2014-04-05 05:18:54 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Jimmy Jacobson",
      "screen_name" : "jimmyjacobson",
      "protected" : false,
      "id_str" : "17545050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422075733259739136\/vBtrgoED_normal.jpeg",
      "id" : 17545050,
      "verified" : false
    }
  },
  "id" : 452315194673213440,
  "created_at" : "2014-04-05 05:22:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy Jacobson",
      "screen_name" : "jimmyjacobson",
      "indices" : [ 0, 14 ],
      "id_str" : "17545050",
      "id" : 17545050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452314412594896896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859650309, -122.2755312557 ]
  },
  "id_str" : "452314579180060672",
  "in_reply_to_user_id" : 17545050,
  "text" : "@jimmyjacobson Ha!",
  "id" : 452314579180060672,
  "in_reply_to_status_id" : 452314412594896896,
  "created_at" : "2014-04-05 05:19:33 +0000",
  "in_reply_to_screen_name" : "jimmyjacobson",
  "in_reply_to_user_id_str" : "17545050",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McCabe",
      "screen_name" : "Patrick7m",
      "indices" : [ 0, 10 ],
      "id_str" : "279881947",
      "id" : 279881947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452313601022251008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596675256, -122.2755447192 ]
  },
  "id_str" : "452314136978784256",
  "in_reply_to_user_id" : 279881947,
  "text" : "@Patrick7m They become fish for more experienced traders to rob (even before HFT). Casual investors should buy rarely and hold long.",
  "id" : 452314136978784256,
  "in_reply_to_status_id" : 452313601022251008,
  "created_at" : "2014-04-05 05:17:48 +0000",
  "in_reply_to_screen_name" : "Patrick7m",
  "in_reply_to_user_id_str" : "279881947",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy Jacobson",
      "screen_name" : "jimmyjacobson",
      "indices" : [ 0, 14 ],
      "id_str" : "17545050",
      "id" : 17545050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452313366220910592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596993774, -122.275536832 ]
  },
  "id_str" : "452313710317424641",
  "in_reply_to_user_id" : 17545050,
  "text" : "@jimmyjacobson There are no bug free alternatives on the table. Bugs are rampant in both machines and humans.",
  "id" : 452313710317424641,
  "in_reply_to_status_id" : 452313366220910592,
  "created_at" : "2014-04-05 05:16:06 +0000",
  "in_reply_to_screen_name" : "jimmyjacobson",
  "in_reply_to_user_id_str" : "17545050",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick McCabe",
      "screen_name" : "Patrick7m",
      "indices" : [ 0, 10 ],
      "id_str" : "279881947",
      "id" : 279881947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452312023720669185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597611581, -122.2752838624 ]
  },
  "id_str" : "452312901211004928",
  "in_reply_to_user_id" : 279881947,
  "text" : "@Patrick7m It lowers trading costs, spreads, increases liquidity, and discourages day trading for casual investors, amongst other things.",
  "id" : 452312901211004928,
  "in_reply_to_status_id" : 452312023720669185,
  "created_at" : "2014-04-05 05:12:53 +0000",
  "in_reply_to_screen_name" : "Patrick7m",
  "in_reply_to_user_id_str" : "279881947",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452311774067306496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595229643, -122.2756050621 ]
  },
  "id_str" : "452312472217612288",
  "in_reply_to_user_id" : 2185,
  "text" : "There's new uncertainty about what risks we're exposing the market to, but I think risk is a good thing. \"Certainty\" is what makes bubbles.",
  "id" : 452312472217612288,
  "in_reply_to_status_id" : 452311774067306496,
  "created_at" : "2014-04-05 05:11:11 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452310814729326593",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595410811, -122.2756412654 ]
  },
  "id_str" : "452311774067306496",
  "in_reply_to_user_id" : 2185,
  "text" : "Yes some HFTers made a ton of money, but it was probably taken more from other orgs\/banks making tons of money. &amp; now it's less profitable.",
  "id" : 452311774067306496,
  "in_reply_to_status_id" : 452310814729326593,
  "created_at" : "2014-04-05 05:08:25 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596460516, -122.2754783012 ]
  },
  "id_str" : "452310814729326593",
  "text" : "I know basically zero about high frequency trading but that hasn't stopped me from believing it's probably more helpful than harmful.",
  "id" : 452310814729326593,
  "created_at" : "2014-04-05 05:04:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596650098, -122.2754184602 ]
  },
  "id_str" : "452308967012564992",
  "text" : "Think Tesla will ever make something like a EuroVan? Cause I'd Kickstarter that.",
  "id" : 452308967012564992,
  "created_at" : "2014-04-05 04:57:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/452302347973054464\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/XhxQAMiowR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkbmloYCUAAWfxN.jpg",
      "id_str" : "452302346765094912",
      "id" : 452302346765094912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkbmloYCUAAWfxN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XhxQAMiowR"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/452302347973054464\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/XhxQAMiowR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkbmlNkCYAETi2V.jpg",
      "id_str" : "452302339567673345",
      "id" : 452302339567673345,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkbmlNkCYAETi2V.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/XhxQAMiowR"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/452302347973054464\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/XhxQAMiowR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bkbmi8tCUAAfrJP.jpg",
      "id_str" : "452302300682276864",
      "id" : 452302300682276864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bkbmi8tCUAAfrJP.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XhxQAMiowR"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/452302347973054464\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/XhxQAMiowR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkbmjDuCAAAeQaa.jpg",
      "id_str" : "452302302565498880",
      "id" : 452302302565498880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkbmjDuCAAAeQaa.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XhxQAMiowR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8599268, -122.27565491 ]
  },
  "id_str" : "452302347973054464",
  "text" : "8:36pm Back from Asilomar, just feeling like posting more beach shots. http:\/\/t.co\/XhxQAMiowR",
  "id" : 452302347973054464,
  "created_at" : "2014-04-05 04:30:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "indices" : [ 0, 12 ],
      "id_str" : "289534689",
      "id" : 289534689
    }, {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 27, 41 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452292308046585856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595767765, -122.2755116287 ]
  },
  "id_str" : "452300373609304064",
  "in_reply_to_user_id" : 289534689,
  "text" : "@seriouspony I never will, @buster_ebooks is my legacy.",
  "id" : 452300373609304064,
  "in_reply_to_status_id" : 452292308046585856,
  "created_at" : "2014-04-05 04:23:07 +0000",
  "in_reply_to_screen_name" : "seriouspony",
  "in_reply_to_user_id_str" : "289534689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 13, 21 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Adam Dole",
      "screen_name" : "adamdole",
      "indices" : [ 22, 31 ],
      "id_str" : "14789168",
      "id" : 14789168
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 32, 48 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Karan Singh",
      "screen_name" : "kvsingh",
      "indices" : [ 49, 57 ],
      "id_str" : "14818867",
      "id" : 14818867
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 58, 65 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "maxutter",
      "screen_name" : "maxutter",
      "indices" : [ 66, 75 ],
      "id_str" : "16977297",
      "id" : 16977297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452145092585730048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.6188801593, -121.9378670679 ]
  },
  "id_str" : "452157842774974464",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker @dreeves @adamdole @tonystubblebine @kvsingh @cwhogg @maxutter Whatever this is about, count me in!",
  "id" : 452157842774974464,
  "in_reply_to_status_id" : 452145092585730048,
  "created_at" : "2014-04-04 18:56:45 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MediaREDEF",
      "screen_name" : "MediaREDEF",
      "indices" : [ 3, 14 ],
      "id_str" : "24438551",
      "id" : 24438551
    }, {
      "name" : "Mark Cuban",
      "screen_name" : "mcuban",
      "indices" : [ 60, 67 ],
      "id_str" : "16228398",
      "id" : 16228398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/DMssQT1U20",
      "expanded_url" : "http:\/\/redef.it\/d01N",
      "display_url" : "redef.it\/d01N"
    } ]
  },
  "geo" : { },
  "id_str" : "451981492755759105",
  "text" : "RT @MediaREDEF: The Idiots Guide to High Frequency Trading (@mcuban - blog maverick) http:\/\/t.co\/DMssQT1U20",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Cuban",
        "screen_name" : "mcuban",
        "indices" : [ 44, 51 ],
        "id_str" : "16228398",
        "id" : 16228398
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/DMssQT1U20",
        "expanded_url" : "http:\/\/redef.it\/d01N",
        "display_url" : "redef.it\/d01N"
      } ]
    },
    "geo" : { },
    "id_str" : "451980070199259136",
    "text" : "The Idiots Guide to High Frequency Trading (@mcuban - blog maverick) http:\/\/t.co\/DMssQT1U20",
    "id" : 451980070199259136,
    "created_at" : "2014-04-04 07:10:20 +0000",
    "user" : {
      "name" : "MediaREDEF",
      "screen_name" : "MediaREDEF",
      "protected" : false,
      "id_str" : "24438551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000017516730\/1709a44517019eb6acf53ec99516f126_normal.png",
      "id" : 24438551,
      "verified" : false
    }
  },
  "id" : 451981492755759105,
  "created_at" : "2014-04-04 07:15:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/1U7WG09nTi",
      "expanded_url" : "http:\/\/flic.kr\/p\/mKa9AX",
      "display_url" : "flic.kr\/p\/mKa9AX"
    } ]
  },
  "geo" : { },
  "id_str" : "451927424327221248",
  "text" : "8:36pm S'mores time http:\/\/t.co\/1U7WG09nTi",
  "id" : 451927424327221248,
  "created_at" : "2014-04-04 03:41:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/hU5w3BWRIU",
      "expanded_url" : "https:\/\/vine.co\/v\/MiqWBrFrLFU",
      "display_url" : "vine.co\/v\/MiqWBrFrLFU"
    } ]
  },
  "geo" : { },
  "id_str" : "451904769213612032",
  "text" : "Beach dance https:\/\/t.co\/hU5w3BWRIU",
  "id" : 451904769213612032,
  "created_at" : "2014-04-04 02:11:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/451902110406160384\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/VWJfhfbvwj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkV6kvuCIAEFQFP.jpg",
      "id_str" : "451902109324025857",
      "id" : 451902109324025857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkV6kvuCIAEFQFP.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/VWJfhfbvwj"
    } ],
    "hashtags" : [ {
      "text" : "california",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.6187238145, -121.9407548659 ]
  },
  "id_str" : "451902110406160384",
  "text" : "#california http:\/\/t.co\/VWJfhfbvwj",
  "id" : 451902110406160384,
  "created_at" : "2014-04-04 02:00:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cayley",
      "screen_name" : "cayley",
      "indices" : [ 0, 7 ],
      "id_str" : "16867621",
      "id" : 16867621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451770052270772224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.6167278961, -121.9371451345 ]
  },
  "id_str" : "451875874401312770",
  "in_reply_to_user_id" : 16867621,
  "text" : "@cayley Now I can finally resume asking Falquora questions. Only downside is there will be nobody to answer them.",
  "id" : 451875874401312770,
  "in_reply_to_status_id" : 451770052270772224,
  "created_at" : "2014-04-04 00:16:18 +0000",
  "in_reply_to_screen_name" : "cayley",
  "in_reply_to_user_id_str" : "16867621",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451861746496462848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.6166694412, -121.9372178315 ]
  },
  "id_str" : "451872239189643264",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach He should take a master class in apologizing... seems like that would've helped more in this particular case.",
  "id" : 451872239189643264,
  "in_reply_to_status_id" : 451861746496462848,
  "created_at" : "2014-04-04 00:01:51 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.6166660787, -121.9374000152 ]
  },
  "id_str" : "451870793132015616",
  "text" : "Current status: eating cypress grove creamline cheese like an angry raccoon.",
  "id" : 451870793132015616,
  "created_at" : "2014-04-03 23:56:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/56tobFUgji",
      "expanded_url" : "https:\/\/blog.mozilla.org\/blog\/2014\/04\/03\/brendan-eich-steps-down-as-mozilla-ceo\/",
      "display_url" : "blog.mozilla.org\/blog\/2014\/04\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "451867770129379328",
  "text" : "RT @isaach: and there it is. \u201CBrendan Eich Steps Down as Mozilla CEO\u201D https:\/\/t.co\/56tobFUgji",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/56tobFUgji",
        "expanded_url" : "https:\/\/blog.mozilla.org\/blog\/2014\/04\/03\/brendan-eich-steps-down-as-mozilla-ceo\/",
        "display_url" : "blog.mozilla.org\/blog\/2014\/04\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "451797136984637440",
    "text" : "and there it is. \u201CBrendan Eich Steps Down as Mozilla CEO\u201D https:\/\/t.co\/56tobFUgji",
    "id" : 451797136984637440,
    "created_at" : "2014-04-03 19:03:26 +0000",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430605387117494272\/lmplHwca_normal.png",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 451867770129379328,
  "created_at" : "2014-04-03 23:44:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/LOSzwAALX3",
      "expanded_url" : "http:\/\/blog.vine.co\/post\/81606025464\/vine-messages",
      "display_url" : "blog.vine.co\/post\/816060254\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.618874, -121.93796 ]
  },
  "id_str" : "451865711258783744",
  "text" : "The new Vine messages look pretty rad. VM me! http:\/\/t.co\/LOSzwAALX3",
  "id" : 451865711258783744,
  "created_at" : "2014-04-03 23:35:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 0, 10 ],
      "id_str" : "1771141",
      "id" : 1771141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451862850181427200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.6188825065, -121.9379954973 ]
  },
  "id_str" : "451863421852471296",
  "in_reply_to_user_id" : 1771141,
  "text" : "@samantham Good thing his aim was fairly poor and missed me by at least 40 feet.",
  "id" : 451863421852471296,
  "in_reply_to_status_id" : 451862850181427200,
  "created_at" : "2014-04-03 23:26:49 +0000",
  "in_reply_to_screen_name" : "samantham",
  "in_reply_to_user_id_str" : "1771141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/451863203979354112\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/n7QFWhkSFI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkVXMAPCMAAJddY.jpg",
      "id_str" : "451863201353707520",
      "id" : 451863201353707520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkVXMAPCMAAJddY.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/n7QFWhkSFI"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/451863203979354112\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/n7QFWhkSFI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkVXL2iCUAAUr4g.jpg",
      "id_str" : "451863198749052928",
      "id" : 451863198749052928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkVXL2iCUAAUr4g.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/n7QFWhkSFI"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/451863203979354112\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/n7QFWhkSFI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkVXMAJCMAAmsl7.jpg",
      "id_str" : "451863201328541696",
      "id" : 451863201328541696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkVXMAJCMAAmsl7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/n7QFWhkSFI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.61887798, -121.937982822 ]
  },
  "id_str" : "451863203979354112",
  "text" : "Spotted a family of gray whales migrating north at Point Lobos. Seen also, but not pictured here: lazy sea otters. http:\/\/t.co\/n7QFWhkSFI",
  "id" : 451863203979354112,
  "created_at" : "2014-04-03 23:25:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.6188615213, -121.9379822099 ]
  },
  "id_str" : "451860980801081344",
  "text" : "Just watched a giant tree spontaneously split in half as I rode my bike past it.",
  "id" : 451860980801081344,
  "created_at" : "2014-04-03 23:17:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cognitive Lode",
      "screen_name" : "cogLode",
      "indices" : [ 3, 11 ],
      "id_str" : "2383547119",
      "id" : 2383547119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/cbuCu9XFP1",
      "expanded_url" : "http:\/\/ribot.co.uk\/thought\/cognitivelode\/",
      "display_url" : "ribot.co.uk\/thought\/cognit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "451739756078960640",
  "text" : "RT @cogLode: Why I was created http:\/\/t.co\/cbuCu9XFP1",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/cbuCu9XFP1",
        "expanded_url" : "http:\/\/ribot.co.uk\/thought\/cognitivelode\/",
        "display_url" : "ribot.co.uk\/thought\/cognit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "451676576921681921",
    "text" : "Why I was created http:\/\/t.co\/cbuCu9XFP1",
    "id" : 451676576921681921,
    "created_at" : "2014-04-03 11:04:22 +0000",
    "user" : {
      "name" : "Cognitive Lode",
      "screen_name" : "cogLode",
      "protected" : false,
      "id_str" : "2383547119",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443344473485869056\/nYE5KDLu_normal.png",
      "id" : 2383547119,
      "verified" : false
    }
  },
  "id" : 451739756078960640,
  "created_at" : "2014-04-03 15:15:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Haggerty",
      "screen_name" : "bhaggs",
      "indices" : [ 0, 7 ],
      "id_str" : "1692881",
      "id" : 1692881
    }, {
      "name" : "Dropcam",
      "screen_name" : "Dropcam",
      "indices" : [ 8, 16 ],
      "id_str" : "19823750",
      "id" : 19823750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451577338455552001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.6189485975, -121.9376884495 ]
  },
  "id_str" : "451577783949328384",
  "in_reply_to_user_id" : 1692881,
  "text" : "@bhaggs @Dropcam I might get one! Though admit that my current setup makes me feel a bit more MacGyvery.",
  "id" : 451577783949328384,
  "in_reply_to_status_id" : 451577338455552001,
  "created_at" : "2014-04-03 04:31:48 +0000",
  "in_reply_to_screen_name" : "bhaggs",
  "in_reply_to_user_id_str" : "1692881",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/451565505048875011\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/MEgyP4ORLy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkRIbvLCMAEropG.jpg",
      "id_str" : "451565504000307201",
      "id" : 451565504000307201,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkRIbvLCMAEropG.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/MEgyP4ORLy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.6186993616, -121.9353984297 ]
  },
  "id_str" : "451565505048875011",
  "text" : "8:36pm Using a laptop, my iPhone, and Google Hangouts to watch Niko sleep while adults plot other places to hang. http:\/\/t.co\/MEgyP4ORLy",
  "id" : 451565505048875011,
  "created_at" : "2014-04-03 03:43:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451555416015532032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.6186097414, -121.9354879763 ]
  },
  "id_str" : "451562040537006081",
  "in_reply_to_user_id" : 2185,
  "text" : "Does that first photo look distorted and crazy to others or just me?",
  "id" : 451562040537006081,
  "in_reply_to_status_id" : 451555416015532032,
  "created_at" : "2014-04-03 03:29:14 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/451555416015532032\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/h6FLpRlNPZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkQ_QYyCUAAKxch.jpg",
      "id_str" : "451555413406666752",
      "id" : 451555413406666752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkQ_QYyCUAAKxch.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/h6FLpRlNPZ"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/451555416015532032\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/h6FLpRlNPZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkQ_QazCcAA89Vc.jpg",
      "id_str" : "451555413947740160",
      "id" : 451555413947740160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkQ_QazCcAA89Vc.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/h6FLpRlNPZ"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/451555416015532032\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/h6FLpRlNPZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkQ_QYvCMAAZ2Ez.jpg",
      "id_str" : "451555413394075648",
      "id" : 451555413394075648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkQ_QYvCMAAZ2Ez.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/h6FLpRlNPZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.6167171072, -121.9372425945 ]
  },
  "id_str" : "451555416015532032",
  "text" : "Tide pools http:\/\/t.co\/h6FLpRlNPZ",
  "id" : 451555416015532032,
  "created_at" : "2014-04-03 03:02:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 31, 42 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451482087309070337",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.6189339711, -121.9377878589 ]
  },
  "id_str" : "451482454096740352",
  "in_reply_to_user_id" : 142467448,
  "text" : "It doesn't completely suck. RT @nikobenson: I don't hate spending 3 days at the beach.",
  "id" : 451482454096740352,
  "in_reply_to_status_id" : 451482087309070337,
  "created_at" : "2014-04-02 22:12:59 +0000",
  "in_reply_to_screen_name" : "nikobenson",
  "in_reply_to_user_id_str" : "142467448",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Support",
      "screen_name" : "Support",
      "indices" : [ 8, 16 ],
      "id_str" : "17874544",
      "id" : 17874544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "emojiparty",
      "indices" : [ 110, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451405281310687232",
  "text" : "Rad. RT @Support: \uD83D\uDE0D Twitter users love tweeting emoji from their phones. Now you can view these emoji on web! #emojiparty \uD83C\uDF89 \uD83D\uDE1C \uD83D\uDC6F \uD83C\uDF7B  \uD83C\uDFA4 \uD83C\uDFAE \uD83D\uDE80 \uD83C\uDF09 \u2728",
  "id" : 451405281310687232,
  "created_at" : "2014-04-02 17:06:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451389908892934144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597125458, -122.2756027804 ]
  },
  "id_str" : "451391864797540352",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover Me too, and I don't have a game console either. But I want my 3yo to play!",
  "id" : 451391864797540352,
  "in_reply_to_status_id" : 451389908892934144,
  "created_at" : "2014-04-02 16:13:01 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596825833, -122.2756170437 ]
  },
  "id_str" : "451389395648536576",
  "text" : "Amazon's Fire TV's killer feature (to me) is Minecraft.",
  "id" : 451389395648536576,
  "created_at" : "2014-04-02 16:03:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Hatter",
      "screen_name" : "sh",
      "indices" : [ 0, 3 ],
      "id_str" : "4037",
      "id" : 4037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451383650030858240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596900823, -122.2755441071 ]
  },
  "id_str" : "451385397046558722",
  "in_reply_to_user_id" : 4037,
  "text" : "@sh Exactly.",
  "id" : 451385397046558722,
  "in_reply_to_status_id" : 451383650030858240,
  "created_at" : "2014-04-02 15:47:19 +0000",
  "in_reply_to_screen_name" : "sh",
  "in_reply_to_user_id_str" : "4037",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Hatter",
      "screen_name" : "sh",
      "indices" : [ 0, 3 ],
      "id_str" : "4037",
      "id" : 4037
    }, {
      "name" : "CoSupport",
      "screen_name" : "cosupport",
      "indices" : [ 4, 14 ],
      "id_str" : "243233537",
      "id" : 243233537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451369866851676160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596556327, -122.275480237 ]
  },
  "id_str" : "451378216075161600",
  "in_reply_to_user_id" : 4037,
  "text" : "@sh @cosupport Great article! Can you also address why it feels so wrong when people say \"I'm sorry you were pained by what I did\"?",
  "id" : 451378216075161600,
  "in_reply_to_status_id" : 451369866851676160,
  "created_at" : "2014-04-02 15:18:47 +0000",
  "in_reply_to_screen_name" : "sh",
  "in_reply_to_user_id_str" : "4037",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Hatter",
      "screen_name" : "sh",
      "indices" : [ 3, 6 ],
      "id_str" : "4037",
      "id" : 4037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/VHIOfDdMwp",
      "expanded_url" : "http:\/\/cosupport.com\/hypothetical-apologies-and-pizza-dreams\/",
      "display_url" : "cosupport.com\/hypothetical-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "451377871416610816",
  "text" : "RT @sh: \"So what\u2019s the harm if we say we\u2019re sorry and we mean it, even when it\u2019s not our fault?\" http:\/\/t.co\/VHIOfDdMwp",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/VHIOfDdMwp",
        "expanded_url" : "http:\/\/cosupport.com\/hypothetical-apologies-and-pizza-dreams\/",
        "display_url" : "cosupport.com\/hypothetical-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "451369866851676160",
    "text" : "\"So what\u2019s the harm if we say we\u2019re sorry and we mean it, even when it\u2019s not our fault?\" http:\/\/t.co\/VHIOfDdMwp",
    "id" : 451369866851676160,
    "created_at" : "2014-04-02 14:45:36 +0000",
    "user" : {
      "name" : "Sarah Hatter",
      "screen_name" : "sh",
      "protected" : false,
      "id_str" : "4037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432907123643514880\/NFPWwdyI_normal.jpeg",
      "id" : 4037,
      "verified" : false
    }
  },
  "id" : 451377871416610816,
  "created_at" : "2014-04-02 15:17:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katia Verresen",
      "screen_name" : "kvaleadership",
      "indices" : [ 42, 56 ],
      "id_str" : "183809041",
      "id" : 183809041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/om6qy25hz9",
      "expanded_url" : "http:\/\/shar.es\/Bx8uC",
      "display_url" : "shar.es\/Bx8uC"
    } ]
  },
  "in_reply_to_status_id_str" : "451361822495358976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596888013, -122.2755031138 ]
  },
  "id_str" : "451369304500338688",
  "in_reply_to_user_id" : 183809041,
  "text" : "My bet is it's neither Nest nor Oculus RT @kvaleadership: The search for the next platform http:\/\/t.co\/om6qy25hz9",
  "id" : 451369304500338688,
  "in_reply_to_status_id" : 451361822495358976,
  "created_at" : "2014-04-02 14:43:22 +0000",
  "in_reply_to_screen_name" : "kvaleadership",
  "in_reply_to_user_id_str" : "183809041",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597410605, -122.2755749182 ]
  },
  "id_str" : "451247264950788097",
  "text" : "TIL from DayQuil-induced Hulu binging: Game of Thrones starts up again in 5 days!",
  "id" : 451247264950788097,
  "created_at" : "2014-04-02 06:38:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Underwood",
      "screen_name" : "aunder",
      "indices" : [ 0, 7 ],
      "id_str" : "4265731",
      "id" : 4265731
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twobirds",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451241948037128192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596449877, -122.2755881121 ]
  },
  "id_str" : "451243258065068033",
  "in_reply_to_user_id" : 4265731,
  "text" : "@aunder Thanks, luckily I'm double-booking the rest of the week for sick vacation. #twobirds",
  "id" : 451243258065068033,
  "in_reply_to_status_id" : 451241948037128192,
  "created_at" : "2014-04-02 06:22:31 +0000",
  "in_reply_to_screen_name" : "aunder",
  "in_reply_to_user_id_str" : "4265731",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Colbert",
      "screen_name" : "StephenAtHome",
      "indices" : [ 9, 23 ],
      "id_str" : "16303106",
      "id" : 16303106
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CancelColbert",
      "indices" : [ 44, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859716364, -122.2755698687 ]
  },
  "id_str" : "451238566559895552",
  "text" : "Watching @StephenAtHome's Monday show about #CancelColbert on DayQuil.",
  "id" : 451238566559895552,
  "created_at" : "2014-04-02 06:03:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stillsick",
      "indices" : [ 38, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/u5rIfW0N3J",
      "expanded_url" : "http:\/\/flic.kr\/p\/mFt88p",
      "display_url" : "flic.kr\/p\/mFt88p"
    } ]
  },
  "geo" : { },
  "id_str" : "451204902950559744",
  "text" : "8:36pm It's a smurf pants kinda night #stillsick http:\/\/t.co\/u5rIfW0N3J",
  "id" : 451204902950559744,
  "created_at" : "2014-04-02 03:50:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Wander",
      "screen_name" : "jordanwander",
      "indices" : [ 0, 13 ],
      "id_str" : "6124352",
      "id" : 6124352
    }, {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 31, 39 ],
      "id_str" : "353195232",
      "id" : 353195232
    }, {
      "name" : "Reporter App",
      "screen_name" : "GetReporter",
      "indices" : [ 44, 56 ],
      "id_str" : "2201640770",
      "id" : 2201640770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451197850492600321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596622963, -122.2755107471 ]
  },
  "id_str" : "451202290112684033",
  "in_reply_to_user_id" : 6124352,
  "text" : "@jordanwander My current faves @liftapp and @GetReporter. Check them out!",
  "id" : 451202290112684033,
  "in_reply_to_status_id" : 451197850492600321,
  "created_at" : "2014-04-02 03:39:43 +0000",
  "in_reply_to_screen_name" : "jordanwander",
  "in_reply_to_user_id_str" : "6124352",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "megan gebhart",
      "screen_name" : "megangebhart",
      "indices" : [ 0, 13 ],
      "id_str" : "32966836",
      "id" : 32966836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451115839060582400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7791374217, -122.414370709 ]
  },
  "id_str" : "451130751455469568",
  "in_reply_to_user_id" : 32966836,
  "text" : "@megangebhart Oops looks like you got hacked. :(",
  "id" : 451130751455469568,
  "in_reply_to_status_id" : 451115839060582400,
  "created_at" : "2014-04-01 22:55:27 +0000",
  "in_reply_to_screen_name" : "megangebhart",
  "in_reply_to_user_id_str" : "32966836",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597496776, -122.275591381 ]
  },
  "id_str" : "451009304175194112",
  "text" : "Rabbit rabbit!",
  "id" : 451009304175194112,
  "created_at" : "2014-04-01 14:52:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]