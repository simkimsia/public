Grailbird.data.tweets_2014_05 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/466430739652018178\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/jmFsQAVI4k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnkYSNGIAAEk3ZG.jpg",
      "id_str" : "466430737441619969",
      "id" : 466430737441619969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnkYSNGIAAEk3ZG.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jmFsQAVI4k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85974533094689, -122.2754358793295 ]
  },
  "id_str" : "466430739652018178",
  "text" : "8:36pm Everyone's asleep and Sopor's happy to have her cone off http:\/\/t.co\/jmFsQAVI4k",
  "id" : 466430739652018178,
  "created_at" : "2014-05-14 04:12:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466413987165642752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85974557049373, -122.275467077384 ]
  },
  "id_str" : "466414190685868032",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin So is my woman.",
  "id" : 466414190685868032,
  "in_reply_to_status_id" : 466413987165642752,
  "created_at" : "2014-05-14 03:06:23 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malcolm Ocean",
      "screen_name" : "Malcolm_Ocean",
      "indices" : [ 0, 14 ],
      "id_str" : "49044207",
      "id" : 49044207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466410352620871680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859752904659, -122.2754507326728 ]
  },
  "id_str" : "466413944358600704",
  "in_reply_to_user_id" : 49044207,
  "text" : "@Malcolm_Ocean That would be pretty rad.",
  "id" : 466413944358600704,
  "in_reply_to_status_id" : 466410352620871680,
  "created_at" : "2014-05-14 03:05:24 +0000",
  "in_reply_to_screen_name" : "Malcolm_Ocean",
  "in_reply_to_user_id_str" : "49044207",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ramez Naam",
      "screen_name" : "ramez",
      "indices" : [ 30, 36 ],
      "id_str" : "6044272",
      "id" : 6044272
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ramez\/status\/466245751253659648\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/6qqZmW6rna",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnhwCj9CQAAQ1fF.jpg",
      "id_str" : "466245750746136576",
      "id" : 466245750746136576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnhwCj9CQAAQ1fF.jpg",
      "sizes" : [ {
        "h" : 620,
        "resize" : "fit",
        "w" : 981
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 338
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 981
      }, {
        "h" : 379,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/6qqZmW6rna"
    } ],
    "hashtags" : [ {
      "text" : "amazoncart",
      "indices" : [ 9, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/PBprI7EjiJ",
      "expanded_url" : "http:\/\/amzn.to\/17HLkHL",
      "display_url" : "amzn.to\/17HLkHL"
    } ]
  },
  "in_reply_to_status_id_str" : "466245751253659648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79298232309085, -122.396525696509 ]
  },
  "id_str" : "466390927821770753",
  "in_reply_to_user_id" : 6044272,
  "text" : "Friends, #amazoncart this: RT @ramez: 400 Amazon reviews for my novel Nexus as of today: http:\/\/t.co\/PBprI7EjiJ http:\/\/t.co\/6qqZmW6rna",
  "id" : 466390927821770753,
  "in_reply_to_status_id" : 466245751253659648,
  "created_at" : "2014-05-14 01:33:56 +0000",
  "in_reply_to_screen_name" : "ramez",
  "in_reply_to_user_id_str" : "6044272",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Mallard Air",
      "screen_name" : "MallardAir",
      "indices" : [ 17, 28 ],
      "id_str" : "2474291041",
      "id" : 2474291041
    }, {
      "name" : "Rakesh Agrawal",
      "screen_name" : "rakeshlobster",
      "indices" : [ 44, 58 ],
      "id_str" : "770550",
      "id" : 770550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466383558219927552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78638591284609, -122.4061766515261 ]
  },
  "id_str" : "466387290538139649",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine @MallardAir This has to be @rakeshlobster's new gig.",
  "id" : 466387290538139649,
  "in_reply_to_status_id" : 466383558219927552,
  "created_at" : "2014-05-14 01:19:29 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UkraineDesk",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466338847065128961",
  "geo" : { },
  "id_str" : "466339569529790464",
  "in_reply_to_user_id" : 2185,
  "text" : "\"The account will automatically tweet stories coming from partner tweets with the hashtag #UkraineDesk. No one will control the account.\"",
  "id" : 466339569529790464,
  "in_reply_to_status_id" : 466338847065128961,
  "created_at" : "2014-05-13 22:09:52 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ukraine Desk",
      "screen_name" : "ukrainedesk",
      "indices" : [ 6, 18 ],
      "id_str" : "2471274882",
      "id" : 2471274882
    }, {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "indices" : [ 22, 33 ],
      "id_str" : "419710142",
      "id" : 419710142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/V8jBCVe8Wl",
      "expanded_url" : "http:\/\/pndo.ly\/RCRarW",
      "display_url" : "pndo.ly\/RCRarW"
    } ]
  },
  "in_reply_to_status_id_str" : "466338091952009216",
  "geo" : { },
  "id_str" : "466338847065128961",
  "in_reply_to_user_id" : 419710142,
  "text" : "\u2014&gt; @ukrainedesk RT @PandoDaily: Vice, Quartz, Mashable, and others team up on a \"joint Twitter account\" about Ukraine http:\/\/t.co\/V8jBCVe8Wl",
  "id" : 466338847065128961,
  "in_reply_to_status_id" : 466338091952009216,
  "created_at" : "2014-05-13 22:06:59 +0000",
  "in_reply_to_screen_name" : "PandoDaily",
  "in_reply_to_user_id_str" : "419710142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brittany A Butler",
      "screen_name" : "BrittanyButler0",
      "indices" : [ 0, 16 ],
      "id_str" : "408768082",
      "id" : 408768082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466322405104054272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77659381183107, -122.4167722618767 ]
  },
  "id_str" : "466330800292917249",
  "in_reply_to_user_id" : 408768082,
  "text" : "@BrittanyButler0 There is general information about your tweets and followers, but we haven't scaled it up to all accounts quite yet.",
  "id" : 466330800292917249,
  "in_reply_to_status_id" : 466322405104054272,
  "created_at" : "2014-05-13 21:35:01 +0000",
  "in_reply_to_screen_name" : "BrittanyButler0",
  "in_reply_to_user_id_str" : "408768082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brittany A Butler",
      "screen_name" : "BrittanyButler0",
      "indices" : [ 0, 16 ],
      "id_str" : "408768082",
      "id" : 408768082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466307131180740608",
  "geo" : { },
  "id_str" : "466313347579641856",
  "in_reply_to_user_id" : 408768082,
  "text" : "@BrittanyButler0 It's not accessible to everyone. At the moment, it requires that the account either be an advertiser or a cards publisher.",
  "id" : 466313347579641856,
  "in_reply_to_status_id" : 466307131180740608,
  "created_at" : "2014-05-13 20:25:40 +0000",
  "in_reply_to_screen_name" : "BrittanyButler0",
  "in_reply_to_user_id_str" : "408768082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/466015217504112640\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/hyvkioflqG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BneeXqXCMAAV5L8.jpg",
      "id_str" : "466015215801217024",
      "id" : 466015215801217024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BneeXqXCMAAV5L8.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hyvkioflqG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.6376627128, -84.4320997231 ]
  },
  "id_str" : "466015217504112640",
  "text" : "8:36pm Richmond \u2708\uFE0F SFO via Atlanta http:\/\/t.co\/hyvkioflqG",
  "id" : 466015217504112640,
  "created_at" : "2014-05-13 00:41:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GameOfThrones",
      "indices" : [ 32, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.5621436257, -77.4792944268 ]
  },
  "id_str" : "465659892121235457",
  "text" : "I really hope nobody gets hurt. #GameOfThrones",
  "id" : 465659892121235457,
  "created_at" : "2014-05-12 01:09:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/hOEBWZy8kY",
      "expanded_url" : "https:\/\/flic.kr\/p\/nidhAb",
      "display_url" : "flic.kr\/p\/nidhAb"
    } ]
  },
  "geo" : { },
  "id_str" : "465652790425944064",
  "text" : "8:36pm We're in the leftovers and YouTube music videos portion of Mother's Day evening https:\/\/t.co\/hOEBWZy8kY",
  "id" : 465652790425944064,
  "created_at" : "2014-05-12 00:40:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465634014053675008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.5622425741, -77.4792612345 ]
  },
  "id_str" : "465639760816795649",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel He cried and hid under the covers during Gmork and Artax's death scenes. But he came out pretty quickly.",
  "id" : 465639760816795649,
  "in_reply_to_status_id" : 465634014053675008,
  "created_at" : "2014-05-11 23:49:04 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/fhHsQf6FT5",
      "expanded_url" : "https:\/\/vine.co\/v\/MgjqXx9Yiuq",
      "display_url" : "vine.co\/v\/MgjqXx9Yiuq"
    } ]
  },
  "geo" : { },
  "id_str" : "465634384205602816",
  "text" : "Niko, day 3 of new roller skates https:\/\/t.co\/fhHsQf6FT5",
  "id" : 465634384205602816,
  "created_at" : "2014-05-11 23:27:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.5623712859, -77.4790286345 ]
  },
  "id_str" : "465619631940845569",
  "text" : "Just watched a movie that blew Niko's mind. Hint: \"Moon-chi-ld!\"",
  "id" : 465619631940845569,
  "created_at" : "2014-05-11 22:29:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 21, 31 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/465475049060065280\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/jBtk925kBl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnWzFskCAAAkVVb.jpg",
      "id_str" : "465475046945718272",
      "id" : 465475046945718272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnWzFskCAAAkVVb.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jBtk925kBl"
    } ],
    "hashtags" : [ {
      "text" : "MothersDay",
      "indices" : [ 6, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.56236634, -77.47900649 ]
  },
  "id_str" : "465475049060065280",
  "text" : "Happy #MothersDay to @Kellianne! Beauteous maximus mom and a million other things! http:\/\/t.co\/jBtk925kBl",
  "id" : 465475049060065280,
  "created_at" : "2014-05-11 12:54:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/465469598834634752\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/V8xwkLD0Ny",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnWuIAbIcAAU1N1.jpg",
      "id_str" : "465469589078700032",
      "id" : 465469589078700032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnWuIAbIcAAU1N1.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/V8xwkLD0Ny"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/465469598834634752\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/V8xwkLD0Ny",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnWuIMiIQAAnM7R.jpg",
      "id_str" : "465469592329273344",
      "id" : 465469592329273344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnWuIMiIQAAnM7R.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/V8xwkLD0Ny"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/465469598834634752\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/V8xwkLD0Ny",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnWuIU_IAAAUvFn.jpg",
      "id_str" : "465469594598375424",
      "id" : 465469594598375424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnWuIU_IAAAUvFn.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/V8xwkLD0Ny"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/465469598834634752\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/V8xwkLD0Ny",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnWuIMQIQAA7j0H.jpg",
      "id_str" : "465469592253775872",
      "id" : 465469592253775872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnWuIMQIQAA7j0H.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/V8xwkLD0Ny"
    } ],
    "hashtags" : [ {
      "text" : "MothersDay",
      "indices" : [ 22, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465469598834634752",
  "text" : "My mom is cool. Happy #MothersDay. http:\/\/t.co\/V8xwkLD0Ny",
  "id" : 465469598834634752,
  "created_at" : "2014-05-11 12:32:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/465202934566100992\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/tzD4VR6RwP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnS7mnRIAAA2TMi.jpg",
      "id_str" : "465202933576237056",
      "id" : 465202933576237056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnS7mnRIAAA2TMi.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tzD4VR6RwP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.55750277548801, -77.48865709647302 ]
  },
  "id_str" : "465202934566100992",
  "text" : "New family reunion! http:\/\/t.co\/tzD4VR6RwP",
  "id" : 465202934566100992,
  "created_at" : "2014-05-10 18:53:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aurelia Cotta",
      "screen_name" : "AureliaCotta",
      "indices" : [ 0, 13 ],
      "id_str" : "19055125",
      "id" : 19055125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464980184534220800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6874382997, -77.4217755286 ]
  },
  "id_str" : "464980391838093313",
  "in_reply_to_user_id" : 19055125,
  "text" : "@AureliaCotta It's great!",
  "id" : 464980391838093313,
  "in_reply_to_status_id" : 464980184534220800,
  "created_at" : "2014-05-10 04:08:58 +0000",
  "in_reply_to_screen_name" : "AureliaCotta",
  "in_reply_to_user_id_str" : "19055125",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen",
      "screen_name" : "gln",
      "indices" : [ 0, 4 ],
      "id_str" : "4366051",
      "id" : 4366051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464979298349101056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6875361428, -77.4216975086 ]
  },
  "id_str" : "464979745600720897",
  "in_reply_to_user_id" : 4366051,
  "text" : "@gln Yeah that sealed the deal for any doubts.",
  "id" : 464979745600720897,
  "in_reply_to_status_id" : 464979298349101056,
  "created_at" : "2014-05-10 04:06:24 +0000",
  "in_reply_to_screen_name" : "gln",
  "in_reply_to_user_id_str" : "4366051",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omid Ashtari",
      "screen_name" : "omid",
      "indices" : [ 0, 5 ],
      "id_str" : "114971521",
      "id" : 114971521
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 6, 14 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464978919595053057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6875136718, -77.4217074789 ]
  },
  "id_str" : "464979486002659328",
  "in_reply_to_user_id" : 114971521,
  "text" : "@omid @23andMe That's the one!",
  "id" : 464979486002659328,
  "in_reply_to_status_id" : 464978919595053057,
  "created_at" : "2014-05-10 04:05:23 +0000",
  "in_reply_to_screen_name" : "omid",
  "in_reply_to_user_id_str" : "114971521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/464978340919529472\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/PMVCB5LF6U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnPvVXkIQAEkk6u.jpg",
      "id_str" : "464978336931135489",
      "id" : 464978336931135489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnPvVXkIQAEkk6u.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PMVCB5LF6U"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6874262748, -77.4215945237 ]
  },
  "id_str" : "464978340919529472",
  "text" : "8:36pm Met my brother today http:\/\/t.co\/PMVCB5LF6U",
  "id" : 464978340919529472,
  "created_at" : "2014-05-10 04:00:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 3, 14 ],
      "id_str" : "14120151",
      "id" : 14120151
    }, {
      "name" : "Swarm",
      "screen_name" : "swarmapp",
      "indices" : [ 41, 50 ],
      "id_str" : "240676055",
      "id" : 240676055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/vFkRs36Zgm",
      "expanded_url" : "http:\/\/bit.ly\/1uKfqb5",
      "display_url" : "bit.ly\/1uKfqb5"
    } ]
  },
  "geo" : { },
  "id_str" : "464837311029850112",
  "text" : "RT @foursquare: Mayorships and more: How @swarmapp is going to make your experiences more fun and playful http:\/\/t.co\/vFkRs36Zgm",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Swarm",
        "screen_name" : "swarmapp",
        "indices" : [ 25, 34 ],
        "id_str" : "240676055",
        "id" : 240676055
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/vFkRs36Zgm",
        "expanded_url" : "http:\/\/bit.ly\/1uKfqb5",
        "display_url" : "bit.ly\/1uKfqb5"
      } ]
    },
    "geo" : { },
    "id_str" : "464825793705938944",
    "text" : "Mayorships and more: How @swarmapp is going to make your experiences more fun and playful http:\/\/t.co\/vFkRs36Zgm",
    "id" : 464825793705938944,
    "created_at" : "2014-05-09 17:54:39 +0000",
    "user" : {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "protected" : false,
      "id_str" : "14120151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000770738444\/25695fb17af43d668149e9919316f836_normal.png",
      "id" : 14120151,
      "verified" : true
    }
  },
  "id" : 464837311029850112,
  "created_at" : "2014-05-09 18:40:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seriouspony",
      "screen_name" : "seriouspony",
      "indices" : [ 18, 30 ],
      "id_str" : "289534689",
      "id" : 289534689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/y6Iho2Xx4X",
      "expanded_url" : "https:\/\/seriouspony.exposure.co\/touching-the-wild",
      "display_url" : "seriouspony.exposure.co\/touching-the-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464816427451822081",
  "text" : "Beautiful post by @seriouspony: \"What does it mean to be a horse? What is the nature of a horse?\" https:\/\/t.co\/y6Iho2Xx4X",
  "id" : 464816427451822081,
  "created_at" : "2014-05-09 17:17:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/464598636291440641\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/Iw4e8vdbqD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnKV_xOCcAAORTC.jpg",
      "id_str" : "464598634349096960",
      "id" : 464598634349096960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnKV_xOCcAAORTC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Iw4e8vdbqD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.5605471659, -77.4744049635 ]
  },
  "id_str" : "464598636291440641",
  "text" : "Monkey queen http:\/\/t.co\/Iw4e8vdbqD",
  "id" : 464598636291440641,
  "created_at" : "2014-05-09 02:52:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 5, 15 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 20, 29 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/464597795123761152\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/7ROB2rfukY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnKVO24IYAAM8NE.jpg",
      "id_str" : "464597794054234112",
      "id" : 464597794054234112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnKVO24IYAAM8NE.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7ROB2rfukY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.560533073, -77.4742469059 ]
  },
  "id_str" : "464597795123761152",
  "text" : "It's @Kellianne and @RickWebb! http:\/\/t.co\/7ROB2rfukY",
  "id" : 464597795123761152,
  "created_at" : "2014-05-09 02:48:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 19, 28 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 30, 40 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/y0nsR1ayMz",
      "expanded_url" : "https:\/\/flic.kr\/p\/ng9rLf",
      "display_url" : "flic.kr\/p\/ng9rLf"
    } ]
  },
  "geo" : { },
  "id_str" : "464581438957170689",
  "text" : "8:36pm Dinner with @rickwebb, @kellianne, Brian, Melanie, Chelsie, and more! https:\/\/t.co\/y0nsR1ayMz",
  "id" : 464581438957170689,
  "created_at" : "2014-05-09 01:43:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 95, 104 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.5606073067, -77.474665437 ]
  },
  "id_str" : "464558302492622848",
  "text" : "Watched student projects at VCU Brandcenter and met some famous ad world celebrities thanks to @RickWebb.",
  "id" : 464558302492622848,
  "created_at" : "2014-05-09 00:11:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sutha Kamal",
      "screen_name" : "SuthaKamal",
      "indices" : [ 0, 11 ],
      "id_str" : "5295",
      "id" : 5295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464459349067571201",
  "geo" : { },
  "id_str" : "464459611006046209",
  "in_reply_to_user_id" : 5295,
  "text" : "@SuthaKamal They recently changed the format of the JSON export but I plan on releasing the scripts when I get a bit of time.",
  "id" : 464459611006046209,
  "in_reply_to_status_id" : 464459349067571201,
  "created_at" : "2014-05-08 17:39:35 +0000",
  "in_reply_to_screen_name" : "SuthaKamal",
  "in_reply_to_user_id_str" : "5295",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 10, 21 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/JsdLoZh8Db",
      "expanded_url" : "https:\/\/medium.com\/p\/b716758d7d97",
      "display_url" : "medium.com\/p\/b716758d7d97"
    } ]
  },
  "in_reply_to_status_id_str" : "464404328115998721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.5620096517, -77.4791512441 ]
  },
  "id_str" : "464406614024667137",
  "in_reply_to_user_id" : 13919072,
  "text" : "Me too RT @robinsloan: I love the new definition of \"season\"\u2014and not just for TV. https:\/\/t.co\/JsdLoZh8Db",
  "id" : 464406614024667137,
  "in_reply_to_status_id" : 464404328115998721,
  "created_at" : "2014-05-08 14:08:59 +0000",
  "in_reply_to_screen_name" : "robinsloan",
  "in_reply_to_user_id_str" : "13919072",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 19, 28 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/464239463275569153\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/YfVu9I7qtS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnFPU9sCEAAKFbC.jpg",
      "id_str" : "464239458171097088",
      "id" : 464239458171097088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnFPU9sCEAAKFbC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/YfVu9I7qtS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.5424582206, -77.449610369 ]
  },
  "id_str" : "464239463275569153",
  "text" : "8:36pm Meeting the @rickwebb in Richmond for a birthday drink http:\/\/t.co\/YfVu9I7qtS",
  "id" : 464239463275569153,
  "created_at" : "2014-05-08 03:04:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 47, 57 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 74, 84 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/v6FwKM0oMK",
      "expanded_url" : "http:\/\/4sq.com\/1jfZx7D",
      "display_url" : "4sq.com\/1jfZx7D"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.539104, -77.450348 ]
  },
  "id_str" : "464173409392676864",
  "text" : "Finally eating here after 7 years of hype from @kellianne (@ Mama Zu's w\/ @kellianne) http:\/\/t.co\/v6FwKM0oMK",
  "id" : 464173409392676864,
  "created_at" : "2014-05-07 22:42:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 13, 23 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/464151532217589760\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/HH0k48cfmY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnD_W7eIgAI8bf0.jpg",
      "id_str" : "464151531005444098",
      "id" : 464151531005444098,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnD_W7eIgAI8bf0.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 767
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 767
      } ],
      "display_url" : "pic.twitter.com\/HH0k48cfmY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.5620559535, -77.4792307843 ]
  },
  "id_str" : "464151532217589760",
  "text" : "Staying with @kellianne's good friends in Richmond, VA and found some drunken? poetry of hers cutely framed http:\/\/t.co\/HH0k48cfmY",
  "id" : 464151532217589760,
  "created_at" : "2014-05-07 21:15:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bodge",
      "screen_name" : "mikebodge",
      "indices" : [ 0, 10 ],
      "id_str" : "19344531",
      "id" : 19344531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464121566260125697",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.5620982864, -77.4791467273 ]
  },
  "id_str" : "464129010881282048",
  "in_reply_to_user_id" : 19344531,
  "text" : "@mikebodge That's my guess... and I assume it will. And leaves room for stretch goals\/rewards\/updates.",
  "id" : 464129010881282048,
  "in_reply_to_status_id" : 464121566260125697,
  "created_at" : "2014-05-07 19:45:53 +0000",
  "in_reply_to_screen_name" : "mikebodge",
  "in_reply_to_user_id_str" : "19344531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 54, 66 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/Wg3umtRyWd",
      "expanded_url" : "http:\/\/Upcoming.org",
      "display_url" : "Upcoming.org"
    }, {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/qT7sRECIq1",
      "expanded_url" : "http:\/\/kck.st\/1iXG7p1",
      "display_url" : "kck.st\/1iXG7p1"
    } ]
  },
  "geo" : { },
  "id_str" : "464097999006621697",
  "text" : "I just backed The Return of http:\/\/t.co\/Wg3umtRyWd on @Kickstarter http:\/\/t.co\/qT7sRECIq1",
  "id" : 464097999006621697,
  "created_at" : "2014-05-07 17:42:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 8, 19 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/NSGDFxea4q",
      "expanded_url" : "http:\/\/upcoming.org\/",
      "display_url" : "upcoming.org"
    } ]
  },
  "in_reply_to_status_id_str" : "464087471383257089",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.5524217233, -77.4784972503 ]
  },
  "id_str" : "464097478812258304",
  "in_reply_to_user_id" : 13461,
  "text" : "Yay! RT @waxpancake: UPCOMING IS COMING BACK. http:\/\/t.co\/NSGDFxea4q",
  "id" : 464097478812258304,
  "in_reply_to_status_id" : 464087471383257089,
  "created_at" : "2014-05-07 17:40:36 +0000",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Park",
      "screen_name" : "charliepark",
      "indices" : [ 0, 12 ],
      "id_str" : "3225381",
      "id" : 3225381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464053539220627456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.5488574067, -77.4704416104 ]
  },
  "id_str" : "464061484377444356",
  "in_reply_to_user_id" : 3225381,
  "text" : "@charliepark Fave restaurants? We have old friends to give us the full tour but always open to fresh ideas!",
  "id" : 464061484377444356,
  "in_reply_to_status_id" : 464053539220627456,
  "created_at" : "2014-05-07 15:17:34 +0000",
  "in_reply_to_screen_name" : "charliepark",
  "in_reply_to_user_id_str" : "3225381",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003Efoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lamplighter Roasting",
      "screen_name" : "LampPostsRVA",
      "indices" : [ 56, 69 ],
      "id_str" : "148009281",
      "id" : 148009281
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 73, 83 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/ZojmR680Ks",
      "expanded_url" : "http:\/\/4sq.com\/1fUlhGP",
      "display_url" : "4sq.com\/1fUlhGP"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.548854, -77.470704 ]
  },
  "id_str" : "464040072476504065",
  "text" : "Hello beautiful Richmond! (@ Lamplighter Roasting Co. - @lamppostsrva w\/ @kellianne) http:\/\/t.co\/ZojmR680Ks",
  "id" : 464040072476504065,
  "created_at" : "2014-05-07 13:52:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cau\u00EA Napier",
      "screen_name" : "cauenapier",
      "indices" : [ 0, 11 ],
      "id_str" : "198441257",
      "id" : 198441257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464026166139969538",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.5072968226, -77.3358817783 ]
  },
  "id_str" : "464029666391498752",
  "in_reply_to_user_id" : 198441257,
  "text" : "@cauenapier That's the one. It's a very weird book. Not super easy but packed full of strange and interesting ideas.",
  "id" : 464029666391498752,
  "in_reply_to_status_id" : 464026166139969538,
  "created_at" : "2014-05-07 13:11:08 +0000",
  "in_reply_to_screen_name" : "cauenapier",
  "in_reply_to_user_id_str" : "198441257",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "amy farrow",
      "screen_name" : "amyf",
      "indices" : [ 0, 5 ],
      "id_str" : "385195745",
      "id" : 385195745
    }, {
      "name" : "US Airways",
      "screen_name" : "USAirways",
      "indices" : [ 6, 16 ],
      "id_str" : "78084813",
      "id" : 78084813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463997768516640769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.8804247276, -75.2367128583 ]
  },
  "id_str" : "464001949516324866",
  "in_reply_to_user_id" : 385195745,
  "text" : "@amyf @USAirways WHAT?? I wonder what sort of drama is unfolding behind the scenes.",
  "id" : 464001949516324866,
  "in_reply_to_status_id" : 463997768516640769,
  "created_at" : "2014-05-07 11:21:00 +0000",
  "in_reply_to_screen_name" : "amyf",
  "in_reply_to_user_id_str" : "385195745",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Airways",
      "screen_name" : "USAirways",
      "indices" : [ 0, 10 ],
      "id_str" : "78084813",
      "id" : 78084813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463992443646394368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.8800936947, -75.2373156232 ]
  },
  "id_str" : "463994534532100097",
  "in_reply_to_user_id" : 78084813,
  "text" : "@USAirways Yes, still traveling. A voucher for a future flight might alleviate some of the associations of dread I have with your services.",
  "id" : 463994534532100097,
  "in_reply_to_status_id" : 463992443646394368,
  "created_at" : "2014-05-07 10:51:32 +0000",
  "in_reply_to_screen_name" : "USAirways",
  "in_reply_to_user_id_str" : "78084813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Airways",
      "screen_name" : "USAirways",
      "indices" : [ 0, 10 ],
      "id_str" : "78084813",
      "id" : 78084813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463907499922309120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.8762859225, -75.2410473827 ]
  },
  "id_str" : "463991887829819393",
  "in_reply_to_user_id" : 78084813,
  "text" : "@USAirways Originally I was on the 1:40pm flight from SFO -&gt; Charlotte -&gt; RIC.",
  "id" : 463991887829819393,
  "in_reply_to_status_id" : 463907499922309120,
  "created_at" : "2014-05-07 10:41:01 +0000",
  "in_reply_to_screen_name" : "USAirways",
  "in_reply_to_user_id_str" : "78084813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 0, 10 ],
      "id_str" : "1771141",
      "id" : 1771141
    }, {
      "name" : "US Airways",
      "screen_name" : "USAirways",
      "indices" : [ 63, 73 ],
      "id_str" : "78084813",
      "id" : 78084813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463903366892908544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6138217852, -122.3846721968 ]
  },
  "id_str" : "463903781315289088",
  "in_reply_to_user_id" : 1771141,
  "text" : "@samantham Yeah, seems neck and neck. I've been forced to take @USAirways more because of the back and forth to PHL, so it feels worse.",
  "id" : 463903781315289088,
  "in_reply_to_status_id" : 463903366892908544,
  "created_at" : "2014-05-07 04:50:55 +0000",
  "in_reply_to_screen_name" : "samantham",
  "in_reply_to_user_id_str" : "1771141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen",
      "screen_name" : "gln",
      "indices" : [ 0, 4 ],
      "id_str" : "4366051",
      "id" : 4366051
    }, {
      "name" : "US Airways",
      "screen_name" : "USAirways",
      "indices" : [ 22, 32 ],
      "id_str" : "78084813",
      "id" : 78084813
    }, {
      "name" : "American Airlines",
      "screen_name" : "AmericanAir",
      "indices" : [ 81, 93 ],
      "id_str" : "22536055",
      "id" : 22536055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463899650013945858",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6139797887, -122.3848514053 ]
  },
  "id_str" : "463900800272453633",
  "in_reply_to_user_id" : 4366051,
  "text" : "@gln I have sworn off @USAirways previously, and had booked with the much better @AmericanAir. But they switched me, and then this happened.",
  "id" : 463900800272453633,
  "in_reply_to_status_id" : 463899650013945858,
  "created_at" : "2014-05-07 04:39:04 +0000",
  "in_reply_to_screen_name" : "gln",
  "in_reply_to_user_id_str" : "4366051",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463897141052583936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6036165018, -122.3788791644 ]
  },
  "id_str" : "463897760463200260",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel It's all good, I'm none of those things.",
  "id" : 463897760463200260,
  "in_reply_to_status_id" : 463897141052583936,
  "created_at" : "2014-05-07 04:26:59 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463895189124153344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6137008359, -122.3850972867 ]
  },
  "id_str" : "463896484820172801",
  "in_reply_to_user_id" : 2185,
  "text" : "Asked for a voucher but they wouldn't budge, \"We're getting you to your destination.\" Give\/take a day is within bounds of acceptable error.",
  "id" : 463896484820172801,
  "in_reply_to_status_id" : 463895189124153344,
  "created_at" : "2014-05-07 04:21:55 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Airways",
      "screen_name" : "USAirways",
      "indices" : [ 3, 13 ],
      "id_str" : "78084813",
      "id" : 78084813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.613792164, -122.3850794217 ]
  },
  "id_str" : "463895189124153344",
  "text" : "Is @USAirways the worst airline or is it THE WORST airline? This time it's a 9 hr delay because a crew member called in sick.",
  "id" : 463895189124153344,
  "created_at" : "2014-05-07 04:16:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/JcjVM4Ti33",
      "expanded_url" : "https:\/\/flic.kr\/p\/nwqrLs",
      "display_url" : "flic.kr\/p\/nwqrLs"
    } ]
  },
  "geo" : { },
  "id_str" : "463888227128979456",
  "text" : "8:36pm Still staring down gate 21. Flight boards in an hour. https:\/\/t.co\/JcjVM4Ti33",
  "id" : 463888227128979456,
  "created_at" : "2014-05-07 03:49:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 9, 18 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 19, 26 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 27, 37 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Morgan Warstler",
      "screen_name" : "morganwarstler",
      "indices" : [ 38, 53 ],
      "id_str" : "7792422",
      "id" : 7792422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463880538139279360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6139600049, -122.3850671535 ]
  },
  "id_str" : "463881142773350400",
  "in_reply_to_user_id" : 15275073,
  "text" : "@tberman @RickWebb @harryh @kellianne @morganwarstler True. Is that the biggest limitation? If so maybe we could revisit in 5 yrs.",
  "id" : 463881142773350400,
  "in_reply_to_status_id" : 463880538139279360,
  "created_at" : "2014-05-07 03:20:57 +0000",
  "in_reply_to_screen_name" : "tberman",
  "in_reply_to_user_id_str" : "15275073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 11, 20 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 21, 28 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 29, 39 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463880061179817984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.613959853, -122.3850252978 ]
  },
  "id_str" : "463880741974077441",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward @RickWebb @harryh @kellianne I think that's the problem... the existing systems are expensive, inefficient, and unsustainable.",
  "id" : 463880741974077441,
  "in_reply_to_status_id" : 463880061179817984,
  "created_at" : "2014-05-07 03:19:22 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 11, 20 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 21, 28 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 29, 39 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463878476466892802",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6138948538, -122.385043238 ]
  },
  "id_str" : "463878844479307777",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward @RickWebb @harryh @kellianne Which viable alternative do you think is best?",
  "id" : 463878844479307777,
  "in_reply_to_status_id" : 463878476466892802,
  "created_at" : "2014-05-07 03:11:49 +0000",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 10, 17 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 18, 28 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Morgan Warstler",
      "screen_name" : "morganwarstler",
      "indices" : [ 29, 44 ],
      "id_str" : "7792422",
      "id" : 7792422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463877397587054592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6092847734, -122.382377648 ]
  },
  "id_str" : "463878372615933954",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @harryh @kellianne @morganwarstler That's why I liked this post... he ventured to flesh out some details.",
  "id" : 463878372615933954,
  "in_reply_to_status_id" : 463877397587054592,
  "created_at" : "2014-05-07 03:09:57 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sterling White",
      "screen_name" : "hey_sterling",
      "indices" : [ 0, 13 ],
      "id_str" : "150863291",
      "id" : 150863291
    }, {
      "name" : "Mike Kruzeniski",
      "screen_name" : "mkruz",
      "indices" : [ 14, 20 ],
      "id_str" : "6604912",
      "id" : 6604912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463875079776903168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6092847734, -122.382377648 ]
  },
  "id_str" : "463878040028606465",
  "in_reply_to_user_id" : 150863291,
  "text" : "@hey_sterling @mkruz I'll get there! I have a whole week off! :)",
  "id" : 463878040028606465,
  "in_reply_to_status_id" : 463875079776903168,
  "created_at" : "2014-05-07 03:08:37 +0000",
  "in_reply_to_screen_name" : "hey_sterling",
  "in_reply_to_user_id_str" : "150863291",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriemTeam",
      "screen_name" : "TriemTeam",
      "indices" : [ 0, 10 ],
      "id_str" : "24792603",
      "id" : 24792603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463873204079980544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6139305789, -122.3849238538 ]
  },
  "id_str" : "463873596759105536",
  "in_reply_to_user_id" : 24792603,
  "text" : "@TriemTeam Of all things, yelling does seem to have the highest pay grades.",
  "id" : 463873596759105536,
  "in_reply_to_status_id" : 463873204079980544,
  "created_at" : "2014-05-07 02:50:58 +0000",
  "in_reply_to_screen_name" : "TriemTeam",
  "in_reply_to_user_id_str" : "24792603",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriemTeam",
      "screen_name" : "TriemTeam",
      "indices" : [ 0, 10 ],
      "id_str" : "24792603",
      "id" : 24792603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463872929344651264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.613911621, -122.3849163676 ]
  },
  "id_str" : "463873036500733954",
  "in_reply_to_user_id" : 24792603,
  "text" : "@TriemTeam Medium post? :)",
  "id" : 463873036500733954,
  "in_reply_to_status_id" : 463872929344651264,
  "created_at" : "2014-05-07 02:48:44 +0000",
  "in_reply_to_screen_name" : "TriemTeam",
  "in_reply_to_user_id_str" : "24792603",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 8, 17 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 18, 28 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463869262029791232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6139255394, -122.3849069318 ]
  },
  "id_str" : "463872906603147266",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @RickWebb @kellianne What's the best means tested proposal in your opinion?",
  "id" : 463872906603147266,
  "in_reply_to_status_id" : 463869262029791232,
  "created_at" : "2014-05-07 02:48:13 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriemTeam",
      "screen_name" : "TriemTeam",
      "indices" : [ 0, 10 ],
      "id_str" : "24792603",
      "id" : 24792603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463872147236990977",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6139110351, -122.3849411058 ]
  },
  "id_str" : "463872373431603200",
  "in_reply_to_user_id" : 24792603,
  "text" : "@TriemTeam Is there a link that describes that to your satisfaction?",
  "id" : 463872373431603200,
  "in_reply_to_status_id" : 463872147236990977,
  "created_at" : "2014-05-07 02:46:06 +0000",
  "in_reply_to_screen_name" : "TriemTeam",
  "in_reply_to_user_id_str" : "24792603",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriemTeam",
      "screen_name" : "TriemTeam",
      "indices" : [ 0, 10 ],
      "id_str" : "24792603",
      "id" : 24792603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463871770722705408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6138690902, -122.3848994507 ]
  },
  "id_str" : "463871952629686274",
  "in_reply_to_user_id" : 24792603,
  "text" : "@TriemTeam What is?",
  "id" : 463871952629686274,
  "in_reply_to_status_id" : 463871770722705408,
  "created_at" : "2014-05-07 02:44:26 +0000",
  "in_reply_to_screen_name" : "TriemTeam",
  "in_reply_to_user_id_str" : "24792603",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 59, 68 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 69, 76 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 77, 87 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/Pkp0LPJ4Yz",
      "expanded_url" : "https:\/\/medium.com\/p\/1d068ac5a205",
      "display_url" : "medium.com\/p\/1d068ac5a205"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6045172, -122.37995782 ]
  },
  "id_str" : "463866603927379968",
  "text" : "Thoughts on guaranteed income? https:\/\/t.co\/Pkp0LPJ4Yz \/cc @rickwebb @harryh @kellianne",
  "id" : 463866603927379968,
  "created_at" : "2014-05-07 02:23:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Kruzeniski",
      "screen_name" : "mkruz",
      "indices" : [ 0, 6 ],
      "id_str" : "6604912",
      "id" : 6604912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463864640619835392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6045172, -122.37995782 ]
  },
  "id_str" : "463865886550392832",
  "in_reply_to_user_id" : 6604912,
  "text" : "@mkruz It's not the easiest story but he really takes it somewhere strange, which I thoroughly enjoy. Have you read any of his other books?",
  "id" : 463865886550392832,
  "in_reply_to_status_id" : 463864640619835392,
  "created_at" : "2014-05-07 02:20:20 +0000",
  "in_reply_to_screen_name" : "mkruz",
  "in_reply_to_user_id_str" : "6604912",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/463863860475076609\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/jjWGAr1seS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm_5tZ_CMAEVn09.jpg",
      "id_str" : "463863845107150849",
      "id" : 463863845107150849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm_5tZ_CMAEVn09.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/jjWGAr1seS"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/463863860475076609\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/jjWGAr1seS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm_5uJBCcAAYVsl.jpg",
      "id_str" : "463863857732022272",
      "id" : 463863857732022272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm_5uJBCcAAYVsl.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/jjWGAr1seS"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/463863860475076609\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/jjWGAr1seS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm_5uNeCEAAg_nu.jpg",
      "id_str" : "463863858927374336",
      "id" : 463863858927374336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm_5uNeCEAAg_nu.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/jjWGAr1seS"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/463863860475076609\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/jjWGAr1seS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm_5tb7CUAApNQq.jpg",
      "id_str" : "463863845627252736",
      "id" : 463863845627252736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm_5tb7CUAApNQq.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/jjWGAr1seS"
    } ],
    "hashtags" : [ {
      "text" : "deep",
      "indices" : [ 17, 22 ]
    }, {
      "text" : "spoilerfree",
      "indices" : [ 23, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6045172044, -122.3799578186 ]
  },
  "id_str" : "463863860475076609",
  "text" : "Accelerando gets #deep #spoilerfree http:\/\/t.co\/jjWGAr1seS",
  "id" : 463863860475076609,
  "created_at" : "2014-05-07 02:12:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463859241455853569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6045225346, -122.3799560579 ]
  },
  "id_str" : "463861887055048705",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver Definitely. The last 5% has some really good stuff.",
  "id" : 463861887055048705,
  "in_reply_to_status_id" : 463859241455853569,
  "created_at" : "2014-05-07 02:04:26 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6129399706, -122.3851490581 ]
  },
  "id_str" : "463858176442396673",
  "text" : "Who has read Accelerando? Just finished it. It's like a super weird sci-fi Master and Margarita. Which is in itself pretty weird.",
  "id" : 463858176442396673,
  "created_at" : "2014-05-07 01:49:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463850015476035585",
  "geo" : { },
  "id_str" : "463857861995401217",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc I tried.",
  "id" : 463857861995401217,
  "in_reply_to_status_id" : 463850015476035585,
  "created_at" : "2014-05-07 01:48:27 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6125865477, -122.3832994235 ]
  },
  "id_str" : "463827416528343041",
  "text" : "For some reason I have no desire to leave Terminal 1. It's a stare down.",
  "id" : 463827416528343041,
  "created_at" : "2014-05-06 23:47:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463825609508929537",
  "geo" : { },
  "id_str" : "463826097201631232",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez Same.",
  "id" : 463826097201631232,
  "in_reply_to_status_id" : 463825609508929537,
  "created_at" : "2014-05-06 23:42:13 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 7, 17 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6125220908, -122.3834673968 ]
  },
  "id_str" : "463824936671268865",
  "text" : "I hope @kellianne likes her Mother's Day gift from Terminal 1.",
  "id" : 463824936671268865,
  "created_at" : "2014-05-06 23:37:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arianna Huffington",
      "screen_name" : "ariannahuff",
      "indices" : [ 55, 67 ],
      "id_str" : "21982720",
      "id" : 21982720
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 69, 76 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463823109611470848",
  "text" : "I\u2019m a slow reader, so unless Donna Tartt chimes in\u2026 RT @ariannahuff: @buster, you have time to read both!",
  "id" : 463823109611470848,
  "created_at" : "2014-05-06 23:30:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 0, 13 ],
      "id_str" : "1784841",
      "id" : 1784841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463819312436760576",
  "geo" : { },
  "id_str" : "463822210780499969",
  "in_reply_to_user_id" : 1784841,
  "text" : "@sawickipedia Round trip. It's about 1.5 hrs total, not counting security etc.",
  "id" : 463822210780499969,
  "in_reply_to_status_id" : 463819312436760576,
  "created_at" : "2014-05-06 23:26:47 +0000",
  "in_reply_to_screen_name" : "sawickipedia",
  "in_reply_to_user_id_str" : "1784841",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463819061529284608",
  "geo" : { },
  "id_str" : "463821959801733120",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright The latter is probably a likely possibility. Might need a drink to get started.",
  "id" : 463821959801733120,
  "in_reply_to_status_id" : 463819061529284608,
  "created_at" : "2014-05-06 23:25:47 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 0, 7 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/463817309174251521\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/tmi0wYsJAx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm_PYmACAAACX9o.jpg",
      "id_str" : "463817308066938880",
      "id" : 463817308066938880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm_PYmACAAACX9o.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/tmi0wYsJAx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463813840224792576",
  "geo" : { },
  "id_str" : "463817309174251521",
  "in_reply_to_user_id" : 2185,
  "text" : "@buster Read Thrive or The Goldfinch? http:\/\/t.co\/tmi0wYsJAx",
  "id" : 463817309174251521,
  "in_reply_to_status_id" : 463813840224792576,
  "created_at" : "2014-05-06 23:07:18 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 0, 13 ],
      "id_str" : "1784841",
      "id" : 1784841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463815892774563842",
  "geo" : { },
  "id_str" : "463816126049157121",
  "in_reply_to_user_id" : 1784841,
  "text" : "@sawickipedia Berkeley.",
  "id" : 463816126049157121,
  "in_reply_to_status_id" : 463815892774563842,
  "created_at" : "2014-05-06 23:02:36 +0000",
  "in_reply_to_screen_name" : "sawickipedia",
  "in_reply_to_user_id_str" : "1784841",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moves",
      "screen_name" : "movesapp",
      "indices" : [ 0, 9 ],
      "id_str" : "888379981",
      "id" : 888379981
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/463816060827750400\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/hYk400lWmm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm_OP78CIAAMPQt.jpg",
      "id_str" : "463816059825299456",
      "id" : 463816059825299456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm_OP78CIAAMPQt.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/hYk400lWmm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463814825630396416",
  "geo" : { },
  "id_str" : "463816060827750400",
  "in_reply_to_user_id" : 2185,
  "text" : "@movesapp ? http:\/\/t.co\/hYk400lWmm",
  "id" : 463816060827750400,
  "in_reply_to_status_id" : 463814825630396416,
  "created_at" : "2014-05-06 23:02:20 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Zilar",
      "screen_name" : "jeremyzilar",
      "indices" : [ 0, 12 ],
      "id_str" : "291363",
      "id" : 291363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463814367725633536",
  "geo" : { },
  "id_str" : "463815262102241281",
  "in_reply_to_user_id" : 291363,
  "text" : "@jeremyzilar I'm not that social.",
  "id" : 463815262102241281,
  "in_reply_to_status_id" : 463814367725633536,
  "created_at" : "2014-05-06 22:59:10 +0000",
  "in_reply_to_screen_name" : "jeremyzilar",
  "in_reply_to_user_id_str" : "291363",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 0, 13 ],
      "id_str" : "1784841",
      "id" : 1784841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463814532888928256",
  "geo" : { },
  "id_str" : "463815120389300224",
  "in_reply_to_user_id" : 1784841,
  "text" : "@sawickipedia That would take 3 hours or $100+.",
  "id" : 463815120389300224,
  "in_reply_to_status_id" : 463814532888928256,
  "created_at" : "2014-05-06 22:58:36 +0000",
  "in_reply_to_screen_name" : "sawickipedia",
  "in_reply_to_user_id_str" : "1784841",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moves",
      "screen_name" : "movesapp",
      "indices" : [ 0, 9 ],
      "id_str" : "888379981",
      "id" : 888379981
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/463814825630396416\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/PRHxpg3ZIh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm_NH7ZCEAACA0d.jpg",
      "id_str" : "463814822727913472",
      "id" : 463814822727913472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm_NH7ZCEAACA0d.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PRHxpg3ZIh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463814224699879424",
  "geo" : { },
  "id_str" : "463814825630396416",
  "in_reply_to_user_id" : 2185,
  "text" : "@movesapp Get to know the bartender at Legends? http:\/\/t.co\/PRHxpg3ZIh",
  "id" : 463814825630396416,
  "in_reply_to_status_id" : 463814224699879424,
  "created_at" : "2014-05-06 22:57:26 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 0, 7 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Moves",
      "screen_name" : "movesapp",
      "indices" : [ 39, 48 ],
      "id_str" : "888379981",
      "id" : 888379981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463813840224792576",
  "geo" : { },
  "id_str" : "463814224699879424",
  "in_reply_to_user_id" : 2185,
  "text" : "@buster Attempt to set a new record on @movesapp by dragging luggage up and down the halls?",
  "id" : 463814224699879424,
  "in_reply_to_status_id" : 463813840224792576,
  "created_at" : "2014-05-06 22:55:03 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6129715542, -122.3843640956 ]
  },
  "id_str" : "463813840224792576",
  "text" : "What would you do if you were stuck in Terminal 1 of SFO airport for 10 hours with no wifi and few working outlets? Asking for a friend.",
  "id" : 463813840224792576,
  "created_at" : "2014-05-06 22:53:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Secret",
      "screen_name" : "getsecret",
      "indices" : [ 22, 32 ],
      "id_str" : "2244765331",
      "id" : 2244765331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6124831988, -122.3836583366 ]
  },
  "id_str" : "463795144857120771",
  "text" : "I wish I could search @getsecret.",
  "id" : 463795144857120771,
  "created_at" : "2014-05-06 21:39:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8538678447, -122.2706126982 ]
  },
  "id_str" : "463737852447031296",
  "text" : "What Wall St thinks = the sum of what you and everyone else thinks it thinks. Remember which side of the equation you're on.",
  "id" : 463737852447031296,
  "created_at" : "2014-05-06 17:51:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/463732466843267073\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/K4Nven7Msw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm-COJJCQAA8GXt.jpg",
      "id_str" : "463732466126045184",
      "id" : 463732466126045184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm-COJJCQAA8GXt.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/K4Nven7Msw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596919805, -122.275537579 ]
  },
  "id_str" : "463732466843267073",
  "text" : "I love this cat. http:\/\/t.co\/K4Nven7Msw",
  "id" : 463732466843267073,
  "created_at" : "2014-05-06 17:30:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Albarn",
      "screen_name" : "Damonalbarn",
      "indices" : [ 16, 28 ],
      "id_str" : "531750633",
      "id" : 531750633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463706814031200257",
  "text" : "Really enjoying @damonalbarn's new album, Everyday Robots. Weird and fun.",
  "id" : 463706814031200257,
  "created_at" : "2014-05-06 15:48:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 8, 14 ],
      "id_str" : "8285392",
      "id" : 8285392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463687682980184064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597020684, -122.2753002775 ]
  },
  "id_str" : "463688028129480705",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey @raffi Me too.",
  "id" : 463688028129480705,
  "in_reply_to_status_id" : 463687682980184064,
  "created_at" : "2014-05-06 14:33:35 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonard",
      "screen_name" : "lhl",
      "indices" : [ 0, 4 ],
      "id_str" : "12513",
      "id" : 12513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463667532943986688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597161478, -122.2755199901 ]
  },
  "id_str" : "463668386048647169",
  "in_reply_to_user_id" : 12513,
  "text" : "@lhl You're right. I just want to invest in the idea of cryptocurrency without trying to predict the winner.",
  "id" : 463668386048647169,
  "in_reply_to_status_id" : 463667532943986688,
  "created_at" : "2014-05-06 13:15:32 +0000",
  "in_reply_to_screen_name" : "lhl",
  "in_reply_to_user_id_str" : "12513",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonard",
      "screen_name" : "lhl",
      "indices" : [ 0, 4 ],
      "id_str" : "12513",
      "id" : 12513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463647035766226944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596603684, -122.2754907982 ]
  },
  "id_str" : "463664118570827777",
  "in_reply_to_user_id" : 12513,
  "text" : "@lhl The index fund should invest in proportion to their value, and be an ETF with very low management fees. Like VOO for example.",
  "id" : 463664118570827777,
  "in_reply_to_status_id" : 463647035766226944,
  "created_at" : "2014-05-06 12:58:34 +0000",
  "in_reply_to_screen_name" : "lhl",
  "in_reply_to_user_id_str" : "12513",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slava Shirokov",
      "screen_name" : "sshirokov",
      "indices" : [ 0, 10 ],
      "id_str" : "10147092",
      "id" : 10147092
    }, {
      "name" : "Doge Tip Bot",
      "screen_name" : "tipdoge",
      "indices" : [ 11, 19 ],
      "id_str" : "591713080",
      "id" : 591713080
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463574063294603264",
  "geo" : { },
  "id_str" : "463575286177484801",
  "in_reply_to_user_id" : 10147092,
  "text" : "@sshirokov @tipdoge Aww thanks!",
  "id" : 463575286177484801,
  "in_reply_to_status_id" : 463574063294603264,
  "created_at" : "2014-05-06 07:05:35 +0000",
  "in_reply_to_screen_name" : "sshirokov",
  "in_reply_to_user_id_str" : "10147092",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 1, 7 ],
      "id_str" : "5814",
      "id" : 5814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463567868416630784",
  "geo" : { },
  "id_str" : "463568714554544128",
  "in_reply_to_user_id" : 5814,
  "text" : ".@tempo Is there an total-cryptocurrency-market-fund-coin-etf yet? I\u2019d buy that.",
  "id" : 463568714554544128,
  "in_reply_to_status_id" : 463567868416630784,
  "created_at" : "2014-05-06 06:39:28 +0000",
  "in_reply_to_screen_name" : "tempo",
  "in_reply_to_user_id_str" : "5814",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    }, {
      "name" : "April Underwood",
      "screen_name" : "aunder",
      "indices" : [ 5, 12 ],
      "id_str" : "4265731",
      "id" : 4265731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463567143422787584",
  "geo" : { },
  "id_str" : "463567323865956352",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm @aunder wait, it\u2019s not?",
  "id" : 463567323865956352,
  "in_reply_to_status_id" : 463567143422787584,
  "created_at" : "2014-05-06 06:33:57 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Underwood",
      "screen_name" : "aunder",
      "indices" : [ 0, 7 ],
      "id_str" : "4265731",
      "id" : 4265731
    }, {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 8, 12 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463565947257638912",
  "geo" : { },
  "id_str" : "463566412502409216",
  "in_reply_to_user_id" : 4265731,
  "text" : "@aunder @ltm me neither\u2026 but I do have 100 dogecoin.",
  "id" : 463566412502409216,
  "in_reply_to_status_id" : 463565947257638912,
  "created_at" : "2014-05-06 06:30:20 +0000",
  "in_reply_to_screen_name" : "aunder",
  "in_reply_to_user_id_str" : "4265731",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596936475, -122.2755609496 ]
  },
  "id_str" : "463564068419145730",
  "text" : "How many bitcoin do y'all have?",
  "id" : 463564068419145730,
  "created_at" : "2014-05-06 06:21:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/463550874648715264\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/WXz1oKgXuK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm7dD0DCEAEahYG.jpg",
      "id_str" : "463550869246447617",
      "id" : 463550869246447617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm7dD0DCEAEahYG.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/WXz1oKgXuK"
    } ],
    "hashtags" : [ {
      "text" : "MEOW",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597020265, -122.2754976713 ]
  },
  "id_str" : "463550874648715264",
  "text" : "8:36pm Sopor's feeling better enough to get really angry about not being allowed outside #MEOW http:\/\/t.co\/WXz1oKgXuK",
  "id" : 463550874648715264,
  "created_at" : "2014-05-06 05:28:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    }, {
      "name" : "Tina Barseghian",
      "screen_name" : "MindShiftKQED",
      "indices" : [ 15, 29 ],
      "id_str" : "179248364",
      "id" : 179248364
    }, {
      "name" : "Will Richardson",
      "screen_name" : "willrich45",
      "indices" : [ 30, 41 ],
      "id_str" : "1349941",
      "id" : 1349941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463511663442817025",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597263945, -122.2755985753 ]
  },
  "id_str" : "463518428192456704",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin @MindShiftKQED @willrich45 Right on!",
  "id" : 463518428192456704,
  "in_reply_to_status_id" : 463511663442817025,
  "created_at" : "2014-05-06 03:19:39 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stoprunningandstartliving",
      "indices" : [ 52, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463488639419555840",
  "geo" : { },
  "id_str" : "463488934073212928",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover coffee is your friend, it won't hurt you. #stoprunningandstartliving",
  "id" : 463488934073212928,
  "in_reply_to_status_id" : 463488639419555840,
  "created_at" : "2014-05-06 01:22:27 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin!",
      "screen_name" : "jpbimmer",
      "indices" : [ 24, 33 ],
      "id_str" : "13706182",
      "id" : 13706182
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 84, 93 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ittakestime",
      "indices" : [ 66, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463426991866138624",
  "geo" : { },
  "id_str" : "463428466163986432",
  "in_reply_to_user_id" : 761628,
  "text" : "I commend your patience @jpbimmer while we get the product right. #ittakestime \/via @rickwebb",
  "id" : 463428466163986432,
  "in_reply_to_status_id" : 463426991866138624,
  "created_at" : "2014-05-05 21:22:11 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Love",
      "screen_name" : "andrewtlove",
      "indices" : [ 0, 12 ],
      "id_str" : "18132818",
      "id" : 18132818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463395284383723521",
  "geo" : { },
  "id_str" : "463413169566646272",
  "in_reply_to_user_id" : 18132818,
  "text" : "@andrewtlove Wait\u2026 you read it??",
  "id" : 463413169566646272,
  "in_reply_to_status_id" : 463395284383723521,
  "created_at" : "2014-05-05 20:21:24 +0000",
  "in_reply_to_screen_name" : "andrewtlove",
  "in_reply_to_user_id_str" : "18132818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "indices" : [ 0, 13 ],
      "id_str" : "1186",
      "id" : 1186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463392651052462080",
  "geo" : { },
  "id_str" : "463392906292654080",
  "in_reply_to_user_id" : 1186,
  "text" : "@chrismessina You should've put an affiliate tag on the hash tag.",
  "id" : 463392906292654080,
  "in_reply_to_status_id" : 463392651052462080,
  "created_at" : "2014-05-05 19:00:52 +0000",
  "in_reply_to_screen_name" : "chrismessina",
  "in_reply_to_user_id_str" : "1186",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/CLBGAM47kB",
      "expanded_url" : "https:\/\/iwantmyname.com\/?domain=manversushimself.net&hideUnavailable=false",
      "display_url" : "iwantmyname.com\/?domain=manver\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463379568124899328",
  "geo" : { },
  "id_str" : "463379972296433664",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver For an extra $14.90, sure! https:\/\/t.co\/CLBGAM47kB",
  "id" : 463379972296433664,
  "in_reply_to_status_id" : 463379568124899328,
  "created_at" : "2014-05-05 18:09:29 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MyAmazon",
      "screen_name" : "MyAmazon",
      "indices" : [ 3, 12 ],
      "id_str" : "2390062825",
      "id" : 2390062825
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 14, 21 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/UI8zuBAewh",
      "expanded_url" : "http:\/\/amazon.com\/gp\/cart\/view.html\/ref=tsm_1_tw_amzn_genie_cart_n544vd527",
      "display_url" : "amazon.com\/gp\/cart\/view.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463378739233959936",
  "text" : "RT @MyAmazon: @buster Great! We added this item to your Amazon Cart. When ready, review your Cart http:\/\/t.co\/UI8zuBAewh and check out",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.amazon.com\" rel=\"nofollow\"\u003EAmazonCart\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/UI8zuBAewh",
        "expanded_url" : "http:\/\/amazon.com\/gp\/cart\/view.html\/ref=tsm_1_tw_amzn_genie_cart_n544vd527",
        "display_url" : "amazon.com\/gp\/cart\/view.h\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "463378675887386625",
    "geo" : { },
    "id_str" : "463378697870118912",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster Great! We added this item to your Amazon Cart. When ready, review your Cart http:\/\/t.co\/UI8zuBAewh and check out",
    "id" : 463378697870118912,
    "in_reply_to_status_id" : 463378675887386625,
    "created_at" : "2014-05-05 18:04:25 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "MyAmazon",
      "screen_name" : "MyAmazon",
      "protected" : false,
      "id_str" : "2390062825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463281589137309697\/Oh81P9nO_normal.png",
      "id" : 2390062825,
      "verified" : true
    }
  },
  "id" : 463378739233959936,
  "created_at" : "2014-05-05 18:04:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 0, 7 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amazoncart",
      "indices" : [ 23, 34 ]
    }, {
      "text" : "whynot",
      "indices" : [ 35, 42 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463378449566924800",
  "geo" : { },
  "id_str" : "463378675887386625",
  "in_reply_to_user_id" : 2185,
  "text" : "@buster I'll take one! #amazoncart #whynot",
  "id" : 463378675887386625,
  "in_reply_to_status_id" : 463378449566924800,
  "created_at" : "2014-05-05 18:04:20 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmazonCart",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/2snXppzJHr",
      "expanded_url" : "http:\/\/www.amazon.com\/gp\/product\/0595657699\/ref=as_li_tl?ie=UTF8&camp=1789&creative=390957&creativeASIN=0595657699&linkCode=as2&tag=mockerybird&linkId=Y3SB6I3MO76UBQDZ",
      "display_url" : "amazon.com\/gp\/product\/059\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463378449566924800",
  "text" : "Who wants to buy my 2003 novel about an 89-year old CEO whose head is wrapped in bandages? Reply with #AmazonCart http:\/\/t.co\/2snXppzJHr",
  "id" : 463378449566924800,
  "created_at" : "2014-05-05 18:03:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8048153548, -122.2947963328 ]
  },
  "id_str" : "463361153750405121",
  "text" : "I think Apple could do really well if they sold iPhone 4s with pre-cracked screens in BART stations.",
  "id" : 463361153750405121,
  "created_at" : "2014-05-05 16:54:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463353764070838272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8530045933, -122.2703489466 ]
  },
  "id_str" : "463354512753696771",
  "in_reply_to_user_id" : 2185,
  "text" : "I should have something to share more broadly in 5-10 years. What's your address I'll mail you a copy when it's ready.",
  "id" : 463354512753696771,
  "in_reply_to_status_id" : 463353764070838272,
  "created_at" : "2014-05-05 16:28:19 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8544431671, -122.2710002667 ]
  },
  "id_str" : "463353764070838272",
  "text" : "I'm writing a game. And I mean that in the same sense that a double English\/Psycholgy major implies when they say they're write a novel.",
  "id" : 463353764070838272,
  "created_at" : "2014-05-05 16:25:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aileenlee",
      "screen_name" : "aileenlee",
      "indices" : [ 3, 13 ],
      "id_str" : "17493187",
      "id" : 17493187
    }, {
      "name" : "Heidi Roizen",
      "screen_name" : "HeidiRoizen",
      "indices" : [ 22, 34 ],
      "id_str" : "577490455",
      "id" : 577490455
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/1yLd57AKW6",
      "expanded_url" : "http:\/\/heidiroizen.tumblr.com\/post\/84530650750\/its-different-for-girls",
      "display_url" : "heidiroizen.tumblr.com\/post\/845306507\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463346009431478272",
  "text" : "RT @aileenlee: thanks @heidiroizen for sharing this impt post, tho it made me a little sad. You rock. http:\/\/t.co\/1yLd57AKW6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/tweetbutton\" rel=\"nofollow\"\u003ETweet Button\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Heidi Roizen",
        "screen_name" : "HeidiRoizen",
        "indices" : [ 7, 19 ],
        "id_str" : "577490455",
        "id" : 577490455
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/1yLd57AKW6",
        "expanded_url" : "http:\/\/heidiroizen.tumblr.com\/post\/84530650750\/its-different-for-girls",
        "display_url" : "heidiroizen.tumblr.com\/post\/845306507\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "463343576349306881",
    "text" : "thanks @heidiroizen for sharing this impt post, tho it made me a little sad. You rock. http:\/\/t.co\/1yLd57AKW6",
    "id" : 463343576349306881,
    "created_at" : "2014-05-05 15:44:51 +0000",
    "user" : {
      "name" : "aileenlee",
      "screen_name" : "aileenlee",
      "protected" : false,
      "id_str" : "17493187",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1280437344\/ALee_11-04_crop_3_normal.jpg",
      "id" : 17493187,
      "verified" : false
    }
  },
  "id" : 463346009431478272,
  "created_at" : "2014-05-05 15:54:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    }, {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 15, 25 ],
      "id_str" : "1771141",
      "id" : 1771141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nopants",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463198923750789120",
  "geo" : { },
  "id_str" : "463200683508785152",
  "in_reply_to_user_id" : 1771141,
  "text" : "@carinnatarvin @samantham So how did you discover this? I didn't see it in my Timehop. Many #nopants-related questions over here.",
  "id" : 463200683508785152,
  "in_reply_to_status_id" : 463198923750789120,
  "created_at" : "2014-05-05 06:17:03 +0000",
  "in_reply_to_screen_name" : "samantham",
  "in_reply_to_user_id_str" : "1771141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463177097536475136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596547551, -122.2755557208 ]
  },
  "id_str" : "463184079437828097",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin I think the recovery took longer than a single day.",
  "id" : 463184079437828097,
  "in_reply_to_status_id" : 463177097536475136,
  "created_at" : "2014-05-05 05:11:04 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463178236168372224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596669063, -122.2755100765 ]
  },
  "id_str" : "463179349407969282",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey and all the white walkers and galaxies etc too.",
  "id" : 463179349407969282,
  "in_reply_to_status_id" : 463178236168372224,
  "created_at" : "2014-05-05 04:52:17 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GameOfThrones",
      "indices" : [ 0, 14 ]
    }, {
      "text" : "Cosmos",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597189525, -122.275692561 ]
  },
  "id_str" : "463178044698406912",
  "text" : "#GameOfThrones wishes it was half as epic as #Cosmos. Winter has come 4.5 billion times already, as well as 5 mass extinctions, no biggie.",
  "id" : 463178044698406912,
  "created_at" : "2014-05-05 04:47:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/463166439315083264\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/XrEulGwbcI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm1_a-4CQAADUrs.jpg",
      "id_str" : "463166438220382208",
      "id" : 463166438220382208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm1_a-4CQAADUrs.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XrEulGwbcI"
    } ],
    "hashtags" : [ {
      "text" : "Cosmos",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597440404, -122.27564025 ]
  },
  "id_str" : "463166439315083264",
  "text" : "8:36pm Sopor and I getting ready to watch #Cosmos. http:\/\/t.co\/XrEulGwbcI",
  "id" : 463166439315083264,
  "created_at" : "2014-05-05 04:00:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Crawford",
      "screen_name" : "britt",
      "indices" : [ 0, 6 ],
      "id_str" : "5362",
      "id" : 5362
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/463160202808668160\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/55YeFgywhM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm15wBTCMAAWbfI.png",
      "id_str" : "463160202577981440",
      "id" : 463160202577981440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm15wBTCMAAWbfI.png",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 924,
        "resize" : "fit",
        "w" : 2088
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/55YeFgywhM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463159871538339840",
  "geo" : { },
  "id_str" : "463160202808668160",
  "in_reply_to_user_id" : 5362,
  "text" : "@britt :( http:\/\/t.co\/55YeFgywhM",
  "id" : 463160202808668160,
  "in_reply_to_status_id" : 463159871538339840,
  "created_at" : "2014-05-05 03:36:12 +0000",
  "in_reply_to_screen_name" : "britt",
  "in_reply_to_user_id_str" : "5362",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpoonRocket",
      "screen_name" : "SpoonRocket",
      "indices" : [ 14, 26 ],
      "id_str" : "1541964121",
      "id" : 1541964121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweekend",
      "indices" : [ 39, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463159618365947904",
  "text" : "Not cool that @spoonrocket is sold out\u2014#hackweekend is ruined.",
  "id" : 463159618365947904,
  "created_at" : "2014-05-05 03:33:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/IbOegFzhpo",
      "expanded_url" : "http:\/\/hyoomans.com\/t\/my-hackweekend-project\/9\/15?u=buster",
      "display_url" : "hyoomans.com\/t\/my-hackweeke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463071638443929600",
  "text" : "The game's still super ugly, but it works! http:\/\/t.co\/IbOegFzhpo",
  "id" : 463071638443929600,
  "created_at" : "2014-05-04 21:44:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DataMingle",
      "screen_name" : "DataMingle",
      "indices" : [ 0, 11 ],
      "id_str" : "1549478280",
      "id" : 1549478280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462995237133377536",
  "geo" : { },
  "id_str" : "462996170176876545",
  "in_reply_to_user_id" : 1549478280,
  "text" : "@DataMingle Cool, thanks!",
  "id" : 462996170176876545,
  "in_reply_to_status_id" : 462995237133377536,
  "created_at" : "2014-05-04 16:44:23 +0000",
  "in_reply_to_screen_name" : "DataMingle",
  "in_reply_to_user_id_str" : "1549478280",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462994381566652416",
  "text" : "Does anyone have a couple dogecoin I can borrow?",
  "id" : 462994381566652416,
  "created_at" : "2014-05-04 16:37:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Ewing",
      "screen_name" : "hoverbird",
      "indices" : [ 0, 10 ],
      "id_str" : "792690",
      "id" : 792690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462872089083785216",
  "geo" : { },
  "id_str" : "462872574695710720",
  "in_reply_to_user_id" : 792690,
  "text" : "@hoverbird tweetships passing in the morning\/night.",
  "id" : 462872574695710720,
  "in_reply_to_status_id" : 462872089083785216,
  "created_at" : "2014-05-04 08:33:16 +0000",
  "in_reply_to_screen_name" : "hoverbird",
  "in_reply_to_user_id_str" : "792690",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Ewing",
      "screen_name" : "hoverbird",
      "indices" : [ 0, 10 ],
      "id_str" : "792690",
      "id" : 792690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462868140637290496",
  "geo" : { },
  "id_str" : "462871583149666304",
  "in_reply_to_user_id" : 792690,
  "text" : "@hoverbird Totally makes sense\u2026 I'm just being a 1am devil's advocate on Twitter, as one does.",
  "id" : 462871583149666304,
  "in_reply_to_status_id" : 462868140637290496,
  "created_at" : "2014-05-04 08:29:19 +0000",
  "in_reply_to_screen_name" : "hoverbird",
  "in_reply_to_user_id_str" : "792690",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Ewing",
      "screen_name" : "hoverbird",
      "indices" : [ 0, 10 ],
      "id_str" : "792690",
      "id" : 792690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462862396806410240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596880287, -122.2754611262 ]
  },
  "id_str" : "462864666088443904",
  "in_reply_to_user_id" : 792690,
  "text" : "@hoverbird Well, we use the same software\/mental models in dreams as during waking hours. Their correlation doesn't imply accuracy.",
  "id" : 462864666088443904,
  "in_reply_to_status_id" : 462862396806410240,
  "created_at" : "2014-05-04 08:01:50 +0000",
  "in_reply_to_screen_name" : "hoverbird",
  "in_reply_to_user_id_str" : "792690",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hyoomans",
      "screen_name" : "Hyoomans",
      "indices" : [ 36, 45 ],
      "id_str" : "2471899068",
      "id" : 2471899068
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweekend",
      "indices" : [ 5, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/BbtAi7LDg3",
      "expanded_url" : "http:\/\/hyoomans.com\/t\/my-hackweekend-project\/9\/14?u=buster",
      "display_url" : "hyoomans.com\/t\/my-hackweeke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462834849263263745",
  "text" : "Last #hackweekend update of the day @hyoomans: http:\/\/t.co\/BbtAi7LDg3 Realizing now how stupid I was for not buying ice cream at the store.",
  "id" : 462834849263263745,
  "created_at" : "2014-05-04 06:03:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/462801121518432256\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/PS2tlfmhC7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmwzKkfCYAAsjNh.jpg",
      "id_str" : "462801118397882368",
      "id" : 462801118397882368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmwzKkfCYAAsjNh.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PS2tlfmhC7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596765455, -122.2754493916 ]
  },
  "id_str" : "462801121518432256",
  "text" : "8:36pm Just Sopor and I in this too quiet house. http:\/\/t.co\/PS2tlfmhC7",
  "id" : 462801121518432256,
  "created_at" : "2014-05-04 03:49:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "indices" : [ 3, 17 ],
      "id_str" : "1901375096",
      "id" : 1901375096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462751210886270976",
  "text" : "RT @buster_ebooks: Barbara Walters and I are doing something for the robot revolution part",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/busterbenson.com\" rel=\"nofollow\"\u003EBuster eBooks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "462750745104617472",
    "text" : "Barbara Walters and I are doing something for the robot revolution part",
    "id" : 462750745104617472,
    "created_at" : "2014-05-04 00:29:09 +0000",
    "user" : {
      "name" : "buster ebooks",
      "screen_name" : "buster_ebooks",
      "protected" : false,
      "id_str" : "1901375096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000503050571\/228ccabfeeb4e55bd8e172595babe02e_normal.jpeg",
      "id" : 1901375096,
      "verified" : false
    }
  },
  "id" : 462751210886270976,
  "created_at" : "2014-05-04 00:31:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hyoomans",
      "screen_name" : "Hyoomans",
      "indices" : [ 116, 125 ],
      "id_str" : "2471899068",
      "id" : 2471899068
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweekend",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666152, -122.2755249125 ]
  },
  "id_str" : "462743660044382208",
  "text" : "Implemented nested logic and access to actions and outcomes from past turns. Time for a stretch break! #hackweekend @Hyoomans",
  "id" : 462743660044382208,
  "created_at" : "2014-05-04 00:01:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hyoomans",
      "screen_name" : "Hyoomans",
      "indices" : [ 3, 12 ],
      "id_str" : "2471899068",
      "id" : 2471899068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/OjkMzW9XSc",
      "expanded_url" : "http:\/\/hyoomans.com\/t\/questions-ask-them-here\/16",
      "display_url" : "hyoomans.com\/t\/questions-as\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462691469489217536",
  "text" : "RT @Hyoomans: Have questions about the the game, or just want to toss around ideas? I added a discussion topic for just that. AMA! http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/OjkMzW9XSc",
        "expanded_url" : "http:\/\/hyoomans.com\/t\/questions-ask-them-here\/16",
        "display_url" : "hyoomans.com\/t\/questions-as\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "462691290316939264",
    "text" : "Have questions about the the game, or just want to toss around ideas? I added a discussion topic for just that. AMA! http:\/\/t.co\/OjkMzW9XSc",
    "id" : 462691290316939264,
    "created_at" : "2014-05-03 20:32:54 +0000",
    "user" : {
      "name" : "Hyoomans",
      "screen_name" : "Hyoomans",
      "protected" : false,
      "id_str" : "2471899068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461744488671498240\/PpOO_IuH_normal.png",
      "id" : 2471899068,
      "verified" : false
    }
  },
  "id" : 462691469489217536,
  "created_at" : "2014-05-03 20:33:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hyoomans",
      "screen_name" : "Hyoomans",
      "indices" : [ 131, 140 ],
      "id_str" : "2471899068",
      "id" : 2471899068
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweekend",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462682956104884224",
  "text" : "I can now play the game from the command line, as long as strategies require no nested logic or memory of past turns. #hackweekend @hyoomans",
  "id" : 462682956104884224,
  "created_at" : "2014-05-03 19:59:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill S.",
      "screen_name" : "outseide",
      "indices" : [ 0, 9 ],
      "id_str" : "143694663",
      "id" : 143694663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462636710925705216",
  "geo" : { },
  "id_str" : "462637375416307712",
  "in_reply_to_user_id" : 143694663,
  "text" : "@outseide Thank you!",
  "id" : 462637375416307712,
  "in_reply_to_status_id" : 462636710925705216,
  "created_at" : "2014-05-03 16:58:40 +0000",
  "in_reply_to_screen_name" : "outseide",
  "in_reply_to_user_id_str" : "143694663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hyoomans",
      "screen_name" : "Hyoomans",
      "indices" : [ 128, 137 ],
      "id_str" : "2471899068",
      "id" : 2471899068
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweekend",
      "indices" : [ 89, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462634549353005056",
  "text" : "Went to Whole Foods and stocked up on 2 days of food for myself and poor sick Sopor. Let #hackweekend begin! Live-tweeting from @hyoomans.",
  "id" : 462634549353005056,
  "created_at" : "2014-05-03 16:47:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 11, 20 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "750 Words",
      "screen_name" : "750words",
      "indices" : [ 59, 68 ],
      "id_str" : "401833335",
      "id" : 401833335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462598805389459456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597303992, -122.2753396725 ]
  },
  "id_str" : "462633847713062912",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne @RickWebb Not every service needs a mobile app. @750words is a great example.",
  "id" : 462633847713062912,
  "in_reply_to_status_id" : 462598805389459456,
  "created_at" : "2014-05-03 16:44:39 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462540462549901312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596989839, -122.2755154427 ]
  },
  "id_str" : "462595176150482946",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine That sounds amazing. Wish I had known about it! Next time...",
  "id" : 462595176150482946,
  "in_reply_to_status_id" : 462540462549901312,
  "created_at" : "2014-05-03 14:10:59 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462518073585442816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596891603, -122.2754561809 ]
  },
  "id_str" : "462589125216858112",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb that would be way too practical. :)",
  "id" : 462589125216858112,
  "in_reply_to_status_id" : 462518073585442816,
  "created_at" : "2014-05-03 13:46:56 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Ewing",
      "screen_name" : "hoverbird",
      "indices" : [ 0, 10 ],
      "id_str" : "792690",
      "id" : 792690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462485158558715904",
  "geo" : { },
  "id_str" : "462485849016246272",
  "in_reply_to_user_id" : 792690,
  "text" : "@hoverbird No, you never did! That's rad.",
  "id" : 462485849016246272,
  "in_reply_to_status_id" : 462485158558715904,
  "created_at" : "2014-05-03 06:56:33 +0000",
  "in_reply_to_screen_name" : "hoverbird",
  "in_reply_to_user_id_str" : "792690",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Ewing",
      "screen_name" : "hoverbird",
      "indices" : [ 0, 10 ],
      "id_str" : "792690",
      "id" : 792690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/1dJXklS7ZO",
      "expanded_url" : "http:\/\/hyoomans.com",
      "display_url" : "hyoomans.com"
    } ]
  },
  "in_reply_to_status_id_str" : "462481822291881984",
  "geo" : { },
  "id_str" : "462481972422406144",
  "in_reply_to_user_id" : 792690,
  "text" : "@hoverbird Awesome! Sign up at http:\/\/t.co\/1dJXklS7ZO and I'll let you know when there's stuff to play with.",
  "id" : 462481972422406144,
  "in_reply_to_status_id" : 462481822291881984,
  "created_at" : "2014-05-03 06:41:09 +0000",
  "in_reply_to_screen_name" : "hoverbird",
  "in_reply_to_user_id_str" : "792690",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hyoomans",
      "screen_name" : "Hyoomans",
      "indices" : [ 3, 12 ],
      "id_str" : "2471899068",
      "id" : 2471899068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/QABe3Ff2Px",
      "expanded_url" : "http:\/\/hyoomans.com\/t\/the-game-pieces-and-the-board\/12",
      "display_url" : "hyoomans.com\/t\/the-game-pie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462463957937029120",
  "text" : "RT @Hyoomans: The game board and the pieces: http:\/\/t.co\/QABe3Ff2Px",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/QABe3Ff2Px",
        "expanded_url" : "http:\/\/hyoomans.com\/t\/the-game-pieces-and-the-board\/12",
        "display_url" : "hyoomans.com\/t\/the-game-pie\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "462463851980541952",
    "text" : "The game board and the pieces: http:\/\/t.co\/QABe3Ff2Px",
    "id" : 462463851980541952,
    "created_at" : "2014-05-03 05:29:09 +0000",
    "user" : {
      "name" : "Hyoomans",
      "screen_name" : "Hyoomans",
      "protected" : false,
      "id_str" : "2471899068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461744488671498240\/PpOO_IuH_normal.png",
      "id" : 2471899068,
      "verified" : false
    }
  },
  "id" : 462463957937029120,
  "created_at" : "2014-05-03 05:29:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dary",
      "screen_name" : "chrisdary",
      "indices" : [ 0, 10 ],
      "id_str" : "15441990",
      "id" : 15441990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462455707468455936",
  "geo" : { },
  "id_str" : "462456996176748544",
  "in_reply_to_user_id" : 15441990,
  "text" : "@chrisdary Cool, definitely helpful! I think I\u2019ll end up designing something like this\u2026 hopefully simpler and more specific to my task.",
  "id" : 462456996176748544,
  "in_reply_to_status_id" : 462455707468455936,
  "created_at" : "2014-05-03 05:01:54 +0000",
  "in_reply_to_screen_name" : "chrisdary",
  "in_reply_to_user_id_str" : "15441990",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dary",
      "screen_name" : "chrisdary",
      "indices" : [ 0, 10 ],
      "id_str" : "15441990",
      "id" : 15441990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462453319202377729",
  "geo" : { },
  "id_str" : "462453925321265152",
  "in_reply_to_user_id" : 15441990,
  "text" : "@chrisdary Do you know of any examples of finite state machines being represented in XML or JSON? Examples might increase my chances here\u2026",
  "id" : 462453925321265152,
  "in_reply_to_status_id" : 462453319202377729,
  "created_at" : "2014-05-03 04:49:42 +0000",
  "in_reply_to_screen_name" : "chrisdary",
  "in_reply_to_user_id_str" : "15441990",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dary",
      "screen_name" : "chrisdary",
      "indices" : [ 0, 10 ],
      "id_str" : "15441990",
      "id" : 15441990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462452600902647808",
  "geo" : { },
  "id_str" : "462452934756663296",
  "in_reply_to_user_id" : 15441990,
  "text" : "@chrisdary Yeah, it\u2019s still mostly in my head. My goal is to at least get the idea of it all out of my head, and to maybe build a bit of it.",
  "id" : 462452934756663296,
  "in_reply_to_status_id" : 462452600902647808,
  "created_at" : "2014-05-03 04:45:46 +0000",
  "in_reply_to_screen_name" : "chrisdary",
  "in_reply_to_user_id_str" : "15441990",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dary",
      "screen_name" : "chrisdary",
      "indices" : [ 0, 10 ],
      "id_str" : "15441990",
      "id" : 15441990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462450297512525824",
  "geo" : { },
  "id_str" : "462451696996610048",
  "in_reply_to_user_id" : 15441990,
  "text" : "@chrisdary I'd like it to be simple enough that a non-programmer could write strategies. Even XML and JSON is a bit advanced for a game.",
  "id" : 462451696996610048,
  "in_reply_to_status_id" : 462450297512525824,
  "created_at" : "2014-05-03 04:40:51 +0000",
  "in_reply_to_screen_name" : "chrisdary",
  "in_reply_to_user_id_str" : "15441990",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hyoomans",
      "screen_name" : "Hyoomans",
      "indices" : [ 10, 19 ],
      "id_str" : "2471899068",
      "id" : 2471899068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/AwMiEsvcGB",
      "expanded_url" : "http:\/\/www.iterated-prisoners-dilemma.net\/prisoners-dilemma-strategies.shtml",
      "display_url" : "iterated-prisoners-dilemma.net\/prisoners-dile\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "462439571452485633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596926937, -122.2755118028 ]
  },
  "id_str" : "462439957529755648",
  "in_reply_to_user_id" : 2471899068,
  "text" : "Ideas? RT @Hyoomans: Step 1 is to find the best way to represent prisoner's dilemma strategies. XML\/JSON\/etc? http:\/\/t.co\/AwMiEsvcGB",
  "id" : 462439957529755648,
  "in_reply_to_status_id" : 462439571452485633,
  "created_at" : "2014-05-03 03:54:12 +0000",
  "in_reply_to_screen_name" : "Hyoomans",
  "in_reply_to_user_id_str" : "2471899068",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/462436088011694080\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/Idycqfg5MS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmrnKh1CMAAOHfX.jpg",
      "id_str" : "462436079824416768",
      "id" : 462436079824416768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmrnKh1CMAAOHfX.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Idycqfg5MS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8546257729, -122.2712094931 ]
  },
  "id_str" : "462436088011694080",
  "text" : "8:36pm Venus looks almost as big as the moon here http:\/\/t.co\/Idycqfg5MS",
  "id" : 462436088011694080,
  "created_at" : "2014-05-03 03:38:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the wrens",
      "screen_name" : "thewrens",
      "indices" : [ 0, 9 ],
      "id_str" : "26252918",
      "id" : 26252918
    }, {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 10, 19 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461940709252431874",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7791244972, -122.4143832319 ]
  },
  "id_str" : "462428624390737920",
  "in_reply_to_user_id" : 26252918,
  "text" : "@thewrens @spangley Woah this is big news!",
  "id" : 462428624390737920,
  "in_reply_to_status_id" : 461940709252431874,
  "created_at" : "2014-05-03 03:09:10 +0000",
  "in_reply_to_screen_name" : "thewrens",
  "in_reply_to_user_id_str" : "26252918",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    }, {
      "name" : "Hyoomans",
      "screen_name" : "Hyoomans",
      "indices" : [ 10, 19 ],
      "id_str" : "2471899068",
      "id" : 2471899068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462425860767612929",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7795615141, -122.4137733667 ]
  },
  "id_str" : "462427073164746754",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover @Hyoomans We'll see how far I can get... but that's a great plan. :)",
  "id" : 462427073164746754,
  "in_reply_to_status_id" : 462425860767612929,
  "created_at" : "2014-05-03 03:03:00 +0000",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hyoomans",
      "screen_name" : "Hyoomans",
      "indices" : [ 113, 122 ],
      "id_str" : "2471899068",
      "id" : 2471899068
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweekend",
      "indices" : [ 33, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/1dJXklS7ZO",
      "expanded_url" : "http:\/\/hyoomans.com",
      "display_url" : "hyoomans.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776414404, -122.4168118741 ]
  },
  "id_str" : "462423777763024896",
  "text" : "Really excited to start my 2-day #hackweekend game idea. Check out http:\/\/t.co\/1dJXklS7ZO for details and follow @hyoomans for updates.",
  "id" : 462423777763024896,
  "created_at" : "2014-05-03 02:49:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Atwood",
      "screen_name" : "codinghorror",
      "indices" : [ 0, 13 ],
      "id_str" : "5637652",
      "id" : 5637652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462378570946330624",
  "geo" : { },
  "id_str" : "462378818682904576",
  "in_reply_to_user_id" : 5637652,
  "text" : "@codinghorror Are you sure Minecraft isn't today's Logo?",
  "id" : 462378818682904576,
  "in_reply_to_status_id" : 462378570946330624,
  "created_at" : "2014-05-02 23:51:15 +0000",
  "in_reply_to_screen_name" : "codinghorror",
  "in_reply_to_user_id_str" : "5637652",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/0FyQtuiScm",
      "expanded_url" : "http:\/\/notonappstore.com\/",
      "display_url" : "notonappstore.com"
    } ]
  },
  "geo" : { },
  "id_str" : "462361529480777728",
  "text" : "Not available on the App Store: http:\/\/t.co\/0FyQtuiScm",
  "id" : 462361529480777728,
  "created_at" : "2014-05-02 22:42:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/06Wu3nEIGF",
      "expanded_url" : "http:\/\/www.thehumorcolumnist.com\/atlantics-never-ending-end-stories\/",
      "display_url" : "thehumorcolumnist.com\/atlantics-neve\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462357964750200832",
  "text" : "RT @isaach: in which not just twitter but the entire world crumbles around our very ears http:\/\/t.co\/06Wu3nEIGF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/06Wu3nEIGF",
        "expanded_url" : "http:\/\/www.thehumorcolumnist.com\/atlantics-never-ending-end-stories\/",
        "display_url" : "thehumorcolumnist.com\/atlantics-neve\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "461961869247258624",
    "text" : "in which not just twitter but the entire world crumbles around our very ears http:\/\/t.co\/06Wu3nEIGF",
    "id" : 461961869247258624,
    "created_at" : "2014-05-01 20:14:27 +0000",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430605387117494272\/lmplHwca_normal.png",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 462357964750200832,
  "created_at" : "2014-05-02 22:28:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462312782654750720",
  "geo" : { },
  "id_str" : "462314609953632256",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley that\u2019s a super cute creature.",
  "id" : 462314609953632256,
  "in_reply_to_status_id" : 462312782654750720,
  "created_at" : "2014-05-02 19:36:07 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/buster\/status\/462074591980957696\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/RSChjk94Oi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmmeZHrCcAEArnb.jpg",
      "id_str" : "462074591175667713",
      "id" : 462074591175667713,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmmeZHrCcAEArnb.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/RSChjk94Oi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597308617, -122.2755891006 ]
  },
  "id_str" : "462074591980957696",
  "text" : "8:36pm Found out today that Sopor is sicker than we were hoping. Poor girl. http:\/\/t.co\/RSChjk94Oi",
  "id" : 462074591980957696,
  "created_at" : "2014-05-02 03:42:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lookingoooood",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/4tS9iFeJ8d",
      "expanded_url" : "https:\/\/vine.co\/",
      "display_url" : "vine.co"
    } ]
  },
  "geo" : { },
  "id_str" : "461965030926213120",
  "text" : "#lookingoooood https:\/\/t.co\/4tS9iFeJ8d",
  "id" : 461965030926213120,
  "created_at" : "2014-05-01 20:27:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    }, {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "indices" : [ 10, 15 ],
      "id_str" : "949521",
      "id" : 949521
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 16, 23 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461920259810009089",
  "geo" : { },
  "id_str" : "461922525010604034",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim @stop @sippey I don't have a very strong defense against that argument.",
  "id" : 461922525010604034,
  "in_reply_to_status_id" : 461920259810009089,
  "created_at" : "2014-05-01 17:38:06 +0000",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461920092310106112",
  "geo" : { },
  "id_str" : "461920560587370496",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey Thanks! I'm gonna totally rock this standup.",
  "id" : 461920560587370496,
  "in_reply_to_status_id" : 461920092310106112,
  "created_at" : "2014-05-01 17:30:18 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "indices" : [ 0, 5 ],
      "id_str" : "949521",
      "id" : 949521
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 6, 13 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461917947619860480",
  "geo" : { },
  "id_str" : "461919981861490688",
  "in_reply_to_user_id" : 949521,
  "text" : "@stop @sippey I'm not really liking mine anymore. Prepare thyself for another switcheroo soon. I know, change is scary.",
  "id" : 461919981861490688,
  "in_reply_to_status_id" : 461917947619860480,
  "created_at" : "2014-05-01 17:28:00 +0000",
  "in_reply_to_screen_name" : "stop",
  "in_reply_to_user_id_str" : "949521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461917000566980608",
  "geo" : { },
  "id_str" : "461919636548624384",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey I hope they also enable always-on Siri integration: \"OK Siri, play something that'll pump me up for my next meeting.\"",
  "id" : 461919636548624384,
  "in_reply_to_status_id" : 461917000566980608,
  "created_at" : "2014-05-01 17:26:38 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461916205255651328",
  "geo" : { },
  "id_str" : "461916692365320193",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey Once it's fully integrated drone doctors will be automatically dispatched to your house.",
  "id" : 461916692365320193,
  "in_reply_to_status_id" : 461916205255651328,
  "created_at" : "2014-05-01 17:14:56 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Secret",
      "screen_name" : "getsecret",
      "indices" : [ 105, 115 ],
      "id_str" : "2244765331",
      "id" : 2244765331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/UpwJTa2Gm2",
      "expanded_url" : "https:\/\/www.secret.ly\/p\/uvvnhatfbvfdrlfzypihnshsbq",
      "display_url" : "secret.ly\/p\/uvvnhatfbvfd\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776296, -122.416737 ]
  },
  "id_str" : "461911456594673664",
  "text" : "Exciting if true. \"Apple's new EarPods will have sensors in them, for heart rate &amp; blood pressure.\"- @getsecret https:\/\/t.co\/UpwJTa2Gm2",
  "id" : 461911456594673664,
  "created_at" : "2014-05-01 16:54:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 19, 30 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/HtMnBy3C2D",
      "expanded_url" : "http:\/\/bit.ly\/1n6I9SW",
      "display_url" : "bit.ly\/1n6I9SW"
    } ]
  },
  "in_reply_to_status_id_str" : "461869562968170496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597459838, -122.2755861972 ]
  },
  "id_str" : "461878378010644480",
  "in_reply_to_user_id" : 14120151,
  "text" : "Iiiiinteresting RT @foursquare: A look into the future of Foursquare, including a new app called Swarm http:\/\/t.co\/HtMnBy3C2D",
  "id" : 461878378010644480,
  "in_reply_to_status_id" : 461869562968170496,
  "created_at" : "2014-05-01 14:42:41 +0000",
  "in_reply_to_screen_name" : "foursquare",
  "in_reply_to_user_id_str" : "14120151",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462321784386117632\/ZWai-QL4_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]