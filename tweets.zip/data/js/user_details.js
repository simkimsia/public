var user_details =  {
  "expanded_url" : "http:\/\/busterbenson.com",
  "screen_name" : "buster",
  "location" : "Berkeley, CA",
  "url" : "http:\/\/t.co\/JghZ8d7hCO",
  "full_name" : "Buster",
  "bio" : "Product manager on http:\/\/t.co\/GAkyhXMcgU. Amateur behavior change fanatic\/skeptic. I tweet 10.4 times\/day, retweet 1.4 times\/day, and get 2.1 faves\/tweet.",
  "id" : "2185",
  "created_at" : "2006-07-18 04:35:07 +0000",
  "display_url" : "busterbenson.com"
}